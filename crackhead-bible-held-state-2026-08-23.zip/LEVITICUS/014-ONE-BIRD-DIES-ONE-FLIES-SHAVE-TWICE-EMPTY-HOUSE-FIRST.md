# CRACKHEAD LEVITICUS 14

## Title page

**ONE BIRD DIES. ONE BIRD FLIES. SHAVE EVERYTHING TWICE.**

**HOUSE LOOKS WRONG? EMPTY THE BASTARD BEFORE THE PRIEST LOOKS.**

Source parent: Leviticus chapter 14, verses 1–57, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-014/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/013-PRIEST-LOOKS-WAIT-LOOKS-AGAIN-SPREAD-BURN-FADE-WASH.md`.

CrackFlix routing: none. Every change follows an explicit prospective branch;
no healed person, house or performed inspection is narrated.

## Causal foundation

```text
HEALED PERSON OUTSIDE CAMP
-> PRIEST GOES OUT + EXAMINES
-> TWO CLEAN BIRDS + CEDAR + SCARLET + HYSSOP
-> KILL ONE BIRD IN CLAY VESSEL OVER RUNNING WATER
-> DIP LIVE BIRD + MATERIALS IN BLOOD/WATER
-> SPRINKLE PERSON 7 / PRONOUNCE CLEAN / RELEASE LIVE BIRD
-> WASH CLOTHES / SHAVE ALL HAIR / BATHE
-> ENTER CAMP / STAY OUTSIDE OWN TENT 7
-> DAY 7 SHAVE HEAD + BEARD + EYEBROWS + ALL HAIR
-> WASH CLOTHES + BATHE -> CLEAN

DAY 8 STANDARD PACKAGE
-> 2 MALE LAMBS + 1 EWE LAMB + 3/10 FLOUR/OIL + 1 LOG OIL
-> TRESPASS LAMB + OIL WAVED
-> LAMB KILLED
-> BLOOD TO RIGHT EAR / THUMB / BIG TOE
-> OIL LEFT PALM / RIGHT FINGER / SPRINKLE 7
-> OIL OVER BLOOD ADDRESSES + REST ON HEAD
-> SIN OFFERING -> BURNT + MEAL OFFERINGS
-> ATTRIBUTED ATONEMENT / CLEAN

POOR / CANNOT AFFORD STANDARD PACKAGE
-> 1 MALE TRESPASS LAMB + 1/10 FLOUR/OIL + 1 LOG OIL
-> 2 TURTLEDOVES OR 2 PIGEONS
-> SAME BLOOD/OIL EAR-THUMB-TOE/HEAD ROUTE
-> ONE BIRD SIN + ONE BIRD BURNT
-> ATTRIBUTED ATONEMENT

FUTURE CANAAN HOUSE + GOD-ATTRIBUTED MILDEW
-> OWNER SAYS: THERE SEEMS TO ME SOME SORT OF PLAGUE
-> PRIEST ORDERS HOUSE EMPTIED BEFORE ENTRY
-> INSPECT HOLLOW GREENISH/REDDISH DEEP WALL STREAKS
-> SHUT HOUSE 7
-> IF SPREAD -> REMOVE STONES / SCRAPE ALL / DUMP OUTSIDE CITY
-> NEW STONES + NEW MORTAR + REPLASTER
-> IF RETURNS + SPREADS -> DEMOLISH WHOLE HOUSE / DUMP OUTSIDE CITY
-> ENTRY WHILE SHUT = UNCLEAN UNTIL EVENING
-> LIE OR EAT INSIDE = WASH CLOTHES
-> IF NO SPREAD AFTER REPLASTER -> PRONOUNCE CLEAN
-> TWO-BIRD / CEDAR / SCARLET / HYSSOP HOUSE CLEANSING
```

## Leviticus 14:1–7 — THE PRIEST LEAVES CAMP; ONE BIRD COMES BACK

The LORD speaks directly to Moses. On the cleansing day, the priest goes outside
the camp and examines the person. Only if the source-classified plague is healed
does the cleansing route begin.

Two living clean birds, cedar wood, scarlet and hyssop are taken. One bird is
killed in an earthen vessel over running water. The live bird and materials are
dipped in the killed bird's blood over that water. The priest sprinkles the
person seven times, pronounces clean and releases the living bird into the open
field.

Two birds enter different stated routes. No bird, person, priest, field or act
is instantiated by this law.

## Leviticus 14:8–9 — CLEAN ENOUGH FOR CAMP; NOT YET INSIDE HIS TENT

The person washes clothes, shaves all hair and bathes, then is clean and may
enter camp. He still remains outside his own tent for seven days.

On the seventh day he shaves all hair again, with head, beard and eyebrows
explicitly named, washes clothes and bathes. He is then clean. Camp entry and
own-tent entry are different boundaries.

## Leviticus 14:10–20 — DAY EIGHT LOADS EAR, THUMB, TOE AND HEAD

The standard eighth-day package is two defect-free male lambs, one defect-free
one-year ewe lamb, three-tenths of an ephah of fine flour mixed with oil and one
log of oil. The cleansing priest presents the person and package at the Tent
door.

One male lamb and the oil are waved as a trespass offering package. The lamb is
killed in the sanctuary slaughter place. Its blood goes on the person's right
ear tip, right thumb and right big toe.

The priest pours oil into his left palm, uses his right finger to sprinkle oil
seven times, then puts oil on the same right ear/thumb/toe addresses over the
blood. Remaining oil goes on the person's head.

The priest next offers the sin offering, then kills and offers the burnt
offering with the meal offering. Atonement and resulting cleanliness remain
source-attributed effects.

## Leviticus 14:21–32 — POOR DOESN'T DELETE THE EAR-THUMB-TOE ROUTE

If the person is poor and cannot afford the standard package, the package
becomes one male trespass lamb, one-tenth ephah of oil-mixed flour, one log of
oil and two turtledoves or two young pigeons as affordable.

The trespass lamb/oil wave, killing, blood on right ear/thumb/toe, oil in left
palm, right-finger sevenfold sprinkle, oil over the three blood addresses and
remaining oil on the head all remain.

One affordable bird becomes the sin offering and the other the burnt offering,
with the meal offering. The chapter repeats “able to afford” and closes this as
the law for a person unable to afford the cleansing sacrifice. Means changes
the package, not the retained body-address route.

## Leviticus 14:33–35 — FUTURE LAND, FUTURE HOUSE, OWNER SAYS ONLY WHAT HE SEES

The LORD then speaks directly to Moses and Aaron about a future condition after
Israel enters Canaan, which the LORD calls a possession he gives them. The LORD
says, “I put a spreading mildew in a house.” This causation remains exact
God-only speech; no physical mechanism is invented.

The house owner is to tell the priest, **“There seems to me to be some sort of
plague in the house.”** The owner reports appearance, not certainty, cause or
diagnosis.

## Leviticus 14:36–42 — EMPTY FIRST, THEN INSPECT, THEN REBUILD THE PATCH

Before entering, the priest orders the house emptied so its contents are not
made unclean by the inspection State. He then inspects.

Hollow greenish or reddish wall streaks that appear deeper than the wall route
to seven days of house closure. If they spread, affected stones are removed to
an unclean place outside the city, the whole interior is scraped, scraped mortar
goes to the same outside place, and new stones and mortar replaster the house.

The empty-first instruction preserves movable contents before the priest's
classification. No inventory, owner, city, house or actual mildew is supplied.

## Leviticus 14:43–45 — IF IT COMES BACK AFTER ALL THAT, THE HOUSE GOES

If the plague returns after stones were removed, walls scraped and the house
replastered, the priest returns. If it has spread, the source calls it destructive
mildew and unclean.

The whole house—stones, timber and mortar—is broken down and carried outside the
city to an unclean place. Patch replacement and whole-house demolition are
sequential escalation branches, not contradictory responses to one State.

## Leviticus 14:46–47 — CLOSED-HOUSE ENTRY HAS THREE CONTACT LEVELS

Entering the house while it is shut makes the entrant unclean until evening.
Lying down inside requires clothes washing. Eating inside also requires clothes
washing. The source supplies no meal, sleeper, entrant or enforcement event.

## Leviticus 14:48–53 — NO SPREAD AFTER REPLASTER GETS THE TWO-BIRD ROUTE

If the priest finds no spread after replastering, he pronounces the house clean
because the source calls the plague healed.

Two birds, cedar, scarlet and hyssop are used again. One bird is killed in an
earthen vessel over running water. The live bird and materials are dipped in the
blood and water, and the house is sprinkled seven times. The live bird is
released outside the city into the open field. The source attributes atonement
and cleanliness to the house.

## Leviticus 14:54–57 — THE INDEX SAYS WHAT THIS MACHINE IS FOR

The chapter closes by indexing leprosy, itch, garment and house mildew,
swelling, scab and bright spot. Its stated teaching function is when a State is
unclean and when it is clean.

## Character and world-ledger changes

- LORD directly gives Moses the healed-person cleansing route;
- LORD directly gives Moses and Aaron the future Canaan house route;
- priest goes outside camp rather than importing the person before examination;
- one clean bird is killed and the other released in person and house routes;
- person receives two full shave/wash/bathe passes with gated camp/tent entry;
- standard and poor eighth-day packages retain separate quantities;
- both means branches retain blood/oil right-ear, right-thumb and right-big-toe addressing;
- source-attributed atonement and cleanliness remain effects, not invented mechanics;
- God-only speech retains “I put a spreading mildew in a house”;
- owner speech remains uncertain appearance report, not diagnosis;
- house is emptied before priest inspection;
- seven-day closure, stone removal, scraping, replastering and demolition remain sequential branches;
- closed-house entry, lying and eating have distinct outputs;
- no actual person, bird, lamb, house, owner, inspection, cleansing or demolition occurs;
- all prospective living people, birds, lambs and material-source organisms are Joe-faced;
- no contradiction, SKIP, crack or Captain appearance occurs;
- publication remains held; Canaan entry, Nadab/Abihu burial, cloud departure and Joseph burial remain open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — REENTRY AND STRUCTURAL SUPPORT`;
- bird transaction: `ONE INTO BLOOD / ONE INTO FIELD`;
- human wash cycle: `SHAVE WASH BATHE / WAIT 7 / SHAVE WASH BATHE AGAIN`;
- access status: `CAMP YES / OWN TENT NOT YET`;
- body ports: `RIGHT EAR / RIGHT THUMB / RIGHT BIG TOE`;
- oil UI: `LEFT PALM / RIGHT FINGER / SPRINKLE X7`;
- budget mode: `FEWER LAMBS / SAME BODY PORTS`;
- owner support ticket: `SEEMS TO ME SOME SORT OF PLAGUE`;
- priest preflight: `EMPTY HOUSE BEFORE LOOKING`;
- structural repair: `BAD STONES OUT / WALLS SCRAPED / NEW PATCH IN`;
- recurrence warranty: `WHOLE FUCKING HOUSE OUTSIDE CITY`;
- barcode: `CHB-LEV14-57-BIRD-DIE-FLY-SHAVE2-EMPTYFIRST-NOCRACK-HELD`.

## FIR verification

- all 57 verse markers are represented in order;
- direct LORD speech remains God-only and speaker boundaries remain exact;
- outside-camp examination precedes the healed-person cleansing route;
- killed/live bird, clay vessel, running water, cedar, scarlet and hyssop remain complete;
- sevenfold sprinkling, pronouncement and live-bird release remain ordered;
- two shave/wash/bathe passes and camp-versus-tent access remain distinct;
- standard three-lamb/flour/oil package remains complete;
- trespass, sin, burnt and meal offering routes remain ordered;
- right ear/thumb/toe blood and oil plus head oil remain exact;
- poor package changes quantities without deleting the retained body-address route;
- Canaan and divine house-mildew causation remain attributed future speech;
- owner's exact uncertainty is preserved without upgraded diagnosis;
- empty-before-inspection protection remains explicit;
- shut, remove/scrape/replaster, recur/demolish and healed/clean routes remain distinct;
- closed-house enter/lie/eat outputs remain exact;
- house bird-cleansing route remains separate from person route despite shared materials;
- no actual occurrence or physical mechanism is invented;
- every prospective living person, animal and source organism uses Joe face if shown;
- no contradiction, SKIP, crack or Captain is added;
- publication remains held and unpublished.

Continuation required: Leviticus 15 establishes bodily-discharge, bed, seat,
touch, washing, evening, emission, intercourse and menstruation contact routes.
