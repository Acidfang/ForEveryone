# CRACKHEAD LEVITICUS 7

## Title page

**THANKS? EAT TODAY. VOW? TOMORROW IS STILL OPEN.**

**DAY THREE? BURN IT, JOE.**

Source parent: Leviticus chapter 7, verses 1–38, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-007/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/006-GIVE-IT-BACK-PLUS-A-FIFTH-KEEP-THE-FIRE-ON.md`.

CrackFlix routing: none. No completed observable contradiction occurs.

## Causal foundation

```text
TRESPASS OFFERING
-> KILL AT BURNT-OFFERING PLACE / BLOOD AROUND ALTAR
-> FAT TAIL + INNARD FAT + KIDNEYS/FAT + LIVER COVER BURNED
-> PRIEST MALES MAY EAT IN HOLY PLACE
-> ATONING PRIEST RECEIVES OFFERING

OTHER PRIEST ALLOCATIONS
-> BURNT-OFFERING PRIEST RECEIVES SKIN
-> OVEN/PAN/GRIDDLE MEAL GOES TO OFFERING PRIEST
-> OIL-MIXED OR DRY MEAL SHARED ACROSS AARON'S SONS

THANKSGIVING PEACE OFFERING
-> THREE UNLEAVENED OIL FORMS + LEAVENED BREAD
-> ONE OF EACH TO BLOOD-SPRINKLING PRIEST
-> MEAT EATEN SAME DAY / NONE LEFT MORNING

VOW OR FREEWILL PEACE OFFERING
-> EAT DAY ONE + REMAINDER DAY TWO
-> DAY THREE REMAINDER BURNED
-> DAY-THREE EATING INVALID / NOT CREDITED / INIQUITY STATED

MEAT TOUCHES UNCLEAN THING -> BURN / DO NOT EAT
CLEAN PERSON -> MAY EAT CLEAN MEAT
UNCLEAN PERSON EATS LORD'S PEACE MEAT -> CUT OFF STATED

BULL/SHEEP/GOAT FAT -> DO NOT EAT
SELF-DEAD/TORN FAT -> OTHER SERVICE ALLOWED / EATING FORBIDDEN
BIRD OR ANIMAL BLOOD -> DO NOT EAT IN ANY DWELLING

OFFERER'S OWN HANDS BRING FAT + BREAST
-> BREAST WAVED / AARON + SONS
-> FAT BURNED
-> RIGHT THIGH TO BLOOD/FAT-SERVING PRIEST
-> ALL RULES REMAIN PROSPECTIVE
```

## Leviticus 7:1–6 — TRESPASS RAM: BLOOD AROUND, FAT ON FIRE, PRIESTS EAT

The trespass offering is called most holy. It is killed where the burnt
offering is killed, and its blood is sprinkled around the altar. The fat tail,
innard-covering fat, two kidneys and their loin fat, and liver cover are removed.
The priest burns them as the LORD's fire offering.

Every male among the priests may eat the remainder in a holy place. No ram,
priest, slaughter, blood, fire or meal occurs.

## Leviticus 7:7–10 — WHICH PRIEST GETS WHICH OUTPUT

Sin and trespass offerings share one law: the priest making atonement receives
the offering. A priest who offers another Joe's burnt offering receives its
skin.

Oven-baked, pan-prepared and griddle-prepared meal offerings belong to the
priest who offers them. Meal offerings mixed with oil or dry belong equally to
all Aaron's sons.

Individual-service allocation and shared-priest allocation are separately
addressed categories. The source records no handover or consumption.

## Leviticus 7:11–15 — THANK-YOU PACKAGE: YEAST INCLUDED, CLOCK ENDS TONIGHT

A thanksgiving peace offering brings three unleavened oil forms: mixed cakes,
oil-anointed wafers and oil-mixed cakes. It also brings leavened bread. One item
from each offering is raised to the LORD and belongs to the priest who sprinkles
the peace-offering blood.

The thanksgiving sacrifice meat must be eaten on the offering day, with none
left until morning. The leavened bread is part of this thanksgiving delivery;
the source does not route it into altar fire. That does not contradict the
earlier no-yeast fire-offering rule.

## Leviticus 7:16–18 — VOW/FREEWILL PACKAGE: TOMORROW OPEN, THIRD DAY CLOSED

A vow or freewill peace sacrifice may be eaten on the offering day and its
remainder on the next day. Any meat remaining on the third day is burned.

If any is eaten on the third day, the rule says the sacrifice is not accepted
or credited to the offerer, calls it an abomination, and says the eater bears
iniquity. Thanksgiving and vow/freewill offerings have different time windows;
neither cancels the other.

## Leviticus 7:19–21 — CLEAN MEAT, CLEAN EATER, OR FIRE/CUT-OFF ROUTE

Meat touching any unclean thing must not be eaten and is burned. Everyone who
is clean may eat otherwise eligible meat.

A person with uncleanness who eats the LORD's peace-offering meat is stated to
be cut off from the people. The same outcome is stated when someone touches
human uncleanness, an unclean animal or an unclean abomination and then eats the
peace meat. No contact, eating or cutting-off event occurs.

## Leviticus 7:22–27 — FAT CAN DO OTHER WORK, BUT IT CANNOT BECOME LUNCH

The LORD tells Moses to prohibit Israel from eating bull, sheep or goat fat.
Fat from an animal that dies by itself or is torn by animals may be used for
other service but must never be eaten. Eating fire-offering animal fat carries
the stated cut-off outcome.

No bird or animal blood may be eaten in any dwelling. Anyone eating blood is
stated to be cut off. Other use and eating are different acts, so permitted use
does not conflict with prohibited consumption.

## Leviticus 7:28–34 — BRING IT YOURSELF: FAT, BREAST, THIGH ROUTER

The peace-offering Joe brings the LORD's portion with his own hands: fat with
the breast. The breast is waved before the LORD. The priest burns the fat, while
the breast belongs to Aaron and his sons.

The right thigh is a raised offering for the priest. Specifically, the Aaronic
son who offers that sacrifice's blood and fat receives the right thigh. The
LORD describes waved breast and raised thigh as a perpetual Aaronic portion from
Israel's peace offerings.

## Leviticus 7:35–38 — INSTALLATION PORTION AND SIX-LAW INDEX

The chapter identifies these portions as Aaron's and his sons' consecrated
share from the LORD's fire offerings, assigned when they were presented and
anointed for priestly service. The portion continues through generations.

It closes by indexing the laws of burnt, meal, sin, trespass, consecration and
peace offerings. The narrator locates the LORD's commands to Moses at Mount
Sinai, on the day Israel was commanded to offer in the Sinai wilderness. This
summary does not itself perform a new offering.

## Character and world-ledger changes

- trespass offering gains exact kill, blood, fat-organ and priest-eating route;
- sin/trespass, burnt-skin and meal-form priest allocations are distinguished;
- thanksgiving peace offering gains unleavened and leavened bread package;
- thanksgiving meat closes at the end of day one;
- vow/freewill meat permits day-two remainder and burns day-three remainder;
- unclean-meat and unclean-eater routes remain distinct;
- meat eligibility requires both food and eater cleanliness;
- self-dead/torn fat permits non-food service while prohibiting eating;
- blood prohibition covers bird and animal in every dwelling;
- offerer personally brings fat and breast;
- breast goes to Aaronic family; right thigh goes to serving priest;
- Aaronic portions retain installation and generational continuity;
- six offering-law families are indexed without merging their branches;
- all claimed acceptance, credit, iniquity, holiness and cut-off effects remain attributed;
- all prospective people, animals and living material sources are Joe-faced;
- no contradiction, SKIP, crack or Captain appearance occurs;
- no offering, eating, uncleanness, allocation or penalty occurs;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — SACRIFICE LEFTOVER SUPPORT MATRIX`;
- trespass hardware: `BLOOD 360 / FAT TAIL / TWO KIDNEYS / LIVER COVER`;
- priest output router: `ATONED IT = GET IT / BURNT IT = GET SKIN`;
- meal allocation: `COOKED UNIT = ACTIVE PRIEST / OIL OR DRY = TEAM SHARE`;
- thanks timer: `DAY ONE ONLY / FRIDGE NOT CANON`;
- vow timer: `DAY ONE + DAY TWO / DAY THREE FIRE`;
- cleanliness firewall: `DIRTY MEAT BURN / DIRTY JOE DO NOT EAT`;
- fat licence: `OTHER SERVICE YES / MOUTH NO`;
- blood licence: `BIRD NO / ANIMAL NO / EVERY HOUSE NO`;
- manual input: `BRING YOUR OWN FAT AND BREAST, JOE`;
- priest payroll: `WAVE BREAST FAMILY PLAN / RIGHT THIGH ACTIVE OPERATOR`;
- index: `BURNT MEAL SIN TRESPASS CONSECRATION PEACE`;
- barcode: `CHB-LEV07-38-DAY1-DAY2-DAY3FIRE-FATNO-BLOODNO-NOCRACK-HELD`.

## FIR verification

- all 38 verse markers are represented in order;
- trespass kill place, blood route and exact fat organs remain complete;
- individual and shared priest allocations retain their offering-form selectors;
- thanksgiving bread forms include both unleavened and leavened inputs;
- no unsupported altar burning of leavened bread is invented;
- thanksgiving and vow/freewill meat clocks remain distinct;
- day-three burn and prohibited eating consequences remain attributed rules;
- unclean meat and unclean eater branches do not merge;
- human/animal/abomination contact inputs remain stated without added motives;
- fat other-service permission remains distinct from eating prohibition;
- bull/sheep/goat fat and bird/animal blood categories remain exact;
- own-hands delivery, wave breast, burned fat and right thigh remain allocated;
- serving-priest and family-wide portions remain distinguishable;
- anointing-day/generational allocation and six-law summary remain retained;
- instructions do not become performed offerings, meals or penalties;
- no unsupported contradiction is manufactured, so Captain does not appear;
- every prospective living person, animal and source organism uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Leviticus 8 records the commanded ordination assembly,
clothing, anointing, sacrifices and seven-day Tent-door stay as performed acts.
