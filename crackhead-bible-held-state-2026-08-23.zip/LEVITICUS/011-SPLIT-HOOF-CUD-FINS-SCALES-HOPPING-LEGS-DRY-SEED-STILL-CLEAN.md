# CRACKHEAD LEVITICUS 11

## Title page

**SPLIT HOOF AND CUD. FINS AND SCALES.**

**HOPPING LEGS GET THROUGH. DRY SEED STILL CLEAN.**

Source parent: Leviticus chapter 11, verses 1–47, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-011/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/010-NOT-COMMANDED-FIRE-IN-ATE-RULE-OUT-BURNED-ANSWER-ACCEPTED.md`.

CrackFlix routing: none. No completed observable contradiction occurs.

## Causal foundation

```text
LORD SPEAKS TO MOSES + AARON
-> LAND FOOD = FULLY PARTED HOOF + CHEWS CUD
-> CAMEL / HYRAX / HARE FAIL HOOF
-> PIG FAILS CUD
-> DO NOT EAT MEAT OR TOUCH CARCASSES

WATER FOOD = FINS + SCALES
-> BOTH PRESENT = MAY EAT
-> EITHER ABSENT = DETEST / DO NOT EAT / DETEST CARCASS

BIRD EXCLUSION LIST
-> EAGLE THROUGH BAT RETAINED IN SOURCE ORDER

WINGED CRAWLER
-> FOUR-FOOTED = DO NOT EAT
-> JOINTED HOPPING LEGS = MAY EAT
-> LOCUST / KATYDID / CRICKET / GRASSHOPPER KINDS ALLOWED

UNCLEAN CARCASS TOUCH
-> PERSON UNCLEAN UNTIL EVENING
-> CARRIER ALSO WASHES CLOTHES
-> INCOMPLETE HOOF / NON-CUD / PAW WALKERS INCLUDED

DEAD CREEPER FALLS
-> WOOD / CLOTHING / SKIN / SACK / WORK VESSEL -> WATER -> EVENING -> CLEAN
-> EARTHEN VESSEL -> CONTENTS UNCLEAN + VESSEL BROKEN
-> WATER-SOAKED FOOD / DRINK IN VESSEL -> UNCLEAN
-> OVEN / RANGE -> BROKEN
-> SPRING / CISTERN REMAINS CLEAN; CARCASS TOUCHER UNCLEAN
-> DRY SOWING SEED REMAINS CLEAN
-> WATERED SEED + CARCASS = UNCLEAN

EDIBLE ANIMAL DIES
-> TOUCH = UNCLEAN UNTIL EVENING
-> EAT OR CARRY CARCASS = WASH CLOTHES + UNCLEAN UNTIL EVENING

EARTH CREEPERS ON BELLY / FOUR / MANY FEET = DO NOT EAT
-> DO NOT DEFILE YOURSELVES
-> LORD IDENTIFIES SELF / EGYPT-UP RELATION / HOLINESS REQUIREMENT
-> DISTINGUISH CLEAN/UNCLEAN + EDIBLE/NON-EDIBLE
```

## Leviticus 11:1–3 — LAND FOOD NEEDS BOTH SWITCHES ON

The LORD speaks directly to Moses and Aaron and orders them to speak to Israel.
Among land animals, an animal may be eaten when it both parts the hoof completely
and chews the cud. One matching feature alone does not pass the rule.

## Leviticus 11:4–8 — THREE HAVE THE CUD SIDE; THE PIG HAS THE HOOF SIDE

The camel, hyrax and hare are each stated to chew the cud but not have a parted
hoof. The pig has a split, cloven hoof but does not chew the cud. Each is called
unclean to Israel. Israel must not eat their meat or touch their carcasses.

The four examples show both one-sided failure routes already inside the rule.
They do not contradict the two-part selector.

## Leviticus 11:9–12 — WATER FOOD NEEDS FINS AND SCALES

In seas and rivers, creatures with both fins and scales may be eaten. Everything
in the waters without fins and scales is called an abomination. Israel must
detest them, not eat their meat and detest their carcasses. No individual water
species or hidden mechanism is supplied.

## Leviticus 11:13–19 — THE SOURCE'S BIRD BLOCK ENDS WITH A BAT

The prohibited bird list is retained in order: eagle, vulture, black vulture,
red kite and its kinds, raven kinds, horned owl, screech owl, gull, hawk kinds,
little owl, cormorant, great owl, white owl, desert owl, osprey, stork, heron
kinds, hoopoe and bat.

The bat remains in the source's bird list. No outside taxonomy is imported to
correct it or manufacture a contradiction. If shown, every living listed
creature has Joe's face, including the bat Joe at the end of the bird queue.

## Leviticus 11:20–23 — FOUR FEET FAILS UNTIL THE HOPPING-LEG BRANCH APPLIES

Winged insects that walk on all fours are called an abomination. A stated branch
permits winged creeping things with long, jointed legs for hopping. Locust,
katydid, cricket and grasshopper kinds are named as edible examples. Other
four-footed winged creeping things remain prohibited.

The permission is not a later reversal. It is the supplied jointed-hopping-leg
selector inside the same rule block.

## Leviticus 11:24–28 — TOUCH GETS EVENING; CARRY ALSO GETS LAUNDRY

Touching the relevant carcass makes a person unclean until evening. Carrying any
part of it also requires washing clothes and remaining unclean until evening.
Animals with a split hoof that is not completely divided, animals that do not
chew cud and four-footed animals that walk on paws are included.

## Leviticus 11:29–31 — DEAD CREEPER CONTACT STARTS THE CLOCK

The unclean creeping list is weasel, rat, great-lizard kinds, gecko, monitor
lizard, wall lizard, skink and chameleon. Whoever touches one when dead is
unclean until evening. Their living Joe faces remain required while alive. No
individual death or contact occurrence is narrated.

## Leviticus 11:32–35 — SOFT GEAR GETS WATER; EARTHENWARE AND OVENS GET DELETED

When a dead listed creeper falls on a wooden vessel, clothing, skin, sack or any
work vessel, the object goes into water, remains unclean until evening and then
becomes clean.

If one falls into an earthen vessel, everything inside becomes unclean and the
vessel must be broken. Water-soaked food and drink in such a vessel become
unclean. An oven or pot range touched by part of the carcass is unclean and must
be broken. These are different material routes, not unequal outcomes applied to
the same input.

## Leviticus 11:36–38 — THE WATER SOURCE STAYS CLEAN; DRY SEED ALSO GETS A PASS

A spring or cistern holding gathered water remains clean, but a person or thing
touching the carcass is unclean. Dry sowing seed remains clean if carcass matter
falls on it. If water has been put on the seed and carcass matter then falls on
it, the seed is unclean. The source supplies the wet/dry Difference directly.

## Leviticus 11:39–40 — EVEN AN EDIBLE ANIMAL HAS A DEAD-BODY ROUTE

If an animal permitted for food dies, touching its carcass makes a person
unclean until evening. Eating from or carrying that carcass also requires
washing clothes and remaining unclean until evening. Food eligibility while
living and handling an animal that dies are separate selectors.

## Leviticus 11:41–45 — BELLY, FOUR OR MANY FEET: DON'T EAT THEM

Every earth-creeping thing is called an abomination and may not be eaten. The
prohibition covers belly movement, four feet and many feet. Israel must not make
themselves abominable, unclean or defiled through them.

The LORD identifies himself as Israel's God, commands them to sanctify
themselves and be holy because he is holy, and identifies himself as the LORD
who brought them up from Egypt to be their God. These are direct God-only lines.
No hidden physical mechanism is invented.

## Leviticus 11:46–47 — THE WHOLE THING IS A DISTINCTION MACHINE

The speech closes by calling this the law of animals, birds, water creatures
and earth creepers. Its stated purpose is to distinguish unclean from clean and
living things that may be eaten from those that may not.

The chapter contains classification rules and prospective consequences. It does
not narrate an Israelite eating, touching, carrying, washing, waiting, breaking
or becoming clean or unclean. No occurrence is invented from a rule.

## Character and world-ledger changes

- LORD directly addresses Moses and Aaron with the complete classification law;
- land-food access requires completely divided hoof plus cud chewing;
- water-food access requires fins plus scales;
- the complete named bird exclusion list is retained, including bat in the source category;
- jointed hopping legs provide an explicit winged-creeper branch;
- locust, katydid, cricket and grasshopper kinds are permitted;
- carcass touch, carry and eating routes retain distinct outputs;
- wooden/work materials, earthen vessels, ovens/ranges, water sources and seed retain separate contact routes;
- dry seed and watered seed differ explicitly;
- food eligibility and dead-carcass handling remain separate;
- holiness and Egypt-up relations remain direct divine claims;
- all prospective living people, animals, birds, bats, water creatures, insects and creepers are Joe-faced;
- no actual rule-triggering occurrence, contradiction, SKIP, crack or Captain appearance occurs;
- publication remains held; Nadab/Abihu burial, cloud departure and Joseph burial remain open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — EDIBILITY FIREWALL CONFIGURATION`;
- land gate: `HOOF=FULL + CUD=YES OR FUCK OFF`;
- camel/hyrax/hare status: `CUD PASS / HOOF FAIL`;
- pig status: `HOOF PASS / CUD FAIL`;
- water gate: `FINS + SCALES / BOTH OR NOTHING`;
- bird queue terminator: `BAT JOE / STILL IN THIS LIST`;
- insect override: `FOUR FEET NO / HOPPING LEG DRIVER YES`;
- carcass timer: `TOUCH -> EVENING / CARRY -> LAUNDRY + EVENING`;
- object support: `WOOD WASH / CLAY SMASH / OVEN SMASH`;
- water exception: `CISTERN CLEAN / TOUCHER DIRTY`;
- seed firmware: `DRY PASS / WET FAIL`;
- final interface: `CLEAN|UNCLEAN / FOOD|NOT FOOD`;
- barcode: `CHB-LEV11-47-BOOLEAN-ZOO-BATQUEUE-DRYSEED-NOCRACK-HELD`.

## FIR verification

- all 47 verse markers are represented in order;
- direct LORD speech to Moses and Aaron remains God-only speech;
- complete-hoof/cud, fins/scales and hopping-leg selectors remain distinct;
- camel, hyrax, hare and pig retain their exact stated one-sided failures;
- water consequences and bird exclusion list remain complete;
- bat remains in the source bird category without outside correction or invented friction;
- jointed hopping legs remain an explicit exception rather than a contradiction;
- carcass touch, carry and eating retain different consequences;
- all eight named creeping categories remain represented;
- work-vessel water route remains distinct from earthen-vessel breaking;
- soaked food/drink and oven/range rules remain represented;
- spring/cistern cleanliness and toucher uncleanness remain separate;
- dry seed and watered seed retain their exact Difference;
- edible-animal death handling remains separate from ordinary food permission;
- belly/four/many-foot earth-creeper prohibition remains complete;
- no prospective rule is rewritten as a performed occurrence;
- every living person, animal and source organism uses Joe face if shown;
- no contradiction, SKIP, crack or Captain is added;
- publication remains held and unpublished.

Continuation required: Leviticus 12 establishes birth-linked maternal
uncleanness intervals, circumcision on day eight, purification time and
post-period offering routes.
