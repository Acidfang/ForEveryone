# CRACKHEAD LEVITICUS 2

## Title page

**BRING THE HONEY. DON'T BURN THE HONEY.**

**PUT SALT ON EVERYTHING.**

Source parent: Leviticus chapter 2, verses 1–16, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-002/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/001-HERD-FLOCK-OR-BIRD-BURN-THE-WHOLE-THING.md`.

CrackFlix routing: none. No completed observable contradiction occurs.

## Causal foundation

```text
RAW FLOUR + OIL + FRANKINCENSE PATH
OR OVEN CAKE/WAFER PATH
OR GRIDDLE PATH
OR PAN PATH
-> OFFERER BRINGS PREPARED GRAIN
-> PRIEST TAKES MEMORIAL PORTION
-> MEMORIAL PORTION BURNS
-> REMAINDER BELONGS TO AARON + SONS
-> YEAST/HONEY MAY BE FIRSTFRUITS
-> YEAST/HONEY MAY NOT BE ALTAR-AROMA FIRE PORTION
-> EVERY OFFERING REQUIRES SALT
-> FRESH FIRSTFRUIT GRAIN GETS PARCHED/CRUSHED + OIL + FRANKINCENSE
-> PRIEST BURNS ITS MEMORIAL PORTION
-> ALL PROCEDURES REMAIN PROSPECTIVE
```

## Leviticus 2:1–3 — RAW FLOUR PATH

A prospective meal offering begins with fine flour, oil poured on it and
frankincense placed on it. The offerer brings it to Aaron's priest sons. A
priest takes one handful of flour/oil plus all frankincense and burns that
memorial portion on the altar.

The source calls it a fire offering and pleasant aroma to the LORD. The
remainder belongs to Aaron and sons and is called a most-holy portion of the
LORD's fire offerings. Aroma and holiness remain direct divine descriptions.

No flour amount, oil amount, frankincense amount, offerer, priest, date,
hand-size standard or actual burn is supplied.

## Leviticus 2:4–10 — THREE COOKED PATHS

Oven input may be unleavened fine-flour cakes mixed with oil or unleavened
wafers coated with oil.

Griddle input is unleavened fine flour mixed with oil, cut into pieces with
more oil poured over it.

Pan input is fine flour made with oil.

Each prepared form is brought to the LORD, presented to a priest and carried by
the priest to the altar. The priest removes and burns its memorial portion. The
remainder belongs to Aaron and sons as a most-holy fire-offering portion.

The source does not state that every cooking path uses frankincense, cutting or
the same oil timing. Missing branch steps are not imported from another branch.

## Leviticus 2:11–13 — HONEY MAY ARRIVE; HONEY MAY NOT BURN

No meal offering offered to the LORD may be made with yeast. Neither yeast nor
honey may be burned as a fire offering to the LORD. They may be offered as
firstfruits, but may not rise from the altar as a pleasant aroma.

This is a bounded routing rule, not contradiction:

```text
YEAST/HONEY -> FIRSTFRUITS DELIVERY: ALLOWED
YEAST/HONEY -> ALTAR AROMA FIRE: NOT ALLOWED
```

Every meal offering must be seasoned with salt. The salt of God's covenant may
not be missing, and all offerings must include salt.

No yeast, honey, salt, offering or violation is actually present.

## Leviticus 2:14–16 — FRESH FIRSTFRUIT GRAIN PATH

A firstfruits meal offering uses fresh grain heads parched with fire and
crushed. The offerer adds oil and frankincense. A priest burns a memorial
portion of crushed grain/oil with all frankincense as a fire offering to the
LORD.

Parched grain fire is preparation before altar presentation; it does not erase
the separate yeast/honey altar-fire boundary. No firstfruits batch is made or
offered here.

## Character and world-ledger changes

- prospective Israel offerers gain raw, oven, griddle, pan and fresh-firstfruit
  grain input paths;
- priest role gains memorial-portion removal/burning and remainder custody;
- Aaron and sons gain the prospective most-holy remainder allocation;
- firstfruits delivery is distinguished from altar-aroma burning;
- yeast and honey are permitted firstfruits inputs but prohibited fire-offering
  inputs;
- salt becomes mandatory across every offering, with covenant significance
  retained as divine wording;
- grain, oil, frankincense, honey, yeast and salt sources are living Joe-faced
  organisms where living source organisms are depicted;
- no contradiction, SKIP, crack or Captain appearance occurs;
- no ingredient preparation, offering, burning, remainder transfer or aroma
  occurs yet;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — GRAIN ROUTER`;
- raw mode: `FLOUR + OIL + ALL THE SMELL DUST`;
- oven mode: `CAKE OR WAFER / YEAST OFF`;
- griddle mode: `CUT IT / OIL IT AGAIN`;
- pan mode: `FLOUR + OIL / DETAILS SOLD SEPARATELY`;
- priest hand scanner: `MEMORIAL PORTION: ONE HANDFUL-ISH`;
- remainder label: `AARON + SONS / MOST HOLY LUNCH COMPONENT`;
- honey switch: `BRING YES / BURN NO`;
- salt warning: `EVERY OFFERING / DO NOT FORGET THE COVENANT SPRINKLES`;
- firstfruits machine: `PARCH -> CRUSH -> OIL -> FRANKINCENSE`;
- barcode: `CHB-LEV02-16-5PATHS-SALTALL-HONEYROUTED-NOCRACK-HELD`.

## FIR verification

- all 16 verse markers are represented in order;
- raw flour, oven, griddle, pan and firstfruits branches remain distinct;
- offerer delivery, priest memorial removal/burning and Aaronic remainder
  allocation remain separate acts;
- frankincense and cutting are not imported into branches where unstated;
- yeast/honey firstfruits delivery is distinguished from prohibited altar fire;
- the explicit act boundary prevents an invented contradiction;
- universal salt wording is retained without inventing amount or application;
- pleasant aroma, most holiness and covenant significance remain divine claims;
- instructions do not become performed offerings;
- no unsupported contradiction is manufactured, so Captain does not appear;
- all living people and ingredient-source organisms use Joe face if shown;
- publication remains held and unpublished.

Continuation required: Leviticus 3 reconstructs peace-offering herd/flock/goat
paths, blood/fat allocation and the perpetual no-fat/no-blood consumption rule.
