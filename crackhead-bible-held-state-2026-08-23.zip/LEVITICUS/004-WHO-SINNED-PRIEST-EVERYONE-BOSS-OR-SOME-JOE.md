# CRACKHEAD LEVITICUS 4

## Title page

**WHO SINNED?**

**PRIEST. EVERYONE. BOSS. OR SOME JOE. DIFFERENT BLOOD ROUTE.**

Source parent: Leviticus chapter 4, verses 1–35, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-004/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/003-MALE-OR-FEMALE-HAND-ON-HEAD-ALL-FAT-BELONGS-TO-GOD.md`.

CrackFlix routing: none. No completed observable contradiction occurs.

## Causal foundation

```text
PROHIBITED ACT DONE UNINTENTIONALLY
-> ADDRESS = ANOINTED PRIEST / WHOLE CONGREGATION / RULER / COMMON PERSON
-> REQUIRED ANIMAL SELECTED
-> HAND(S) ON HEAD + ANIMAL KILLED
-> PRIEST/CONGREGATION BULL BLOOD: TENT / 7x VEIL / INCENSE HORNS / BURNT-ALTAR BASE
-> RULER/COMMON BLOOD: BURNT-ALTAR HORNS / BASE
-> FAT REMOVED AND BURNED
-> PRIEST/CONGREGATION REMAINDER: CLEAN ASH PLACE OUTSIDE CAMP / BURNED
-> PRIEST MAKES ATONEMENT
-> FORGIVENESS STATED
-> ALL PROCEDURES REMAIN PROSPECTIVE
```

## Leviticus 4:1–2 — UNINTENTIONAL DOES NOT MEAN UNHAPPENED

The LORD tells Moses to speak to Israel about anyone unintentionally doing an
act the LORD commanded not to be done. The act and lack of intention are both
conditions inside the rule. No actor, prohibited command or actual act is
identified here.

## Leviticus 4:3–12 — ANOINTED PRIEST ADDRESS

If the anointed priest sins so guilt comes on the people, his input is a young
defect-free bull. He brings it to the Tent door, lays a hand on its head and
kills it.

The anointed priest takes blood into the Tent, dips a finger and sprinkles blood
seven times before the sanctuary veil. Blood goes on the sweet-incense altar
horns; the rest goes at the base of the burnt altar outside at the door.

The bull's entrail-covering fat, kidneys/kidney fat and liver cover are removed
as in the peace bull and burned on the burnt altar. Skin, meat, head, legs,
innards, dung and every remaining part go outside camp to the clean ash-dump
place and burn there on wood and fire.

No named priest, people-guilt event, bull or procedure occurs.

## Leviticus 4:13–21 — WHOLE CONGREGATION ADDRESS

If the whole congregation performs a prohibited act while it is hidden from the
assembly's eyes, they are described as guilty. When the sin becomes known, the
assembly brings a young bull before the Tent. Congregation elders lay their
hands on its head and the bull is killed.

The anointed priest repeats the inside-Tent blood route: blood enters; seven
sprinkles occur before the veil; blood touches the inside altar horns; the rest
is poured at the burnt-altar base. Fat is removed and burned. The bull is taken
outside camp and burned like the first bull.

The priest is stated to make atonement for them and they are stated to be
forgiven. Those are rule outcomes, not performed or externally measured effects.

## Leviticus 4:22–26 — RULER ADDRESS

When a ruler unintentionally performs a prohibited act and is guilty, the
procedure activates if his sin is made known to him. He brings a defect-free
male goat, lays a hand on its head and kills it where burnt offerings are
killed.

A priest puts blood on the burnt-altar horns and pours the rest at its base.
All fat burns like peace-offering fat. The priest is stated to make atonement
and the ruler is stated to be forgiven.

No blood enters the Tent and no carcass disposal is specified in this branch.

## Leviticus 4:27–35 — ORDINARY JOE ADDRESS

If one common person unintentionally performs a prohibited act and becomes
guilty, the procedure activates when the sin becomes known. The person may
bring a defect-free female goat, lay a hand on its head and kill it at the
burnt-offering place. Priest blood goes on burnt-altar horns and the remainder
at its base. Peace-offering-style fat is removed and burned as pleasant aroma;
atonement and forgiveness are stated.

Alternatively, the person may bring a defect-free female lamb. Hand placement,
killing location and burnt-altar blood route repeat. Lamb peace-offering fat is
removed and burned on the LORD's fire offerings; atonement and forgiveness are
again stated.

The female goat and female lamb are alternatives, not two required animals.

## Character and world-ledger changes

- unintentional prohibited acts gain four addressed resolution branches;
- anointed-priest sin is distinguished by stated people-guilt relation and bull;
- congregation hidden act gains knowledge trigger, elder hand placement and bull;
- ruler knowledge trigger gains defect-free male goat path;
- common-person knowledge trigger gains defect-free female goat/lamb alternatives;
- priest/congregation bull blood enters Tent and touches veil/incense altar;
- ruler/common blood remains at burnt altar;
- priest/congregation bull remainder goes to clean ash place outside camp;
- peace-offering fat extraction is reused by exact pointer, not reimagined;
- atonement, forgiveness, guilt and pleasant aroma remain divine-rule claims;
- all prospective people and animals are living Joe-faced beings;
- no contradiction, SKIP, crack or Captain appearance occurs;
- no sin case, discovery, offering, blood route, burning or forgiveness occurs;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — SIN ADDRESS ROUTER`;
- selector: `ANOINTED PRIEST / EVERYONE / BOSS / SOME JOE`;
- detection state: `DID FIRST / FOUND OUT LATER`;
- priest input: `BULL / PEOPLE GUILT ATTACHED`;
- congregation input: `BULL / ELDER MULTI-TOUCH`;
- ruler input: `MALE GOAT / BOSS MODE`;
- common input: `FEMALE GOAT OR FEMALE LAMB / USER CHOICE`;
- internal blood route: `7x VEIL + SMELL ALTAR HORNS`;
- external blood route: `BURNT ALTAR HORNS + BASE`;
- carcass export: `OUTSIDE CAMP / CLEAN ASH ADDRESS / BURN REST`;
- result display: `ATONED + FORGIVEN — CLAIMED, NO CASE RUN`;
- barcode: `CHB-LEV04-35-4ADDRESSES-2BLOODROUTES-NOCRACK-HELD`.

## FIR verification

- all 35 verse markers are represented in order;
- prohibited act, unintentional condition, guilt and later knowledge remain
  distinct states;
- anointed priest, congregation, ruler and common-person branches do not merge;
- animal type/sex/defect requirements remain exact for each branch;
- individual versus elder hand-placement roles are retained;
- inside-Tent and burnt-altar-only blood routes remain distinct;
- seven veil sprinkles, incense horns and burnt-altar base are retained;
- exact fat/organs and outside-camp clean-ash disposal remain represented;
- common goat/lamb paths remain alternatives;
- atonement, forgiveness, guilt and aroma remain attributed rule outcomes;
- instructions do not become performed sins, discoveries or offerings;
- no unsupported contradiction is manufactured, so Captain does not appear;
- every prospective living person and animal uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Leviticus 5 reconstructs testimony silence, uncleanness,
rash oath awareness, confession, sliding-scale sin offerings and trespass cases.
