# CRACKHEAD LEVITICUS 16

## Title page

**NOT JUST ANY TIME. COVER THE MERCY SEAT WITH A CLOUD.**

**TWO GOATS. ONE FOR THE LORD. ONE GOES AWAY. ONCE A YEAR.**

Source parent: Leviticus chapter 16, verses 1–34, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-016/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/015-BED-SEAT-SADDLE-SPIT-CLAY-BREAK-WOOD-RINSE-EVENING.md`.

Earlier continuity parent: `LEVITICUS/010-FIRE-WENT-OUT-FIRE-CAME-OUT.md`.

CrackFlix routing: none. The chapter resumes from a retained death occurrence,
gives one controlled annual procedure and records that it was done. No
claim/performed-act mismatch occurs.

## Causal foundation

```text
NADAB + ABIHU CAME NEAR BEFORE THE LORD AND DIED
-> LORD TO MOSES: AARON MUST NOT ENTER AT JUST ANY TIME
-> DEATH WARNING + LORD APPEARS IN CLOUD ON MERCY SEAT

AARON: BULL SIN + RAM BURNT + BATHE + HOLY LINEN
ASSEMBLY: TWO MALE GOATS SIN + RAM BURNT
TWO GOATS AT TENT DOOR -> CAST LOTS
  -> LORD LOT: SIN OFFERING
  -> SCAPEGOAT LOT: PRESENT ALIVE -> SEND WILDERNESS

BULL FOR AARON/HOUSE KILLED
-> ALTAR COALS + TWO HANDFULS BEATEN INCENSE INSIDE VEIL
-> INCENSE CLOUD COVERS MERCY SEAT SO HE DOES NOT DIE
-> BULL BLOOD EAST ON SEAT + SEVEN TIMES BEFORE
-> PEOPLE'S GOAT BLOOD REPEATS ROUTE
-> HOLY PLACE / TENT / ALTAR ATONEMENT ATTRIBUTED
-> NOBODY ELSE IN TENT UNTIL AARON EXITS

LIVE GOAT -> BOTH HANDS + CONFESS ALL ISRAEL'S WRONGS
-> SOURCE PUTS THEM ON GOAT HEAD
-> READY MAN SENDS GOAT
-> SOURCE SAYS GOAT CARRIES THEM TO SOLITARY LAND
-> RELEASE

AARON: LEAVE LINEN -> BATHE -> OWN CLOTHES -> BURNT OFFERINGS
SENDER: WASH + BATHE -> RETURN CAMP
BULL/GOAT CARCASSES: OUTSIDE CAMP -> SKIN/FLESH/DUNG BURNED
BURNER: WASH + BATHE -> RETURN CAMP

MONTH 7 / DAY 10 -> AFFLICT SOULS + NO WORK + SOLEMN SABBATH
SUCCESSOR PRIEST -> SAME ANNUAL PROCEDURE
NARRATOR: IT WAS DONE AS THE LORD COMMANDED MOSES
```

## Leviticus 16:1–2 — AFTER THE TWO SONS DIED, NOT JUST ANY TIME

The LORD speaks to Moses after Aaron's two sons came near before the LORD and
died. This retains the Leviticus 10 occurrence; it adds no new motive or
replacement cause. The LORD tells Moses that Aaron must not enter the Most Holy
Place within the veil at just any time, lest he die, because the LORD appears in
the cloud on the mercy seat.

## Leviticus 16:3–5 — ENTRY PACKAGE

Aaron's package is a young bull for a sin offering, a ram for a burnt offering,
a body bath, and the holy linen tunic, trousers, sash and turban. The assembly
supplies two male goats for a sin offering and another ram for a burnt offering.

## Leviticus 16:6–10 — TWO LOTS, TWO GOAT ROUTES

Aaron offers the bull for himself and his house. He places both goats at the
Tent door and casts one lot for the LORD and one for the scapegoat. The first
goat becomes the sin offering. The second is presented alive and sent into the
wilderness. Different lots select different routes; nothing conflicts.

## Leviticus 16:11–14 — CLOUD BEFORE BLOOD

Aaron kills his bull, takes a censer of altar coals and two handfuls of finely
beaten incense inside the veil, and puts the incense on the fire. Its cloud
covers the mercy seat so, the source says, he does not die. Bull blood is
sprinkled on the seat's east side and seven times before it.

## Leviticus 16:15–19 — PEOPLE'S BLOOD, EMPTY TENT, ALTAR HORNS

Aaron kills the people's goat and repeats the bull-blood route. The source
attributes atonement to the Holy Place and Tent because of Israel's uncleanness,
transgressions and sins. Nobody else may occupy the Tent from Aaron's entry
until his exit. Bull and goat blood then go on the altar horns and are sprinkled
seven times; cleansing and holiness remain source-attributed effects.

## Leviticus 16:20–22 — BOTH HANDS, ALL THE WORDS, ONE GOAT OUT

Aaron places both hands on the live goat and confesses all Israel's iniquities,
transgressions and sins. The source says he puts them on its head. A ready man
sends it into the wilderness; the source says it carries them to a solitary
land, where it is released. No transfer mechanism, goat thought or reaction is
supplied.

## Leviticus 16:23–25 — LEAVE LINEN, BATHE, CHANGE, OFFER

Aaron removes and leaves the linen garments in the Tent, bathes in a holy
place, puts on his own garments, and offers his and the people's burnt
offerings. The sin-offering fat burns on the altar.

## Leviticus 16:26–28 — TWO OUTSIDE JOBS, TWO RETURNS

The goat sender washes clothes, bathes and returns to camp. The bull and goat
carcasses whose blood entered the Holy Place go outside camp, where their skins,
flesh and dung are burned. The burner also washes clothes, bathes and returns.
Sender and burner remain separate addressed roles.

## Leviticus 16:29–34 — DAY TEN, ONCE A YEAR, DONE

On day ten of month seven, native-born and foreign resident alike afflict their
souls and do no work. It is a Sabbath of solemn rest. The source attributes
atonement and cleansing from sins. An anointed successor priest inherits the
linen procedure for Sanctuary, Tent, altar, priests and assembly, once a year.

The narrator records that it was done as the LORD commanded Moses. This closes
compliance at the chapter's total boundary. It does not provide the exact date,
a second-by-second view, individual handler identities or the mechanisms of the
attributed effects.

## Character and world-ledger changes

- Nadab and Abihu's retained deaths explicitly frame the new access rule;
- Aaron's inner access is controlled rather than available at any time;
- one goat follows the LORD lot and one the scapegoat lot;
- incense cloud precedes the inner blood actions;
- bull, people's-goat and altar blood routes remain distinct;
- Tent exclusion lasts from Aaron's entry until exit;
- the live goat receives both hands, confession and a ready-man route;
- sender and carcass burner each wash, bathe and return;
- native and foreign resident share the day-ten rule;
- a successor priest inherits the annual procedure;
- narrator-recorded compliance is retained without invented details;
- all living priests, people, goats, bull and rams are Joe-faced;
- no contradiction, SKIP, crack or Captain appearance occurs;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — INNER ROOM ACCESS CONTROL`;
- warning: `NOT JUST ANY TIME, DICKHEAD`;
- cloud: `MERCY-SEAT VISIBILITY PATCH / LEST HE DIE`;
- goat router: `CAST LOT / LORD OR GET OUT`;
- blood bus: `EAST ONCE / FRONT SEVEN / REPEAT`;
- Tent status: `NO OTHER JOES UNTIL AARON EXITS`;
- courier: `BOTH HANDS / ALL SINS / READY MAN`;
- outside support: `SEND / BURN / WASH / RETURN`;
- scheduler: `MONTH 7 / DAY 10 / ONCE PER YEAR`;
- completion lamp: `IT WAS DONE`;
- barcode: `CHB-LEV16-34-CLOUD-TWO-GOATS-ONCE-A-YEAR-DONE-HELD`.

## FIR verification

- all 34 verse markers are represented in order;
- Leviticus 10 remains the death parent and is not rewritten;
- direct LORD speech remains God-only speech;
- exact source term `scapegoat` is retained;
- all quantities, lots, blood routes, intervals and wash routes remain distinct;
- attributed death prevention, atonement, cleansing and transfer stay attributed;
- narrator compliance is retained without invented date or hidden subacts;
- every living thing uses Joe face if shown;
- no contradiction, SKIP, crack or Captain is added;
- publication remains held and unpublished.

Continuation required: Leviticus 17 addresses slaughter locations, blood at the
Tent door, blood as life, covering hunted blood with dust and carcass washing.
