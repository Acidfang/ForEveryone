# CRACKHEAD LEVITICUS 5

## Title page

**HEARD IT. TOUCHED IT. SWORE IT.**

**CAN'T AFFORD THE LAMB? KEEP GOING DOWN THE MENU.**

Source parent: Leviticus chapter 5, verses 1–19, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-005/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/004-WHO-SINNED-PRIEST-EVERYONE-BOSS-OR-SOME-JOE.md`.

CrackFlix routing: none. No completed observable contradiction occurs.

## Causal foundation

```text
PUBLIC ADJURATION HEARD + WITNESS SAW/KNEW + DID NOT REPORT
OR UNCLEAN CARCASS TOUCHED + CONDITION HIDDEN
OR HUMAN UNCLEANNESS TOUCHED + CONDITION HIDDEN + LATER KNOWN
OR RASH OATH SPOKEN + CONDITION HIDDEN + LATER KNOWN
-> GUILT / INIQUITY STATED
-> CONFESS THE SPECIFIC SIN
-> IF FLOCK AFFORDABLE: FEMALE LAMB OR GOAT / SIN OFFERING
-> ELSE IF TWO BIRDS AFFORDABLE: SIN BIRD FIRST + BURNT BIRD SECOND
-> ELSE: 1/10 EPHAH FINE FLOUR / NO OIL / NO FRANKINCENSE
-> PRIEST MAKES ATONEMENT
-> FORGIVENESS STATED

HOLY THING WRONGED UNWITTINGLY
-> DEFECT-FREE VALUED RAM + RESTITUTION + 1/5 TO PRIEST
-> ATONEMENT / FORGIVENESS STATED

PROHIBITED ACT DONE WHILE UNAWARE
-> GUILTY / BEARS INIQUITY
-> DEFECT-FREE VALUED RAM
-> ATONEMENT FOR UNKNOWING ERROR / FORGIVENESS STATED
-> ALL CASES AND PROCEDURES REMAIN PROSPECTIVE
```

## Leviticus 5:1 — WITNESS JOE HEARD THE PUBLIC CALL

If a Joe hears a public adjuration to testify, is a witness because he has seen
or known, and does not report it, the rule says he bears his iniquity. Hearing,
witness knowledge and not reporting are all required states. No witness,
adjuration, testimony or silence occurs here.

## Leviticus 5:2–3 — TOUCHED IT BEFORE THE STATE WAS VISIBLE TO HIM

Touching the carcass of an unclean wild animal, unclean livestock or an unclean
creeping thing makes the person unclean and guilty even when the condition is
hidden from him. Touching human uncleanness follows the stated hidden-then-known
sequence: when he knows, he is guilty.

The animal categories and human-uncleanness category remain separate inputs.
The source does not identify an actual carcass, person, contact or discovery.

## Leviticus 5:4–6 — MOUTH RAN FIRST, CASE ROUTER OPENED LATER

If anyone rashly swears with his lips to do evil or good, the rule covers
whatever rash oath a person might utter. When it was hidden from him and he
knows of it, he is guilty of one of these cases.

For any of verses 1–4, the guilty person confesses the particular sin and brings
a female lamb or goat from the flock as a sin offering. The priest is assigned
atonement concerning the sin. Confession and offering are required acts, not
events recorded as having happened.

## Leviticus 5:7–10 — CAN'T REACH LAMB: TWO-BIRD MODE

If the person cannot afford a lamb, the input becomes two turtledoves or two
young pigeons: one sin offering and one burnt offering.

The priest offers the sin bird first. He wrings its head at the neck without
severing it completely, sprinkles some blood on the altar side and drains the
rest at the altar base. Then he offers the second bird as a burnt offering
according to the ordinance. Atonement and forgiveness are stated outcomes.

The two birds have different assigned jobs. They are not interchangeable after
the route is selected.

## Leviticus 5:11–13 — CAN'T REACH BIRDS: DRY FLOUR MODE

If the person cannot afford two birds, the offering becomes one-tenth of an
ephah of fine flour. No oil and no frankincense go on it because it is a sin
offering.

The priest takes a memorial handful and burns it on the altar over the LORD's
fire offerings. The rest belongs to the priest as with the meal offering.
Atonement and forgiveness are stated.

This flour shares material and a remainder relation with a meal offering, but
the source explicitly classifies this one as a sin offering and changes its
ingredients. Different addressed offering types are not a contradiction.

## Leviticus 5:14–16 — HOLY-THING ACCOUNT HAS PRINCIPAL PLUS TWENTY PERCENT

The LORD tells Moses that an unwitting trespass regarding the LORD's holy things
requires a defect-free ram from the flock, valued in sanctuary silver shekels,
as a trespass offering.

The wrong done to the holy thing must be restored. One-fifth is added and given
to the priest. The priest uses the ram for atonement, and forgiveness is stated.
The ram and the restitution are both required; one does not replace the other.

## Leviticus 5:17–19 — DID THE PROHIBITED THING WITHOUT KNOWING

If anyone does something the LORD commanded not to be done, even though he did
not know it, the rule calls him guilty and says he bears his iniquity. He brings
the priest a defect-free ram of the stated value. The priest makes atonement for
the error committed unknowingly, and forgiveness is stated.

The chapter closes by classifying it as a trespass offering and stating that he
certainly trespassed against the LORD. The source establishes a rule; it does
not identify the act, actor, value, ram, procedure or observed forgiveness.

## Character and world-ledger changes

- testimony silence gains a hearing/witness/non-reporting accountability route;
- carcass contact distinguishes unclean wild animal, livestock and creeping inputs;
- human-uncleanness contact retains hidden state followed by knowledge;
- rash oath retains spoken act, hidden state and later knowledge;
- confession must address the particular sin;
- affordability routes one case through flock, two birds or fine flour;
- the two birds split into sin-first and burnt-second jobs;
- sin-bird neck, blood-side and blood-base actions remain exact;
- lowest-cost flour excludes oil and frankincense because of offering type;
- flour memorial burn and priest remainder remain allocated;
- holy-thing trespass requires valued ram, restitution and an added fifth;
- unaware prohibited action requires a valued defect-free ram;
- guilt, iniquity, atonement and forgiveness remain divine-rule claims;
- all prospective people, animals and ingredient-source organisms are Joe-faced;
- no contradiction, SKIP, crack or Captain appearance occurs;
- no witness silence, contact, oath, confession, offering or restitution occurs;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — GUILT INPUT / BUDGET ROUTER`;
- input one: `HEARD PUBLIC CALL / SAW OR KNEW / SAID NOTHING`;
- input two: `TOUCHED DEAD UNCLEAN JOE / STATUS HIDDEN`;
- input three: `TOUCHED HUMAN UNCLEANNESS / FOUND OUT LATER`;
- input four: `MOUTH PROMISED EVIL OR GOOD / FOUND OUT LATER`;
- confession field: `WHICH ONE DID YOU DO, JOE?`;
- premium input: `FEMALE LAMB OR GOAT`;
- economy input: `BIRD ONE = SIN / BIRD TWO = BURNT`;
- minimum input: `0.1 EPHAH DRY FLOUR / NO OIL / NO SMELL POWDER`;
- holy-account invoice: `ORIGINAL + 20% + RAM`;
- awareness display: `DIDN'T KNOW / STILL ROUTED`;
- result display: `ATONED + FORGIVEN — CLAIMED, NO CASE RUN`;
- barcode: `CHB-LEV05-19-4INPUTS-3BUDGETS-PLUS20-NOCRACK-HELD`.

## FIR verification

- all 19 verse markers are represented in order;
- public adjuration, witness status and failure to report remain linked;
- the three carcass categories and human uncleanness remain distinguishable;
- hidden condition and later knowledge remain separate where stated;
- rash oath includes both evil and good without inventing oath content;
- confession follows guilt and precedes the offering route;
- flock, bird and flour paths remain affordability alternatives;
- bird order, neck treatment and blood destinations remain exact;
- lowest-cost flour amount and oil/frankincense exclusions are retained;
- memorial portion and priest remainder are both retained;
- holy-thing ram, sanctuary valuation, restitution and added fifth remain additive;
- unknowing prohibited act and holy-thing trespass remain separate cases;
- guilt, iniquity, atonement and forgiveness remain attributed rule outcomes;
- instructions do not become performed contact, silence, oath, offerings or effects;
- no unsupported contradiction is manufactured, so Captain does not appear;
- every prospective living person, animal and source organism uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Leviticus 6 continues trespass restitution, then gives
priest-facing burnt, meal and anointed-priest offering procedures.
