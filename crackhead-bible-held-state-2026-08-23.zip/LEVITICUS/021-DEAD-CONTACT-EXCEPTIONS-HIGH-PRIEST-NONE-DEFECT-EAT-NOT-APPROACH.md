# CRACKHEAD LEVITICUS 21

## Title page

**DEAD CONTACT: PRIEST EXCEPTIONS. HIGH PRIEST: NONE.**

**DEFECT? EAT THE HOLY BREAD. DON'T APPROACH THE VEIL OR ALTAR.**

Source parent: Leviticus chapter 21, verses 1–24, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-021/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/020-DONT-HIDE-YOUR-EYES-PENALTY-MAP-SEPARATE-CLEAN-UNCLEAN.md`.

CrackFlix routing: none. The LORD supplies priest-role selectors and the
narrator records Moses delivering them. No selected death, marriage, body
condition, altar approach or punishment occurs.

## Causal foundation

```text
LORD -> MOSES -> AARON'S PRIEST SONS

ORDINARY PRIEST + DEAD PERSON
-> GENERALLY NO SELF-DEFILEMENT
-> EXCEPT MOTHER / FATHER / SON / DAUGHTER / BROTHER
-> EXCEPT NEAR VIRGIN SISTER WITH NO HUSBAND

PRIEST BODY/GROOMING
-> NO HEAD SHAVE / BEARD-CORNER SHAVE / FLESH CUTTINGS
-> HOLY / DO NOT PROFANE NAME

PRIEST MARRIAGE
-> NO SOURCE-LABELLED PROSTITUTE / PROFANE / DIVORCED WOMAN
PRIEST'S DAUGHTER + PROSTITUTION
-> SOURCE: PROFANES FATHER -> BURNED

HIGH PRIEST
-> NO LOOSE HAIR / TORN CLOTHES
-> NO DEAD BODY, INCLUDING FATHER/MOTHER
-> DOES NOT LEAVE SANCTUARY
-> WIFE: VIRGIN OF OWN PEOPLE
-> NOT WIDOW / DIVORCED / SOURCE-DEFILED / PROSTITUTE

AARON DESCENDANT WITH SOURCE-LISTED DEFECT
-> MAY EAT MOST HOLY + HOLY BREAD
-> MAY NOT OFFER FIRE OFFERINGS
-> MAY NOT APPROACH VEIL OR ALTAR

MOSES SPOKE TO AARON + SONS + ALL ISRAEL
```

## Leviticus 21:1–4 — ORDINARY-PRIEST DEAD-CONTACT EXCEPTIONS

The LORD tells Moses to address Aaron's priest sons. A priest generally may not
defile himself for a dead person among the people. The listed exceptions are
mother, father, son, daughter, brother and a near virgin sister who has had no
husband. The sister's exact condition remains part of the selector.

No death, relative or contact event occurs.

## Leviticus 21:5–6 — HEAD, BEARD, FLESH AND HOLY SERVICE

Priests may not shave their heads or beard corners or make flesh cuttings. They
are to be holy and not profane God's name because they offer the LORD's fire
offerings, called the bread of their God. Holiness and profanation remain divine
classifications.

## Leviticus 21:7–9 — PRIEST MARRIAGE AND THE DAUGHTER'S PENALTY

An ordinary priest may not marry women carrying the source's prostitute,
profane or divorced selectors. Israel is ordered to sanctify the priest. The
LORD states that he sanctifies Israel and is holy.

If a priest's daughter plays the prostitute, the source says she profanes her
father and is to be burned. This is prospective punishment law, not an actual
daughter, act, judgment, fire or death.

## Leviticus 21:10–12 — HIGH PRIEST: NO DEAD-BODY EXCEPTION

The high priest, identified by anointing oil and consecrated garments, may not
let his hair hang loose or tear clothes. He may not enter to any dead body or
defile himself even for father or mother. He does not leave or profane the
sanctuary. The anointing relation and the LORD's identity remain source claims.

The ordinary-priest exception list and high-priest no-exception branch apply to
different roles and therefore do not conflict.

## Leviticus 21:13–15 — HIGH-PRIEST WIFE SELECTOR

The high priest takes a wife in her virginity from his own people. Widow,
divorced, source-defiled and prostitute selectors are excluded. The LORD says
this prevents profaning offspring and identifies himself as the high priest's
sanctifier. No marriage or offspring occurrence is narrated.

## Leviticus 21:16–21 — SOURCE-LISTED BODY CONDITIONS AND SERVICE ACCESS

The LORD separately tells Moses to address Aaron. Across Aaron's generations,
a descendant with a source-labelled defect may not approach to offer God's
bread or fire offerings. The list is blind, lame, flat nose, deformity, injured
foot, injured hand, hunchbacked, dwarf, eye defect, itching disease, scabs and
damaged testicles.

These are source access classifications. No modern diagnosis, moral worth,
cause, cure, contagion, inability or universal disability rule is imported.

## Leviticus 21:22–23 — EAT YES; VEIL AND ALTAR NO

The same priest descendant may eat both most-holy and holy bread. He may not
approach the veil or altar. Eating access and service-location access are
explicitly different outputs, not a contradiction. The stated sanctuary and
sanctification relation remains direct divine speech.

## Leviticus 21:24 — MOSES DELIVERS THE RULE

The narrator records that Moses spoke to Aaron, Aaron's sons and all Israel.
This is the chapter's performed occurrence. It proves delivery at the source's
total speech boundary; it does not prove a later death contact, marriage,
inspection, exclusion, eating or offering event.

## Character and world-ledger changes

- ordinary-priest and high-priest dead-contact branches remain separate;
- exact ordinary-priest close-relative exceptions are retained;
- grooming, marriage and priest-daughter punishment rules remain prospective;
- high-priest anointing, sanctuary and wife selectors remain exact;
- every source-listed body condition remains independently retained;
- food access remains allowed while veil/altar offering access remains restricted;
- body-condition labels do not alter Joe identity, worth or boil genetics;
- Moses' delivery to Aaron, sons and Israel is recorded as performed;
- no death, contact, marriage, body examination, exclusion, offering or punishment occurs;
- all living participants are Joe-faced;
- no contradiction, SKIP, crack or Captain appearance occurs;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — PRIEST ACCESS MATRIX`;
- ordinary-death port: `DENY / EXCEPT CLOSE LIST`;
- high-priest port: `DENY / YES EVEN YOUR PARENTS`;
- grooming lock: `HEAD / BEARD / FLESH — NO CUT`;
- marriage filter: `ROLE-SPECIFIC SOURCE SELECTORS`;
- body-list scanner: `TWELVE INPUTS / DO NOT DIAGNOSE`;
- cafeteria badge: `HOLY BREAD YES`;
- service badge: `VEIL NO / ALTAR NO`;
- delivery receipt: `MOSES SPOKE TO ALL ADDRESSES`;
- barcode: `CHB-LEV21-24-DEAD-EXCEPTIONS-EAT-NOT-APPROACH-HELD`.

## FIR verification

- all 24 verse markers are represented in order;
- direct LORD speech, holiness and sanctification remain God-only attribution;
- ordinary-priest relative exceptions remain complete;
- high-priest father/mother prohibition remains distinct;
- grooming and marriage selectors retain exact role boundaries;
- priest-daughter burning remains prospective and unperformed;
- every source body-condition label is retained without outside diagnosis;
- eating and veil/altar access outputs remain different and complete;
- no modern medical, disability-worth or functional inference is imported;
- Moses' performed delivery is retained without treating rules as performed acts;
- every living thing uses Joe face if shown;
- no contradiction, SKIP, crack, Captain or YOINK is added;
- publication remains held and unpublished.

Continuation required: Leviticus 22 addresses priest uncleanness gates, holy-food
eligibility, household eaters and acceptable/unacceptable offering animals.
