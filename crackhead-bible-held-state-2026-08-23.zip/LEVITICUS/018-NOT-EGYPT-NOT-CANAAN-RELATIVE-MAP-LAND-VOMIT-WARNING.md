# CRACKHEAD LEVITICUS 18

## Title page

**NOT EGYPT. NOT CANAAN. HERE IS THE ENTIRE RELATIVE MAP.**

**THE LAND VOMITED THEM OUT. DON'T MAKE IT DO THAT AGAIN.**

Source parent: Leviticus chapter 18, verses 1–30, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-018/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/017-BRING-THE-KILL-TO-THE-DOOR-LIFE-IN-THE-BLOOD-COVER-IT-WITH-DUST.md`.

CrackFlix routing: none. This chapter is a direct divine prohibition map plus
divine historical, moral, land-effect and enforcement claims. No prohibited act
is independently narrated as occurring in the chapter.

## Causal foundation

```text
LORD -> MOSES -> ISRAEL
-> I AM THE LORD YOUR GOD
-> DO NOT COPY EGYPT WHERE YOU LIVED
-> DO NOT COPY CANAAN WHERE I AM BRINGING YOU
-> DO MY ORDINANCES / KEEP MY STATUTES
-> SOURCE CLAIM: PERSON WHO DOES THEM LIVES IN THEM

NO APPROACH TO UNCOVER NAKEDNESS OF CLOSE RELATIVE
-> FATHER / MOTHER
-> FATHER'S WIFE
-> SISTER: FATHER'S OR MOTHER'S DAUGHTER, HOME OR ABROAD
-> SON'S DAUGHTER / DAUGHTER'S DAUGHTER
-> FATHER'S WIFE'S DAUGHTER CONCEIVED BY FATHER
-> FATHER'S SISTER
-> MOTHER'S SISTER
-> FATHER'S BROTHER VIA HIS WIFE
-> DAUGHTER-IN-LAW
-> BROTHER'S WIFE
-> WOMAN + DAUGHTER / SON'S DAUGHTER / DAUGHTER'S DAUGHTER
-> WIFE'S SISTER AS RIVAL WHILE WIFE ALIVE

ALSO PROHIBITED
-> APPROACH WOMAN DURING SOURCE-DEFINED IMPURITY
-> LIE CARNALLY WITH NEIGHBOUR'S WIFE
-> GIVE CHILD AS SACRIFICE TO MOLECH
-> LIE WITH MAN AS WITH WOMAN
-> MAN OR WOMAN LIE WITH ANIMAL

LORD ATTRIBUTES THESE ACTS TO PRIOR NATIONS/MEN OF LAND
-> LAND DEFILED
-> LORD PUNISHED INIQUITY
-> LAND VOMITED OUT INHABITANTS

ISRAEL NATIVE + FOREIGN RESIDENT
-> KEEP RULES / DO NOT PRACTICE LIST
-> SOURCE WARNING: LAND MAY VOMIT YOU OUT
-> SOURCE WARNING: DOERS CUT OFF
```

## Leviticus 18:1–5 — DON'T COPY EGYPT OR CANAAN

The LORD tells Moses to address Israel: “I am the LORD your God.” Israel must
not do what the source attributes to Egypt, where Israel lived, or Canaan,
where the LORD says he is bringing them. They are to follow the LORD's
ordinances and statutes instead. The LORD states that a person who does them
will live in them. Identity, destination and life-effect remain direct divine
claims.

## Leviticus 18:6 — THE GENERAL CLOSE-RELATIVE BOUNDARY

No one is to approach a close relative to uncover nakedness. This is the common
rule; the following verses retain each supplied relationship rather than
collapsing them into an invented modern kinship category.

## Leviticus 18:7–11 — PARENTS, THEIR CHILDREN, GRANDDAUGHTERS

The prohibited addresses are:

- father or mother, with the mother's relation stated directly;
- father's wife, described as the father's nakedness;
- sister who is the father's or mother's daughter, born at home or abroad;
- son's daughter or daughter's daughter, described as one's own nakedness;
- father's wife's daughter conceived by the father, identified as sister.

No named family or act occurs.

## Leviticus 18:12–16 — AUNTS, DAUGHTER-IN-LAW, BROTHER'S WIFE

The list continues with the father's sister, mother's sister, father's
brother's wife, daughter-in-law and brother's wife. Each source relationship
remains separate; nobody approaches anyone in the chapter.

## Leviticus 18:17–18 — CONNECTED WOMEN AND THE LIVING-SISTER CONDITION

A woman and her daughter may not both be addressed, nor the woman's son's
daughter or daughter's daughter. The source calls them near kinswomen and the
act wickedness.

A wife may not be joined by her sister as a rival while the wife is alive. The
alive-sister condition is retained and not generalized beyond the source.

## Leviticus 18:19–23 — PERIOD, NEIGHBOUR, MOLECH, MAN, ANIMAL

The LORD prohibits approaching a woman for the stated act during her
source-defined impurity, lying carnally with a neighbour's wife, giving a child
as a sacrifice to Molech, lying with a man as with a woman, and sexual acts
between a person and an animal. The source labels the acts and effects in its
own terms. No participant, victim, consent State, ceremony, animal response or
actual event is supplied.

## Leviticus 18:24–28 — THE LAND VOMITED THEM OUT

The LORD tells Israel not to defile themselves by the listed acts. He attributes
those acts to the nations being cast out and to the earlier men of the land. He
states that the land became defiled, that he punished its iniquity and that the
land vomited out its inhabitants.

These are direct divine historical and causal claims. The land is not given an
invented mind, mouth, motive or physical vomiting mechanism. The warning says
the land may likewise vomit Israel out if they defile it.

## Leviticus 18:29–30 — CUT-OFF WARNING AND FINAL IDENTITY LINE

The LORD says people who perform the listed acts will be cut off. Native-born
and foreign resident are both addressed. Israel must keep the requirements and
not practice the attributed earlier customs. The chapter closes with the LORD's
identity statement.

No act, detection, judgment, removal or land reaction occurs inside this
chapter's observable present.

## Character and world-ledger changes

- LORD directly distinguishes Israel's rule set from attributed Egypt/Canaan practices;
- every kinship selector in verses 7–18 remains separately addressable;
- home/abroad birth and living-sister conditions remain exact;
- period, neighbour's wife, Molech-child, male-male and human-animal branches remain source-worded prohibitions;
- earlier national practice, land defilement, punishment and vomiting remain divine attribution;
- native-born and foreign resident share the final prohibition/enforcement boundary;
- no named household, prohibited act, sacrifice, enforcement or land reaction occurs;
- all prospective living people, children, animals and land-if-faced are Joe-faced;
- no contradiction, SKIP, crack or Captain appearance occurs;
- publication remains held; the attributed prior national acts and mechanisms remain unresolved beyond the source claim.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — RELATIVE ACCESS CONTROL`;
- migration warning: `DO NOT IMPORT EGYPT.EXE OR CANAAN.EXE`;
- relationship bus: `FATHER / MOTHER / SISTER / AUNT / IN-LAW / GRANDDAUGHTER`;
- sister interlock: `WHILE CURRENT SISTER IS ALIVE`;
- Molech port: `DO NOT INSERT CHILD`;
- animal boundary: `WRONG SPECIES SOCKET`;
- land status: `DEFILED / QUEASY / PRIOR TENANTS EJECTED`;
- foreign-resident support: `SAME RULES, SAME VOMIT WARNING`;
- barcode: `CHB-LEV18-30-RELATIVE-MAP-LAND-VOMIT-HELD`.

## FIR verification

- all 30 verse markers are represented in order;
- direct LORD identity, history, morality, life, land and enforcement claims remain attributed;
- Egypt residence and future Canaan destination remain source claims;
- verses 7–18 retain every exact relationship and condition;
- verses 19–23 retain each separately prohibited act without invented occurrence;
- source labels are preserved as source labels, not converted into universal narrator judgment;
- child sacrifice remains prohibited and no child event is depicted;
- animal roles remain prospective and Joe-faced if shown;
- prior-nation practice and land-vomit history remain divine attribution;
- no land mind, motive, anatomy or physical mechanism is invented;
- native-born and foreign-resident scope is retained;
- no contradiction, SKIP, crack, Captain or YOINK is added;
- publication remains held and unpublished.

Continuation required: Leviticus 19 addresses holiness, parents, Sabbaths,
offerings, gleaning, wages, disability, judgment, mixtures, fruit timing,
weights and foreign-resident treatment.
