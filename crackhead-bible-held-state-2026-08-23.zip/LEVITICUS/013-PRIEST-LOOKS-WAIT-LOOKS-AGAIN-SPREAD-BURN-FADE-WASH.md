# CRACKHEAD LEVITICUS 13

## Title page

**PRIEST LOOKS. WAIT SEVEN. PRIEST LOOKS AGAIN.**

**SPREAD? UNCLEAN. FADE? WASH. GARMENT WON'T CHANGE? BURN THE BASTARD.**

Source parent: Leviticus chapter 13, verses 1–59, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-013/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/012-SEVEN-THIRTY-THREE-FOURTEEN-SIXTY-SIX-BIRDS-IF-NO-LAMB.md`.

CrackFlix routing: none. The chapter supplies prospective diagnostic branches,
not an observed patient or a claim/act mismatch.

## Causal foundation

```text
LORD SPEAKS TO MOSES + AARON
-> SWELLING / SCAB / BRIGHT SPOT -> BRING PERSON TO PRIEST

WHITE HAIR + DEEPER APPEARANCE
-> PRONOUNCE UNCLEAN
NO WHITE HAIR + NOT DEEP
-> ISOLATE 7
-> NO SPREAD -> ISOLATE 7 MORE
-> FADED + NO SPREAD -> CLEAN + WASH CLOTHES
-> LATER SPREAD -> REINSPECT -> UNCLEAN

WHITE SWELLING + WHITE HAIR + RAW FLESH
-> CHRONIC / UNCLEAN / NO ISOLATION NEEDED
ALL SKIN WHITE + NO RAW FLESH
-> CLEAN
RAW FLESH APPEARS
-> UNCLEAN
RAW FLESH RETURNS WHITE
-> REINSPECT -> CLEAN

HEALED BOIL SITE OR FIRE-BURN SITE
-> DEEP + WHITE HAIR -> UNCLEAN
-> NOT DEEP / NO WHITE HAIR / DIM -> ISOLATE 7
-> SPREAD -> UNCLEAN
-> STAYS / FADES -> SCAR -> CLEAN

HEAD OR BEARD ITCH
-> DEEP + THIN YELLOW HAIR -> UNCLEAN
-> NOT DEEP + NO BLACK HAIR -> ISOLATE 7
-> NO SPREAD / NO YELLOW / NOT DEEP -> SHAVE AROUND IT + ISOLATE 7
-> STILL NO SPREAD / NOT DEEP -> CLEAN + WASH
-> LATER SPREAD -> UNCLEAN WITHOUT YELLOW-HAIR TEST
-> ARRESTED + BLACK HAIR GROWS -> HEALED / CLEAN

DULL-WHITE SPOTS -> HARMLESS RASH / CLEAN
BALD OR BALD FOREHEAD ALONE -> CLEAN
REDDISH-WHITE BALD-AREA PLAGUE -> INSPECT -> UNCLEAN

PRONOUNCED PERSON
-> TORN CLOTHES + LOOSE HAIR + COVER UPPER LIP
-> CRY UNCLEAN! UNCLEAN!
-> DWELL ALONE OUTSIDE CAMP WHILE PLAGUE REMAINS

GREENISH/REDDISH WOOL / LINEN / WARP / WOOF / LEATHER
-> PRIEST INSPECTS + ISOLATES 7
-> SPREAD -> DESTRUCTIVE MILDEW / BURN WHOLE THING
-> NO SPREAD -> WASH + ISOLATE 7 MORE
-> COLOR UNCHANGED EVEN WITHOUT SPREAD -> BURN
-> FADED -> TEAR OUT PATCH
-> RETURNS -> BURN AFFECTED THING
-> DEPARTED -> WASH SECOND TIME -> CLEAN
```

## Leviticus 13:1–8 — THE FIRST SKIN ROUTER GETS TWO SEVEN-DAY LOOPS

The LORD speaks directly to Moses and Aaron. A person with a swelling, scab or
bright spot that becomes the source-classified plague is brought to Aaron or
one of his priest sons.

The priest examines the skin. White hair plus an appearance deeper than the
skin routes directly to an unclean pronouncement. A white spot that is not
deeper and has no white hair routes to seven days of isolation.

On day seven, an arrested, non-spreading plague receives seven more days. On
the next examination, faded and non-spreading means the priest calls it a scab,
pronounces the person clean and requires clothes washing. If the scab later
spreads after the cleansing appearance, the person returns; observed spreading
then routes to an unclean pronouncement.

These are prospective examinations. No patient, lesion, priest examination,
isolation or pronouncement actually occurs in the chapter.

## Leviticus 13:9–17 — A WHOLE BODY OF WHITE CAN BE CLEAN UNTIL RAW FLESH APPEARS

A white swelling with white hair and raw flesh is called chronic leprosy. The
priest pronounces the person unclean without isolation because the rule already
classifies the State.

If the condition covers the person's visible skin from head to feet and all the
flesh has turned white, the priest pronounces the person clean. When raw flesh
appears, the person is unclean. If the raw flesh changes back to white, the
person returns and may be pronounced clean.

Partial signs, total white coverage and visible raw flesh are different inputs.
The clean full-white branch does not contradict the raw-flesh branch.

## Leviticus 13:18–23 — THE BOIL IS HEALED BEFORE THIS BRANCH EVEN STARTS

When a boil on the skin has healed and its former site develops a white swelling
or reddish-white bright spot, the spot is shown to the priest. A deeper
appearance with white hair routes to an unclean pronouncement. No white hair,
no depth and a dim appearance route to seven days of isolation. Spreading then
means unclean; staying in place means a boil scar and clean.

The source does not classify the original boil as the plague. It explicitly
begins with a healed boil and a changed site. Crackheadverse boils remain normal,
ancient organism carriers and status symbols. That universe rule does not alter
this source inspection branch, and the word “boil” alone does not summon
Captain Crackhead.

## Leviticus 13:24–28 — FIRE-BURN SCARS USE THE SAME SPREAD TEST

A fire burn whose raw flesh becomes reddish-white or white is examined. White
hair plus depth routes to unclean. No white hair, no depth and fading route to
seven days of isolation. Spreading at the next examination means unclean.
Staying in place and fading means the swelling or scar from the burn and clean.

No fire event, burn injury, healing interval or person is narrated.

## Leviticus 13:29–37 — HEAD OR BEARD ITCH: DON'T SHAVE THE ACTUAL ITCH

For a head or beard plague, depth plus thin yellow hair routes to an unclean
pronouncement. If it is not deeper and has no black hair, the priest isolates
the person for seven days.

If the itch has not spread, has no yellow hair and is not deeper, the person is
shaved except for the itch and isolated seven more days. Continued non-spread
and no depth route to clean plus clothes washing.

If it spreads after cleansing, the priest does not need the yellow-hair test;
the person is unclean. If it remains arrested and black hair grows, it is called
healed and clean, and the priest pronounces clean.

## Leviticus 13:38–44 — DULL SPOTS AND BALDNESS ARE CLEAN; A BALD-AREA PLAGUE ISN'T

Dull-white bright spots are classified as a harmless rash and clean. Hair loss
from the head or front forehead is baldness and clean.

A reddish-white plague in the bald head or forehead is a separate input. The
priest examines its swelling; when it matches the stated plague appearance, he
pronounces the person unclean. Baldness itself is not the trigger.

## Leviticus 13:45–46 — THE PRONOUNCED PERSON BECOMES HIS OWN WARNING SYSTEM

A person in whom the plague remains wears torn clothes, leaves head hair loose,
covers the upper lip and cries, **“Unclean! Unclean!”** The person remains
unclean for all days the plague is present, dwells alone and lives outside the
camp.

This is required prospective speech, not a line spoken by an observed person in
this chapter. No emotion, social reaction, enforcement event, dwelling design,
distance or recovery is supplied.

## Leviticus 13:47–52 — THE GARMENT GETS ISOLATED; SPREAD MEANS FIRE

The garment branch covers wool, linen, warp, woof, leather and leather-made
objects. A greenish or reddish plague is shown to the priest and isolated for
seven days.

If it spreads, the source calls it destructive mildew and unclean. The affected
garment, woven component or leather object is burned in fire. No owner, maker,
wearer, inspector, actual garment or fire occurrence is narrated.

## Leviticus 13:53–59 — NO SPREAD ISN'T ENOUGH IF THE COLOR WON'T CHANGE

If the garment plague has not spread, the priest commands the thing washed and
isolated seven more days. After washing, unchanged color routes to burning even
when it still has not spread.

If washing makes the plague fade, the affected patch is torn from the garment,
skin, warp or woof. If it appears again, the affected thing is spreading and is
burned. If the plague departs, the article is washed a second time and becomes
clean.

The chapter closes by identifying this as the law for pronouncing wool, linen,
warp, woof and skin objects clean or unclean.

## Character and world-ledger changes

- LORD directly gives Moses and Aaron the complete inspection law;
- Aaron and priest sons receive examination, isolation and pronouncement roles;
- initial skin, chronic/raw-flesh, healed-boil, fire-burn, head/beard, rash and baldness branches remain distinct;
- spread, depth, hair color, raw flesh, fading and time are explicit selectors;
- seven-day reinspection can occur once or twice depending on the branch;
- clean pronouncements can require clothes washing;
- the healed-boil branch does not classify genetically normal boils themselves as plague;
- a pronounced person's required clothing, speech and outside-camp State are retained;
- garment materials use inspect, isolate, wash, reinspect, tear-out and burn routes;
- unchanged color after washing can require burning without spread;
- all prospective living patients, priests and material-source organisms are Joe-faced;
- no actual patient, lesion, examination, isolation, pronouncement, garment or destruction occurs;
- no contradiction, SKIP, crack or Captain appearance occurs;
- publication remains held; Nadab/Abihu burial, cloud departure and Joseph burial remain open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — PRIESTLY SKIN SUPPORT DESK`;
- intake: `SWELL / SCAB / BRIGHT SPOT -> SHOW PRIEST`;
- scanner: `DEPTH / HAIR COLOR / RAW FLESH / SPREAD`;
- timer: `WAIT 7 / LOOK / MAYBE WAIT 7 AGAIN`;
- full-white alert: `EVERYWHERE WHITE = CLEAN / RAW PATCH = UNCLEAN`;
- boil compatibility sticker: `BOIL NORMAL / WE ARE INSPECTING WHAT CAME AFTER`;
- itch barber warning: `SHAVE AROUND IT, DICKHEAD`;
- baldness result: `BALD = BALD / RED-WHITE PLAGUE = DIFFERENT JOB`;
- public output device: `UNCLEAN! UNCLEAN!`;
- garment service: `ISOLATE / WASH / LOOK / PATCH OR FIRE`;
- stubborn-color support: `DIDN'T SPREAD / DIDN'T CHANGE / BURN ANYWAY`;
- barcode: `CHB-LEV13-59-LOOK-WAIT-LOOK-SPREAD-FADE-BURN-NOCRACK-HELD`.

## FIR verification

- all 59 verse markers are represented in order;
- direct LORD speech to Moses and Aaron remains God-only speech;
- every branch remains prospective rather than an invented patient occurrence;
- initial lesion depth/hair and two-stage isolation routes remain exact;
- chronic white-hair/raw-flesh and total-white/raw-flesh change routes remain distinct;
- healed-boil and fire-burn branches retain their separate source origins;
- Crackheadverse boil genetics do not overwrite source diagnostics;
- head/beard yellow-hair, black-hair, shaving and reinspection rules remain exact;
- dull-white rash, baldness and bald-area plague remain different States;
- required torn clothes, loose hair, covered lip, exact cry and outside-camp dwelling remain complete;
- wool/linen/warp/woof/leather scope remains complete;
- garment spread, unchanged-color, faded-patch, recurrence and departed-plague routes remain distinct;
- no modern diagnosis, contagion mechanism, medical advice or historical patient is imported;
- every prospective living person and source organism uses Joe face if shown;
- no contradiction, SKIP, crack or Captain is added;
- publication remains held and unpublished.

Continuation required: Leviticus 14 establishes the cleansing process for a
healed person and the inspect-empty-scrape-replaster-demolish state machine for
a plague in a house.
