# CRACKHEAD LEVITICUS 9

## Title page

**EIGHTH DAY. AARON RUNS THE ALTAR.**

**FIRE COMES OUT. EVERYONE SHOUTS AND FALLS ON THEIR JOE FACES.**

Source parent: Leviticus chapter 9, verses 1–24, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-009/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/008-WASH-DRESS-OIL-BLOOD-EAR-THUMB-TOE-STAY-SEVEN-DAYS.md`.

CrackFlix routing: none. No completed observable contradiction occurs.

## Causal foundation

```text
EIGHTH DAY
-> MOSES CALLS AARON + SONS + ISRAEL ELDERS
-> AARON: SIN CALF + DEFECT-FREE BURNT RAM
-> PEOPLE: SIN GOAT + YEAR-OLD CALF/LAMB + PEACE BULL/RAM + OIL MEAL
-> MOSES SAYS LORD APPEARS TODAY

ALL ITEMS BROUGHT / ALL CONGREGATION STANDS BEFORE LORD
-> MOSES IDENTIFIES LORD-COMMANDED WORK + ATTRIBUTED GLORY RESULT
-> AARON ORDERED TO ATONE FOR SELF/PEOPLE THEN OFFER PEOPLE'S ITEMS

AARON PERSONAL SIN OFFERING
-> CALF KILLED
-> SONS DELIVER BLOOD
-> HORNS + BASE
-> FAT/KIDNEYS/LIVER COVER BURNED
-> MEAT/SKIN BURNED OUTSIDE CAMP

AARON PERSONAL BURNT OFFERING
-> RAM KILLED
-> SONS DELIVER BLOOD / PIECES / HEAD
-> BLOOD AROUND ALTAR
-> PIECES BURNED / INNARDS + LEGS WASHED + BURNED

PEOPLE'S OFFERINGS
-> SIN GOAT LIKE FIRST
-> BURNT OFFERING BY ORDINANCE
-> MEAL HANDFUL BURNED BESIDE MORNING BURNT OFFERING
-> PEACE BULL + RAM KILLED
-> BLOOD AROUND ALTAR / FAT PACKAGE BURNED
-> BREASTS + RIGHT THIGH WAVED

AARON LIFTS HANDS / BLESSES PEOPLE / COMES DOWN
-> MOSES + AARON ENTER TENT / EXIT / BLESS PEOPLE
-> LORD'S GLORY APPEARS TO ALL (NARRATOR ATTRIBUTION)
-> FIRE COMES OUT FROM BEFORE LORD
-> BURNT OFFERING + ALTAR FAT CONSUMED
-> ALL PEOPLE SEE / SHOUT / FALL ON FACES
```

## Leviticus 9:1–4 — DAY EIGHT INPUT LIST: AARON TWO, PEOPLE FIVE PLUS MEAL

On the eighth day Moses calls Aaron, Aaron's sons and Israel's elders. He tells
Aaron to take a calf for his sin offering and a defect-free ram for his burnt
offering.

Aaron is to tell Israel to bring a male goat for a sin offering; a one-year-old
defect-free calf and lamb for a burnt offering; a bull and ram for peace
offerings; and a meal offering mixed with oil. Moses says the LORD will appear
to them that day. This remains Moses' attributed announcement until the later
narrated appearance.

## Leviticus 9:5–7 — EVERYTHING ARRIVES, EVERYONE STANDS THERE, START THE JOB

The commanded items are brought before the Tent of Meeting. All the
congregation comes near and stands before the LORD.

Moses calls the work the thing the LORD commanded and says the LORD's glory
will appear. He tells Aaron to approach the altar, offer his sin and burnt
offerings, make atonement for himself and the people, then offer the people's
items and make atonement for them as commanded.

The claimed atonement and glory effects remain attributed. The arrival,
assembly, speech and instruction are performed events.

## Leviticus 9:8–11 — AARON'S SIN CALF: SONS HAND HIM BLOOD, REST GOES OUTSIDE

Aaron approaches the altar and kills his sin-offering calf. His sons present
the blood. Aaron dips his finger in it, puts blood on the altar horns and pours
the rest at the base.

He burns the fat, kidneys and liver cover on the altar as the LORD commanded
Moses. The calf's meat and skin are burned outside the camp. The source does not
name the outside-camp operator in verse 11, so one is not invented.

## Leviticus 9:12–14 — AARON'S BURNT RAM, DELIVERED TO HIM PIECE BY PIECE

Aaron kills the burnt offering. His sons deliver its blood, which he sprinkles
around the altar. They deliver the offering piece by piece with the head, and
Aaron burns them.

He washes the innards and legs and burns them over the burnt offering. Aaron is
now visibly operating the service that prior chapters specified.

## Leviticus 9:15–17 — PEOPLE'S GOAT, BURNT PACKAGE, THEN ONE HANDFUL

Aaron presents the people's sin-offering goat, kills it and processes it like
the first sin offering. He presents the people's burnt offering and performs it
according to the ordinance.

He presents the meal offering, fills his hand from it and burns that portion on
the altar in addition to the morning burnt offering. “According to the
ordinance” preserves the referenced procedure without inventing omitted camera
angles or duplicating unstated details.

## Leviticus 9:18–21 — PEACE BULL AND RAM: BLOOD, FAT, BREASTS, RIGHT THIGH

Aaron kills the bull and ram of the people's peace offering. His sons deliver
the blood, and he sprinkles it around the altar.

The fat from both animals—including the ram's fat tail, innard-covering fat,
kidneys and liver cover—is placed on the breasts. Aaron burns the fat on the
altar. He waves the breasts and right thigh before the LORD as Moses commanded.

## Leviticus 9:22–23 — AARON BLESSES, THEN MOSES AND AARON GO IN AND COME OUT

Aaron lifts his hands toward the people and blesses them. The words are absent.
He comes down after offering the sin, burnt and peace offerings.

Moses and Aaron enter the Tent of Meeting, come back out and bless the people.
Those blessing words are also absent. The LORD's glory is then narrated as
appearing to all the people. The appearance is retained as an observed
source event with attributed identity; its form and mechanism are not supplied.

## Leviticus 9:24 — FIRE OUT, ALTAR CONTENTS GONE, CROWD DOWN

Fire comes out from before the LORD and consumes the burnt offering and fat on
the altar. All the people see it. They shout and fall on their faces.

The visible sequence is fire emergence, consumption, sight, shout and fall.
The source gives the fire an origin phrase but supplies no physical mechanism,
fuel accounting, temperature, duration, words in the shout or private mental
State. None is added.

Moses' earlier announcement and the later narrated event agree at the source
boundary. That is not an observable contradiction. No crack forms and Captain
does not arrive.

## Character and world-ledger changes

- eighth day follows the seven-day consecration address;
- Moses calls Aaron, sons and Israel's elders;
- Aaron and the people receive separately specified offering packages;
- all commanded items are actually brought;
- all congregation comes near and stands before the LORD;
- Aaron begins the first detailed public altar service after ordination;
- Aaron's sons actively deliver blood, pieces, head and peace-offering inputs;
- Aaron's personal sin/burnt routes precede the people's sin/burnt/meal/peace routes;
- seven animal inputs are specified across Aaron and people;
- explicit killings and ordinance-referenced offering performance remain distinguished;
- morning burnt offering is already present as the meal-offering addition point;
- Aaron blesses the people and descends;
- Moses and Aaron enter and exit the Tent and bless the people;
- glory appearance remains narrator-attributed to the LORD;
- fire emerges, consumes altar offering/fat, and is seen by all people;
- congregation visibly shouts and falls on faces;
- blessing words, appearance form and fire mechanism remain unresolved;
- all living people and animals are Joe-faced;
- no contradiction, SKIP, crack or Captain appearance occurs;
- publication remains held; cloud departure and Joseph burial remain open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — EIGHTH-DAY PRODUCTION DEPLOYMENT`;
- Aaron input queue: `CALF SIN / RAM BURNT`;
- public input queue: `GOAT SIN / CALF+LAMB BURNT / BULL+RAM PEACE / OIL MEAL`;
- staging light: `ALL CONGREGATION STANDING BY`;
- priest API: `SONS DELIVER / AARON PROCESSES`;
- personal route: `SELF FIRST / PEOPLE AFTER`;
- morning extension: `ADD ONE HANDFUL TO EXISTING FIRE JOB`;
- blessing audio: `FILE NOT INCLUDED`;
- Tent transition: `MOSES + AARON IN / MOSES + AARON OUT`;
- appearance driver: `CRACKHEAD GLORY — MECHANISM UNAVAILABLE`;
- fire output: `FROM BEFORE LORD -> ALTAR CONTENTS CONSUMED`;
- crowd output: `SEE -> AAAAA -> FACE FLOOR`;
- barcode: `CHB-LEV09-24-DAY8-AARONRUN-FIREOUT-CROWDOWN-NOCRACK-HELD`.

## FIR verification

- all 24 verse markers are represented in order;
- eighth-day call retains Aaron, sons and elders;
- Aaron and people offering packages remain separate and complete;
- Moses' appearance/atonement statements remain attributed speech;
- item arrival and congregation standing are performed acts;
- Aaron's personal sin and burnt routes remain before people's routes;
- sons' delivery acts and Aaron's processing acts remain distinct;
- people's sin goat, ordinance-referenced burnt offering, meal handful and peace pair remain ordered;
- morning burnt offering is retained as already present without invented origin detail;
- peace blood, fat, breasts and right thigh remain exact;
- Aaron's blessing and Moses/Aaron blessing retain missing words;
- Tent entry/exit occurs before narrated glory appearance;
- fire, consumption, sight, shout and fall remain an observable sequence;
- fire/glory identity attribution is preserved without invented mechanism;
- agreement between announced and narrated appearance is not misclassified as contradiction;
- every living person, animal and source organism uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Leviticus 10 records Nadab and Abihu's unauthorized
fire, consuming fire, silence, body removal, priest conduct rules and Moses'
final inquiry with Aaron's answer.
