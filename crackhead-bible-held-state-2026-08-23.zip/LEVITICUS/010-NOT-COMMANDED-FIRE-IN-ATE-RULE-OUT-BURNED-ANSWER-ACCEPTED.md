# CRACKHEAD LEVITICUS 10

## Title page

**FIRE WASN'T COMMANDED. THEY OFFERED IT.**

**GOAT WAS SUPPOSED TO BE EATEN. IT WAS BURNED. MOSES ACCEPTED THE ANSWER.**

Source parent: Leviticus chapter 10, verses 1–20, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-010/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/009-EIGHTH-DAY-AARON-RUNS-THE-ALTAR-FIRE-COMES-OUT.md`.

CrackFlix routing:

- `S098-E001-LEV10 — OFFERED FIRE THE LORD HAD NOT COMMANDED`;
- `S099-E001-LEV10 — EAT ROUTE BURNED; EXPLANATION ACCEPTED`.

Both are new contradiction types. No SKIP occurs.

## Causal foundation

```text
NADAB + ABIHU EACH TAKE CENSER
-> PUT FIRE + INCENSE IN IT
-> OFFER BEFORE LORD
-> SOURCE: FIRE WAS NOT COMMANDED
-> REQUIRED COMMANDED SERVICE / PERFORMED UNCOMMANDED FIRE MISMATCH CLOSES S098
-> YOINK! / POKE BOIL / LICK FINGER / WALK AWAY
-> FIRE COMES OUT / DEVOURS THEM / THEY DIE

MOSES QUOTES LORD HOLINESS/GLORY LINE
-> AARON SILENT
-> MISHAEL + ELZAPHAN CARRY BODIES IN TUNICS OUTSIDE CAMP

MOSES TO AARON + ELEAZAR + ITHAMAR
-> DO NOT LOOSE HAIR / TEAR CLOTHES / LEAVE TENT DOOR
-> ISRAEL MAY MOURN BURNING
-> THEY COMPLY

LORD DIRECTLY TO AARON
-> NO WINE/STRONG DRINK FOR TENT ENTRY
-> DISTINGUISH HOLY/COMMON + CLEAN/UNCLEAN
-> TEACH ISRAEL STATUTES

MOSES TO SURVIVING PRIESTS
-> EAT UNLEAVENED MEAL REMAINDER BESIDE ALTAR
-> AARONIC FAMILY EATS BREAST/THIGH IN CLEAN PLACE

MOSES INSPECTS PEOPLE'S SIN GOAT
-> GOAT WAS BURNED
-> MOSES ANGRY WITH ELEAZAR + ITHAMAR
-> BLOOD DID NOT ENTER INNER SANCTUARY
-> RULE REQUIRES PRIESTS EAT IT
-> AARON: TODAY'S OFFERINGS + EVENTS / WOULD EATING PLEASE LORD?
-> MOSES HEARS / ANSWER PLEASES HIM
-> REQUIRED EAT / ACTUAL BURN / ACCEPTED RESULT MISMATCH CLOSES S099
-> YOINK! / POKE BOIL / LICK FINGER / WALK AWAY
```

## Leviticus 10:1–2 — THE FIRE JOB THAT WASN'T IN THE JOB

Nadab and Abihu, Aaron's sons, each take a censer, put fire in it, place incense
on it and offer it before the LORD. The source calls it strange fire and states
that the LORD had not commanded it.

The service boundary is commanded priest work. Their visible act is an
uncommanded fire offering. No motive, accident, intoxication, misunderstanding
or private belief is supplied. The command/act mismatch completes
`S098-E001-LEV10`.

Captain Crackhead appears in his suit. One boil is on Nadab.

He pokes it, licks his finger and says, **“YOINK!”**

He walks away and does not look back. Nadab, Abihu and the service continue
unchanged.

Fire comes out from before the LORD, devours Nadab and Abihu, and they die before
the LORD. The narrator supplies the fire-origin attribution and deaths, but not
the mechanism, body condition, duration or causal physics. Captain did nothing
to the outcome.

## Leviticus 10:3 — MOSES QUOTES GOD; AARON SAYS NOTHING

Moses tells Aaron this is what the LORD spoke: “I will show myself holy to those
who come near me, and before all the people I will be glorified.” This is a
direct divine line inside Moses' quotation and remains God-only speech.

Aaron holds his peace. Silence is observable. Grief, agreement, shock,
submission or any other internal meaning is not supplied.

## Leviticus 10:4–5 — COUSINS CARRY THE TWO TUNIC-WRAPPED BODIES OUT

Moses calls Mishael and Elzaphan, sons of Aaron's uncle Uzziel. He orders them
to carry their brothers away from before the sanctuary and outside the camp.

They approach and carry Nadab and Abihu in their tunics outside the camp as
Moses said. The kin relation, approach, tunics, transport and destination are
observed. No funeral procedure or burial occurs.

## Leviticus 10:6–7 — PRIESTS STAY ON DUTY; THE REST OF ISRAEL MAY MOURN

Moses tells Aaron, Eleazar and Ithamar not to let their head hair go loose or
tear their clothes, under stated death and congregation-anger outcomes. The
whole house of Israel may bewail the burning attributed to the LORD.

Aaron and his surviving sons must not leave the Tent door because the LORD's
anointing oil is on them. They do according to Moses' word. Priest conduct and
Israel's mourning permission address different people, so they do not conflict.

## Leviticus 10:8–11 — NO DRINK BEFORE TENT ENTRY; DISTINGUISH AND TEACH

The LORD speaks directly to Aaron. Aaron and his sons must not drink wine or
strong drink when entering the Tent of Meeting, under a death warning and
perpetual generational statute.

They are to distinguish holy from common and unclean from clean, and teach
Israel all statutes spoken by the LORD through Moses.

The rule follows Nadab and Abihu's deaths, but the source does not say either
man drank. No intoxication cause is invented.

## Leviticus 10:12–15 — SURVIVING PRIEST FOOD STILL HAS TO GO SOMEWHERE

Moses tells Aaron, Eleazar and Ithamar—the sons who remain—to eat the remaining
meal offering without yeast beside the altar in a holy place. He attributes
most-holy status and identifies it as their commanded portion.

The waved breast and raised thigh may be eaten in a clean place by Aaron, his
sons and daughters. The breast and thigh are brought with the fat fire offering,
waved, and remain a perpetual portion as commanded.

Holy-place meal remainder and clean-place peace portions retain different
location and eligibility boundaries.

## Leviticus 10:16–18 — MOSES CHECKS THE GOAT: THE EAT ROUTE WAS BURNED

Moses diligently inquires about the people's sin-offering goat and observes
that it was burned. He is angry with Eleazar and Ithamar.

Moses asks why they did not eat it in the sanctuary. He says it was most holy,
given to them to bear the congregation's iniquity and make atonement. He points
out that its blood was not brought into the inner sanctuary and says they
certainly should have eaten it as he commanded.

The retained selector from Leviticus 6 is explicit: blood not brought inside
routes the animal to priestly eating. The observed goat went to fire instead.

## Leviticus 10:19–20 — AARON ANSWERS; MOSES ACCEPTS THE NON-EATING

Aaron answers Moses. He observes that the sin and burnt offerings were offered
that day and that “such things as these” happened to him. He asks whether eating
the sin offering that day would have been pleasing in the LORD's sight.

Aaron does not name Nadab and Abihu in the answer, and the source does not
specify which events or internal State control the question. Those relations
remain unresolved.

Moses hears the answer, and it is pleasing in his sight. The command required
eating; the goat was burned; the explanation produces acceptance without a
replacement rule or explicit exception. That observable relation completes
`S099-E001-LEV10`.

Captain Crackhead appears. One boil is on Aaron.

He pokes it, licks his finger and says, **“YOINK!”**

He walks away and does not look back. Moses and Aaron's final State remains the
same: Moses is pleased with the answer.

## Character and world-ledger changes

- Nadab and Abihu perform an uncommanded censer/fire/incense offering;
- S098 closes on commanded-service versus uncommanded-fire performance;
- Captain's first poke/lick/YOINK changes nothing;
- attributed fire emerges, devours Nadab/Abihu and both die;
- Moses quotes the direct divine holiness/glory line;
- Aaron is silent;
- Mishael and Elzaphan carry the bodies in tunics outside camp;
- Aaron, Eleazar and Ithamar remain at Tent door and comply with conduct order;
- whole Israel receives mourning permission;
- LORD directly gives Aaron no-drink, distinction and teaching rules;
- no alcohol use by Nadab or Abihu is inferred;
- surviving Aaronic meal/breast/thigh allocations continue;
- Moses observes the people’s sin goat burned and becomes angry;
- outer-blood eat selector is restated against actual burn;
- Aaron answers with that day's offerings/events and a pleasingness question;
- Moses accepts the answer without an explicit rule replacement;
- S099 closes on required eating versus actual burning plus accepted result;
- Captain's second poke/lick/YOINK changes nothing;
- Nadab and Abihu become dead Joe histories; Captain remains boil-free;
- all other living people and source organisms remain Joe-faced;
- publication remains held; burials, fire mechanisms, cloud departure and Joseph burial remain open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — AUTHORIZED FIRE SUPPORT INCIDENT`;
- censer status: `INPUT ACCEPTED / JOB NOT FOUND`;
- S098 title card: `NOT COMMANDED / RAN ANYWAY`;
- Captain action log: `POKE / LICK / YOINK / ZERO EFFECT`;
- body export ticket: `TUNIC WRAP / OUTSIDE CAMP / BURIAL NULL`;
- priest grief UI: `HAIR LOCKED / CLOTHES LOCKED / DOOR LOCKED`;
- public grief UI: `ISRAEL MAY BEWAIL`;
- entry interlock: `WINE OR STRONG DRINK = NO`;
- priest classifier: `HOLY|COMMON / CLEAN|UNCLEAN`;
- training requirement: `TEACH EVERY STATUTE`;
- goat router: `BLOOD OUT -> EAT / ACTUAL -> BURNED`;
- S099 support response: `WHY NOT EAT? / WOULD THAT PLEASE? / FAIR ENOUGH`;
- barcode: `CHB-LEV10-20-S098-S099-2YOINK-NOSKIP-HELD`.

## FIR verification

- all 20 verse markers are represented in order;
- each censer/fire/incense act and explicit not-commanded boundary remains observable;
- no motive, alcohol use or theological justification is invented;
- S098 crack closes before the fatal fire outcome;
- Captain's action is causally unnecessary and boil-free;
- fire origin/death remains narrator attribution without invented physics;
- Moses' quoted LORD line remains direct divine speech inside attribution;
- Aaron's silence remains silence without mind-reading;
- Mishael/Elzaphan genealogy, tunics and outside transport remain exact;
- priest non-mourning/door rule and Israel mourning permission remain separately addressed;
- direct LORD no-drink/distinguish/teach rules remain complete;
- meal remainder and breast/thigh food boundaries remain distinct;
- burned goat, Moses' anger, outer-blood selector and should-eat statement remain observed;
- Aaron's exact answer boundary remains intact without supplied referents;
- Moses' acceptance is retained without inventing a permanent exception;
- S099 is distinct from S098 and receives no SKIP;
- two completed contradictions produce two exact `YOINK!` occurrences;
- every living person/animal/source organism uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Leviticus 11 establishes clean/unclean land-animal,
water-creature, bird, winged-crawler, carcass-contact, vessel and seed rules.
