# CRACKHEAD LEVITICUS 3

## Title page

**MALE OR FEMALE. HAND ON HEAD.**

**ALL FAT BELONGS TO GOD. DO NOT EAT THE BLOOD EITHER.**

Source parent: Leviticus chapter 3, verses 1–17, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-003/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/002-BRING-THE-HONEY-DONT-BURN-THE-HONEY-AND-PUT-SALT-ON-EVERYTHING.md`.

CrackFlix routing: none. No completed observable contradiction occurs.

## Causal foundation

```text
PEACE OFFERING SELECTED
-> HERD / SHEEP / GOAT PATH
-> MALE OR FEMALE / WITHOUT DEFECT
-> OFFERER HAND ON HEAD + KILL AT TENT
-> AARONIC PRIESTS SPRINKLE BLOOD AROUND ALTAR
-> SPECIFIED FAT + KIDNEYS + LIVER COVER REMOVED
-> SHEEP ALSO SUPPLIES ENTIRE FAT TAIL
-> PRIEST BURNS ALLOCATED PARTS
-> ALL FAT ASSIGNED TO LORD
-> FAT + BLOOD PROHIBITED AS FOOD IN ALL DWELLINGS
-> ALL PROCEDURES REMAIN PROSPECTIVE
```

## Leviticus 3:1–5 — HERD PEACE OFFERING

A herd peace offering may be male or female but must be without defect. The
offerer presents it before the LORD, lays a hand on its head and kills it at the
Tent door. Aaron's priest sons sprinkle its blood around the altar.

The fire portion is fat covering and surrounding the innards, both kidneys and
their loin-side fat, plus the liver cover removed with the kidneys. Aaron's
sons burn it on the altar above the burnt offering, wood and fire. The source
calls it a pleasant-aroma fire offering.

No animal, sex, offerer, priest, date, defect inspection or act is selected.

## Leviticus 3:6–11 — SHEEP PEACE OFFERING

A flock peace offering may likewise be male or female without defect. For a
lamb, the offerer presents it, lays a hand on its head and kills it before the
Tent. Aaron's sons sprinkle blood around the altar.

The fire portion includes the entire fat tail removed close to the backbone,
all entrail-covering/surrounding fat, both kidneys with loin-side fat, and the
liver cover removed with the kidneys. The priest burns it as food of the fire
offering to the LORD.

The sheep-only tail instruction is not imported into herd or goat paths.

## Leviticus 3:12–16 — GOAT PEACE OFFERING

For a goat, the offerer presents it before the LORD, lays a hand on its head and
kills it before the Tent. Aaron's sons sprinkle its blood around the altar.

The fire portion is the entrail-covering/surrounding fat, both kidneys with
loin-side fat, and liver cover removed with them. A priest burns the parts as
food of the fire offering and pleasant aroma. The source concludes that all fat
is the LORD's.

Although verse 12 says goat rather than restating sex/defect, the flock rule in
verse 6 supplies male-or-female/without-defect to the sheep-or-goat parent path.
That inheritance is source structure, not an invented goat exception.

## Leviticus 3:17 — THE FOOD LOCKOUT

A perpetual statute through generations and in all dwellings prohibits eating
fat or blood.

This agrees with the preceding allocation: blood goes around the altar and the
specified fat becomes the LORD's fire portion. No meal, violation, enforcement
or consequence occurs here.

## Character and world-ledger changes

- prospective peace offerers gain herd, sheep and goat input paths;
- male and female inputs are both permitted while no-defect remains required;
- offerers receive hand-placement and Tent-side killing roles;
- Aaronic priests receive blood sprinkling and allocated-part burning roles;
- herd/sheep/goat share kidney, kidney-fat, entrail-fat and liver-cover outputs;
- sheep alone adds the entire fat tail near the backbone;
- specified fat is allocated to the LORD's altar-fire food;
- all Israel generations/dwellings receive the no-fat/no-blood eating rule;
- prospective herd/flock animals are distinct living Joe-faced animals;
- no contradiction, SKIP, crack or Captain appearance occurs;
- no animal is selected, killed, divided, sprinkled, burned or eaten;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — PEACE THROUGH ORGAN ALLOCATION`;
- input selector: `HERD / SHEEP / GOAT / SEX ANY / DEFECT NONE`;
- user action: `TOUCH JOE HEAD -> KILL AT TENT`;
- priest action: `BLOOD 360° AROUND ALTAR`;
- standard output: `FAT + 2 KIDNEYS + LIVER COVER`;
- sheep DLC: `ENTIRE FAT TAIL NEAR BACKBONE`;
- altar menu: `FOOD OF FIRE OFFERING`;
- ownership label: `ALL FAT: LORD`;
- household warning: `FAT NO / BLOOD NO / EVERYWHERE / FOREVER`;
- barcode: `CHB-LEV03-17-3PATHS-ALLFAT-NOBLOOD-NOCRACK-HELD`.

## FIR verification

- all 17 verse markers are represented in order;
- herd, sheep and goat procedures remain separate;
- male/female permission and no-defect requirement remain simultaneous;
- offerer hand/kill and priest blood/burn roles remain distinct;
- every specified fat, kidney and liver-cover relation is retained;
- the sheep fat tail is not imported into other animal paths;
- goat inherits sex/defect from the explicit parent flock rule without inventing
  an exception;
- all-fat ownership and no-fat/no-blood consumption rules agree rather than
  generating false crack;
- pleasant aroma and fire-food ownership remain divine descriptions;
- instructions do not become performed offerings or meals;
- no unsupported contradiction is manufactured, so Captain does not appear;
- all prospective living people and animals use Joe face if shown;
- publication remains held and unpublished.

Continuation required: Leviticus 4 reconstructs inadvertent-sin offering paths
for anointed priest, congregation, ruler and ordinary person, including blood
location and disposal differences.
