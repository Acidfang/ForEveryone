# CRACKHEAD LEVITICUS 27

## Title page

**FIFTY. THIRTY. TWENTY. TEN. FIVE. THREE.**

**ADD A FIFTH. DON'T SWAP IT. IF YOU DO, BOTH ARE HOLY.**

Source parent: Leviticus chapter 27, verses 1–34, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-027/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/026-DO-THE-RULES-GET-RAIN-DONT-KEEP-LISTENING-SEVEN-TIMES-MORE.md`.

Joined parents: Leviticus 25 Jubilee/property rules; sanctuary shekel and priestly valuation roles.

CrackFlix routing: none. The chapter states prospective valuation, dedication,
redemption and consequence rules. No vow, exchange, sale, redemption, tithe or
death is performed.

## Causal foundation

```text
PERSON VOW
-> AGE + SEX TABLE -> SANCTUARY-SHEKEL VALUATION
POORER THAN TABLE
-> PRIEST VALUES BY ABILITY TO PAY

OFFERABLE ANIMAL GIVEN -> HOLY
EXCHANGE ATTEMPT -> ORIGINAL + SUBSTITUTE BOTH HOLY
NON-OFFERABLE ANIMAL -> PRIEST VALUE
REDEEM -> VALUE + ONE FIFTH

HOUSE DEDICATED -> PRIEST VALUE
REDEEM -> VALUE + ONE FIFTH

POSSESSION FIELD DEDICATED
-> SEED CAPACITY + YEARS TO JUBILEE -> VALUE
REDEEM -> VALUE + ONE FIFTH
NO REDEMPTION / SOLD TO ANOTHER
-> NO LATER REDEMPTION -> JUBILEE DEVOTED FIELD -> PRIEST OWNERSHIP

PURCHASED FIELD DEDICATED
-> VALUE TO JUBILEE + PAYMENT THAT DAY
-> JUBILEE RETURN TO ORIGINAL POSSESSOR

FIRSTBORN OX/SHEEP -> ALREADY LORD'S -> CANNOT DEDICATE AGAIN
UNCLEAN FIRSTBORN -> VALUE + FIFTH OR SALE

PERMANENTLY DEVOTED PERSON/ANIMAL/FIELD -> NO SALE / NO REDEMPTION
PERSON DEVOTED TO DESTRUCTION -> NO RANSOM / PUT TO DEATH

LAND TITHE -> LORD'S / HOLY
REDEEM -> ADD FIFTH
HERD/FLOCK TENTH UNDER ROD -> HOLY
EXCHANGE -> BOTH HOLY / NO REDEMPTION

NARRATOR -> COMMANDMENTS GIVEN BY LORD TO MOSES FOR ISRAEL AT SINAI
```

## Leviticus 27:1–8 — THE PERSON-VALUATION TABLE

The LORD tells Moses to give Israel a valuation table for a person consecrated
to the LORD by a vow, measured in sanctuary shekels:

- age twenty through sixty: male fifty, female thirty;
- age five through twenty: male twenty, female ten;
- age one month through five years: male five, female three;
- age sixty and upward: male fifteen, female ten.

If the person is poorer than the table valuation, the person is set before the
priest and the priest assigns a value according to ability to pay. The unequal
source categories are retained exactly as valuation categories; they are not
silently converted into claims about human worth. No person makes a vow, is
presented, valued or pays.

## Leviticus 27:9–13 — DON'T SWAP THE ANIMAL

An offerable animal given to the LORD becomes holy. It may not be altered or
exchanged, good for bad or bad for good. If an exchange is nevertheless made,
the original and substitute both become holy.

A source-labelled unclean animal that is not offered is set before the priest,
whose good-or-bad valuation stands. Redemption costs that valuation plus one
fifth. The prohibition and stated consequence occupy the same prospective
rule; they do not prove an exchange occurred. Every animal is Joe-faced if
shown.

## Leviticus 27:14–15 — HOUSE VALUE PLUS A FIFTH

When a person dedicates a house as holy, the priest evaluates it good or bad and
that valuation stands. If the dedicator redeems the house, the person adds one
fifth to the valuation and the house becomes theirs again. No house is
dedicated, inspected, priced or redeemed.

## Leviticus 27:16–21 — POSSESSION FIELD: SEED, YEARS AND JUBILEE

A dedicated possession field is valued by its seed capacity: sowing one homer
of barley corresponds to fifty silver shekels. Dedication from the Jubilee year
keeps the full valuation; dedication afterward is reduced according to the
years remaining until Jubilee.

The dedicator may redeem it by adding one fifth. If the field is not redeemed,
or has been sold to another person, it cannot later be redeemed. At Jubilee it
becomes holy as a devoted field and is owned by the priests. These are ordered
branches, not a completed field history.

## Leviticus 27:22–25 — PURCHASED FIELD RETURNS

A dedicated purchased field, unlike an ancestral possession field, is valued
by the priest only through Jubilee. The stated amount is paid that day as holy,
then at Jubilee the field returns to the person from whom it was bought—the
holder of the underlying possession. All valuations use the sanctuary shekel,
twenty gerahs to one shekel. No purchase, dedication, payment or return occurs.

## Leviticus 27:26–27 — YOU CAN'T DEDICATE WHAT IS ALREADY HIS

A firstborn ox or sheep may not be dedicated because it already belongs to the
LORD as firstborn. A source-labelled unclean firstborn animal may be bought back
for its valuation plus one fifth; if not redeemed, it is sold for the
valuation. The prior ownership State supplies the explicit reason for the
dedication exclusion. No animal is dedicated, redeemed or sold.

## Leviticus 27:28–29 — PERMANENTLY DEVOTED MEANS NO REDEMPTION

A permanently devoted thing from a person's holdings—person, animal or
possession field—may not be sold or redeemed and is most holy to the LORD. A
person devoted to destruction may not be ransomed and is to be put to death.

The source does not identify an actual devoted person, the actor or authority
that could create that State, a case, a judgment process or a death occurrence.
None is invented. The rule and lethal endpoint remain explicit and
prospective.

## Leviticus 27:30–33 — EVERY TENTH UNDER THE ROD

The land tithe from seed or tree fruit belongs to the LORD and is holy. A person
redeeming any of it adds one fifth. From herds and flocks, every tenth animal
passing under the rod is holy. It is not examined as good or bad and may not be
exchanged. If exchanged anyway, both animals become holy and cannot be
redeemed. No produce or animal passes through a tithe event.

## Leviticus 27:34 — LEVITICUS CLOSES AT SINAI

The narrator identifies these as the commandments the LORD commanded Moses for
Israel on Mount Sinai. This performs the command-attribution relation and
closes Leviticus. It does not perform any prospective vow, valuation,
dedication, exchange, redemption, sale, tithe or execution.

## Character and world-ledger changes

- person-vow valuations retain every age, sex and shekel category;
- poverty activates an explicit ability-to-pay priest valuation branch;
- offerable and non-offerable animal paths remain distinct;
- prohibited animal exchange has the explicit both-become-holy consequence;
- house and possession-field redemption add one fifth;
- possession-field value changes with years remaining to Jubilee;
- purchased fields return to the underlying possessor at Jubilee;
- firstborn offerable animals are already the LORD's and cannot be dedicated again;
- permanent devotion blocks sale/redemption, with the human destruction rule retained prospectively;
- land and animal tithe rules remain unperformed;
- all living people, animals, crops and trees are Joe-faced if shown;
- no contradiction, SKIP, crack, Captain appearance or YOINK occurs;
- Leviticus closes; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — FINAL ACCOUNTS DEPARTMENT`;
- person calculator: `AGE / SEX / SHEKELS / CAN'T PAY? ASK PRIEST`;
- exchange warning: `NO SWAPS — SWAP DETECTED — NOW YOU OWN ZERO NORMAL ANIMALS`;
- universal redemption fee: `VALUE + 20% HOLY RESTOCKING CHARGE`;
- field calculator: `BARLEY CAPACITY x JUBILEE YEARS REMAINING`;
- property return scheduler: `NOT YOUR ROOT FIELD — SEND IT BACK AT 50`;
- duplicate dedication detector: `FIRSTBORN ALREADY UPLOADED`;
- permanent flag: `DEVOTED / NO SELL / NO UNDO`;
- livestock selector: `EVERY 10TH JOE-FACED ANIMAL`;
- unit standard: `1 SANCTUARY SHEKEL = 20 GERAH.EXE`;
- barcode: `CHB-LEV27-34-FIFTH-NOSWAP-BOOK-CLOSED-HELD`.

## FIR verification

- all 34 verse markers are represented in order;
- all rules and classifications remain direct LORD-to-Moses source attribution;
- person valuation categories are retained without an invented human-worth conclusion;
- the poverty exception retains its ability-to-pay selector;
- animal, house, field, firstborn and tithe branches remain separately typed;
- Jubilee timing and possession/purchased-field ownership differences remain intact;
- every add-one-fifth rule is attached only to its stated redemption branch;
- every prohibited exchange and its stated consequence remain prospective;
- the devoted-person death rule remains explicit without an invented actor, authority, process or occurrence;
- narrator command attribution is distinguished from rule execution;
- every living thing uses Joe face if shown;
- no contradiction, SKIP, crack, Captain or YOINK is added;
- publication remains held and unpublished.

Continuation required: Numbers 1 begins the wilderness census and service assignment.
