# CRACKHEAD LEVITICUS 15

## Title page

**BED. SEAT. SADDLE. SPIT. TOUCH. WASH UNTIL EVENING.**

**CLAY? BREAK IT. WOOD? RINSE IT. BODY RESET? COUNT SEVEN.**

Source parent: Leviticus chapter 15, verses 1–33, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-015/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/014-ONE-BIRD-DIES-ONE-FLIES-SHAVE-TWICE-EMPTY-HOUSE-FIRST.md`.

CrackFlix routing: none. The chapter defines prospective condition/contact
routes and does not narrate a person performing one.

## Causal foundation

```text
LORD SPEAKS TO MOSES + AARON

MAN'S BODY DISCHARGE RUNNING OR STOPPED
-> PERSON UNCLEAN
-> BED / SEAT / SADDLE UNCLEAN
-> TOUCH BED / SIT ON SEAT / TOUCH BODY / RECEIVE SPIT
   -> WASH CLOTHES + BATHE + UNCLEAN UNTIL EVENING
-> TOUCH SADDLE OBJECT -> UNCLEAN UNTIL EVENING
-> CARRY SADDLE OBJECT -> WASH + BATHE + EVENING
-> UNRINSED HAND TOUCH -> WASH + BATHE + EVENING
-> TOUCHED CLAY VESSEL BREAKS / WOOD VESSEL RINSES
-> DISCHARGE CLEANSED -> COUNT 7 + WASH + RUNNING-WATER BATHE
-> DAY 8 TWO BIRDS -> SIN + BURNT -> ATTRIBUTED ATONEMENT

SEMEN EMISSION
-> BODY BATHE + UNCLEAN UNTIL EVENING
-> GARMENT / SKIN WASH + EVENING
-> MAN + WOMAN WITH EMISSION -> BOTH BATHE + EVENING

WOMAN'S PERIOD BLOOD
-> IMPURITY 7 DAYS
-> TOUCH PERSON -> UNCLEAN UNTIL EVENING
-> BED / SEAT UNCLEAN
-> TOUCH BED/SEAT -> WASH + BATHE + EVENING
-> CONTACT WITH BED/SEAT OBJECT -> EVENING
-> MAN LIES WITH HER + FLOW ON HIM -> UNCLEAN 7 DAYS
-> HIS BEDS UNCLEAN

WOMAN'S BLOOD DISCHARGE OUTSIDE/BEYOND PERIOD
-> UNCLEAN FOR ALL DISCHARGE DAYS
-> BED / SEAT ROUTES AS PERIOD
-> TOUCH -> WASH + BATHE + EVENING
-> CLEANSED -> COUNT 7 -> CLEAN
-> DAY 8 TWO BIRDS -> SIN + BURNT -> ATTRIBUTED ATONEMENT

SEPARATE ISRAEL FROM UNCLEANNESS
-> SOURCE-STATED DEATH/DEFILEMENT WARNING AROUND TABERNACLE
```

## Leviticus 15:1–3 — RUNNING OR STOPPED, THE SOURCE RETAINS THE CONDITION

The LORD speaks directly to Moses and Aaron and orders them to address Israel.
A man with a bodily discharge is called unclean because of it. The source says
the condition applies whether his body runs with the discharge or has stopped
from it.

The wording defines a prospective State. No man, body, discharge, duration,
cause, symptom beyond the source phrase or medical diagnosis is supplied.

## Leviticus 15:4–7 — BED, SEAT AND BODY CONTACT ALL ROUTE THROUGH WATER

Every bed the man lies on and everything he sits on becomes unclean. A person
who touches the bed, sits on one of his prior seats or touches his body must wash
clothes, bathe in water and remain unclean until evening.

Touching, sitting and body contact are distinct inputs with the same stated
output package. The repetition does not merge the acts.

## Leviticus 15:8 — SPIT MAKES THE CLEAN RECIPIENT RUN THE SAME WASH JOB

If the man with the discharge spits on a clean person, the recipient washes
clothes, bathes and remains unclean until evening. No spit, recipient, intent,
distance, confrontation or reaction occurs in the chapter.

## Leviticus 15:9–12 — SADDLE TOUCH, CARRY, UNRINSED HANDS, CLAY AND WOOD

Whatever saddle the man rides on becomes unclean. Touching something that was
under him makes the toucher unclean until evening. Carrying those things adds
clothes washing and bathing before the evening boundary.

If the man touches someone without first rinsing his hands, that person washes
clothes, bathes and remains unclean until evening.

An earthen vessel he touches is broken. A wooden vessel is rinsed. Clay and wood
are separate material branches, not inconsistent handling of one object.

## Leviticus 15:13–15 — DISCHARGE ENDS, THEN SEVEN DAYS, THEN TWO BIRDS

When the man is cleansed of the discharge, he counts seven days, washes clothes
and bathes his flesh in running water. The source then calls him clean.

On day eight he brings two turtledoves or two young pigeons to the Tent door and
gives them to the priest. One becomes a sin offering and one a burnt offering.
The source attributes atonement to the priestly act.

## Leviticus 15:16–18 — SEMEN HAS A ONE-EVENING ROUTE

A man with an emission of semen bathes all his flesh and remains unclean until
evening. Every garment and skin bearing semen is washed and remains unclean
until evening.

If a man lies with a woman and an emission occurs, both bathe and remain unclean
until evening. No actual emission, intercourse, consent State, relationship,
pregnancy, privacy setting or emotional meaning is narrated.

## Leviticus 15:19–23 — PERIOD CONTACT PROPAGATES THROUGH BED AND SEAT

A woman's blood discharge during her period carries a seven-day impurity State.
Whoever touches her is unclean until evening. Her bed and every seat become
unclean.

Touching her bed or seat requires clothes washing, bathing and uncleanness until
evening. Touching something on the bed or seat retains the evening endpoint.
The source gives contact outputs, not motives or performed occurrences.

## Leviticus 15:24 — FLOW CONTACT DURING INTERCOURSE EXTENDS TO SEVEN DAYS

If a man lies with her and her monthly flow is on him, he is unclean seven days
and every bed he lies on becomes unclean. This is a separately stated selector
from ordinary touch and therefore has a different duration without contradiction.

## Leviticus 15:25–30 — OUTSIDE OR BEYOND THE PERIOD GETS ITS OWN RESET CLOCK

A blood discharge for many days outside the period, or beyond its usual time,
makes the woman unclean for every discharge day. Her bed and seat follow the
period-contact rules; touching them requires clothes washing, bathing and
uncleanness until evening.

When she is cleansed of the discharge, she counts seven days and is then clean.
On day eight she brings two turtledoves or two young pigeons to the priest at the
Tent door. One becomes a sin offering and the other a burnt offering. Atonement
remains a source-attributed effect.

## Leviticus 15:31–33 — THE TABERNACLE WARNING AND THE FOUR-ROUTE INDEX

The LORD orders Israel separated from uncleanness so they do not die in it when
defiling the Tabernacle among them. Death, defilement and their causal relation
remain direct divine warning claims; no death or Tabernacle contact occurs.

The narrator indexes the law for a man with discharge, a man with semen
emission, a woman in her period, a man or woman with another discharge, and a
man who lies with a woman who is unclean.

## Character and world-ledger changes

- LORD directly gives Moses and Aaron the discharge/contact law;
- running and stopped male discharge remain inside one source condition;
- bed, seat, body, spit, saddle, carry and unrinsed-hand paths remain distinct;
- clay breaks while wood rinses;
- cleansed male discharge routes through seven days, running-water bath and day-eight birds;
- semen emission body/material/intercourse routes retain an evening endpoint;
- period person/bed/seat routes and seven-day flow-contact route remain distinct;
- extended female discharge persists for its duration then uses seven-day reset and day-eight birds;
- male and female two-bird routes each split into sin and burnt offerings;
- death/Tabernacle-defilement relation remains direct divine warning;
- no actual discharge, touch, spit, ride, carry, sex, wash, offering or death occurs;
- all prospective living men, women, priests and birds are Joe-faced;
- no contradiction, SKIP, crack or Captain appearance occurs;
- publication remains held; Canaan entry, Nadab/Abihu burial, cloud departure and Joseph burial remain open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — BODY OUTPUT CONTACT NETWORK`;
- male discharge bus: `BED / SEAT / BODY / SPIT / SADDLE`;
- contact result: `WASH CLOTHES / BATHE / WAIT FOR EVENING`;
- hands interlock: `RINSE BEFORE TOUCHING OTHER JOES`;
- vessel support: `CLAY DELETE / WOOD REBOOT`;
- reset: `OUTPUT STOPPED / COUNT 7 / RUNNING WATER`;
- bird checkout: `DAY 8 / SIN BIRD + BURNT BIRD`;
- semen route: `BODY + FABRIC + BOTH PEOPLE / EVENING`;
- period route: `PERSON / BED / SEAT / SEVEN-DAY SOURCE CLOCK`;
- extended route: `ALL DAYS + COUNT 7 + BIRD CHECKOUT`;
- Tabernacle warning: `DO NOT DIE IN YOUR OWN OUTPUT`;
- barcode: `CHB-LEV15-33-BED-SEAT-SPIT-SADDLE-CLAYBREAK-WOODRINSE-HELD`.

## FIR verification

- all 33 verse markers are represented in order;
- direct LORD speech to Moses and Aaron remains God-only speech;
- all conditions remain prospective; no person or contact event is invented;
- running/stopped discharge language remains exact without medical interpretation;
- bed, seat, body, spit, saddle-touch, carry and unrinsed-hand routes remain distinct;
- clay breaking and wood rinsing retain their material selectors;
- male discharge cleansing uses seven days, running water and day-eight two birds;
- semen body, garment/skin and intercourse routes remain distinct;
- period touch, bed, seat and flow-on-man routes retain their exact durations;
- extended female discharge and post-cleansing seven-day/day-eight route remain complete;
- sin and burnt bird roles remain separated;
- death/Tabernacle-defilement warning remains attributed without invented mechanism;
- no motive, consent State, shame, disease identity, contagion model or treatment advice is imported;
- every prospective living person, animal and source organism uses Joe face if shown;
- no contradiction, SKIP, crack or Captain is added;
- publication remains held and unpublished.

Continuation required: Leviticus 16 returns to Nadab and Abihu's deaths and
establishes Aaron's inner-sanctuary, two-goat, incense-cloud, blood-sprinkle and
annual atonement-day procedure.
