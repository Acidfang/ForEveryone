# CRACKHEAD LEVITICUS 6

## Title page

**GIVE IT BACK. ADD A FIFTH. BRING THE RAM.**

**KEEP THE FIRE ON. CHANGE CLOTHES TO MOVE THE ASH.**

Source parent: Leviticus chapter 6, verses 1–30, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-006/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/005-HEARD-TOUCHED-SWORE-CANT-AFFORD-THE-LAMB.md`.

CrackFlix routing: none. No completed observable contradiction occurs.

## Causal foundation

```text
FALSE DEALING WITH NEIGHBOR
-> DEPOSIT / BARGAIN / ROBBERY / OPPRESSION / FOUND PROPERTY / FALSE OATH
-> GUILTY
-> RESTORE EXACT PROPERTY IN FULL + ADD 1/5 TO OWNER THAT DAY
-> DEFECT-FREE VALUED RAM TO PRIEST
-> PRIEST MAKES ATONEMENT
-> FORGIVENESS STATED

BURNT OFFERING ON HEARTH ALL NIGHT
-> ALTAR FIRE KEPT BURNING
-> LINEN GARMENTS FOR ASH REMOVAL BESIDE ALTAR
-> OTHER GARMENTS FOR ASH CARRY OUTSIDE CAMP
-> WOOD + BURNT OFFERING + PEACE FAT EACH MORNING
-> FIRE CONTINUAL / NOT OUT

ORDINARY MEAL OFFERING
-> MEMORIAL HANDFUL/OIL/ALL FRANKINCENSE BURNED
-> AARON + SONS EAT UNLEAVENED REMAINDER IN TENT COURT

ANOINTED PRIEST'S OWN MEAL OFFERING
-> 1/10 EPHAH / HALF MORNING + HALF EVENING / OIL + GRIDDLE
-> WHOLE THING BURNED / NOT EATEN

SIN OFFERING
-> KILLED AT BURNT-OFFERING PLACE
-> OFFERING PRIEST / PRIEST MALES EAT IN HOLY COURT
-> BLOOD ON GARMENT WASHED / EARTHEN POT BROKEN / BRONZE POT SCOURED
-> IF BLOOD ENTERS TENT FOR HOLY-PLACE ATONEMENT: DO NOT EAT / BURN
-> ALL CASES AND PROCEDURES REMAIN PROSPECTIVE
```

## Leviticus 6:1–7 — NEIGHBOR ACCOUNT: ORIGINAL PLUS TWENTY PERCENT PLUS RAM

The LORD tells Moses that false dealing with a neighbor is also classified as a
trespass against the LORD. The rule addresses a deposit, a bargain, robbery,
oppression, found property lied about, or anything supported by a false oath.

When the person has sinned and is guilty, he restores the exact stolen,
oppressed, deposited, found or falsely sworn-about thing in full. He adds a
fifth and returns it to its owner on the day he is found guilty.

He also brings the priest a defect-free ram of the required valuation as a
trespass offering. The priest makes atonement before the LORD and forgiveness
is stated concerning whatever act produced the guilt.

Returning the neighbor's property and bringing the LORD's offering are additive
requirements. No neighbor, property, lie, guilty finding, return or offering is
recorded as occurring.

## Leviticus 6:8–13 — FIRE DOES NIGHT SHIFT AND DAY SHIFT

The LORD tells Moses to command Aaron and his sons concerning the burnt
offering. It stays on the altar hearth all night until morning, with altar fire
kept burning.

The priest puts on his linen garment and linen trousers, removes the ashes left
by the consumed offering and places them beside the altar. He then removes those
garments, puts on other garments and carries the ashes outside camp to a clean
place.

Every morning the priest adds wood, arranges the burnt offering and burns the
peace-offering fat. The fire must remain continually burning and must not go
out. Linen-at-altar and other-clothes-outside are successive location-bound
states, not conflicting uniforms.

## Leviticus 6:14–18 — ORDINARY MEAL OFFERING: BURN SOME, PRIESTS EAT THE REST

Aaron's sons offer the meal offering before the LORD at the altar. One priest
takes a handful of fine flour and oil plus all its frankincense and burns the
memorial portion as pleasant aroma.

Aaron and his sons eat the remainder without yeast in a holy place, specifically
the Tent court. The LORD states that the fire-offering remainder is their
portion, most holy like the sin and trespass offerings. Every male among Aaron's
children may eat it through their generations. Whoever touches the offerings is
stated to become holy.

The food allocation, holiness and aroma are direct divine-rule claims. No meal
offering is brought, burned, touched or eaten.

## Leviticus 6:19–23 — PRIEST'S OWN MEAL OFFERING: BURN ALL, EAT NONE

The LORD specifies Aaron's and his sons' offering on the day of anointing: one-
tenth of an ephah of fine flour, continuing as half in the morning and half in
the evening. It is made with oil on a griddle, soaked, brought in as baked
pieces and offered as pleasant aroma.

The anointed priest who succeeds from among the sons offers it under the
perpetual statute. It is wholly burned to the LORD. Every priest-owned meal
offering is wholly burned and must not be eaten.

This does not contradict verses 14–18. There the priests receive another
offerer's remainder; here the offering belongs to the priest who offers it.

## Leviticus 6:24–30 — SIN OFFERING: EAT HERE UNLESS THE BLOOD WENT IN THERE

The LORD tells Moses to give Aaron and his sons the sin-offering law. It is
killed before the LORD where the burnt offering is killed and is called most
holy. The priest who offers it for sin eats it in a holy place in the Tent
court. Every male among the priests may eat it.

Whatever touches its flesh is stated to become holy. If its blood is sprinkled
on a garment, the marked part is washed in a holy place. An earthen boiling
vessel is broken. A bronze vessel is scoured and rinsed with water.

A sin offering whose blood is carried into the Tent to make atonement in the
Holy Place must not be eaten; it is burned with fire. Blood staying outside and
blood entering the Tent select different disposal branches. No offering,
contact, stain, vessel treatment, eating or burning occurs in the chapter.

## Character and world-ledger changes

- neighbor trespass gains six explicit property/dealing inputs;
- owner-facing restitution requires original property plus one-fifth that day;
- LORD-facing route additionally requires a valued defect-free ram;
- continual altar fire gains night hearth and morning maintenance schedule;
- priest ash work gains linen-at-altar then other-clothes-outside sequence;
- ordinary meal offering retains memorial burn and Aaronic male remainder meal;
- Tent court becomes the explicit holy eating place;
- priest's own anointing meal splits one-tenth ephah morning/evening and burns all;
- successor anointed priest inherits the same offering obligation;
- sin-offering garment and earthen/bronze vessel handling become explicit;
- sin-offering eating depends on whether blood enters the Tent;
- guilt, atonement, forgiveness, holiness and aroma remain divine-rule claims;
- all prospective people, animals and living material sources are Joe-faced;
- no contradiction, SKIP, crack or Captain appearance occurs;
- no trespass, repair, fire service, offering, eating or cleaning occurs;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — PROPERTY RETURNS / FIRE NEVER CLOCKS OFF`;
- neighbor input: `DEPOSIT / DEAL / ROB / SQUEEZE / FOUND IT / LIED UNDER OATH`;
- invoice: `GIVE BACK EXACT THING + 20% + RAM`;
- due date: `DAY FOUND GUILTY / NO ACCOUNTS RECEIVABLE EXCUSE`;
- fire status: `NIGHT ON / MORNING WOOD / CONTINUAL ON`;
- ash PPE: `LINEN HERE / CHANGE / OTHER CLOTHES OUT THERE`;
- ordinary meal: `HANDFUL UP / REMAINDER PRIEST LUNCH`;
- priest-owned meal: `HALF AM + HALF PM / ALL FIRE / ZERO LUNCH`;
- sin-offering router: `BLOOD STAYED OUT = EAT / BLOOD WENT IN = BURN`;
- cookware support: `CLAY DELETE / BRONZE SCRUB AND RINSE`;
- result display: `FORGIVEN + HOLY + NICE SMELL — CLAIMED, NO CASE RUN`;
- barcode: `CHB-LEV06-30-PLUS20-FIREON-CHANGEKIT-BLOODROUTER-NOCRACK-HELD`.

## FIR verification

- all 30 verse markers are represented in order;
- all six neighbor-dealing inputs remain represented without invented cases;
- full restitution, added fifth, owner timing and ram remain simultaneous duties;
- atonement and forgiveness remain stated rather than observed;
- night hearth, morning maintenance and continual-fire rules remain connected;
- linen and other-garment states retain their distinct locations and order;
- ash beside altar and clean place outside camp remain separate destinations;
- ordinary meal memorial/remainder and priest-owned whole-burn remain distinct;
- one-tenth ephah, morning/evening halves, oil/griddle/pieces are retained;
- successor-priest continuity and no-eating rule are retained;
- sin-offering killing/eating place and eligible priests remain represented;
- garment, earthen vessel and bronze vessel responses remain exact;
- inside-Tent blood route selects burn/no-eat without altering outside route;
- holiness, aroma, atonement and forgiveness remain divine-rule outcomes;
- instructions do not become performed crimes, offerings, meals or effects;
- no unsupported contradiction is manufactured, so Captain does not appear;
- every prospective living person, animal and source organism uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Leviticus 7 completes trespass, peace-offering eating,
fat/blood, priest portions and offering-summary rules.
