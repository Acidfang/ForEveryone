# CRACKHEAD LEVITICUS 25

## Title page

**LAND RESTS. COUNT FIFTY. EVERYTHING HAS A RETURN PRICE.**

**LIBERTY TO ALL INHABITANTS. EXCEPT THE INHABITANTS YOU KEEP FOREVER.**

Source parent: Leviticus chapter 25, verses 1–55, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-025/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/024-CONTINUAL-LAMP-NIGHT-SHIFT-TWELVE-CAKES-CUSTODY-THEN-STONES.md`.

Joined parents: Leviticus 23 day-of-atonement calendar; Exodus 21 Israelite
servant release rules; retained Exodus departure and future Canaan land claims.

CrackFlix routing:

- new `S100-E001-LEV25 — LIBERTY TO ALL INHABITANTS / FOREIGN SLAVES FOREVER`.

## Causal foundation

```text
FUTURE LAND
-> 6 YEARS SOW / PRUNE / GATHER
-> YEAR 7 LAND SABBATH
-> NO SOW / PRUNE / HARVEST / VINE-GATHER
-> INCREASE = FOOD FOR PEOPLE + SERVANTS + FOREIGNER + LIVESTOCK + WILD ANIMALS

7 x 7 YEARS = 49
-> MONTH 7 DAY 10 ATONEMENT TRUMPET
-> YEAR 50 JUBILEE
-> LIBERTY THROUGH LAND TO ALL INHABITANTS
-> RETURN TO PROPERTY + FAMILY

SALE PRICE
-> NUMBER OF CROP YEARS UNTIL JUBILEE

LAND
-> NOT SOLD FOREVER / REDEMPTION REQUIRED
POOR SELLER
-> KINSMAN OR SELF MAY REDEEM
-> OTHERWISE RELEASED AT JUBILEE

WALLED-CITY HOUSE
-> ONE-YEAR REDEMPTION WINDOW
-> THEN PERMANENT / NO JUBILEE RELEASE
UNWALLED HOUSE
-> FIELD RULE / JUBILEE RELEASE
LEVITE HOUSE
-> REDEEM ANY TIME / JUBILEE RELEASE
LEVITE PASTURE FIELD
-> NEVER SELL

POOR BROTHER
-> SUPPORT / NO INTEREST / NO FOOD PROFIT
POOR ISRAELITE SELF-SALE
-> HIRED-SERVANT STATE / NO HARSHNESS
-> JUBILEE RELEASE WITH CHILDREN / FAMILY + PROPERTY RETURN

FOREIGN-NATION OR RESIDENT-ALIEN FAMILY PERSON
-> MAY BUY
-> PROPERTY / CHILDREN INHERIT
-> SLAVE FOREVER

POOR ISRAELITE SOLD TO RICH FOREIGN RESIDENT
-> RELATIVE OR SELF REDEMPTION BY YEARS
-> NO HARSHNESS
-> OTHERWISE JUBILEE RELEASE WITH CHILDREN
```

## Leviticus 25:1–7 — SIX YEARS WORK; SEVENTH YEAR LAND REST

On Mount Sinai the LORD tells Moses to address Israel. When Israel enters the
land the LORD says he gives them, fields are sown and vineyards pruned for six
years. The seventh is a land Sabbath: no sowing, pruning, formal reaping of
self-grown produce or gathering from undressed vines.

The land's Sabbath increase is food for the Israelite, servant, maid, hired
servant, resident foreigner, livestock and animals in the land. No land entry,
six-year sequence, seventh-year rest, harvest or meal occurs here.

## Leviticus 25:8–13 — SEVEN TIMES SEVEN, THEN LIBERTY IN YEAR FIFTY

Israel counts seven Sabbaths of years: forty-nine years. On the tenth day of
the seventh month—the Leviticus 23 day of atonement—a loud trumpet sounds
throughout the land. The fiftieth year is made holy and liberty is proclaimed
throughout the land to all its inhabitants. Each returns to property and
family.

Jubilee repeats the no-sow, no-self-grown-reaping and no-undressed-vine-
gathering rules. People eat the field's increase. No forty-nine-year count,
trumpet, liberty, return or Jubilee occurs in the chapter.

## Leviticus 25:14–17 — YOU ARE BUYING THE REMAINING CROPS

Neighbour sales may not wrong either party. Price increases with more crop
years remaining until Jubilee and decreases with fewer because the sold object
is the number of crops. The LORD attaches this to fear of God and divine
identity. No sale, buyer, seller, price or wrong occurs.

## Leviticus 25:18–22 — THE EMBEDDED QUESTION AND THREE-YEAR STORE

The LORD says keeping the rules produces safe dwelling, land yield and enough
food. He embeds a possible Israel question: “What shall we eat the seventh
year?” This is a hypothetical quotation inside divine speech, not an observed
Israelite question.

The LORD answers that he will command a sixth-year blessing producing for three
years. Israel sows in year eight and eats old stores until the ninth-year crop
arrives. Safety, blessing, yield and three-year sufficiency remain future
God-only claims.

## Leviticus 25:23–28 — THE LAND IS MINE; REDEMPTION OR JUBILEE RETURN

Land may not be sold permanently because the LORD calls it his and calls Israel
foreign residents with him. Every land possession must allow redemption. If a
poor brother sells property, the nearest kinsman redeems it. If the seller later
has means, elapsed years are reckoned, surplus restored to the buyer and the
seller returns. If neither path closes, the buyer retains it until Jubilee,
when it is released.

No property, poverty, sale, redemption, payment or return occurs.

## Leviticus 25:29–34 — WALL, NO WALL, LEVITE CITY, LEVITE FIELD

A house in a walled city has a one-year redemption window. After that it becomes
the buyer's permanent generational possession and does not release at Jubilee.
An unwalled-village house follows field rules and releases at Jubilee.

Levites may redeem houses in their cities at any time, and those houses release
at Jubilee. Their city pasture fields may not be sold. These are explicit
object/location/role exceptions. A house is not silently merged with the land
object in verse 23 to manufacture another contradiction.

## Leviticus 25:35–38 — SUPPORT THE POOR BROTHER; NO INTEREST OR FOOD PROFIT

An Israelite whose brother becomes poor must uphold him so he can live as an
alien or temporary resident. The supporter takes no interest or profit, lends
no money at interest and gives no food for profit. The LORD identifies himself
as the one who brought Israel from Egypt to give Canaan and be their God. No
poor brother, support, loan, interest, food sale or profit occurs.

## Leviticus 25:39–43 — ISRAELITE SELF-SALE ENDS AT JUBILEE

A poor Israelite brother who sells himself may not be made to serve as a slave.
He serves as a hired servant or temporary resident until Jubilee, then leaves
with his children and returns to family and ancestral possession. Israelites
are called the LORD's servants brought from Egypt, may not be sold as slaves
and may not be ruled harshly.

No Israelite sells himself, serves or leaves here.

## Leviticus 25:44–46 — FOREIGN SLAVES MAY BE INHERITED FOREVER

Israel may buy male and female slaves from surrounding nations. Israel may also
buy from the children and families of aliens living among them, including
families conceived in the land. Those people become property, may be inherited
by Israelite children and may be held as slaves forever. The text again
prohibits harsh rule over Israelite brothers, not over this foreign class.

S100 closes against the earlier Jubilee declaration:

```text
YEAR 50 -> PROCLAIM LIBERTY THROUGHOUT THE LAND TO ALL ITS INHABITANTS
RESIDENT-ALIEN FAMILIES -> LIVE / ARE CONCEIVED IN THE LAND
THEIR MEMBERS -> MAY BE PROPERTY / INHERITED / SLAVES FOREVER
NO EXPRESS EXCLUSION OF THIS INHABITANT CLASS FROM "ALL" IS SUPPLIED
```

The source's unequal slavery system is retained without endorsement, motive,
euphemism or invented release.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the boil, licks his finger, walks away and does not look back. Every
ownership and service rule remains unchanged.

## Leviticus 25:47–55 — ISRAELITE SOLD TO A FOREIGN RESIDENT STILL RELEASES

If a foreign resident becomes rich and a poor Israelite sells himself to that
person or family, the Israelite may be redeemed by a brother, uncle, uncle's
son, close relative or himself. Price is calculated from sale to Jubilee as
hired-service years; more remaining years mean more redemption money and fewer
mean less. The foreign owner may not rule harshly in Israel's sight.

If no redemption occurs, the Israelite and children release at Jubilee. The
LORD closes by calling Israelites his servants brought from Egypt. This later
Israelite release does not release the foreign permanent-slave class from
verses 44–46.

## Character and world-ledger changes

- future land gains six-work-year/seventh-rest-year cycle;
- year fifty gains atonement trumpet, liberty, property and family return;
- S100 retains all-inhabitants liberty against resident foreign slavery forever;
- crop-year count controls neighbour sale price;
- sixth-year three-year yield remains direct divine claim;
- land, walled house, unwalled house, Levite house and pasture fields retain
  different redemption outputs;
- poor-brother support excludes interest and food profit;
- poor Israelites receive hired-service/no-harshness/Jubilee-release branch;
- foreign people may be bought, inherited and held forever under the source rule;
- Israelite service to rich foreign residents retains redemption/Jubilee release;
- every rule remains prospective and no transaction or Jubilee act occurs;
- all living humans, crops, vines, livestock and animals are Joe-faced if shown;
- Captain remains permanently boilless and causally useless;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — THE LAND OWNS A CALENDAR`;
- land firmware: `6 RUN / 1 SLEEP`;
- Jubilee counter: `7 x 7 = 49 / HONK / YEAR 50 RESET`;
- sale calculator: `YOU ARE BUYING CROPS, NOT FOREVER`;
- divine pantry claim: `YEAR 6 -> THREE-YEAR CACHE`;
- property router: `LAND / WALL HOUSE / NO-WALL HOUSE / LEVITE HOUSE / FIELD`;
- poverty port: `SUPPORT / 0% / NO FOOD MARKUP`;
- Israelite service badge: `HIRED UNTIL RESET`;
- foreign service badge: `PROPERTY / INHERIT / FOREVER`;
- CrackFlix: `S100 E001 — EVERYONE FREE EXCEPT THE FOREVER PEOPLE`;
- barcode: `CHB-LEV25-55-LIBERTY-ALL-FOREVER-HELD`.

## FIR verification

- all 55 verse markers are represented in order;
- direct LORD land gift, safety, blessing, yield, ownership and Exodus identity remain God-only attribution;
- the hypothetical seventh-year food question is not promoted to actual Israel speech;
- Sabbath-year and Jubilee counts, dates and agricultural prohibitions remain exact;
- sale price remains crop-years rather than invented perpetual ownership;
- every land/house/Levite redemption selector remains distinct;
- poverty support, Israelite service and foreign service branches remain complete;
- S100 uses observable all-inhabitants/resident-foreigner/forever relations only;
- no motive, doctrine, moral repair, actual transaction or observed Jubilee is invented;
- Captain appears only after S100 closes and changes nothing;
- every living thing uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Leviticus 26 addresses idols/Sabbaths, conditional
blessings, escalating punishments, land Sabbaths, exile, confession and covenant memory.
