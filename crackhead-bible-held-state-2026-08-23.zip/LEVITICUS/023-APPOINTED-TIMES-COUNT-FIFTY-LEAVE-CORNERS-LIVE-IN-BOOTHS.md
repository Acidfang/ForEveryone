# CRACKHEAD LEVITICUS 23

## Title page

**APPOINTED TIMES. COUNT FIFTY. LEAVE THE CORNERS.**

**TENTH DAY: DO NOTHING. FIFTEENTH DAY: LIVE IN BOOTHS.**

Source parent: Leviticus chapter 23, verses 1–44, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-023/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/022-WASH-WAIT-SUNDOWN-HOUSEHOLD-FOOD-DAY-EIGHT-MOTHER-YOUNG.md`.

Joined parents: Exodus 12–13 Passover and unleavened-bread history; Exodus 23
and 34 feast rules; Leviticus 16 annual atonement procedure; Leviticus 19
harvest-corner and gleaning rule.

CrackFlix routing: none. Repeated rules retain their prior occurrences and gain
this calendar address. Moses declares the appointed feasts to Israel. No feast,
harvest, offering, trumpet blast, self-denial, destruction or booth dwelling is
performed in this chapter.

## Causal foundation

```text
EVERY SEVENTH DAY
-> SABBATH / HOLY CONVOCATION / NO WORK

MONTH 1 DAY 14 EVENING
-> PASSOVER
MONTH 1 DAY 15 -> SEVEN DAYS
-> UNLEAVENED BREAD / FIRE OFFERINGS
-> DAY 1 + DAY 7: HOLY CONVOCATION / NO REGULAR WORK

FUTURE LAND + HARVEST
-> FIRST SHEAF TO PRIEST
-> DAY AFTER SABBATH: WAVE SHEAF + LAMB + FLOUR/OIL + WINE
-> NO BREAD / ROASTED GRAIN / FRESH GRAIN BEFORE OFFERING

WAVE-SHEAF DAY + SEVEN COMPLETE SABBATHS + NEXT DAY
-> COUNT 50
-> TWO YEASTED LOAVES + ANIMAL/OFFERING PACKAGE
-> HOLY CONVOCATION / NO REGULAR WORK

HARVEST
-> LEAVE FIELD CORNERS + GLEANINGS FOR POOR + FOREIGNER

MONTH 7 DAY 1
-> TRUMPET MEMORIAL / REST / HOLY CONVOCATION

MONTH 7 DAY 9 EVENING -> NEXT EVENING
-> DAY 10 ATONEMENT SABBATH
-> SELF-DENIAL / NO WORK / OFFERING
-> REFUSAL: CUT OFF
-> WORK: LORD SAYS HE WILL DESTROY PERSON

MONTH 7 DAY 15 -> SEVEN DAYS + DAY 8
-> BOOTHS / BRANCHES / REJOICING / OFFERINGS
-> DAY 1 + DAY 8: REST / HOLY CONVOCATION

MOSES -> DECLARES APPOINTED FEASTS TO ISRAEL
```

## Leviticus 23:1–3 — THE WEEKLY SABBATH

The LORD tells Moses to proclaim the appointed feasts as holy convocations.
Six days are available for work; the seventh is a Sabbath of solemn rest and a
holy convocation in every dwelling, with no work. No calendar day, gathering or
rest occurrence is narrated here.

## Leviticus 23:4–8 — PASSOVER AND UNLEAVENED BREAD

The LORD's Passover is the evening of the fourteenth day of the first month.
The feast of unleavened bread begins on the fifteenth and lasts seven days.
Days one and seven are holy convocations with no regular work; fire offerings
run through all seven days.

This calendar retains the performed Exodus 12 Passover and the later rules in
Exodus 13, 23 and 34 as parents. It does not repeat those events or prove a new
observance.

## Leviticus 23:9–14 — FIRST SHEAF BEFORE FIRST BITE

When Israel enters the land the LORD says he gives them and reaps its harvest,
the first sheaf goes to the priest. On the day after the Sabbath the priest
waves it for attributed acceptance. That day also requires a one-year-old male
lamb without defect, two tenths of an ephah of fine flour mixed with oil and a
quarter hin of wine. Bread, roasted grain and fresh grain may not be eaten
before the offering is brought.

The future land entry, harvest, offering and acceptance are not performed.

## Leviticus 23:15–21 — SEVEN SABBATHS, THEN DAY FIFTY

From the day after the Sabbath when the wave sheaf is brought, Israel counts
seven complete Sabbaths. The next day is day fifty. The new meal offering uses
two loaves from the dwellings, each made from two tenths of an ephah of fine
flour and baked with yeast as firstfruits.

With the bread come seven one-year-old lambs without defect, one young bull and
two rams as burnt offerings with meal and drink offerings; one male goat as a
sin offering; and two one-year-old male lambs as peace offerings. The priest
waves the bread and two lambs. That day is proclaimed a holy convocation with
no regular work. No counting, baking, animal selection, waving or offering
occurs here.

## Leviticus 23:22 — THE FEAST CALENDAR STILL LEAVES THE CORNERS

When the land is harvested, the field corners and gleanings are left for the
poor and foreigner. This repeats and retains the Leviticus 19 harvest rule at
the feast-calendar boundary. Repetition is not a contradiction and does not
need SKIP because no explanation is being omitted.

## Leviticus 23:23–25 — SEVENTH MONTH, DAY ONE: TRUMPETS

The first day of the seventh month is a solemn rest, a trumpet-blowing
memorial and holy convocation. There is no regular work and a fire offering is
required. No trumpet is blown and no gathering or offering occurs.

## Leviticus 23:26–32 — THE ANNUAL ATONEMENT PROCEDURE GETS ITS DATE

The tenth day of the seventh month is the day of atonement: a holy convocation,
self-denial, fire offering and complete work prohibition. The Sabbath runs from
evening on the ninth day to the next evening.

This supplies the date absent from Leviticus 16's annual atonement procedure.
It does not rerun Aaron's recorded Leviticus 16 compliance or invent any hidden
subact. The LORD says a person who does not deny himself is cut off and that he
will destroy a person who works that day. Those effects remain prospective
God-only claims; no person violates the rule or receives either outcome.

## Leviticus 23:33–38 — BOOTHS: SEVEN DAYS, THEN DAY EIGHT

The feast of booths begins on the fifteenth day of the seventh month and lasts
seven days. Day one is a holy convocation with no regular work. Fire offerings
continue for seven days. Day eight is another holy convocation, fire offering,
solemn assembly and no-regular-work day.

These appointed offerings are in addition to Sabbaths, gifts, vows and
freewill offerings. Separate obligations accumulate; none replaces another.

## Leviticus 23:39–43 — BRANCHES, REJOICING AND TEMPORARY SHELTERS

After gathering the land's produce, Israel keeps seven feast days, with solemn
rest on days one and eight. On day one they take fruit of majestic trees, palm
branches, boughs of thick trees and brook willows, and rejoice before the LORD
for seven days.

Native-born Israelites dwell in temporary shelters for seven days so later
generations may know the LORD's stated history: he made Israel dwell in
temporary shelters when bringing them out of Egypt. The historical cause and
divine identity remain direct LORD speech. No branches are gathered and no
booth is built or occupied here.

## Leviticus 23:44 — MOSES DECLARES THE CALENDAR

The narrator records Moses declaring the LORD's appointed feasts to Israel.
That declaration is the chapter's performed occurrence. It proves delivery of
the calendar at the source boundary, not performance of any scheduled feast.

## Character and world-ledger changes

- weekly Sabbath and appointed-feast calendars remain distinct and cumulative;
- Passover/unleavened-bread rules retain Exodus parents without duplicating events;
- future land entry gates the first-sheaf harvest procedure;
- exact flour, oil, wine, bread and animal quantities remain retained;
- the fifty-day count begins from the wave-sheaf address;
- Leviticus 19 field-corner and gleaning protection is retained unchanged;
- Leviticus 16's annual atonement procedure now gains its exact calendar date;
- cut-off and divine-destruction outcomes remain unperformed God-only claims;
- booths retain branch, rejoicing, native-born and Exodus-memory selectors;
- Moses' declaration to Israel is performed;
- no scheduled feast or penalty event is performed;
- all living people, plants and animals are Joe-faced if shown;
- no contradiction, SKIP, crack, Captain appearance or YOINK occurs;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — GOD'S SHARED CALENDAR INVITE`;
- weekly slot: `6 DO / 1 DON'T`;
- Passover alarm: `M1-D14-EVENING`;
- bread mode: `M1-D15 + 7 / YEAST OFF`;
- grain interlock: `WAVE BEFORE BITE`;
- count engine: `7x7 + 1 = LOAVES WITH YEAST`;
- harvest footer: `CORNERS ARE NOT YOURS`;
- trumpet alert: `M7-D1 — HONK AND STOP`;
- atonement lockout: `M7-D9 PM -> D10 PM / DO NOTHING`;
- booth booking: `M7-D15 / BRANCH HOTEL / CHECK OUT DAY 8`;
- barcode: `CHB-LEV23-44-CALENDAR-COUNT50-CORNERS-BOOTHS-HELD`.

## FIR verification

- all 44 verse markers are represented in order;
- direct LORD speech, calendar ownership, acceptance, atonement, cut-off,
  destruction and Exodus-booth history remain God-only attribution;
- weekly Sabbath, Passover, unleavened bread, first sheaf, fifty-day feast,
  trumpet day, atonement day and booths retain exact selectors;
- all stated measures, counts, dates, animal classes and work restrictions remain;
- the Leviticus 16 annual procedure gains a date without invented rerun;
- the Leviticus 19 harvest rule is retained as a repeated parent, not a new act;
- cumulative offerings are not treated as replacements;
- Moses' declaration is distinguished from feast performance;
- no violation, punishment, harvest, offering, trumpet or booth event is invented;
- every living thing uses Joe face if shown;
- no contradiction, SKIP, crack, Captain or YOINK is added;
- publication remains held and unpublished.

Continuation required: Leviticus 24 addresses continual lamp oil, weekly bread,
a narrated blasphemy case, custody, divine judgment and public stoning.
