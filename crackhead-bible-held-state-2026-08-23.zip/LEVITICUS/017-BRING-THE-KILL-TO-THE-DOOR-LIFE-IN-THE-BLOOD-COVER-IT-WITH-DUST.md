# CRACKHEAD LEVITICUS 17

## Title page

**KILL IT IN CAMP? OUT OF CAMP? BRING IT TO THE DOOR.**

**THE LIFE IS IN THE BLOOD. DON'T EAT IT. COVER IT WITH DUST.**

Source parent: Leviticus chapter 17, verses 1–16, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-017/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/016-NOT-ANY-TIME-CLOUD-TWO-GOATS-ONE-GOES-AWAY.md`.

CrackFlix routing: none. The chapter gives prospective slaughter, offering,
blood, hunting and carcass rules. No person performs a triggering act.

## Causal foundation

```text
LORD -> MOSES -> AARON + SONS + ALL ISRAEL

ISRAEL MAN KILLS BULL / LAMB / GOAT IN OR OUTSIDE CAMP
-> MUST BRING IT TO TENT DOOR AS OFFERING
-> DOES NOT BRING IT
   -> BLOOD IMPUTED / SHED BLOOD / CUT OFF (DIRECT SOURCE CLAIMS)
-> BRINGS OPEN-FIELD SACRIFICE TO PRIEST
   -> PEACE OFFERING
   -> PRIEST SPRINKLES BLOOD + BURNS FAT

LORD: NO MORE SACRIFICES TO GOAT IDOLS
-> SOURCE ATTRIBUTES PRIOR/ONGOING PROSTITUTION-LIKE FOLLOWING

ISRAELITE OR FOREIGN RESIDENT OFFERS BURNT OFFERING / SACRIFICE
-> DOES NOT BRING TO TENT DOOR
-> CUT OFF (DIRECT SOURCE CLAIM)

ISRAELITE OR FOREIGN RESIDENT EATS BLOOD
-> LORD SETS FACE AGAINST + CUTS OFF (DIRECT SOURCE CLAIM)
-> LORD: LIFE OF FLESH IS IN BLOOD
-> LORD: BLOOD GIVEN ON ALTAR FOR ATONEMENT
-> NO PERSON MAY EAT BLOOD

HUNTER TAKES EDIBLE ANIMAL OR BIRD
-> POUR OUT BLOOD
-> COVER WITH DUST

NATIVE OR FOREIGNER EATS SELF-DEAD OR ANIMAL-TORN CARCASS
-> WASH CLOTHES + BATHE + UNCLEAN UNTIL EVENING -> CLEAN
-> DOES NOT WASH/BATHE -> BEARS INIQUITY (DIRECT SOURCE CLAIM)
```

## Leviticus 17:1–2 — THE COMMAND ADDRESS

The LORD speaks to Moses and orders him to speak to Aaron, Aaron's sons and all
Israel. The following lines remain direct divine rules relayed through Moses.

## Leviticus 17:3–4 — IN CAMP OR OUT, THE DOOR IS THE SELECTOR

If an Israelite kills a bull, lamb or goat inside or outside camp but does not
bring it to the Tent door as an offering, the source imputes blood to him,
states that he shed blood and says he will be cut off from his people.

This is a prospective conditional. No animal is killed, no offering is withheld
and no person is cut off in the chapter.

## Leviticus 17:5–7 — OPEN-FIELD SACRIFICES MOVE TO THE PRIEST

The stated end is that Israel brings its open-field sacrifices to the LORD at
the Tent door and gives them to the priest as peace offerings. The priest
sprinkles blood on the altar and burns fat for a pleasant aroma.

The LORD says they shall no longer sacrifice to goat idols after which they
play the prostitute. That earlier/repeated conduct and its characterization
remain direct divine attribution; the chapter does not independently show an
Israelite doing it.

## Leviticus 17:8–9 — THE FOREIGN RESIDENT GETS THE SAME DOOR

An Israelite or foreign resident who offers a burnt offering or sacrifice but
does not bring it to the Tent door is to be cut off. The participant category
widens; the required location does not change.

## Leviticus 17:10–12 — LIFE IN BLOOD, BLOOD ON ALTAR, NOT IN MOUTH

The LORD says he will set his face against and cut off any Israelite or foreign
resident who eats blood. He states that the life of flesh is in the blood, that
he gave blood on the altar to make atonement for souls, and that blood makes
atonement by reason of the life.

These life, gift, atonement and enforcement relations are direct God-only
claims. They are not imported as Crackhead Science mechanisms and are not
presented as an independently measured model.

## Leviticus 17:13–14 — HUNT IT, POUR IT, DUST IT

When an Israelite or foreign resident hunts an edible animal or bird, the
hunter pours out its blood and covers it with dust. The LORD repeats that the
life of all flesh is its blood and that anyone eating it is cut off.

No hunt, animal death, blood pouring, dust covering or eating occurs here.

## Leviticus 17:15–16 — SELF-DEAD OR TORN: WASH, BATHE, EVENING

A native or foreign resident who eats an animal that died by itself or was torn
by animals washes clothes, bathes and remains unclean until evening, after
which the source calls the person clean. If the person does not wash clothes or
bathe, the source says the person bears iniquity.

The wash route and failure branch are explicit alternatives, not inconsistent
outcomes for the same completed State.

## Character and world-ledger changes

- Moses relays the direct LORD command to Aaron, his sons and all Israel;
- bull/lamb/goat slaughter inside and outside camp share the Tent-door route;
- open-field sacrifices are redirected to priestly peace offerings;
- goat-idol sacrifice/prostitution language remains direct divine attribution;
- Israelites and foreign residents share offering and blood prohibitions;
- life-in-blood and blood-for-atonement remain God-only claims;
- hunting creates pour-blood-and-cover-with-dust obligations;
- self-dead/torn eating creates wash/bathe/evening and non-wash branches;
- no actual kill, sacrifice, blood eating, hunt, wash or enforcement occurs;
- all prospective living people, animals, birds and source organisms are Joe-faced;
- no contradiction, SKIP, crack or Captain appearance occurs;
- publication remains held; Leviticus 16 exact performance date, Nadab/Abihu burial, cloud departure and Joseph burial remain open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — BLOOD ROUTING SUPPORT`;
- slaughter input: `IN CAMP / OUT OF CAMP / SAME BLOODY DOOR`;
- sacrifice router: `FIELD JOB -> TENT DOOR -> PRIEST`;
- goat-idol warning: `NO MORE SIDE-GOAT CHECKOUTS`;
- blood label: `LIFE CARRIER / NOT A BEVERAGE`;
- altar label: `LIFE PACKET / ATONEMENT PORT`;
- hunting patch: `POUR / DUST / DONE`;
- carcass reset: `WASH CLOTHES / BATHE / WAIT UNTIL EVENING`;
- barcode: `CHB-LEV17-16-DOOR-BLOOD-LIFE-DUST-WASH-HELD`.

## FIR verification

- all 16 verse markers are represented in order;
- all direct LORD speech and source effects remain God-only attribution;
- slaughter inside/outside camp and Tent-door requirement remain linked;
- bull, lamb and goat categories remain explicit;
- open-field, priest, peace-offering, blood and fat actions remain ordered;
- goat-idol/prostitution wording is attributed and not independently amplified;
- Israelite and foreign-resident branches remain present;
- life-in-blood and atonement statements are not converted into outside physics;
- hunting, blood pouring and dust covering remain prospective;
- self-dead/torn carcass, wash/bathe/evening and non-wash branches remain complete;
- no occurrence, motive, mechanism or contradiction is invented;
- every living thing uses Joe face if shown;
- no SKIP, crack, Captain or YOINK is added;
- publication remains held and unpublished.

Continuation required: Leviticus 18 addresses kinship, household and national
sexual prohibitions, attributed land defilement and cut-off consequences.
