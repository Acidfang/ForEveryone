# CRACKHEAD LEVITICUS 24

## Title page

**CONTINUAL LAMP. EVENING-TO-MORNING SHIFT. SKIP.**

**TWELVE CAKES. ONE FIGHT. CUSTODY. THEN STONES.**

Source parent: Leviticus chapter 24, verses 1–23, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-024/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/023-APPOINTED-TIMES-COUNT-FIFTY-LEAVE-CORNERS-LIVE-IN-BOOTHS.md`.

Joined parents: Exodus 25 table/lampstand specification; Exodus 27 continual
lamp/evening-to-morning rule; Exodus 40 installed table, bread, lampstand and
lit lamps; Exodus 21 injury and restitution rules.

CrackFlix routing:

- repeated `S087-E002-LEV24 — CONTINUAL LAMP / EVENING-TO-MORNING SHIFT`;
- `SKIP -> S087-E001-EXO27` omits the already retained explanation, changes
  nothing and does not remove the new occurrence.

## Causal foundation

```text
ISRAEL -> PURE BEATEN OLIVE OIL
-> LAMP BURNS CONTINUALLY
AARON -> ORDERS LAMPS EVENING TO MORNING CONTINUALLY
-> S087-E002

FINE FLOUR
-> 12 CAKES / 2 TENTHS EPHAH EACH
-> 2 ROWS OF 6 + FRANKINCENSE
-> REORDER EVERY SABBATH
-> AARON + SONS EAT IN HOLY PLACE

ISRAELITE-WOMAN'S SON + ISRAELITE MAN
-> FIGHT IN CAMP
ISRAELITE-WOMAN'S SON
-> BLASPHEMES THE NAME + CURSES
-> BROUGHT TO MOSES
-> CUSTODY UNTIL LORD'S WILL DECLARED

LORD -> MOSES
-> CURSER OUTSIDE CAMP
-> HEARERS' HANDS ON HEAD
-> CONGREGATION STONES HIM
-> GENERAL CURSING / KILLING / INJURY / RESTITUTION LAW

MOSES -> ISRAEL
ISRAEL -> MAN OUTSIDE CAMP -> STONES HIM
-> MAN DIES
```

## Leviticus 24:1–4 — SAME CONTINUAL LAMP, SAME NIGHT SHIFT

The LORD tells Moses to command Israel to bring pure beaten olive oil so a lamp
burns continually. Aaron must order it outside the Testimony veil from evening
to morning continually and keep the pure-gold lampstand's lamps in order.

Exodus 40 already records the lampstand installed and its lamps lit. This
chapter supplies a renewed maintenance command, not a narrated oil delivery or
tending shift.

The exact S087 relation appears again:

```text
REQUIRED LAMP STATE -> BURN CONTINUALLY
ASSIGNED MAINTENANCE WINDOW -> EVENING TO MORNING
NO DAYTIME TENDING, EXTINCTION/RELIGHTING RULE OR EXPRESS BRIDGE
```

`SKIP -> S087-E001-EXO27 / 24/7 NIGHT-SHIFT LIGHTING`

Captain's eyes glaze. The words and world continue.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes a boil, licks his finger, walks away and does not look back. The lamp
rule remains unchanged.

## Leviticus 24:5–9 — TWELVE CAKES, TWO ROWS, EVERY SABBATH

Fine flour becomes twelve cakes, each containing two tenths of an ephah. They
sit on the pure-gold table in two rows of six. Pure frankincense goes on each
row as the bread's memorial and fire offering. Every Sabbath the bread is set
in order continually on Israel's behalf. Aaron and his sons eat it in a holy
place as a most-holy perpetual allocation.

Exodus 25 required bread before the LORD continually, and Exodus 40 records
bread placed on the installed table. Leviticus 24 supplies the recipe, layout,
weekly replacement and eater allocation. It does not narrate a new baking,
placement, frankincense use, replacement or meal.

## Leviticus 24:10–12 — FIGHT, BLASPHEMY, MOSES, CUSTODY

The son of an Israelite woman and Egyptian father goes among Israel and fights
an Israelite man in the camp. The son blasphemes the Name and curses. People
bring him to Moses and place him in custody until the LORD's will is declared.

His mother is Shelomith, daughter of Dibri, of Dan. The son and Israelite man
remain unnamed. The exact fight acts, words, trigger, injuries, witnesses,
father's identity and motive are not supplied. Parentage is retained as source
identity, not explanation.

## Leviticus 24:13–16 — THE LORD DECLARES DEATH BY STONING

The LORD tells Moses to take the curser outside the camp. Everyone who heard
him is to lay hands on his head, and the congregation is to stone him. The
general rule says a person who curses his God bears his sin, and a person who
blasphemes the LORD's name is put to death by congregational stoning. The rule
applies to foreigner and native-born.

The judgment and penalty are direct God-only speech. The source does not supply
a quoted blasphemy, defense, further hearing, vote, appeal or alternative.

## Leviticus 24:17–22 — PERSON, ANIMAL, INJURY AND ONE LAW

The LORD's speech continues:

- one who mortally strikes a person is put to death;
- one who mortally strikes an animal makes it good, life for life;
- injury to a neighbour routes to fracture for fracture, eye for eye and tooth
  for tooth;
- killing an animal routes to restitution;
- killing a person routes to death;
- one law applies to foreigner and native-born.

These general rules join Exodus 21 as retained law parents. No separate person
or animal killing, injury, fracture, eye injury, tooth injury or restitution
occurs in this section. The rules do not prove an injury inside the earlier
fight.

## Leviticus 24:23 — COMMAND DELIVERED; MAN STONED

Moses speaks to Israel. They bring the man who cursed outside the camp and
stone him with stones. The narrator says Israel did as the LORD commanded
Moses. The man changes from living to dead.

Collective compliance closes the source's command boundary. It does not name
individual hearers, hand-layers or stone throwers, enumerate stones, describe
injuries, or supply the exact death mechanism beyond stoning.

Captain does not cause, stop, approve or judge the execution. Removing him
changes nothing.

## Character and world-ledger changes

- S087 gains a second episode at the same continual/night-maintenance relation;
- SKIP points to S087-E001 and has no causal effect;
- the installed Exodus 40 lamp/table system gains renewed maintenance rules;
- twelve-cake recipe, two-row layout, frankincense and weekly priest allocation enter State;
- Shelomith, Dibri and Dan lineage are retained exactly;
- Shelomith's unnamed son and the unnamed Israelite man fight;
- the son blasphemes/curses, is brought to Moses and held in custody;
- divine judgment supplies witnesses/congregation/death and general law;
- Moses delivers the judgment and Israel performs the stoning;
- Shelomith's son changes from living to dead;
- no motive, quoted curse, injury, trial detail or individual executor is invented;
- every living person, olive tree and animal is Joe-faced if shown;
- Captain remains permanently boilless and causally useless;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — NIGHT LIGHT / BREAD RACK / PUBLIC ROCKS`;
- CrackFlix: `S087 E002 — THE NIGHT SHIFT IS STILL CONTINUAL`;
- pointer: `SKIP -> S087-E001-EXO27`;
- lamp dashboard: `CONTINUALLY / STAFFED PM-AM`;
- bakery card: `12 x 0.2 EPHAH / 2 ROWS x 6`;
- weekly deploy: `SABBATH BREAD HOTSWAP`;
- incident ticket: `FIGHT -> NAME CURSED -> HOLD FOR ROOT RESPONSE`;
- judgment route: `OUTSIDE / HANDS / STONES`;
- injury table: `PERSON DEATH / ANIMAL RESTORE / BODY MATCH`;
- equality switch: `FOREIGNER = NATIVE-BORN`;
- barcode: `CHB-LEV24-23-S087E002-CUSTODY-STONES-HELD`.

## FIR verification

- all 23 verse markers are represented in order;
- lamp, oil, location, maintenance window and continual wording remain exact;
- S087-E002 reuses the validated root rather than creating a duplicate series;
- SKIP points to the exact prior explanation and changes nothing;
- Captain's action occurs only after the repeated contradiction is complete;
- bread count, measure, rows, frankincense, Sabbath timing and priest allocation remain exact;
- fight, blasphemy, custody, divine ruling, Moses delivery and stoning remain sequential;
- mother/grandfather/tribe and Egyptian-father relation remain exact;
- no parentage motive, quoted curse, injury, trial or individual executor is invented;
- general person/animal/injury rules are not misreported as additional occurrences;
- the man's death is explicit and not softened into a prospective rule;
- every living thing uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Leviticus 25 addresses Sabbath years, Jubilee, land
sale/redemption, poverty support, servant release and resident-foreigner service.
