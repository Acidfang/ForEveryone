# CRACKHEAD LEVITICUS 12

## Title page

**BOY ROUTE: SEVEN PLUS THIRTY-THREE.**

**GIRL ROUTE: FOURTEEN PLUS SIXTY-SIX. NO LAMB? TWO BIRDS.**

Source parent: Leviticus chapter 12, verses 1–8, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-012/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/011-SPLIT-HOOF-CUD-FINS-SCALES-HOPPING-LEGS-DRY-SEED-STILL-CLEAN.md`.

CrackFlix routing: none. No birth or rule-triggering occurrence is narrated, and
the different branches are stated by the rule itself.

## Causal foundation

```text
LORD SPEAKS TO MOSES
-> MOSES ADDRESSES ISRAEL

IF WOMAN CONCEIVES + BEARS MALE CHILD
-> UNCLEAN SEVEN DAYS
-> CHILD FORESKIN CIRCUMCISED ON DAY EIGHT
-> MOTHER CONTINUES PURIFICATION BLOOD THIRTY-THREE DAYS
-> NO HOLY-THING TOUCH / NO SANCTUARY ENTRY UNTIL COMPLETE

IF WOMAN BEARS FEMALE CHILD
-> UNCLEAN TWO WEEKS
-> CONTINUES PURIFICATION BLOOD SIXTY-SIX DAYS

WHEN PURIFICATION DAYS COMPLETE FOR SON OR DAUGHTER
-> BRING ONE-YEAR LAMB FOR BURNT OFFERING
-> BRING YOUNG PIGEON OR TURTLEDOVE FOR SIN OFFERING
-> PRIEST OFFERS / MAKES ATTRIBUTED ATONEMENT
-> SOURCE STATES CLEANSING FROM BLOOD FLOW

IF SHE CANNOT AFFORD LAMB
-> TWO TURTLEDOVES OR TWO YOUNG PIGEONS
-> ONE BURNT + ONE SIN
-> PRIEST MAKES ATTRIBUTED ATONEMENT
-> SOURCE STATES SHE IS CLEAN
```

## Leviticus 12:1–2 — THE RULE STARTS IF A WOMAN CONCEIVES AND BEARS

The LORD speaks directly to Moses and tells him to speak to Israel. If a woman
conceives and bears a male child, she is unclean for seven days, compared in the
source to the days of her monthly period.

This is a prospective condition. No woman, conception, birth, date, body State
or actual period occurrence is identified in the chapter.

## Leviticus 12:3 — DAY EIGHT HAS ONE ADDRESSED ACT

On the eighth day, the flesh of the male child's foreskin is to be circumcised.
The source states the required day and body address. It does not name the child,
operator, tool, setting, method, reaction, healing process or completed act.

If a living mother, child, operator, animal or bird is shown, each has Joe's
face. Distinct people remain distinct Joes despite the shared face.

## Leviticus 12:4 — THIRTY-THREE MORE DAYS, WITH TWO ACCESS RULES

After the seven-day male-child interval, the mother continues in the blood of
purification for thirty-three days. During that period she may not touch a holy
thing or enter the sanctuary. Both restrictions last until the purification
days are completed.

The chapter supplies the interval and prohibited acts, but does not narrate a
touch attempt, entry attempt, enforcement act or completed purification.

## Leviticus 12:5 — THE FEMALE-CHILD BRANCH HAS ITS OWN NUMBERS

If she bears a female child, she is unclean for two weeks as in her period and
continues in the blood of purification for sixty-six days.

The male-child and female-child routes have visibly different stated durations.
That difference is the rule's own branch structure, not an actor saying one
duration and applying another to the same occurrence. With no actual birth,
claim/act mismatch or retrospectively denied interaction, no contradiction
completes.

## Leviticus 12:6–7 — WHEN THE CLOCK ENDS, LAMB PLUS BIRD GO TO THE PRIEST

When the purification days for either a son or daughter are completed, the
mother is to bring a one-year-old lamb for a burnt offering and either a young
pigeon or turtledove for a sin offering to the priest at the Tent door.

The priest is to offer it before the LORD and make atonement for her. The source
then states that she is cleansed from the fountain of her blood. Atonement and
cleansing remain source-attributed effects. No priest action, animal arrival,
offering or observed effect occurs in this chapter.

The source then calls this the law for one who bears a male or female child.

## Leviticus 12:8 — CAN'T AFFORD THE LAMB? THE INPUT PACKAGE CHANGES

If she cannot afford a lamb, she is to take two turtledoves or two young
pigeons: one for a burnt offering and one for a sin offering. The priest makes
atonement for her, and the source states she is clean.

The affordability branch replaces the lamb-plus-one-bird package with a
two-bird package. It is supplied before any occurrence and does not contradict
the primary route. The source does not define the affordability measurement,
who evaluates it, which bird pair is selected or whether anyone uses the branch.

## Character and world-ledger changes

- LORD directly gives Moses the prospective birth/purification law;
- Israel remains the addressed recipient through Moses;
- a male-child birth route states seven days plus thirty-three days;
- male-child foreskin circumcision is required on day eight;
- a female-child birth route states fourteen days plus sixty-six days;
- holy-thing touch and sanctuary entry are restricted until completion;
- the standard post-period package is one-year lamb plus pigeon or turtledove;
- inability to afford a lamb activates a two-bird package;
- burnt and sin offering roles remain distinct in both packages;
- priestly atonement and maternal cleansing remain attributed effects;
- no actual conception, birth, circumcision, waiting, access attempt, offering or cleansing occurs;
- all prospective living mothers, children, priests, lambs and birds are Joe-faced;
- no contradiction, SKIP, crack or Captain appearance occurs;
- publication remains held; Nadab/Abihu burial, cloud departure and Joseph burial remain open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — POST-BIRTH ACCESS TIMER`;
- male timer: `7 DIRTY + DAY 8 CUT + 33 PURIFY`;
- female timer: `14 DIRTY + 66 PURIFY`;
- sanctuary UI: `HOLY TOUCH LOCKED / ENTRY LOCKED / WAIT UNTIL COMPLETE`;
- standard checkout: `LAMB BURNT + BIRD SIN`;
- budget detector: `CAN'T AFFORD LAMB`;
- budget checkout: `BIRD BURNT + BIRD SIN`;
- effect driver: `ATONEMENT/CLEAN — SOURCE CLAIM / SENSOR NOT INCLUDED`;
- Joe maternity ward sign: `EVERY BABY HAS THE SAME FACE / IDENTITY STILL SEPARATE`;
- barcode: `CHB-LEV12-08-7-33-14-66-BIRDBUDGET-NOCRACK-HELD`.

## FIR verification

- all eight verse markers are represented in order;
- direct LORD speech remains God-only speech addressed through Moses;
- prospective conditions are not rewritten as actual births or performed acts;
- male seven-day, day-eight and thirty-three-day addresses remain distinct;
- female two-week and sixty-six-day addresses remain exact;
- differing sex-linked durations remain explicit branches, not invented contradiction;
- holy-thing touch and sanctuary-entry restrictions remain separate;
- standard lamb-plus-bird package and affordability two-bird package remain distinct;
- burnt versus sin offering roles remain exact;
- priest, Tent-door, atonement and cleansing relations remain attributed;
- affordability measurement and branch use remain unresolved;
- no mother, child, priest, operator or offering animal is invented as an occurrence;
- every prospective living person, animal and source organism uses Joe face if shown;
- no contradiction, SKIP, crack or Captain is added;
- publication remains held and unpublished.

Continuation required: Leviticus 13 establishes priest-inspected skin, hair,
burn, boil, head, beard, baldness, isolation and garment-plague state machines.
