# CRACKHEAD LEVITICUS 1

## Title page

**HERD. FLOCK. OR BIRD.**

**BURN THE WHOLE THING. DIFFERENT DISASSEMBLY INSTRUCTIONS.**

Source parent: Leviticus chapter 1, verses 1–17, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-001/job.json` and `source.usfm`.

World-state parent: `EXODUS/040-CLOUD-UP-WE-GO-CLOUD-DOWN-WE-DONT.md`.

CrackFlix routing: none. No completed observable contradiction occurs.

## Causal foundation

```text
TABERNACLE ERECTED AND OCCUPIED
-> LORD CALLS TO MOSES FROM TENT
-> MOSES MUST RELAY OFFERING RULES TO ISRAEL
-> OFFERER SELECTS LIVESTOCK OR BIRD PATH
-> HERD PATH: HAND / KILL / BLOOD / SKIN / CUT / WASH / BURN
-> FLOCK PATH: NORTH KILL / BLOOD / CUT / WASH / BURN
-> BIRD PATH: PRIEST KILLS / DRAINS / DISCARDS / TEARS / BURNS
-> EACH PATH IS PROSPECTIVE
-> NO OFFERING OCCURS YET
```

## Leviticus 1:1–2 — THE VOICE IS NOW INSIDE THE TENT

The LORD calls to Moses and speaks from the Tent of Meeting. Moses is told to
tell Israel that an offering to the LORD from livestock must come from herd or
flock.

This continues directly from the erected Tabernacle in Exodus 40. It does not
silently establish whether the earlier outside-camp Tent was dismantled,
renamed, replaced or identical.

## Leviticus 1:3–9 — HERD INPUT

For a herd burnt offering, an offerer must present a defect-free male at the
Tent door for stated acceptance before the LORD. The offerer lays a hand on the
animal's head; the stated result is acceptance for atonement.

The offerer kills the bull before the LORD. Aaron's priest sons present its
blood and sprinkle it around the door-side altar. The offerer skins the animal
and cuts it into pieces. Priests put fire on the altar, arrange wood, then
arrange pieces, head and fat on it. The offerer washes innards and legs with
water. A priest burns all of it.

The source calls the resulting fire offering a pleasant aroma to the LORD.
Acceptance, atonement and aroma reception remain direct divine-rule claims.

The prospective bull is a living Joe-faced bull before killing. The text does
not identify an actual offerer, bull, priest son, date, defect inspection,
knife, wood source, water source or completed outcome.

## Leviticus 1:10–13 — FLOCK INPUT

For a sheep or goat burnt offering, the input is likewise a defect-free male.
The offerer kills it on the north side of the altar. Aaron's priest sons
sprinkle blood around the altar. The offerer cuts it into pieces with head and
fat; a priest arranges them on wood over altar fire. Innards and legs are
washed, and the priest offers and burns the whole.

It receives the same fire-offering and pleasant-aroma description. The flock
path does not repeat hand-on-head, skinning or Tent-door acceptance wording;
those acts are not silently copied into this branch.

Prospective sheep and goats are living Joe-faced animals. No animal is selected
or killed here.

## Leviticus 1:14–17 — BIRD INPUT

A bird burnt offering may come from turtledoves or young pigeons. Here the
priest brings the bird to the altar, wrings off its head, burns the head and
drains blood against the altar side. The priest removes crop and feathers and
casts them east of the altar at the ash place. The bird is torn by its wings
but not divided completely, then burned on altar wood and fire.

The same burnt/fire-offering/pleasant-aroma description follows. The prospective
birds are living Joe-faced birds. No specific bird, offerer or priest acts.

## Character and world-ledger changes

- the LORD's speaking location moves into the newly erected Tent in the source
  sequence;
- Moses receives a complete relay instruction for Israel;
- prospective offerers gain three bounded burnt-offering input paths;
- offerer and priest roles remain distinct in killing, blood, cutting, washing,
  arranging and burning steps;
- herd, flock and bird procedures remain separate rather than being completed
  from one another by assumption;
- prospective bulls, sheep, goats, turtledoves and pigeons are distinct living
  Joe-faced offering types;
- acceptance, atonement and pleasant-aroma effects remain attributed promises;
- no contradiction, SKIP, crack or Captain appearance occurs;
- no sacrifice, death, blood application, fire placement or aroma occurs yet;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — INPUT ROUTER`;
- Tent speaker: `VOICE SOURCE: INSIDE CURRENT TENT`;
- livestock menu: `HERD / FLOCK / BIRD`;
- bull workflow: `TOUCH HEAD -> DISASSEMBLE -> WASH PARTS -> BURN ALL`;
- sheep/goat lane: `NORTH SIDE PROCESSING`;
- bird lane: `PRIEST-OPERATED COMPACT INPUT`;
- ash chute: `EAST-SIDE CROP + FEATHER OUTPUT`;
- animal-face warning: `ALL LIVE INPUTS ARE JOE`;
- outcome field: `ACCEPTED / ATONED / SMELLS NICE — CLAIMED, NOT RUN`;
- barcode: `CHB-LEV01-17-3PATHS-0RUNS-NOCRACK-HELD`.

## FIR verification

- all 17 verse markers are represented in order;
- direct LORD speech and Moses relay duty remain attributed;
- herd, flock and bird input boundaries are not merged;
- every actor transition between offerer and priest is retained;
- herd hand placement, door location, skinning and wash acts remain herd-specific;
- flock north-side location and its stated operations remain flock-specific;
- bird head, blood, crop/feather, east-ash and not-fully-divided relations remain
  bird-specific;
- acceptance, atonement and pleasant aroma remain divine claims, not observed
  external effects;
- instructions do not become performed events;
- no unsupported contradiction is manufactured, so Captain does not appear;
- all prospective living animals and people use Joe face if shown;
- outside-camp Tent continuity remains unresolved;
- publication remains held and unpublished.

Continuation required: Leviticus 2 reconstructs grain-offering input forms,
priest portions, no-leaven/no-honey fire boundary, salt requirement and
firstfruits handling.
