# CRACKHEAD LEVITICUS 22

## Title page

**WASH. WAIT FOR SUNDOWN. THEN EAT.**

**FREEWILL MAY. VOW MAY NOT. DAY EIGHT. NOT MOTHER AND YOUNG SAME DAY.**

Source parent: Leviticus chapter 22, verses 1–33, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-022/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/021-DEAD-CONTACT-EXCEPTIONS-HIGH-PRIEST-NONE-DEFECT-EAT-NOT-APPROACH.md`.

CrackFlix routing: none. The LORD supplies priest-uncleanness, household-food,
offering-animal and timing selectors. No priest becomes unclean, eats, repays,
inspects, offers, gives birth or kills an animal in the narrated chapter.

## Causal foundation

```text
UNCLEAN AARON DESCENDANT + HOLY THINGS
-> SEPARATE / DO NOT APPROACH

LISTED CONTACT OR BODY STATE
-> UNCLEAN UNTIL EVENING
-> BATHE
-> SUN DOWN
-> CLEAN -> MAY EAT HOLY FOOD

HOLY-FOOD HOUSEHOLD GATE
-> STRANGER / LODGER / HIRED SERVANT: NO
-> PURCHASED / HOUSEBORN: YES
-> DAUGHTER MARRIED OUTSIDE: NO
-> WIDOWED OR DIVORCED DAUGHTER + NO CHILD + RETURNED HOME: YES

UNWITTING HOLY-FOOD EATING
-> RESTORE HOLY THING + ONE FIFTH

VOW OR FREEWILL BURNT / PEACE OFFERING
-> REQUIRED ANIMAL CLASS + CONDITION
SPECIFIED DEFORMITY OR LACKING PART
-> FREEWILL: MAY
-> VOW: NOT ACCEPTED

NEWBORN BULL / SHEEP / GOAT
-> SEVEN DAYS WITH MOTHER
-> DAY EIGHT: MAY BE ACCEPTED

COW OR EWE + YOUNG
-> NOT KILLED SAME DAY

THANKSGIVING SACRIFICE
-> EAT SAME DAY
-> NONE LEFT UNTIL MORNING
```

## Leviticus 22:1–3 — SEPARATE FROM HOLY THINGS WHILE UNCLEAN

The LORD tells Moses to address Aaron and his sons. They are to separate
themselves from Israel's holy things so they do not profane the holy name. An
Aaronic descendant who approaches holy things while unclean is to be cut off
from before the LORD. Profanation, holiness and cutting off remain direct
divine claims. No descendant approaches anything here.

## Leviticus 22:4–9 — WASH, WAIT FOR SUNDOWN, THEN EAT

An Aaronic descendant carrying the source-labelled leprosy or discharge may
not eat holy things until clean. The same gate follows contact with a thing
made unclean by a dead body, a man with a seminal emission, an unclean creeping
thing or an unclean person. The person remains unclean until evening, bathes in
water, and after sundown may eat holy things as his bread.

The priest may not eat an animal that died by itself or was torn by animals.
The LORD says priests must keep the command lest they bear sin and die through
profanation, and identifies himself as their sanctifier. No condition, contact,
bathing, meal, sin, death or sanctification effect is performed.

## Leviticus 22:10–13 — WHO MAY EAT FROM THE PRIEST'S HOUSE

A stranger, a priest's foreign lodger and a hired servant may not eat a holy
thing. A person purchased by the priest and one born in his house may eat. A
priest's daughter married to an outsider may not eat the heave offering. A
widowed or divorced priest's daughter who has no child and returns to her
father's house may eat her father's bread as in youth. No stranger may eat it.

The source's slavery, household, marriage and descent statuses are retained
exactly as eligibility selectors. They are not erased, endorsed, generalized
or repaired by invented events.

## Leviticus 22:14–16 — ACCIDENTAL EATING: RETURN IT PLUS A FIFTH

Someone who eats a holy thing unwittingly must restore the holy thing and add
one fifth for the priest. Priests must not profane Israel's holy things or
cause the people to bear the guilt of eating them. The LORD again identifies
himself as sanctifier. No accidental meal, repayment or guilt occurrence is
narrated.

## Leviticus 22:17–21 — OFFERING-ANIMAL BASELINE

The LORD tells Moses to address Aaron, his sons and all Israel. An Israelite or
foreigner presenting a vow or freewill burnt offering uses a male without
defect from cattle, sheep or goats. A defective animal is not accepted. A
peace offering for vow or freewill must likewise be perfect and without defect.

Acceptance remains God's attributed output. No animal is selected, examined,
presented, rejected or killed.

## Leviticus 22:22–25 — DEFECT LIST; FREEWILL EXCEPTION; VOW DENIAL

Blind, injured, maimed, wart-bearing, festering or running-sore animals may not
be placed on the altar. A bull or lamb with a deformity or lacking parts may be
used for a freewill offering but is not accepted for a vow. Animals with
bruised, crushed, broken or cut testicles are excluded, including animals
received from a foreigner's hand.

The freewill and vow outputs differ because the offering selector differs.
That is an explicit branch, not a contradiction. The source's corruption,
defect and acceptance classifications remain attributed without a modern
diagnosis or claim about animal worth.

## Leviticus 22:26–28 — SEVEN DAYS, DAY EIGHT, NOT BOTH SAME DAY

A newborn bull, sheep or goat remains with its mother for seven days. From the
eighth day it may be accepted as a fire offering. A cow or ewe and its young
may not both be killed on the same day. No birth, separation, acceptance or
killing happens in this chapter.

## Leviticus 22:29–30 — THANKSGIVING: FINISH IT TODAY

A thanksgiving sacrifice is to be offered for acceptance, eaten on the same
day and not left until morning. No thanksgiving offering or meal occurs.

## Leviticus 22:31–33 — KEEP, DO, DO NOT PROFANE

Israel is told to keep and do the commandments and not profane the holy name.
The LORD states that he will be made holy among Israel, identifies himself as
the one who makes Israel holy, and says he brought them out of Egypt to be
their God. These identity, Exodus and sanctification relations remain direct
divine claims.

## Character and world-ledger changes

- priest uncleanness, washing, sundown and holy-food gates remain prospective;
- all listed contact and body-state inputs remain distinct;
- household food eligibility retains stranger, lodger, servant, purchased,
  houseborn, married-daughter and returned-daughter branches;
- slavery and unequal household statuses remain visible source relations;
- unwitting consumption routes to restoration plus one fifth;
- burnt and peace offering animal requirements remain exact;
- freewill and vow selectors produce different explicit outputs;
- animal-condition labels do not alter Joe identity, worth or boil genetics;
- newborn day-eight and mother/young same-day rules remain prospective;
- thanksgiving food must be consumed the same day;
- no triggering contact, meal, repayment, inspection, offering, birth or death occurs;
- all living people and animals are Joe-faced if shown;
- no contradiction, SKIP, crack, Captain appearance or YOINK occurs;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — HOLY FOOD AND LIVESTOCK I/O`;
- contamination clock: `WASH -> SUNSET -> SNACK`;
- household scanner: `WHO LIVES HERE / WHO OWNS WHO / WHO CAME BACK`;
- accidental-bite invoice: `ORIGINAL + 20%`;
- livestock port: `BULL / SHEEP / GOAT — CHECK INPUT`;
- dual selector: `FREEWILL MAY / VOW WON'T`;
- newborn timer: `SEVEN WITH MUM / DAY EIGHT PORT OPENS`;
- same-day lock: `MOTHER + YOUNG = PICK ANOTHER DAY`;
- leftovers warning: `THANKS TODAY / BIN NOTHING TOMORROW`;
- barcode: `CHB-LEV22-33-WASH-SUNDOWN-FREEWILL-VOW-DAY8-HELD`.

## FIR verification

- all 33 verse markers are represented in order;
- direct LORD speech, acceptance, cut-off, holiness and sanctification remain God-only attribution;
- uncleanness inputs, bathing, evening and sundown sequence remain complete;
- household holy-food eligibility retains every listed status and exception;
- slavery and unequal status are retained without endorsement or invented repair;
- unwitting eating requires the holy thing plus one fifth;
- animal classes, conditions and offering types remain exact;
- the freewill/vow difference is not misclassified as contradiction;
- newborn day-eight, mother-young and thanksgiving timings remain complete;
- no modern medical, biological, moral-worth or animal-culpability inference is imported;
- rules are not converted into performed cases;
- every living thing uses Joe face if shown;
- no contradiction, SKIP, crack, Captain or YOINK is added;
- publication remains held and unpublished.

Continuation required: Leviticus 23 addresses appointed feasts, Sabbath,
Passover, firstfruits, weeks, trumpets, atonement and booths.
