# CRACKHEAD LEVITICUS 20

## Title page

**GAVE A CHILD TO MOLECH? DON'T HIDE YOUR EYES.**

**THE PROHIBITION LIST NOW HAS A PENALTY COLUMN.**

Source parent: Leviticus chapter 20, verses 1–27, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-020/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/019-LEAVE-THE-CORNERS-PAY-BEFORE-MORNING-JUST-WEIGHTS-LOVE-THE-FOREIGNER.md`.

Earlier rule parents: Leviticus 18–19.

CrackFlix routing: none. The chapter supplies prospective enforcement branches
for previously prohibited inputs. It narrates no offence or punishment.

## Causal foundation

```text
LORD -> MOSES -> ISRAEL

ISRAELITE OR FOREIGN RESIDENT GIVES OFFSPRING TO MOLECH
-> PEOPLE OF LAND STONE PERSON
-> LORD SETS FACE AGAINST / CUTS OFF
-> SOURCE: SANCTUARY DEFILED + HOLY NAME PROFANED

PEOPLE HIDE EYES + DO NOT PUT PERSON TO DEATH
-> LORD SETS FACE AGAINST MAN + FAMILY
-> CUTS OFF MAN + FOLLOWERS (DIRECT DIVINE CLAIM)

TURN TO MEDIUMS/WIZARDS
-> LORD SETS FACE AGAINST + CUTS OFF

SANCTIFY / BE HOLY / KEEP STATUTES
-> LORD SAYS HE SANCTIFIES

PENALTY ROUTER
-> CURSE FATHER/MOTHER: DEATH
-> ADULTERY: BOTH DEATH
-> FATHER'S WIFE: BOTH DEATH
-> DAUGHTER-IN-LAW: BOTH DEATH
-> MALE WITH MALE: BOTH DEATH
-> WOMAN + HER MOTHER: BURNED
-> MAN + ANIMAL: MAN DEATH + ANIMAL KILLED
-> WOMAN + ANIMAL: WOMAN + ANIMAL DEATH
-> SISTER: CUT OFF + BEAR INIQUITY
-> PERIOD SEX: BOTH CUT OFF
-> MOTHER/FATHER'S SISTER: BEAR INIQUITY
-> UNCLE'S WIFE: BEAR SIN + DIE CHILDLESS
-> BROTHER'S WIFE: CHILDLESS

KEEP STATUTES
-> LAND NOT VOMIT ISRAEL (DIRECT CLAIM)
-> DO NOT COPY CAST-OUT NATION
-> LORD GIVES MILK/HONEY LAND + SEPARATES ISRAEL
-> DISTINGUISH CLEAN/UNCLEAN ANIMAL + FOWL + GROUND CREATURE
-> BE HOLY / SET APART

MEDIUM OR WIZARD
-> STONED / DEATH (SOURCE RULE)
```

## Leviticus 20:1–5 — MOLECH AND THE DON'T-HIDE-YOUR-EYES BRANCH

The LORD tells Moses that an Israelite or foreign resident who gives offspring
to Molech is to be put to death by stoning. The LORD also says he will set his
face against and cut off that person because the act defiles his sanctuary and
profanes his holy name.

If the people hide their eyes and do not carry out the stated death penalty,
the LORD says he will set his face against the man and family and cut off the
man and followers. Offence, public inaction, divine action and consequences are
all prospective. No child, giver, witness, stone, family or death occurs.

## Leviticus 20:6–8 — MEDIUMS, HOLINESS AND SANCTIFICATION

Turning to mediums or wizards routes to the LORD's face-against and cut-off
claims. Israel is ordered to sanctify itself, be holy, keep and perform the
statutes. “I am the LORD who sanctifies you” remains direct divine causation.

## Leviticus 20:9–14 — PARENTS AND SIX HOUSEHOLD/SEXUAL PENALTIES

The prospective penalty list covers cursing father or mother, adultery, a
father's wife, daughter-in-law, male with male, and a woman together with her
mother. The first five listed branches specify death for the addressed people;
the last specifies burning. Source moral labels and “blood upon themselves”
lines remain attributed.

No act, accusation, proof process, operator, fire or death is supplied.

## Leviticus 20:15–16 — PERSON AND ANIMAL PENALTIES

For a man with an animal, the rule says the man dies and the animal is killed.
For a woman approaching an animal, the rule says the woman and animal die.
These are two prospective branches. No animal act, culpability, reaction or
death is narrated.

## Leviticus 20:17–21 — CUT OFF, BEAR INIQUITY, CHILDLESS

The remaining relationship branches cover sister, woman during her period,
mother's or father's sister, uncle's wife and brother's wife. Their stated
outputs differ: cut off, bear iniquity, die childless or be childless. Each
output remains attached to its exact input rather than normalized into one
penalty.

## Leviticus 20:22–24 — LAND WARNING, CAST-OUT NATION, MILK AND HONEY

Israel must keep the statutes so the land does not vomit them out. The LORD
attributes the listed conduct to the nation being cast out and says he abhorred
them. He promises Israel inheritance of a land flowing with milk and honey and
identifies himself as the one separating Israel from the peoples.

All history, feeling, gift, separation and land-effect statements remain direct
God-only claims. No land transfer or vomiting occurs here.

## Leviticus 20:25–27 — CLEAN/UNCLEAN SEPARATION AND FINAL STONING RULE

Israel must distinguish clean and unclean animals and fowl and avoid the animal,
bird and ground-creature categories the LORD says he separated as unclean. The
LORD again orders Israel holy and set apart as his.

The chapter ends with a prospective death-by-stoning rule for a man or woman
who is a medium or wizard. No identified practitioner or enforcement occurs.

## Character and world-ledger changes

- Leviticus 18–19 prohibitions gain exact prospective penalty outputs;
- Molech branch includes public enforcement and a separate hide-eyes branch;
- divine face-against/cut-off/sanctification effects remain God-only claims;
- every verses 9–21 input retains its own death/burning/cut-off/iniquity/childless output;
- person-animal branches retain animal death without invented animal fault;
- land-vomit, national conduct, divine abhorrence, land gift and separation remain attributed;
- clean/unclean animal classification reconnects to Leviticus 11;
- no offence, witness, trial, proof, punishment, death or land effect occurs;
- all prospective living participants and animals are Joe-faced;
- no contradiction, SKIP, crack or Captain appearance occurs;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — PENALTY COLUMN ENABLED`;
- Molech alarm: `DON'T INSERT CHILD / DON'T HIDE EYES`;
- enforcement table: `INPUT EXACTLY / OUTPUT EXACTLY`;
- family router: `DEATH / FIRE / CUT OFF / CHILDLESS — CHECK ROW`;
- animal warning: `ANIMAL ALSO GETS THE SHIT END`;
- land monitor: `MILK + HONEY / VOMIT PORT ARMED`;
- classifier callback: `LEV11 CLEAN/UNCLEAN DRIVER LOADED`;
- barcode: `CHB-LEV20-27-DONT-HIDE-PENALTY-SEPARATION-HELD`.

## FIR verification

- all 27 verse markers are represented in order;
- direct LORD speech, history, feeling, causation and effects remain attributed;
- Molech offence and hide-eyes branches remain separate;
- medium-seeker and medium/wizard practitioner branches remain distinct;
- every verses 9–21 input/output pair remains exact;
- death, burning, cut-off, iniquity and childlessness are not merged;
- no accusation, evidence, trial or enforcement procedure is invented;
- animal deaths remain prospective without invented culpability;
- land-vomit, cast-out nation and milk/honey gift remain source claims;
- Leviticus 11 classification lineage is retained;
- no actual offence, punishment or death is depicted;
- every living thing uses Joe face if shown;
- no contradiction, SKIP, crack, Captain or YOINK is added;
- publication remains held and unpublished.

Continuation required: Leviticus 21 addresses priest contact with the dead,
marriage and body conditions, high-priest restrictions and altar-access rules.
