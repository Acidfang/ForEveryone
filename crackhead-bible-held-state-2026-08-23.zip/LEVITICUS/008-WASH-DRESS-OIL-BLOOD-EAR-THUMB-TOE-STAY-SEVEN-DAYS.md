# CRACKHEAD LEVITICUS 8

## Title page

**WASH THEM. DRESS THEM. OIL EVERYTHING.**

**BLOOD: RIGHT EAR, RIGHT THUMB, RIGHT BIG TOE. STAY HERE SEVEN DAYS.**

Source parent: Leviticus chapter 8, verses 1–36, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-008/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/007-THANKS-EAT-TODAY-VOW-TOMORROW-DAY-THREE-BURN-IT.md`.

CrackFlix routing: none. No completed observable contradiction occurs.

## Causal foundation

```text
LORD COMMANDS MOSES
-> TAKE AARON + SONS + GARMENTS + OIL + SIN BULL + TWO RAMS + BREAD
-> ASSEMBLE ALL CONGREGATION AT TENT DOOR

MOSES DOES / CONGREGATION ASSEMBLES
-> MOSES IDENTIFIES LORD-COMMANDED ACT
-> WASHES AARON + SONS
-> DRESSES AARON / PUTS URIM + THUMMIM IN BREASTPLATE
-> DRESSES SONS

ANOINTING OIL
-> TABERNACLE + CONTENTS ANOINTED
-> ALTAR SPRINKLED SEVEN TIMES
-> ALTAR + VESSELS + BASIN + BASE ANOINTED
-> OIL POURED ON AARON'S HEAD

SIN BULL
-> AARON + SONS HANDS ON HEAD
-> KILLED
-> BLOOD ON ALTAR HORNS + BASE
-> FAT PACKAGE BURNED ON ALTAR
-> BULL / SKIN / MEAT / DUNG BURNED OUTSIDE CAMP

BURNT RAM
-> HANDS ON HEAD -> KILLED -> BLOOD AROUND ALTAR
-> CUT / INNARDS + LEGS WASHED
-> WHOLE RAM BURNED

CONSECRATION RAM
-> HANDS ON HEAD -> KILLED
-> BLOOD ON RIGHT EAR + RIGHT THUMB + RIGHT BIG TOE OF AARON + SONS
-> REMAINING BLOOD AROUND ALTAR
-> FAT PACKAGE + RIGHT THIGH + THREE BREAD ITEMS
-> PUT IN THEIR HANDS / WAVED / TAKEN BACK / BURNED
-> BREAST WAVED / MOSES PORTION
-> OIL + ALTAR BLOOD SPRINKLED ON PEOPLE + GARMENTS

MOSES COMMANDS AARON + SONS
-> BOIL MEAT AT TENT DOOR / EAT MEAT + BREAD THERE
-> BURN LEFTOVERS
-> DO NOT LEAVE TENT DOOR SEVEN DAYS
-> STAY DAY + NIGHT / KEEP COMMAND / DEATH WARNING
-> NARRATOR RECORDS THEY DID ALL COMMANDED THINGS
```

## Leviticus 8:1–5 — BRING THE WHOLE INSTALLATION PACKAGE AND EVERYONE

The LORD tells Moses to take Aaron and his sons, the garments, anointing oil,
the sin-offering bull, two rams and the basket of unleavened bread. He is also
to assemble the entire congregation at the Tent of Meeting door.

Moses does as commanded. The congregation is assembled at the door, and Moses
tells them, “This is the thing which the LORD has commanded to be done.” The
chapter has moved from offering rules to an observed public installation act.

## Leviticus 8:6–9 — WASH, LAYER THE CLOTHES, LOAD THE URIM AND THUMMIM

Moses brings Aaron and his sons and washes them with water. He puts the tunic,
sash, robe, ephod and its woven band on Aaron. He places the breastplate on him
and puts the Urim and Thummim inside it. He sets the turban on Aaron's head and
the golden holy crown on its front.

The Urim and Thummim are now explicitly placed. Their prior unresolved carry is
closed at the placement boundary; their construction, contents and operation
remain absent.

## Leviticus 8:10–13 — OIL THE TENT, SEVEN-SPRAY THE ALTAR, POUR IT ON AARON

Moses anoints the Tabernacle and everything in it. He sprinkles the altar seven
times, then anoints the altar, all its vessels, the basin and its base. He pours
anointing oil on Aaron's head. The narrator attributes sanctification to these
acts.

Moses clothes Aaron's sons in tunics, ties their sashes and puts headbands on
them. The source says this was as the LORD commanded Moses.

Exodus 40 already reports priest washing, dressing and anointing through a
summary completion statement. Leviticus 8 supplies a detailed performance
account. The sources do not establish two incompatible occurrences, so no
contradiction or SKIP is manufactured.

## Leviticus 8:14–17 — SIN BULL: HORNS, BASE, FAT FIRE, REST OUTSIDE

The sin-offering bull is brought. Aaron and his sons lay their hands on its
head, and it is killed. Moses puts blood around the altar horns with his finger,
pours the rest at the altar base, and the source attributes purification,
sanctification and atonement to the procedure.

Moses burns the innard fat, liver cover, two kidneys and their fat on the altar.
The bull's remaining body, skin, meat and dung are burned outside the camp.

## Leviticus 8:18–21 — BURNT RAM: CUT IT, WASH IT, BURN THE WHOLE RAM

The burnt-offering ram is presented. Aaron and his sons lay hands on its head.
It is killed, and Moses sprinkles its blood around the altar. He cuts it into
pieces and burns the head, pieces and fat. The innards and legs are washed with
water, and Moses burns the entire ram.

Pleasant aroma and offering-to-the-LORD status remain source attributions. The
animal, hand placement, killing, washing and burning are performed acts.

## Leviticus 8:22–24 — CONSECRATION BLOOD GOES EAR, THUMB, TOE

The second ram, identified as the consecration ram, is presented. Aaron and his
sons lay their hands on its head, and it is killed.

Moses puts its blood on the tip of Aaron's right ear, the thumb of his right
hand and the great toe of his right foot. He repeats the same three right-side
applications on Aaron's sons. He then sprinkles blood around the altar.

No symbolism, motive or hidden physiological effect is supplied. The observable
route is ear, thumb, toe, then altar.

## Leviticus 8:25–30 — PUT IT IN THEIR HANDS, WAVE IT, TAKE IT BACK, BURN IT

Moses takes the fat, fat tail, innard fat, liver cover, kidneys and their fat,
and right thigh. From the unleavened basket he adds one unleavened cake, one
oiled bread cake and one wafer.

He puts the entire package into Aaron's and his sons' hands and waves it before
the LORD. He then takes it from their hands and burns it on the altar over the
burnt offering. Consecration, pleasant aroma and fire-offering status remain
attributed descriptions.

Moses waves the ram's breast and receives it as his portion. He mixes anointing
oil with blood from the altar and sprinkles it on Aaron, Aaron's garments, his
sons and their garments. The source attributes sanctification to all four
addresses.

## Leviticus 8:31–36 — BOIL DINNER, BURN LEFTOVERS, DO NOT LEAVE FOR A WEEK

Moses tells Aaron and his sons to boil the meat at the Tent door and eat it
there with the consecration bread. Any remaining meat and bread must be burned.
Here “boil” is the cooking verb in the source; it does not establish a
Crackheadverse status boil or contradiction organism.

They must not leave the Tent door for seven days, until their consecration days
are fulfilled. Moses says the acts performed that day follow the LORD's command
to make atonement for them. He orders them to remain there day and night for
seven days and keep the LORD's command so they do not die, adding that he was so
commanded.

The narrator closes by saying Aaron and his sons did all the things the LORD
commanded by Moses. That records compliance with the addressed command Whole.
The text does not separately narrate seven daily departure checks, exact meals,
leftover quantities or a death event, so none is invented.

## Character and world-ledger changes

- all congregation is actually assembled at the Tent door;
- Moses publicly identifies and performs the commanded installation;
- Aaron and sons are actually washed and dressed in this detailed account;
- Aaron receives tunic, sash, robe, ephod, breastplate, Urim/Thummim, turban and crown;
- Urim/Thummim placement closes its prior unresolved carry;
- Tabernacle, contents, altar, vessels, basin and base are actually anointed;
- altar receives seven oil sprinklings;
- Aaron receives oil poured on his head;
- sin bull, burnt ram and consecration ram are actually presented and killed;
- animal bodies, blood, fat, organs and portions follow three distinct routes;
- Aaron and sons receive consecration blood on right ear, thumb and big toe;
- consecration fat/thigh/bread package passes through their hands before altar fire;
- Moses receives the waved breast;
- Aaron, sons and garments receive mixed oil/altar-blood sprinkling;
- Tent-door cooking/eating, leftover burning and seven-day residence are commanded;
- narrator records Aaron and sons did all commanded things;
- atonement, sanctification, holiness and pleasant aroma remain attributed effects;
- Exodus 40 summary and Leviticus 8 detail remain overlapping parent accounts;
- all living people, congregation members, animals and material-source organisms are Joe-faced;
- no contradiction, SKIP, crack or Captain appearance occurs;
- cloud departure and Joseph's burial remain open.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — PRIEST INSTALLER COMPLETE EDITION`;
- deployment bundle: `AARON / SONS / CLOTHES / OIL / BULL / RAM / RAM / BREAD`;
- audience mode: `ALL CONGREGATION AT THE DOOR, YES ALL OF THEM`;
- clothing stack: `TUNIC > SASH > ROBE > EPHOD > CHEST SLOT > HAT > GOLD FRONT BIT`;
- breastplate payload: `URIM + THUMMIM NOW ACTUALLY INSERTED`;
- altar calibration: `CRACKHEAD ANOINTING SPRAY x7`;
- sacrifice queue: `SIN BULL / WHOLE RAM / EAR-THUMB-TOE RAM`;
- blood bus: `RIGHT AUDIO / RIGHT GRIP / RIGHT WALKING OUTPUT`;
- hand transaction: `GIVE PACKAGE / WAVE PACKAGE / TAKE PACKAGE / BURN PACKAGE`;
- Moses payroll: `ONE WAVED BREAST`;
- dinner terminal: `CRACKHEAD BOIL MEAT — NOT THAT BOIL, DICKHEAD`;
- accommodation warning: `TENT DOOR 7 DAYS / DAY MODE + NIGHT MODE`;
- barcode: `CHB-LEV08-36-WASH-DRESS-OIL-BLOOD-RIGHTx3-STAY7-NOCRACK-HELD`.

## FIR verification

- all 36 verse markers are represented in order;
- command bundle and actual congregation assembly remain distinct State changes;
- Moses' public attribution remains Moses speech;
- clothing order retains every named garment and Urim/Thummim placement;
- anointing routes distinguish Tabernacle, sevenfold altar, equipment and Aaron;
- sin bull, burnt ram and consecration ram procedures do not merge;
- each animal is treated as an actual living Joe-faced animal occurrence;
- source-attributed purification, sanctification, atonement and aroma remain attributed;
- blood application retains Aaron then sons, right ear/thumb/toe, then altar;
- fat/thigh/bread hand-wave-return-burn sequence remains complete;
- Moses' breast portion and mixed oil/blood sprinkling remain separate acts;
- cooking “boil” is not silently converted into a status boil;
- narrator-recorded total compliance is retained without invented daily observations;
- Exodus 40 and Leviticus 8 are not forced into separate dates or contradiction;
- no unsupported contradiction is manufactured, so Captain does not appear;
- every living person, animal and source organism uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Leviticus 9 records the eighth-day offerings and the
first public Aaronic service, followed by attributed glory and fire appearances.
