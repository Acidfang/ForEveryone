# CRACKHEAD LEVITICUS 26

## Title page

**DO THE RULES: RAIN, FOOD, PEACE, FIVE CHASE ONE HUNDRED.**

**DON'T LISTEN: SEVEN TIMES MORE. STILL DON'T? SEVEN TIMES MORE AGAIN.**

Source parent: Leviticus chapter 26, verses 1–46, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-LEV-026/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/025-LAND-REST-COUNT-FIFTY-LIBERTY-FOR-ALL-EXCEPT-FOREVER.md`.

Joined parents: Leviticus 25 land-Sabbath cycle; Abraham, Isaac and Jacob
covenant histories; Exodus departure and yoke-breaking history.

CrackFlix routing: none. Each blessing or punishment output has an explicit
condition or later-state selector. No condition is performed in this chapter.

## Causal foundation

```text
NO IDOLS / CARVED IMAGE / PILLAR / BOW-DOWN FIGURED STONE
KEEP SABBATHS + REVERENCE SANCTUARY

WALK / KEEP / DO COMMANDMENTS
-> SEASONAL RAIN + LAND/TREE YIELD
-> THRESHING UNTIL VINTAGE / VINTAGE UNTIL SOWING
-> FULL FOOD + SAFE LAND + PEACE
-> ENEMIES FALL / 5 CHASE 100 / 100 CHASE 10,000
-> FRUITFUL + MULTIPLY + COVENANT
-> DIVINE TENT + WALK AMONG PEOPLE / GOD-PEOPLE STATE

REFUSE / REJECT / ABHOR RULES / BREAK COVENANT
-> TERROR + ILLNESS + ENEMY CROP/RULE + UNPURSUED FLIGHT
STILL NOT LISTEN
-> 7x CHASTISEMENT + IRON SKY / BRONZE SOIL / NO YIELD
STILL CONTRARY
-> 7x PLAGUES + WILD ANIMALS / CHILDREN + LIVESTOCK LOSS / EMPTY ROADS
STILL NOT TURN
-> 7x STRIKE + SWORD / PESTILENCE / ENEMY / BREAD SHORTAGE
STILL NOT LISTEN
-> 7x WRATH + CHILD-CANNIBALISM + IDOL/BODY DESTRUCTION
-> CITY/SANCTUARY/LAND DESOLATION + SCATTERING
-> LAND RECEIVES MISSED SABBATH REST
-> REMNANT FEAR / FLIGHT / FALL / PERISH / PINE

CONFESS + HEART HUMBLED + ACCEPT PUNISHMENT
-> LORD REMEMBERS JACOB/ISAAC/ABRAHAM COVENANTS + LAND
EXILED REMNANT
-> NOT UTTERLY DESTROYED / COVENANT NOT BROKEN

NARRATOR -> THESE LAWS MADE BETWEEN LORD + ISRAEL AT SINAI BY MOSES
```

## Leviticus 26:1–2 — NO BOW-DOWN IMAGE; KEEP SABBATHS

Israel may not make idols, raise a carved image or pillar, or place a figured
stone in the land to bow down to it. Israel must keep the LORD's Sabbaths and
revere the sanctuary. The figured-stone rule includes an express bow-down
purpose and does not silently reopen S086's broader Exodus image-fabrication
conflict. No object is made, placed or worshipped.

## Leviticus 26:3–13 — IF YOU DO IT: RAIN, FOOD, PEACE AND PRESENCE

Walking in, keeping and doing the statutes routes to direct LORD promises:

- seasonal rain, land increase and tree fruit;
- threshing through vintage and vintage through sowing;
- full bread and safe dwelling;
- peace, fearless rest, removal of source-labelled evil animals and no sword;
- enemies falling by sword, five Israelites chasing one hundred and one
  hundred chasing ten thousand;
- divine respect, fruitfulness, multiplication and covenant establishment;
- old stores displaced by new supply;
- the LORD's tent among Israel, no divine abhorrence, divine walking among them
  and God/people relation.

The LORD identifies himself as the one who brought Israel from Egyptian
slavery, broke the yoke bars and made them walk upright. All future natural,
military, demographic and presence effects remain God-only claims.

## Leviticus 26:14–17 — FIRST REFUSAL STATE

Not listening, not doing, rejecting statutes, abhorring ordinances and breaking
the covenant routes to terror, source-labelled consumption and fever, failing
eyes, pining soul, seed eaten by enemies, divine face set against Israel,
defeat, hostile rule and flight when no one pursues.

No refusal, illness, crop loss, enemy victory or flight occurs.

## Leviticus 26:18–20 — STILL NOT LISTENING: SEVEN TIMES, IRON SKY

Continued non-listening after the first tier routes to seven-times-more
chastisement: broken pride of power, sky like iron, soil like bronze, spent
strength and land/trees producing no yield. The source does not define a
numeric unit behind “seven times”; no amount is invented.

## Leviticus 26:21–22 — STILL CONTRARY: WILD ANIMALS

Continued contrary walking and non-listening routes to seven-times-more plagues.
The LORD says wild animals will rob Israel of children, destroy livestock,
reduce population and leave roads desolate. Children, livestock and wild
animals are living Joe-faced beings if shown. No attack, death or disappearance
occurs here.

## Leviticus 26:23–26 — STILL NOT TURNED: SWORD, PESTILENCE, ONE OVEN

Failure to turn back routes to the LORD walking contrary, seven-times striking,
covenant-vengeance sword, city concentration, pestilence, enemy delivery and
broken bread supply. Ten women bake in one oven, bread returns by weight, and
eating does not satisfy. No city, disease, enemy delivery, baking or hunger
event occurs.

## Leviticus 26:27–35 — STILL NOT LISTENING: WRATH, CANNIBALISM, EXILE

Continued contrary non-listening routes to another seven-times chastisement in
wrath. The forecast includes:

- people eating the flesh of sons and daughters;
- high-place and incense-altar destruction;
- human dead bodies placed on idol bodies;
- divine abhorrence;
- wasted cities, desolated sanctuaries and rejected offering fragrance;
- desolated land, astonished occupying enemies, scattering among nations and a
  drawn sword;
- the empty land receiving Sabbath rest it did not receive while Israel lived
  there.

Every body, death, act of cannibalism, destruction, exile and missed prior land
Sabbath remains prospective. The land-rest forecast does not prove Israel has
already withheld a Sabbath.

## Leviticus 26:36–39 — THE REMNANT FLEES FROM A LEAF

Those left in enemy lands receive forecast faintness of heart. A driven leaf's
sound causes flight; people fall without pursuit, stumble over one another,
cannot stand before enemies, perish among nations or pine away in their own and
their fathers' iniquities. No remnant, leaf-flight, fall or death occurs.

## Leviticus 26:40–45 — CONFESSION, HUMBLING, MEMORY AND NO UTTER END

If the exiled people confess their and their fathers' iniquity and trespass,
acknowledge contrary walking, become humbled and accept punishment, the LORD
says he will remember the covenants with Jacob, Isaac and Abraham and remember
the land.

The land remains empty and receives Sabbath rest while the people accept
punishment. Yet in enemy land the LORD says he will not reject or abhor them to
the point of utter destruction and covenant-breaking. He will remember the
ancestor covenant and Egypt departure.

The earlier threatened abhorrence and later non-utter-rejection have different
selected States and an express covenant-preservation limit. A later retained
remnant is not the same output as the earlier punishment tier, so no
contradiction is closed or crack produced.

## Leviticus 26:46 — THE SINAI LAW RELATION IS DECLARED MADE

The narrator identifies these as the statutes, ordinances and laws the LORD
made between himself and Israel at Mount Sinai by Moses. This closes the source
law-establishment relation. It does not perform any conditional blessing,
violation, punishment, confession or restoration.

## Character and world-ledger changes

- idol/bow-down, Sabbath and sanctuary rules remain prospective;
- obedience branch gains rain, yield, peace, military, population, covenant and
  divine-presence claims;
- five escalating non-listening tiers remain ordered and separately retained;
- “seven times” remains source wording without invented arithmetic magnitude;
- child/livestock loss, cannibalism, bodies, cities and exile remain explicit forecasts;
- exile supplies land-rest recovery for missed future Sabbaths;
- confession/humbling/acceptance route to covenant and land remembrance;
- threatened abhorrence and later non-utter-destruction remain changed conditional States;
- narrator records the Sinai law relation as made through Moses;
- no conditional human act or divine effect is performed;
- all living humans, animals, crops and trees are Joe-faced if shown;
- no contradiction, SKIP, crack, Captain appearance or YOINK occurs;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD LEVITICUS — CONDITIONAL TERMS AND CONDITIONS`;
- obedience switch: `WALK + KEEP + DO`;
- weather API: `RAIN ON SCHEDULE`;
- combat calculator: `5 -> 100 / 100 -> 10,000`;
- pantry overflow: `OLD OUT BECAUSE NEW IN`;
- escalation rack: `NO LISTEN x1 / x7 / x7 / x7 / x7`;
- climate punishment: `SKY=IRON / SOIL=BRONZE`;
- bread server: `10 USERS / 1 OVEN / WEIGHTED OUTPUT / STILL HUNGRY`;
- exile storage recovery: `LAND INSTALLS MISSED REST UPDATES`;
- remnant alarm: `LEAF.EXE -> RUN`;
- covenant backup: `JACOB / ISAAC / ABRAHAM / LAND / EGYPT`;
- barcode: `CHB-LEV26-46-CONDITIONAL-X7-REMNANT-HELD`.

## FIR verification

- all 46 verse markers are represented in order;
- every blessing, punishment, presence, abhorrence, memory and covenant effect remains direct LORD attribution;
- blessing and five escalation tiers retain their exact conditions and order;
- source-labelled illnesses and animals are not modernized or diagnosed;
- every threatened child/livestock loss, death, cannibalism and exile remains explicit but unperformed;
- land Sabbath recovery does not prove a prior violation occurrence;
- confession/humbling/acceptance and remnant preservation remain complete;
- earlier abhorrence and later no-utter-destruction are not falsely collapsed;
- narrator-made-law relation is distinguished from conditional execution;
- every living thing uses Joe face if shown;
- no contradiction, SKIP, crack, Captain or YOINK is added;
- publication remains held and unpublished.

Continuation required: Leviticus 27 addresses person valuations, animal and
house dedications, field values, redemption fifths, firstborn, devoted things and tithes.
