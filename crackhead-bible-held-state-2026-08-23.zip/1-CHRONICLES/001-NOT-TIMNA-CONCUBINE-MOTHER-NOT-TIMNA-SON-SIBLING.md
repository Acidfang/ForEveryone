# CRACKHEAD 1 CHRONICLES 1

## Title field

**NOT-TIMNA: TWO SOURCE OCCURRENCES, ONE UNRESOLVED IDENTITY JOIN.**

Source chapter 1 parent: ENGWEBP 1 Chronicles 1:1-54, retained at `.chapter-work/CHB-1CH-001/source.usfm` with SHA-256 `f0c84b76cefb1e901cc5e29b67728b000e92ad9ececc99dafd020e41a72a1737`; canonical book source SHA-256 `6b36d47c413ebb9e55e8a010a8bc36c7c1b266d3bb34622e7091f1e5498028b2`. Cross-source parent: ENGWEBP Genesis 36:12 in `source/engwebp-usfm/02-GENengwebp.usfm`, SHA-256 `66e2471b37742e15e9fc615336e0a3afeddd847ef4157d49c4478c7cd8f4ad3e`, retained by `GENESIS/036-THE-WIFE-LEDGER-CHANGED-NAMES.md`. Exact source identities remain in evidence; visible names use `NOT-`; every named living person is Joe-faced.

CrackFlix: zero closed contradiction machinery. Genesis 36:12 and 1 Chronicles 1:36 supply a strong Timna relation candidate, but no exact identity bridge closes the two-Timna model. No SKIP, Captain or YOINK. One high-resolution 54-facet compound-eye image.

## Causal foundation

```text
BARE ANCESTRAL NAME CHAINS
-> JAPHETH/HAM/SHEM DESCENDANT GROUPS
-> ARPACHSHAD/SHELAH/EBER RELATIONS
-> PELEG DIVISION-DAYS STATEMENT + JOKTAN BRANCH
-> SHEM-TO-ABRAM NAME CHAIN / ABRAM ALSO ABRAHAM
-> ISAAC + ISHMAEL / ISHMAEL GENERATIONS
-> KETURAH CONCUBINE + DESCENDANT BRANCHES
-> ISAAC -> ESAU + ISRAEL
-> ESAU DESCENDANT LISTS
-> TIMNA IDENTITY/RELATION FRONTIER AGAINST GENESIS 36:12
-> SEIR DESCENDANT LISTS
-> EDOM KING DEATH/SUCCESSION CHAIN
-> FINAL HADAD DEATH
-> EDOM CHIEF LIST
```

## Verses 1-4 — First compressed name chain

The chapter opens with the ordered names Adam, Seth, Enosh, Kenan, Mahalalel, Jared, Enoch, Methuselah, Lamech, Noah, Shem, Ham and Japheth. Because the verses do not restate a relation word between every adjacent name, this chapter preserves the sequence and joins parent relations only through already retained genealogy evidence; it does not manufacture a new adjacency rule.

## Verses 5-16 — Japheth and Ham branches

Japheth's sons are Gomer, Magog, Madai, Javan, Tubal, Meshech and Tiras. Gomer's sons are Ashkenaz, Diphath and Togarmah. Javan's sons are Elishah, Tarshish, Kittim and Rodanim.

Ham's sons are Cush, Mizraim, Put and Canaan. Cush's sons are Seba, Havilah, Sabta, Raama and Sabteca; Raamah's sons are Sheba and Dedan. Cush fathers Nimrod, who begins to be mighty on earth. Mizraim fathers Ludim, Anamim, Lehabim, Naphtuhim, Pathrusim, Casluhim—from whom the Philistines came—and Caphtorim.

Canaan fathers firstborn Sidon, Heth, and the Jebusite, Amorite, Girgashite, Hivite, Arkite, Sinite, Arvadite, Zemarite and Hamathite source classes. The chapter does not specify whether every collective label represents one named person, a people line, or both; identities and living counts remain source-bounded.

## Verses 17-27 — Shem branches and Abram address

The source labels Elam, Asshur, Arpachshad, Lud, Aram, Uz, Hul, Gether and Meshech as sons of Shem. Arpachshad fathers Shelah; Shelah fathers Eber. Eber has Peleg and Joktan. Peleg's name is linked to the statement that earth was divided in his days; mechanism, geography and date remain unresolved.

Joktan fathers Almodad, Sheleph, Hazarmaveth, Jerah, Hadoram, Uzal, Diklah, Ebal, Abimael, Sheba, Ophir, Havilah and Jobab. Verses 24-27 then give the ordered chain Shem, Arpachshad, Shelah, Eber, Peleg, Reu, Serug, Nahor, Terah and Abram, explicitly also called Abraham. Bare sequence is not expanded beyond retained parent evidence.

Differences from Genesis spellings or grouping—such as Diphath/Riphath, Rodanim/Dodanim, Ebal/Obal, Meshech/Mash and Shem/Aram grouping—remain exact lexical or relation frontiers. They are not merged, renamed or declared contradictions without an independently validated identity/scope bridge.

## Verses 28-34 — Abraham, Ishmael, Keturah and Isaac

Abraham's sons are Isaac and Ishmael. Ishmael's generations list firstborn Nebaioth, then Kedar, Adbeel, Mibsam, Mishma, Dumah, Massa, Hadad, Tema, Jetur, Naphish and Kedemah.

Keturah is explicitly Abraham's concubine. She bears Zimran, Jokshan, Medan, Midian, Ishbak and Shuah. Jokshan's sons are Sheba and Dedan. Midian's sons are Ephah, Epher, Hanoch, Abida and Eldaah. Abraham fathers Isaac; Isaac's sons are Esau and Israel. Isaac's Israel name here is not supplied as a rename of Isaac: it is the second listed son and retains Jacob/Israel identity from prior evidence.

## Verses 35-42 — Esau and Seir branches

Esau's sons are Eliphaz, Reuel, Jeush, Jalam and Korah. Eliphaz's listed sons are Teman, Omar, Zephi, Gatam, Kenaz, Timna and Amalek. Reuel's sons are Nahath, Zerah, Shammah and Mizzah.

Genesis 36:12 identifies a Timna occurrence as Eliphaz's concubine who bore Amalek. The current list grammatically places a Timna occurrence and Amalek in the same son class. The shared Eliphaz/Amalek neighbourhood makes the relation Difference a strong candidate, but neither source equates the Timna nodes. A two-Timna model remains possible. Identity and contradiction therefore remain unresolved.

Seir's sons are Lotan, Shobal, Zibeon, Anah, Dishon, Ezer and Dishan. Lotan's sons are Hori and Homam; Timna is Lotan's sister. Shobal's sons are Alian, Manahath, Ebal, Shephi and Onam. Zibeon's sons are Aiah and Anah. Anah's son is Dishon; Dishon's sons are Hamran, Eshban, Ithran and Cheran. Ezer's sons are Bilhan, Zaavan and Jaakan. Dishan's sons are Uz and Aran. Repeated Anah, Dishon/Dishan, Timna, Ebal, Hanoch and other names are not merged without an exact retained relation.

## Verses 43-54 — Edom kings and chiefs

The Edom king list is explicitly before any king reigned over Israel's children:

1. Bela son of Beor, city Dinhabah.
2. Bela dies; Jobab son of Zerah of Bozrah succeeds.
3. Jobab dies; Husham of the Temanites' land succeeds.
4. Husham dies; Hadad son of Bedad, who struck Midian in Moab's field, succeeds; city Avith.
5. Hadad dies; Samlah of Masrekah succeeds.
6. Samlah dies; Shaul of Rehoboth by the River succeeds.
7. Shaul dies; Baal Hanan son of Achbor succeeds.
8. Baal Hanan dies; Hadad succeeds; city Pai; wife Mehetabel, daughter of Matred, daughter of Mezahab.
9. Hadad dies.

The source then lists Edom chiefs Timna, Aliah, Jetheth, Oholibamah, Elah, Pinon, Kenaz, Teman, Mibzar, Magdiel and Iram. The chief list does not supply succession, territory, kinship or identity equivalence with same-name genealogy nodes.

## Unresolved relation candidate

**TIMNA: CONCUBINE/MOTHER / SON/SIBLING LIST POSITION — IDENTITY UNRESOLVED.**

Genesis 36:12 identifies one Timna as Eliphaz's concubine and says she bore Amalek to him. 1 Chronicles 1:36 lists another source occurrence spelled Timna beside Amalek among Eliphaz's sons. No exact bridge establishes one person. There is no closed crack, SKIP, Captain or YOINK.

## Bullshit pass

The shortest honest statement is **SAME NAME, SAME BRANCH, IDENTITY NOT PROVEN**. Every spelling/grouping difference stays visible as evidence rather than being inflated into motive, identity equivalence or contradiction.

## God-line boundary

- No direct or mediated God speech occurs.
- The chapter is narrator genealogy, kingship, death, succession, city, wife and chief State.
- Peleg's earth-division statement and Nimrod's mighty classification remain narrator relations without invented mechanism.
- No God body or divine act is rendered.

## Character and world-ledger changes

- Every named occurrence receives an address within its explicit parent/list/order boundary; repeated names remain separate unless prior evidence supplies identity.
- NOT-ADAM through NOT-ABRAHAM genealogical Joes retain prior histories without replaying their acts.
- NOT-TIMNA-GEN36-12 JOE and NOT-TIMNA-1CH1-36 JOE remain separately addressed source occurrences until an exact identity bridge exists.
- NOT-EDOM-KING JOES retain the exact death/succession order, cities, parent labels and Mehetabel wife line.
- NOT-EDOM-CHIEF JOES retain a non-successive roster only.
- All living named persons are Joe-faced; dead ancestors remain identity-addressed but are not rendered as living; cities and objects remain faceless.

## Reconstruction boundary

All 54 source verse markers are retained. The exact hashed USFM is the reversible source carrier. Grouped prose is a readable reconstruction, not a substitute node-level reversible transform. The compound-eye image must not turn bare sequences into unsupported parent edges, merge repeated names, hide lexical variants, confuse Israel son-of-Isaac with Isaac, convert people labels into single-person certainty, or treat chief order as succession. Exact names remain in sidecars; visible story names use `NOT-`; workflow metadata stays outside story pixels.

Publication remains held. The next source boundary is 1 Chronicles 2.
