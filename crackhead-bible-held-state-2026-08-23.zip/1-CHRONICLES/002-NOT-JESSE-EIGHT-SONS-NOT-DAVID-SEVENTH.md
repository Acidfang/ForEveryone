# CRACKHEAD 1 CHRONICLES 2

## Fly title

**NOT-JESSE: EIGHT SONS. / NOT-DAVID: THE SEVENTH.**

Source chapter 2 parent: ENGWEBP 1 Chronicles 2:1-55. Comparison parents: 1 Samuel 16:10-12 and 17:12-14. Publication remains held.

CrackFlix: one new physical count/ordinal contradiction `S263-E001-1CH2`; no SKIP; exactly one causally-null Captain/YOINK after closure. One high-resolution 55-facet compound-eye image. Exact hashed USFM remains the reversible source carrier.

## Causal foundation

ISRAEL'S TWELVE SONS
-> JUDAH'S FIVE-SON TOTAL AND ER'S LORD-ATTRIBUTED DEATH
-> PEREZ/ZERAH BRANCHES
-> RAM TO JESSE/DAVID LINE
-> JESSE SON COUNT/ORDINAL CONFLICT
-> HEZRON/CALEB/MACHIR BRANCH
-> JERAHMEEL BRANCH
-> SHESHAN/JARHA DAUGHTER-LINE SUCCESSION
-> CALEB/HEBRON BRANCHES
-> KIRIATH JEARIM/BETHLEHEM/FAMILY ROSTERS

## Verses 1-17 — Israel, Judah and Jesse

Israel's sons are Reuben, Simeon, Levi, Judah, Issachar, Zebulun, Dan, Joseph, Benjamin, Naphtali, Gad and Asher.

Judah's sons are Er, Onan and Shelah, all three born by Shua's Canaanite daughter. Er is Judah's firstborn, is narrator-classified wicked in LORD's sight, and LORD kills him. Tamar, Judah's daughter-in-law, bears Judah Perez and Zerah. The narrator totals Judah's sons as five.

Perez's sons are Hezron and Hamul. Zerah's sons are Zimri, Ethan, Heman, Calcol and Dara, explicitly five. Carmi's son Achar is called Israel's troubler who trespassed in the devoted thing. This Achar spelling is retained and is not silently rewritten to Achan. Ethan's son is Azariah.

Hezron's sons are Jerahmeel, Ram and Chelubai. Ram fathers Amminadab; Amminadab fathers Nahshon, prince of Judah's children; Nahshon fathers Salma; Salma fathers Boaz; Boaz fathers Obed; Obed fathers Jesse.

Jesse fathers Eliab first, Abinadab second, Shimea third, Nethanel fourth, Raddai fifth, Ozem sixth and David seventh. Their sisters are Zeruiah and Abigail. Zeruiah's three sons are Abishai, Joab and Asahel. Abigail bears Amasa; Amasa's father is Jether the Ishmaelite.

Caleb son of Hezron fathers children by Azubah his wife and by Jerioth; the listed sons are Jesher, Shobab and Ardon. Azubah dies. Caleb marries Ephrath, who bears Hur. Hur fathers Uri; Uri fathers Bezalel.

At age sixty Hezron takes as wife the daughter of Machir, father of Gilead; she bears Segub. Segub fathers Jair, who has twenty-three cities in Gilead. Geshur and Aram take Jair's towns with Kenath and its villages, sixty cities. The source groups all these as sons of Machir father of Gilead. It does not supply arithmetic reconciling twenty-three with sixty, nor does it state that the same object set is counted at the same boundary.

After Hezron dies in Caleb Ephrathah, Abijah, Hezron's wife, bears him Ashhur father of Tekoa. The post-death wording and birth are retained in source order; conception timing and place-name/person-name grain are not inferred.

Jerahmeel, Hezron's firstborn, has Ram firstborn, Bunah, Oren, Ozem and Ahijah. His other wife Atarah is Onam's mother. Ram's sons are Maaz, Jamin and Eker. Onam's sons are Shammai and Jada. Shammai's sons are Nadab and Abishur. Abishur's wife Abihail bears Ahban and Molid. Nadab's sons are Seled and Appaim; Seled dies childless. Appaim fathers Ishi; Ishi fathers Sheshan; Sheshan fathers Ahlai.

Jada, Shammai's brother, has Jether and Jonathan; Jether dies childless. Jonathan's sons are Peleth and Zaza. These are grouped as Jerahmeel's sons.

Sheshan has no sons, only daughters, and has an Egyptian servant named Jarha. Sheshan gives his daughter to Jarha as wife; she bears Attai. Attai fathers Nathan; Nathan fathers Zabad; Zabad fathers Ephlal; Ephlal fathers Obed; Obed fathers Jehu; Jehu fathers Azariah; Azariah fathers Helez; Helez fathers Eleasah; Eleasah fathers Sismai; Sismai fathers Shallum; Shallum fathers Jekamiah; Jekamiah fathers Elishama. The unnamed daughter's identity remains source-unnamed.

Caleb, Jerahmeel's brother, has Mesha firstborn, father of Ziph, followed by the source's Mareshah/father-of-Hebron relation. Hebron's sons are Korah, Tappuah, Rekem and Shema. Shema fathers Raham father of Jorkeam; Rekem fathers Shammai; Shammai fathers Maon; Maon is father of Beth Zur.

Ephah, Caleb's concubine, bears Haran, Moza and Gazez; Haran fathers another source occurrence named Gazez. The two Gazez occurrences are not merged without an exact bridge. Jahdai's sons are Regem, Jothan, Geshan, Pelet, Ephah and Shaaph. Same-name Ephah occurrences are not automatically identical.

Maacah, Caleb's concubine, bears Sheber and Tirhanah. She also bears Shaaph father of Madmannah and Sheva father of Machbena and Gibea. Caleb's daughter is Achsah. Pronoun scope is retained as Maacah from the preceding verse; identity with any other Maacah is not inferred.

The source then groups sons of Caleb son of Hur, Ephrathah's firstborn: Shobal father of Kiriath Jearim; Salma father of Bethlehem; Hareph father of Beth Gader. Shobal's sons are Haroeh and half the Menuhoth. Kiriath Jearim families are Ithrites, Puthites, Shumathites and Mishraites; from them come Zorathites and Eshtaolites. Salma's sons are Bethlehem, Netophathites, Atroth Beth Joab, half the Manahathites and Zorites. These person/place/people labels remain at their source grain.

The scribe families living at Jabez are Tirathites, Shimeathites and Sucathites. They are Kenites who came from Hammath, father of Rechab's house. No individual identities, migration mechanics or dates are supplied.

## CrackFlix closure

`S263-E001-1CH2` — **JESSE HAS EIGHT SONS / DAVID IS THE SEVENTH**.

1 Samuel 17:12 states Jesse had eight sons and identifies David as Jesse's son; verses 13-14 identify three elder brothers and David as youngest. 1 Samuel 16:10 says Jesse made seven sons pass before David was fetched. 1 Chronicles 2:13-15 supplies only six named older sons and calls David seventh. The same Jesse/David family and ordinal boundary receives totals eight and seven without a missing-son identity, removal, counting-scope transition or correction. First occurrence: no SKIP. One post-closure Captain pokes and licks one boil, says YOINK, walks away and changes nothing.

## Bullshit pass

**JESSE LOST ONE SON BETWEEN THE COUNT AND THE CREDITS.** The joke does not identify a missing person, repair the count or alter either source Moment.

## God-line boundary

- Direct God speech does not occur.
- LORD is narrator-attributed as seeing Er's wickedness and killing Er.
- No divine form, mechanism, words, motive beyond the source classification, or executor substitute is rendered.
- All other chapter content is narrator genealogy, death, marriage, property, city and family State.

## Character and world-ledger changes

- Every explicit parent, child, spouse, sibling, ordinal, ethnicity, city, death, property and family relation is retained.
- Repeated equal names remain separate source occurrences unless an exact bridge exists.
- Achar/Achan and other lexical variants remain unresolved, not silently normalized.
- Person/place/population labels are not collapsed into one actor.
- All living named persons are Joe-faced; cities, devoted property and other nonliving carriers remain faceless.
- Exact names remain in machine sidecars; visible story names use `NOT-`; workflow metadata stays outside story pixels.

## Reconstruction boundary

- The exact hashed USFM is reversible. This grouped manuscript is not claimed as a node-by-node reversible transform.

Publication remains held. The next source boundary is 1 Chronicles 3.
