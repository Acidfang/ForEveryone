# CRACKHEAD GENESIS 12

## Title page

**TELL THEM YOU'RE MY SISTER. WHY DIDN'T YOU TELL ME SHE WAS YOUR WIFE?**

Source parent: Genesis 12:1–20, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 12.

Parent manuscript: `GENESIS/011-BUILD-IT-NOT-TO-SCATTER.md`.

CrackFlix crossover: `S011 — PUNISHED FOR WHAT YOU WERE NOT TOLD`.

## Causal foundation

```text
ABRAM HOUSEHOLD SETTLED AT HARAN
-> GOD COMMANDS DEPARTURE TO SHOWN LAND
-> GREAT-NATION / BLESSING / NAME / FAMILY-BLESSING PROMISES
-> ABRAM DEPARTS AT 75 WITH SARAI/LOT/POSSESSIONS/ACQUIRED PEOPLE
-> CANAAN ENTRY -> SHECHEM/MOREH -> CANAANITES PRESENT
-> GOD PROMISES LAND TO OFFSPRING -> ALTAR
-> BETHEL/AI CAMP -> ALTAR/CALL -> SOUTHWARD TRAVEL
-> SEVERE FAMINE -> EGYPT FOREIGN RESIDENCE
-> ABRAM STATES BEAUTY/DEATH PREDICTION
-> ABRAM REQUESTS SISTER PRESENTATION FOR HIS SURVIVAL/WELLBEING
-> EGYPTIANS/PRINCES SEE/PRAISE SARAI
-> SARAI TAKEN INTO PHARAOH HOUSE
-> PHARAOH TREATS ABRAM WELL -> POSSESSIONS INCREASE
-> GOD PLAGUES PHARAOH/HOUSE BECAUSE SARAI IS ABRAM'S WIFE
-> PHARAOH CONFRONTS ABRAM -> RETURNS SARAI -> ESCORTS HOUSEHOLD OUT
```

## Genesis 12:1–3 — LEAVE / PROMISE

> **CRACKHEAD GOD:** `LEAVE YOUR COUNTRY, RELATIVES AND FATHER'S HOUSE.`
>
> `GO TO THE LAND I'LL SHOW YOU.`
>
> `I'LL MAKE YOU A GREAT NATION.`
>
> `BLESS YOU. MAKE YOUR NAME GREAT. MAKE YOU A BLESSING.`
>
> `I'LL BLESS WHO BLESSES YOU, CURSE WHO TREATS YOU WITH CONTEMPT.`
>
> `ALL EARTH FAMILIES WILL BE BLESSED THROUGH YOU.`

These are commands and future commitments, not completed results. Abram is
still childless through the Sarai State retained from Genesis 11; the great
nation and offspring paths remain open.

## Genesis 12:4–5 — ABRAM ACTUALLY GOES

Abram leaves Haran as God told him at age 75. A Lot Joe goes with him. Abram
takes Sarai Joe, Lot, all gathered possessions and the people acquired in Haran.
They enter Canaan.

The chapter does not define `acquired people`, their consent, roles, names or
legal status. Each is a distinct Joe identity with unresolved origin.

Terah's earlier Canaan destination now continues through Abram after Terah's
death; it is not restarted from nothing.

## Genesis 12:6–9 — CANAAN MOVEMENT AND ALTARS

Abram passes through to Shechem and Moreh's oak. Canaanites are then in the
land.

God appears:

> **CRACKHEAD GOD:** `I'LL GIVE THIS LAND TO YOUR OFFSPRING.`

Abram builds an altar at the appearance place. He later camps on the mountain
east of Bethel, with Bethel west and Ai east, builds another altar and calls on
God's name. Then he continues toward the South.

Wordplay map: **Shek-'Em**, **More Oak**, **Bet-Hell**, and **Aye**. Relative
east/west positions remain source geometry.

## Genesis 12:10 — FAMINE MOVES THE HOUSEHOLD

A severe famine occurs in the land. Abram goes down into Egypt to live there as
a foreigner because of it.

```text
SEVERE FAMINE -> TEMPORARY FOREIGN RESIDENCE IN EGYPT
```

The source does not record God commanding or forbidding this move.

Egypt enters as a current nation/place from the earlier Mizraim/Ham nation root;
no modern Egyptian identity is projected backward.

## Genesis 12:11–13 — THE PRESENTATION PLAN

Near Egypt, Abram tells Sarai:

> **ABRAM JOE:** `YOU'RE BEAUTIFUL.`
>
> `THE EGYPTIAN JOES WILL SEE YOU, CALL YOU MY WIFE, KILL ME AND KEEP YOU.`
>
> `PLEASE SAY YOU'RE MY SISTER.`
>
> `THEN IT GOES WELL FOR ME AND I LIVE BECAUSE OF YOU.`

His prediction is retained as his statement, not an observed Egyptian plan.
The requested outputs are explicitly Abram's wellbeing and survival.

This chapter does not yet resolve whether `sister` has any genealogical truth.
It does establish Sarai as Abram's wife and the requested presentation as
omitting that concurrent relation.

## Genesis 12:14–16 — SARAI TAKEN / ABRAM PAID

Egyptians see that Sarai is very beautiful. Pharaoh's princes see her, praise
her to Pharaoh, and Sarai is taken into Pharaoh's house.

Pharaoh deals well with Abram for her sake. Abram receives or holds:

- sheep;
- cattle;
- male and female donkeys;
- male and female servants;
- camels.

The source does not record Sarai speaking, agreeing, refusing, or receiving the
goods. Do not invent her internal State.

Background receipt: `CRACKHEAD SISTER PRESENTATION — BENEFICIARY: ABRAM JOE`.

## Genesis 12:17 — PLAGUES GO TO THE UNINFORMED HOUSE

God afflicts Pharaoh and his household with great plagues because of Sarai,
Abram's wife.

Observable information path:

```text
PHARAOH RECEIVES: SARAI PRESENTED WITHOUT WIFE RELATION
PHARAOH ACTS: TAKES SARAI / TREATS ABRAM WELL
ACTUAL RETAINED STATE: SARAI IS ABRAM'S WIFE
RESULT: PHARAOH + HOUSEHOLD PLAGUED BECAUSE OF WIFE STATE
```

The source does not record God warning Pharaoh before the plagues.

## Genesis 12:18–20 — WHAT DID YOU DO TO ME?

Pharaoh calls Abram:

> **PHARAOH JOE:** `WHAT DID YOU DO TO ME?`
>
> `WHY DIDN'T YOU TELL ME SHE WAS YOUR WIFE?`
>
> `WHY SAY SISTER SO I TOOK HER AS MY WIFE?`
>
> `HERE'S YOUR WIFE. TAKE HER. GO.`

Pharaoh's words establish his missing wife-information and the action it
produced. This completes `S011-E001 — SISTER IN, PLAGUES OUT`.

Captain's glazed eyes clear. He appears boilless in the suit.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes Abram's boil, licks his finger, walks away eating the crack crystal he
sees, and never looks back. Pharaoh continues the expulsion unchanged.

Pharaoh commands men concerning Abram. They escort Abram away with Sarai and
everything he has. The goods are not recorded as reclaimed.

## Character and world-ledger changes

- Abram: receives call/promises; departs at 75; enters Canaan; builds altars;
  moves under famine; requests sister presentation; gains household wealth;
  receives Pharaoh confrontation and escort.
- Sarai: travels Haran–Canaan–Egypt; is observed beautiful; taken into Pharaoh's
  house; identified/returned as Abram's wife; no source speech retained.
- Lot: travels with Abram into Canaan and Egypt; no speech retained.
- Pharaoh: receives Sarai through princes, treats Abram well, is plagued with
  household, learns wife relation, confronts and expels Abram.
- Canaan: current inhabitants and Abram movement/altar sites are retained.
- Egypt: ruler/princes/household, foreign-residence and property-transfer
  processes appear; broader institutions remain unresolved.

## Fuck-up pass

- Lot -> A Lot Joe.
- Shechem -> Shek-'Em.
- Moreh oak -> More Oak.
- Bethel -> Bet-Hell.
- Ai -> Aye.
- Egypt -> E-Jipped in background travel advertising; source address retained.
- Pharaoh -> Fair-Oh Joe.
- famine -> `CRACKHEAD ZERO-FOOD TOURISM DRIVER`.
- sister presentation -> `CRACKHEAD RELATIONSHIP FIELD: PARTIAL`.

## FIR verification

- All 20 verse markers are covered in order.
- God promises are distinguished from completed States.
- Haran departure, Canaan sites and Egypt move retain order and causes.
- Severe famine—not invented fear—produces Egypt foreign residence.
- Abram's death prediction remains stated, not observed.
- Sarai's wife relation and sister request remain separately retained.
- Sarai's taking precedes Abram's benefit and the plagues.
- Pharaoh's confrontation supplies evidence that wife status was not told.
- S011 does not depend on deciding whether sister status was genealogically
  false; it depends on withheld concurrent wife status.
- Sarai's speech, consent and motive remain unresolved.
- Captain appears only after the completed information/punishment friction.
- Manuscript remains held and unpublished.

Continuation required: Genesis 13 receives Egypt return, wealth, altar return,
Abram/Lot livestock conflict, voluntary land separation, Lot's Jordan choice,
Sodom proximity, renewed land/offspring promise and Hebron altar.
