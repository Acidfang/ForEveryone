# CRACKHEAD GENESIS 21

## Title page

**HE LAUGHS. SHE LEAVES. SEVEN SHEEP.**

Source parent: Genesis 21:1–34, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 21.

Parent manuscript: `GENESIS/020-SISTER-AGAIN-DREAM-WARNING.md`.

CrackFlix crossover: none closed in this chapter.

## Causal foundation

```text
LORD VISITS / DOES AS SPOKEN
-> SARAH CONCEIVES -> ISAAC BORN AT SET TIME
-> ABRAHAM NAMES ISAAC
-> ISAAC CIRCUMCISED AT EIGHT DAYS
-> ABRAHAM AGE 100
-> SARAH STATES GOD-MADE LAUGHTER / BIRTH
-> ISAAC GROWS -> WEANED -> GREAT FEAST
-> SARAH SEES HAGAR'S SON MOCKING
-> SARAH DEMANDS SERVANT/SON EXPULSION OVER JOINT INHERITANCE
-> ABRAHAM GRIEVED ON ACCOUNT OF SON
-> GOD TELLS ABRAHAM LISTEN / ISAAC NAMED-OFFSPRING LINE
-> GOD RESTATES NATION PROMISE FOR SERVANT'S SON
-> ABRAHAM GIVES BREAD/WATER/CHILD -> SENDS HAGAR AWAY
-> HAGAR WANDERS BEERSHEBA WILDERNESS
-> WATER SPENT -> BOY UNDER SHRUB -> HAGAR DISTANCES / WEEPS
-> GOD HEARS BOY
-> ANGEL CALLS / COMMANDS LIFT-HOLD / GREAT-NATION PROMISE
-> GOD OPENS HAGAR'S EYES -> WELL
-> WATER CONTAINER FILLED -> BOY DRINKS
-> GOD WITH BOY -> GROWS -> ARCHER -> PARAN
-> HAGAR GETS EGYPTIAN WIFE FOR ISHMAEL
-> ABIMELECH + PHICOL REQUEST NON-FALSE OATH
-> ABRAHAM SWEARS
-> ABRAHAM RAISES VIOLENTLY TAKEN WELL
-> ABIMELECH STATES NO KNOWLEDGE / NO PRIOR NOTICE
-> SHEEP/CATTLE EXCHANGE -> COVENANT
-> SEVEN EWE LAMBS SEPARATED -> WELL-DIGGING WITNESS
-> BEERSHEBA NAME / OATH
-> ABIMELECH + PHICOL RETURN TO PHILISTINE LAND
-> ABRAHAM PLANTS TAMARISK / CALLS EVERLASTING GOD
-> ABRAHAM REMAINS FOREIGNER MANY DAYS
```

## Genesis 21:1–5 — PROMISE BECOMES BIRTH

The LORD visits Sarah and does as previously spoken. Sarah conceives and bears
Abraham a son at the stated set time in Abraham's old age.

Abraham names him Isaac—`he laughs`—and circumcises him at eight days as God
commanded. Abraham is 100 when Isaac is born.

```text
GENESIS 17–18 FUTURE ISAAC
-> GENESIS 21 CONCEPTION/BIRTH
-> SAME JOE, PROMISE STATE MATERIALIZED
```

The birth closes the promised timing, parents, name and eight-day requirement.
It does not automatically close every future covenant, nation, king or land
promise attached to Isaac's line.

Background certificate: `CRACKHEAD PROMISE DELIVERY — RECIPIENT: EYE-SACK JOE / AGE OF FATHER: 100`.

## Genesis 21:6–8 — LAUGHTER AND WEANING

> **SARAH JOE:** `GOD HAS MADE ME LAUGH.`
>
> `EVERYONE WHO HEARS WILL LAUGH WITH ME.`
>
> `WHO WOULD HAVE SAID SARAH WOULD NURSE CHILDREN?`
>
> `I HAVE BORNE ABRAHAM A SON IN HIS OLD AGE.`

This is a new laugh statement after an observed birth. Sarah does not deny this
laugh, so S013 does not repeat.

Isaac grows and is weaned. Abraham makes a great feast on the weaning day.
Neither Isaac's weaning age nor the guest inventory is supplied.

## Genesis 21:9–13 — CAST THEM OUT

Sarah sees Hagar the Egyptian's son, born to Abraham, mocking.

> **SARAH JOE:** `CAST OUT THIS SERVANT AND HER SON.`
>
> `THE SERVANT'S SON WILL NOT BE HEIR WITH MY SON ISAAC.`

The source records the observed mocking but supplies no quoted words, target,
duration or act beyond that classification. It records no Hagar or Ishmael
reply to Sarah's demand.

The thing is very grievous in Abraham's sight on account of his son.

> **CRACKHEAD GOD:** `DON'T LET IT BE GRIEVOUS BECAUSE OF THE BOY OR YOUR SERVANT.`
>
> `LISTEN TO EVERYTHING SARAH SAYS.`
>
> `YOUR OFFSPRING WILL BE NAMED THROUGH ISAAC.`
>
> `I WILL ALSO MAKE A NATION OF THE SERVANT'S SON, BECAUSE HE IS YOUR CHILD.`

The Isaac inheritance line and Ishmael nation promise remain separate. Hagar's
Genesis 16 return/submission command stays in history, but this is a later
instruction after Isaac's birth and Sarah's expulsion demand. No stable
unchanged rule or identical speaker designation is supplied from which to
force a contradiction.

## Genesis 21:14–16 — BREAD, WATER, WILDERNESS

Abraham rises early. He gives Hagar bread and a water container, puts them on
her shoulder, gives her the child, and sends her away. She departs and wanders
in Beersheba's wilderness.

Hagar's speech, agreement and destination choice are not recorded at the
sending boundary.

The water is spent. Hagar puts the child beneath a shrub, sits about a bowshot
away and says:

> **HAGAR JOE:** `DON'T LET ME SEE THE DEATH OF THE CHILD.`

She lifts her voice and weeps.

The empty container precedes the separation. Hagar's anticipated death is her
spoken expectation, not a completed death State.

## Genesis 21:17–19 — THE BOY IS HEARD

God hears the boy's voice. The angel of God calls to Hagar from the sky:

> **ANGEL OF GOD JOE:** `WHAT TROUBLES YOU, HAGAR?`
>
> `DON'T BE AFRAID. GOD HEARD THE BOY WHERE HE IS.`
>
> `GET UP. LIFT HIM. HOLD HIM WITH YOUR HAND.`
>
> `I WILL MAKE HIM A GREAT NATION.`

God opens Hagar's eyes. She sees a water well, fills the container and gives the
boy a drink.

The source says God opens her eyes; it does not say the well is newly created,
previously absent or physically invisible. `Seeing` changes before filling and
drinking.

Every well bucket and shrub interpreted as having a face receives Joe's face.
Neither Hagar nor Ishmael comments.

## Genesis 21:20–21 — ISHMAEL GROWS

God is with Ishmael. He grows, lives in the wilderness and becomes an archer.
He lives in Paran's wilderness. Hagar obtains a wife for him from Egypt.

The wife's name, parents, consent, travel route and speech remain unresolved.
The marriage extends Ishmael's promised line but does not yet materialize the
twelve princes or great nation.

Equipment label: `CRACKHEAD GREAT-NATION STARTER KIT — ONE ARCHER / ONE UNNAMED WIFE / OUTPUT PENDING`.

## Genesis 21:22–24 — SWEAR YOU WON'T DEAL FALSELY

Abimelech and Phicol, captain of his army, approach Abraham.

> **ABIMELECH JOE:** `GOD IS WITH YOU IN EVERYTHING YOU DO.`
>
> `SWEAR BY GOD THAT YOU WON'T DEAL FALSELY WITH ME, MY SON OR MY SON'S SON.`
>
> `SHOW ME AND THIS LAND THE KINDNESS I SHOWED YOU.`

> **ABRAHAM JOE:** `I WILL SWEAR.`

Abimelech's broad statement and requested oath are both his words. The source
does not state that the oath request accuses Abraham of a new false act.

## Genesis 21:25–27 — THE WELL WAS TAKEN

Abraham complains because Abimelech's servants violently took a water well.

> **ABIMELECH JOE:** `I DON'T KNOW WHO DID THIS.`
>
> `YOU DIDN'T TELL ME.`
>
> `I DIDN'T HEAR ABOUT IT UNTIL TODAY.`

Those statements agree with the complaint arriving now; no contrary earlier
notice is retained. This is information delivery, not `I DIDN'T DO THAT` and
not a punishment-for-unknown-information episode.

Abraham gives Abimelech sheep and cattle. The two make a covenant.

## Genesis 21:28–32 — SEVEN EWE WITNESSES

Abraham sets seven ewe lambs apart.

> **ABIMELECH JOE:** `WHAT DO THESE SEVEN EWES MEAN?`

> **ABRAHAM JOE:** `TAKE THEM FROM MY HAND AS WITNESS THAT I DUG THIS WELL.`

The place is called Beersheba—`well of the oath` or `well of seven`—because
both swear there. The covenant is made. Abimelech and Phicol rise and return to
the land of the Philistines.

The lambs witness the digging claim through agreed transfer; they do not speak,
sign or become judges. They do have seven identical Joe faces.

## Genesis 21:33–34 — TAMARISK AND MANY DAYS

Abraham plants a tamarisk at Beersheba and calls on the name of the LORD, the
Everlasting God. He remains a foreigner in Philistine land many days.

The chapter supplies no exact duration, property boundary beyond the well
witness, or end to foreigner status.

## Character and world-ledger changes

- Isaac: moves from named future Joe to born Joe; named, circumcised at eight
  days, grows, is weaned and receives a great feast.
- Sarah: conceives/bears/nurses; states God-made laughter; observes Ishmael
  mocking; demands Hagar/Ishmael expulsion over inheritance.
- Abraham: becomes father of Isaac at 100; performs eighth-day circumcision;
  sends Hagar/Ishmael away with bread/water; swears with Abimelech; raises well
  seizure; transfers livestock/seven ewes; plants tamarisk and calls on God.
- Hagar: sent away without retained reply; wanders; spends water; separates from
  child and weeps; receives angel call; sees well; gives water; later obtains an
  Egyptian wife for Ishmael.
- Ishmael: observed mocking; expelled; heard by God; drinks; grows under
  God-with-him State; becomes wilderness archer; receives Egyptian wife.
- Abimelech: seeks intergenerational non-false oath; receives well complaint;
  states first notice; covenants and accepts well-witness lambs.
- Phicol: named army captain and covenant witness/participant; returns with
  Abimelech.
- Beersheba: wilderness crisis site and later oath/seven/well naming site.
- Philistine land: named as Abimelech/Phicol return domain and Abraham's many-day
  foreign residence.

## Fuck-up pass

- Isaac -> `EYE-SACK JOE`, delivered in a sack with an eye and Joe face.
- weaning feast -> `CRACKHEAD MILK-SERVICE TERMINATION PARTY`.
- bowshot distance -> literal bow fires a location pin with Joe's face.
- Paran -> `PARANORMAL ARCHERY DISTRICT`, nothing paranormal observed.
- Phicol -> `FEE-CALL JOE`, captain of the itemized army invoice.
- Beersheba -> `BEER-SHEBA`, a well containing water despite the sign.
- seven ewe lambs -> `CRACKHEAD WELL RECEIPT — PAYMENT: EWE EWE EWE EWE EWE EWE EWE`.
- tamarisk -> `CRACKHEAD PERPETUAL SUPPORT TREE / MANY DAYS WARRANTY`.

## FIR verification

- All 34 verse markers are covered in order.
- Prior Isaac promise transitions to conception, birth, naming and circumcision
  without replacing identity.
- Mocking precedes expulsion demand; demand and grief precede God's instruction;
  instruction precedes sending.
- Ishmael nation promise remains active through expulsion and rescue.
- Empty water precedes expected-death speech; hearing precedes angel call; eye
  opening precedes well use.
- Ishmael growth, archery, residence and wife acquisition remain ordered and do
  not prematurely complete the nation promise.
- Abimelech's oath request precedes Abraham's well complaint; first-notice claim
  is not contradicted by an invented earlier report.
- Seven ewes remain distinct from the earlier sheep/cattle covenant transfer.
- No CrackFlix series, SKIP, Captain or crack is manufactured.
- Manuscript remains held and unpublished.

Continuation required: Genesis 22 receives God's test, Isaac burnt-offering
command, three-day journey, father/son ascent, binding/knife interruption, ram
substitution, renewed oath promise and Nahor/Milcah/Rebekah genealogy.
