# CRACKHEAD GENESIS 47

## Title page

**THERE WAS NO BREAD IN ALL THE LAND.**

**JOSEPH GAVE THEM BREAD.**

**ALL THE LAND BECAME PHARAOH'S. EXCEPT THE LAND THAT DIDN'T.**

Source parent: Genesis 47:1–31, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 47.

Prepared evidence: `.chapter-work/CHB-GEN-047/job.json` and `source.usfm`.

Parent manuscript: `GENESIS/046-THEY-CAME-TO-EGYPT-THEY-DIED-IN-CANAAN.md`.

CrackFlix routing:

- existing `S032 — YOUR NAME IS NO LONGER JACOB. JACOB.`, episode
  `S032-E004-GEN47 — JACOB ANSWERS FOR ISRAEL AGAIN`;
- new `S054 — NO BREAD IN ALL THE LAND. HERE IS BREAD.`, episode
  `S054-E001-GEN47 — THE BREAD-FREE BREAD COUNTER`;
- new `S055 — ALL THE LAND. EXCEPT THAT LAND.`, episode
  `S055-E001-GEN47 — PHARAOH OWNS EVERYTHING EXCEPT THE EXEMPTION`.

## Causal foundation

```text
JOSEPH REPORTS FAMILY ARRIVAL / PRESENTS FIVE BROTHERS
-> PHARAOH ASKS OCCUPATION
-> BROTHERS PERFORM PREPARED SHEPHERD ANSWER / REQUEST GOSHEN
-> PHARAOH GRANTS BEST LAND / GOSHEN / LIVESTOCK AUTHORITY OPTION
-> JOSEPH PRESENTS JACOB
-> JACOB BLESSES PHARAOH / REPORTS 130-YEAR PILGRIMAGE
-> JACOB BLESSES PHARAOH AGAIN / LEAVES
-> JOSEPH PLACES HOUSEHOLD IN RAMESES / PROVIDES BREAD
-> NARRATOR: NO BREAD IN ALL THE LAND
-> JOSEPH COLLECTS ALL EGYPT/CANAAN MONEY FOR SOLD GRAIN
-> MONEY FAILS
-> JOSEPH EXCHANGES BREAD FOR ALL LIVESTOCK FOR ONE YEAR
-> LIVESTOCK NOW PHARAOH'S / MONEY SPENT / ONLY BODIES + LAND LEFT
-> PEOPLE OFFER THEMSELVES + LAND FOR BREAD + SEED
-> JOSEPH BUYS ALL EGYPT LAND FOR PHARAOH / MOVES PEOPLE TO CITIES
-> PRIEST LAND IS NOT BOUGHT BECAUSE PHARAOH ALREADY FEEDS PRIESTS
-> JOSEPH ISSUES SEED / PERMANENT FIFTH TO PHARAOH
-> PEOPLE SAY JOSEPH SAVED THEIR LIVES / ACCEPT SERVANT STATE
-> ISRAEL HOUSEHOLD POSSESSES / MULTIPLIES IN GOSHEN
-> JACOB LIVES SEVENTEEN YEARS / REACHES 147
-> JACOB REQUIRES JOSEPH OATH: DO NOT BURY ME IN EGYPT
-> JOSEPH SWEARS / ISRAEL BOWS ON BED HEAD
```

## Genesis 47:1–6 — THE PREPARED ANSWER HAPPENS

Joseph reports to Pharaoh that his father, brothers, flocks, herds and goods
have arrived from Canaan and are in Goshen. He presents five brothers. Pharaoh
asks their occupation. They answer that they and their fathers are shepherds,
state that Canaan has no pasture under the severe famine and ask to live in
Goshen.

This performs the dialogue prepared in Genesis 46. Pharaoh tells Joseph that
Egypt is before him, commands that the family live in the best land in Goshen
and permits able family members to oversee Pharaoh's livestock.

The requested audience, occupation answer and Goshen grant close. No brother is
named among the five, and no livestock overseer is selected in this chapter.

## Genesis 47:7–10 — HOW OLD ARE YOU, JACOB?

Joseph brings Jacob before Pharaoh. Jacob blesses Pharaoh. Pharaoh asks Jacob's
age. Jacob calls his 130 years a pilgrimage, says they have been few and evil,
and says they have not reached his fathers' years. Jacob blesses Pharaoh again
and leaves.

The source continues using Jacob after the retained no-longer-Jacob declarations.
A Joe-faced fly presses `SKIP`.

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

His eyes glaze. Jacob gives the whole age answer, blesses Pharaoh and exits.
Nothing skips.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the old-name boil, licks his finger, walks away and never looks back.

## Genesis 47:11–12 — THE BEST LAND HAS BREAD

Joseph places his father and brothers in Egypt, gives them a possession in the
best land, the land of Rameses, as Pharaoh commanded, and provides his father,
brothers and whole household with bread according to family size.

Goshen and Rameses are retained as source place labels in the same settlement
act. Their exact geographic relation is unresolved rather than invented.

## Genesis 47:13–17 — NO BREAD. BREAD FOR MONEY. BREAD FOR ANIMALS.

The next verse says there was no bread in all the land because the famine was
very severe. Egypt and Canaan fainted. Joseph then gathers all money found in
Egypt and Canaan for grain they bought and brings it into Pharaoh's house.

When the money is spent, Egyptians ask Joseph for bread so they will not die.
Joseph tells them to give livestock for food. They bring horses, flocks, herds
and donkeys, and Joseph feeds them with bread in exchange for all their
livestock for that year.

```text
JOSEPH PROVIDES HOUSEHOLD BREAD IN EGYPT
-> NO BREAD IN ALL THE LAND
-> PEOPLE BUY GRAIN / ASK FOR BREAD
-> JOSEPH GIVES BREAD FOR LIVESTOCK
-> NO EXCLUSION OF JOSEPH'S STOCK FROM "ALL THE LAND"
```

That completes S054. The bread counter grows a Joe-faced boil wearing a sign:
`NO BREAD AVAILABLE — BREAD EXCHANGE OPEN`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain pokes it, licks his finger and leaves. Every exchange remains completed.

Every horse, flock animal, herd animal and donkey has Joe's face. They remain
distinct animals and transferred property in the source; no animal speech,
consent or fate is supplied.

## Genesis 47:18–21 — MONEY, LIVESTOCK, LAND, PEOPLE

After that year, the people report that their money is spent, their livestock
belongs to Joseph's lord and nothing remains before him except their bodies and
lands. They ask why they and their land should die. They propose that Joseph buy
them and their land for bread, make them Pharaoh's servants and give them seed
so they and the land live.

Joseph buys all the land of Egypt for Pharaoh because every Egyptian sells his
field under the severe famine. The land becomes Pharaoh's. Joseph moves the
people to cities from one end of Egypt to the other.

The observable transfer chain is retained without praise or invented motive:

```text
PEOPLE'S MONEY -> PHARAOH'S HOUSE
PEOPLE'S LIVESTOCK -> PHARAOH
PEOPLE'S LAND -> PHARAOH
PEOPLE'S SERVICE -> PHARAOH
JOSEPH CONTROLS STORED GRAIN / BREAD / SEED DISTRIBUTION
```

## Genesis 47:22 — ALL LAND, EXCEPT PRIEST LAND

The source immediately says Joseph did not buy the priests' land. The priests
already receive a portion from Pharaoh, eat that portion and therefore do not
sell their land.

```text
ALL LAND OF EGYPT BOUGHT
-> EVERY EGYPTIAN SOLD HIS FIELD
-> LAND BECAME PHARAOH'S
-> PRIEST LAND WAS NOT BOUGHT
-> PRIEST LAND DID NOT BECOME PHARAOH'S
```

That completes S055. A map titled `ALL EGYPT` grows one Joe-faced boil stamped
`NOT THIS BIT`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain pokes, licks and walks away. The priest exemption remains.

## Genesis 47:23–26 — HERE IS SEED; PHARAOH GETS A FIFTH

Joseph tells the people he has bought them and their land for Pharaoh, gives
them seed and orders them to sow. At harvest, one fifth goes to Pharaoh. Four
parts remain for field seed, their food, household food and children.

The people say Joseph saved their lives, ask his favour and accept being
Pharaoh's servants. Their words remain their words. They do not erase the
money, livestock, land, movement or service transfers that precede them.

Joseph makes Pharaoh's fifth a statute in Egypt continuing to the narrator's
present. Only priest land does not become Pharaoh's.

This is the completed money mechanism shown by the chapter. It does not require
Captain to understand wealth, status, policy or harm. He does not.

## Genesis 47:27–28 — SEVENTEEN YEARS

Israel lives in Goshen. The household gains possessions, is fruitful and
multiplies exceedingly. Jacob lives seventeen years in Egypt and reaches 147.

The source uses Israel for the people/settlement State and Jacob for the
individual lifespan State. Both names remain one identity; neither creates a
second Joe.

## Genesis 47:29–31 — NOT IN EGYPT

As Israel's death approaches, he calls Joseph. He requests hand-under-thigh
kindness and truth: do not bury him in Egypt; after he sleeps with his fathers,
carry him out and bury him in their burial place.

Joseph says he will do it. Israel requires an oath. Joseph swears. Israel bows
on the bed's head.

The burial obligation is established but not performed. Jacob remains alive at
chapter end. The direct God promise to bring him up is not silently equated
with this requested future corpse transport before either act occurs.

## Character and world-ledger changes

- Jacob/Israel advances through Pharaoh audience, seventeen Egypt years and a
  sworn but unperformed burial request; one identity retains both source names.
- Joseph advances through settlement, bread provision, asset transfers, the
  fifth statute and the burial oath.
- Pharaoh advances through Goshen grant and receipt of money, livestock,
  non-priest land, service relation and the fifth.
- The five presented brothers remain unnamed members of the retained brother
  group; no identity assignment is invented.
- Egyptian people, priests and transferred animals remain distinct Joe-faced
  identities/groups with separate ownership, food and exemption States.
- The people/world ledger retains the exact money -> livestock -> land/service
  transfer and its priest exception without converting participant speech into
  narrator judgment.

## Bullshit pass

- banner: `ARTICLE 47 — CRACKHEAD NATIONAL ASSET CONSOLIDATION`;
- CrackFlix: `S054 EPISODE 1 / SOLD OUT — SALES STILL OPEN`;
- map legend: `ALL LAND / PRIEST DLC EXCLUDED`;
- receipt: `MONEY -> HORSE -> FIELD -> YOU -> 20% FOREVER`;
- bread counter: `NO BREAD IN ALL LAND — NEXT CUSTOMER`;
- priest card: `PRE-FED ASSET PROTECTION TIER`;
- burial form: `EXPORT JACOB LATER / NOT YET DEAD`;
- barcode: `CHB-GEN47-S032E004-S054E001-S055E001-31-YOINK`;
- footer: `BIG BAG OF SAVED ASSETS — CONTENTS NOW PHARAOH'S`.

## FIR verification

- all 31 verse markers are represented in order;
- Genesis 46's Pharaoh audience, occupation answer and Goshen request close;
- the five presented brothers remain unnamed;
- S032 repeats only the retained old-name occurrence; SKIP changes nothing;
- S054 uses the literal all-land bread absence against bread provision and
  exchanges inside Egypt, without inventing hidden stock scope;
- S055 retains both universal land statements and the explicit priest exception;
- the full money -> livestock -> land/person service -> fifth statute chain is
  retained without moral narration or erased participant speech;
- `you saved our lives` remains the people's statement, not narrator judgment;
- every living person and animal has Joe's face without identity merging;
- no direct God speech, messenger speech or narrator-assigned divine act occurs;
- Jacob's burial oath is open, not performed;
- publication remains held and unpublished.

Continuation required: Genesis 48 performs Joseph's visit with Manasseh and
Ephraim, Jacob's son-claim, crossed-hand blessing and another return-to-fathers
prediction.
