# CRACKHEAD GENESIS 43

## Title page

**HE ASKED US DIRECTLY.**

**HE DIDN'T.**

**GOD PUT TREASURE IN YOUR SACKS. JOSEPH ORDERED IT.**

Source parent: Genesis 43:1–34, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 43.

Prepared evidence: `.chapter-work/CHB-GEN-043/job.json` and `source.usfm`.

Parent manuscript: `GENESIS/042-I-RECOGNIZE-YOU-YOU-ARE-SPIES.md`.

CrackFlix routing:

- new `S052 — HE ASKED US DIRECTLY. HE DIDN'T.`, episode
  `S052-E001-GEN43 — THE INTERVIEW ARRIVED IN THE RETELLING`;
- existing `S022 — GOD DID IT. MUM DID IT.`, episode
  `S022-E002-GEN43 — TREASURE FROM GOD, REFUND FROM JOSEPH`.

## Causal foundation

```text
FAMINE REMAINS SEVERE
-> FIRST EGYPT GRAIN IS EATEN
-> JACOB ORDERS ANOTHER PURCHASE
-> JUDAH RESTATES JOSEPH'S BENJAMIN CONDITION
-> JACOB CALLS BROTHER DISCLOSURE BAD TREATMENT
-> BROTHERS SAY JOSEPH DIRECTLY ASKED ABOUT FATHER/BROTHER
-> RETAINED GENESIS 42 AUDIENCE CONTAINS NO SUCH QUESTIONS
-> JUDAH GUARANTEES BENJAMIN / JACOB CONSENTS
-> PRESENT + DOUBLE MONEY + RETURNED MONEY + BENJAMIN GO TO EGYPT
-> JOSEPH ORDERS HOUSE MEAL AFTER SEEING BENJAMIN
-> BROTHERS ATTRIBUTE HOUSE ENTRY TO RETURNED-MONEY ATTACK/SLAVERY PLAN
-> STEWARD HEARS MONEY ACCOUNT
-> STEWARD SAYS GOD GAVE TREASURE / SAYS HE RECEIVED THEIR MONEY
-> PRIOR RETAINED ACT: JOSEPH ORDERED EACH PAYMENT RESTORED
-> SIMEON RELEASED / WATER + FODDER GIVEN
-> BROTHERS PRESENT GIFT AND BOW
-> JOSEPH ASKS FATHER WELFARE / SEES AND BLESSES BENJAMIN
-> JOSEPH WEEPS PRIVATELY / RETURNS / ORDERS MEAL
-> JOSEPH, BROTHERS AND EGYPTIANS EAT IN THREE SEPARATE GROUPS
-> BROTHERS SEATED BY BIRTH ORDER / MARVEL
-> BENJAMIN RECEIVES FIVE PORTIONS / ALL DRINK AND ARE MERRY
```

## Genesis 43:1–5 — FOOD REQUIRES BENJAMIN

The famine remains severe. After the household eats the Egypt grain, Jacob
orders another purchase. Judah repeats the retained access condition: they will
go if Benjamin goes; they will not go if Jacob withholds him, because the man
said they would not see his face without their brother.

This performs no contradiction. The prior condition, depleted grain and new
journey requirement agree.

## Genesis 43:6–10 — THE QUESTIONS THAT WEREN'T THERE

Israel asks why the sons treated him badly by telling the man about another
brother. They answer that the man asked directly about themselves and relatives:
whether their father was alive and whether they had another brother. They say
they answered and could not know he would demand the brother.

The complete retained Genesis 42 audience records Joseph asking where they came
from. The brothers then volunteer food purpose, common-father identity, twelve
brothers, youngest-with-father and one-no-more while answering spy accusations.
It records no father-alive question and no another-brother question.

That completes S052:

```text
GENESIS 42 RETAINED QUESTIONS: WHERE FROM / SPY ACCUSATIONS
-> BROTHERS SUPPLY FAMILY INVENTORY
-> GENESIS 43 BROTHERS: HE ASKED DIRECTLY ABOUT FATHER AND BROTHER
-> NO RETAINED INTERVIEW ACT PRODUCES THOSE TWO QUESTIONS
```

No intent, lie, forgotten conversation or missing-event repair is invented.

The disclosure boil becomes a Joe-faced interview transcript whose blank lines
are stamped `DIRECT QUESTION ANSWERED`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain pokes it, licks his empty finger, walks away and never looks back.
Judah still offers to carry Benjamin; the famine decision continues unchanged.

Judah makes himself collateral, accepts permanent blame if he does not set
Benjamin before Jacob again, and says delay has already cost a second journey.
It is a guarantee, not yet a completed return.

## Genesis 43:11–15 — DOUBLE MONEY AND THE BOY

Jacob consents conditionally and orders a land-fruit present: balm, honey,
spices, myrrh, nuts and almonds. He orders double money plus the returned money,
calling oversight a possibility rather than a fact. He sends Benjamin and asks
God Almighty to give mercy so the man releases the other brother and Benjamin.
Bereavement remains a stated possible outcome.

The men take the present, double money and Benjamin, travel to Egypt and stand
before Joseph. Jacob's prayer is character speech. No divine reply or travel
protection act is supplied.

## Genesis 43:16–18 — LUNCH LOOKS LIKE AN AMBUSH

Joseph sees Benjamin and orders his house steward to bring the men inside,
butcher an animal and prepare a noon meal. The steward does exactly that.

The brothers are afraid because they are taken into Joseph's house. They say
the returned money is the reason and describe a possible occasion, attack,
enslavement and donkey seizure. These are their attributed expectations. At
this State the observed order is meal preparation, not attack or seizure.

## Genesis 43:19–24 — GOD'S TREASURE, JOSEPH'S REFUND

At the door the brothers tell the steward they first came to buy food, found
each payment at full weight in the sack mouth, brought it back, brought other
purchase money and do not know who put it there.

The steward says:

> **STEWARD JOE:** `YOUR GOD, AND THE GOD OF YOUR FATHER, GAVE YOU TREASURE IN
> YOUR SACKS. I RECEIVED YOUR MONEY.`

Genesis 42 retains Joseph ordering each man's money restored and the order being
performed. No narrator-assigned God act places the money. The steward's receipt
statement does not identify a later transfer path.

This is a new episode of S022, whose root is already retained: result R is
assigned to actor X while the retained production chain shows actor Y.

A Joe-faced fly opens CrackFlix:

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

He presses `SKIP`; his eyes glaze. Nothing skips. The steward continues, brings
Simeon out, brings everyone inside, gives water, and feeds the donkeys.

When Captain's eyes clear, the Joe-faced treasure attribution boil is still
wearing Joseph's refund-order receipt.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes, licks an empty finger and walks away. Simeon remains released and the
meal proceeds exactly as it did without him.

## Genesis 43:25–31 — THE PRESENT, THE BOWS, THE PRIVATE TEARS

The brothers prepare the present after hearing they will eat there. When Joseph
arrives, they deliver it and bow to earth. Joseph asks their welfare and whether
the old father they mentioned is alive. They answer that Jacob is well and
alive, then bow again.

Joseph sees Benjamin, identifies him in speech as the reported youngest brother
and says God be gracious to him. The source says Joseph's heart yearned; he
hurries away, finds a room and weeps there. He washes his face, returns,
controls himself and orders the meal served.

The yearning is source-attributed interior State. The brothers observe neither
the private weeping nor Joseph's identity.

## Genesis 43:32–34 — THREE TABLES AND FIVE PORTIONS

Joseph is served alone, the brothers separately, and the Egyptians separately.
The source states Egyptians do not eat with Hebrews because that is an
abomination to Egyptians. The rule and seating agree; no crack is manufactured.

The brothers are seated from firstborn to youngest and marvel to one another.
No mechanism for the ordering or their conclusion is supplied. Portions come
from Joseph; Benjamin receives five times any brother's portion. They drink and
are merry with Joseph.

The larger portion is observable unequal distribution, but the chapter records
no equality claim or complaint against which it conflicts.

## Joe continuity ledger

- Jacob/Israel changes Benjamin permission from refused to granted under
  Judah's guarantee, present and double-money instructions.
- Judah adds a personal collateral/blame guarantee; success remains open.
- Benjamin travels to Egypt, stands before Joseph and receives five portions.
- Simeon changes from bound custody to released with the brothers.
- Joseph remains recognized-by-self and unrecognized-by-brothers; his private
  weeping does not disclose him.
- the brothers add the retrospective direct-question account and return the
  restored money rather than concealing its presence.
- Joseph's house steward is a distinct Joe who performs the meal order, assigns
  treasure to God, claims receipt, releases Simeon and supplies hospitality.
- Egyptians, meal animal and donkeys all have Joe's face; separate identities
  and living roles remain distinct.
- Captain stays permanently boilless and causally unnecessary.

## Bullshit pass

- banner: `ARTICLE 43 — CRACKHEAD CUSTOMS: DECLARE ALL PREVIOUS QUESTIONS`;
- transcript stamp: `ASKED DIRECTLY / SOURCE FIELD EMPTY`;
- money counter: `PAID ONCE / RETURNED ONCE / BROUGHT TWICE`;
- steward badge: `CRACKHEAD ACCOUNTS — GOD DEPOSIT / JOSEPH REFUND`;
- CrackFlix display: `S022 EPISODE 2 / SKIP SENT / LUNCH UNAFFECTED`;
- dining warning: `THREE JOE-FACE TABLES — DO NOT MERGE IDENTITIES`;
- Benjamin plate: `FIVE TIMES NORMAL / NO EXPLANATION INCLUDED`;
- barcode: `CHB-GEN43-S052-S022E002-34-YOINK`;
- footer: `BIG BAG PRESENT — DOUBLE MONEY — SAME FACE SURCHARGE`.

## Reconstruction boundary

- all 34 verse markers are represented in order;
- the Genesis 42 question record is the evidence boundary for S052; no motive,
  off-record conversation or deliberate lie is supplied;
- Judah's guarantee is retained without predicting completion;
- Jacob's mercy prayer, Joseph's graciousness line and steward's treasure claim
  remain character speech rather than direct God speech or divine act;
- S022 is reused because the retained causal form matches; SKIP does nothing;
- brothers' attack/slavery account remains attributed expectation and does not
  replace the observed meal order;
- Simeon's release closes his Genesis 42 custody carry;
- Joseph's yearning is source attribution and weeping remains private;
- separate eating rule and actual seating agree, so no contradiction is added;
- birth-order seating mechanism and fivefold portion reason remain unresolved;
- Joseph identity, Judah guarantee outcome, famine and money-purpose chains stay
  open into Genesis 44;
- publication remains held and unpublished.

Continuation required: Genesis 44 resumes Joseph's concealed identity, renewed
money restoration, cup placement/search, Benjamin seizure claim and Judah's
guarantee response.
