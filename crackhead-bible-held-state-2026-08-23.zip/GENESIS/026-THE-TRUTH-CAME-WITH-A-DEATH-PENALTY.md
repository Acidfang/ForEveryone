# CRACKHEAD GENESIS 26

## Title page

**I HID THAT SHE WAS MY WIFE SO YOU WOULDN'T KILL ME.**

**NOW WE KNOW SHE'S YOUR WIFE, ANYONE WHO TOUCHES YOU DIES.**

Source parent: Genesis 26:1–35, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 26.

Parent manuscript: `GENESIS/025-ABOUT-TO-DIE-WALKS-AWAY.md`.

Primary CrackFlix: `S019 — THE HIDDEN STATE TRIGGERS THE PROTECTION.`, episode
`S019-E001-GEN26 — SISTER UNTIL PROTECTED`.

Routed CrackFlix: `S020 — YOU HATE ME. WE DID NOTHING BUT GOOD.`, episode
`S020-E001-GEN26 — SENT AWAY IN PEACE`.

Repeated-material reference: S011's retained wife-presented-as-sister segment.
That segment repeats; S011's punishment root does not complete here.

## Causal foundation

```text
SECOND-NAMED FAMINE -> ISAAC GOES TO ABIMELECH AT GERAR
-> LORD APPEARS: DO NOT GO EGYPT / LIVE HERE / LAND-OATH PROMISE
-> ISAAC LIVES IN GERAR
-> MEN ASK ABOUT REBEKAH
-> ISAAC: SHE IS MY SISTER
-> SOURCE ATTRIBUTES FEAR / LEST-I-DIE THOUGHT
-> LONG TIME PASSES
-> ABIMELECH SEES ISAAC CARESSING REBEKAH
-> ABIMELECH: SHE IS SURELY YOUR WIFE
-> ISAAC: I SAID IT LEST I DIE
-> ABIMELECH: SOMEONE COULD HAVE LAIN WITH HER / GUILT RISK
-> ABIMELECH ORDERS DEATH FOR ANYONE TOUCHING ISAAC OR REBEKAH
-> ISAAC SOWS / REAPS HUNDREDFOLD / LORD BLESSES
-> ISAAC BECOMES VERY GREAT / PHILISTINES ENVY
-> PHILISTINES STOP ABRAHAM-ERA WELLS
-> ABIMELECH SENDS ISAAC AWAY AS MUCH MIGHTIER
-> ISAAC DEPARTS / REOPENS NAMED WELLS
-> SERVANTS FIND FLOWING WATER
-> GERAR HERDSMEN CLAIM WATER / TWO WELL DISPUTES
-> ISAAC MOVES / THIRD WELL UNDISPUTED / REHOBOTH
-> ISAAC GOES TO BEERSHEBA
-> LORD APPEARS: WITH YOU / BLESS / MULTIPLY
-> ALTAR + CALL + TENT + WELL
-> ABIMELECH + AHUZZATH + PHICOL ARRIVE
-> ISAAC: WHY COME? YOU HATE ME AND SENT ME AWAY
-> DELEGATION: WE DID NOTHING BUT GOOD / SENT YOU IN PEACE
-> COVENANT REQUEST / FEAST / MUTUAL OATH / PEACEFUL DEPARTURE
-> SAME-DAY WELL WATER REPORT / SHIBAH / BEERSHEBA
-> ESAU AT 40 TAKES JUDITH + BASEMATH
-> MARRIAGES GRIEVE ISAAC + REBEKAH SPIRITS
```

## Genesis 26:1–5 — DO NOT GO TO EGYPT

A famine occurs in addition to the famine from Abraham's days. Isaac goes to
Abimelech, king of the Philistines, at Gerar.

The same name and office occurred earlier, but this chapter supplies no parent,
age, accession statement or explicit `same man` relation. `Abimelech of Genesis
26` therefore receives his own Joe identity with a retained unresolved mapping
to the Genesis 20–21 Abimelech. The later Phicol recurrence gets the same
protection against an unsupported merge.

The LORD appears to Isaac:

> **CRACKHEAD GOD:** `DO NOT GO DOWN TO EGYPT.`
>
> `LIVE IN THE LAND I TELL YOU ABOUT.`
>
> `I WILL BE WITH YOU AND BLESS YOU.`
>
> `I WILL GIVE THESE LANDS TO YOU AND YOUR OFFSPRING.`
>
> `I WILL ESTABLISH MY OATH TO ABRAHAM.`
>
> `I WILL MULTIPLY YOUR OFFSPRING LIKE THE STARS.`
>
> `ALL NATIONS WILL BE BLESSED IN YOUR OFFSPRING.`
>
> `ABRAHAM OBEYED MY VOICE AND KEPT MY REQUIREMENTS, COMMANDMENTS, STATUTES`
> `AND LAWS.`

The appearance, command, Abraham-grounded promise and stated reason remain one
God-only speech act. Isaac's next recorded act is living in Gerar. The chapter
does not narrate an attempted Egypt journey or verbal reply.

## Genesis 26:6–7 — SISTER AGAIN

Isaac lives in Gerar. The men of the place ask about Rebekah.

> **ISAAC JOE:** `SHE IS MY SISTER.`

The source attributes fear to Isaac and supplies the stated thought: he is
afraid to say `my wife` lest the men kill him because Rebekah is beautiful.
This is source testimony, not a conclusion drawn by the fly from his face.

The wife-presented-as-sister segment has already occurred in S011-E001 and
S011-E002. Captain recognizes only that retained material:

> **CAPTAIN CRACKHEAD FLY:** `SKIP.`

Glazed eyes. Nothing skips. The men have still asked, Isaac has still answered,
Rebekah remains his wife, and a long time still has to pass.

This does not make Genesis 26 an S011 episode. No uninformed Gerar Joe takes
Rebekah and no punishment follows. The repeated setup proceeds into S019's
different causal result.

## Genesis 26:8–11 — THE REVEALED WIFE GETS THE PROTECTION

After Isaac has been there a long time, Abimelech looks from a window and sees
Isaac caressing Rebekah his wife.

> **ABIMELECH JOE:** `SHE IS SURELY YOUR WIFE.`
>
> `WHY DID YOU SAY, "SHE IS MY SISTER"?`

> **ISAAC JOE:** `BECAUSE I SAID, "LEST I DIE BECAUSE OF HER."`

> **ABIMELECH JOE:** `WHAT HAVE YOU DONE TO US?`
>
> `ONE OF THE PEOPLE MIGHT EASILY HAVE LAIN WITH YOUR WIFE.`
>
> `YOU WOULD HAVE BROUGHT GUILT ON US.`

Then Abimelech commands all the people:

> **ABIMELECH JOE:** `WHOEVER TOUCHES THIS MAN OR HIS WIFE WILL SURELY DIE.`

That order completes S019:

```text
ISAAC WITHHOLDS WIFE STATE -> STATES DEATH AVOIDANCE
WIFE STATE BECOMES OBSERVABLE
-> AUTHORITY ORDERS DEATH AGAINST ANYONE TOUCHING ISAAC OR WIFE
```

The source does not prove whether Isaac's forecast would otherwise have
occurred. It does show that the protection against the stated threat is issued
only after the relationship he concealed becomes known.

Isaac's survival-strategy boil grows a Joe-faced emergency information curtain.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. The command remains in force and no
Gerar Joe touches either spouse in the retained chapter.

## Genesis 26:12–17 — BLESSED, ENVIED, SENT AWAY

Isaac sows in that land and reaps one hundred times what he planted in the same
year. The LORD blesses him. Isaac grows great, then increasingly great, then
very great. He holds flocks, herds and a great household. The Philistines envy
him.

The Philistines stop and fill with earth all wells Abraham's servants had dug.

> **ABIMELECH JOE:** `GO AWAY FROM US.`
>
> `YOU ARE MUCH MIGHTIER THAN WE ARE.`

Isaac departs, camps in the Gerar valley and lives there. The command and
departure are observable; no private negotiation or forced-removal action is
invented.

## Genesis 26:18–22 — STOPPED, REOPENED, DISPUTED, MOVED

Isaac re-digs the Abraham-era wells that the Philistines stopped after Abraham's
death and restores Abraham's names for them. This preserves well continuity; it
does not create a new Abraham act after death.

Isaac's servants dig in the valley and find flowing water.

> **GERAR HERDSMEN JOES:** `THE WATER IS OURS.`

They argue with Isaac's herdsmen. Isaac names that well Esek because they
contended with him. His people dig another well; that is also disputed, and he
names it Sitnah.

Isaac moves and digs a third well. Nobody argues over it.

> **ISAAC JOE:** `NOW THE LORD HAS MADE ROOM FOR US.`
>
> `WE WILL BE FRUITFUL IN THE LAND.`

He names it Rehoboth. Competing ownership words and repeated movement are
retained, but no title deed, violence, adjudicator or resolved ownership of the
first two wells is supplied.

## Genesis 26:23–25 — THE SECOND APPEARANCE

Isaac goes to Beersheba. The LORD appears that same night:

> **CRACKHEAD GOD:** `I AM THE GOD OF ABRAHAM YOUR FATHER.`
>
> `DO NOT BE AFRAID. I AM WITH YOU.`
>
> `I WILL BLESS YOU AND MULTIPLY YOUR OFFSPRING FOR MY SERVANT ABRAHAM'S SAKE.`

Isaac builds an altar, calls on the LORD's name, pitches his tent, and has his
servants dig a well. These are four retained acts after the appearance; the
source gives no additional God dialogue or altar contents.

## Genesis 26:26–29 — NOTHING BUT GOOD

Abimelech comes from Gerar with Ahuzzath his friend and Phicol, captain of his
army. Ahuzzath is a new named Joe. This Phicol has the same name and office as
the Genesis 21 figure, but personal identity remains unresolved rather than
silently merged.

> **ISAAC JOE:** `WHY HAVE YOU COME TO ME?`
>
> `YOU HATE ME AND SENT ME AWAY FROM YOU.`

The delegation answers:

> **ABIMELECH, AHUZZATH AND PHICOL JOES:** `WE SAW PLAINLY THAT THE LORD WAS`
> `WITH YOU.`
>
> `LET THERE BE AN OATH AND A COVENANT BETWEEN US.`
>
> `DO US NO HARM.`
>
> `WE HAVE NOT TOUCHED YOU.`
>
> `WE HAVE DONE NOTHING TO YOU BUT GOOD.`
>
> `WE SENT YOU AWAY IN PEACE.`
>
> `YOU ARE NOW BLESSED OF THE LORD.`

S020 retains the disagreement without deciding which description secretly
means more:

```text
ACKNOWLEDGED ACT: ABIMELECH SENT ISAAC AWAY
ISAAC DESCRIPTION: YOU HATE ME
DELEGATION DESCRIPTION: NOTHING BUT GOOD / SENT IN PEACE
NO INTERVENING CHANGE TO THE SENDING ACT
```

The same act carries incompatible spoken classifications. This is a distinct
root, not allowed to contaminate S019.

> **CRACKFLIX:** `S020 — YOU HATE ME. WE DID NOTHING BUT GOOD.`

The delegation's covenant-status boil displays a tiny Joe-faced peace parcel
labelled `RETURN TO SENDER`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. The covenant request proceeds.

## Genesis 26:30–33 — FEAST, OATH, WATER

Isaac makes the delegation a feast. They eat and drink. In the morning they
swear an oath to one another. Isaac sends them away and they depart in peace.

This later departure supplies a new peaceful State; it does not travel backward
and replace the earlier sending act disputed in S020.

The same day Isaac's servants report:

> **ISAAC'S SERVANTS:** `WE HAVE FOUND WATER.`

Isaac names the well Shibah. The source connects that name to Beersheba's name
`to this day`. It does not erase the earlier Beersheba oath/well history from
Genesis 21; both witness Moments remain.

## Genesis 26:34–35 — ESAU'S TWO WIVES

At age forty, Esau takes two wives:

- Judith, daughter of Beeri the Hittite;
- Basemath, daughter of Elon the Hittite.

Judith, Beeri, Basemath and Elon are four distinct new Joes. Later similar or
different spouse names must reconstruct before any identity merge or correction.

The source states that the two wives/marriages grieve Isaac's and Rebekah's
spirits. The fly does not assign a cause, quote an objection, infer facial
expressions or claim how either wife acts beyond becoming Esau's wife.

## Character and world-ledger changes

- Isaac: obeys Gerar boundary; repeats sister presentation; is observed with
  Rebekah; states death concern; receives protection; prospers; is sent away;
  reopens/digs/names wells; receives second appearance; covenants; receives
  water report; becomes father-in-law through Esau's two marriages.
- Rebekah: presented as sister while remaining wife; observed being caressed;
  covered by Abimelech's death-protection order; becomes Esau wives' mother-in-law;
  source records spirit grief.
- Genesis-26 Abimelech: king at Gerar; observes wife relation; confronts Isaac;
  issues protection; sends Isaac away; later seeks covenant and describes prior
  conduct as nothing but good/peace. Relation to earlier Abimelech unresolved.
- Ahuzzath: named as Abimelech's friend; joins covenant delegation.
- Genesis-26 Phicol: captain of Abimelech's army; joins delegation; relation to
  Genesis-21 Phicol unresolved.
- men/people of Gerar: ask relationship question and receive protection order.
- Philistines: source attributes envy and Abraham-well stoppage to group.
- Isaac's servants/herdsmen: re-dig/find wells, receive disputes, report water.
- Gerar herdsmen: claim first flowing water and dispute two wells.
- Esau: takes Judith and Basemath as wives at forty.
- Judith/Beeri/Basemath/Elon: new Hittite marriage-line Joe identities.
- Isaac's flocks/herds: living Joe-faced possessions; growth contributes to his
  very-great State but does not speak.

## Fuck-up pass

- Gerar -> `GRR-AR`, where every map growls at Isaac.
- famine -> `FAM-IN`, a family-entry sign with no food behind it.
- hundredfold -> `CRACKHEAD RETURN: 100× / TAX BASIS UNRESOLVED`.
- stopped wells -> literal corks with Philistine Joe faces.
- Esek -> `HE'S-SICK`, a disputed-water medical kiosk.
- Sitnah -> `SIT-NOW`, a chair lowered into the second well.
- Rehoboth -> `REHAB-BOTH`, treatment for both arguing well crews.
- Beersheba -> `BEER-SHE-BAR`, a Joe-faced bar built over Shibah well.
- Ahuzzath -> `A-WHO'S-THAT JOE`, wearing an official friend badge.
- Phicol -> `FEE-CALL JOE`, charging the covenant delegation by phone minute.
- Shibah -> `SHE-BAR`, the well producing a bar instead of water.
- Judith -> `YOU-DID-IT JOE`, blamed by a background sign for marrying.
- Beeri -> `BEERY JOE`, permanently standing beside Beer-Sheba.
- Basemath -> `BASE-MATH JOE`, calculating two wives in base Joe.
- Elon -> `E-LONG JOE`, holding an unnecessarily long marriage receipt.
- protection order -> `WIFE DISCLOSED / CUSTOMER NOW ELIGIBLE FOR SECURITY`.
- peace covenant -> `NOTHING BUT GOOD™ / EXCLUDES BEING SENT AWAY`.

## God-line boundary

Genesis 26 directly records two LORD appearances and their speech. It also
attributes Isaac's hundredfold prosperity to the LORD's blessing. Those acts
enter the God ledger. Isaac's Rehoboth statement and the delegation's God-with-
Isaac statement remain character speech. God does not comment on the sister
presentation, well disputes, S019, S020, covenant or Esau's marriages.

## FIR verification

- All 35 verse markers are covered in order.
- The famine is distinguished from Abraham's earlier famine.
- Both direct LORD appearances, commands, promises and stated Abraham basis are
  God-only and remain at their source Moments.
- Same-name Abimelech/Phicol personal identity is unresolved, not assumed.
- S011 is referenced only for the exact repeated wife-as-sister material; its
  take/punish root is explicitly not claimed.
- `SKIP` occurs only because the segment is retained twice earlier; it changes
  no act or panel outcome.
- S019 closes only after concealed wife State is exposed and the resulting
  protection order is spoken.
- Source-attributed fear/thought/envy/grief are not presented as fly inference.
- Blessing, sowing, harvest, growth, possessions, envy, stopped wells and
  sending-away remain in causal order.
- Abraham-era wells retain names/history across stopping and re-digging.
- Both disputed wells and the undisputed third well remain distinct.
- S020 preserves two spoken classifications of one acknowledged sending act
  without choosing hidden meaning.
- Feast/oath/later peaceful departure do not rewrite the earlier act.
- Esau's age, two wives, both fathers and Hittite relations are retained.
- Captain appears after each completed contradiction, says only `YOINK!`, has
  no boils and changes nothing.
- No unrelated punishment, touching, violence, title deed, motive or identity
  merge is invented.
- Manuscript remains held and unpublished.

Continuation required: Genesis 27 receives Isaac's age/blindness, venison-based
blessing instruction, Rebekah's overhearing and counter-plan, Jacob's identity
deception, goat-skin substitution, blessing transfer, Esau's return/cry, limited
remaining blessing, kill statement, flight instruction and differing parental
reasons for Jacob's departure.
