# CRACKHEAD GENESIS 14

## Title page

**FOUR KINGS. FIVE KINGS. 318 HOUSE JOES. A LOT GETS TAKEN.**

Source parent: Genesis 14:1–24, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 14.

Parent manuscript: `GENESIS/013-TOO-MUCH-STUFF-ONE-FIELD.md`.

CrackFlix crossover: none closed in this chapter.

## Causal foundation

```text
FIVE KINGS SERVE CHEDORLAOMER 12 YEARS
-> REBEL YEAR 13
-> FOUR-KING CAMPAIGN YEAR 14 -> MULTIPLE PEOPLES STRUCK
-> FOUR KINGS VS FIVE KINGS AT SIDDIM
-> TAR-PIT/HILL FLIGHT
-> SODOM/GOMORRAH GOODS + FOOD TAKEN
-> LOT + GOODS TAKEN FROM SODOM
-> ESCAPEE REPORTS TO ABRAM HEBREW
-> ABRAM + 318 HOUSE-TRAINED MEN + ALLY RELATION
-> NIGHT DIVISION/STRIKE/PURSUIT
-> LOT + GOODS + WOMEN + PEOPLE RECOVERED
-> SODOM KING MEETS ABRAM
-> MELCHIZEDEK BRINGS BREAD/WINE + BLESSES
-> ABRAM GIVES TENTH
-> SODOM KING REQUESTS PEOPLE / OFFERS GOODS
-> ABRAM REFUSES SODOM PROPERTY EXCEPT FOOD/ALLY PORTIONS
```

## Genesis 14:1–4 — THE KING SPREADSHEET

Four-king coalition:

- Amraphel of Shinar;
- Arioch of Ellasar;
- Chedorlaomer of Elam;
- Tidal of Goiim.

Five-king coalition:

- Bera of Sodom;
- Birsha of Gomorrah;
- Shinab of Admah;
- Shemeber of Zeboiim;
- unnamed king of Bela/Zoar.

The five join in Siddim/Salt Sea valley. They serve Chedorlaomer twelve years
and rebel in year thirteen.

Background table: `CRACKHEAD WAR LEDGER — 4 v 5, CAUSE FIELD: SERVICE/REBELLION`.

No ideology, tax amount, treaty wording or private motive is supplied.

## Genesis 14:5–7 — YEAR FOURTEEN CAMPAIGN

In year fourteen, Chedorlaomer and allied kings strike:

- Rephaim at Ashteroth Karnaim;
- Zuzim in Ham;
- Emim at Shaveh Kiriathaim;
- Horites at Mount Seir as far as El Paran by the wilderness;
- Amalekite country at En Mishpat/Kadesh;
- Amorites at Hazazon Tamar.

Every living combatant has Joe's face. Names remain separate people/place
addresses; no later identity is projected backward.

## Genesis 14:8–12 — TAR PITS AND A LOT OF CAPTURE

The five kings array against the four in Siddim. The valley contains tar pits.
Sodom and Gomorrah's kings flee; some fall there; survivors flee to hills.

The victors take all Sodom/Gomorrah goods and food. They also take A Lot Joe,
who now lives in Sodom, and his goods.

This continues Genesis 13's movement:

```text
LOT TENTS TOWARD SODOM -> LOT LIVES IN SODOM -> SODOM DEFEATED -> LOT CAPTURED
```

The comic does not call his earlier choice morally causal; it retains the
geographic exposure that makes capture possible.

Tar-pit label: `CRACKHEAD NON-SLIP BATTLEFIELD — SOME ASSEMBLY REQUIRED`.

## Genesis 14:13–16 — 318 HOUSE JOES

An escapee tells Abram the Hebrew. Abram lives by Mamre the Amorite's oaks.
Mamre and brothers Eshcol and Aner are Abram's allies.

When Abram hears his relative was captured, he leads 318 trained men born in
his household and pursues to Dan. At night Abram and servants divide against
the captors, strike them and pursue to Hobah left/north of Damascus.

Abram brings back:

- all goods;
- Lot and Lot's goods;
- women;
- other people.

This creates Abram's first observed armed-rescue capability. It does not supply
weapons, casualty count, formation detail or a generic right to wage war.

Badge: `CRACKHEAD HOUSEHOLD SECURITY — STAFF: 318`.

## Genesis 14:17–20 — MEL-CHEESE-A-DECK

The king of Sodom meets Abram at Shaveh/King's Valley after Abram returns from
striking Chedorlaomer and allies.

Melchizedek Joe, king of Salem and priest of God Most High, brings bread and
wine.

> **MELCHIZEDEK JOE:** `BLESSED BE ABRAM OF GOD MOST HIGH, POSSESSOR OF HEAVEN
> AND EARTH.`
>
> `BLESSED BE GOD MOST HIGH, WHO DELIVERED YOUR ENEMIES INTO YOUR HAND.`

Abram gives him one tenth of all.

Display: **Mel-Cheese-A-Deck Joe**, serving bread, wine and inexplicable cheese
on a literal deck. Cheese is production bullshit, not source offering.

This encounter receives a retained occurrence address for later religious or
ancient-text witnesses. Any later retelling of this same meeting must import the
same canonical panel rather than redraw it once identity closes.

## Genesis 14:21–24 — NOT EVEN YOUR SANDAL STRAP

> **SODOM KING JOE:** `GIVE ME THE PEOPLE. KEEP THE GOODS.`

Abram answers:

> **ABRAM JOE:** `I LIFTED MY HAND TO GOD MOST HIGH, POSSESSOR OF HEAVEN AND
> EARTH.`
>
> `I'M NOT TAKING YOUR THREAD, SANDAL STRAP OR ANYTHING.`
>
> `YOU DON'T GET TO SAY YOU MADE ABRAM RICH.`
>
> `ONLY WHAT THE YOUNG MEN ATE.`
>
> `ANER, ESHCOL AND MAMRE GET THEIR OWN PORTIONS.`

Abram distinguishes his refusal from the young men's consumed food and allies'
shares. He does not surrender their portions in his own vow.

This is not contradiction with Genesis 12 wealth retention: the property,
speaker, stated risk and choice are different Moments. No complaint follows the
refusal here.

## Character and world-ledger changes

- Lot: Sodom resident, captured with goods, recovered by Abram.
- Abram: first called Hebrew; has 318 trained house-born men and three named
  allies; conducts night rescue; recovers people/property; receives blessing;
  gives tenth; refuses Sodom goods while preserving others' portions.
- Melchizedek: distinct king/priest Joe; brings bread/wine; blesses Abram and God
  Most High; receives tenth.
- Sodom king: defeated/flees, later meets Abram and requests people while
  offering goods.
- regional nations: service, rebellion, campaign, battle and capture histories
  become time-bounded nation-ledger Moments.

## Fuck-up pass

- Chedorlaomer -> Cheddar-Lay-Omer background nameplate.
- Siddim -> Sit-'Em Valley.
- Salt Sea -> Assault Sea.
- Lot -> A Lot Joe.
- Mamre -> Mammary.
- Dan -> Damn.
- Damascus -> Damn-Ask-Us.
- Melchizedek -> Mel-Cheese-A-Deck.
- Salem -> Say-Lem.
- tithe -> `CRACKHEAD EXACTLY ONE-TENTH RECEIPT`.

## FIR verification

- All 24 verse markers are covered in order.
- Twelve-year service, year-thirteen rebellion and year-fourteen campaign remain
  distinct.
- Four/five coalition identities and all campaign locations are retained.
- Battle flight precedes goods/food/people capture.
- Lot's Sodom residence provides the capture exposure without invented blame.
- Escapee report precedes Abram mobilization.
- 318 trained-household count, night division and pursuit bounds are retained.
- Recovery precedes both king encounters.
- Melchizedek blessing precedes Abram's tenth.
- Sodom offer precedes Abram's bounded refusal.
- No contradiction series or Captain appearance is manufactured.
- Manuscript remains held and unpublished.

Continuation required: Genesis 15 receives vision/reward, Abram's childless
objection, heir correction, star-count promise, belief/righteousness statement,
land question, divided-animal covenant procedure, darkness prophecy and land
boundary covenant.
