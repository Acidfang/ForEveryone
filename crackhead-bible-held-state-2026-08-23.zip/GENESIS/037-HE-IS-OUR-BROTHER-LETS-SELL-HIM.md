# CRACKHEAD GENESIS 37

## Title page

**HE IS OUR BROTHER.**

**HE IS OUR FLESH.**

**LET'S SELL HIM.**

**WE MADE THE BLOODY ROBE.**

**WE FOUND THIS.**

Source parent: Genesis 37:1–36, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 37.

Parent manuscript: `GENESIS/036-THE-WIFE-LEDGER-CHANGED-NAMES.md`.

CrackFlix routing:

- `S040 — HE IS OUR BROTHER, OUR FLESH. LET'S SELL HIM.`, episode
  `S040-E001-GEN37 — THE MERCIFUL SALE`;
- `S041 — WE MADE THIS. WE FOUND THIS.`, episode
  `S041-E001-GEN37 — EXAMINE THE EVIDENCE WE MANUFACTURED`.

Held, not routed:

- Joseph's two dreams and the family interpretations remain open until later
  acts establish or fail the bowing relations.
- Jacob asks whether Joseph's mother will bow although Rachel's death is already
  retained. The source does not explicitly identify the dream's moon as Rachel
  or close the predicted bowing act here.
- Reuben says `the child is no more` after observing only that Joseph is absent
  from the pit. `No more` may address pit-presence, custody or life; the chapter
  does not isolate his asserted meaning.
- all Jacob's sons and daughters rise to comfort him. The source does not map
  which individual comfort acts belong to which earlier robe/pit/sale actors.

## Causal foundation

```text
JACOB LIVES IN CANAAN
-> JOSEPH AGE 17 FEEDS FLOCK WITH BROTHERS / BILHAH-ZILPAH SONS
-> JOSEPH BRINGS FATHER EVIL REPORT OF THEM
-> ISRAEL LOVES JOSEPH MORE / MAKES MANY-COLORED TUNIC
-> BROTHERS SEE PREFERENTIAL LOVE
-> BROTHERS HATE / CANNOT SPEAK PEACEABLY
-> JOSEPH DREAMS SHEAVES / TELLS BROTHERS
-> BROTHERS INTERPRET REIGN/DOMINION / HATE MORE
-> JOSEPH DREAMS SUN/MOON/ELEVEN STARS BOW / TELLS FAMILY
-> JACOB REBUKES / INTERPRETS FAMILY BOWING
-> BROTHERS ENVY / FATHER KEEPS SAYING
-> BROTHERS FEED FLOCK AT SHECHEM
-> ISRAEL SENDS JOSEPH TO CHECK BROTHERS/FLOCK + RETURN WORD
-> JOSEPH TRAVELS HEBRON -> SHECHEM
-> UNNAMED MAN FINDS JOSEPH WANDERING / DIRECTS HIM TO DOTHAN
-> JOSEPH FINDS BROTHERS
-> BROTHERS SEE FROM AFAR / CONSPIRE TO KILL
-> PROPOSE KILL / PIT / EVIL-ANIMAL REPORT / TEST DREAMS
-> REUBEN OPPOSES LIFE-TAKING / PROPOSES EMPTY PIT
-> SOURCE ASSIGNS REUBEN RESTORATION PURPOSE
-> BROTHERS STRIP TUNIC / THROW JOSEPH IN EMPTY DRY PIT
-> BROTHERS SIT TO EAT
-> ISHMAELITE CARAVAN APPROACHES WITH CAMELS/GOODS FOR EGYPT
-> JUDAH PROPOSES SALE BECAUSE BROTHER/FLESH
-> BROTHERS LISTEN
-> MIDIANITE MERCHANTS DRAW/LIFT JOSEPH
-> JOSEPH SOLD TO ISHMAELITES FOR 20 SILVER
-> MERCHANTS BRING JOSEPH TO EGYPT
-> REUBEN RETURNS / PIT EMPTY / TEARS CLOTHES / REPORTS CHILD NO MORE
-> GROUP KILLS MALE GOAT / DIPS TUNIC IN BLOOD
-> GROUP PRESENTS TUNIC AS FOUND / ASKS JACOB TO EXAMINE
-> JACOB RECOGNIZES TUNIC / CONCLUDES ANIMAL DEVOURED JOSEPH
-> JACOB MOURNS / REFUSES COMFORT
-> MIDIANITES SELL LIVING JOSEPH IN EGYPT TO POTIPHAR
```

## Genesis 37:1–4 — THE REPORT, THE LOVE, THE ROBE

Jacob lives in Canaan, the land of his father's travels.

Joseph is seventeen. He feeds the flock with his brothers and is specifically
with the sons of Bilhah and Zilpah, called his father's wives. Joseph brings an
evil report of them to their father. `Evil report` is the source label; no act,
quotation, truth test, witness or recipient reaction is supplied.

The source states Israel loves Joseph more than all his children because Joseph
is the son of his old age. Israel makes Joseph a tunic of many colors.

The brothers see that their father loves Joseph more than all his brothers. The
source says they hate Joseph and cannot speak peaceably to him. Love, hate and
speech incapacity are direct source testimony, not conclusions from identical
Joe faces.

The tunic is an observable preference object. No design beyond `many colors`,
material, sleeve length, laborer or ceremony is supplied.

## Genesis 37:5–11 — TWO DREAMS, THREE INTERPRETATIONS

Joseph dreams and tells his brothers. In the first dream:

> **JOSEPH JOE:** `WE WERE BINDING SHEAVES IN THE FIELD.`
>
> **JOSEPH JOE:** `MY SHEAF AROSE AND STOOD UPRIGHT.`
>
> **JOSEPH JOE:** `YOUR SHEAVES CAME AROUND AND BOWED TO MY SHEAF.`

The brothers respond:

> **BROTHER JOES:** `WILL YOU INDEED REIGN OVER US?`
>
> **BROTHER JOES:** `WILL YOU INDEED HAVE DOMINION OVER US?`

The reign/dominion relation is their spoken interpretation. The source says
they hate Joseph more for his dreams and words.

Joseph dreams again and tells his brothers:

> **JOSEPH JOE:** `THE SUN, THE MOON, AND ELEVEN STARS BOWED DOWN TO ME.`

He also tells his father. His father rebukes him and asks:

> **JACOB / ISRAEL JOE:** `WILL I AND YOUR MOTHER AND YOUR BROTHERS INDEED
> COME TO BOW OURSELVES TO THE EARTH BEFORE YOU?`

That family mapping is Jacob's interpretation. The source does not independently
label the sun, moon or stars.

The brothers envy Joseph. The father keeps the saying in mind. Both are source-
assigned States; no private reasoning content is added.

No contradiction completes yet. Dreams and interpretations remain claims about
relations not performed in this chapter.

## Genesis 37:12–17 — GO, SEE, BRING WORD

The brothers feed their father's flock in Shechem. Israel asks Joseph to go to
them. Joseph answers:

> **JOSEPH JOE:** `HERE I AM.`

Israel commands:

> **JACOB / ISRAEL JOE:** `SEE WHETHER IT IS WELL WITH YOUR BROTHERS, AND
> WELL WITH THE FLOCK; AND BRING ME WORD AGAIN.`

Jacob sends Joseph from Hebron valley. Joseph reaches Shechem.

An unnamed man finds Joseph wandering in a field and asks what he seeks.
Joseph says he seeks his brothers and asks where they feed the flock. The man
says they left and that he heard them say they would go to Dothan.

Joseph goes after his brothers and finds them in Dothan. The unnamed man is a
distinct Joe with no angel, divine messenger, motive or later role added.

The return-word command remains open as Joseph approaches the brothers.

## Genesis 37:18–24 — KILL HIM; DON'T KILL HIM; PIT HIM

The brothers see Joseph from far away. Before he comes near, they conspire to
kill him. They call him the dreamer and propose:

> **BROTHER JOES:** `LET'S KILL HIM AND CAST HIM INTO ONE OF THE PITS.`
>
> **BROTHER JOES:** `WE WILL SAY, "AN EVIL ANIMAL HAS DEVOURED HIM."`
>
> **BROTHER JOES:** `WE WILL SEE WHAT WILL BECOME OF HIS DREAMS.`

The proposed killing and future false report are explicit group speech. The
source does not identify each speaker.

Reuben hears and delivers Joseph out of their hand by saying:

> **REUBEN JOE:** `LET'S NOT TAKE HIS LIFE.`
>
> **REUBEN JOE:** `SHED NO BLOOD. THROW HIM INTO THIS WILDERNESS PIT, BUT
> LAY NO HAND ON HIM.`

The narrator supplies Reuben's purpose: to deliver Joseph from their hand and
restore him to his father. This purpose is retained because the source states
it; it is not inferred from Reuben's face.

When Joseph arrives, the brothers strip the many-colored tunic from him, take
him and throw him into the pit. The pit is empty and contains no water.

Reuben's restoration purpose remains uncompleted.

## Genesis 37:25–28 — OUR BROTHER, OUR FLESH, FOR SALE

The brothers sit down to eat bread. They see an Ishmaelite caravan coming from
Gilead. Joe-faced camels carry spices, balm and myrrh toward Egypt.

Judah says:

> **JUDAH JOE:** `WHAT PROFIT IS IT IF WE KILL OUR BROTHER AND CONCEAL HIS
> BLOOD?`
>
> **JUDAH JOE:** `LET'S SELL HIM TO THE ISHMAELITES, AND NOT LET OUR HAND BE
> ON HIM; FOR HE IS OUR BROTHER, OUR FLESH.`

His brothers listen.

Midianite merchants pass. This translation's grammatical subject says they
draw and lift Joseph from the pit and sell Joseph to the Ishmaelites for twenty
pieces of silver. The merchants bring Joseph into Egypt.

Do not silently assign the drawing, silver receipt or sale act to Judah or all
brothers. Judah proposed the sale, the brothers listened, and Midianite
merchants are the explicit actors in verse 28. Ishmaelite and Midianite labels
are retained without invented ethnic equivalence.

That completes S040:

```text
JUDAH IDENTIFIES JOSEPH = OUR BROTHER / OUR FLESH
-> THAT IDENTIFICATION SUPPORTS DON'T KILL / DON'T PUT HAND ON HIM
-> SAME PROPOSAL: SELL HIM
-> BROTHERS LISTEN
-> JOSEPH DRAWN FROM PIT / SOLD / TRANSFERRED TOWARD EGYPT
-> KINSHIP PREVENTS ONE FORM OF HARM WHILE ENABLING COMMODITY TRANSFER
```

Judah's mercy boil becomes a Joe-faced livestock auction board labelled
`BROTHER / FLESH / 20 SILVER / HANDS TECHNICALLY CLEAN`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

The others see a boilless nobody in a superhero suit poke Judah's boil, lick an
empty finger, walk away and never look back. Joseph remains transferred and the
caravan continues.

## Genesis 37:29–30 — REUBEN RETURNS TO AN EMPTY PIT

Reuben returns to the pit and sees Joseph is absent. He tears his clothes,
returns to his brothers and says:

> **REUBEN JOE:** `THE CHILD IS NO MORE; AND I, WHERE WILL I GO?`

The source does not state where Reuben was during the sale, who answers him,
whether he learns the transfer, or what `no more` asserts beyond his observed
empty-pit State. His restore-to-father purpose fails in this chapter.

## Genesis 37:31–36 — WE FOUND THE THING WE MADE

The group takes Joseph's tunic, kills a male goat and dips the tunic in its
blood. The male goat is a living Joe-faced animal until killed. No gag is placed
over the killing.

They bring the tunic to their father and say:

> **BROTHER JOES:** `WE HAVE FOUND THIS.`
>
> **BROTHER JOES:** `EXAMINE IT, AND SEE IF IT IS YOUR SON'S TUNIC OR NOT.`

The observed chain is exact:

```text
THEY TAKE JOSEPH'S TUNIC
-> THEY KILL GOAT
-> THEY DIP TUNIC IN GOAT BLOOD
-> THEY BRING MANUFACTURED BLOODY TUNIC TO JACOB
-> THEY CLAIM: WE FOUND THIS
-> THEY ASK JACOB TO IDENTIFY IT
```

Jacob recognizes the tunic and concludes:

> **JACOB / ISRAEL JOE:** `IT IS MY SON'S TUNIC.`
>
> **JACOB / ISRAEL JOE:** `AN EVIL ANIMAL HAS DEVOURED HIM.`
>
> **JACOB / ISRAEL JOE:** `JOSEPH IS WITHOUT DOUBT TORN IN PIECES.`

The brothers do not directly utter their earlier planned animal claim. They
manufacture the evidence, falsely call it found, ask Jacob to examine it, and
Jacob supplies the intended conclusion himself.

Meanwhile, Joseph remains alive in the merchant transfer State.

That completes S041:

```text
ACTUAL: JOSEPH ALIVE / SOLD / CARRIED TO EGYPT
-> ACTORS MANUFACTURE BLOODY ROBE
-> ACTORS CLAIM ROBE WAS FOUND
-> TARGET EXAMINES MANUFACTURED EVIDENCE
-> TARGET CONCLUDES JOSEPH DEVOURED / TORN APART
-> CLAIMED DEATH STATE != ACTUAL LIVING TRANSFER STATE
```

The bloody robe's evidence boil grows Joseph's full Joe face and prints a fake
warning: `OBJECT MAY CONTAIN CONCLUSIONS ADDED BY RECIPIENT`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

The family sees the suited boilless nobody poke the evidence boil, lick an
empty finger, walk away and never look back. Jacob's conclusion and mourning
continue unchanged.

Jacob tears his clothes, puts sackcloth on his waist and mourns many days. All
his sons and daughters rise to comfort him; he refuses comfort and says he will
go down to Sheol—the source footnote calls it the place of the dead—to his son
mourning. His father weeps for him.

No individual comfort act is assigned. No participant confession, correction
or acceptance occurs.

The Midianites sell Joseph in Egypt to Potiphar, an officer of Pharaoh and
captain of the guard. This final verse proves Joseph is living and closes the
chapter custody State:

```text
JOSEPH -> PIT -> MIDIANITE MERCHANT DRAW/LIFT -> ISHMAELITE SALE
-> MERCHANT TRANSPORT TO EGYPT -> MIDIANITE SALE TO POTIPHAR
```

The source does not identify whether the verse 28 and verse 36 Midianite groups
are the exact same individuals, how the Ishmaelite custody relates between the
two sales, who receives each payment, or whether Potiphar knows the prior acts.

## Joe continuity ledger

- Jacob/Israel remains one Joe under both source names.
- Joseph remains Rachel/Jacob's living seventeen-year-old son; Jacob's death
  conclusion does not alter Joseph's actual State.
- Bilhah and Zilpah remain distinct wives/servants and maternal roots; their
  sons are not individually named as report subjects.
- the brothers' group changes scope across scenes; exact speakers and actors
  remain collective unless Reuben or Judah is named.
- Reuben's source-assigned restoration purpose is retained and fails locally.
- Judah owns his exact brother/flesh/sale proposal, not every merchant act.
- the unnamed field man remains an ordinary unnamed Joe.
- Ishmaelite and Midianite merchant groups remain separately labelled.
- every camel, flock animal and killed male goat has Joe's face.
- Potiphar and Pharaoh are distinct Joes; Pharaoh is only referenced by office
  relation in this chapter.
- Captain remains permanently boilless and causally irrelevant.

## Bullshit pass

- banner: `THE CRACKHEAD BIBLE — ARTICLE 37 — FAMILY ASSET TRANSFER`;
- robe label: `CRACKHEAD FORENSICS — SAMPLE PRE-CONTAMINATED BY SUBMITTER`;
- dream sheaves all have Joseph's face and bow to a sheaf with Joseph's face;
- the sun, moon and eleven stars also have Joseph's face because the image
  generator will absolutely misunderstand the genetics correctly;
- pit sign: `NO WATER / NO HAND LAID / PERSON STILL IN PIT`;
- merchant invoice: `BROTHER/FLESH — 20 SILVER — NO REFUNDS`;
- CrackFlix tiles: `S040 THE MERCIFUL SALE`; `S041 FOUND AFTER MANUFACTURE`;
- barcode: `CHB-GEN37-S040-S041-36-YOINK`;
- footer: `BIG BAG OF EVIDENCE — RECIPIENT ASSEMBLY REQUIRED`.

## Reconstruction boundary

- all 36 source verse markers are represented in ordered required States;
- source-attributed love, hate, envy, keeping-in-mind and Reuben purpose are
  retained as testimony, not inferred;
- dreams remain dreams; family/reign meanings remain character interpretations;
- exact brother-group versus named Reuben/Judah versus merchant actor scope is
  preserved;
- S040 completes only after the brother/flesh sale proposal is accepted and a
  sale/transfer occurs;
- S041 distinguishes manufactured evidence, found claim, Jacob conclusion and
  Joseph's actual living custody;
- Joseph is not declared sold directly by brothers where this translation names
  Midianite merchants as verse 28 actors;
- Ishmaelite/Midianite identity equivalence and silver recipients remain open;
- no direct God speech, divine act, dream authorization or providential motive
  is inserted;
- Genesis 33 Seir, Genesis 34 retaliation/captives, Genesis 35 Reuben/Bilhah and
  promise chains remain open;
- publication remains held and unpublished.

Continuation required: Genesis 38 follows Judah's separation, marriages,
deaths, Tamar's withheld marriage, disguise, pledge evidence, judgment reversal
and Perez/Zerah birth sequence.
