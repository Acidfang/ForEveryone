# CRACKHEAD GENESIS 38

## Title page

**WAIT UNTIL SHELAH IS GROWN.**

**SHELAH GREW UP.**

**I DIDN'T GIVE HER TO SHELAH.**

**BRING HER OUT AND BURN HER.**

**PLEASE DISCERN WHOSE PLEDGES THESE ARE.**

Source parent: Genesis 38:1–30, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 38.

Parent manuscript: `GENESIS/037-HE-IS-OUR-BROTHER-LETS-SELL-HIM.md`.

CrackFlix routing:

- `S042 — RAISE OFFSPRING. MAKE SURE THERE IS NO OFFSPRING.`, episode
  `S042-E001-GEN38 — DUTY WITH THE RESULT REMOVED`;
- `S043 — WAIT UNTIL HE GROWS. HE GREW. I DIDN'T GIVE HER TO HIM.`, episode
  `S043-E001-GEN38 — THE PERMANENT TEMPORARY WIDOW`;
- `S044 — BURN HER. THOSE ARE MY PLEDGES.`, episode
  `S044-E001-GEN38 — JUDGMENT WITH A SIGNET RECEIPT`;
- `S045 — THIS CAME OUT FIRST. HIS BROTHER CAME OUT FIRST.`, episode
  `S045-E001-GEN38 — SCARLET THREAD PHOTO FINISH`.

## Causal foundation

```text
JUDAH LEAVES BROTHERS / VISITS HIRAH
-> JUDAH SEES/TAKES SHUA'S DAUGHTER / GOES IN TO HER
-> SHE BEARS ER / ONAN / SHELAH
-> JUDAH TAKES TAMAR AS ER WIFE
-> ER WICKED IN LORD SIGHT
-> LORD KILLS ER
-> JUDAH ORDERS ONAN: BROTHER-HUSBAND DUTY / RAISE OFFSPRING FOR ER
-> ONAN KNOWS OFFSPRING NOT HIS
-> ONAN GOES IN / SPILLS SEMEN TO PREVENT OFFSPRING FOR BROTHER
-> ACT EVIL IN LORD SIGHT
-> LORD KILLS ONAN
-> JUDAH TELLS TAMAR: WIDOW IN FATHER HOUSE UNTIL SHELAH GROWN
-> SOURCE REPORTS JUDAH'S LEST-SHELAH-DIE STATEMENT
-> TAMAR OBEYS / LIVES IN FATHER HOUSE
-> JUDAH WIFE DIES / JUDAH COMFORTED
-> JUDAH + HIRAH GO TO TIMNAH SHEEP SHEARERS
-> TAMAR TOLD
-> TAMAR REMOVES WIDOW GARMENTS / VEILS / SITS ENAIM GATE
-> SOURCE: SHELAH GROWN / TAMAR NOT GIVEN TO HIM
-> JUDAH SEES / THINKS PROSTITUTE / DOES NOT KNOW DAUGHTER-IN-LAW
-> JUDAH REQUESTS SEX
-> TAMAR NEGOTIATES YOUNG GOAT + SIGNET/CORD/STAFF PLEDGE
-> JUDAH GIVES PLEDGES / GOES IN / TAMAR CONCEIVES
-> TAMAR RESTORES WIDOW GARMENTS
-> JUDAH SENDS GOAT WITH HIRAH TO RECOVER PLEDGE
-> HIRAH CANNOT FIND WOMAN
-> PLACE MEN SAY NO PROSTITUTE WAS THERE
-> JUDAH LETS HER KEEP PLEDGES TO AVOID SHAME
-> THREE MONTHS / REPORT: TAMAR PROSTITUTION + PREGNANCY
-> JUDAH ORDERS BRING OUT / BURN
-> TAMAR SENDS PLEDGES / ASKS WHOSE
-> JUDAH ACKNOWLEDGES
-> JUDAH: SHE MORE RIGHTEOUS BECAUSE I DIDN'T GIVE SHELAH
-> JUDAH KNOWS HER NO MORE
-> TAMAR LABOR / TWINS
-> ONE HAND OUT / MIDWIFE TIES SCARLET THREAD / DECLARES FIRST
-> HAND RETRACTS
-> OTHER BROTHER COMES OUT / NAMED PEREZ
-> THREAD-HAND BROTHER COMES OUT AFTER / NAMED ZERAH
```

## Genesis 38:1–6 — JUDAH'S NEW HOUSEHOLD

At that time Judah goes down from his brothers and visits Hirah, a named
Adullamite. The source does not state a dispute, destination plan or duration.

Judah sees the daughter of a Canaanite man named Shua. He takes her and goes in
to her. Her personal name and consent State are not supplied.

She conceives and bears three sons:

- Er, named by Judah;
- Onan, named by his mother;
- Shelah, named by his mother while Judah is at Chezib.

Judah takes Tamar as wife for Er, his firstborn. Tamar is a new Joe identity;
no parentage, consent dialogue, wedding form or prior history is supplied.

## Genesis 38:7–10 — DUTY WITH THE OUTCOME REMOVED

The source says Er is wicked in the LORD's sight. It does not specify Er's act.
The LORD kills Er. This is a narrator-assigned divine act.

Judah orders Onan:

> **JUDAH JOE:** `GO IN TO YOUR BROTHER'S WIFE.`
>
> **JUDAH JOE:** `PERFORM THE DUTY OF A HUSBAND'S BROTHER TO HER.`
>
> **JUDAH JOE:** `RAISE UP OFFSPRING FOR YOUR BROTHER.`

This is Judah's stated obligation. The chapter does not separately state a
general legal code.

The source says Onan knows the offspring would not be his. When he goes in to
his brother's wife, he spills his semen on the ground so that he will not give
offspring to his brother.

Tamar receives no speech or consent State in this encounter. No pleasure,
frequency, contraception theory or medical consequence is invented.

That completes S042:

```text
REQUIRED OUTCOME IN JUDAH'S ORDER: RAISE OFFSPRING FOR DEAD BROTHER
-> ONAN PERFORMS SEXUAL ENCOUNTER
-> ONAN DELIBERATELY REMOVES THE REQUIRED OFFSPRING OUTCOME
-> ACT DOES THE ACCESS PART WHILE BLOCKING THE DUTY'S STATED RESULT
```

Onan's duty boil becomes a Joe-faced workflow diagram reading
`START -> DO DUTY -> DELETE OUTPUT -> COMPLETE`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

The Joes see only a boilless suited nobody poke the boil, lick an empty finger,
walk away and never look back. The source then says the act is evil in the
LORD's sight and the LORD kills Onan also.

Captain does not cause, judge, explain or alter either death.

## Genesis 38:11 — WAIT UNTIL HE IS GROWN

Judah tells Tamar:

> **JUDAH JOE:** `REMAIN A WIDOW IN YOUR FATHER'S HOUSE UNTIL SHELAH, MY
> SON, IS GROWN UP.`

The source then reports Judah saying `lest he also die, like his brothers`.
That fear/reason State is direct source testimony. It is not inferred from
Judah's face and is not attributed to Tamar.

Tamar goes and lives in her father's house. The required wait State begins.

Shelah's eventual growth and Tamar's marriage State remain open at this verse.

## Genesis 38:12–14 — HE GREW; SHE WASN'T GIVEN

After many days, Judah's wife—the daughter of Shua—dies. Judah is comforted and
goes with Hirah to his sheep shearers at Timnah. No Captain beat is placed on
her death.

Tamar is told Judah is going to Timnah. She removes widowhood garments, covers
herself with a veil, wraps herself and sits at Enaim's gate on the Timnah road.

The source supplies the producing observation:

```text
SHELAH IS GROWN UP
AND
TAMAR HAS NOT BEEN GIVEN TO HIM AS WIFE
```

That closes Judah's earlier wait condition without the implied household
transition.

## Genesis 38:15–19 — THE PLEDGE

Judah sees Tamar and thinks she is a prostitute because her face is covered.
The source says he does not know she is his daughter-in-law. These are Judah's
source-attributed identification States, not facial inference.

Judah asks to come in to her. Tamar asks what he will give. Judah promises a
young goat from the flock. Tamar requests a pledge until it is sent.

She identifies the pledge objects:

> **TAMAR JOE:** `YOUR SIGNET, YOUR CORD, AND YOUR STAFF THAT IS IN YOUR
> HAND.`

Judah gives them to Tamar and goes in to her. Tamar conceives by him.

The dialogue establishes agreement to the stated exchange, but it does not
authorize invented feelings, broader consent conditions, knowledge of identity
or a permanent relationship.

Tamar leaves, removes the veil and puts widowhood garments back on.

That completes S043 when combined with Judah's later admission:

```text
JUDAH: WAIT AS WIDOW UNTIL SHELAH GROWN
-> TAMAR WAITS IN FATHER HOUSE
-> SHELAH GROWS
-> TAMAR NOT GIVEN TO SHELAH
-> JUDAH LATER: I DIDN'T GIVE HER TO SHELAH
```

The waiting-condition boil grows into a Joe-faced progress bar at 100% reading
`SHELAH GROWN — NEXT STEP DISABLED`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes, licks an empty finger, walks away and never looks back. Tamar remains
pregnant and the withheld marriage State remains unchanged.

## Genesis 38:20–23 — NO PROSTITUTE HERE

Judah sends the young goat with Hirah to recover the pledge. Hirah cannot find
the woman. He asks men of the place where the road-side prostitute at Enaim is.
They say:

> **PLACE MEN:** `THERE HAS BEEN NO PROSTITUTE HERE.`

Hirah reports both his failed search and their statement to Judah.

Judah says:

> **JUDAH JOE:** `LET HER KEEP IT, LEST WE BE SHAMED.`
>
> **JUDAH JOE:** `I SENT THIS YOUNG GOAT, AND YOU HAVEN'T FOUND HER.`

The goat-send act occurs; pledge recovery does not. `No prostitute here` is the
place men's classification, while Judah's classification concerned the veiled
person he encountered. The source never supplies shared identity knowledge, so
this is not forced into a contradiction series.

## Genesis 38:24–26 — BURN HER; RECOGNIZE MY PROPERTY

About three months later, Judah receives a report:

> **REPORTING JOE(S):** `TAMAR HAS PLAYED THE PROSTITUTE.`
>
> **REPORTING JOE(S):** `SHE IS WITH CHILD BY PROSTITUTION.`

The report's speaker, evidence and legal authority are not identified.

Judah orders:

> **JUDAH JOE:** `BRING HER OUT, AND LET HER BE BURNED.`

When Tamar is brought out, she sends to her father-in-law:

> **TAMAR JOE:** `I AM WITH CHILD BY THE MAN WHO OWNS THESE.`
>
> **TAMAR JOE:** `PLEASE DISCERN WHOSE THESE ARE: THE SIGNET, THE CORDS,
> AND THE STAFF.`

Judah acknowledges the pledge objects. He says:

> **JUDAH JOE:** `SHE IS MORE RIGHTEOUS THAN I, BECAUSE I DIDN'T GIVE HER
> TO SHELAH, MY SON.`

The source then says Judah knows her again no more.

That completes S044:

```text
JUDAH PARTICIPATES IN THE ENCOUNTER / GIVES UNIQUE PLEDGES
-> JUDAH DOES NOT KNOW WOMAN = TAMAR
-> REPORT ACCUSES TAMAR OF PROSTITUTION/PREGNANCY
-> JUDAH ORDERS TAMAR BURNED
-> TAMAR PRODUCES JUDAH'S PLEDGES + IDENTIFIES OWNER AS FATHER
-> JUDAH ACKNOWLEDGES OBJECTS
-> JUDAH REVERSES RELATIVE JUDGMENT: SHE MORE RIGHTEOUS THAN I
-> JUDAH NAMES HIS WITHHELD-SHELAH ACT AS CAUSE
```

Judah's judgment boil grows into a Joe-faced signet stamp printing
`BURN HER` on one side and `PROPERTY OF JUDAH` on the other.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Everyone sees the boilless suited nobody poke the boil, lick an empty finger,
walk away and never look back. The source records no burning, and the pregnancy
continues.

Judah's `more righteous` statement is his explicit revised comparison. The
manuscript does not convert it into a complete law, acquittal procedure,
apology, Tamar reply or public institutional reform.

## Genesis 38:27–30 — FIRST HAND, SECOND BABY

At Tamar's labor, twins are in her womb. One puts out a hand. The midwife ties
a scarlet thread on that hand and says:

> **MIDWIFE JOE:** `THIS CAME OUT FIRST.`

The hand draws back. Then the brother comes out. The midwife asks why he made a
breach for himself, and he is named Perez. The source footnote says Perez means
`breaking out`.

Afterward, the brother with the scarlet thread comes out and is named Zerah.
The source footnote says Zerah means `scarlet` or `brightness`.

That completes S045:

```text
TWIN ZERAH HAND EMERGES
-> MIDWIFE MARKS HAND / DECLARES THIS CAME OUT FIRST
-> HAND RETRACTS
-> TWIN PEREZ'S WHOLE BODY COMES OUT FIRST
-> PEREZ NAMED FOR BREAKING OUT
-> THREAD-MARKED ZERAH COMES OUT AFTERWARD
-> FIRST-HAND CLASSIFICATION != FIRST-BORN BODY ORDER
```

The birth-order boil becomes a Joe-faced finish-line camera photographing one
hand in lane one and an entire baby in lane two.

> **CAPTAIN CRACKHEAD:** `YOINK!`

The midwife sees only a suited boilless nobody poke the boil, lick an empty
finger, walk away and never look back. Perez remains born before Zerah.

## Joe continuity ledger

- Judah continues from Genesis 37 and becomes a separate household root here.
- Hirah remains the same named Adullamite friend across visit, Timnah travel and
  goat-recovery acts.
- Shua's unnamed daughter remains Judah's wife and mother of Er, Onan and
  Shelah; no personal name is invented.
- Er and Onan are killed by the LORD in separate narrator-assigned acts.
- Tamar remains one Joe across wife, widow, veiled roadside identity, pledge
  holder, accused daughter-in-law and mother.
- no prostitute Joe is separately invented from Judah's mistaken classification.
- Shelah grows but does not receive Tamar in this chapter.
- signet, cord and staff are distinct evidence objects. Anything interpreted as
  a face may carry Joe's face, but object-face does not make objects living.
- the promised young goat is a living Joe-faced animal; sending it does not
  complete pledge recovery.
- Perez and Zerah are distinct twins. A protruding hand is not a separate Joe.
- the midwife remains an unnamed distinct Joe.
- Captain remains permanently boilless and changes nothing.

## Bullshit pass

- banner: `THE CRACKHEAD BIBLE — ARTICLE 38 — PLEDGE-BASED JUDICIAL REVIEW`;
- Shelah progress bar: `100% GROWN / 0% GIVEN`;
- signet label: `CRACKHEAD TWO-FACTOR PATERNITY AUTHENTICATION`;
- Hirah search form: `PROSTITUTE NOT FOUND / COLLATERAL NOT RETURNED`;
- judgment stamp: `BURN PENDING OWNER IDENTIFICATION`;
- birth camera: `HAND WON QUALIFYING / PEREZ WON FINAL`;
- CrackFlix: `S042 OUTPUT DELETED`; `S043 WAIT COMPLETE`; `S044 SIGNET APPEAL`;
  `S045 THREAD PHOTO FINISH`;
- barcode: `CHB-GEN38-S042-S045-30-YOINK`;
- footer: `BIG BAG OF COLLATERAL — IDENTITY INSIDE`.

## Reconstruction boundary

- all 30 source verse markers are represented in ordered required States;
- Er/Onan wicked/evil judgments and deaths remain exact LORD-associated source
  acts; no general death rule or Captain causation is invented;
- Onan's knowledge/purpose is retained only because the source states it;
- Tamar receives no invented speech or consent in the Er/Onan relations;
- Judah/Tamar roadside dialogue and pledge exchange remain exact without added
  feelings or identity knowledge;
- S043 closes only when Shelah growth, non-giving and Judah's admission all
  exist;
- S044 preserves report, judgment, evidence, acknowledgment and revised
  comparison in order;
- Perez/Zerah hand and body emergence are not collapsed;
- no prior Genesis open chain is silently closed by this Judah side-history;
- publication remains held and unpublished.

Continuation required: Genesis 39 returns to Joseph in Potiphar's house,
directly attributes divine presence/prosperity, records repeated refusal,
garment evidence, accusation, imprisonment and prison trust.
