# CRACKHEAD GENESIS 30

## Title page

**NAME YOUR WAGES.**

**SPECKLED, SPOTTED AND BLACK.**

**AGREED.**

**I REMOVED ALL OF THOSE.**

Source parent: Genesis 30:1–43, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 30.

Parent manuscript: `GENESIS/029-SEVEN-YEARS-FOR-RACHEL-HERES-LEAH.md`.

CrackFlix:

- `S027 — THIS WILL MAKE HIM LOVE ME. I'M STILL HATED.`, episode
  `S027-E002-GEN30 — I HIRED MY HUSBAND FOR TONIGHT`;
- `S028 — NAME YOUR WAGES. I REMOVED THEM.`, episode
  `S028-E001-GEN30 — THREE DAYS FROM THE PAY`.

## Causal foundation

```text
RACHEL NO CHILDREN / ENVIES LEAH / DEMANDS CHILDREN OR DEATH
-> JACOB ANGER / GOD-PLACE RESPONSE
-> RACHEL GIVES BILHAH AS WIFE / CHILDREN-ON-KNEES PLAN
-> BILHAH BEARS DAN + NAPHTALI
-> RACHEL NAMES / CLAIMS JUDGMENT-HEARING + SISTER PREVAILING
-> LEAH SEES FINISHED BEARING
-> LEAH GIVES ZILPAH AS WIFE
-> ZILPAH BEARS GAD + ASHER
-> REUBEN FINDS MANDRAKES / GIVES LEAH
-> RACHEL REQUESTS MANDRAKES
-> LEAH: YOU TOOK HUSBAND
-> RACHEL TRADES JACOB'S NIGHT FOR MANDRAKES
-> LEAH: I HIRED YOU / JACOB LIES WITH HER
-> GOD LISTENS / LEAH BEARS ISSACHAR
-> LEAH BEARS ZEBULUN + DINAH
-> GOD REMEMBERS/LISTENS TO RACHEL / OPENS WOMB
-> RACHEL BEARS JOSEPH
-> JACOB REQUESTS DEPARTURE + WIVES/CHILDREN
-> LABAN REQUESTS STAY / ATTRIBUTES BLESSING TO JACOB
-> LABAN: APPOINT WAGES / I WILL GIVE
-> JACOB DEFINES SPECKLED/SPOTTED/BLACK ANIMALS AS HIRE
-> LABAN AGREES ACCORDING TO JACOB'S WORD
-> SAME DAY LABAN REMOVES EVERY QUALIFYING ANIMAL
-> LABAN GIVES THEM TO SONS / SETS THREE-DAY SEPARATION
-> JACOB FEEDS REMAINING FLOCK
-> JACOB PEELS THREE TREE-ROD TYPES / PLACES AT TROUGHS
-> SOURCE: FLOCKS CONCEIVE / PRODUCE STREAKED-SPECKLED-SPOTTED
-> JACOB SEPARATES / ORIENTS / SELECTIVELY USES RODS WITH STRONGER FLOCK
-> FEEBLER LABAN / STRONGER JACOB
-> JACOB INCREASES EXCEEDINGLY
```

## Genesis 30:1–2 — GIVE ME CHILDREN OR I DIE

Rachel sees she has borne Jacob no children. The source attributes envy of Leah.

> **RACHEL JOE:** `GIVE ME CHILDREN, OR I WILL DIE.`

The source attributes burning anger to Jacob.

> **JACOB JOE:** `AM I IN GOD'S PLACE?`
>
> `GOD HAS WITHHELD THE FRUIT OF THE WOMB FROM YOU.`

Rachel's death statement is conditional on the childless State. The chapter
later changes that State, so it is not routed as an S018 imminent-death episode.
Jacob's attribution remains his speech; no direct God line occurs here.

## Genesis 30:3–8 — BILHAH, DAN AND NAPHTALI

> **RACHEL JOE:** `HERE IS MY SERVANT BILHAH.`
>
> `GO IN TO HER.`
>
> `SHE WILL BEAR ON MY KNEES, AND I MAY OBTAIN CHILDREN THROUGH HER.`

Rachel gives Bilhah to Jacob as wife. Jacob goes in to her. Bilhah conceives and
bears Dan.

> **RACHEL JOE:** `GOD JUDGED ME, HEARD MY VOICE AND GAVE ME A SON.`

Rachel names him Dan. Biological motherhood remains Bilhah's; Rachel's stated
obtain-children relation is retained without replacing either Joe.

Bilhah conceives again and bears Naphtali.

> **RACHEL JOE:** `I WRESTLED MIGHTILY WITH MY SISTER AND PREVAILED.`

Rachel names him Naphtali. `Prevailed` is her spoken classification at this
Moment. Leah's later children do not retroactively remove the statement.

## Genesis 30:9–13 — ZILPAH, GAD AND ASHER

Leah sees that she has finished bearing. This is her observed chapter State,
not a permanent biological conclusion.

She gives Zilpah to Jacob as wife. Zilpah bears Gad.

> **LEAH JOE:** `HOW FORTUNATE.`

Leah names him Gad. Zilpah bears Asher.

> **LEAH JOE:** `HAPPY AM I.`
>
> `THE DAUGHTERS WILL CALL ME HAPPY.`

Leah names him Asher. Bilhah and Zilpah remain wives, servants and biological
mothers simultaneously as the source states; no voice or consent is invented.

## Genesis 30:14–16 — I HIRED MY HUSBAND

During wheat harvest, Reuben finds mandrakes in the field and brings them to
Leah. Mandrakes are living Crackheadverse organisms and receive Joe faces before
being gathered; the face does not make them children or give them dialogue.

> **RACHEL JOE:** `PLEASE GIVE ME SOME OF YOUR SON'S MANDRAKES.`

> **LEAH JOE:** `IS IT SMALL THAT YOU TOOK AWAY MY HUSBAND?`
>
> `WILL YOU TAKE MY SON'S MANDRAKES TOO?`

> **RACHEL JOE:** `HE WILL LIE WITH YOU TONIGHT FOR THE MANDRAKES.`

Jacob returns from the field.

> **LEAH JOE:** `YOU MUST COME IN TO ME.`
>
> `I HAVE HIRED YOU WITH MY SON'S MANDRAKES.`

Jacob lies with Leah that night. The source gives no Jacob reply, Rachel-Jacob
authorization discussion, mandrake quantity, transfer panel or private intent.

That spoken hire completes S027's second episode against Leah's retained Levi
statement:

```text
GEN29 AFTER THIRD SON: NOW MY HUSBAND WILL BE JOINED TO ME
GEN30: RACHEL CONTROLS TONIGHT IN THE MANDRAKE EXCHANGE
GEN30 LEAH: I HAVE HIRED MY HUSBAND FOR TONIGHT
```

It is the same prediction/non-result root in a new State. Captain has heard it.

> **CAPTAIN CRACKHEAD FLY:** `SKIP.`

Glazed eyes. Nothing skips. Jacob still lies with Leah; God still listens; the
next conception still occurs.

Leah's joined-husband boil prints a Joe-faced one-night hire docket.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back.

## Genesis 30:17–21 — ISSACHAR, ZEBULUN AND DINAH

God listens to Leah. She conceives and bears a fifth son, Issachar.

> **LEAH JOE:** `GOD GAVE ME MY HIRE BECAUSE I GAVE MY SERVANT TO MY HUSBAND.`

That is Leah's naming attribution. The source separately narrates God's
listening and separately retains the mandrake night hire; the comic does not
silently choose which meaning of `hire` Leah privately holds.

Leah conceives and bears a sixth son, Zebulun.

> **LEAH JOE:** `GOD ENDOWED ME WITH A GOOD DOWRY.`
>
> `NOW MY HUSBAND WILL LIVE WITH ME. I HAVE BORNE HIM SIX SONS.`

This new prediction has no later chapter-30 Jacob residence result, so it stays
open rather than becoming another S027 episode.

Afterward Leah bears a daughter and names her Dinah. No naming speech, rank
among all children or reason is supplied.

## Genesis 30:22–24 — RACHEL BEARS JOSEPH

God remembers Rachel, listens to her and opens her womb. Rachel conceives and
bears Joseph.

> **RACHEL JOE:** `GOD HAS TAKEN AWAY MY REPROACH.`
>
> `MAY THE LORD ADD ANOTHER SON TO ME.`

The first statement addresses the completed Joseph birth. The second requests a
future addition and remains open. God remembering/listening/opening are narrator-
assigned acts; no direct God speech is supplied.

## Genesis 30:25–30 — SEND ME HOME; STAY AND NAME WAGES

After Joseph's birth:

> **JACOB JOE:** `SEND ME TO MY OWN PLACE AND COUNTRY.`
>
> `GIVE ME MY WIVES AND CHILDREN FOR WHOM I SERVED.`
>
> `YOU KNOW MY SERVICE.`

> **LABAN JOE:** `IF I FOUND FAVOR, STAY.`
>
> `I DIVINED THAT THE LORD BLESSED ME FOR YOUR SAKE.`
>
> `APPOINT YOUR WAGES, AND I WILL GIVE THEM.`

Jacob says Laban knows his service and livestock increase, attributes blessing
wherever he turned to the LORD, and asks when he may provide for his own house.
The departure request becomes a wage negotiation; no departure occurs.

## Genesis 30:31–34 — THE WAGE AGREEMENT

> **LABAN JOE:** `WHAT SHALL I GIVE YOU?`

> **JACOB JOE:** `GIVE ME NOTHING.`
>
> `IF YOU DO THIS, I WILL KEEP FEEDING YOUR FLOCK.`
>
> `I WILL PASS THROUGH THE FLOCK TODAY AND REMOVE EVERY SPECKLED, SPOTTED AND`
> `BLACK ANIMAL.`
>
> `THESE WILL BE MY HIRE.`
>
> `ANY NONQUALIFYING ANIMAL WITH ME WILL BE CONSIDERED STOLEN.`

`Give me nothing` remains distinct from the proposed earn/remove wage mechanism;
the comic does not manufacture a contradiction by erasing that distinction.

> **LABAN JOE:** `LET IT BE ACCORDING TO YOUR WORD.`

The agreement retains:

- Jacob as the proposed same-day flock passer/remover;
- every streaked/spotted male goat;
- every speckled/spotted female goat or goat with white;
- every black sheep;
- those categories as Jacob's hire;
- nonqualifying animals with Jacob classified as stolen.

## Genesis 30:35–36 — AGREED; REMOVED

That same day, Laban—not Jacob—removes every listed qualifying animal. Laban
gives them to his sons and places three days' journey between himself and Jacob.
Jacob feeds the rest of Laban's flock.

That completes S028:

```text
LABAN: APPOINT WAGES / I WILL GIVE
JACOB: TODAY I REMOVE QUALIFYING PATTERNED/BLACK ANIMALS AS HIRE
LABAN: ACCORDING TO YOUR WORD
SAME DAY LABAN REMOVES ALL QUALIFYING ANIMALS
-> GIVES THEM TO HIS SONS
-> THREE DAYS BETWEEN THEM AND JACOB
-> JACOB RECEIVES REST OF LABAN FLOCK TO FEED
```

No allegation of secret intent is required. Agreement State and Laban's next
acts do not cleanly agree on who performs the removal or where the starting wage
animals are placed.

Laban's wage-agreement boil grows a Joe-faced spotted goat that is immediately
carried three days away.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. The qualifying animals remain with
Laban's sons and Jacob still receives the rest.

## Genesis 30:37–43 — CRACKHEAD LIVESTOCK GENERATION

Jacob takes fresh rods from poplar, almond and plane trees. He peels white
streaks into them and exposes white. He puts the rods at the watering troughs
before the flocks. The source records that the flocks conceive at the troughs
and produce streaked, speckled and spotted offspring.

This is serious Crackheadverse source physics. The manuscript preserves what
the source says happened and does not compare it with another domain, invent a
symbolic mechanism, or mock the mechanism into non-occurrence.

Jacob:

- separates lambs;
- turns flock faces toward streaked/black animals in Laban's flock;
- keeps his droves apart from Laban's;
- places rods for stronger animals at conception;
- withholds rods for feeble animals.

The resulting State is feebler animals for Laban and stronger animals for Jacob.
Jacob increases exceedingly and obtains large flocks, female/male servants,
camels and donkeys.

Every tree, flock animal, camel and donkey is Joe-faced. The rods may keep Joe
faces as severed plant material if the generator interprets a face there. None
of that changes the recorded breeding/property outcome.

## Character and world-ledger changes

- Rachel: envy/death demand; gives Bilhah as wife; claims children through her;
  names Dan/Naphtali; trades Jacob's night for mandrakes; remembered/listened-to/
  opened by God; bears/names Joseph; requests another son.
- Jacob: anger/source speech; takes Bilhah/Zilpah as wives; fathers eight new
  named children; participates in mandrake night; requests departure; negotiates
  patterned wage; manages remaining flock/rods/separation; becomes very wealthy.
- Leah: gives Zilpah; names Gad/Asher; receives mandrakes; trades/accesses Jacob's
  night; bears Issachar/Zebulun/Dinah; makes hire/dowry/residence statements.
- Bilhah: becomes Jacob wife; bears Dan/Naphtali.
- Zilpah: becomes Jacob wife; bears Gad/Asher.
- Reuben: finds/brings mandrakes; no speech added.
- Dan/Naphtali/Gad/Asher/Issachar/Zebulun/Dinah/Joseph: eight distinct new Joe
  identities with exact biological/social/naming relations.
- Laban: asks Jacob stay/name wage; agrees patterned categories; same day removes
  all qualifying animals; transfers them to sons; separates three days.
- Laban's sons: unnamed recipient/herding group for removed wage animals.
- mandrakes: living Joe-faced plant organisms found/transferred in wheat harvest.
- flock animals: qualifying/nonqualifying, strong/feeble, owner/drove and
  generation States retained without merging individual animals.

## Fuck-up pass

- fruit of womb -> literal Joe-faced fruit hanging from a maternity tree.
- bear on my knees -> Bilhah hands a Joe-faced bear to Rachel's knees.
- mighty wrestlings -> Rachel and Leah arm-wrestle their identical Joe faces.
- Gad -> `GADGET JOE`, newborn supplied with no useful function.
- Asher -> `ASH-ER JOE`, covered in unexplained fireplace ash.
- mandrakes -> screaming Joe-faced men being dragged from the field: `MAN-DRAG`.
- hired husband -> `JACOB NIGHT SHIFT / PAID IN PLANTS`.
- Issachar -> `IS-A-CAR JOE`, newborn interpreted as a vehicle.
- Zebulun -> `ZEBRA-LOON JOE`, striped balloon foreshadowing livestock.
- Dinah -> `DINER JOE`, born beside a mandrake restaurant booth.
- Joseph -> `JOE-SIF`, same Joe face with an unnecessary conditional label.
- divined blessing -> Laban uses a Joe-faced fork labelled `DIVINING ROD`.
- give me nothing -> empty wage bag immediately followed by animal specification.
- patterned animals -> `CRACKHEAD PAYROLL: SPOTS ACCEPTED / SOLIDS STOLEN`.
- three days away -> payroll department physically carried three calendar pages.
- peeled rods -> `CRACKHEAD GENETIC USER INTERFACE`, all controls decorative-looking.
- stronger conception -> animals lifting weights while drinking.
- exceedingly increased -> wealth boil chart exits the panel and becomes scenery.

## God-line boundary

Genesis 30 narrates that God listens to Leah, remembers/listens to Rachel and
opens Rachel's womb. Jacob, Rachel and Leah also make divine attributions in
their own speech. No God or divine messenger speaks directly. The livestock
generation chain is attributed to the stated rods/flocks/actions and outcome;
no unrecorded God line or external-physics correction is added.

## FIR verification

- All 43 verse markers are covered in order.
- Biological mothers, social child claims, wife and servant relations remain
  simultaneously distinct.
- Rachel's conditional death statement is not misrouted after child State changes.
- Every conception/birth/name occurs in source order.
- S027 recurrence links Leah's three-son joined prediction to her later one-night
  husband hire statement; `SKIP` changes nothing.
- Mandrake access trade and God-listened conception remain separate relations.
- Zebulun residence prediction and Joseph additional-son request remain open.
- Departure request precedes Laban's stay/wage negotiation.
- `Give me nothing` is not detached from Jacob's earn/remove mechanism.
- Every wage category and stolen-category boundary is retained.
- S028 closes only after Laban agrees, removes all qualifiers, transfers them to
  sons and separates them three days from Jacob.
- Rod types, peeling, trough placement, conception, patterns, selective use and
  stronger/feebler property outcome remain in source order.
- Source livestock physics is preserved seriously without cross-domain rebuttal.
- All eight new children, mandrakes and living livestock carry Joe identity.
- Captain appears only after completed contradictions, says only `YOINK!`, is
  boilless and changes nothing.
- No direct God speech, servant-wife voice, hidden motive, invented consent or
  departure is added.
- Manuscript remains held and unpublished.

Continuation required: Genesis 31 receives Jacob's observation of Laban sons/
face, direct return command, Rachel/Leah wage-history response, secret departure,
Rachel's household-god taking, Laban pursuit/dream boundary, search/body-search
statement, hidden saddle objects, Jacob confrontation, twenty-year wage/change
ledger, covenant heap/pillar and Mizpah oath.
