# CRACKHEAD GENESIS 39

## Title page

**THE MIDIANITES SOLD JOSEPH TO POTIPHAR.**

**POTIPHAR BOUGHT JOSEPH FROM THE ISHMAELITES.**

**SHE CAUGHT HIM BY HIS GARMENT.**

**HE CAME IN TO LIE WITH ME.**

Source parent: Genesis 39:1–23, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 39.

Parent manuscript:
`GENESIS/038-BRING-HER-OUT-AND-BURN-HER-THOSE-ARE-MY-PLEDGES.md`.

CrackFlix routing:

- `S046 — THE MIDIANITES SOLD HIM. THE ISHMAELITES SOLD HIM.`, episode
  `S046-E001-GEN39 — ONE BUYER, TWO SELLER LEDGERS`;
- `S047 — I GRABBED HIS GARMENT. HE CAME IN TO ME.`, episode
  `S047-E001-GEN39 — GARMENT IN HAND, STORY BACKWARDS`.

## Causal foundation

```text
GEN37: MIDIANITES SELL JOSEPH IN EGYPT TO POTIPHAR
-> GEN39: POTIPHAR BUYS JOSEPH FROM ISHMAELITES WHO BROUGHT HIM DOWN
-> LORD WITH JOSEPH / JOSEPH PROSPEROUS IN POTIPHAR HOUSE
-> POTIPHAR SEES LORD WITH JOSEPH / ALL JOSEPH DOES PROSPERS
-> JOSEPH FINDS FAVOR / MINISTERS / MADE HOUSE OVERSEER
-> ALL POTIPHAR HAS PUT IN JOSEPH HAND
-> LORD BLESSES HOUSE/FIELD FOR JOSEPH SAKE
-> POTIPHAR CONCERNS HIMSELF ONLY WITH FOOD
-> JOSEPH WELL-BUILT/HANDSOME
-> POTIPHAR WIFE SAYS LIE WITH ME
-> JOSEPH REFUSES / STATES TRUST-WIFE-GOD BOUNDARIES
-> SHE SPEAKS DAY BY DAY
-> JOSEPH DOES NOT LISTEN / LIE BY / BE WITH HER
-> JOSEPH ENTERS HOUSE TO WORK / NO HOUSE MEN INSIDE
-> WIFE CATCHES JOSEPH GARMENT / SAYS LIE WITH ME
-> JOSEPH LEAVES GARMENT IN HER HAND / RUNS OUTSIDE
-> WIFE SEES GARMENT + FLIGHT
-> WIFE CALLS HOUSE MEN
-> CLAIM 1: POTIPHAR BROUGHT HEBREW TO MOCK US / JOSEPH CAME TO LIE / SHE CRIED
-> WIFE KEEPS GARMENT UNTIL POTIPHAR HOME
-> CLAIM 2: YOUR HEBREW SERVANT CAME TO MOCK ME / SHE CRIED / HE FLED
-> POTIPHAR HEARS / WRATH KINDLED
-> POTIPHAR PUTS JOSEPH IN KING-PRISONER PRISON
-> LORD WITH JOSEPH / KINDNESS / FAVOR WITH PRISON KEEPER
-> KEEPER COMMITS ALL PRISONERS/WORK TO JOSEPH
-> KEEPER DOES NOT LOOK AFTER JOSEPH-HAND MATTERS
-> LORD WITH JOSEPH / MAKES HIS WORK PROSPER
```

## Genesis 39:1 — TWO SELLERS AT ONE PURCHASE

Joseph is brought down to Egypt. Potiphar is identified as an Egyptian,
Pharaoh's officer and captain of the guard.

This verse says Potiphar buys Joseph from the hand of the Ishmaelites who
brought Joseph down.

The immediately retained prior custody statement says:

```text
GENESIS 37:36
MIDIANITES SOLD JOSEPH IN EGYPT TO POTIPHAR

GENESIS 39:1
POTIPHAR BOUGHT JOSEPH FROM ISHMAELITES WHO BROUGHT HIM TO EGYPT
```

The source supplies no transfer between those groups after entry into Egypt,
no joint seller statement, no alternate-name declaration and no correction.
Same Joe faces do not merge Midianite and Ishmaelite seller identities.

That completes S046:

```text
ONE BUYER: POTIPHAR
ONE PURCHASED PERSON: JOSEPH
ONE EGYPT PURCHASE MOMENT
SELLER LEDGER A: MIDIANITES
SELLER LEDGER B: ISHMAELITES
IDENTITY/CUSTODY BRIDGE: NOT SUPPLIED
```

Potiphar's purchase boil becomes a Joe-faced receipt printing two seller names
on the same signature line.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Potiphar sees a boilless nobody in a superhero suit poke the boil, lick an
empty finger, walk away and never look back. Joseph remains purchased and the
seller equivalence remains unresolved.

## Genesis 39:2–6 — EVERYTHING EXCEPT THE FOOD

The LORD is with Joseph. The source calls Joseph prosperous while he is in his
Egyptian master's house.

Potiphar sees that the LORD is with Joseph and that the LORD makes everything
Joseph does prosper in his hand. This sight/interpretation is explicitly
assigned to Potiphar by the source.

Joseph finds favor, ministers to Potiphar and becomes house overseer. Potiphar
puts all he has in Joseph's hand.

From that appointment, the LORD blesses the Egyptian's house for Joseph's sake.
The LORD's blessing is on all Potiphar has in house and field.

Potiphar leaves everything in Joseph's hand and concerns himself with nothing
except the food he eats. The food boundary remains explicit; it is not silently
included in Joseph's control.

The source calls Joseph well-built and handsome. This physical description is
source testimony despite every living thing having the same Joe face.

No contradiction is routed. Trust, delegation, blessing and prosperity align
in this State.

## Genesis 39:7–10 — DAY BY DAY, NO

Potiphar's wife sets her eyes on Joseph and says:

> **POTIPHAR'S WIFE JOE:** `LIE WITH ME.`

Joseph refuses. He tells her Potiphar does not know what is with Joseph in the
house and has put everything into Joseph's hand. Joseph says nobody is greater
in the house, and Potiphar has withheld only his wife because she is his wife.

> **JOSEPH JOE:** `HOW THEN CAN I DO THIS GREAT WICKEDNESS, AND SIN AGAINST
> GOD?`

Those trust, wife and God relations are Joseph's stated reasons.

She speaks to Joseph day by day. Joseph does not listen to her to lie by her or
be with her. The repetition and refusal are observable; no private temptation,
fear, attraction or strategy is invented.

## Genesis 39:11–13 — THE GARMENT CHANGES HANDS

Joseph enters the house to do his work. None of the men of the house are
inside.

Potiphar's wife catches Joseph by his garment and says again:

> **POTIPHAR'S WIFE JOE:** `LIE WITH ME.`

Joseph leaves the garment in her hand and runs outside.

The physical sequence is exact:

```text
JOSEPH ENTERS TO WORK
-> WIFE CATCHES JOSEPH BY GARMENT
-> WIFE REQUESTS SEX
-> JOSEPH LEAVES GARMENT IN HER HAND
-> JOSEPH RUNS OUTSIDE
-> WIFE SEES GARMENT IN HAND + JOSEPH OUTSIDE
```

The garment proves possession and flight only. It does not independently prove
who initiated contact, whether anyone cried, or the purpose of entry.

## Genesis 39:14–18 — SAME GARMENT, REVERSED INITIATOR

Potiphar's wife calls the men of her house and says Potiphar brought a Hebrew
to mock `us`. She claims Joseph came in to lie with her, that she cried loudly,
and that he left the garment and fled when he heard.

This is the first accusation. It differs from the observed sequence:

```text
OBSERVED: SHE CATCHES HIM / SHE SAYS LIE WITH ME / HE RUNS
CLAIMED: HE COMES TO LIE WITH HER / SHE CRIES / HE RUNS
```

She lays the garment beside her until Potiphar comes home.

She then speaks to Potiphar with the same accusation, changing audience and
framing:

> **POTIPHAR'S WIFE JOE:** `THE HEBREW SERVANT, WHOM YOU BROUGHT TO US,
> CAME IN TO ME TO MOCK ME.`
>
> **POTIPHAR'S WIFE JOE:** `I LIFTED MY VOICE AND CRIED; HE LEFT HIS
> GARMENT AND RAN OUTSIDE.`

A Joe-faced fly in the corner opens CrackFlix:

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

He presses `SKIP`. His eyes glaze. Nothing skips. Potiphar hears the accusation
while Captain zones out.

That completes S047:

```text
WIFE INITIATES / PHYSICALLY CATCHES GARMENT
-> JOSEPH REFUSES BY FLIGHT / GARMENT REMAINS
-> WIFE CLAIMS JOSEPH INITIATED
-> GARMENT USED AS SUPPORT FOR REVERSED ACCOUNT
-> CLAIM REPEATED TO HOUSE MEN THEN POTIPHAR
-> SECOND REPEAT IS SKIP-ELIGIBLE
-> SKIP DOES NOTHING
```

The accusation boil grows into Joseph's Joe-faced garment holding Potiphar's
wife by the wrist while a caption says `GARMENT ATTACKED FIRST`.

Captain's eyes clear after the world has continued:

> **CAPTAIN CRACKHEAD:** `YOINK!`

He is an unexplained boilless nobody in a superhero suit. He pokes the boil,
licks an empty finger, walks away and never looks back. Potiphar's response and
Joseph's custody remain unchanged.

## Genesis 39:19–20 — FROM ALL THE HOUSE TO PRISON

Potiphar hears his wife's words: `This is what your servant did to me.` The
source says Potiphar's wrath is kindled. It does not specify the object of the
wrath, a fact-finding process, Joseph's reply, witness examination or garment
inspection.

Potiphar takes Joseph and puts him in the prison where the king's prisoners are
bound. Joseph is there in custody.

The prior trust State changes:

```text
POTIPHAR HOUSE: ALL POSSESSIONS IN JOSEPH HAND
-> WIFE ACCUSATION
-> POTIPHAR WRATH KINDLED
-> JOSEPH IN KING-PRISONER PRISON
```

This change alone is not routed as a second contradiction. New accusation
information visibly intervenes; the source does not record Potiphar claiming
the prior trust remained unchanged.

## Genesis 39:21–23 — EVERYTHING IN HIS HAND, AGAIN

The LORD is with Joseph in prison, shows him kindness and gives him favor in
the prison keeper's sight.

The keeper commits all prisoners to Joseph's hand. Whatever they do there,
Joseph is responsible. The keeper does not look after anything under Joseph's
hand because the LORD is with Joseph and makes what Joseph does prosper.

This repeats a structural State, not a contradiction:

```text
POTIPHAR HOUSE
LORD WITH JOSEPH -> FAVOR -> EVERYTHING COMMITTED -> OVERSEER TRUST

PRISON
LORD WITH JOSEPH -> FAVOR -> ALL PRISONERS COMMITTED -> RESPONSIBILITY TRUST
```

The two authorities, assets and places remain distinct. No `SKIP` is used
because this is repeated alignment, not repeated bullshit.

## Joe continuity ledger

- Joseph remains alive and moves from Potiphar purchase/house custody to prison
  custody; Jacob's false death belief remains unchanged elsewhere.
- Potiphar remains the Genesis 37 buyer/officer and Genesis 39 master.
- Potiphar's unnamed wife is a distinct Joe; no name is invented.
- house men hear the first accusation but are absent during the observed
  garment encounter.
- Ishmaelite and Midianite seller labels remain distinct unresolved groups.
- the garment is one nonliving evidence object across catch, flight, first
  accusation, storage and second accusation.
- the prison keeper is a new unnamed Joe, not silently Potiphar despite both
  holding authority.
- all prisoners are Joe-faced living people and remain distinct from Joseph.
- Captain remains permanently boilless and changes nothing.

## Bullshit pass

- banner: `THE CRACKHEAD BIBLE — ARTICLE 39 — GARMENT-BASED INCIDENT REPORT`;
- purchase receipt: `SELLER: MIDIANITES / ISHMAELITES / SELECT ONE`;
- Potiphar inventory panel: `EVERYTHING EXCEPT LUNCH`;
- garment evidence warning: `POSSESSION PROVES WHO POSSESSES IT`;
- CrackFlix: `S046 DUAL SELLER`; `S047 REVERSE INITIATOR`, with a glowing
  `SKIP` button connected to nothing;
- prison desk sign: `CRACKHEAD CORRECTIONS — PRISONER NOW RUNS PRISONERS`;
- barcode: `CHB-GEN39-S046-S047-23-YOINK`;
- footer: `BIG BAG OF CUSTODY — CHAIN MAY CHANGE LABELS`.

## Reconstruction boundary

- all 23 source verse markers are represented in ordered required States;
- Genesis 37 Midianite seller and Genesis 39 Ishmaelite seller statements remain
  separate parents; S046 does not solve their identity relation;
- direct LORD presence, blessing, kindness, favor and prosperity causation are
  retained as narrator-assigned divine acts;
- Joseph's refusal reasons remain his speech, not universal legal commentary;
- actual garment sequence remains separate from both accusation tellings;
- possession of garment is not treated as proof of accusation;
- Potiphar wrath target, investigation and belief are unresolved;
- prison trust does not erase prisoner custody;
- no direct God speech, trial, consent, sexual contact, punishment rationale or
  providential accusation motive is invented;
- prior Genesis open chains remain open;
- publication remains held and unpublished.

Continuation required: Genesis 40 introduces Pharaoh's cupbearer/baker prison
custody, paired dreams, Joseph's God-attributed interpretation claim, three-day
outcomes and the cupbearer's forgetting.
