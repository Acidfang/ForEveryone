# CRACKHEAD GENESIS 29

## Title page

**SEVEN YEARS FOR RACHEL.**

**HERE'S LEAH.**

**LOCAL RULE.**

Source parent: Genesis 29:1–35, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 29.

Parent manuscript: `GENESIS/028-RUN-FOR-YOUR-LIFE-AND-GET-MARRIED.md`.

CrackFlix:

- `S026 — SEVEN YEARS FOR RACHEL. HERE'S LEAH.`, episode
  `S026-E001-GEN29 — LOCAL RULE AFTER DELIVERY`;
- `S027 — THIS WILL MAKE HIM LOVE ME. I'M STILL HATED.`, episode
  `S027-E001-GEN29 — REUBEN DID NOT CLOSE IT`.

## Causal foundation

```text
JACOB REACHES EASTERN LAND
-> WELL + LARGE STONE + THREE WAITING FLOCKS
-> HARAN SHEPHERDS KNOW LABAN / REPORT RACHEL APPROACHING
-> SHEPHERDS STATE ALL-FLOCK / STONE-ROLL WATER PROCESS
-> RACHEL ARRIVES WITH LABAN'S SHEEP
-> JACOB ROLLS STONE / WATERS FLOCK
-> KISS + WEEP + KINSHIP REPORT
-> RACHEL REPORTS TO LABAN
-> LABAN RUNS / EMBRACES / KISSES / HOUSES JACOB
-> MONTH RESIDENCE
-> LABAN ASKS WAGES INSTEAD OF NOTHING-SERVICE
-> JACOB NAMES RACHEL + SEVEN YEARS
-> LABAN: BETTER GIVE HER TO YOU / STAY
-> JACOB SERVES SEVEN YEARS FOR RACHEL
-> JACOB: DAYS COMPLETE / GIVE MY WIFE
-> LABAN FEASTS MEN
-> EVENING: LABAN BRINGS LEAH / JACOB GOES IN
-> MORNING: LEAH IDENTITY DISCOVERED
-> JACOB CONFRONTS RACHEL-SERVICE / DECEIT
-> LABAN FIRST DISCLOSES LOCAL FIRSTBORN RULE
-> LEAH WEEK + RACHEL ALSO + SEVEN MORE YEARS
-> JACOB COMPLETES WEEK / RECEIVES RACHEL
-> BILHAH + ZILPAH SERVANT RELATIONS
-> JACOB LOVES RACHEL MORE / SERVES SEVEN MORE YEARS
-> LORD SEES LEAH HATED / OPENS WOMB / RACHEL BARREN
-> REUBEN BORN: NOW HUSBAND WILL LOVE ME
-> SIMEON BORN: LORD HEARD I AM HATED
-> LEVI BORN: NOW HUSBAND WILL BE JOINED
-> JUDAH BORN: PRAISE LORD
-> LEAH STOPS BEARING
```

## Genesis 29:1–8 — THE WELL PROCESS

Jacob continues into the land of the eastern children. He sees a field well,
three flocks lying nearby and a large stone over the well mouth. The source
describes the ordinary process: all flocks gather, the stone is rolled away,
the sheep are watered, and the stone is replaced.

> **JACOB JOE:** `MY RELATIVES, WHERE ARE YOU FROM?`

> **SHEPHERD JOES:** `HARAN.`

> **JACOB JOE:** `DO YOU KNOW LABAN, SON OF NAHOR?`

> **SHEPHERD JOES:** `WE KNOW HIM.`

> **JACOB JOE:** `IS HE WELL?`

> **SHEPHERD JOES:** `HE IS WELL.`
>
> `RACHEL HIS DAUGHTER IS COMING WITH THE SHEEP.`

Jacob says it is still midday and tells them to water/feed the sheep.

> **SHEPHERD JOES:** `WE CAN'T UNTIL ALL THE FLOCKS ARE GATHERED.`
>
> `THEN THEY ROLL THE STONE AWAY AND WE WATER THE SHEEP.`

The chapter does not enumerate every expected flock. Rachel arrives immediately
afterward, so the comic does not assert that Jacob violates the all-flocks
condition. Collective process and Jacob's next individual act remain distinct.

`Laban son of Nahor` is Jacob's spoken description. The retained genealogy has
Bethuel as Laban's father and Nahor as Bethuel's father. The source wording may
use a broader descendant relation; no immediate-father replacement is invented.

## Genesis 29:9–14 — RACHEL ARRIVES; LABAN RECEIVES JACOB

Rachel arrives while Jacob is speaking. She keeps her father Laban's sheep.
Jacob sees Rachel and Laban's flock, rolls away the stone and waters the flock.
He kisses Rachel, raises his voice and weeps.

Jacob tells Rachel he is her father's relative and Rebekah's son. Rachel runs
and tells Laban. Laban hears, runs to Jacob, embraces and kisses him, brings him
home, and hears Jacob's account.

> **LABAN JOE:** `YOU ARE MY BONE AND MY FLESH.`

Jacob stays one month. No romantic dialogue, Rachel response to the kiss,
reason for tears, travel duration or stone weight is supplied.

## Genesis 29:15–20 — THE WAGE IS RACHEL

> **LABAN JOE:** `BECAUSE YOU ARE MY RELATIVE, SHOULD YOU SERVE ME FOR NOTHING?`
>
> `TELL ME YOUR WAGES.`

Laban has two daughters: elder Leah and younger Rachel. The source describes
Leah's eyes as weak and Rachel as beautiful in form and appearance. Those
descriptions do not authorize production to give either woman a non-Joe face.

The source attributes Jacob's love for Rachel.

> **JACOB JOE:** `I WILL SERVE SEVEN YEARS FOR RACHEL, YOUR YOUNGER DAUGHTER.`

> **LABAN JOE:** `IT IS BETTER THAT I GIVE HER TO YOU THAN ANOTHER MAN.`
>
> `STAY WITH ME.`

The named person, younger-daughter relation, service period and wage context are
all established before service. Laban states no elder-first rule, alternative
bride, extra week or second service term here.

Jacob serves seven years for Rachel. The source says they seem like a few days
to him because of his love; that is source-attributed duration experience, not
a panel inferred from his face.

## Genesis 29:21–25 — THE NIGHT DELIVERY CHANGES THE PERSON

After seven years:

> **JACOB JOE:** `MY DAYS ARE COMPLETE.`
>
> `GIVE ME MY WIFE SO I MAY GO IN TO HER.`

Laban gathers all local men and makes a feast. In the evening he takes Leah and
brings her to Jacob. Jacob goes in to her. Laban gives Zilpah to Leah as servant.

The source supplies no statement that Laban announces Leah, that Jacob checks
identity, that Rachel is present, or that Leah speaks. The fly does not invent
darkness, veil, intoxication, consent dialogue or a method explaining the
unrecognized identity.

Morning changes the observed identity State:

```text
NIGHT RECIPIENT ASSUMED/ADDRESSED THROUGH COMPLETED RACHEL WAGE
MORNING: IT WAS LEAH
```

> **JACOB JOE:** `WHAT HAVE YOU DONE TO ME?`
>
> `DIDN'T I SERVE YOU FOR RACHEL?`
>
> `WHY DID YOU DECEIVE ME?`

That discovery and confrontation complete S026. Seven-year service did produce
a wife delivery, but not the named wage person.

Laban's wage-delivery boil becomes Leah's full Joe face wearing a barcode that
reads `RACHEL CONTRACT / LEAH DELIVERY`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. Leah remains Jacob's wife and Laban
still answers.

## Genesis 29:26–30 — THE LOCAL RULE ARRIVES AFTERWARD

> **LABAN JOE:** `WE DON'T GIVE THE YOUNGER BEFORE THE FIRSTBORN HERE.`
>
> `FULFILL THIS ONE'S WEEK.`
>
> `WE WILL GIVE YOU THE OTHER ALSO FOR SEVEN MORE YEARS OF SERVICE.`

The local rule first appears after:

- Rachel was named as the wage;
- Laban responded that giving her to Jacob was better;
- seven years were fully served;
- Jacob requested his completed-term wife;
- Laban delivered Leah;
- morning exposed Leah.

No earlier retained update inserted that rule into the agreement. The rule does
not undo S026; it explains the replacement only after the replacement occurred
and creates a new term for Rachel.

Jacob fulfills Leah's week. Laban gives Rachel as wife and gives Bilhah to
Rachel as servant. Jacob goes in to Rachel, loves Rachel more than Leah, and
serves seven additional years.

The source does not say the second seven years occur before Rachel is given;
Rachel follows the fulfilled week, and service follows as an ongoing second
term. Both marriages and both service periods remain.

## Genesis 29:31–33 — REUBEN DID NOT CLOSE IT

The LORD sees that Leah is hated and opens her womb. Rachel is barren. `Hated`
and `barren` are source States; no facial evidence, cause for Rachel's barrenness
or direct God speech is invented.

Leah conceives, bears a son and names him Reuben.

> **LEAH JOE:** `THE LORD LOOKED AT MY AFFLICTION.`
>
> `NOW MY HUSBAND WILL LOVE ME.`

Leah conceives again, bears Simeon and says:

> **LEAH JOE:** `THE LORD HEARD THAT I AM HATED.`
>
> `HE GAVE ME THIS SON TOO.`

That second statement completes S027:

```text
AFTER REUBEN: NOW MY HUSBAND WILL LOVE ME
AFTER SIMEON: LORD HEARD I AM HATED
REUBEN BIRTH REMAINS COMPLETED BETWEEN BOTH STATEMENTS
```

No private Jacob feeling is inferred. Leah's own later words retain the
non-closure of the result she predicted after Reuben.

Leah's family-outcome boil grows a Joe-faced progress bar labelled
`HUSBAND LOVE: STILL SOURCE-REPORTED HATED`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. Reuben and Simeon remain distinct
sons and Leah's next pregnancies continue.

## Genesis 29:34–35 — LEVI AND JUDAH

Leah conceives again and bears Levi.

> **LEAH JOE:** `NOW MY HUSBAND WILL BE JOINED TO ME.`
>
> `I HAVE BORNE HIM THREE SONS.`

No later chapter-29 State confirms or denies that prediction, so it remains an
open statement rather than a new contradiction episode.

Leah conceives again and bears Judah.

> **LEAH JOE:** `THIS TIME I WILL PRAISE THE LORD.`

Then Leah stops bearing. The chapter does not say the stop is permanent, chosen,
caused by God or known to Leah as a final State.

## Character and world-ledger changes

- Jacob: reaches Haran region; moves well stone/waters flock; kisses/weeps;
  reports kinship; resides/serves; agrees seven years for Rachel; receives Leah;
  confronts substitution; accepts fulfilled week/Rachel/second seven years;
  becomes father of Reuben, Simeon, Levi and Judah.
- Laban: receives sister's son; asks wages; responds to Rachel term; receives
  seven years; delivers Leah; first states local elder rule after discovery;
  gives Rachel after Leah's week; receives second seven-year service.
- Rachel: new Joe identity; Laban's younger daughter/shepherd; reports Jacob;
  becomes Jacob wife; receives Bilhah; source records greater love and barrenness.
- Leah: new Joe identity; Laban's elder daughter; delivered to Jacob; receives
  Zilpah; becomes wife; source records hated State; bears/names four sons.
- Zilpah/Bilhah: new servant Joe identities assigned respectively to Leah/Rachel;
  no speech, consent, prior history or later acts imported.
- Reuben/Simeon/Levi/Judah: four distinct new born Joe identities with exact
  mother/father/birth order/naming-speech relations.
- Haran shepherds: answer origin/Laban/well questions and state watering process.
- well flocks: living Joe-faced sheep gathered/watered; individual lineages and
  counts beyond initial three flocks remain unresolved.
- feast men: gathered by Laban; no speech or knowledge of substitution assigned.

## Fuck-up pass

- children of the east -> literal adult Joes wearing `EAST'S CHILD` badges.
- three flocks -> `FLOCK 1`, `FLOCK 2`, `FLOCK 3`, every sheep with Joe face.
- large stone -> `MULTI-USER WELL PASSWORD`, moved by one Jacob.
- Laban son of Nahor -> genealogy printer outputs `BETHUEL` in tiny corrective text.
- bone and flesh -> Laban hands Jacob a Joe-faced bone and steak identification kit.
- seven years -> `RACHEL PAYMENT PLAN: 84 MONTHS / PERSON MAY VARY`.
- feast -> `CRACKHEAD DELIVERY WINDOW: EVENING`.
- morning Leah -> alarm clock displaying Leah's Joe face instead of time.
- local rule -> `TERMS DISCLOSED AFTER FULFILMENT` in microscopic lettering.
- fulfill her week -> calendar stamped `WIFE 1 ACTIVATION PERIOD`.
- seven more years -> receipt reads `RACHEL TOTAL: 14 YEARS + LEAH`.
- weak eyes -> Leah wears structural-support glasses for weak eyeballs.
- opened womb -> `CRACKHEAD PRODUCTION PORT: OPEN`.
- Reuben -> `RUBEN SANDWICH JOE`, newborn wrapped like lunch.
- Simeon -> `SIM-E-ON JOE`, simulation switch permanently on.
- Levi -> `LEVY JOE`, charging three-son joining tax.
- Judah -> `YOU-DA JOE`, praising through a useless pointing sign.

## God-line boundary

Genesis 29 directly narrates that the LORD sees Leah's hated State and opens her
womb. Leah attributes looking/hearing/giving to the LORD in her own naming
speeches. No God or divine messenger speaks directly. The God ledger retains
the narrated seeing/opening acts and keeps Leah's statements as character
attributions.

## FIR verification

- All 35 verse markers are covered in order.
- The shepherd all-flocks condition is not declared broken after Rachel arrives.
- `Laban son of Nahor` remains spoken descendant wording; Bethuel father lineage
  is not overwritten.
- Rachel's arrival precedes Jacob's stone/watering/kiss/report acts.
- Wage request, named Rachel term, Laban response and seven-year completion all
  precede Leah delivery.
- No veil, darkness, intoxication, consent dialogue or recognition mechanism is
  invented.
- S026 closes at morning Leah discovery and Rachel-service confrontation.
- The local firstborn rule is retained only where first disclosed, after delivery.
- Leah week precedes Rachel delivery; second service term follows.
- Rachel/Leah love comparison, hated State and barrenness remain source
  attributions rather than facial inference.
- S027 uses Leah's own post-Reuben and post-Simeon statements; no Jacob mind is
  invented.
- Levi's joined prediction remains open; Judah praise does not close it.
- All four sons and both servants receive distinct Joe identities.
- Captain appears only after completed contradictions, says only `YOINK!`, is
  boilless and changes nothing.
- No `SKIP`, direct God speech, retrospective contract term or permanent
  childbearing conclusion is invented.
- Manuscript remains held and unpublished.

Continuation required: Genesis 30 receives Rachel/Leah childbearing conflict,
Bilhah/Zilpah wife/child acts, Dan/Naphtali/Gad/Asher/Issachar/Zebulun/Dinah/
Joseph births, mandrake transaction, departure/wage negotiation, livestock
pattern agreement, Laban's removal act and Jacob's breeding/property increase.
