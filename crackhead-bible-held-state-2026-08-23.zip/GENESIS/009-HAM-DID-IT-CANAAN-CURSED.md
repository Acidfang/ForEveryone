# CRACKHEAD GENESIS 9

## Title page

**HAM DID IT. CANAAN GETS CURSED.**

Source parent: Genesis 9:1–29, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 9.

Parent manuscript: `GENESIS/008-THE-HEART-IS-STILL-EVIL.md`.

CrackFlix crossover: `S009 — WRONG JOE GETS THE SENTENCE`.

## Causal foundation

```text
POST-FLOOD HOUSEHOLD + LIVING KINDS
-> GOD BLESSES / COMMANDS MULTIPLICATION
-> ANIMAL FEAR + HUMAN HAND RELATION
-> MOVING LIFE BECOMES FOOD
-> BLOOD/LIFE FOOD PROHIBITION
-> LIFE-BLOOD ACCOUNTING + HUMAN-BLOOD CONSEQUENCE
-> COVENANT ESTABLISHED WITH HOUSEHOLD/OFFSPRING/CREATURES
-> NO MORE EARTH-DESTROYING FLOOD
-> RAINBOW INSTALLED AS PERPETUAL SIGN/REMINDER
-> THREE SONS POPULATE EARTH; HAM FATHERS CANAAN
-> NO-AH FARMS -> VINEYARD -> WINE -> DRUNK -> UNCOVERED IN TENT
-> HAM SEES + TELLS BROTHERS
-> SHEM/JAPHETH BACKWARD-COVER WITHOUT SEEING
-> NO-AH WAKES / KNOWS YOUNGEST-SON ACT
-> CANAAN CURSED; SHEM/JAPHETH STATEMENTS
-> NO-AH LIVES 350 MORE -> DIES AT 950
```

## Genesis 9:1–7 — FOOD, BLOOD AND ACCOUNTING

God blesses No-Ah and his sons and commands them to be fruitful, multiply and
fill Earth. Animals, birds, ground-movers and fish receive fear/dread of humans
and are delivered into human hands.

Every moving living thing becomes food as green plants were previously given.
One boundary is explicit:

> **CRACKHEAD GOD:** `DON'T EAT FLESH WITH ITS LIFE—ITS BLOOD—STILL IN IT.`

God requires accounting for human life-blood from animals and humans. Whoever
sheds human blood will have their blood shed by a human, because God made
humankind in God's image.

> **CRACKHEAD GOD:** `MULTIPLY. A LOT. FILL THE PLACE.`

This changes the food inventory from the earlier plant grant. It does not erase
the blood prohibition or authorize unspecified preparation methods.

Label: `CRACKHEAD BLOOD ACCOUNTING — EVERY DROP HAS A JOE NUMBER`.

## Genesis 9:8–17 — RAIN-BOW CONTRACT

God establishes the previously promised covenant with:

- No-Ah and his sons;
- their offspring;
- every bird, livestock animal and animal that left the ship;
- every living creature of all flesh on Earth.

Terms: all flesh will not again be cut off by floodwater; no flood will again
destroy Earth.

God sets a rainbow in cloud as the perpetual-generation sign between God and
Earth. When cloud and rainbow appear, God will remember and look upon the
everlasting covenant.

> **CRACKHEAD GOD:** `RAIN-BOW. CLOUD. LOOK. REMEMBER.`
>
> `NO MORE DELETE-EVERYTHING FLOOD.`

Display: an enormous literal bow made of rain, with a Joe face where a knot
would be. It remains a rainbow and covenant sign.

The sign does not cause the covenant; God establishes the covenant and assigns
the sign.

## Genesis 9:18–19 — THREE POPULATION ROOTS

Shem Joe, Ham Joe and Japheth Joe exit the ship. Ham is identified as Canaan
Joe's father. From the three sons, the whole Earth is populated.

This creates ancestry roots for later peoples. It does not yet authorize modern
nation labels, traits or geography. Genesis 10 must derive the named branches.

## Genesis 9:20–21 — NO-AH'S VINEYARD INCIDENT

No-Ah begins farming and plants a vineyard. He drinks its wine, becomes drunk,
and lies uncovered inside his tent.

```text
PLANT VINEYARD -> WINE AVAILABLE -> DRINK -> DRUNK -> UNCOVERED IN TENT
```

The source supplies no production process, quantity, intention or witness to
the undressing. Do not invent one.

Tent label: `CRACKHEAD PRIVATE VINEYARD QUALITY LAB`.

## Genesis 9:22–23 — SEE / TELL / COVER

Ham Joe, father of Canaan, sees his father's nakedness and tells his two
brothers outside.

Shem Joe and Japheth Joe take a garment on their shoulders, walk backward, and
cover No-Ah. Their faces point backward and they do not see his nakedness.

The comic shows the actions exactly. It does not label Ham's motive, invent
mockery, sexual conduct or a command that preceded the event.

All three share Joe's face; direction, garment and action distinguish them.

## Genesis 9:24–25 — HAM DID IT, CANAAN GETS IT

No-Ah wakes from his wine and knows what his youngest son did to him. The source
does not state how he knows or identify anything beyond the retained sequence.

Then No-Ah says:

> **NO-AH JOE:** `CANAAN IS CURSED.`
>
> `SERVANT OF SERVANTS TO HIS BROTHERS.`

Observable chain:

```text
HAM JOE: SEES + TELLS
SHEM/JAPHETH: COVER
NO-AH: KNOWS YOUNGEST-SON ACT
CANAAN JOE: RECEIVES CURSE STATEMENT
```

No act by Canaan Joe and no sanction-transfer rule appears in this chapter.
That completes `S009-E001 — HAM DID IT, CANAAN GETS CURSED`.

Captain appears boilless in his unexplained suit after the curse statement.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes No-Ah's boil, licks his finger, walks away eating the crack crystal he
sees, and does not look back. Everyone else sees only poking and licking. The
curse statement and family outcome remain unchanged.

## Genesis 9:26–27 — BRANCH DECLARATIONS

No-Ah continues:

- the LORD, God of Shem, is blessed;
- Canaan is to serve Shem;
- God is asked to enlarge Japheth;
- Japheth is to dwell in Shem's tents;
- Canaan is to serve Japheth.

These are No-Ah's spoken declarations. Their later completion or
non-completion must be reconstructed from descendant histories rather than
asserted here.

## Genesis 9:28–29 — NO-AH CLOCKS OUT

No-Ah lives 350 years after the flood. His total life is 950 years. Then he
dies.

His same Joe identity now closes living State. The ark builder, bird tester,
farmer, drunk tent occupant and lineage speaker are not separate Joes because
their life Moments do not create a new identity root.

## Character and world-ledger changes

- No-Ah: receives blessing/covenant; farms; plants vineyard; drinks; becomes
  drunk/uncovered; wakes; knows a son-act; curses Canaan; declares branch
  relations; dies at 950.
- Shem: covered father backward; receives God/tent/Canaan declarations.
- Ham: fathers Canaan; sees nakedness; tells brothers; identified as youngest
  son through No-Ah's later knowledge statement where applicable.
- Japheth: covers backward; receives enlargement/tent/Canaan declarations.
- Canaan: new Joe identity, child of Ham, receives curse/service declarations
  without a recorded act in this chapter.
- world: meat-food permission, blood prohibition, homicide accounting and
  rainbow covenant become inherited post-flood conditions.

## Fuck-up pass

- Noah -> No-Ah Joe.
- Ham -> Ham Joe; background meat packet labelled `HAM? WRONG JOE`.
- Canaan -> Can-a-Nan Joe in signage, source identity retained.
- rainbow -> literal Rain-Bow covenant hardware.
- covenant -> `CRACKHEAD CLOUD SERVICE AGREEMENT — PERPETUAL PLAN`.
- vineyard -> `PRIVATE QUALITY LAB`.
- nakedness covering -> `CRACKHEAD REVERSE GARMENT INSTALLATION`.

## FIR verification

- All 29 verse markers are covered in order.
- Blessing/multiplication precede food and blood boundaries.
- Covenant parties, terms, duration and rainbow sign remain explicit.
- Rainbow is sign/reminder, not invented covenant cause.
- Ham/Canaan ancestry is established before the tent occurrence.
- Vineyard precedes wine, drunkenness and uncovered State.
- Ham's act and brothers' covering remain separate observable sequences.
- S009 retains Ham as actor and Canaan as sanctioned Joe without inventing why.
- Captain appears only after that completed friction and changes nothing.
- No-Ah's branch declarations remain statements pending later history.
- Death at 950 closes the same identity's living State.
- Manuscript remains held and unpublished.

Continuation required: Genesis 10 derives the first explicit families,
languages, lands and nations from Japheth, Ham and Shem, including Nimrod,
Shinar, Babel and territorial boundaries.
