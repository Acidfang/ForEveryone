# CRACKHEAD GENESIS 16

## Title page

**I GAVE HER TO YOU. THIS IS YOUR FAULT.**

Source parent: Genesis 16:1–16, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 16.

Parent manuscript: `GENESIS/015-COUNT-STARS-CUT-ANIMALS.md`.

CrackFlix: `S012 — I DID IT. YOUR FAULT.`, episode
`S012-E001-GEN16 — I GAVE HER TO YOU`.

## Causal foundation

```text
SARAI HAS NO CHILD + HAGAR IS HER EGYPTIAN SERVANT
-> SARAI PROPOSES HAGAR AS CHILD-BEARING ROUTE
-> ABRAM LISTENS
-> TEN-YEAR CANAAN MARK
-> SARAI TAKES HAGAR AND GIVES HER TO ABRAM AS WIFE
-> ABRAM GOES IN TO HAGAR -> HAGAR CONCEIVES
-> HAGAR SEES CONCEPTION -> SARAI DESPISED IN HAGAR'S EYES
-> SARAI SAYS WRONG IS ABRAM'S FAULT
   WHILE SAYING "I GAVE MY SERVANT"
-> ABRAM RETURNS HAGAR TO SARAI'S HAND
-> SARAI TREATS HAGAR HARSHLY -> HAGAR FLEES
-> LORD'S ANGEL FINDS HAGAR AT WILDERNESS FOUNTAIN
-> QUESTION -> HAGAR STATES FLIGHT
-> RETURN/SUBMIT COMMAND + OFFSPRING/SON PROMISE
-> ISHMAEL NAME + FUTURE CONFLICT DESCRIPTION
-> HAGAR NAMES THE LORD WHO SPOKE
-> WELL RECEIVES NAME AND LOCATION
-> HAGAR BEARS SON -> ABRAM NAMES HIM ISHMAEL AT AGE 86
```

## Genesis 16:1–3 — THE SELECTED ROUTE

Sarai has borne Abram no children. She has an Egyptian servant named Hagar.

> **SARAI JOE:** `THE LORD HAS RESTRAINED ME FROM BEARING.`
>
> `PLEASE GO IN TO MY SERVANT.`
>
> `MAYBE I'LL OBTAIN CHILDREN BY HER.`

Abram listens to Sarai. After Abram has lived ten years in Canaan, Sarai takes
Hagar and gives her to Abram as his wife.

The source identifies Hagar as Sarai's servant and records Sarai taking and
giving her. It records no speech or consent from Hagar in this transition. The
comic retains that absence instead of supplying agreement, refusal or motive.

## Genesis 16:4 — THE REQUESTED STATE ARRIVES

Abram goes in to Hagar. Hagar conceives. When Hagar sees that she has conceived,
Sarai is despised in Hagar's eyes.

The source states the changed regard but supplies no spoken insult, witnessed
gesture or explanation. Production may show the Joes in the same room; it may
not invent an observable act for `despised in her eyes`.

## Genesis 16:5 — I GAVE HER. YOUR FAULT.

> **SARAI JOE:** `THIS WRONG IS YOUR FAULT.`
>
> `I GAVE MY SERVANT INTO YOUR BOSOM.`
>
> `WHEN SHE SAW SHE HAD CONCEIVED, SHE DESPISED ME.`
>
> `MAY THE LORD JUDGE BETWEEN ME AND YOU.`

That speech completes the exact friction. Sarai retains her own producing act
and assigns the wrong to Abram in the same account. Nothing here decides how
responsibility ought to be distributed; the contradiction series records only
the two observable statements.

A suited, completely boilless Captain Crackhead touches Sarai's largest status
boil.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Sarai and Abram see a nobody poke the boil, lick his finger and walk away without
looking back. Captain sees a crack crystal eaten. The household State does not
change.

This is the first retained occurrence of S012, so no `SKIP` appears.

## Genesis 16:6 — IN YOUR HAND

> **ABRAM JOE:** `YOUR MAID IS IN YOUR HAND.`
>
> `DO TO HER WHATEVER IS GOOD IN YOUR EYES.`

Sarai deals harshly with Hagar. Hagar flees from her face.

`Good in your eyes` is Abram's quoted permission. `Dealt harshly` and flight
are the observed result. The manuscript does not rename the result good or add
an unrecorded act.

## Genesis 16:7–9 — FOUND AT THE FOUNTAIN

The LORD's angel finds Hagar at a wilderness fountain on the way to Shur.

> **LORD'S ANGEL JOE:** `HAGAR, SARAI'S SERVANT: WHERE DID YOU COME FROM?`
>
> `WHERE ARE YOU GOING?`

> **HAGAR JOE:** `I'M FLEEING FROM MY MISTRESS SARAI.`

> **LORD'S ANGEL JOE:** `RETURN TO YOUR MISTRESS.`
>
> `SUBMIT UNDER HER HANDS.`

The question, Hagar's stated flight and the return command stay separate. The
comic does not convert being found into rescue or the command into endorsement
by the narrator.

## Genesis 16:10–12 — ISHMAEL

The LORD's angel says Hagar's offspring will be multiplied beyond counting.
Hagar is pregnant and will bear a son. She must call him Ishmael because the
LORD has heard her affliction.

The angel describes the future son as a wild donkey among men: his hand against
every man, every man's hand against him, living opposed to all his brothers.

These are source future statements. They are not current conduct, inherited
guilt, a diagnosis or permission for later Joes to fill in events.

The donkey in the comparison has Joe's face. It is a comparison, not a newly
present animal unless production misreads it. *shrug* OK.

## Genesis 16:13–14 — THE GOD WHO SEES

Hagar calls the LORD who spoke to her:

> **HAGAR JOE:** `YOU ARE A GOD WHO SEES.`
>
> `HAVE I EVEN STAYED ALIVE AFTER SEEING HIM?`

The well is called Beer Lahai Roi—`well of the one who lives and sees me`—and
is located between Kadesh and Bered.

The source first calls the speaker the LORD's angel, then says Hagar named the
LORD who spoke. The manuscript retains that transition and does not settle the
speaker's ontology. The fountain has a Joe-faced well housing labelled
`CRACKHEAD LIVE VIEWER — BEER LOW-HIGH ROY`.

## Genesis 16:15–16 — BIRTH STATE

Hagar bears Abram a son. Abram names the son Hagar bore Ishmael. Abram is 86
years old when Hagar bears Ishmael to him.

The birth closes the chapter's promised son/name State. It does not erase the
servant relation, flight, return command or harsh-treatment parent chain.

## Character and world-ledger changes

- Sarai: no-child State; proposes Hagar route; takes/gives Hagar as Abram's
  wife; later states both her act and Abram's fault; receives Hagar back into
  her hand; treats Hagar harshly.
- Abram: listens; receives Hagar as wife; fathers Ishmael; returns authority
  over Hagar to Sarai; names Ishmael at age 86.
- Hagar: Egyptian servant of Sarai; is taken/given as Abram's wife without
  retained speech; conceives; flees harsh treatment; is found and questioned;
  states flight; receives return command and future promise; names the LORD;
  bears Ishmael.
- Ishmael: promised/name-commanded before birth, then born to Hagar and Abram.
- LORD's angel: finds, questions, commands, promises and describes future State;
  exact relation to the LORD remains source-retained and unresolved here.
- Beer Lahai Roi: named well between Kadesh and Bered.

## Fuck-up pass

- Hagar -> `HAG-ARRR JOE`, on an Egyptian household inventory ticket.
- Shur -> `SURE` on an arrow pointing both ways.
- Ishmael -> `IS-MALE JOE`, while every face remains Joe.
- Beer Lahai Roi -> `BEER LOW-HIGH ROY`, containing neither beer nor Roy.
- source household form -> `CRACKHEAD FAMILY EXPANSION REQUEST / NO HAGAR
  SIGNATURE FIELD`.
- Sarai's boil -> gold-framed `SUCCESS ASSET / DO NOT LICK`.
- margin stamp -> `CRACKFLIX S012 E001 — FIRST PLAY / SKIP UNAVAILABLE`.

## FIR verification

- All 16 verse markers are covered in order.
- Sarai's initial proposal precedes her taking/giving act; that act precedes
  conception; conception and changed regard precede her blame statement.
- S012 is grounded only in Sarai's explicit `I gave` / `your fault` speech.
- Hagar's missing speech/consent in verses 1–4 remains missing.
- Harsh treatment precedes flight; flight precedes discovery and return command.
- The messenger's identity wording is not silently collapsed into God.
- Promise, naming instruction and birth are distinct States.
- Captain appears only after the contradiction completes, says only `YOINK!`,
  has no boil and changes nothing.
- No `SKIP` is used on a first retained episode.
- Ancient/religious overlap remains source-specific unless another witness
  passes the full occurrence-identity test.
- Manuscript remains held and unpublished.

Continuation required: Genesis 17 receives Abram at 99, covenant/name changes,
circumcision requirement, Sarai-to-Sarah change, Isaac promise, Ishmael request
and household circumcision execution.
