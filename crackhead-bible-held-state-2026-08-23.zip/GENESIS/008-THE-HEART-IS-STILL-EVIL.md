# CRACKHEAD GENESIS 8

## Title page

**THE HEART IS STILL EVIL. SO I'M NOT DOING THAT AGAIN.**

Source parent: Genesis 8:1–22, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 8.

Parent manuscript: `GENESIS/007-GOD-SHUT-THE-DOOR.md`.

CrackFlix crossover: `S008 — SAME REASON OPPOSITE POLICY`.

## Causal foundation

```text
150-DAY WATER STATE + LOADED CLOSED SHIP
-> GOD REMEMBERS OCCUPANTS
-> WIND + WATER SOURCES STOPPED -> RECESSION
-> MONTH 7 DAY 17: SHIP RESTS ON ARARAT MOUNTAINS
-> MONTH 10 DAY 1: MOUNTAIN TOPS VISIBLE
-> 40 DAYS -> RAVEN TEST
-> DOVE TEST 1: NO REST / RETURNS
-> 7 DAYS -> DOVE TEST 2: OLIVE LEAF / WATER ABATED KNOWN
-> 7 DAYS -> DOVE TEST 3: NO RETURN
-> YEAR 601 MONTH 1 DAY 1: SURFACE OBSERVED DRY
-> MONTH 2 DAY 27: EARTH DRY
-> GOD COMMANDS EXIT + MULTIPLICATION
-> ALL SHIP FAMILIES EXIT
-> NO-AH ALTAR + CLEAN BURNT OFFERINGS
-> GOD SMELLS AROMA
-> SAME HUMAN-HEART EVIL CONDITION -> NO-REPEAT COMMITMENT
-> EARTH CYCLES PROMISED TO CONTINUE
```

## Genesis 8:1–3 — REMEMBERED, WIND, RECESSION

God remembers No-Ah and every animal and livestock animal with him. God sends a
wind over Earth. Waters subside. Deep fountains and sky windows stop; sky rain
is restrained; water continually recedes. At 150 days, recession is observed.

`Remembered` is retained as the source transition address. The comic does not
invent prior divine forgetting, memory hardware or a reminder notification.

## Genesis 8:4–5 — ARARAT REST

On month 7, day 17, the ship rests on Ararat's mountains. Water continues
receding. On month 10, day 1, mountain tops become visible.

Place rendering: **ARRR-A-RAT Mountains**, full of Joe-faced rats wearing pirate
hats. The source address Ararat remains intact.

Resting is not exit. Visible tops are not a dry-earth declaration.

## Genesis 8:6–12 — CRACKHEAD BIRD PROBE ARRAY

After forty days, No-Ah opens his constructed ship window.

- Raven Joe goes back and forth until Earth water dries.
- Dove Joe test 1 finds no foot-rest, returns, and is taken back by hand.
- No-Ah waits seven days.
- Dove Joe test 2 returns at evening with a freshly plucked olive leaf.
- No-Ah thereby knows the waters have abated.
- No-Ah waits another seven days.
- Dove Joe test 3 does not return.

Every bird has Joe's face. The olive leaf may also have a tiny Joe face because
production interpreted veins as features. Nobody treats that as evidence.

No-Ah's knowledge derives from the returned leaf, not an invented satellite or
omniscience.

## Genesis 8:13–14 — LOOKED DRY / WAS DRY

In No-Ah's 601st year, month 1, day 1, Earth water is dried from the surface.
No-Ah removes the ship covering, looks, and sees dry ground surface.

On month 2, day 27, Earth is dry.

The two States remain separate:

```text
OBSERVED SURFACE DRY -> LATER EARTH DRY
```

## Genesis 8:15–19 — EVERY JOE OUT

> **CRACKHEAD GOD:** `GET OUT.`
>
> `WIFE. SONS. THEIR WIVES. ALL THE LIVING THINGS.`
>
> `BREED. BE FRUITFUL. MULTIPLY ON EARTH.`

No-Ah exits with his wife, sons and sons' wives. Every animal, creeping thing
and bird exits after its families.

The ship-bound people State ends. A new post-flood Earth population State begins
from the retained occupants; nations and languages still have not yet emerged.

## Genesis 8:20 — ALTAR

No-Ah builds an altar to God. He takes from every clean animal and clean bird
and offers burnt offerings.

The earlier seven-pair quantities make clean creatures available beyond a
single preservation pair. The manuscript retains that dependency without
claiming the source explicitly states this as its motive.

Label: `CRACKHEAD CLEAN INVENTORY — SOME STOCK CONVERTED TO SMOKE`.

## Genesis 8:21 — SAME REASON, OPPOSITE POLICY

God smells the pleasant aroma and says in his heart:

> **CRACKHEAD GOD:** `I'M NOT CURSING THE GROUND AGAIN FOR HUMAN JOE.`
>
> `HIS HEART'S IMAGINATION IS EVIL FROM YOUTH.`
>
> `I'M NEVER AGAIN STRIKING EVERY LIVING THING LIKE I JUST DID.`

Retained cross-chapter Difference:

```text
GENESIS 6: HUMAN HEART CONTINUALLY EVIL
-> GOD DECIDES TO DESTROY LIVING THINGS

GENESIS 8: HUMAN HEART EVIL FROM YOUTH
-> GOD COMMITS NOT TO REPEAT THAT DESTRUCTION
```

The condition remains; the selected policy changes after the flood and
offering. This completes `S008-E001 — THE HEART IS STILL EVIL`.

Captain's glazed eyes clear. He appears as a boilless nobody in a superhero
suit.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes God's boil, licks his finger, walks away eating the crack crystal he
sees, and never looks back. Everyone else sees poking and finger-licking. God's
commitment remains identical without him.

## Genesis 8:22 — EARTH CLOCK

> **CRACKHEAD GOD:** `WHILE EARTH REMAINS:`
>
> `SEEDTIME / HARVEST.`
>
> `COLD / HEAT.`
>
> `SUMMER / WINTER.`
>
> `DAY / NIGHT.`
>
> `THEY DON'T STOP.`

This is a God-only continuity commitment bounded by `while Earth remains`. It
does not promise a particular harvest quantity, climate at every place or human
success.

Background logo: `CRACKHEAD EARTH CLOCK — STILL IS`.

## Character and world-ledger changes

- No-Ah: performs raven/dove tests, derives water-abatement knowledge, observes
  ground, exits on command, builds altar and offers clean creatures.
- Raven Joe: back-and-forth flight until drying; no speech.
- Dove Joe: three distinct test Moments with return/no-rest, leaf return, and
  no-return States.
- God: remembers, sends wind, commands exit, receives aroma, commits against
  repeat total strike and promises Earth-cycle continuity.
- household and animal families: exit into post-flood Earth State.
- Ararat mountains: first retained post-flood ship-rest place.

## Fuck-up pass

- Noah -> No-Ah Joe.
- Ararat -> Arrr-A-Rat Mountains.
- raven/dove -> `CRACKHEAD BIRD PROBE ARRAY`.
- olive leaf -> Joe-faced leaf production error retained.
- altar -> `CRACKHEAD CLEAN INVENTORY CONVERSION UNIT` background label.
- seasons/cycles -> `CRACKHEAD EARTH CLOCK`.

## FIR verification

- All 22 verse markers are covered in order.
- 150-day water State precedes wind, stoppage and recession.
- Every landing/visibility/test/dryness calendar State remains distinct.
- Dove knowledge derives from the returned olive leaf.
- Dry observation precedes divine exit command; nobody exits early.
- Exit precedes altar and offering.
- Offering/aroma precedes God's heart statement.
- S008 uses the exact repeated evil-heart condition and opposite policy States.
- Captain occurs only after the contradiction completes and changes nothing.
- Earth-cycle commitment retains its `while Earth remains` boundary.
- Manuscript remains held and unpublished.

Continuation required: Genesis 9 receives blessing, food/blood boundaries,
human-blood accounting, covenant terms, rainbow sign, family/nation lineage,
No-Ah's vineyard/nakedness and Canaan statements.
