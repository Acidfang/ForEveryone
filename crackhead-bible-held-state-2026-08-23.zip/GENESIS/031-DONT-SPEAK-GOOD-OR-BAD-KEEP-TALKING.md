# CRACKHEAD GENESIS 31

## Title page

**DON'T SPEAK TO JACOB GOOD OR BAD.**

**I CAME HERE TO SPEAK TO JACOB.**

**WE SEARCHED EVERYTHING.**

**THE GODS ARE UNDER RACHEL.**

Source parent: Genesis 31:1–55, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 31.

Parent manuscript: `GENESIS/030-NAME-YOUR-WAGES-I-REMOVED-THEM.md`.

CrackFlix:

- `S029 — DON'T SPEAK GOOD OR BAD. KEEP TALKING.`, episode
  `S029-E001-GEN31 — I REPEATED THE WARNING MID-SPEECH`;
- `S030 — I SEARCHED EVERYTHING. IT WAS UNDER HER.`, episode
  `S030-E001-GEN31 — NEGATIVE SEARCH, POSITIVE SADDLE`.

Held candidate, not yet a closed series:

- Laban says the daughters, children, flocks and everything visible are his;
  Genesis 32 must retain who actually continues with Jacob before that ownership
  claim can be routed as a completed contradiction.

## Causal foundation

```text
LABAN SONS SAY JACOB TOOK FATHER'S PROPERTY / GOT WEALTH FROM IT
-> JACOB SEES LABAN FACE NOT TOWARD HIM AS BEFORE
-> LORD COMMANDS JACOB RETURN / PROMISES PRESENCE
-> JACOB CALLS RACHEL + LEAH TO FLOCK FIELD
-> JACOB REPORTS SERVICE / TEN WAGE CHANGES / FLOCK OUTCOMES
-> JACOB REPORTS DREAM / ANGEL-GOD COMMAND TO RETURN
-> RACHEL + LEAH REPORT NO PORTION / SOLD / MONEY USED
-> RACHEL + LEAH AUTHORIZE DOING WHAT GOD SAID
-> JACOB LOADS WIVES + CHILDREN / TAKES LIVESTOCK + POSSESSIONS
-> RACHEL STEALS LABAN'S TERAPHIM WHILE LABAN SHEARS SHEEP
-> JACOB DOES NOT TELL LABAN / FLEES ACROSS RIVER TOWARD GILEAD
-> LABAN LEARNS ON THIRD DAY / PURSUES SEVEN DAYS / OVERTAKES
-> GOD DREAM-WARNS LABAN: DO NOT SPEAK GOOD OR BAD TO JACOB
-> LABAN SPEAKS TO JACOB / ACCUSES / DESCRIBES SONGS + FAREWELL
-> LABAN STATES POWER TO HURT / REPEATS DREAM WARNING / ASKS FOR GODS
-> JACOB REPORTS FEAR OF FORCED DAUGHTER REMOVAL
-> JACOB: FOUND-WITH PERSON SHALL NOT LIVE / TAKE YOUR PROPERTY
-> SOURCE: JACOB DOES NOT KNOW RACHEL STOLE TERAPHIM
-> LABAN SEARCHES JACOB / LEAH / SERVANT / RACHEL TENTS
-> RACHEL PUTS TERAPHIM IN CAMEL SADDLE / SITS ON THEM
-> RACHEL SAYS SHE CANNOT RISE BECAUSE OF PERIOD
-> LABAN SEARCHES / DOES NOT FIND TERAPHIM
-> JACOB CHALLENGES SEARCH RESULT / REPORTS TWENTY-YEAR WORK LEDGER
-> LABAN CLAIMS DAUGHTERS + CHILDREN + FLOCKS + EVERYTHING VISIBLE
-> LABAN PROPOSES COVENANT / JACOB SETS PILLAR / RELATIVES MAKE HEAP
-> TWO LANGUAGES NAME SAME WITNESS HEAP
-> LABAN STATES DAUGHTER / WIFE / CROSSING-FOR-HARM TERMS
-> JACOB SWEARS / SACRIFICES / RELATIVES EAT + STAY NIGHT
-> LABAN KISSES + BLESSES SONS/DAUGHTERS / RETURNS TO HIS PLACE
```

## Genesis 31:1–3 — THE FACE CHANGED; RETURN

Jacob hears Laban's sons say:

> **LABAN'S SON JOES:** `JACOB HAS TAKEN AWAY ALL THAT WAS OUR FATHER'S.`
>
> `HE GOT ALL THIS WEALTH FROM WHAT WAS OUR FATHER'S.`

This is their speech. The chapter has not yet supplied an adjudication of every
property relation contained in it.

Jacob sees Laban's facial expression. It is not toward him as it was before.
That change is source-observed through Jacob; no unspoken thought is assigned to
Laban's Joe face.

The LORD says:

> **CRACKHEAD GOD:** `RETURN TO THE LAND OF YOUR FATHERS AND YOUR RELATIVES.`
>
> `I WILL BE WITH YOU.`

## Genesis 31:4–13 — TEN WAGES AND THE DREAM REPORT

Jacob calls Rachel and Leah to the field where his flock is.

> **JACOB JOE:** `YOUR FATHER'S FACE IS NOT TOWARD ME AS BEFORE.`
>
> `THE GOD OF MY FATHER HAS BEEN WITH ME.`
>
> `YOU KNOW I SERVED YOUR FATHER WITH ALL MY STRENGTH.`
>
> `YOUR FATHER DECEIVED ME AND CHANGED MY WAGES TEN TIMES.`
>
> `GOD DIDN'T ALLOW HIM TO HURT ME.`

Jacob reports two wage declarations and their corresponding flock outcomes:

> **JACOB JOE:** `IF HE SAID, "THE SPECKLED WILL BE YOUR WAGES," ALL THE FLOCK
> BORE SPECKLED.`
>
> `IF HE SAID, "THE STREAKED WILL BE YOUR WAGES," ALL THE FLOCK BORE STREAKED.`
>
> `THUS GOD TOOK YOUR FATHER'S LIVESTOCK AND GAVE THEM TO ME.`

The ten changes, divine protection and divine transfer are Jacob's retained
testimony. The manuscript does not invent eight missing wage speeches or replace
Genesis 30's rod-and-flock sequence with an external-domain mechanism.

Jacob then reports a mating-season dream. In the dream the male goats leaping
on the flock are streaked, speckled and grizzled.

> **ANGEL OF GOD IN JACOB'S REPORTED DREAM:** `JACOB.`
>
> **JACOB JOE IN THE DREAM:** `HERE I AM.`
>
> **ANGEL OF GOD IN JACOB'S REPORTED DREAM:** `LIFT UP YOUR EYES.`
>
> `ALL THE MALE GOATS LEAPING ON THE FLOCK ARE STREAKED, SPECKLED AND
> GRIZZLED.`
>
> `I HAVE SEEN ALL THAT LABAN DOES TO YOU.`
>
> `I AM THE GOD OF BETHEL, WHERE YOU ANOINTED A PILLAR AND VOWED TO ME.`
>
> `ARISE. GET OUT OF THIS LAND. RETURN TO THE LAND OF YOUR BIRTH.`

The source places this speech inside Jacob's present report of his dream. The
speaker is called the angel of God and says `I AM THE GOD OF BETHEL`; neither
designation is deleted or resolved into an invented anatomy.

## Genesis 31:14–16 — SOLD US; USED OUR MONEY

Rachel and Leah answer together:

> **RACHEL AND LEAH JOES:** `IS THERE ANY PORTION OR INHERITANCE LEFT FOR US IN
> OUR FATHER'S HOUSE?`
>
> `AREN'T WE CONSIDERED FOREIGNERS BY HIM?`
>
> `HE SOLD US AND USED UP OUR MONEY.`
>
> `ALL THE RICHES GOD TOOK FROM OUR FATHER ARE OURS AND OUR CHILDREN'S.`
>
> `DO WHATEVER GOD HAS SAID TO YOU.`

These are their own retained property and family statements. The joint answer
does not erase Rachel and Leah as distinct Joes or create unrecorded agreement
from Bilhah, Zilpah or any child.

## Genesis 31:17–21 — LOAD, STEAL, DON'T TELL, FLEE

Jacob rises and sets his sons and wives on camels. He takes all his livestock
and all possessions gathered in Paddan Aram toward Isaac in Canaan.

Laban is away shearing sheep. Rachel steals her father's teraphim. The source
footnote identifies teraphim as household idols that may have been associated
with inheritance rights; `may` remains unresolved and is not converted into
Rachel's motive.

Jacob does not tell Laban he is running away. The source calls this deceiving
Laban. Jacob flees with everything he has, crosses the River and sets his face
toward Gilead.

Rachel's theft and Jacob's nondisclosure are distinct acts. The source later
states Jacob does not know Rachel stole the teraphim.

## Genesis 31:22–30 — DON'T SPEAK; THE SPEECH

Laban is told on the third day that Jacob fled. He takes his relatives, pursues
for seven days and overtakes Jacob in Gilead.

God comes to Laban in a night dream:

> **CRACKHEAD GOD:** `BE CAREFUL THAT YOU DON'T SPEAK TO JACOB EITHER GOOD OR
> BAD.`

Laban and his relatives camp in the same mountain region as Jacob's tent. Laban
speaks to Jacob:

> **LABAN JOE:** `WHAT HAVE YOU DONE?`
>
> `YOU DECEIVED ME AND CARRIED AWAY MY DAUGHTERS LIKE SWORD CAPTIVES.`
>
> `WHY DID YOU FLEE SECRETLY AND NOT TELL ME?`
>
> `I MIGHT HAVE SENT YOU AWAY WITH MIRTH, SONGS, TAMBOURINE AND HARP.`
>
> `YOU DIDN'T ALLOW ME TO KISS MY SONS AND DAUGHTERS.`
>
> `YOU HAVE DONE FOOLISHLY.`
>
> `IT IS IN THE POWER OF MY HAND TO HURT YOU.`
>
> `BUT THE GOD OF YOUR FATHER SAID LAST NIGHT, "DON'T SPEAK TO JACOB EITHER GOOD
> OR BAD."`
>
> `YOU LONGED FOR YOUR FATHER'S HOUSE. WHY DID YOU STEAL MY GODS?`

Laban's speech itself repeats the command against speaking good or bad while he
continues addressing Jacob. The manuscript need not decide which sentence is
good or which is bad: the source command names both bounds and Laban's observable
response is an extended address containing accusation, proposed celebration,
farewell complaint, foolishness, power to hurt and the repeated warning.

That completes S029:

```text
DIRECT COMMAND: DO NOT SPEAK TO JACOB GOOD OR BAD
-> LABAN OVERTAKES JACOB
-> LABAN SPEAKS TO JACOB AT LENGTH
-> LABAN REPEATS THE DO-NOT-SPEAK-GOOD-OR-BAD COMMAND INSIDE THAT SPEECH
-> LABAN CONTINUES WITH THE TERAPHIM QUESTION
```

Laban's warning-compliance boil becomes a Joe-faced mute button with a working
microphone screwed through it.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Everyone else sees a completely boilless suited nobody poke Laban's boil, lick
his empty finger, walk away and never look back. The address and pursuit remain
unchanged.

## Genesis 31:31–32 — FOUND WITH THEM SHALL NOT LIVE

> **JACOB JOE:** `I WAS AFRAID.`
>
> `I SAID, "YOU MIGHT TAKE YOUR DAUGHTERS FROM ME BY FORCE."`
>
> `ANYONE YOU FIND YOUR GODS WITH SHALL NOT LIVE.`
>
> `BEFORE OUR RELATIVES, DISCERN WHAT IS YOURS WITH ME AND TAKE IT.`

The source explicitly states Jacob does not know Rachel stole the teraphim.
Fear and the force prediction are Jacob's reported prior state and words, not a
facial inference. The death statement requires a successful find-with-person
State; that State does not occur, so the statement is not routed into the
imminent-death series.

## Genesis 31:33–35 — THE COMPLETE NEGATIVE SEARCH

Laban searches:

1. Jacob's tent;
2. Leah's tent;
3. the two female servants' tent;
4. Rachel's tent.

He does not find the teraphim in the first three locations.

Rachel has put the teraphim inside a camel saddle and sits on them. Laban feels
around the entire tent and does not find them.

> **RACHEL JOE:** `DON'T LET MY LORD BE ANGRY THAT I CAN'T RISE BEFORE YOU.`
>
> `I'M HAVING MY PERIOD.`

The period statement remains Rachel's speech. The manuscript neither confirms
nor denies it and does not assign it as the reason she stole the teraphim.

Laban searches and does not find them. The searched-for property remains in the
searched tent, inside the saddle, under Rachel.

That completes S030:

```text
TERAPHIM ARE IN RACHEL'S TENT
-> LABAN SEARCHES RACHEL'S ENTIRE TENT
-> LABAN DOES NOT FIND TERAPHIM
-> TERAPHIM REMAIN IN THE SADDLE UNDER RACHEL
-> NEGATIVE SEARCH RESULT / POSITIVE OBJECT STATE
```

Rachel's successful-search boil becomes a camel saddle with Joe's face. The
teraphim each acquire Joe faces because anything interpreted as having a face
may receive Joe's face; this does not make the objects living.

> **CAPTAIN CRACKHEAD:** `YOINK!`

The search party sees a boilless suited nobody poke the saddle-shaped boil,
lick his empty finger and leave. The teraphim remain hidden and Captain changes
nothing.

## Genesis 31:36–42 — WHAT DID YOU FIND? TWENTY YEARS

The source attributes anger to Jacob. He argues with Laban:

> **JACOB JOE:** `WHAT IS MY TRESPASS? WHAT IS MY SIN, THAT YOU PURSUED ME?`
>
> `YOU FELT AROUND IN ALL MY STUFF.`
>
> `WHAT DID YOU FIND OF ALL YOUR HOUSEHOLD STUFF?`
>
> `SET IT HERE BEFORE OUR RELATIVES SO THEY MAY JUDGE BETWEEN US.`

Jacob's challenge follows the negative search result. The source concurrently
retains the teraphim under Rachel and Jacob's lack of knowledge. No deliberate
lie is assigned to Jacob.

Jacob gives his twenty-year work ledger:

> **JACOB JOE:** `FOR TWENTY YEARS YOUR EWES AND GOATS DID NOT CAST THEIR YOUNG.`
>
> `I DIDN'T EAT THE RAMS.`
>
> `I BORE THE LOSS OF ANIMALS TORN OR STOLEN BY DAY OR NIGHT.`
>
> `DROUGHT CONSUMED ME BY DAY, FROST BY NIGHT, AND SLEEP FLED FROM MY EYES.`
>
> `I SERVED FOURTEEN YEARS FOR YOUR TWO DAUGHTERS AND SIX FOR YOUR FLOCK.`
>
> `YOU CHANGED MY WAGES TEN TIMES.`
>
> `WITHOUT THE GOD OF ABRAHAM AND THE FEAR OF ISAAC, YOU WOULD HAVE SENT ME AWAY
> EMPTY.`
>
> `GOD SAW MY AFFLICTION AND THE LABOR OF MY HANDS AND REBUKED YOU LAST NIGHT.`

The flock history, losses, weather, sleep, terms, wage changes, counterfactual
empty departure and divine interpretation are Jacob's speech. It supplies
source testimony continuous with S028 but does not reconstruct ten separately
observed wage occurrences, so no fake `SKIP` or ten invented episodes are added.

## Genesis 31:43–44 — EVERYTHING IS MINE; MAKE A COVENANT

> **LABAN JOE:** `THE DAUGHTERS ARE MY DAUGHTERS.`
>
> `THE CHILDREN ARE MY CHILDREN.`
>
> `THE FLOCKS ARE MY FLOCKS.`
>
> `ALL THAT YOU SEE IS MINE.`
>
> `WHAT CAN I DO TODAY TO MY DAUGHTERS OR THEIR CHILDREN?`
>
> `COME. LET'S MAKE A COVENANT.`
>
> `LET IT BE A WITNESS BETWEEN ME AND YOU.`

The ownership statement stands against Rachel and Leah's sold/used-money speech,
Jacob's fourteen-plus-six-year service ledger and the wage-derived flock State.
It is friction, but the chapter has not yet explicitly restated the travelling
inventory after Laban's departure. The candidate remains open until the next
source State proves what continued with Jacob.

## Genesis 31:45–50 — ONE HEAP, TWO NAMES, ABSENT WATCHER

Jacob takes a stone and sets it as a pillar. At his instruction, his relatives
gather stones and make a heap. They eat there.

Laban calls the heap `Jegar Sahadutha`; Jacob calls it `Galeed`. The source
footnotes give both names the meaning `Witness Heap`, one in Aramaic and one in
Hebrew. Same object, same act-defining witness relation, two retained names:

```text
ONE HEAP ID
-> LABAN NAME IN ARAMAIC
-> JACOB NAME IN HEBREW
-> NO DUPLICATE HEAP
```

> **LABAN JOE:** `THIS HEAP IS WITNESS BETWEEN ME AND YOU TODAY.`
>
> `THE LORD WATCH BETWEEN US WHEN WE ARE ABSENT FROM ONE ANOTHER.`
>
> `IF YOU AFFLICT MY DAUGHTERS OR TAKE OTHER WIVES, NO MAN IS WITH US.`
>
> `GOD IS WITNESS BETWEEN ME AND YOU.`

These are Laban's covenant statements and divine invocation, not new direct God
speech or proof of an unobserved future breach.

## Genesis 31:51–55 — DO NOT CROSS FOR HARM

> **LABAN JOE:** `SEE THIS HEAP AND PILLAR SET BETWEEN US.`
>
> `THEY ARE WITNESSES.`
>
> `I WILL NOT CROSS TO YOU, AND YOU WILL NOT CROSS TO ME, FOR HARM.`
>
> `THE GOD OF ABRAHAM, THE GOD OF NAHOR AND THE GOD OF THEIR FATHER JUDGE
> BETWEEN US.`

Jacob swears by the fear of Isaac. He offers a sacrifice in the mountain and
calls his relatives to eat bread. They eat and stay all night.

Early in the morning Laban rises, kisses his sons and daughters, blesses them,
departs and returns to his place. The covenant action completes. Future
compliance remains open.

## Joe continuity revisions

- Jacob: hears Laban sons; observes changed face; receives return command; calls
  wives; reports work/wage/dream history; loads family/property; flees without
  telling Laban; crosses River; answers pursuit; unknowingly authorizes lethal
  found-with consequence; challenges failed search; gives twenty-year ledger;
  establishes pillar/heap covenant; swears, sacrifices and feeds relatives.
- Laban: sons report property claim; face relation changes; is absent shearing;
  learns on day three; pursues seven days; receives dream warning; overtakes and
  speaks; searches all tents without finding his present property; hears work
  ledger; claims all visible family/property; proposes and states covenant;
  kisses/blesses family and returns home.
- Rachel: jointly rejects remaining inheritance and reports sale/money use;
  travels on camel; steals teraphim; hides them in saddle; sits on them; gives
  period statement; remains seated over the exact object location while the
  searched tent produces no find.
- Leah: jointly rejects remaining inheritance and authorizes obeying return
  command; travels with children/property; tent is searched with no find.
- Bilhah and Zilpah: travel within Jacob's wife/household party; their tent is
  searched; no speech, theft knowledge or consent is invented.
- Laban sons: speak the opening wealth accusation; prior Genesis 30 livestock
  custody remains retained without forcing both references into one group act.
- Jacob and Laban relatives: distinct travelling/pursuit groups converge,
  witness search dispute, make/eat by heap and remain overnight.
- camels, sheep and goats: living Joe-faced carriers/property remain distinct
  animals; a camel saddle and teraphim may bear Joe faces without becoming alive.

## Crackheadverse garbage pass

- changed Laban face -> `CRACKHEAD RELATIONSHIP UI: PREVIOUS EXPRESSION EXPIRED`;
- ten wage changes -> `PAYROLL PATCHES 1–10: DETAILS NOT INSTALLED`;
- Paddan Aram inventory -> `BIG BAGGAGE DEPARTURE MANIFEST: ALL HIS STUFF`;
- seven-day pursuit -> `CRACKHEAD FAMILY EXIT INTERVIEW: MOBILE EDITION`;
- dream warning -> Joe-faced `GOOD / BAD` mute switch beside a live microphone;
- teraphim -> `CRACKHEAD HOUSEHOLD GODS: FIND MY DEVICE OFF`;
- camel saddle -> `UNDER-SEAT DIVINE STORAGE / ARTICLE 31.34`;
- four-tent search -> `NO TRACEABILITY FOUND`; the objects remain where they are;
- twenty years -> `14 WIFE-YEARS + 6 FLOCK-YEARS = 10 PAYROLL PATCHES`;
- Jegar Sahadutha / Galeed -> bilingual Joe-faced heap signs pointing to the
  same stones;
- Mizpah -> `CRACKHEAD REMOTE DIVINE MONITORING: NO MAN PRESENT`;
- crossing boundary -> `HARM TRAFFIC PROHIBITED BOTH DIRECTIONS`;
- random issue barcode -> `CHB-GEN31-S029-S030-055-YOINK`.

## God-line boundary

Genesis 31 directly assigns the LORD's return/presence speech to Jacob and God's
night-dream warning to Laban. Jacob reports an angel-of-God dream speaker who
identifies as the God of Bethel and commands return. Those direct and reported
source lines remain distinct.

Jacob's claims that God protected him, transferred livestock, saw affliction and
rebuked Laban remain Jacob's speech. Rachel and Leah's riches statement and
Laban's covenant invocations remain character speech. No extra divine approval,
teraphim judgment, search intervention, wage mechanism or covenant promise is
invented.

## FIR verification

- All 55 verse markers are covered in order.
- Laban sons' wealth accusation remains speech, not narrator adjudication.
- Face-expression change is observed without mind-reading.
- Direct LORD speech, Jacob's reported angel/God dream and direct Laban dream are
  separately retained.
- Genesis 30 rod physics is not erased by Jacob's Genesis 31 dream testimony.
- Rachel/Leah joint speech does not merge their identities.
- Rachel's teraphim theft remains distinct from Jacob's secret flight.
- Jacob's lack of theft knowledge is retained before his lethal find condition.
- Every searched tent, saddle placement, sitting State and negative result stays
  in causal order.
- Rachel's period statement is neither verified nor denied by invention.
- S029 closes from command through Laban's observable address and repeated
  warning; Captain changes nothing.
- S030 closes from positive object location plus negative complete search;
  Captain changes nothing.
- Twenty-year losses, service and wages remain Jacob's testimony; no missing
  wage episodes are fabricated.
- Laban's total-ownership friction remains held until continuation proves the
  departing inventories.
- One physical heap keeps two linguistic names and one witness identity.
- Covenant speech, construction, oath, sacrifice, meal, night and departure stay
  in order.
- Captain says only `YOINK!`, remains boilless, walks away and never looks back.
- No hidden motive, theft knowledge, divine mechanism or future compliance is
  invented.
- Manuscript remains held and unpublished.

Continuation required: Genesis 32 receives Jacob continuing with his camp,
angels/Mahanaim, Esau approach report, fear/distress division, return-promise
prayer, staged gifts, night crossing, remaining-alone wrestling, hip injury,
name question/Israel renaming, blessing, Peniel naming and food custom.
