# CRACKHEAD GENESIS 7

## Title page

**EVERY JOE GOT IN. GOD SHUT THE DOOR. THEN WATER.**

Source parent: Genesis 7:1–24, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 7.

Parent manuscript: `GENESIS/006-BUILD-THE-BOAT.md`.

CrackFlix crossover: none closed in this chapter.

## Causal foundation

```text
SHIP BUILT + NO-AH DID ALL COMMANDED
-> GOD ORDERS HOUSEHOLD ENTRY
-> CLEAN / UNCLEAN / BIRD COUNTS SPECIFIED
-> SEVEN-DAY WARNING + FORTY-DAY/NIGHT RAIN PLAN
-> NO-AH DOES ALL COMMANDED
-> AGE 600 + HOUSEHOLD ENTRY + ANIMAL PAIRS
-> SEVEN DAYS PASS
-> YEAR 600 / MONTH 2 / DAY 17
-> DEEP FOUNTAINS BURST + SKY WINDOWS OPEN
-> FORTY DAYS/NIGHTS RAIN
-> PEOPLE + ANIMAL KINDS ENTER
-> GOD SHUTS NO-AH IN
-> WATER INCREASES -> SHIP LIFTS / FLOATS
-> ALL MOUNTAINS COVERED + FIFTEEN CUBITS HIGHER
-> DRY-LAND LIFE DIES
-> ONLY SHIP POPULATION LEFT
-> WATER PREVAILS 150 DAYS
```

## Genesis 7:1 — HOUSEHOLD ENTRY

> **CRACKHEAD GOD:** `GET YOUR WHOLE HOUSEHOLD INTO THE SHIP.`
>
> `I'VE SEEN YOU RIGHTEOUS BEFORE ME IN THIS GENERATION.`

The command activates the held entry requirement from Genesis 6. No-Ah's wife,
three sons and three sons' wives are included through the household relation.
Their names remain unresolved where the source has not supplied them.

## Genesis 7:2–3 — PASSENGER MANIFEST REVISION

God specifies:

- seven pairs of every clean animal, male and female;
- two of every unclean animal, male and female;
- seven and seven of sky birds, male and female;
- preservation of seed/life across Earth's surface.

Genesis 6 required two of every sort as the preservation floor. Genesis 7 adds
larger clean-animal and bird quantities while retaining an unclean pair.

```text
GENESIS 6: EVERY SORT HAS A TWO-PASSENGER MINIMUM
GENESIS 7: CLEAN/BIRD CLASSES RECEIVE ADDITIONAL QUANTITY
```

Because the later command supplies a new specification before loading closes,
the count Difference is a revision, not a completed contradiction.

Ledger label: `CRACKHEAD PASSENGER MANIFEST v7 — SUPERSEDES QUANTITY ONLY`.

Every animal has the canonical Joe face and ordinary boils. Clean and unclean
are source inventory classes; neither is inferred from boil size.

## Genesis 7:4–5 — SEVEN DAYS

> **CRACKHEAD GOD:** `SEVEN DAYS.`
>
> `THEN FORTY DAYS AND FORTY NIGHTS OF RAIN.`
>
> `EVERY LIVING THING I MADE COMES OFF THE GROUND.`

No-Ah does everything God commands. The seven-day wait remains part of the
causal clock; the comic cannot jump directly from command to flood and still
claim the same sequence.

## Genesis 7:6–10 — ENTRY BEFORE ARRIVAL

No-Ah is 600 years old when floodwaters come.

Because of the floodwaters, No-Ah enters the ship with:

- his wife;
- Shem Joe, Ham Joe and Japheth Joe;
- their three wives;
- clean animals;
- unclean animals;
- birds;
- every ground-creeping kind.

The animals go by pairs, male and female, as God commanded. After the retained
seven days, floodwater comes on Earth.

The source supplies both class quantities and paired entry language. The
manuscript retains both rather than reducing every class back to exactly one
pair.

Background clipboard: `IF YOUR FACE IS JOE, THAT DOES NOT IDENTIFY YOUR SPECIES.`

## Genesis 7:11–12 — THE DATE OPENS

In the 600th year of No-Ah's life, second month, seventeenth day:

- all fountains of the great deep burst open;
- the sky's windows open;
- rain falls for forty days and forty nights.

This exact date anchors the flood-start Moment. `Great deep` and `sky windows`
remain source mechanisms; no modern physical model is imported to explain them.

Literal production gives each sky window a Joe face in its frame. It changes no
water.

## Genesis 7:13–16 — FINAL ENTRY AND DIVINE DOOR SERVICE

On that same day the named family enters:

```text
NO-AH JOE + WIFE JOE
SHEM JOE + WIFE JOE
HAM JOE + WIFE JOE
JAPHETH JOE + WIFE JOE
```

They enter with every animal, livestock, creeping thing and bird after its kind.
Pairs of all life-breath flesh go to No-Ah and enter male and female as God
commanded.

Then God shuts No-Ah in.

> **CRACKHEAD GOD:** `DOOR.`

The source records God's closing act, not a human locking mechanism. Sign:
`CRACKHEAD DIVINE DOOR SERVICE — NO EXTERNAL HANDLE SPECIFIED`.

No-Ah's household has entered; the earlier requirement changes from held to
observed complete.

## Genesis 7:17–20 — SHIP BECOMES SHIP

The flood continues forty days. Water increases, lifts the ship above Earth,
rises greatly and carries the ship floating on its surface.

All high mountains beneath the whole sky are covered. Water rises fifteen
cubits higher and covers them.

The source note again addresses a cubit as approximately 18 inches / 46 cm.
`Fifteen cubits higher` is retained without inventing the unstated measurement
instrument, mountain catalogue or reference procedure.

The built object now demonstrates its selected function under water:

```text
SEALED SHIP + RISING WATER -> LIFTED FLOATING SHIP
```

## Genesis 7:21–23 — OUTSIDE CLOSES

All moving flesh on Earth dies: birds, livestock, animals, creeping things and
every human. Everything on dry land with life-spirit breath in its nostrils dies.

Every living surface-ground thing is destroyed. Only No-Ah and those with him in
the ship remain.

The manuscript does not turn mass death into Captain's snack, applause or a
contradiction. It is the stated result of the preceding destruction decision
and flood sequence.

The Joe-faced fly is inside because its kind entered, not because Captain saved
anything. It waits on a wall and adds nothing.

## Genesis 7:24 — ONE HUNDRED FIFTY

Water prevails over Earth for 150 days.

This duration extends beyond the forty-day rain statement. Rain duration and
water-prevailing duration are distinct clocks:

```text
RAIN: 40 DAYS/NIGHTS
WATER PREVAILING: 150 DAYS
```

No recession is observed yet.

## Character and world-ledger changes

- No-Ah: age 600; obeys revised passenger manifest; enters; remains aboard after
  God closes door.
- household: all eight human members become observed ship occupants.
- unnamed wives: retain individual Joe identities through spouse relations;
  names and origins unresolved.
- living kinds: class counts and pair relations become observed entry State.
- God: supplies seven-day clock, rain duration, manifest revision and door-close
  act.
- Earth: deep fountains and sky windows open; mountains cover; dry-land living
  State closes outside ship.
- ship: changes from completed construction to loaded, closed, floating
  preservation container.

## Fuck-up pass

- Noah -> No-Ah Joe continues.
- ark/ship -> `CRACKHEAD PASSENGER SHIP`.
- clean/unclean -> clipboard lanes labelled `CLEAN JOES` / `DIRTY JOES`; source
  animal classes remain intact.
- sky windows -> literal Joe-faced windows.
- great deep -> `CRACKHEAD DEEP DEPARTMENT`.
- forty days/nights -> `40/40 WATER VISION` background warning.
- God shuts door -> useless `DIVINE DOOR SERVICE` receipt.

## FIR verification

- All 24 verse markers are covered in order.
- Genesis 6 construction and preservation commands precede entry.
- Genesis 7 quantity specification is retained as a pre-loading revision.
- Seven-day warning precedes floodwater arrival.
- Exact No-Ah age and flood-start calendar address are retained.
- Deep fountains/sky windows precede rain and rising water.
- Family and animal entry precedes God's door closure.
- Water rise precedes ship lift, mountain coverage and outside death.
- Forty-day rain and 150-day prevailing-water clocks remain distinct.
- No recession, landing, exit or covenant sign is imported early.
- No contradiction series or Captain intervention is manufactured.
- Manuscript remains held and unpublished.

Continuation required: Genesis 8 receives God's remembrance, wind, closed water
sources, recession chronology, Ararat resting, raven/dove tests, dry-ground
observation, exit command, altar/offering and God's heart statement.
