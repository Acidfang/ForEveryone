# CRACKHEAD GENESIS 28

## Title page

**RUN TO LABAN. YOUR BROTHER PLANS TO KILL YOU.**

**GO TO LABAN. DON'T MARRY A CANAANITE.**

Source parent: Genesis 28:1–22, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 28.

Parent manuscript: `GENESIS/027-THE-VOICE-IS-JACOB-THE-HANDS-ARE-ESAU.md`.

CrackFlix:

- `S023 — SAME TRIP. DIFFERENT REASON.`, episode
  `S023-E001-GEN28 — RUN FOR YOUR LIFE AND GET MARRIED`;
- `S024 — THE PROBLEM STAYS. I ADDED THE OPPOSITE.`, episode
  `S024-E001-GEN28 — THIRD WIFE FIX`;
- `S025 — I PROMISE. IF YOU DO.`, episode
  `S025-E001-GEN28 — THE CONDITIONAL ACCEPTANCE OF A PROMISE`.

## Causal foundation

```text
GEN27 REBEKAH -> JACOB: FLEE TO LABAN / ESAU PLANS TO KILL YOU
GEN27 REBEKAH -> ISAAC: HETHITE-WIFE LIFE-WEARINESS
-> ISAAC CALLS/BLESSES/COMMANDS JACOB
-> NO CANAANITE WIFE
-> GO TO BETHUEL/LABAN HOUSE / TAKE LABAN DAUGHTER
-> ABRAHAM BLESSING / LAND INHERITANCE WORDS
-> ISAAC SENDS JACOB
-> JACOB GOES TO PADDAN ARAM
-> ESAU SEES BLESSING + SENDING + NO-CANAANITE COMMAND + OBEDIENCE
-> ESAU SEES CANAAN DAUGHTERS DISPLEASE ISAAC
-> ESAU ADDS MAHALATH, ISHMAEL DAUGHTER / NEBAIOTH SISTER
-> PRIOR JUDITH + BASEMATH WIVES REMAIN
-> JACOB LEAVES BEERSHEBA TOWARD HARAN
-> SUNSET / STONE HEADREST / SLEEP
-> DREAM: EARTH-HEAVEN STAIRWAY / ANGELS ASCEND + DESCEND
-> LORD STANDS ABOVE / IDENTIFIES / PROMISES LAND + OFFSPRING + BLESSING
-> LORD PROMISES PRESENCE + KEEPING + RETURN + NON-LEAVING UNTIL DONE
-> JACOB WAKES / STATES LORD HERE + DIDN'T KNOW
-> FEAR ATTRIBUTED / HOUSE-OF-GOD + HEAVEN-GATE STATEMENTS
-> MORNING STONE PILLAR + OIL
-> PLACE RENAMED BETHEL / PRIOR CITY NAME LUZ RETAINED
-> JACOB VOWS IF PRESENCE + KEEPING + FOOD + CLOTHING + PEACEFUL RETURN
-> THEN LORD AS HIS GOD + STONE AS GOD'S HOUSE + TENTH
```

## Genesis 28:1–5 — ISAAC SENDS JACOB FOR A WIFE

Isaac calls Jacob, blesses him and commands him:

> **ISAAC JOE:** `DO NOT TAKE A WIFE FROM THE DAUGHTERS OF CANAAN.`
>
> `GO TO PADDAN ARAM, TO BETHUEL YOUR MOTHER'S FATHER.`
>
> `TAKE A WIFE FROM THE DAUGHTERS OF LABAN, YOUR MOTHER'S BROTHER.`
>
> `MAY GOD ALMIGHTY BLESS, MULTIPLY AND MAKE YOU A COMPANY OF PEOPLES.`
>
> `MAY HE GIVE YOU AND YOUR OFFSPRING ABRAHAM'S BLESSING.`
>
> `MAY YOU INHERIT THE LAND WHERE YOU TRAVEL, WHICH GOD GAVE ABRAHAM.`

Isaac sends Jacob. Jacob goes to Paddan Aram, to Laban son of Bethuel the
Syrian, Rebekah's brother. Rebekah remains mother of both Jacob and Esau.

That performed sending closes the Genesis 27 frontier and S023:

```text
REBEKAH TO JACOB: LABAN DESTINATION + ESCAPE ESAU KILL PLAN
REBEKAH TO ISAAC: HETHITE-WIFE LIFE-WEARINESS, NO KILL PLAN MENTIONED
ISAAC TO JACOB: LABAN DESTINATION + NON-CANAANITE WIFE COMMAND
ISAAC SENDS / JACOB GOES
```

Both stated reasons can exist, but they do not cleanly become one reported
reason. The same trip is privately commanded as flight and formally authorized
as wife acquisition. No secret motive is assigned to Rebekah, Isaac or Jacob.

Rebekah's travel-authorization boil grows two Joe-faced destination labels on
one bag: `DON'T GET KILLED` and `GET MARRIED`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. Jacob is still sent and still goes.

## Genesis 28:6–9 — ESAU ADDS THE APPROVED CATEGORY

Esau observes all of the following:

- Isaac blessed Jacob;
- Isaac sent Jacob to Paddan Aram for a wife;
- Isaac commanded no Canaanite wife;
- Jacob obeyed father and mother and left;
- Canaan's daughters did not please Isaac.

Esau then goes to Ishmael and takes Mahalath as an additional wife. Mahalath is
Ishmael son of Abraham's daughter and Nebaioth's sister.

The text explicitly says she is added to Esau's existing wives. Judith and
Basemath therefore remain wives; the displeasing category is not removed.

That completes S024:

```text
OBSERVED PROBLEM: EXISTING CANAAN/HITTITE WIVES DISPLEASE ISAAC
OBSERVED RESPONSE: ADD ISHMAEL-LINE MAHALATH
RETAINED AFTER-STATE: EXISTING WIVES + MAHALATH
```

The source's `so` retains Esau's response relation. The comic does not claim he
said the problem was solved or infer whether Isaac became pleased.

Esau's marriage-correction boil adds a Joe-faced green tick without removing
the two red entries underneath it.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. All three wife relations remain.

### Ishmael chronology boundary

Genesis 25 gives Ishmael's complete-life summary and eventual death at 137.
That summary's textual placement does not require every later narrated event to
occur after his death. Retained ages place Ishmael fourteen years older than
Isaac; when Esau is forty, Isaac is one hundred and Ishmael is approximately
114. The visit/marriage can therefore be retained before Ishmael's eventual
death without reopening his closed final State.

The exact marriage date within Esau's age history is supplied here only by the
surrounding chronology; no dialogue with Ishmael is invented.

## Genesis 28:10–12 — STONE PILLOW, STAIRWAY, ANGELS

Jacob leaves Beersheba toward Haran. At sunset he stays overnight at a certain
place. He takes a stone, puts it under his head and sleeps.

He dreams of a stairway standing on earth with its top reaching heaven. Angels
of God ascend and descend on it. Every angel is a living Joe-faced angel. Their
shared face does not merge them, turn them into Captain, or supply dialogue.

The dream status is explicit. The comic does not present the stairway as a
waking structure independently measured by the fly.

## Genesis 28:13–15 — GOD'S PROMISE

In the dream, the LORD stands above the stairway and speaks:

> **CRACKHEAD GOD:** `I AM THE LORD, GOD OF ABRAHAM YOUR FATHER AND GOD OF ISAAC.`
>
> `I WILL GIVE YOU AND YOUR OFFSPRING THE LAND YOU ARE LYING ON.`
>
> `YOUR OFFSPRING WILL BE LIKE THE DUST OF THE EARTH.`
>
> `YOU WILL SPREAD WEST, EAST, NORTH AND SOUTH.`
>
> `ALL EARTH'S FAMILIES WILL BE BLESSED IN YOU AND YOUR OFFSPRING.`
>
> `I AM WITH YOU.`
>
> `I WILL KEEP YOU WHEREVER YOU GO.`
>
> `I WILL BRING YOU BACK TO THIS LAND.`
>
> `I WILL NOT LEAVE YOU UNTIL I HAVE DONE WHAT I SPOKE TO YOU.`

This is direct God-only dream speech. Land, offspring spread and global-family
blessing remain promised future States. Presence, keeping, return and
non-leaving are also explicit promises; they become causal parents of Jacob's
later vow.

## Genesis 28:16–19 — I DIDN'T KNOW; NOW A PILLAR

Jacob wakes.

> **JACOB JOE:** `SURELY THE LORD IS IN THIS PLACE, AND I DIDN'T KNOW IT.`

The source attributes fear to him.

> **JACOB JOE:** `HOW AWESOME THIS PLACE IS.`
>
> `THIS IS GOD'S HOUSE AND HEAVEN'S GATE.`

Early in the morning Jacob takes the headrest stone, stands it as a pillar and
pours oil on top. He names the place Bethel. The city was formerly named Luz.
Stone, pillar, oil and naming are separate observable acts; the source supplies
no audience, property claim, oil quantity or construction mechanism.

## Genesis 28:20–22 — I PROMISE; IF YOU DO

Jacob vows:

> **JACOB JOE:** `IF GOD WILL BE WITH ME,`
>
> `IF HE WILL KEEP ME ON THIS WAY,`
>
> `IF HE WILL GIVE ME BREAD AND CLOTHING,`
>
> `IF I RETURN TO MY FATHER'S HOUSE IN PEACE,`
>
> `THEN THE LORD WILL BE MY GOD.`
>
> `THIS PILLAR STONE WILL BE GOD'S HOUSE.`
>
> `I WILL GIVE YOU A TENTH OF EVERYTHING YOU GIVE ME.`

The vow completes S025 because it conditionally restates the immediately prior
promise:

```text
GOD: I AM WITH YOU / WILL KEEP YOU / WILL BRING YOU BACK / WILL NOT LEAVE
JACOB: IF GOD IS WITH ME / KEEPS ME / SUPPLIES ME / BRINGS ME BACK IN PEACE
-> THEN LORD MY GOD / PILLAR GOD'S HOUSE / TENTH
```

Food, clothing and `in peace` are additions in Jacob's conditions; they are not
retroactively inserted into God's wording. The contradiction is not whether
future promises ultimately occur. It is the immediate promise followed by
conditional acceptance of overlapping promised States.

Jacob's conditional-vow boil becomes a Joe-faced contract saying
`PROMISE RECEIVED / SUBJECT TO PROMISE`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. The vow, pillar and uncompleted
future conditions remain unchanged.

## Character and world-ledger changes

- Isaac: calls/blesses/commands/sends Jacob; supplies non-Canaanite wife reason,
  Paddan Aram destination and Abraham inheritance blessing.
- Rebekah: prior flight and Hethite-wife statements become causal parents of
  S023; no new Genesis 28 speech or act is invented.
- Jacob: obeys/leaves; sleeps/dreams; receives direct God promise; wakes and
  interprets place; erects/oils/names pillar; makes conditional vow.
- Esau: observes command/sending/obedience/displeasure; adds Mahalath while
  retaining Judith/Basemath.
- Mahalath: new Joe identity; Ishmael daughter, Nebaioth sister, Esau wife.
- Ishmael: receives a historically earlier Esau visit/marriage relation without
  reopening eventual death State or inventing speech.
- Nebaioth: receives Mahalath sibling relation.
- dream angels: living Joe-faced group ascending/descending without speech.
- Bethuel/Laban: destination/genealogy references only; no chapter act/speech.
- stone/Luz/Bethel: nonliving/place States change by placement, oil and naming;
  they may receive wrong-context Joe faces without becoming living Joes.

## Fuck-up pass

- Paddan Aram -> `PAD-AN-A-RAM`, mandatory marriage application stationery.
- daughters of Canaan -> `CAN-A-NAN DAUGHTERS`, prohibited nan-based dating pool.
- Mahalath -> `MA-HALF-A-LATHE JOE`, half a lathe issued as wedding luggage.
- third wife -> `CORRECTIVE WIFE PATCH / PREVIOUS VERSIONS STILL INSTALLED`.
- Beersheba -> `BEER-SHE-BAR`, Jacob exits through a literal bar door.
- Haran -> `HAIR-RUN`, still using leftover goat-hair road signs.
- stairway -> `CRACKHEAD HEAVEN ACCESS / ANGELS USE BOTH DIRECTIONS`.
- dust offspring -> Joe-faced dust particles forming a family portrait.
- stone pillow -> `COMFORT RATING: BIBLICAL`.
- Bethel -> `BET-HELL`, a house-shaped betting kiosk at heaven's gate.
- Luz -> `LOSE`, the city loses its name to a stone.
- pillar oil -> `CRACKHEAD BUILDING CONSENT: POUR ON TOP`.
- tenth -> a Joe-faced calculator that only has a `10%` key.
- vow -> `IF PROMISE, THEN ACCEPT PROMISE` recursive contract paper.

## God-line boundary

The LORD directly stands and speaks within Jacob's explicitly identified dream.
Every promise remains God-only dialogue at that dream boundary. Isaac's
invocations and Jacob's waking statements/vow are character speech, not added
God lines. The angels act in the dream but do not speak.

## FIR verification

- All 22 verse markers are covered in order.
- Genesis 27 frontier closes only after Isaac commands/sends and Jacob goes.
- Rebekah's private kill-flight and public Hethite-wife statements remain
  separate source Moments; neither becomes a hidden-motive verdict.
- S023 retains one trip with two spoken reason chains.
- Esau's observations precede Mahalath marriage; two existing wives explicitly
  remain afterward.
- S024 does not claim Esau said the problem was solved or Isaac became pleased.
- Ishmael's historical act is placed before eventual death using retained ages;
  his closed final State is not reversed.
- Mahalath/Ishmael/Nebaioth genealogy is complete and not merged with later names.
- Dream, waking, pillar and vow remain distinct States.
- Angels receive Joe faces without invented speech or identity merger.
- Every direct LORD promise remains God-only and future promises remain open.
- Jacob's food/clothing/peace conditions are distinguished from God's exact
  promise wording.
- S025 closes on conditional acceptance, not on future fulfillment.
- Captain appears after each completed contradiction, says only `YOINK!`, is
  boilless and changes nothing.
- No `SKIP`, premature fulfillment, waking stairway measurement, divine motive
  or unrecorded family dialogue is invented.
- Manuscript remains held and unpublished.

Continuation required: Genesis 29 receives Jacob's well arrival, Rachel/Laban
identity, stone movement, greeting/report, month residence, seven-year Rachel
service, Leah substitution, morning discovery, fulfilled-week/second marriage,
second seven-year service, unequal-love attribution and the first four sons.
