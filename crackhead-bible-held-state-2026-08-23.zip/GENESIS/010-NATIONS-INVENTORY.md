# CRACKHEAD GENESIS 10

## Title page

**THREE JOES HAD JOES. NOW THERE ARE COUNTRIES.**

Source parent: Genesis 10:1–32, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 10.

Parent manuscript: `GENESIS/009-HAM-DID-IT-CANAAN-CURSED.md`.

CrackFlix crossover: none closed in this chapter.

## Causal foundation

```text
NO-AH -> SHEM / HAM / JAPHETH
-> POST-FLOOD CHILDREN
-> THREE DESCENDANT BRANCHES
-> FAMILIES + LANGUAGES + LANDS + NATIONS
-> JAPHETH ISLAND-NATION DIVISIONS
-> HAM BRANCH + NIMROD KINGDOM/CITIES + CANAAN BORDER
-> SHEM BRANCH + EBER + PELEG DIVISION + JOKTAN DWELLING
-> NATIONS DIVIDED ON EARTH AFTER FLOOD
```

This is the first explicit nation inventory. A nation is not a personality. Each
entry retains only its stated lineage, language existence, land relation and
named descendants or boundaries.

## Genesis 10:1 — POST-FLOOD GENERATION ROOT

Sons are born to Shem Joe, Ham Joe and Japheth Joe after the flood. Their three
identity branches remain children of No-Ah Joe without becoming interchangeable.

## Genesis 10:2–5 — JAPHETH BRANCH

```text
JAPHETH
├─ Gomer -> Ashkenaz / Riphath / Togarmah
├─ Magog
├─ Madai
├─ Javan -> Elishah / Tarshish / Kittim / Dodanim
├─ Tubal
├─ Meshech
└─ Tiras
```

From these, island nations divide into lands, languages, families and nations.
The source does not map them onto current states, borders, ethnic traits or
modern speakers.

Background customs form: `CRACKHEAD ISLAND DIVISION — LANGUAGE FIELD REQUIRED`.

## Genesis 10:6–7 — HAM BRANCH ROOTS

```text
HAM
├─ Cush -> Seba / Havilah / Sabtah / Raamah / Sabteca
│          Raamah -> Sheba / Dedan
├─ Mizraim
├─ Put
└─ Canaan
```

Havilah renders **Have-a-Laugh**, retaining the source identity used elsewhere.
Put becomes **Put Joe**, constantly placed somewhere by production. Nobody
explains it.

## Genesis 10:8–12 — NIM-ROD'S KINGDOM

Cush fathers Nimrod Joe. Nimrod begins to be mighty on Earth and is a mighty
hunter before God. A retained saying compares mighty hunters to him.

Display name: **Nim-Rod Joe**, carrying a useless rod with his own face on it.

The beginning of his kingdom is:

- Babel;
- Erech;
- Accad;
- Calneh;
- all in Shinar.

He goes from that land into Assyria and builds Nineveh, Rehoboth Ir, Calah and
Resen between Nineveh and Calah; Calah is identified as the great city.

Wordplay addresses: `Bagel`, `A-Wreck`, `A-Cad`, `Shin-Argh`, `A-Syria`, and
`Nine-Ever`. The source city/land identities remain in the ledger.

No hunting target, weapon, conquest method or kingdom law is supplied.

## Genesis 10:13–14 — MIZRAIM BRANCH

Mizraim fathers Ludim, Anamim, Lehabim, Naphtuhim, Pathrusim, Casluhim and
Caphtorim. The Philistines descend from Casluhim in the retained source wording.

This is a lineage statement only. Later histories must produce their places,
institutions, speech and actions.

## Genesis 10:15–20 — CANAAN BRANCH AND BORDER

Canaan fathers Sidon, his firstborn, and Heth. His branch includes Jebusites,
Amorites, Girgashites, Hivites, Arkites, Sinites, Arvadites, Zemarites and
Hamathites. Canaanite families spread abroad.

Their retained border runs:

```text
SIDON -> TOWARD GERAR -> GAZA
-> TOWARD SODOM / GOMORRAH / ADMAH / ZEBOIIM
-> LASHA
```

No current map coordinates are invented. Later location evidence may resolve
addresses while preserving this source boundary as its parent.

These are Ham's descendants by families, languages, lands and nations.

## Genesis 10:21–24 — SHEM TO EBER

Shem, elder brother of Japheth, is father of all Eber's children.

```text
SHEM
├─ Elam
├─ Asshur
├─ Arpachshad -> Shelah -> Eber
├─ Lud
└─ Aram -> Uz / Hul / Gether / Mash
```

Different source-name occurrences remain different Joes unless their lineage
root matches. `Lud` and `Ludim`, for example, are not merged by spelling.

## Genesis 10:25 — PELEG'S DIVIDED EARTH

Eber has Peleg Joe and Joktan Joe. Peleg is named because Earth is divided in
his days.

Display name: **Split-Peleg Joe**, printed down the middle but still one Joe.
The chapter does not identify the exact division mechanism. Genesis 11 is a
required continuation candidate; it may supply the language/scattering parent.

## Genesis 10:26–30 — JOKTAN DWELLING

Joktan fathers Almodad, Sheleph, Hazarmaveth, Jerah, Hadoram, Uzal, Diklah,
Obal, Abimael, Sheba, Ophir, Havilah and Jobab.

Their dwelling extends from Mesha toward Sephar, the eastern mountain.

Sign: `CRACKHEAD JOKTAN ESTATE — FROM ME-SHA TO SO-FAR`.

## Genesis 10:31–32 — NATION STATE EXISTS

Shem's descendants are recorded by families, languages, lands and nations.
The chapter closes all three branches:

```text
NO-AH FAMILIES
-> GENERATIONS
-> NATIONS
-> DIVIDED ON EARTH AFTER FLOOD
```

Genesis 10 records the resulting plurality. Genesis 11 opens at an earlier
one-language State and reconstructs a producing transition. Result-first
catalogue followed by causal account is not automatically contradiction.

## Default nation ledger created

Every nation branch now inherits only:

- its exact No-Ah/Shem-Ham-Japheth lineage path;
- its named family relations;
- existence of its own language where stated;
- its land or boundary where stated;
- its named city/kingdom relations where stated;
- unresolved clothing, institutions, beliefs, technologies and mannerisms
  unless an earlier connected parent actually supplies them.

No nation receives a universal personality. New identity still means new Joe;
national membership is one parent condition, not identity by itself.

## Fuck-up pass

- Havilah -> Have-a-Laugh.
- Nimrod -> Nim-Rod Joe.
- Babel -> Bagel here; `Bagylon` remains reserved for later Babylon address.
- Erech -> A-Wreck.
- Accad -> A-Cad.
- Shinar -> Shin-Argh.
- Assyria -> A-Syria.
- Nineveh -> Nine-Ever.
- Peleg -> Split-Peleg Joe.
- Mesha/Sephar -> Me-Sha/So-Far signage.
- all source identities remain recoverable in tables and ledgers.

## FIR verification

- All 32 verse markers are covered in order.
- Every named genealogy edge is retained.
- Japheth, Ham and Shem branches remain distinct.
- Nimrod's might, hunting, kingdom beginning, movement and cities remain in
  source order without invented conquest.
- Canaanite border and Joktan dwelling bounds are retained.
- Families/languages/lands/nations become explicit only where the source does.
- Modern peoples, stereotypes, borders and languages are not projected back.
- Genesis 10 plurality is held as result inventory pending Genesis 11 mechanism.
- No contradiction or Captain appearance is manufactured.
- Manuscript remains held and unpublished.

Continuation required: Genesis 11 reconstructs one-language Earth, eastward
migration, Shinar settlement, brick/mortar technology, city/tower/name project,
divine inspection, language confusion, scattering, and Shem-to-Abram genealogy.
