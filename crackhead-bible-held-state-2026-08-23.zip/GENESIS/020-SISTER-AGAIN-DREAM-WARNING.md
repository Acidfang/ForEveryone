# CRACKHEAD GENESIS 20

## Title page

**SISTER AGAIN. DREAM WARNING.**

Source parent: Genesis 20:1–18, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 20.

Parent manuscript: `GENESIS/019-DONT-DO-THAT-DO-IT-TO-THESE.md`.

CrackFlix: `S011 — PUNISHED FOR WHAT YOU WERE NOT TOLD.`, episode
`S011-E002-GEN20 — SISTER AGAIN, DREAM WARNING`.

Repeated segments eligible for Captain's private `SKIP`:

- wife presented as sister;
- uninformed ruler takes Sarah;
- wife relation triggers divine action against ruler household.

## Causal foundation

```text
ABRAHAM MOVES SOUTH -> KADESH/SHUR -> FOREIGNER IN GERAR
-> ABRAHAM SAYS SARAH IS HIS SISTER
-> ABIMELECH SENDS AND TAKES SARAH
-> GOD DREAM WARNING: DEAD-MAN / SHE IS A WIFE
-> ABIMELECH HAS NOT TOUCHED SARAH
-> ABIMELECH CITES ABRAHAM'S SISTER CLAIM + SARAH'S BROTHER CLAIM
-> ABIMELECH CITES INTEGRITY / INNOCENCE
-> GOD CONFIRMS INTEGRITY + DIVINE RESTRAINT FROM TOUCHING
-> RESTORE WIFE / PROPHET PRAYER / LIVE
-> NON-RESTORATION -> ABIMELECH + HOUSE DEATH WARNING
-> ABIMELECH REPORTS DREAM TO SERVANTS -> FEAR
-> ABIMELECH CONFRONTS ABRAHAM
-> ABRAHAM REPORTS HIS THOUGHT / HALF-SISTER RELATION / STANDING PLAN
-> ABIMELECH GIVES LIVESTOCK + SERVANTS
-> SARAH RESTORED
-> LAND OPENED TO ABRAHAM
-> 1,000 SILVER GIVEN TO ABRAHAM / SARAH VINDICATION STATEMENT
-> ABRAHAM PRAYS
-> GOD HEALS ABIMELECH / WIFE / FEMALE SERVANTS
-> CHILDBEARING RESUMES
-> SOURCE CLOSES CAUSE: LORD HAD CLOSED HOUSE WOMBS BECAUSE SARAH/WIFE STATE
```

## Genesis 20:1 — GERAR

Abraham travels toward the South, lives between Kadesh and Shur, and resides as
a foreigner in Gerar.

This is a new place/kingdom occurrence. Egypt's Pharaoh episode remains its own
history even though the coming contradiction type repeats.

## Genesis 20:2 — SHE IS MY SISTER, AGAIN

> **ABRAHAM JOE:** `SHE IS MY SISTER.`

Abimelech, king of Gerar, sends for Sarah and takes her.

A Joe-faced fly on the wall opens private CrackFlix:

`S011 — PUNISHED FOR WHAT YOU WERE NOT TOLD`

`PREVIOUSLY: S011-E001 — SISTER IN, PLAGUES OUT`

> **CAPTAIN CRACKHEAD FLY:** `SKIP.`

His eyes glaze. The panel does not skip. Abimelech still takes Sarah. Night
still arrives.

The repeat is exact only at the series root. Sarah now has the sourced
half-sister relation disclosed later in this chapter, and the divine response
occurs through a warning dream before touch.

## Genesis 20:3–5 — DEAD MAN, UNINFORMED MAN

God comes to Abimelech in a night dream.

> **CRACKHEAD GOD:** `YOU ARE A DEAD MAN BECAUSE OF THE WOMAN YOU TOOK.`
>
> `SHE IS A MAN'S WIFE.`

The source immediately states Abimelech had not come near Sarah.

> **ABIMELECH JOE:** `LORD, WILL YOU KILL EVEN A RIGHTEOUS NATION?`
>
> `HE TOLD ME, "SHE IS MY SISTER."`
>
> `SHE HERSELF SAID, "HE IS MY BROTHER."`
>
> `I DID THIS WITH INTEGRITY OF HEART AND INNOCENCE OF HANDS.`

Sarah's `brother` wording is retained as Abimelech's report inside the dream.
The chapter does not provide the earlier scene, timing or exact audience of her
statement, so it is not redrawn as independently witnessed dialogue.

## Genesis 20:6–7 — GOD CONFIRMS THE MISSING-FAULT BOUNDARY

> **CRACKHEAD GOD:** `YES. I KNOW YOU DID THIS IN THE INTEGRITY OF YOUR HEART.`
>
> `I WITHHELD YOU FROM SINNING AGAINST ME.`
>
> `I DID NOT ALLOW YOU TO TOUCH HER.`
>
> `RESTORE THE MAN'S WIFE.`
>
> `HE IS A PROPHET. HE WILL PRAY FOR YOU, AND YOU WILL LIVE.`
>
> `IF YOU DON'T RESTORE HER, YOU AND ALL YOURS WILL SURELY DIE.`

This closes the S011 evidence more tightly than Genesis 12:

```text
ABIMELECH RECEIVES: SISTER / BROTHER PRESENTATION
ABIMELECH ACTS: TAKES SARAH
ABIMELECH DOES NOT: TOUCH SARAH
GOD CONFIRMS: INTEGRITY + DIVINE RESTRAINT
ACTUAL CONCURRENT STATE: SARAH IS ABRAHAM'S WIFE
RESULT ALREADY ACTIVE: HOUSE WOMBS CLOSED
RESULT THREATENED: DEATH IF SARAH NOT RESTORED
```

Captain's glazed eyes clear. A completely boilless Captain Crackhead is now in
the suit beside Abraham's successful-prophet boil.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. The dream, restoration requirement
and household condition remain unchanged.

`SKIP` skipped only Captain's attention. It did not skip the occurrence.

## Genesis 20:8 — THE KING REPORTS THE DREAM

Abimelech rises early, calls all his servants and tells them everything. The
men become very afraid.

The servants receive the warning by Abimelech's report. No servant action,
name, objection or independent dream is supplied.

## Genesis 20:9–10 — WHAT DID YOU DO TO US?

Abimelech calls Abraham.

> **ABIMELECH JOE:** `WHAT HAVE YOU DONE TO US?`
>
> `HOW DID I SIN AGAINST YOU?`
>
> `YOU BROUGHT A GREAT SIN ON ME AND MY KINGDOM.`
>
> `YOU DID THINGS TO ME THAT OUGHT NOT BE DONE.`
>
> `WHAT DID YOU SEE THAT MADE YOU DO THIS?`

The questions expose the causal gap without requiring the comic narrator to
assign a hidden motive.

## Genesis 20:11–13 — ABRAHAM STATES THE STANDING PLAN

> **ABRAHAM JOE:** `I THOUGHT THERE WAS NO FEAR OF GOD IN THIS PLACE.`
>
> `I THOUGHT THEY WOULD KILL ME FOR MY WIFE.`
>
> `SHE REALLY IS MY SISTER: MY FATHER'S DAUGHTER, NOT MY MOTHER'S.`
>
> `SHE BECAME MY WIFE.`
>
> `WHEN GOD CAUSED ME TO WANDER FROM MY FATHER'S HOUSE, I TOLD HER:`
>
> `"EVERYWHERE WE GO, SAY: HE IS MY BROTHER."`

These are Abraham's stated thoughts, genealogy and prior instruction. The fly
records that he says them; it does not independently certify his Gerar
prediction or fill Sarah's mother identity.

The half-sister fact does not dissolve S011. The missing concurrent relation is
`wife`, and Abimelech's own speech plus God's warning show that this relation
changed the action boundary.

Genesis 12 is now reconstructed as one execution of a standing `everywhere`
presentation rule rather than an isolated improvisation, while its exact
Egyptian occurrence remains unchanged.

## Genesis 20:14–16 — RESTORE, PAY, OPEN THE LAND

Abimelech gives Abraham sheep, cattle, male servants and female servants, and
restores Sarah.

> **ABIMELECH JOE:** `MY LAND IS BEFORE YOU. LIVE WHERE IT PLEASES YOU.`

To Sarah he says:

> **ABIMELECH JOE:** `I GAVE YOUR BROTHER ONE THOUSAND PIECES OF SILVER.`
>
> `IT IS A COVERING OF THE EYES FOR EVERYONE WITH YOU.`
>
> `BEFORE EVERYONE, YOU ARE VINDICATED.`

The source assigns the silver to Abraham and calls him `your brother` in this
speech while retaining Sarah as his wife. The manuscript does not invent who
keeps, spends or values the payment, or translate the covering phrase into a
modern legal settlement.

## Genesis 20:17–18 — PRAY, HEAL, REOPEN

Abraham prays to God. God heals Abimelech, his wife and his female servants, and
they bear children.

The final verse supplies the prior condition and cause: the LORD had tightly
closed every womb in Abimelech's house because of Sarah, Abraham's wife.

```text
WOMBS CLOSED BECAUSE WIFE TAKEN
-> WIFE RESTORED
-> ABRAHAM PRAYS
-> GOD HEALS
-> CHILDBEARING RESUMES
```

The source does not state when each womb closed, how the condition was observed,
how long it lasted, or whether any pregnancy begins in this exact panel. `They
bore children` is the resulting capability/outcome statement.

## Character and world-ledger changes

- Abraham: foreign resident in Gerar; repeats sister presentation; is first
  called prophet; states fear-of-place prediction, Sarah half-sister genealogy
  and standing everywhere rule; receives property/payment/land access; prays.
- Sarah: taken under sister presentation; not touched by Abimelech; restored;
  receives public vindication statement; her reported brother statement and
  half-sister/wife relations are retained together.
- Abimelech: king of Gerar; takes Sarah from received presentation; is warned in
  dream before touch; states integrity and missing relation; receives divine
  confirmation; reports warning; confronts Abraham; restores Sarah and gives
  property/silver; is healed after prayer.
- Abimelech's wife and female servants: wombs closed because Sarah-wife event;
  healed after restoration and prayer; childbearing resumes.
- Abimelech's servants: hear the dream report and become afraid.
- Gerar: gains king, household, servants, property-transfer, foreign-residence
  and open-land States; broader national history remains unresolved.

## Fuck-up pass

- Gerar -> `GRR-ARR`, a kingdom whose border sign growls.
- Abimelech -> `A-BIM-A-LICK JOE`; no licking occurs except Captain's finger.
- night dream -> `CRACKHEAD RELATIONSHIP COMPLIANCE ALERT`.
- prophet -> `PRO-FIT JOE`, immediately paid one thousand silver.
- one thousand silver -> `CRACKHEAD COVERING-OF-EYES FUND / EYES STILL VISIBLE`.
- closed wombs -> `CRACKHEAD HOUSEHOLD PRODUCTION: ALL PORTS CLOSED`.
- prayer/healing -> `CRACKHEAD REOPEN REQUEST`, with no invented mechanism.
- SKIP button -> cracked plastic marked `WORKING AS IMAGINED`.

## FIR verification

- All 18 verse markers are covered in order.
- Travel precedes presentation; presentation precedes taking; taking precedes
  dream warning.
- Abimelech's no-touch State and integrity statement are preserved before God's
  confirmation.
- Wife restoration is commanded before property transfer, prayer and healing.
- S011 reuses one contradiction type while Genesis 20 remains a distinct
  episode with distinct evidence.
- `SKIP` appears only because S011-E001 is retained; it changes nothing.
- Captain says only `YOINK!`, remains boilless and does not affect restoration.
- Half-sister truth does not erase concurrently withheld wife status.
- Sarah's brother statement remains reported speech, not invented direct scene.
- Closed-womb cause appears where the source reveals it and is not moved earlier
  as fly knowledge.
- Manuscript remains held and unpublished.

Continuation required: Genesis 21 receives Isaac's birth/circumcision, Sarah's
laughter, weaning feast, Hagar/Ishmael expulsion, wilderness provision,
Abimelech's well dispute/covenant and Beersheba naming.
