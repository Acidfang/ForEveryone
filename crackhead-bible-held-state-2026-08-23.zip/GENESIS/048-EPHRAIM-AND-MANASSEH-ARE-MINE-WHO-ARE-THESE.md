# CRACKHEAD GENESIS 48

## Title page

**EPHRAIM AND MANASSEH ARE MINE.**

**WHO ARE THESE?**

Source parent: Genesis 48:1–22, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 48.

Prepared evidence: `.chapter-work/CHB-GEN-048/job.json` and `source.usfm`.

Parent manuscript: `GENESIS/047-NO-BREAD-HERE-IS-BREAD-ALL-LAND-EXCEPT-THAT-LAND.md`.

CrackFlix routing:

- new `S056 — I KNOW EXACTLY WHO THESE PEOPLE ARE. WHO ARE THESE PEOPLE?`,
  episode `S056-E001-GEN48 — EPHRAIM, MANASSEH, AND THESE TWO RANDOM JOES`.

## Causal foundation

```text
UNNAMED PERSON REPORTS JACOB SICK
-> JOSEPH TAKES MANASSEH + EPHRAIM
-> UNNAMED PERSON REPORTS JOSEPH ARRIVAL
-> ISRAEL STRENGTHENS SELF / SITS ON BED
-> JACOB QUOTES PRIOR LUZ DIVINE APPEARANCE + PROMISE
-> JACOB NAMES EPHRAIM + MANASSEH / CLAIMS THEM AS HIS SONS
-> LATER JOSEPH CHILDREN REMAIN JOSEPH'S / INHERIT THROUGH BROTHERS
-> JACOB RECOUNTS RACHEL DEATH/BURIAL
-> ISRAEL SEES JOSEPH'S SONS / ASKS WHO THEY ARE
-> JOSEPH IDENTIFIES THEM / ATTRIBUTES THEM TO GOD
-> ISRAEL KISSES + EMBRACES THEM
-> JOSEPH POSITIONS FIRSTBORN MANASSEH FOR RIGHT HAND
-> ISRAEL KNOWINGLY CROSSES HANDS / RIGHT HAND ON YOUNGER EPHRAIM
-> JACOB BLESSES / ATTRIBUTES FEEDING + REDEMPTION TO GOD/ANGEL
-> JOSEPH TRIES TO MOVE RIGHT HAND / SAYS MANASSEH IS FIRSTBORN
-> JACOB REFUSES / PREDICTS BOTH PEOPLES / YOUNGER GREATER
-> JACOB SETS EPHRAIM BEFORE MANASSEH
-> ISRAEL PREDICTS GOD RETURN TO FATHERS' LAND
-> JACOB GRANTS JOSEPH EXTRA PORTION / CLAIMS SWORD+BOW ACQUISITION
```

## Genesis 48:1–2 — TWO UNNAMED REPORTS

Someone tells Joseph that his father is sick. Joseph takes Manasseh and
Ephraim. Someone tells Jacob that Joseph is coming. Israel strengthens himself
and sits on the bed.

The two messengers remain unnamed and unmerged. The source does not establish
that they are the same person, what they saw or how either message travelled.

## Genesis 48:3–7 — YOUR TWO SONS ARE MINE

Jacob tells Joseph that God Almighty appeared to him at Luz in Canaan, blessed
him and promised fruitfulness, multiplication, a company of peoples and the
land as an everlasting possession for his offspring.

This is Jacob quoting a prior divine encounter. God is not a present speaker in
this chapter.

Jacob then identifies Joseph's two Egypt-born sons by name:

> **JACOB:** `EPHRAIM AND MANASSEH... WILL BE MINE, AS REUBEN AND SIMEON ARE.`

Later Joseph offspring will remain Joseph's and be called after these brothers
for inheritance. No later offspring are present or named.

Jacob recounts Rachel dying beside him on the Canaan road before Ephrath and
his burying her there on the way to Ephrath/Bethlehem. Rachel's retained death
and burial State do not change.

## Genesis 48:8–12 — WHO ARE THESE?

Israel sees Joseph's sons and asks:

> **ISRAEL:** `WHO ARE THESE?`

Joseph answers that they are his sons, whom God has given him there. That divine
gift claim remains Joseph's attribution.

The completed observable mismatch is:

```text
JACOB IDENTIFIES JOSEPH'S TWO SONS BY NAME
-> CLAIMS EPHRAIM + MANASSEH AS HIS OWN
-> SAME TWO SONS REMAIN PRESENT WITH JOSEPH
-> ISRAEL SEES JOSEPH'S SONS
-> ASKS WHO THEY ARE
-> NO LOSS-OF-MEMORY ACT OR DIFFERENT-CHILD IDENTIFICATION IS SUPPLIED
```

Dim eyes explain that Israel cannot see well; they do not replace his explicit
`saw` act or supply a different pair of sons. S056 closes.

A family ledger grows a Joe-faced boil displaying two already completed identity
cards and one new form marked `WHO?`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain pokes it, licks his finger, walks away and never looks back. Joseph's
answer, Israel's kiss/embrace and Joseph's bow continue unchanged.

## Genesis 48:13–16 — THE HANDS CROSS KNOWINGLY

Joseph places Ephraim toward Israel's left hand and firstborn Manasseh toward
his right. Israel deliberately crosses his hands: right on younger Ephraim,
left on Manasseh. The source explicitly says he guides them knowingly.

Jacob blesses Joseph and speaks of the God before whom Abraham and Isaac walked,
the God who fed him through life and the angel who redeemed him from all evil.
He asks the angel to bless the lads, place the ancestral names on them and let
them grow into a multitude.

These divine feeding, redeeming and requested blessing relations remain Jacob's
speech. No angel appears or speaks, and no growth outcome occurs in this chapter.

## Genesis 48:17–20 — NOT SO. I KNOW.

Joseph sees the right hand on Ephraim. The source attributes displeasure to
Joseph. He lifts Jacob's hand to move it toward Manasseh and says:

> **JOSEPH:** `NOT SO, MY FATHER. THIS IS THE FIRSTBORN.`

Jacob refuses:

> **JACOB:** `I KNOW, MY SON. I KNOW.`

Jacob predicts that Manasseh will become a people and be great, but Ephraim will
be greater and become a multitude of nations. He blesses them and places
Ephraim before Manasseh.

This is an observable correction attempt followed by explicit refusal and a
deliberate different ranking. It is disagreement, not an invented contradiction.
The future people/nation outcomes remain predictions.

## Genesis 48:21–22 — DYING, RETURNING, ONE EXTRA PORTION

Israel tells Joseph he is dying and predicts that God will be with the family
and bring them again to their fathers' land. Jacob then gives Joseph one portion
above his brothers, described as taken from the Amorite with Jacob's sword and
bow.

Jacob remains alive at chapter end. God-return is Jacob's prediction, not a
performed divine act. The exact land portion, Amorite event and relation to
earlier land purchases are unresolved; no missing battle is reconstructed from
the claim alone.

## Character and world-ledger changes

- Jacob/Israel advances through sickness, two-son adoption/claim, intentional
  crossed-hand blessing, future predictions and an extra-portion claim.
- Joseph advances through bringing both sons, identifying them, positioning
  them, attempting hand correction and receiving the extra portion.
- Manasseh and Ephraim remain Joseph/Asenath sons while gaining Jacob-son and
  inheritance-name relations; neither identity is replaced or merged.
- The two unnamed messengers remain separate unresolved identities.
- Rachel remains deceased and buried on the Ephrath/Bethlehem road.
- Every living person has Joe's face; the same face supplies no identity answer.

## Bullshit pass

- banner: `ARTICLE 48 — CRACKHEAD FAMILY LEDGER HOSTILE TAKEOVER`;
- adoption form: `JOSEPH'S SONS / JACOB'S SONS / STILL THE SAME JOES`;
- eye test: `CAN SEE SONS / CANNOT SEE WELL / WHO DIS`;
- hand diagram: `RIGHT -> YOUNGER / LEFT -> FIRSTBORN / KNOWINGLY`;
- correction button: `NOT SO`; response light: `I KNOW`;
- inheritance ticket: `ONE PORTION ABOVE / BATTLE RECEIPT NOT ATTACHED`;
- barcode: `CHB-GEN48-S056E001-22-YOINK`;
- footer: `BIG BAG BLESSING ORDER — HANDS MAY CROSS WITHOUT WARNING`.

## FIR verification

- all 22 verse markers are represented in order;
- the unnamed reporters remain unmerged;
- Jacob's quoted Luz speech remains attributed testimony, not new God speech;
- Ephraim and Manasseh retain Joseph/Asenath parentage while acquiring Jacob-son
  and inheritance relations;
- S056 depends only on names/claim, continued presence, seeing and identity
  question; no motive or diagnosis is invented;
- dim sight is retained without erasing the source's `saw` wording;
- the crossed-hand act is knowingly performed and Joseph's correction fails;
- blessing and future greatness/nation/return claims remain attributed speech;
- no direct God or angel speech, appearance or narrator-assigned act occurs;
- Jacob remains alive; burial oath and divine return remain open;
- sword/bow portion identity and acquisition occurrence remain unresolved;
- publication remains held and unpublished.

Continuation required: Genesis 49 gathers the sons, assigns future sayings to
each, repeats and changes earlier character States, commands Machpelah burial
and completes Jacob's death.
