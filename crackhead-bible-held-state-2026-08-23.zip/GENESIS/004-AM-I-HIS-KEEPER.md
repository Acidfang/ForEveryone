# CRACKHEAD GENESIS 4

## Title page

**I DON'T KNOW WHERE THE JOE I KILLED IS**

Source parent: Genesis 4:1–26, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 4.

Parent manuscript: `GENESIS/003-RULE-GOT-BIGGER.md`.

CrackFlix crossover: `S007 — I DON'T KNOW WHERE HE IS`.

## Causal foundation

```text
EXPELLED HUMAN JOE + EVE JOE
-> CAIN JOE BORN -> ABEL JOE BORN
-> GROUND WORK / SHEEP WORK
-> TWO OFFERINGS -> DIFFERENT RESPECT STATES
-> CAIN ANGRY + FACE FALLEN
-> GOD QUESTIONS + WARNS
-> FIELD -> CAIN KILLS ABEL
-> GOD ASKS LOCATION -> CAIN SAYS HE DOESN'T KNOW
-> BLOOD/GROUND EVIDENCE -> CURSE + FAILED YIELD + WANDERING
-> CAIN OBJECTS TO CONSEQUENCE
-> PROTECTIVE SIGN -> CAIN LEAVES -> NOD SETTLEMENT
-> CAIN LINE -> CITY / TENTS / LIVESTOCK / MUSIC / METALWORK
-> LAMECH REPORTS TWO KILLINGS + SEVENTY-SEVENFOLD CLAIM
-> SETH LINE -> ENOSH -> CALLING ON GOD'S NAME
```

## Genesis 4:1–2 — CANE JOE AND ABLE JOE

Human Joe and Eve Joe have relations. Eve conceives and gives birth to Cain.

> **EVE JOE:** `I GOT A MAN WITH THE LORD'S HELP.`

She later gives birth to Cain's brother Abel.

The fuck-up pass renders their display names **Cane Joe** and **Able Joe** while
the ledger retains Cain and Abel as source identities.

Able Joe keeps Joe-faced sheep. Cane Joe tills the ground already carrying the
Genesis 3 toil boundary. Their occupations derive from different available
work, not different faces.

## Genesis 4:3–5 — TWO OFFERINGS

After time passes, Cane Joe brings fruit of the ground to God. Able Joe brings
firstborn animals from his flock and their fat.

God respects Able Joe and his offering. God does not respect Cane Joe and his
offering. The source supplies no spoken offering rule or explanation in this
chapter, so the comic supplies none.

Cane Joe becomes very angry. His facial expression falls. His ordinary Joe face
remains the universal face; its observable expression changes.

## Genesis 4:6–7 — DO WELL / DOOR THING

> **CRACKHEAD GOD:** `WHY ARE YOU ANGRY? WHY HAS YOUR FACE FALLEN?`
>
> `DO WELL AND IT LIFTS.`
>
> `DON'T, AND SIN JOE IS CROUCHING AT THE DOOR.`
>
> `IT WANTS YOU. RULE OVER IT.`

Anything interpreted as having a face may receive Joe's face. The crouching
door thing therefore has Joe's face in production. The manuscript does not
decide whether the figure is organism, metaphor or badly generated furniture.

## Genesis 4:8 — THE FIELD

> **CANE JOE:** `ABLE JOE. LET'S GO TO THE FIELD.`

In the field, Cane Joe rises against his brother and kills him. No weapon,
method, private thought or unrecorded argument is invented.

Able Joe's life ledger closes at this Moment. His source identity remains; he is
not erased from lineage.

## Genesis 4:9–10 — I DON'T KNOW

> **CRACKHEAD GOD:** `WHERE IS ABLE JOE, YOUR BROTHER?`

> **CANE JOE:** `I DON'T KNOW.`
>
> `AM I MY BROTHER'S KEEPER?`

Observable sequence:

```text
CANE JOE TAKES ABLE JOE INTO FIELD
-> CANE JOE KILLS ABLE JOE THERE
-> GOD ASKS WHERE ABLE JOE IS
-> CANE JOE SAYS I DON'T KNOW
```

This completes CrackFlix `S007-E001 — AM I HIS KEEPER?`. Captain's glazed eyes
clear. He is boilless and dressed as an unexplained superhero.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes Cane Joe's boil, licks his finger, walks away eating the crack crystal
he sees, and does not look back. Cane Joe and God continue unchanged.

> **CRACKHEAD GOD:** `WHAT DID YOU DO?`
>
> `YOUR BROTHER'S BLOOD IS CALLING FROM THE GROUND.`

The blood and ground are observable source evidence. God does not need Captain.

## Genesis 4:11–12 — GROUND CANCELS CANE

God states that the ground opened its mouth to receive Able Joe's blood from
Cane Joe's hand. Cane Joe is cursed from that ground. When he tills, it will no
longer yield its strength to him. He will be a fugitive and wanderer.

Sign: `CRACKHEAD GROUND ACCOUNT — YIELD FACILITY WITHDRAWN`.

This changes Cane Joe's capability inventory: `ground-tilling` remains known;
`ground-yield-for-Cane` becomes unavailable.

## Genesis 4:13–15 — TOO MUCH / DON'T KILL HIM

> **CANE JOE:** `THAT PUNISHMENT IS MORE THAN I CAN CARRY.`
>
> `YOU DROVE ME FROM THE GROUND. I'M HIDDEN FROM YOUR FACE.`
>
> `I'LL WANDER. WHOEVER FINDS ME WILL KILL ME.`

The chapter has not yet identified every possible finder. That population
boundary remains unresolved rather than filled with invented siblings.

God states that whoever kills Cane Joe receives sevenfold vengeance. God places
a sign on Cane Joe so a finder will not strike him.

The sign's appearance is not supplied. Production may make the sign itself a
tiny Joe face. Its retained function is protection from being struck.

## Genesis 4:16–18 — NOD, CITY AND LINE

Cane Joe leaves God's presence and lives in **Nod**, east of Eatin'. Nod is
rendered as a land where every visible Joe is nodding; the place identity stays
Nod.

Cane Joe and his wife have Enoch. The wife's origin and name are not supplied
here and remain unresolved.

Cane Joe builds a city and names it Enoch after his son. The family continues:

```text
CANE JOE
-> ENOCH JOE
-> IRAD JOE
-> MEHUJAEL JOE
-> METHUSHAEL JOE
-> LAMECH JOE
```

The same source name refers to son and city through the recorded naming act;
their identities remain distinct.

## Genesis 4:19–22 — THE INVENTORY ARRIVES

Lamech Joe takes two wives, Adah Joe and Zillah Joe.

Adah Joe gives birth to:

- **Jabal Joe**, ancestor of tent-dwellers with livestock;
- **Jubal Joe**, ancestor of handlers of harp and pipe.

Zillah Joe gives birth to:

- **Tubal-Cain Joe**, forger of bronze and iron cutting instruments;
- **Naamah Joe**, his sister.

These relations create the first explicit generative inventory branches for
tents, livestock practice, instruments, music handling, bronze, iron, forging
and cutting tools. Descendants receive them only through an actual lineage or
learning relation; the entire population does not instantly know them.

Nonsense labels appear after closure: `CRACKHEAD TENT OS`, `JUBAL'S PIPELINE`,
and `TUBAL-CANE CUTTING-EDGE AS-A-SERVICE`.

## Genesis 4:23–24 — LAMECH'S LEDGER ENTRY

> **LAMECH JOE:** `ADAH JOE. ZILLAH JOE. HEAR ME.`
>
> `I KILLED A MAN FOR WOUNDING ME.`
>
> `A YOUNG MAN FOR BRUISING ME.`
>
> `CANE GETS SEVEN. LAMECH GETS SEVENTY-SEVEN.`

The source does not identify whether the two descriptions refer to one person
or two, whether the claimed retaliation rule has authority, or what happened
outside this speech. Both statements and the uncertainty remain retained.

Candidate contradiction routing remains unresolved until another State opposes
or applies Lamech Joe's claim. A violent boast alone is not automatically a
contradiction.

## Genesis 4:25–26 — SETH JOE AND ENOSH JOE

Human Joe and Eve Joe have another son.

> **EVE JOE:** `GOD GAVE ME ANOTHER CHILD INSTEAD OF ABLE JOE, BECAUSE CANE
> KILLED HIM.`

She names him Seth. Seth later has Enosh. At that time, people begin to call on
the LORD's name.

The manuscript retains Eve Joe's explicit causal statement. Seth Joe does not
replace or erase Able Joe's identity; he is a new Joe with a new origin.

`NEW IDENTITY -> NEW JOE`.

## Character and world-ledger changes

- Cane Joe: first child, ground worker, offering giver, angry/fallen expression,
  warned speaker, killer, false-location reporter, cursed wanderer, protected by
  sign, Nod resident, parent and city builder.
- Able Joe: second child, brother, sheep keeper, offering giver, respected with
  offering, killed in field; blood remains causally active in God's address.
- Eve Joe: mother of Cane, Able and Seth; her speech now includes childbirth,
  divine assistance, loss, killing and replacement relations.
- Lamech line: family branches produce settlement, livestock, music and metal
  technology inventories.
- Seth line: produces Enosh and the first retained collective calling on God's
  name.
- People State remains pre-national. Family lines, a named land and a city now
  exist; nations and named languages still do not.

## Fuck-up pass

- Cain -> Cane Joe.
- Abel -> Able Joe.
- Eden -> Eatin'.
- Nod -> visibly nodding land; source spelling retained.
- Cain's mark -> optional tiny Joe-faced sign; function retained.
- sin crouching at door -> Joe-faced door thing; interpretation unresolved.
- Tubal-Cain -> Tubal-Cane Joe.
- cutting instrument -> `CUTTING-EDGE AS-A-SERVICE` background label.
- all other lineage names retain source spelling plus Joe until later wordplay
  can preserve their genealogical addresses without ambiguity.

## FIR verification

- All 26 verse markers are covered in order.
- Birth precedes occupations; occupations precede offerings.
- Different respect States precede anger and God's warning.
- Warning precedes the field killing.
- Killing precedes the location question and `I DON'T KNOW` report.
- Blood/ground evidence precedes curse and lost yield.
- Protective sign precedes departure and Nod settlement.
- Cain's descendant chain remains separate from Seth's chain.
- Every introduced technology retains its producing family relation.
- No nation, language, wife origin, finder population, weapon or hidden motive is
  invented.
- Captain appears only after the completed observable friction and changes no
  outcome.
- Manuscript remains held and unpublished.

Continuation required: Genesis 5 receives the Seth lineage, Adam's age/death
boundary, Enosh, Enoch, Lamech, Noah and the repeated birth/life/death pattern.
