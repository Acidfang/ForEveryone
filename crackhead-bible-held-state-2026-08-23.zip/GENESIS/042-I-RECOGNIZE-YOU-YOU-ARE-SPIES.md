# CRACKHEAD GENESIS 42

## Title page

**I RECOGNIZE YOU.**

**YOU ARE SPIES.**

**SIMEON IS ALIVE IN EGYPT. SIMEON IS NO MORE.**

Source parent: Genesis 42:1–38, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 42.

Prepared evidence: `.chapter-work/CHB-GEN-042/job.json` and `source.usfm`.

Parent manuscript: `GENESIS/041-I-FORGOT-HIM-I-REMEMBER-TODAY.md`.

CrackFlix routing:

- `S050 — I RECOGNIZE YOU. YOU ARE SPIES.`, episode
  `S050-E001-GEN42 — IDENTITY KNOWN, IDENTITY ON TRIAL`;
- `S051 — HE IS ALIVE IN CUSTODY. HE IS NO MORE.`, episode
  `S051-E001-GEN42 — TEMPORARY ABSENCE, TOTAL LOSS LEDGER`.

## Causal foundation

```text
FAMINE IN CANAAN / GRAIN REPORTED IN EGYPT
-> JACOB SENDS TEN SONS TO BUY / HOLDS BENJAMIN BACK FOR HARM FEAR
-> TEN BROTHERS BOW TO EGYPT GOVERNOR JOSEPH
-> JOSEPH RECOGNIZES THEM / THEY DO NOT RECOGNIZE HIM
-> JOSEPH REMEMBERS DREAMS / ACTS STRANGER / SPEAKS ROUGHLY
-> JOSEPH CALLS THEM SPIES / THEY CLAIM FOOD-BUYERS + HONEST BROTHERS
-> BROTHERS REPORT TWELVE: YOUNGEST WITH FATHER / ONE NO MORE
-> JOSEPH REQUIRES BENJAMIN AS TRUTH TEST
-> ALL TEN HELD THREE DAYS
-> TEST REVISED: ONE HELD / OTHERS TAKE GRAIN / RETURN BENJAMIN
-> BROTHERS ATTRIBUTE DISTRESS TO JOSEPH WRONG / REUBEN RECALLS WARNING
-> BROTHERS DO NOT KNOW JOSEPH UNDERSTANDS
-> JOSEPH WEEPS APART / BINDS SIMEON BEFORE THEM
-> JOSEPH FILLS BAGS / SECRETLY RESTORES EACH PAYMENT / GIVES ROAD FOOD
-> ONE FINDS MONEY AT LODGING / BROTHERS FEAR + ASK WHAT GOD DID
-> BROTHERS REPORT OCCURRENCE TO JACOB
-> ALL MONEY BUNDLES FOUND / HOUSEHOLD AFRAID
-> JACOB CLASSIFIES JOSEPH + SIMEON AS NO MORE / REFUSES BENJAMIN
-> REUBEN OFFERS HIS TWO SONS AS FAILURE CONSEQUENCE
-> JACOB RETAINS REFUSAL / SIMEON REMAINS ALIVE IN EGYPT CUSTODY
```

## Genesis 42:1–5 — BUY SO WE MAY LIVE

Jacob sees grain is available in Egypt, asks why his sons look at one another,
and commands them to buy so the household may live rather than die. Ten of
Joseph's brothers go. Jacob withholds Benjamin because he states possible harm.
The sons of Israel enter the famine-buyer population from Canaan.

Jacob's fear is explicitly his stated condition. No prediction of actual harm,
ranking of sons or knowledge of Joseph is added.

## Genesis 42:6–9 — THE DREAM BOWS BACK

Joseph is governor and grain seller. His brothers bow with faces to earth.
Joseph sees and recognizes them, acts as a stranger, speaks roughly and asks
their origin. They say Canaan and food purchase.

The source repeats the asymmetry: Joseph recognizes them; they do not recognize
him. Joseph remembers his dreams and says:

> **JOSEPH JOE:** `YOU ARE SPIES. YOU CAME TO SEE THE NAKEDNESS OF THE LAND.`

That completes S050:

```text
JOSEPH KNOWS THEIR FAMILY IDENTITY
-> BROTHERS STATE CANAAN FOOD-PURCHASE PURPOSE
-> JOSEPH ASSERTS SPY IDENTITY/PURPOSE
-> BENJAMIN PRESENCE MADE TEST OF THEIR WORDS
```

The source does not call the accusation true or reveal a spy observation.
Joseph's remembered dreams precede it, but motive is not stated.

His authority boil becomes a Joe-faced border form already stamped
`IDENTITY KNOWN`, with `SPY?` still demanding proof.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain pokes, licks an empty finger, walks away and never looks back. The test,
custody and grain process remain unchanged.

## Genesis 42:10–17 — HONEST MEN UNDER A SPY TEST

The brothers deny spying, identify themselves as food-buying servants and
honest sons of one man. Joseph repeats the accusation. They disclose twelve
brothers: youngest with father and one `no more`.

That phrase is their report. Joseph is the person classified as no more and is
alive before them, but they do not recognize him. The earlier sale and false
death evidence remain retained; the phrase alone does not specify whether they
mean dead, absent from household or unknown location.

Joseph says one brother must fetch Benjamin while the rest remain bound, or
they are spies. He puts all together in custody for three days. A test condition
is observable; its sufficiency for proving non-spy identity is not explained.

## Genesis 42:18–24 — ONE STAYS, NINE GO

On the third day Joseph says he fears God and revises the process: one brother
will remain bound while the others carry famine grain home, then bring Benjamin
so their words are verified and they do not die. They comply.

The revision follows three days and replaces the earlier send-one/bind-rest
process. It is changed instruction, not secretly treated as simultaneous rules.

The brothers say to one another that they are guilty concerning their brother:
they saw his distress and did not listen when he begged; therefore this distress
came. Reuben says he warned them not to sin against the child and now his blood
is required. These are their causal/moral attributions.

They do not know Joseph understands because an interpreter stands between them.
Joseph turns away and weeps, returns, takes Simeon and binds him before them.
No brother observes Joseph's private weeping.

## Genesis 42:25–28 — PAID MONEY COMES BACK

Joseph commands their bags filled, each man's money restored into his sack and
road food supplied. It is done. They load Joe-faced donkeys and leave.

At lodging one opens a sack to feed his donkey and sees his money at the sack
mouth. He reports it restored. Their hearts fail; they tremble and ask:

> **BROTHER JOES:** `WHAT IS THIS THAT GOD HAS DONE TO US?`

The physical chain proves secret restoration and discovery. The God-causation
question remains brother speech. The source supplies no theft accusation, gift
notice, trap explanation or answer.

## Genesis 42:29–35 — THE REPORT AND ALL THE BUNDLES

The brothers return to Jacob and report the rough lord, spy classification,
their honest-men reply, twelve-brother inventory, one-no-more statement,
Benjamin condition, Simeon retention and promised trade access.

Their retelling compresses the three-day all-brothers custody and changes
Joseph's direct wording into a household report. It does not create a separate
occurrence.

When every sack is emptied, every money bundle is present. The brothers and
Jacob see them and are afraid. The chapter still supplies no accusation or
explanation.

## Genesis 42:36–38 — ALIVE, HELD, NO MORE

> **JACOB JOE:** `YOU HAVE BEREAVED ME OF MY CHILDREN! JOSEPH IS NO MORE,
> SIMEON IS NO MORE, AND YOU WANT TO TAKE BENJAMIN.`

Simeon is alive and bound in Egypt under a stated return condition. Jacob has
just heard that custody report, then classifies Simeon as `no more`. That
completes S051: temporary absence/custody is entered in the same total-loss
language as Joseph.

Jacob's boil becomes a Joe-faced family ledger erasing Simeon's row while the
row itself shouts `CURRENT LOCATION: EGYPT`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain performs the usual useless poke, empty-finger lick and departure.
Simeon remains bound and Jacob remains unwilling.

Reuben offers his two sons to be killed if he fails to return Benjamin and asks
Jacob to entrust Benjamin to him. Jacob refuses: Joseph's brother is dead,
Benjamin alone is left, possible travel harm would bring Jacob's gray hairs to
Sheol in sorrow.

The two sons are neither killed nor transferred. Reuben's offer does not become
Jacob's acceptance. `Only left` retains the immediate Joseph/Benjamin maternal
brother context rather than erasing Jacob's other present sons.

## Joe continuity ledger

- Joseph remains the recognized-by-self/unrecognized-by-brothers governor.
- ten travelling brothers remain distinct; Benjamin stays with Jacob.
- Simeon moves into living Egypt custody and is not dead.
- Reuben retains his earlier warning/restoration divergence from other brothers.
- Jacob retains the false Joseph-death State and now adds Simeon-loss language.
- the interpreter is a distinct unnamed Joe; presence does not prove Joseph
  required interpretation.
- every donkey is Joe-faced; money, sacks and grain are nonliving evidence.
- Captain remains permanently boilless and causally unnecessary.

## Bullshit pass

- banner: `ARTICLE 42 — CRACKHEAD BORDER AND BROTHER VERIFICATION`;
- spy form: `KNOWN FAMILY / UNKNOWN PURPOSE / DETAIN EVERYONE`;
- interpreter badge: `THE GOVERNOR UNDERSTANDS THIS, YOU DON'T`;
- sack label: `PAID / REFUNDED / NOBODY TOLD ACCOUNTS`;
- family ledger: `SIMEON — ALIVE BUT CROSSED OUT`;
- barcode: `CHB-GEN42-S050-S051-38-YOINK`;
- footer: `BIG BAG OF GRAIN — MONEY INCLUDED BY SURPRISE`.

## Reconstruction boundary

- all 38 verse markers are represented in order;
- bowing advances Joseph's dream relation but does not close every family symbol;
- S050 retains Joseph's recognition and unsupported spy assertion without
  inventing motive;
- `one is no more` remains ambiguous brother wording;
- brothers' guilt/blood and God statements remain character attributions;
- Joseph's private weeping remains unavailable to brothers;
- restored money remains unexplained beyond Joseph command and discovery;
- S051 depends on living custody plus Jacob's no-more classification;
- Reuben's child-killing offer is not accepted or performed;
- no direct God speech, messenger speech or narrator-assigned divine act occurs;
- publication remains held and unpublished.

Continuation required: Genesis 43 resumes famine pressure, Judah's Benjamin
guarantee, double-money return, Joseph household reception, Simeon release,
recognition asymmetry and the separated seating/Benjamin portion.
