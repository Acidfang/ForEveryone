# CRACKHEAD GENESIS 34

## Title page

**BECOME ONE PEOPLE WITH US.**

**EVERY MALE AGREED.**

**WAIT UNTIL THE THIRD DAY.**

**KILL ALL THE MALES.**

Source parent: Genesis 34:1–31, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 34.

Parent manuscript:
`GENESIS/033-THE-PRESENT-APPEASED-HIM-BEFORE-HE-KNEW.md`.

CrackFlix crossover:

- `S034 — I LOVE HER. I TOOK AND VIOLATED HER.`, episode
  `S034-E001-GEN34 — KIND WORDS AFTER THE ACT`;
- `S035 — GET POSSESSIONS HERE. THEIR POSSESSIONS WILL BE OURS.`, episode
  `S035-E001-GEN34 — TWO AUDIENCES, BOTH PROPERTY PITCHES`;
- `S036 — BECOME ONE PEOPLE. KILL ALL THE MALES.`, episode
  `S036-E001-GEN34 — CONSENT AS THE ATTACK CONDITION`;
- `S037 — THESE MEN ARE PEACEFUL. THEY KILLED ALL THE MALES.`, episode
  `S037-E001-GEN34 — THIRD-DAY PEACE`.

Held candidate, not routed:

- Simeon and Levi object to their sister being dealt with as a prostitute after
  Jacob's sons take the city's wives and little ones captive as plunder. The
  source identifies Simeon/Levi as the two killers but does not isolate which
  individual sons perform each later plunder/captivity act. Preserve the
  friction; do not manufacture an exact actor map.

## Causal foundation

```text
DINAH GOES OUT TO SEE DAUGHTERS OF LAND
-> SHECHEM SEES / TAKES / LIES WITH / VIOLATES DINAH
-> SOURCE: SOUL JOINS / LOVES / SPEAKS KINDLY
-> SHECHEM ASKS HAMOR TO GET DINAH AS WIFE
-> JACOB HEARS DEFILEMENT / SONS IN FIELD / JACOB WAITS
-> HAMOR COMES TO TALK / SONS RETURN GRIEVED + ANGRY
-> HAMOR REQUESTS DINAH + INTERMARRIAGE + LAND/TRADE/POSSESSIONS
-> SHECHEM OFFERS WHATEVER DOWRY/GIFT / REQUESTS DINAH
-> JACOB SONS ANSWER WITH DECEIT
-> CONDITION: EVERY CITY MALE CIRCUMCISED
-> PROMISE: INTERMARRIAGE + DWELL + ONE PEOPLE
-> REFUSAL RESULT: TAKE SISTER + LEAVE
-> HAMOR/SHECHEM PLEASED / SHECHEM ACTS WITHOUT DELAY
-> HAMOR/SHECHEM TELL CITY: JACOB MEN PEACEFUL
-> CITY PITCH: LAND/MARRIAGE + THEIR LIVESTOCK/POSSESSIONS WILL BE OURS
-> ALL GATE MEN LISTEN / EVERY MALE CIRCUMCISED
-> THIRD DAY / MEN SORE
-> SIMEON + LEVI ENTER UNSUSPECTING CITY / KILL ALL MALES
-> HAMOR + SHECHEM KILLED
-> DINAH TAKEN FROM SHECHEM HOUSE
-> JACOB SONS PLUNDER DEAD/CITY FOR SISTER DEFILEMENT
-> ANIMALS + CITY/FIELD PROPERTY + WEALTH TAKEN
-> LITTLE ONES + WIVES CAPTURED / HOUSE CONTENTS PLUNDERED
-> JACOB STATES ODIOUS/FEW/RETALIATION/DESTRUCTION DANGER
-> SIMEON + LEVI: SHOULD HE TREAT OUR SISTER AS PROSTITUTE?
```

## Genesis 34:1–4 — TOOK, VIOLATED, LOVED, ASKED

Dinah, daughter of Leah and Jacob, goes out to see the daughters of the land.
No companion, invitation, clothing, destination within the land or purpose
beyond `to see` is supplied.

Shechem, son of Hamor the Hivite and prince of the land, sees Dinah. The source
then states that he:

1. takes her;
2. lies with her;
3. violates/humbles her.

The source supplies no Dinah consent statement. Nothing in her prior act of
going out supplies one.

The source then reports that Shechem's soul joins to Dinah, that he loves the
young woman and speaks kindly to her. These internal/affective States are source
testimony, not conclusions drawn from his Joe face.

> **SHECHEM JOE TO HAMOR:** `GET ME THIS YOUNG WOMAN AS A WIFE.`

Dinah has no recorded reply. The request goes to Shechem's father, not to Dinah.

That completes S034:

```text
SHECHEM TAKES DINAH / LIES WITH HER / VIOLATES HER
-> SOURCE: SHECHEM LOVES HER
-> SHECHEM SPEAKS KINDLY TO HER
-> SHECHEM ASKS HIS FATHER TO GET HER AS WIFE
-> NO DINAH CONSENT OR SPEECH RECORDED
```

Shechem's love-status boil grows a Joe-faced wedding card printed directly over
a receipt labelled `TAKEN FIRST`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Dinah and Shechem see only a completely boilless suited nobody poke Shechem's
boil, lick an empty finger, walk away and never look back. Dinah's State and all
subsequent negotiations remain unchanged.

## Genesis 34:5–7 — JACOB WAITS; SONS RETURN

Jacob hears that Shechem defiled Dinah. Jacob's sons are with livestock in the
field, so Jacob holds his peace until they return. The silence and wait are
observable. The source does not assign Jacob's private reason beyond the sons'
absence relation.

Hamor comes out to Jacob to talk. Jacob's sons return when they hear.

The source says the men are grieved and very angry because Shechem did folly in
Israel by lying with Jacob's daughter, a thing that ought not be done. Grief,
anger and the source judgment are direct source testimony, not facial inference.

`In Israel` appears as a people/moral-boundary label while Israel is also Jacob's
new name. The text does not require the later nation inventory to be silently
materialized at this Moment.

## Genesis 34:8–12 — SPEAKING TO EVERYONE EXCEPT DINAH

> **HAMOR JOE:** `MY SON SHECHEM'S SOUL LONGS FOR YOUR DAUGHTER.`
>
> `PLEASE GIVE HER TO HIM AS A WIFE.`
>
> `MAKE MARRIAGES WITH US.`
>
> `GIVE US YOUR DAUGHTERS AND TAKE OUR DAUGHTERS.`
>
> `DWELL WITH US.`
>
> `THE LAND IS BEFORE YOU.`
>
> `LIVE, TRADE AND GET POSSESSIONS IN IT.`

> **SHECHEM JOE TO DINAH'S FATHER AND BROTHERS:** `LET ME FIND FAVOR IN YOUR
> EYES.`
>
> `WHATEVER YOU TELL ME, I WILL GIVE.`
>
> `ASK A GREAT DOWRY AND GIFT.`
>
> `I WILL GIVE WHATEVER YOU ASK.`
>
> `GIVE ME THE YOUNG WOMAN AS WIFE.`

Dinah remains the requested person but receives no recorded question, offer or
reply. The manuscript does not convert father/brother negotiations into her
consent.

## Genesis 34:13–17 — THE DECEITFUL CONDITION

The source explicitly says Jacob's sons answer Shechem and Hamor with deceit
because Shechem defiled Dinah.

> **JACOB'S SON JOES:** `WE CAN'T GIVE OUR SISTER TO AN UNCIRCUMCISED MAN.`
>
> `THAT IS A REPROACH TO US.`
>
> `WE WILL CONSENT ONLY IF EVERY MALE AMONG YOU IS CIRCUMCISED AS WE ARE.`
>
> `THEN WE WILL INTERMARRY, DWELL WITH YOU AND BECOME ONE PEOPLE.`
>
> `IF YOU DON'T, WE WILL TAKE OUR SISTER AND GO.`

The source labels the answer deceit before the city acts. Therefore the stated
condition cannot be treated as a sincere closure promise. Dinah still has no
recorded voice, and `we will consent` belongs to her brothers.

## Genesis 34:18–24 — PEACEFUL MEN / OUR PROPERTY

The words please Hamor and Shechem. The source says Shechem does not delay
because he delights in Jacob's daughter and is honored above his father's
house. Those are source-attributed States.

Hamor and Shechem address the men at their city gate:

> **HAMOR AND SHECHEM JOES:** `THESE MEN ARE PEACEFUL WITH US.`
>
> `LET THEM LIVE AND TRADE IN THE LAND.`
>
> `THE LAND IS LARGE ENOUGH.`
>
> `LET'S INTERMARRY.`
>
> `THEY WILL LIVE WITH US AND BECOME ONE PEOPLE IF EVERY MALE IS CIRCUMCISED.`
>
> `WON'T THEIR LIVESTOCK, POSSESSIONS AND ALL THEIR ANIMALS BE OURS?`
>
> `CONSENT, AND THEY WILL DWELL WITH US.`

To Jacob's family Hamor offered land in which they could `get possessions`. To
the city men, Hamor and Shechem offer the expectation that Jacob's livestock,
possessions and animals will become `ours`.

That completes S035:

```text
TO JACOB FAMILY: LIVE / TRADE / GET POSSESSIONS IN OUR LAND
-> TO CITY MEN: THEIR LIVESTOCK / POSSESSIONS / ANIMALS WILL BE OURS
-> SAME INTERMARRIAGE + DWELLING PROPOSAL SOLD THROUGH OPPOSITE PROPERTY GAINS
```

Hamor's intermarriage boil becomes two full Joe mouths sharing one sales
brochure: `YOU GET POSSESSIONS` on the outside, `WE GET THEIR POSSESSIONS` on
the inside.

> **CAPTAIN CRACKHEAD:** `YOINK!`

The gate assembly sees a boilless nobody poke the boil, lick his finger and
leave. The proposal and consent process remain unchanged.

All men going out of the city gate listen to Hamor and Shechem. Every male is
circumcised. The city has now performed the condition presented as producing
intermarriage, dwelling and one people.

## Genesis 34:25–29 — THIRD-DAY ONE PEOPLE

On the third day, the city men are sore. Simeon and Levi—Jacob's sons and Dinah's
brothers—each take a sword. They enter the unsuspecting city and kill all the
males.

They kill Hamor and Shechem with the sword and take Dinah out of Shechem's house.
This is the chapter's first explicit location of Dinah in that house; the text
does not specify when or by what intermediate act she entered it.

That completes S036:

```text
JACOB SONS: CIRCUMCISE EVERY MALE
-> THEN WE INTERMARRY / DWELL / BECOME ONE PEOPLE
-> SOURCE ALREADY LABELS OFFER DECEIT
-> EVERY MALE COMPLIES
-> THIRD DAY SORENESS
-> SIMEON + LEVI KILL ALL MALES
```

It also completes S037:

```text
HAMOR + SHECHEM TO CITY: THESE MEN ARE PEACEFUL WITH US
-> CITY MEN ACCEPT CONDITION
-> SIMEON + LEVI ENTER UNSUSPECTING CITY
-> KILL ALL MALES
```

The one-people boil becomes a Joe-faced city gate wearing a friendship bracelet
made of tiny swords. The peaceful-men boil becomes a full Joe face stamped
`UNSUSPECTING / VERIFIED PEACEFUL`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes one boil, licks his empty finger and walks away. Then he notices the
second crack, turns without understanding anything, says only:

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the second boil, licks the same empty finger and leaves without looking
back. No death, rescue, property transfer or survival State changes because of
him.

Jacob's sons come upon the dead and plunder the city because their sister was
defiled. They take:

- flocks, herds and donkeys;
- property in city and field;
- all wealth;
- all little ones and wives as captives;
- everything in the houses as plunder.

The source assigns the broader plunder to `Jacob's sons` without listing each
son's exact act. Simeon and Levi are certainly the two named killers; the
manuscript does not automatically assign each later captive or object to them
individually.

## Genesis 34:30–31 — TROUBLED ME / OUR SISTER

> **JACOB / ISRAEL JOE TO SIMEON AND LEVI:** `YOU HAVE TROUBLED ME.`
>
> `YOU MADE ME ODIOUS TO THE CANAANITES AND PERIZZITES.`
>
> `I AM FEW IN NUMBER.`
>
> `THEY WILL GATHER, STRIKE ME AND DESTROY ME AND MY HOUSE.`

This is Jacob's stated present reputation and predicted retaliation chain. The
chapter does not record the Canaanites or Perizzites gathering or attacking.

> **SIMEON AND LEVI JOES:** `SHOULD HE DEAL WITH OUR SISTER AS WITH A
> PROSTITUTE?`

No interpretation, rebuttal or agreement follows. Dinah still receives no
recorded speech.

The reply stands after the source records Jacob's sons taking the city's wives
and little ones captive as plunder. This produces a personhood/property friction,
but exact later plunder actors are not isolated. It remains held rather than
being forced into an individually attributed series.

## Joe continuity revisions

- Dinah: goes to see daughters of land; is seen/taken/lain-with/violated by
  Shechem; receives source-reported kind speech; becomes object of father/brother
  wife negotiations without recorded speech; is later explicitly in Shechem's
  house; is taken out by Simeon/Levi. No consent, marriage, private response or
  route into the house is invented.
- Shechem: Hivite prince/son of Hamor; performs taking/lying/violation; receives
  source soul-joined/love/kind-speech States; asks Hamor for Dinah; offers
  unlimited requested dowry/gift; accepts circumcision condition without delay;
  pitches peaceful/property merger to city; is killed by Simeon/Levi.
- Hamor: receives son's request; negotiates with Jacob/family; offers
  intermarriage/land/trade/possessions; accepts deceptive condition; sells city
  on peaceful men and acquisition of Jacob property; is killed by Simeon/Levi.
- Jacob / Israel: hears Dinah defilement; waits silently for sons; receives Hamor
  talk; does not receive direct attributed negotiation speech; later confronts
  Simeon/Levi over odium, fewness and predicted destruction.
- Simeon and Levi: return grieved/angry within sons; participate in deceptive
  answer; on third day take swords, kill every male/Hamor/Shechem, and take Dinah
  from house; answer Jacob with sister/prostitute question.
- other Jacob sons: return grieved/angry; collectively make deceptive condition;
  collectively plunder city/dead and capture wives/little ones. Exact individual
  plunder acts remain unresolved.
- city-gate men/males: hear peaceful/property pitch; all listen; every male is
  circumcised; third-day men are sore; all males killed. Same faces do not merge
  victim identities or transfer Shechem's initial act to them.
- city wives/little ones: taken captive as plunder after male deaths; no speech,
  consent, individual kinship, destination or later State is supplied.
- daughters of land: people Dinah goes to see; no meeting details or speech are
  supplied.

## Crackheadverse garbage pass

- Shechem's love card -> `CRACKHEAD RELATIONSHIP ONBOARDING: ACT ALREADY DONE`;
- Dinah negotiations -> empty Joe-faced chair labelled `PERSON BEING DISCUSSED`;
- unlimited dowry -> `ASK WHATEVER / TERMS AND CONDITIONS: ENTIRE CITY`;
- circumcision condition -> `CRACKHEAD ONE-PEOPLE INSTALLER / RESTART DAY 3`;
- two sales pitches -> reversible brochure `YOU GET LAND / WE GET EVERYTHING`;
- city gate -> `CRACKHEAD CONSENT PORTAL: ALL USERS SELECTED`;
- peaceful badge -> Joe-faced green shield reading `UNSUSPECTING`;
- third-day attack -> fake warning `SYSTEM SORENESS IS NOT A SECURITY WINDOW`;
- rescue/plunder -> `DINAH EXTRACTED / ENTIRE CITY ADDED TO CART`;
- wives/little ones -> no joke labels over their captivity; their Joe identities
  remain visible and distinct from property icons;
- Jacob risk forecast -> `LOCAL REPUTATION: ODIOUS / HOUSE COUNT: FEW`;
- final reply -> speech bubble remains hanging with no narrator answer;
- barcode -> `CHB-GEN34-S034-S035-S036-S037-031-YOINK`.

## God-line boundary

Genesis 34 contains no direct God speech, divine messenger speech or
narrator-assigned divine act. `Folly in Israel` is a source social/moral label,
not God dialogue. No character invokes God in this chapter.

The manuscript adds no divine authorization for marriage, circumcision,
deception, killing, rescue, plunder, retaliation prediction or the final reply.

## FIR verification

- All 31 verse markers are covered in order.
- Dinah's going out is never converted into consent to any later act.
- taking, lying with, violation, source-reported love and kind speech remain in
  exact order.
- source-attributed soul/love/grief/anger/delight/honor are retained as source
  testimony, not facial inference.
- every marriage/dowry/condition exchange is addressed to fathers/brothers/city;
  no Dinah reply is invented.
- the source's explicit `with deceit` label precedes the circumcision proposal.
- S034, S035, S036 and S037 preserve distinct contradiction roots in one
  crossover occurrence.
- city-wide listening/circumcision precedes soreness and attack.
- Simeon/Levi are named killers; broader plunder remains assigned only as broadly
  as `Jacob's sons`.
- Dinah's Shechem-house location is not projected backward without evidence.
- wives/little ones remain captive Joes, never scenery or livestock.
- Jacob's retaliation/destruction chain remains a prediction, not completed
  attack.
- final sister/prostitute reply receives no invented verdict.
- held personhood/property friction is not falsely individualized.
- no direct God line, divine approval, consent, motive or legal framework is
  added.
- Captain says only `YOINK!`, remains boilless and changes nothing.
- Manuscript remains held and unpublished.

Continuation required: Genesis 35 receives God's Bethel command, foreign-god and
earring burial, divine terror/non-pursuit, altar naming, Deborah death/tree name,
God appearance/Israel renaming recurrence, nation/kings/land promises, pillar
drink/oil acts, Rachel labor/death/Ben-oni-to-Benjamin naming, tower placement,
Reuben/Bilhah act, twelve-son inventory, Isaac return/death/burial.
