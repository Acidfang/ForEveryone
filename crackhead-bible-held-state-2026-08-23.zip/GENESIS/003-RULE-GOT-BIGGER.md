# CRACKHEAD GENESIS 3

## Title page

**DON'T EAT IT BECOMES DON'T EVEN TOUCH IT**

Source parent: Genesis 3:1–24, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 3.

Parent manuscript: `GENESIS/002-DUST-JOE.md`.

CrackFlix crossover: `S006 — THE RULE GOT BIGGER`.

## Causal foundation

```text
GARDEN + TWO JOES + TREE BOUNDARY + NAKED/NO-SHAME
-> SUBTLE SERPENT JOE QUESTIONS BOUNDARY
-> WOMAN JOE RESTATES BOUNDARY WITH ADDED TOUCH CONDITION
-> SERPENT JOE DENIES STATED DEATH CONSEQUENCE
-> WOMAN JOE OBSERVES FOOD / APPEARANCE / WISDOM QUALITIES
-> WOMAN JOE EATS + GIVES -> HUMAN JOE EATS
-> EYES OPEN -> NAKEDNESS KNOWN -> COVERINGS MADE
-> GOD HEARD -> JOES HIDE
-> QUESTIONS -> ADMISSIONS + BLAME STATEMENTS
-> CONSEQUENCES ADDRESSED TO SERPENT / WOMAN / HUMAN
-> EVE NAMED
-> SKIN GARMENTS
-> ACCESS TO LIFE TREE PREVENTED
-> JOES EXPELLED -> GARDEN GUARDED
```

## Genesis 3:1 — SUBTLE SERPENT JOE

Subtle Serpent Joe has the universal Joe face on a serpent body. The source
introduces him as more subtle than other field animals.

> **SUBTLE SERPENT JOE:** `DID GOD SAY YOU CAN'T EAT FROM ANY TREE?`

His speech follows his origin: he selects the boundary and expands its scope
into a question. No hidden motive is supplied.

## Genesis 3:2–3 — THE RULE GOT BIGGER

Woman Joe answers from her received garden boundary.

> **WOMAN JOE:** `WE CAN EAT THE TREES.`
>
> `NOT THE ONE IN THE MIDDLE.`
>
> `GOD SAID DON'T EAT IT OR TOUCH IT OR WE DIE.`

Retained Difference:

```text
GENESIS 2 COMMAND: do not eat from the selected tree
GENESIS 3 REPORT: do not eat or touch its fruit
```

The comic does not invent who added `touch`, when it was added, or why. The
observable rule grew between retained statements.

CrackFlix creates `S006 — THE RULE GOT BIGGER`, episode `S006-E001 — DON'T
EVEN TOUCH IT`.

Captain, current across Books of Old, appears only after Woman Joe completes the
expanded report. He is boilless.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Woman Joe sees a suited nobody touch the new boil, lick an empty finger and
leave. Her conversation continues unchanged.

## Genesis 3:4–5 — TWO CONSEQUENCES ENTER

> **SUBTLE SERPENT JOE:** `YOU WON'T REALLY DIE.`
>
> `YOU'LL SEE DIFFERENT. YOU'LL KNOW GOOD AND EVIL LIKE GOD.`

God's retained statement and Serpent Joe's statement conflict. This chapter
retains both. It does not compress mortality, immediate physical death,
knowledge or later theology into one selected meaning before their downstream
states appear.

Candidate branch: `YOU WILL DIE / YOU WON'T REALLY DIE`. Series identity remains
unresolved pending downstream reconstruction.

## Genesis 3:6 — THEY EAT IT

Woman Joe observes that the tree is good for food, pleasant to the eyes and
desired for wisdom. She takes fruit and eats. She gives fruit to Human Joe, who
is with her, and he eats.

> **WOMAN JOE:** `LOOKS LIKE FOOD.`

> **HUMAN JOE:** `YOU ATE IT?`

> **WOMAN JOE:** `YEAH.`

Human Joe eats. No unrecorded persuasion speech is invented.

## Genesis 3:7 — CLOTHING BECOMES REQUIRED

Their eyes open. They know they are naked. They sew fig leaves into coverings.

Genesis 2 state:

```text
NAKED + NOT ASHAMED
```

Genesis 3 state:

```text
NAKEDNESS KNOWN -> FIG PPE CONSTRUCTED
```

Label: `CRACKHEAD FIG PERSONAL PRIVACY EQUIPMENT`.

This Moment creates the first clothing requirement in both character ledgers.

## Genesis 3:8–11 — WHERE ARE YOU?

Human Joe and Woman Joe hear God walking in Eatin' during the cool of the day.
They hide among the trees.

> **CRACKHEAD GOD:** `WHERE ARE YOU?`

Human Joe answers from his dust/garden/current-shame history.

> **HUMAN JOE:** `I HEARD YOU. I'M NAKED. I HID.`

> **CRACKHEAD GOD:** `WHO TOLD YOU THAT?`
>
> `DID YOU EAT THE ONE TREE?`

God's questions do not imply missing observation is filled by the narrator.

## Genesis 3:12–13 — INVOICE THE MANUFACTURER

> **HUMAN JOE:** `THE WOMAN YOU GAVE ME HANDED IT TO ME. I ATE IT.`

Human Joe names Woman Joe, God as giver, the handed fruit and his own eating.
The comic shows every part without deciding whether the sentence transfers
responsibility successfully.

> **CRACKHEAD GOD:** `WHAT DID YOU DO?`

> **WOMAN JOE:** `SERPENT JOE FOOLED ME. I ATE IT.`

Woman Joe names the serpent's act and her eating. Nobody retracts the act.

## Genesis 3:14–15 — SERPENT CONSEQUENCE

God addresses Subtle Serpent Joe: cursed relative to livestock and field
animals; belly travel; dust eaten; hostility between serpent and woman and
between their offspring; head and heel conflict.

> **CRACKHEAD GOD:** `BELLY. DUST. HOSTILITY. THAT'S YOUR CURRENT PACKAGE.`

The manuscript retains the source relations without importing later doctrinal
identifications into this chapter.

## Genesis 3:16 — WOMAN CONSEQUENCE

God addresses Woman Joe: multiplied pain in childbearing, desire toward husband,
and his rule over her.

The comic does not present these states as medical advice, approval, motive or
timeless instruction beyond the source statement. They enter her ledger as
addressed consequences.

## Genesis 3:17–19 — HUMAN CONSEQUENCE

God addresses Human Joe because he listened to his wife and ate from the tree
God prohibited:

- the ground is cursed for his sake;
- food comes through toil;
- thorns and thistles emerge;
- field plants become food;
- bread comes through facial sweat;
- Human Joe returns to the ground from which he was taken.

> **CRACKHEAD GOD:** `DUST JOE, MEET JOB SECURITY.`
>
> `YOU CAME FROM DUST. YOU'RE GOING BACK TO DUST.`

His garden-work clothing envelope changes to thorn-resistant, sweat-soaked field
workwear. Production may render it inconsistently; the new functions persist.

## Genesis 3:20–21 — EVE JOE AND SKIN CLOTHES

Human Joe names Woman Joe **Eve Joe** because she will be mother of all living.
The source identity `Eve` remains in the ledger.

God makes skin garments for both Joes and clothes them. The garments replace the
fig PPE as the current provided clothing state.

> **CRACKHEAD GOD:** `YOUR LEAF WARRANTY EXPIRED.`

## Genesis 3:22–24 — EVICTED FROM EATIN'

God states that Human Joe has become like one of the divine `us`, knowing good
and evil. God prevents him from reaching the tree of life, eating and living
forever.

Human Joe is sent out of Eatin' to till the ground from which he was taken. God
drives him out. Joe-faced cherubim and a flaming sword turning every direction
guard the eastern way to the tree of life.

Sign: `EATIN' — MEMBERSHIP CANCELLED. TREE OF LIFE ACCESS DENIED.`

No return occurs in this chapter.

## Character-ledger changes

### Human Joe

- ate prohibited fruit;
- nakedness became known;
- hid from God;
- named Woman Joe and God in his account, then admitted eating;
- received ground/toil/thorn/sweat/dust consequences;
- named Eve Joe;
- received skin clothes;
- expelled from Eatin';
- speech expands from garden naming into short factual admission plus causal
  attribution to the supplied person and supplier.

### Eve Joe

- first recorded speech restates the tree boundary with added `touch`;
- heard the serpent's opposing consequence;
- observed, took, ate and gave fruit;
- nakedness became known;
- constructed fig PPE;
- hid;
- named deception and admitted eating;
- received addressed childbirth/desire/rule consequences;
- received the name Eve and skin clothes;
- expelled from Eatin'.

### Subtle Serpent Joe

- questioned the food boundary;
- stated that death would not really occur;
- stated opened-eyes and godlike-knowledge outcomes;
- received belly/dust/hostility consequences.

## Fuck-up pass

- Eden -> Eatin' continues.
- Eve -> Eve Joe; no phonetic mutation selected because the source explicitly
  derives her name from living and that causal naming relation must stay visible.
- fig leaves -> Crackhead FIG PPE.
- naked / not ashamed -> nakedness-known clothing trigger; not reduced to a pun.
- serpent -> Subtle Serpent Joe; `Sir Pent` rejected because it obscured the
  retained animal identity in this manuscript.
- dust -> recurring Dust Joe return address.
- tree of life -> membership/access signage without changing the tree identity.

## FIR verification

- All 24 verse markers are covered.
- Genesis 2 supplies garden, characters, naked/no-shame state and tree boundary.
- The added `touch` condition is observed, not explained.
- Eating precedes opened eyes, shame-covering, hiding, questioning and
  consequences.
- Every admission retains the speaker's own stated act.
- Expulsion precedes guarding.
- Captain appears only after a completed textual contradiction and changes
  nothing.
- The death-claim conflict remains unresolved rather than falsely closed.
- Manuscript remains held and unpublished.

Continuation required: Genesis 4 receives expelled Human Joe and Eve Joe,
ground-work conditions, childbirth consequence, mortality boundary and current
clothing states.
