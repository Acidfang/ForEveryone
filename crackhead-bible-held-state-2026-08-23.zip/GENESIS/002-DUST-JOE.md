# CRACKHEAD GENESIS 2

## Title page

**DUST JOE GETS A JOB, A MENU, AND ANOTHER JOE**

Source parent: Genesis 2:1–25, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 2.

Parent manuscript: `GENESIS/001-BEGIN.md`.

## Causal foundation

```text
GENESIS 1 CREATION COMPLETE
-> SEVENTH DAY REST + BLESSING
-> EARTH WITHOUT CULTIVATING HUMAN
-> DUST + BREATH -> HUMAN JOE
-> GARDEN PLANTED -> HUMAN JOE PLACED THERE
-> RIVER -> FOUR HEADWATERS
-> HUMAN JOE ASSIGNED TO TEND + KEEP
-> FOOD PERMISSION + ONE PROHIBITION + STATED CONSEQUENCE
-> ALONENESS OBSERVED AS NOT GOOD
-> ANIMALS PRESENTED + NAMED
-> NO COMPARABLE HELPER FOUND
-> SLEEP -> RIB TAKEN -> WOMAN JOE MADE
-> WOMAN JOE BROUGHT TO HUMAN JOE
-> ONE-FLESH RELATION STATED
-> BOTH NAKED + NOT ASHAMED
```

## Genesis 2:1–3 — GOD CLOCKS OFF

The completed heavens, Crackhead Earth and their contents remain from Genesis 1.
God finishes the work by the seventh day, rests, blesses the day and makes it
holy.

> **CRACKHEAD GOD:** `DONE.`

Sign: `CRACKHEAD CREATION DEPARTMENT — NO OVERTIME AFTER EVERYTHING EXISTS.`

Rest changes no prior created state.

## Genesis 2:4–6 — BEFORE THE GARDEN SHIFT

The account selects the earth and heavens when created. No field shrub or herb
has yet grown in this selected ground account. Rain has not fallen and no human
exists to cultivate the ground. A mist rises and waters the surface.

The manuscript does not treat this selected description as deletion of Genesis
1. It retains Genesis 1 as parent and follows the source's new account boundary.

## Genesis 2:7 — DUST JOE

Crackhead God forms Human Joe from ground dust and breathes life into his
nostrils. Human Joe becomes living.

> **CRACKHEAD GOD:** `DUST.`
>
> `BREATH.`
>
> `JOE.`

Human Joe receives the authoritative Joe face only when he becomes living.

## Genesis 2:8–9 — EATIN'

God plants a garden eastward in **Eatin'**—source identity: Eden—and places
Human Joe there. Trees pleasant to sight and good for food grow. The tree of
life and the tree of knowledge of good and evil stand in the garden.

> **HUMAN JOE:** `THIS PLACE LOOKS EDIBLE.`

Literal wordplay is current scenery. The garden remains the source-identified
Eden location; `Eatin'` does not erase it.

## Genesis 2:10–14 — RIVER DEPARTMENT

One river flows out of Eatin' to water the garden, then divides into four.

First-manuscript display names:

| Source | Crackhead display | Current visual state |
|---|---|---|
| Pishon | Pishin' | the river keeps trying to sell the garden suspicious links |
| Gihon | Gee-Hon | the river greets every passing Joe |
| Tigris | Tiger-Is | the flowing medium contains far too many calm Joe-faced tigers |
| Euphrates | You-Freight-Ease | freight moves downstream with unreasonable ease |
| Havilah | Have-a-Laugh | gold and stones are displayed like joke-shop prizes |
| Cush | Kush | retained as source land identity with aggressively leafy signage |
| Assyria | A-Syria | retained source land address; no new causal property yet |

The source geography remains: Pishon surrounds Havilah; Gihon surrounds Cush;
Tigris runs east of Assyria; Euphrates is the fourth river. The jokes may alter
scenery but not those relations.

## Genesis 2:15 — FIRST JOB

God places Human Joe in Eatin' to cultivate and keep it.

> **CRACKHEAD GOD:** `HERE'S EVERYTHING. MAINTAIN IT.`

Human Joe's clothing derives its first function: dust-resistant garden workwear
with loops for whatever tool the next retained act requires.

## Genesis 2:16–17 — THE ENTIRE POLICY

God permits Human Joe to eat freely from every garden tree except the tree of
knowledge of good and evil. God states death as the consequence on the day of
eating from it.

> **CRACKHEAD GOD:** `ALL THE TREES.`
>
> `NOT THAT ONE.`
>
> `EAT THAT ONE, YOU DIE.`

The command, exception and consequence are retained before any breach. No motive
for the later act is invented here.

## Genesis 2:18 — ALONE JOE

God observes Human Joe alone.

> **CRACKHEAD GOD:** `NOT GOOD.`

God states that he will make a suitable helper.

This is the first `not good` observation in the manuscript lineage; it does not
retroactively cancel Genesis 1's assessment of the completed Whole.

## Genesis 2:19–20 — NAME EVERY JOE

God forms field animals and sky birds from the ground and brings them to Human
Joe to see what he will call them. Every living animal has Joe's face. Whatever
Human Joe calls each becomes its retained name.

> **HUMAN JOE:** `DOG JOE.`
>
> `BIRD JOE.`
>
> `VERY LONG DOG JOE.`
>
> `ANGRY POCKET JOE.`

Livestock, birds and field animals receive names. No suitable helper comparable
to Human Joe is found among them.

No zoological explanation is required. The names are current.

## Genesis 2:21–22 — RIB JOE

God causes Human Joe to sleep deeply. While he sleeps, God takes one rib and
closes the flesh. God makes Woman Joe from the retained rib and brings her to
Human Joe.

Medical label: `CRACKHEAD RIB TRANSFER — PATIENT CONSENT: ASLEEP.`

Captain is absent. This is a source act, not an observed completed social
contradiction in the selected passage.

## Genesis 2:23–24 — SAME MATERIAL

Human Joe observes Woman Joe.

> **HUMAN JOE:** `BONE OF MY BONE. FLESH OF MY FLESH.`
>
> `FINALLY, A JOE THAT ISN'T A DOG.`

The source naming relation—woman taken from man—is retained. The passage states
that a man leaves father and mother, joins his wife, and they become one flesh.

No later marriage history, doctrine or contradiction is imported into this
Moment. Those branches must route from their own passages.

## Genesis 2:25 — NO SHAME YET

Human Joe and Woman Joe are naked and not ashamed.

Their identical Joe faces remain genetically normal. Production may give Woman
Joe absurd girl-Joe presentation; it may not substitute another facial identity.

Warning: `CLOTHING SYSTEM NOT YET REQUIRED BY CURRENT STATE.`

## Character-ledger changes

### Human Joe

- origin parents: ground dust + divine breath;
- current location: Eatin';
- assigned work: cultivate and keep;
- retained command: all trees except one;
- mannerisms begun: names living creatures by immediate visible distinction;
- speech envelope: short immediate names, work objects, food boundaries and
  direct observations available inside Eatin'; no inherited family, historical
  or doctrinal vocabulary yet;
- clothing envelope: garden work function, though Genesis 2:25 retains naked
  state before clothing becomes required.

### Woman Joe

- origin parents: Human Joe's retained rib + God's making act;
- current location: Eatin';
- relationship: brought to Human Joe and addressed as same bone/flesh;
- speech envelope: source records no spoken line from her in Genesis 2; her next
  available words must derive from Eatin', Human Joe, the tree boundary as she
  received it, and the speaker addressing her;
- clothing envelope: none yet required.

## FIR verification

```text
FILTER: Genesis 2:1–25
ISOLATE: rest, selected ground account, Human Joe origin, garden assignment,
         command boundary, naming process, Woman Joe origin, final shared state
RECONSTRUCT: Genesis 1 completed Whole -> Genesis 2 selected human/garden chain
```

- All 25 verse markers are covered.
- Genesis 1 is retained rather than restarted.
- The four river relations remain source-correct beneath wordplay.
- The prohibited tree command precedes the later breach.
- No contradiction series is created before the contradiction actually occurs.
- No Captain, boil or clothing is inserted without a producing state.
- Manuscript remains held and unpublished.

## Fuck-up pass

- Eden -> Eatin'
- Pishon -> Pishin'
- Gihon -> Gee-Hon
- Tigris -> Tiger-Is
- Euphrates -> You-Freight-Ease
- Havilah -> Have-a-Laugh
- Cush -> Kush
- Assyria -> A-Syria
- `rested` was inspected; no mutation was selected because changing God's
  completed-work state would weaken the chapter chain.
- `rib` remains available for later manuscript revision; no forced joke replaces
  the source body-part relation in this version.

Continuation required: Genesis 3 receives the garden, both Joes, naked/no-shame
state, tree boundary and stated consequence as causal parents.
