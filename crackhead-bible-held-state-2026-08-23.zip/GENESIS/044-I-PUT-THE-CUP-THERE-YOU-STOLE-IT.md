# CRACKHEAD GENESIS 44

## Title page

**I PUT THE CUP THERE.**

**YOU STOLE IT.**

**I ASKED ABOUT YOUR FATHER. STILL DIDN'T.**

Source parent: Genesis 44:1–34, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 44.

Prepared evidence: `.chapter-work/CHB-GEN-044/job.json` and `source.usfm`.

Parent manuscript: `GENESIS/043-HE-ASKED-US-DIRECTLY-HE-DIDNT.md`.

CrackFlix routing:

- existing `S041 — WE MADE THIS. WE FOUND THIS.`, episode
  `S041-E002-GEN44 — THE CUP WE FOUND WHERE WE PUT IT`;
- existing `S052 — HE ASKED US DIRECTLY. HE DIDN'T.`, episode
  `S052-E002-GEN44 — JUDAH READS THE MISSING TRANSCRIPT AGAIN`.

## Causal foundation

```text
JOSEPH ORDERS FOOD + EACH PAYMENT PUT IN EACH SACK
-> JOSEPH ORDERS HIS SILVER CUP PUT IN BENJAMIN'S SACK
-> STEWARD PERFORMS THE ORDER
-> BROTHERS SENT AWAY WITH DONKEYS
-> JOSEPH ORDERS STEWARD TO PURSUE + ACCUSE EVIL-FOR-GOOD/CUP TAKING
-> STEWARD REPEATS SCRIPT
-> BROTHERS DENY / CITE RETURNED MONEY / OFFER HOLDER DEATH + GROUP SLAVERY
-> STEWARD REDUCES CONDITION TO HOLDER SLAVERY / OTHERS BLAMELESS
-> SEARCH RUNS OLDEST TO YOUNGEST
-> CUP FOUND WHERE STEWARD PUT IT: BENJAMIN'S SACK
-> BROTHERS TEAR CLOTHES / ALL RETURN
-> JOSEPH CALLS IT THEIR DEED + CLAIMS DIVINATION
-> JUDAH ATTRIBUTES FOUND INIQUITY TO GOD / OFFERS ALL AS SLAVES
-> JOSEPH SELECTS CUP HOLDER ONLY / ORDERS OTHERS HOME
-> JUDAH RETELLS FAMILY/AUDIENCE/RETURN CONDITION
-> JUDAH AGAIN SAYS JOSEPH ASKED FATHER/BROTHER QUESTIONS
-> RETAINED GENESIS 42 AUDIENCE STILL CONTAINS NO SUCH QUESTIONS
-> JUDAH RETAINS JACOB'S JOSEPH-DEATH BELIEF + BENJAMIN LOSS PREDICTION
-> JUDAH CITES HIS COLLATERAL GUARANTEE
-> JUDAH OFFERS HIMSELF AS SLAVE INSTEAD OF BENJAMIN
-> JOSEPH RESPONSE REMAINS FOR GENESIS 45
```

## Genesis 44:1–3 — THE EVIDENCE GOES IN

Joseph orders his steward to fill every sack with as much food as its carrier
can take and put each man's money at the sack mouth. He separately orders his
silver cup placed with Benjamin's grain money. The steward performs Joseph's
word. At morning light the brothers and Joe-faced donkeys are sent away.

The chapter directly identifies the cup-placement actor and instruction before
any accusation or search. Benjamin has no recorded access to or knowledge of
the cup.

## Genesis 44:4–6 — READ THIS ACCUSATION WHEN YOU CATCH THEM

Before the group is far from the city, Joseph orders the steward to pursue and
say they rewarded evil for good, took the drinking/divining cup and did evil.
The steward overtakes them and speaks those words.

This advances S041's retained manufactured-evidence chain. The first episode
used a goat-blood robe manufactured by brothers and presented as found. This
episode uses a cup planted by Joseph's steward and presented as taken.

A Joe-faced fly opens CrackFlix:

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

He presses `SKIP`; his eyes glaze. The world does not receive the request.

## Genesis 44:7–13 — SEARCHING TOWARD THE KNOWN ANSWER

The brothers deny the act and cite returning the earlier sack money from
Canaan. They ask how they would steal silver or gold and offer that the holder
die while all others become slaves.

The steward says it will be according to their words, then states a different
penalty boundary: the holder becomes his slave and the others are blameless.
The changed term is explicit before the search; death and group slavery are not
performed.

Everyone lowers and opens a sack. The steward searches from oldest to youngest,
ending at Benjamin. The cup is found exactly where the retained placement act
put it. The brothers tear their clothes, reload every donkey and all return to
the city.

Captain remains glazed through the denial, penalty revision, search, discovery
and return. `SKIP` changes none of them.

## Genesis 44:14–17 — THE PLANTER DIVINES THE PLACEMENT

Judah and his brothers fall before Joseph. Joseph asks what deed they have done
and says a man like him can indeed divine.

The retained chain supplies his actual information: Joseph selected Benjamin's
sack, selected his own cup, instructed placement, instructed pursuit and
scripted the accusation. No divination act is needed or narrated.

His evidence boil becomes a Joe-faced silver cup yelling `FOUND BY ADVANCED
CRACKHEAD DIVINATION` from inside a sack labelled `PUT HERE BY ORDER`.

Captain's eyes clear.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes, licks his empty finger, walks away and never looks back. Joseph's
custody process remains identical.

That completes S041-E002:

```text
JOSEPH SELECTS CUP + BENJAMIN SACK
-> STEWARD PLANTS CUP
-> JOSEPH SCRIPTS EVIL/TAKING ACCUSATION
-> STEWARD FINDS CUP AT SELECTED LOCATION
-> JOSEPH CALLS PLACEMENT RESULT THEIR DEED + INVOKES DIVINATION
```

Judah asks how they can clear themselves, says God found out their iniquity and
offers all as slaves. The God statement is Judah's attribution; `iniquity` is
not source-limited to cup theft. Joseph rejects group enslavement, selects the
cup holder as slave and tells the others to return peacefully to their father.

## Genesis 44:18–23 — THE QUESTIONS RETURN

Judah approaches and asks to speak without Joseph's anger because Joseph is as
Pharaoh. He says Joseph asked whether they had a father or brother. That repeats
S052's exact retained mismatch from Genesis 43.

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

Captain zones out again. Nothing skips.

Judah's account says they answered with an old father, youngest old-age child,
dead brother, only maternal son left and fatherly love. He recounts Joseph's
bring-him-down command, an answer that the boy could not leave because the
father would die, and Joseph's no-face-without-youngest condition.

Genesis 42 contains the brother inventory and Joseph's Benjamin condition. It
does not contain Joseph asking the father/brother questions or the brothers
saying the father would die if Benjamin left. The new details remain Judah's
current retelling; no missing prior dialogue is inserted into Genesis 42.

The question boil grows another Joe-faced transcript page. Captain's eyes clear.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes, licks, leaves. Judah's plea continues.

## Genesis 44:24–29 — WHAT JACOB SAID

Judah recounts returning to Jacob, reporting Joseph's words, receiving the next
food-purchase order and repeating the Benjamin condition. He then quotes Jacob:
one wife bore two sons; one left and was surely torn; Jacob has not seen him
since; taking the remaining one and suffering harm would bring his gray hairs
in sorrow to Sheol.

Joseph is alive and hearing his own death classification. Judah does not
recognize him. The chapter preserves Jacob's false conclusion through quoted
speech; it does not show Judah retracting it or learning Joseph's identity.

No separate crack is manufactured from ignorance alone. The causal source of
Jacob's belief remains the Genesis 37 manufactured robe episode already routed
through S041.

## Genesis 44:30–34 — THE COLLATERAL SPEAKS

Judah predicts that returning without Benjamin will kill Jacob because their
lives are bound, and assigns the resulting sorrow-to-Sheol act to the servants.
These are his future claims, not completed deaths.

He cites the exact collateral guarantee retained in Genesis 43 and asks to stay
as Joseph's slave instead of Benjamin, letting Benjamin leave with the brothers.
He asks how he can return without the boy and see the evil that would come on
his father.

The substitution request is spoken but not accepted in this chapter. Judah's
guarantee advances from promised accountability to an offered personal cost;
Benjamin remains selected for slavery at the chapter boundary.

## Joe continuity ledger

- Joseph remains unrecognized and is the explicit designer of cup placement,
  pursuit words and Benjamin selection.
- Joseph's steward performs the placement, scripted pursuit, ordered search and
  cup discovery; finding does not become independent evidence of stealing.
- Benjamin changes from honoured youngest diner to selected cup-holder slave,
  without a recorded taking act or speech.
- Judah advances his active collateral guarantee into a self-substitution offer.
- all brothers return with Benjamin rather than using Joseph's permission to
  abandon him; death/group-slavery offer is not performed.
- Jacob remains absent; his statements enter only through Judah's quoted report.
- every donkey is Joe-faced and returns to the city; sacks/cup/money are
  nonliving evidence.
- Captain stays permanently boilless and causally unnecessary.

## Bullshit pass

- banner: `ARTICLE 44 — CRACKHEAD CUSTOMS PRE-SEARCH RESULT SERVICE`;
- cup label: `PROPERTY OF JOSEPH / FOUND IN TARGET / AMAZING`;
- search form: `OLDEST TO YOUNGEST — DEFINITELY NO PRIOR KNOWLEDGE`;
- CrackFlix screen one: `S041 EPISODE 2 / SKIP / SEARCH CONTINUES`;
- divination certificate: `I KNEW THE THING I ORDERED`;
- CrackFlix screen two: `S052 EPISODE 2 / TRANSCRIPT STILL EMPTY`;
- slavery selector: `ALL OF US / NO ONLY HIM / TERMS UPDATED`;
- barcode: `CHB-GEN44-S041E002-S052E002-34-YOINK`;
- footer: `BIG BAG EVIDENCE — PACKED BEFORE DEPARTURE`.

## Reconstruction boundary

- all 34 verse markers are represented in order;
- S041 is reused because deliberate evidence placement precedes scripted
  accusation, search and blame; no theft motive or act is assigned to Benjamin;
- both SKIP presses occur only on exact retained series repetitions and neither
  changes the world;
- the brothers' death/group-slavery offer is narrowed before search and never
  performed;
- Judah's God/iniquity statement remains character attribution without a new
  divine act or a forced referent for iniquity;
- S052 is reused because Judah repeats the same unretained prior questions;
- quoted Jacob/Judah predictions do not become completed deaths;
- Judah's substitution remains requested, not accepted;
- Joseph disclosure and response are held for Genesis 45;
- publication remains held and unpublished.

Continuation required: Genesis 45 resolves Joseph's disclosure, the brothers'
response, Joseph's God-sending interpretation, Pharaoh's relocation offer and
Jacob's living-Joseph belief change.
