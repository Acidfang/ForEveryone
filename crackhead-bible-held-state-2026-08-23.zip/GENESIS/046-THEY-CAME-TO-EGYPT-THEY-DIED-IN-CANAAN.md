# CRACKHEAD GENESIS 46

## Title page

**THESE ARE THE PEOPLE WHO CAME TO EGYPT.**

**ER AND ONAN DIED IN CANAAN.**

Source parent: Genesis 46:1–34, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 46.

Prepared evidence: `.chapter-work/CHB-GEN-046/job.json` and `source.usfm`.

Parent manuscript: `GENESIS/045-YOU-SOLD-ME-IT-WASNT-YOU-GOD-SENT-ME.md`.

CrackFlix routing:

- existing `S032 — YOUR NAME IS NO LONGER JACOB. JACOB.`, episode
  `S032-E003-GEN46 — JACOB, JACOB, ROSE UP`;
- new `S053 — THEY CAME TO EGYPT. THEY DIED IN CANAAN.`, episode
  `S053-E001-GEN46 — THE PASSENGERS WHO NEVER LEFT`.

## Causal foundation

```text
ISRAEL TRAVELS WITH ALL / SACRIFICES AT BEERSHEBA
-> GOD SPEAKS IN NIGHT VISIONS: JACOB, JACOB
-> GOD IDENTIFIES SELF / COMMANDS NO FEAR / PROMISES EGYPT NATION
-> GOD PROMISES GO-DOWN / BRING-UP / JOSEPH CLOSE-EYES
-> NARRATOR: JACOB ROSE FROM BEERSHEBA
-> HOUSEHOLD / WAGONS / LIVESTOCK / GOODS ENTER EGYPT
-> SOURCE HEADS INVENTORY AS CHILDREN WHO CAME INTO EGYPT
-> NAMED DESCENDANT BRANCHES LISTED
-> JUDAH BRANCH INCLUDES ER AND ONAN
-> SAME VERSE: ER AND ONAN DIED IN CANAAN
-> BRANCH TOTALS: LEAH 33 / ZILPAH 16 / RACHEL 14 / BILHAH 7
-> DIRECT OFFSPRING WHO CAME WITH JACOB, EXCLUDING WIVES: 66
-> ADD JACOB + JOSEPH + TWO EGYPT-BORN SONS: HOUSE TOTAL 70
-> JUDAH SENT AHEAD / HOUSEHOLD REACHES GOSHEN
-> JOSEPH MEETS JACOB / WEEPS
-> JACOB STATES JOSEPH ALIVE AND PERMITS DEATH
-> JOSEPH PREPARES PHARAOH OCCUPATION REPORT/SCRIPT
-> SHEPHERD ABOMINATION RULE USED TO SEEK GOSHEN DWELLING
```

## Genesis 46:1–4 — JACOB, JACOB

Israel travels with all he has, reaches Beersheba and sacrifices to the God of
Isaac. God speaks to Israel in night visions:

> **CRACKHEAD GOD:** `JACOB, JACOB!`

Jacob answers. God identifies himself as the God of Jacob's father, commands
him not to fear Egypt, promises a great nation there, promises to go down and
bring him up again, and says Joseph's hand will close his eyes.

The old name is used twice after two retained no-longer-Jacob declarations.
A Joe-faced fly opens the retained series:

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

He presses `SKIP`; his eyes glaze. God finishes every promise. Nothing skips.

## Genesis 46:5–7 — JACOB ROSE UP

The next narrated act says Jacob rises from Beersheba. His sons carry Jacob,
their children and wives in Pharaoh's wagons. They take Canaan livestock/goods
and bring Jacob, sons, grandsons, daughters and granddaughters into Egypt.

Captain's eyes clear at the continued old-name label.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the rename boil, licks his empty finger, walks away and never looks
back. The migration remains unchanged.

## Genesis 46:8–15 — LEAH BRANCH: THIRTY-THREE

The source introduces the names as the children of Israel who came into Egypt,
Jacob and his sons. It lists Reuben and Hanoch, Pallu, Hezron, Carmi; Simeon and
Jemuel, Jamin, Ohad, Jachin, Zohar, Shaul; Levi and Gershon, Kohath, Merari;
Judah and Er, Onan, Shelah, Perez, Zerah, then Perez's sons Hezron and Hamul;
Issachar and Tola, Puvah, Iob, Shimron; Zebulun and Sered, Elon, Jahleel; and
Dinah. The stated Leah-branch total is thirty-three.

Inside that came-to-Egypt inventory the source says Er and Onan died in Canaan.
They therefore cannot perform the stated Egypt-entry act. That completes S053:

```text
HEADING: CHILDREN OF ISRAEL WHO CAME INTO EGYPT
-> ER + ONAN INCLUDED IN THE NAMED INVENTORY
-> SAME INVENTORY: ER + ONAN DIED IN CANAAN
-> NO RESURRECTION / TRANSPORT / SCOPE REMOVAL ACT RETAINED
```

The household manifest boil grows two Joe-faced passenger portraits stamped
`DECEASED BEFORE DEPARTURE` and `ARRIVED IN EGYPT`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain pokes, licks, leaves. The inventory continues counting without him.

## Genesis 46:16–25 — ZILPAH, RACHEL AND BILHAH BRANCHES

Zilpah's branch lists Gad with Ziphion, Haggi, Shuni, Ezbon, Eri, Arodi,
Areli; Asher with Imnah, Ishvah, Ishvi, Beriah and sister Serah; and Beriah's
sons Heber and Malchiel. The source states sixteen.

Rachel's branch lists Joseph and Benjamin; Joseph's Egypt-born sons Manasseh and
Ephraim through Asenath; and Benjamin's sons Bela, Becher, Ashbel, Gera, Naaman,
Ehi, Rosh, Muppim, Huppim and Ard. The source states fourteen.

Bilhah's branch lists Dan and Hushim; Naphtali and Jahzeel, Guni, Jezer,
Shillem. The source states seven.

Every named living person is a distinct Joe identity with the same face. Parent,
sibling, branch and location edges are retained; no personality, age, spouse,
birthplace or dialogue is supplied where absent.

## Genesis 46:26–27 — SIXTY-SIX IS NOT SEVENTY'S SCOPE

The source states sixty-six direct offspring came with Jacob into Egypt,
excluding sons' wives. It then names Joseph's two Egypt-born sons and states
the whole house coming into Egypt was seventy.

The scopes reconcile directly:

```text
66 = DIRECT OFFSPRING WHO CAME WITH JACOB, EXCLUDING SONS' WIVES
+ 1 JACOB
+ 1 JOSEPH ALREADY IN EGYPT
+ 2 JOSEPH SONS BORN IN EGYPT
= 70 HOUSE OF JACOB
```

No numerical crack is created. The dead-person inventory conflict remains
separate from the stated total arithmetic.

## Genesis 46:28–30 — THE REUNION

Jacob sends Judah ahead to Joseph to show the Goshen way. The household enters
Goshen. Joseph prepares his chariot, meets Israel, presents himself, falls on
his father's neck and weeps a good while.

Israel says he can now die because he has seen Joseph's face and Joseph is
alive. This performs Genesis 45's promised journey and meeting. It is not a
death act; Jacob remains alive at chapter end.

## Genesis 46:31–34 — SAY SHEPHERDS

Joseph tells brothers/household he will report their arrival and shepherd/livestock
work to Pharaoh. He predicts Pharaoh's occupation question and instructs them
to answer that they and their fathers have kept livestock from youth, so they
may dwell in Goshen because every shepherd is an abomination to Egyptians.

The report and answer remain planned speech until Pharaoh's audience. The
source presents the Egyptian shepherd rule and the Goshen strategy as aligned;
no contradiction is manufactured from an exclusion mechanism producing a
separate dwelling location.

## Complete lineage retained by this chapter

- Leah branch: Reuben -> Hanoch/Pallu/Hezron/Carmi; Simeon -> Jemuel/Jamin/Ohad/
  Jachin/Zohar/Shaul; Levi -> Gershon/Kohath/Merari; Judah -> Er/Onan/Shelah/
  Perez/Zerah, Perez -> Hezron/Hamul; Issachar -> Tola/Puvah/Iob/Shimron;
  Zebulun -> Sered/Elon/Jahleel; Dinah.
- Zilpah branch: Gad -> Ziphion/Haggi/Shuni/Ezbon/Eri/Arodi/Areli; Asher ->
  Imnah/Ishvah/Ishvi/Beriah/Serah, Beriah -> Heber/Malchiel.
- Rachel branch: Joseph -> Manasseh/Ephraim through Asenath; Benjamin -> Bela/
  Becher/Ashbel/Gera/Naaman/Ehi/Rosh/Muppim/Huppim/Ard.
- Bilhah branch: Dan -> Hushim; Naphtali -> Jahzeel/Guni/Jezer/Shillem.
- Er and Onan retain deceased-in-Canaan State; all other newly listed people
  retain only the source life/list relation unless a prior State exists.

## Bullshit pass

- banner: `ARTICLE 46 — CRACKHEAD IMMIGRATION HOUSEHOLD MANIFEST`;
- CrackFlix: `S032 EPISODE 3 / NAME UPDATE STILL BUFFERING`;
- passenger form: `ER — DIED IN CANAAN — ARRIVED YES`;
- count terminal: `66 + 4 = 70 / DO NOT SUBTRACT WIVES TWICE`;
- wagon label: `PHARAOH FAMILY TRANSPORT — ALL FACES IDENTICAL`;
- occupation card: `SHEPHERD / ABOMINATION / GOSHEN ELIGIBLE`;
- barcode: `CHB-GEN46-S032E003-S053E001-34-YOINK`;
- footer: `BIG BAG HOUSEHOLD — DEAD PASSENGERS DECLARED SEPARATELY`.

## FIR verification

- all 34 verse markers are represented in order;
- direct God speech and promises remain God-only;
- S032 reuses an exact old-name-after-no-longer-name occurrence; SKIP does
  nothing;
- S053 depends only on the came-to-Egypt heading plus explicit Canaan deaths;
- every named lineage is retained without same-face identity merging;
- 66 and 70 remain separate compatible scopes, not a forced contradiction;
- the Joseph/Jacob reunion closes the journey/meeting carry, not future death;
- Pharaoh dialogue remains predicted until performed;
- shepherd-abomination strategy and Goshen separation agree in this State;
- return-up promise, Joseph eye-closing, great-nation promise and later famine
  remain open;
- publication remains held and unpublished.

Continuation required: Genesis 47 performs the Pharaoh audience, Goshen land
grant, famine property transfers, fifth-rent rule and Jacob's burial request.
