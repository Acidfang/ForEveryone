# CRACKHEAD GENESIS 15

## Title page

**COUNT THE STARS. CUT THE ANIMALS. HERE'S THE FUTURE.**

Source parent: Genesis 15:1–21, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 15.

Parent manuscript: `GENESIS/014-FOUR-KINGS-FIVE-KINGS-318-JOES.md`.

CrackFlix crossover: none closed in this chapter.

## Causal foundation

```text
POST-RESCUE ABRAM + CHILDLESS STATE + LAND/OFFSPRING PROMISES
-> DIVINE VISION: FEAR NOT / SHIELD / REWARD
-> ABRAM OBJECTS: CHILDLESS + ELIEZER/HOUSE-BORN HEIR
-> GOD REJECTS ELIEZER HEIR -> OWN-BODY HEIR
-> STAR-COUNT DISPLAY -> OFFSPRING PROMISE
-> ABRAM BELIEVES -> RIGHTEOUSNESS CREDIT
-> GOD RESTATES UR-TO-LAND PURPOSE
-> ABRAM ASKS HOW HE WILL KNOW LAND INHERITANCE
-> ANIMAL REQUIREMENT -> DIVISION/ARRANGEMENT -> BIRDS UNDIVIDED
-> PREY BIRDS -> ABRAM DRIVES AWAY
-> SLEEP + TERROR + DARKNESS
-> FOREIGN/SERVICE/AFFLICTION PROPHECY + JUDGMENT/WEALTH/RETURN
-> SMOKING FURNACE + FLAMING TORCH PASS BETWEEN PIECES
-> COVENANT + RIVER/NATION LAND BOUNDARY
```

## Genesis 15:1 — SHIELD AND REWARD

After Genesis 14, God's word comes to Abram in a vision:

> **CRACKHEAD GOD:** `DON'T BE AFRAID.`
>
> `I'M YOUR SHIELD.`
>
> `I'M YOUR EXTREMELY LARGE REWARD.`

The source does not identify the feared object. `After these things` preserves
the war/rescue parent without inventing a psychological cause.

## Genesis 15:2–3 — WHAT ARE YOU GIVING A CHILDLESS JOE?

> **ABRAM JOE:** `WHAT WILL YOU GIVE ME? I STILL HAVE NO CHILD.`
>
> `ELIEZER OF DAMASCUS INHERITS MY ESTATE.`
>
> `YOU GAVE ME NO CHILD. A HOUSE-BORN JOE IS MY HEIR.`

Abram's words expose the unresolved difference between earlier offspring
promises and current childless State. This is not retrospective denial; both
remain observable and the promised future has not yet reached its completion
boundary.

Eliezer Joe becomes a named household identity. His parentage, age, role beyond
estate heir and speech remain unresolved.

## Genesis 15:4–6 — NOT THAT HEIR

> **CRACKHEAD GOD:** `THAT JOE IS NOT YOUR HEIR.`
>
> `ONE FROM YOUR OWN BODY IS YOUR HEIR.`

God brings Abram outside.

> **CRACKHEAD GOD:** `LOOK UP. COUNT THE STARS IF YOU CAN.`
>
> `THAT'S YOUR OFFSPRING.`

Abram believes God. God credits it to Abram as righteousness.

The chapter does not name the future child, identify the mother in this line or
complete a birth. `Own body` narrows the heir relation to Abram without filling
the remaining parent State.

Every star has Joe's face because production interpreted light as eyes. Abram
does not mention it.

## Genesis 15:7–8 — HOW WILL I KNOW?

> **CRACKHEAD GOD:** `I'M THE LORD WHO BROUGHT YOU FROM ERR OF THE CALL-DEEZ TO
> GIVE YOU THIS LAND.`

> **ABRAM JOE:** `HOW WILL I KNOW I'LL INHERIT IT?`

Abram's belief in verse 6 and his land-knowledge question in verse 8 are retained
as different addressed claims. The comic does not manufacture contradiction by
assuming belief forbids questions.

## Genesis 15:9–11 — CRACKHEAD COVENANT KIT

God requests:

- a three-year-old heifer;
- a three-year-old female goat;
- a three-year-old ram;
- a turtledove;
- a young pigeon.

Abram brings them. He divides the three mammals through the middle and places
halves opposite. He does not divide the birds.

Birds of prey descend on the carcasses. Abram drives them away.

No knife, altar, spoken explanation or animal-acquisition route is supplied.
Label: `CRACKHEAD COVENANT KIT — BIRDS SOLD SEPARATELY / DO NOT CUT`.

## Genesis 15:12–16 — DARK FUTURE LEDGER

At sunset, deep sleep falls on Abram; terror and great darkness fall on him.

God states:

- Abram's offspring will be foreigners in a land not theirs;
- they will serve that population and be afflicted 400 years;
- God will judge the serving nation;
- afterward the offspring will leave with great wealth;
- Abram will go to his fathers in peace and be buried at a good old age;
- the offspring will return in the fourth generation;
- Amorite iniquity is not yet full.

These are future ledger commitments. The foreign land and serving nation are
not named in this chapter, so later Egypt history must close that identity
rather than being silently imported now.

`400 years` and `fourth generation` are retained as their own source measures;
the manuscript does not invent a conversion formula.

## Genesis 15:17–21 — FURNACE, TORCH, BORDER

After sunset in darkness, a smoking furnace and flaming torch pass between the
animal pieces.

Anything with an interpreted face receives Joe's face: furnace door, flame and
torch all look like Joe. The source event remains unexplained beyond the
observable passage.

God makes a covenant with Abram and states the land grant to Abram's offspring:

```text
RIVER OF EGYPT
-> GREAT RIVER / YOU-FREIGHT-EASE
```

Included lands/peoples:

- Kenites;
- Kenizzites;
- Kadmonites;
- Hittites;
- Perizzites;
- Rephaim;
- Amorites;
- Canaanites;
- Girgashites;
- Jebusites.

The covenant statement does not erase those current peoples or claim Abram's
offspring has already occupied the land.

## Character and world-ledger changes

- Abram: receives vision; directly articulates childless/heir problem; hears
  own-body correction; believes; asks land-knowledge question; prepares divided
  animals; drives prey birds; experiences sleep/terror/darkness; receives future
  and land covenant.
- Eliezer: named Damascus/house-born estate-heir candidate, explicitly excluded
  from promised own-body heir identity.
- future offspring: gains foreigner/service/affliction/judgment/wealth/return
  history before birth; this is promised future State, not current experience.
- nation ledger: Egypt-river/Euphrates boundary and ten resident people names
  become covenant geography while present occupancy remains retained.

## Fuck-up pass

- Ur -> Err.
- Chaldees -> Call-Deez.
- Damascus -> Damn-Ask-Us.
- Eliezer -> E-Lazy-Er Joe on a broken estate form.
- stars -> `CRACKHEAD OFFSPRING COUNTING ARRAY`.
- Euphrates -> You-Freight-Ease.
- smoking furnace -> `CRACKHEAD MOBILE COVENANT FURNACE`.
- flaming torch -> Joe-faced `CRACKHEAD PASS-THROUGH AUTHENTICATOR`.

## FIR verification

- All 21 verse markers are covered in order.
- Current childlessness remains distinct from future offspring promise.
- Abram's heir assumption precedes God's explicit correction.
- Star demonstration precedes belief/righteousness statement.
- Belief and later land question remain separate claims, not forced friction.
- Requested animals precede division and the furnace/torch passage.
- Every age/class detail and undivided-bird exception is retained.
- Future foreign/service/affliction/judgment/wealth/return sequence remains in
  order and unresolved where unnamed.
- Covenant land boundary retains current peoples rather than erasing them.
- No contradiction series or Captain appearance is manufactured.
- Manuscript remains held and unpublished.

Continuation required: Genesis 16 receives Sarai's Hagar proposal, Abram's
agreement, conception/status conflict, harsh treatment/flight, divine messenger
promises and naming, Beer Lahai Roi, and Ishmael's birth when Abram is 86.
