# CRACKHEAD GENESIS 22

## Title page

**YOUR ONLY SON. THE OTHER ONE IS STILL ALIVE.**

Source parent: Genesis 22:1–24, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 22.

Parent manuscript: `GENESIS/021-HE-LAUGHS-SHE-LEAVES-SEVEN-SHEEP.md`.

CrackFlix: `S015 — YOUR ONLY SON. YOUR OTHER SON IS ALIVE.`, episode
`S015-E001-GEN22 — TAKE YOUR ONLY SON ISAAC`.

Content boundary: a father is commanded to kill and burn his son, binds him and
reaches for the knife before being stopped. The source actions remain explicit;
the production does not add wounds, graphic detail, consent, resistance or
internal reaction.

## Causal foundation

```text
SOURCE IDENTIFIES EVENT AS GOD TESTING ABRAHAM
-> GOD CALLS -> ABRAHAM ANSWERS
-> ISAAC CALLED ONLY SON DESPITE RETAINED LIVING SON ISHMAEL
-> MORIAH BURNT-OFFERING COMMAND
-> EARLY RISE / DONKEY / TWO YOUNG MEN / ISAAC / SPLIT WOOD
-> THREE-DAY TRAVEL -> PLACE SEEN
-> SERVANTS/DONKEY WAIT
-> ABRAHAM SAYS FATHER/SON WILL WORSHIP AND RETURN
-> WOOD ON ISAAC; FIRE/KNIFE WITH ABRAHAM
-> ISAAC ASKS FOR LAMB
-> ABRAHAM SAYS GOD WILL PROVIDE
-> PLACE REACHED -> ALTAR -> WOOD ORDERED -> ISAAC BOUND/PLACED
-> ABRAHAM REACHES FOR KNIFE TO KILL ISAAC
-> LORD'S ANGEL CALLS TWICE-NAMED ABRAHAM
-> DO-NOTHING-TO-BOY COMMAND
-> TEST RESULT STATED: FEARS GOD / DID NOT WITHHOLD SON
-> RAM OBSERVED CAUGHT BY HORNS
-> RAM TAKEN/OFFERED INSTEAD OF ISAAC
-> PLACE NAMED LORD-WILL-PROVIDE
-> SECOND ANGEL CALL
-> LORD SELF-OATH / BLESSING / MULTIPLICATION / ENEMY GATE / NATION BLESSING
-> ABRAHAM RETURNS TO YOUNG MEN -> BEERSHEBA
-> NAHOR HOUSEHOLD REPORT
-> MILCAH'S EIGHT SONS -> BETHUEL -> REBEKAH
-> REUMAH'S FOUR SONS
```

## Genesis 22:1–2 — THE TEST AND THE ONLY SON

The source first states that God tested Abraham.

> **CRACKHEAD GOD:** `ABRAHAM.`

> **ABRAHAM JOE:** `HERE I AM.`

> **CRACKHEAD GOD:** `TAKE YOUR SON, YOUR ONLY SON, ISAAC, WHOM YOU LOVE.`
>
> `GO TO MORIAH.`
>
> `OFFER HIM AS A BURNT OFFERING ON THE MOUNTAIN I WILL SHOW YOU.`

`Only son` does not cleanly agree with the retained lineage:

- Hagar bore Abraham's son Ishmael in Genesis 16;
- God called Ishmael Abraham's child in Genesis 21;
- Ishmael remained alive, grew, became an archer and received a wife;
- no death, disowning or deletion of the father/son relation is retained.

The source can preserve Isaac's distinct covenant line without deleting
Ishmael's son relation. S015 stores only the observable designation mismatch;
it does not invent which definition God secretly intended.

Crackhead God's impossibly prestigious boil displays the same Joe face as God,
Abraham, Isaac, Ishmael and the mountain permit office.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. God sees Captain or does not; the
source supplies no interaction. The command and Abraham's next action remain
identical.

## Genesis 22:3–5 — THREE DAYS TOWARD THE PLACE

Abraham rises early, saddles his donkey, takes two young men and Isaac, splits
burnt-offering wood and travels to the place God identified.

On the third day Abraham sees it far away.

> **ABRAHAM JOE:** `STAY HERE WITH THE DONKEY.`
>
> `THE BOY AND I WILL GO THERE, WORSHIP, AND COME BACK TO YOU.`

`We will come back` is Abraham's statement to the young men. The source does
not expose whether it is prediction, assurance, concealment or grammatical
habit. Later return does not authorize invented foreknowledge here.

The donkey has Joe's face and stays with the young men. No animal dialogue.

## Genesis 22:6–8 — WHERE IS THE LAMB?

Abraham puts the wood on Isaac. Abraham carries fire and knife. They walk
together.

> **ISAAC JOE:** `MY FATHER?`

> **ABRAHAM JOE:** `HERE I AM, MY SON.`

> **ISAAC JOE:** `HERE ARE THE FIRE AND WOOD.`
>
> `WHERE IS THE LAMB FOR THE BURNT OFFERING?`

> **ABRAHAM JOE:** `GOD WILL PROVIDE HIMSELF THE LAMB, MY SON.`

They continue together. Isaac's question establishes his missing lamb
information. No source line says when or whether he learns the original command
before being bound.

## Genesis 22:9–10 — ALTAR, BINDING, KNIFE

At the identified place Abraham:

- builds an altar;
- arranges the wood;
- binds Isaac;
- places Isaac on the altar and wood;
- reaches out and takes the knife to kill his son.

The command has advanced to its stated lethal boundary. Isaac's speech,
agreement, refusal, movement and physical condition are not supplied after his
lamb question. Production shows the ordered objects and interrupted hand, not
an injury that never occurs.

## Genesis 22:11–12 — STOP

The LORD's angel calls from the sky:

> **LORD'S ANGEL JOE:** `ABRAHAM! ABRAHAM!`

> **ABRAHAM JOE:** `HERE I AM.`

> **LORD'S ANGEL JOE:** `DO NOT LAY YOUR HAND ON THE BOY.`
>
> `DO NOT DO ANYTHING TO HIM.`
>
> `NOW I KNOW YOU FEAR GOD.`
>
> `YOU HAVE NOT WITHHELD YOUR SON, YOUR ONLY SON, FROM ME.`

The instruction changes after Abraham reaches for the knife. Verse 1 already
labels the sequence a test; verse 12 states the new test result. Therefore the
do-it/stop transition has an explicit State-change dependency and is not forced
into a contradiction series.

The `only son` designation repeats S015. Captain Crackhead is now a Joe-faced
fly beside his private CrackFlix ledger.

> **CAPTAIN CRACKHEAD FLY:** `SKIP.`

Glazed eyes. The world does not skip. Abraham still looks up, the ram still
appears, and every later line occurs.

## Genesis 22:13–14 — INSTEAD OF HIS SON

Abraham looks and sees a ram behind him, caught by its horns in a thicket. He
takes the ram and offers it as a burnt offering instead of Isaac.

The ram is a living Joe with the universal face. Its capture, death and offering
are retained source acts; no animal speech or painless euphemism is added.

Abraham names the place `The LORD Will Provide` / `the LORD Jireh` / `the LORD
Seeing`. The source retains the later saying: `On the LORD's mountain, it will
be provided.`

The substitution fulfills Abraham's earlier lamb-provision statement at the
offering grain, though the supplied animal is called a ram. The manuscript does
not erase that word difference.

## Genesis 22:15–18 — SECOND CALL AND SELF-OATH

The LORD's angel calls from the sky a second time and relays:

> **LORD'S ANGEL JOE:** `THE LORD SAYS: I HAVE SWORN BY MYSELF.`
>
> `BECAUSE YOU DID THIS AND DID NOT WITHHOLD YOUR SON, YOUR ONLY SON:`
>
> `I WILL GREATLY BLESS YOU.`
>
> `I WILL MULTIPLY YOUR OFFSPRING LIKE HEAVEN'S STARS AND SEASHORE SAND.`
>
> `YOUR OFFSPRING WILL POSSESS HIS ENEMIES' GATE.`
>
> `ALL EARTH'S NATIONS WILL BE BLESSED BY YOUR OFFSPRING.`
>
> `BECAUSE YOU OBEYED MY VOICE.`

The third `only son` occurrence remains in S015's same episode. It adds no new
son inventory and deletes no Ishmael State.

The blessing is renewed as future promise. Abraham's performed test action is
the source-stated `because`; the future populations and enemy gate remain open.

## Genesis 22:19 — RETURN TO BEERSHEBA

Abraham returns to the young men. They rise and travel together to Beersheba,
where Abraham lives.

The source does not explicitly include Isaac in the subject of verse 19, but
verse 12 stopped harm and later Isaac history continues. The manuscript does
not invent a separate return scene or claim Isaac was absent; exact travel
group wording remains as written.

## Genesis 22:20–24 — NAHOR'S FAMILY REPORT

Abraham receives a report that Milcah has borne eight sons to his brother Nahor:

1. Uz, firstborn;
2. Buz;
3. Kemuel, father of Aram;
4. Chesed;
5. Hazo;
6. Pildash;
7. Jidlaph;
8. Bethuel, who fathers Rebekah.

Nahor's concubine Reumah bears:

- Tebah;
- Gaham;
- Tahash;
- Maacah.

This is a received lineage report, not an observed simultaneous birth scene.
Each name becomes its own Joe identity. Birth order is supplied only for Uz as
firstborn and for the list structure where explicitly stated; ages, locations,
clothing, speech and most later histories remain unresolved.

Rebekah enters the retained family network here before her Genesis 24 meeting
with Abraham's servant. Later significance must not be imported into her
current no-speech lineage State.

## Character and world-ledger changes

- Abraham: receives/executes test command through knife boundary; states joint
  return and divine provision; binds Isaac; stops at angel call; substitutes
  ram; names provision place; receives renewed oath promise; returns to
  Beersheba; receives Nahor-family report.
- Isaac: called loved/only son despite Ishmael history; carries wood; asks lamb
  location; is bound and placed on altar; is not harmed after angel command.
- Ishmael: absent from scene but remains living son in retained lineage; this
  preserved State creates S015's friction.
- two young men: travel three days, wait with donkey, and return with Abraham;
  identities and reactions unresolved.
- donkey: transports journey equipment and waits with young men.
- ram: found horn-caught and offered instead of Isaac.
- LORD's angel: stops harm, states test result, repeats only-son designation and
  relays LORD's self-oath/offspring promises.
- Nahor/Milcah/Reumah branch: seventeen named identities enter or update the Joe
  inventory, including Rebekah.
- Moriah/provision place: gains altar/test/ram substitution/name history without
  modern coordinates being supplied.

## Fuck-up pass

- Moriah -> `MORE-EYE-AH`, a mountain with too many Joe-faced eyes.
- burnt offering -> `CRACKHEAD TEST BUILD / PRODUCTION ABORTED AT KNIFE GATE`.
- only son -> form field showing `1`, with Ishmael's live ledger attached behind it.
- ram -> `CRACKHEAD LAMB PROVIDER vRAM`, horns stuck in network thicket.
- LORD Will Provide -> `CRACKHEAD JUST-IN-TIME SACRIFICE SUPPLY`.
- stars and sand -> Joe-faced offspring-count arrays, both still uncounted.
- Nahor -> `NAH-OR JOE`; Milcah -> `MILK-CAR JOE`; Reumah -> `ROOM-AH JOE`.
- Rebekah -> `RE-BECKON JOE`, already beckoning from a future issue that has not happened.
- SKIP button -> shows `SKIPPED: 0 MOMENTS`.

## FIR verification

- All 24 verse markers are covered in order.
- Verse 1 test label precedes command and prevents invented motive.
- S015 depends on retained living Ishmael son/child State and explicit only-son
  wording; it does not depend on theological interpretation.
- Captain appears after the first designation mismatch, says only `YOINK!`, is
  boilless and changes nothing.
- Second only-son designation may trigger `SKIP` only because the first is
  already retained; nothing skips.
- Three-day travel, servant wait, wood/fire/knife distribution and lamb question
  remain before altar construction.
- Binding and knife reach precede stop command; no injury is invented.
- Test result explains the command transition, so no extra series is forced.
- Ram substitution and provision naming remain distinct States.
- Future oath promises are not treated as completed populations or possession.
- Every named Nahor-branch Joe receives an identity root without importing later
  life events.
- Manuscript remains held and unpublished.

Continuation required: Genesis 23 receives Sarah's death at 127, Abraham's
mourning, Heth negotiation, Ephron's field/cave offer, four-hundred-shekel
weighing, witnessed property transfer and Sarah's burial.
