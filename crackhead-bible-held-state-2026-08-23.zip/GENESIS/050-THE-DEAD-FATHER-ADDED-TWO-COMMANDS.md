# CRACKHEAD GENESIS 50

## Title page

**MY FATHER SAID HE DUG HIS OWN GRAVE.**

**ABRAHAM BOUGHT IT.**

**MY FATHER ALSO SAID FORGIVE US. AFTER HE DIED.**

Source parent: Genesis 50:1–26, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 50.

Prepared evidence: `.chapter-work/CHB-GEN-050/job.json` and `source.usfm`.

Parent manuscript:
`GENESIS/049-EXCELLING-YOU-SHALL-NOT-EXCEL-I-CURSED-YOU-ALL-BLESSED.md`.

CrackFlix routing:

- new `S060 — HE SAID IT BEFORE HE DIED. HE DIDN'T.`, episodes
  `S060-E001-GEN50 — JACOB DUG ABRAHAM'S PURCHASE` and
  `S060-E002-GEN50 — THE FORGIVENESS COMMAND ARRIVED AFTER DEATH`;
- existing `S022 — PEOPLE DID IT. GOD DID IT.`, episode
  `S022-E004-GEN50 — YOU MEANT EVIL, GOD MEANT GOOD`.

## Causal foundation

```text
JACOB DEAD
-> JOSEPH WEEPS/KISSES / ORDERS PHYSICIANS EMBALM
-> 40-DAY EMBALM / 70-DAY EGYPTIAN WEEPING
-> JOSEPH ASKS PHARAOH STAFF TO RELAY BURIAL REQUEST
-> JOSEPH REPORTS FATHER OATH + "GRAVE I DUG"
-> RETAINED COMMAND: MACHPELAH CAVE ABRAHAM BOUGHT
-> PHARAOH AUTHORIZES BURIAL
-> JOSEPH/BROTHERS/HOUSES/EGYPT ELDERS/SERVANTS/CHARIOTS/HORSEMEN TRAVEL
-> LITTLE ONES/FLOCKS/HERDS REMAIN GOSHEN
-> ATAD LAMENT / CANAANITES NAME ABEL MIZRAIM
-> SONS CARRY JACOB / BURY AT MACHPELAH
-> COMPANY RETURNS EGYPT
-> BROTHERS PREDICT JOSEPH HATE/PAYBACK
-> BROTHERS REPORT FATHER FORGIVENESS COMMAND
-> RETAINED FINAL CHARGE CONTAINS NO FORGIVENESS COMMAND
-> JOSEPH WEEPS / BROTHERS FALL / OFFER SERVICE
-> JOSEPH SAYS NOT GOD'S PLACE / NO FEAR
-> JOSEPH: YOU MEANT EVIL / GOD MEANT GOOD / MANY SAVED
-> JOSEPH PROMISES PROVISION / COMFORTS
-> JOSEPH LIVES 110 / SEES LATER DESCENDANTS
-> JOSEPH PREDICTS GOD VISIT+RETURN / REQUIRES BONES OATH
-> JOSEPH DIES / EMBALMED / COFFIN IN EGYPT
```

## Genesis 50:1–3 — EMBALM ISRAEL

Joseph falls on his father's face, weeps and kisses him. He commands physician
servants to embalm his father; they embalm Israel. Forty days are used for the
embalming, and Egyptians weep seventy days.

Jacob's death State continues. The source still does not narrate Joseph closing
Jacob's eyes, so that Genesis 46 promise relation remains unresolved rather than
filled with a probable off-panel act.

## Genesis 50:4–6 — THE GRAVE JACOB DUG

After the weeping days, Joseph asks Pharaoh's staff to relay his request. His
report quotes Jacob as saying:

> **REPORTED JACOB:** `BURY ME IN MY GRAVE WHICH I HAVE DUG FOR MYSELF IN CANAAN.`

The retained oath and final command say something else:

```text
GENESIS 47: BURIAL PLACE OF MY FATHERS
-> GENESIS 49: MACHPELAH FIELD/CAVE
-> ABRAHAM BOUGHT IT FROM EPHRON
-> ABRAHAM/SARAH + ISAAC/REBEKAH + LEAH BURIED THERE
-> GENESIS 50 REPORT: MY GRAVE WHICH I DUG FOR MYSELF
-> NO JACOB DIGGING ACT RETAINED
```

S060 begins. The burial permit grows a Joe-faced boil shaped like a shovel with
`PURCHASE RECEIPT: ABRAHAM` taped over `DUG BY: JACOB`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain pokes, licks, leaves. Pharaoh grants the request according to the oath.

## Genesis 50:7–14 — MACHPELAH BURIAL PERFORMED

Joseph goes to bury Jacob. Pharaoh's servants, house elders, all Egypt elders,
Joseph's house, brothers and father's house travel with him. Little ones, flocks
and herds remain in Goshen. Chariots and horsemen make a very great company.

At Atad beyond Jordan they perform severe lamentation for seven days.
Canaanite inhabitants see it, call it grievous Egyptian mourning and name the
place Abel Mizraim.

Jacob's sons then carry him into Canaan and bury him at Machpelah near Mamre,
the field/cave Abraham bought from Ephron. The burial command and Joseph oath
close. Joseph, brothers and the whole travelling company return to Egypt.

The Genesis 46 `bring you up again` outcome now has an observable matching
movement—Jacob is carried from Egypt to Canaan—but Genesis 50 does not assign
that movement's cause to God. Outcome correspondence is retained without
inventing divine operation.

## Genesis 50:15–18 — THE SECOND DEAD-FATHER COMMAND

After seeing their father dead, Joseph's brothers say Joseph may hate and repay
them for their evil. This is their stated possibility, not Joseph's observed
intent.

They send Joseph a message reporting that Jacob commanded before death:

> **REPORTED JACOB:** `PLEASE FORGIVE THE DISOBEDIENCE AND SIN OF YOUR BROTHERS.`

Genesis 49 retains the completed final gathering, all twelve sayings, burial
command, finished charge and death. It contains no forgiveness command.

Captain's CrackFlix displays:

`SKIP -> S060 / HE SAID IT BEFORE HE DIED. HE DIDN'T.`

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

He presses it. His eyes glaze. The message finishes. Joseph weeps. The brothers
come, fall before him and offer themselves as servants. Nothing skips.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the new command boil, licks his finger, walks away and never looks
back. No motive, lie, missing private meeting or forgotten command is invented.

## Genesis 50:19–21 — YOU MEANT EVIL / GOD MEANT GOOD

Joseph tells the brothers not to fear and asks whether he is in God's place. He
then says:

> **JOSEPH:** `YOU MEANT EVIL AGAINST ME, BUT GOD MEANT IT FOR GOOD.`

He connects the claimed good intent to saving many people alive as happening
that day, promises to provide for brothers and little ones, comforts them and
speaks kindly.

This is another S022 occurrence: human actors and their attributed intent are
retained, while Joseph assigns a different intent to God over the same result.
God does not speak or narratively claim that intent.

Captain's display points exactly to `S022-E004 / HUMAN EVIL -> GOD GOOD`.

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

His eyes glaze while Joseph completes the provision promise and comfort. The
world continues. When his eyes clear:

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes, licks and leaves. Joseph's interpretation remains Joseph's.

## Genesis 50:22–23 — ONE HUNDRED TEN

Joseph and his father's house live in Egypt. Joseph reaches 110. He sees
Ephraim's children to the third generation. Children of Machir son of Manasseh
are born on Joseph's knees.

Machir becomes a new named Joe identity with Manasseh parentage. Ephraim's
descendants remain generation-scoped but unnamed and unmerged.

## Genesis 50:24–26 — BONES IN A COFFIN

Joseph says he is dying and predicts that God will visit the family and bring
them from Egypt to the land sworn to Abraham, Isaac and Jacob. He makes the
children of Israel swear to carry his bones up when God visits.

The prediction and oath are established, not performed. Joseph dies at 110, is
embalmed and placed in a coffin in Egypt.

His living State changes to deceased. His body remains in Egypt. Exodus must
later supply any visit, departure and bone transport; Genesis does not.

## Character and world-ledger changes

- Jacob/Israel advances from deceased-unburied to embalmed and buried at
  Machpelah; Joseph eye-closing remains unobserved.
- Joseph performs Jacob's burial oath, rejects brother fear in speech, renews
  divine-intent attribution, provides for family, reaches 110 and dies embalmed
  in an Egyptian coffin.
- Joseph's brothers perform Jacob burial, send an unverified father-command
  report, bow/offer service and receive provision/comfort speech.
- Machir becomes a distinct named son of Manasseh; later descendants remain
  distinct but unnamed.
- physicians, Pharaoh staff/elders, Egyptian elders, Canaanite observers,
  chariot horses and retained Goshen animals remain separate Joe-faced groups.
- Abraham's Machpelah purchase lineage remains the burial title root.

## Bullshit pass

- banner: `ARTICLE 50 — CRACKHEAD POSTHUMOUS COMMAND UPDATE SERVICE`;
- grave form: `DUG BY JACOB / PURCHASED BY ABRAHAM / BOTH APPARENTLY`;
- CrackFlix: `S060 EPISODE 2 — DEAD DAD PATCH NOTES`;
- route map: `EGYPT -> ATAD -> MACH-PEEL-AH -> EGYPT`;
- mourning meter: `40 EMBALM / 70 WEEP / 7 MORE AT FLOOR`;
- intent receipt: `YOU: EVIL / GOD: GOOD / SOURCE: JOSEPH`;
- coffin label: `JOE-SEPH BONES — EXODUS PICKUP PENDING`;
- barcode: `CHB-GEN50-S060E001-E002-S022E004-26-YOINK`;
- footer: `BIG BAG OF GENESIS — CLOSED BOOK / OPEN BONES`.

## FIR verification

- all 26 verse markers are represented in order;
- Jacob embalming, procession and Machpelah burial are performed and close the
  retained oath/command;
- S060-E001 compares the reported dug grave to retained purchased cave lineage;
- S060-E002 compares the reported forgiveness command to the complete retained
  final charge without inventing an explanation;
- the second S060 occurrence and repeated S022 occurrence use addressed SKIP;
  SKIP omits explanation, causes nothing and world action continues;
- brother hate/payback remains their stated possibility, not Joseph motive;
- Joseph God-good-intent and future visit/return remain Joseph attribution and
  prediction, not God speech or narrator-assigned act;
- Machir and all descendant/person/animal groups retain distinct identities;
- Jacob is buried; Joseph is deceased/embalmed/coffined in Egypt;
- Joseph bone oath remains open for Exodus;
- publication remains held and unpublished.

Continuation required: Exodus 1 reconstructs the retained Israel-son entry
list, Joseph-generation deaths, population growth, new Pharaoh, forced labour,
midwife commands and Nile death order.
