# CRACKHEAD GENESIS 25

## Title page

**I'M ABOUT TO DIE.**

**EATS. DRINKS. GETS UP. LEAVES.**

Source parent: Genesis 25:1–34, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 25.

Parent manuscript: `GENESIS/024-WE-CANT-SPEAK-BAD-OR-GOOD-TAKE-HER.md`.

CrackFlix: `S018 — I'M ABOUT TO DIE. ANYWAY, I'M OFF.`, episode
`S018-E001-GEN25 — THE TERMINAL LENTIL CONDITION`.

## Causal foundation

```text
ABRAHAM TAKES KETURAH AS WIFE
-> SIX SONS -> NAMED DESCENDANT BRANCHES
-> ALL ABRAHAM HAS GIVEN TO ISAAC
-> GIFTS TO CONCUBINES' SONS
-> THOSE SONS SENT EAST AWAY FROM ISAAC WHILE ABRAHAM LIVES
-> ABRAHAM DIES AT 175
-> ISAAC + ISHMAEL BURY HIM WITH SARAH AT PURCHASED MACHPELAH
-> GOD BLESSES ISAAC / ISAAC LIVES BY BEER LAHAI ROI
-> ISHMAEL'S TWELVE-SON / PRINCE / TERRITORY HISTORY
-> ISHMAEL DIES AT 137
-> ISAAC MARRIED REBEKAH AT 40
-> REBEKAH BARREN
-> ISAAC ENTreats LORD
-> LORD ENTREated / REBEKAH CONCEIVES
-> CHILDREN STRUGGLE / REBEKAH INQUIRES
-> LORD: TWO NATIONS / ELDER SERVES YOUNGER
-> TWINS BORN WHEN ISAAC 60
-> ESAU FIRST, RED + HAIRY
-> JACOB SECOND, HOLDING ESAU'S HEEL
-> BOYS GROW INTO DISTINCT ROLES
-> PARENTS' DISTINCT LOVE RELATIONS RECORDED
-> JACOB BOILS STEW
-> ESAU RETURNS FAMISHED / REQUESTS RED STEW
-> JACOB REQUIRES BIRTHRIGHT SALE
-> ESAU: ABOUT TO DIE / BIRTHRIGHT USELESS
-> JACOB REQUIRES OATH
-> ESAU SWEARS / SELLS BIRTHRIGHT
-> JACOB GIVES BREAD + LENTIL STEW
-> ESAU EATS + DRINKS + RISES + WALKS AWAY
-> SOURCE: ESAU DESPISED BIRTHRIGHT
```

## Genesis 25:1–4 — KETURAH'S BRANCH

Abraham takes another wife, Keturah. She bears Zimran, Jokshan, Medan, Midian,
Ishbak and Shuah.

Jokshan fathers Sheba and Dedan. Dedan's sons are Asshurim, Letushim and
Leummim. Midian's sons are Ephah, Epher, Hanoch, Abida and Eldaah. The source
collectively calls these Keturah's children.

Each named living descendant is a distinct Joe identity with the same Joe face.
Shared face does not merge parents, generations, names or histories.

No conception timing, birth order except the written list order, mothers of the
grandchildren, dialogue, locations, occupations or later national identities
are imported.

## Genesis 25:5–6 — ALL TO ISAAC; GIFTS AND EASTWARD SEPARATION

Abraham gives all he has to Isaac. He gives gifts to the sons of his concubines
and, while still alive, sends them eastward to the east country, away from
Isaac.

```text
ISAAC -> ALL ABRAHAM HAS
CONCUBINES' SONS -> GIFTS + EASTWARD SENDING AWAY FROM ISAAC
```

The source uses `wife` for Keturah in verse 1 and plural `concubines` in verse
6. This chapter does not explicitly map every concubine or every affected son.
The ledger therefore retains the property actions without silently declaring
which named branch exhausts that plural class.

## Genesis 25:7–11 — ABRAHAM'S LIFE CLOSES AT 175

Abraham lives 175 years. He gives up his spirit, dies at a good old age, is old
and full of years, and is gathered to his people.

Isaac and Ishmael bury their father in Machpelah cave, in Ephron son of Zohar's
field near Mamre—the field Abraham purchased from Heth's children. Abraham is
buried with Sarah.

The burial reuses the paid property State from Genesis 23. No new sale, gift,
title transfer or S016 episode occurs.

After Abraham's death, God blesses Isaac. Isaac lives by Beer Lahai Roi.

No final Abraham words, illness, bedside witnesses, estate inventory, funeral
dialogue or meaning of `gathered to his people` is supplied.

## Genesis 25:12–18 — ISHMAEL'S TWELVE PRINCES AND DEATH

The source reaffirms Ishmael as Abraham's son, born to Abraham by Hagar the
Egyptian, Sarah's servant.

His sons are listed in birth order:

1. Nebaioth;
2. Kedar;
3. Adbeel;
4. Mibsam;
5. Mishma;
6. Dumah;
7. Massa;
8. Hadad;
9. Tema;
10. Jetur;
11. Naphish;
12. Kedemah.

Their villages and encampments carry their names, and they are twelve princes
according to their nations. The source does not name their mother here or map
each settlement boundary separately.

Ishmael lives 137 years, gives up his spirit, dies, and is gathered to his
people. His descendant population lives from Havilah to Shur before Egypt on
the Assyria route. The final clause records him living/settling opposite his
relatives; it does not supply a battle or emotion.

## Genesis 25:19–23 — ONE PRAYER, TWO NATIONS

Isaac is Abraham's son. He was forty when he took Rebekah—Bethuel the Syrian's
daughter from Paddan Aram and Laban the Syrian's sister—as wife.

Rebekah is barren. Isaac entreats the LORD for her. The LORD is entreated by
him, and Rebekah conceives. Prayer, divine response and conception retain the
source causal relation without an invented biological scene.

The children struggle together within Rebekah.

> **REBEKAH JOE:** `IF IT IS LIKE THIS, WHY DO I LIVE?`

She goes to inquire of the LORD.

> **CRACKHEAD GOD:** `TWO NATIONS ARE IN YOUR WOMB.`
>
> `TWO PEOPLES WILL BE SEPARATED FROM YOUR BODY.`
>
> `ONE PEOPLE WILL BE STRONGER THAN THE OTHER.`
>
> `THE ELDER WILL SERVE THE YOUNGER.`

The line is God-only because the source directly assigns it to the LORD. It
does not identify a shrine, messenger, audible mechanism, witness or Rebekah's
reply. Nation, strength and service outcomes remain future at this Moment.

## Genesis 25:24–28 — ESAU AND JACOB BECOME DISTINCT JOES

At completed delivery time, twins are present.

The first emerges red all over like a hairy garment and is named Esau. The
second emerges holding Esau's heel and is named Jacob. Isaac is sixty when
Rebekah bears them. Therefore twenty years are retained between Isaac's age at
marriage and his age at the twins' birth; the chapter does not divide that
interval into unrecorded events.

The boys grow. Esau becomes a skillful hunter and man of the field. Jacob
becomes a quiet man living in tents.

The source records that Isaac loves Esau because he eats Esau's venison, while
Rebekah loves Jacob. These are source-attributed relations, not conclusions
drawn from the parents' faces. No claim that either parent does not love the
other son is added.

## Genesis 25:29–31 — THE PRICE IS THE BIRTHRIGHT

Jacob boils stew. Esau comes in from the field famished.

> **ESAU JOE:** `PLEASE FEED ME SOME OF THAT RED STEW.`
>
> `I AM FAMISHED.`

The source connects this red request with the name Edom. `Edom` is retained as
an Esau-associated name, not materialized as a second Joe standing beside him.

> **JACOB JOE:** `FIRST, SELL ME YOUR BIRTHRIGHT.`

The offer is explicit. Food has not yet been transferred and the birthright has
not yet been sold.

## Genesis 25:32–34 — THE TERMINAL LENTIL CONDITION

> **ESAU JOE:** `I AM ABOUT TO DIE.`
>
> `WHAT GOOD IS THE BIRTHRIGHT TO ME?`

> **JACOB JOE:** `SWEAR TO ME FIRST.`

Esau swears. He sells his birthright to Jacob. Jacob gives him bread and lentil
stew. Esau eats and drinks.

Then Esau rises and walks away.

That departure completes S018:

```text
ESAU: I AM ABOUT TO DIE
-> BIRTHRIGHT SOLD UNDER OATH ON THAT STATED BOUNDARY
-> BREAD + STEW RECEIVED
-> ESAU EATS + DRINKS
-> ESAU RISES
-> ESAU WALKS AWAY
```

No medical estimate, exaggeration, secret intention or later lifespan is needed.
The retained imminent-death statement and the immediate able-to-rise-and-leave
State do not cleanly agree.

Esau's field-hunter transaction boil grows a tiny red bowl with Joe's face.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. Esau's birthright remains sold,
Jacob remains its recipient, and Esau has already gone his way. This is S018's
first episode, so there is no `SKIP`.

After the actions, the source states that Esau despised his birthright. This
attribution is retained as source narration. The fly does not replace it with a
facial-expression panel or invent when the internal valuation began.

## Character and world-ledger changes

- Abraham: takes Keturah; fathers six named sons; gives all to Isaac; gives
  gifts/sends concubines' sons east; dies at 175; buried with Sarah.
- Keturah and descendants: seventeen new named Joe identities (Keturah plus
  sixteen descendants) across three
  retained generations; unprovided mothers and later mappings remain unresolved.
- Isaac: receives all; buries Abraham with Ishmael; receives God's blessing;
  lives by Beer Lahai Roi; entreats for Rebekah; becomes father of twins at 60;
  source records love for Esau linked to venison.
- Ishmael: joins Abraham's burial; twelve sons/princes and territorial relation
  retained; dies at 137.
- Ishmael's sons: twelve distinct Joe identities in stated birth order with
  village/encampment/prince/nation relations.
- Rebekah: barren then conceives following Isaac's entreaty/divine response;
  experiences twin struggle; speaks/inquires; receives God-only two-nation line;
  bears twins; source records love for Jacob.
- Esau: first twin; red/hairy; field hunter; venison relation; famished stew
  request; birthright oath/sale; eats/drinks/rises/leaves; Edom name relation.
- Jacob: second twin holding heel; quiet/tent dweller; boils stew; demands sale
  and oath; gives bread/stew; receives birthright.
- Ephron/Zohar/Heth property history: referenced as Abraham's paid Machpelah
  burial place; ownership origin is not replayed or changed.

## Fuck-up pass

- Keturah -> `KETTLE-RAH JOE`, arriving with a boiling genealogy kettle.
- descendants -> `DESCENT-DENTS`, every generation leaves a Joe-faced dent.
- eastward to the east -> `EAST²`, an arrow pointing east twice.
- gathered to his people -> a literal crowd collecting Abraham in a Big Bag.
- twelve princes -> `CRACKHEAD PRINCE MULTIPACK / VILLAGES SOLD SEPARATELY`.
- Beer Lahai Roi -> a beer labelled `LA-HI, ROY` beside Isaac's house.
- Paddan Aram -> `PAD-AN-A-RAM`, a writing pad strapped to a Joe-faced ram.
- twins -> `SAME FACE / DIFFERENT JOE / DO NOT DEDUP`.
- Esau -> `HE-SORE JOE`, covered in red hairy warning labels.
- Jacob -> `JAY-CUP JOE`, cooking stew in a letter-J cup.
- Edom -> `EAT-'EM`, printed on the red stew bowl.
- lentils -> tiny Joe-faced contact lenses labelled `LENT-LENS`.
- birthright receipt -> `ONE FUTURE POSITION / PAID IN FULL: SOUP`.
- imminent-death alarm -> `STATUS: WALKED AWAY`.

## God-line boundary

Genesis 25 narrates God's blessing of Isaac, records the LORD being entreated so
Rebekah conceives, and directly assigns the two-nation/two-people/strength/
elder-serves-younger speech to the LORD. Only that direct speech enters God-only
dialogue. Abraham's death, Ishmael's death, the birthright transaction and the
source's `despised` conclusion receive no invented divine comment.

## FIR verification

- All 34 verse markers are covered in order.
- Every named Keturah descendant and Ishmael son is a separate Joe identity.
- `wife` and plural `concubines` are retained without unsupported total mapping.
- All-to-Isaac, gifts and eastward sending remain distinct property acts.
- Abraham's age/death/burial follows his living property acts.
- Machpelah's prior paid-title lineage remains linked without replaying S016.
- Ishmael's genealogy, territory and death do not erase his burial act.
- Isaac age 40 at marriage and 60 at twin birth are both retained.
- Rebekah's barrenness, Isaac's entreaty, divine response and conception remain
  source-linked without invented mechanics.
- Direct LORD speech remains God-only and future outcomes stay open.
- Esau/Edom is one Joe identity; same universal face does not merge either twin.
- The birthright transfers only after demand, stated condition, oath and sale.
- S018 completes only when Esau rises and walks away after saying he is about to
  die, selling, eating and drinking.
- Source-attributed `despised` is not presented as fly-derived mind-reading.
- Captain appears after the contradiction, says only `YOINK!`, is boilless and
  changes no outcome.
- No `SKIP`, unrelated series, invisible motive or later-life evidence is added.
- Manuscript remains held and unpublished.

Continuation required: Genesis 26 receives famine, Gerar wife-as-sister repeat,
Abimelech's observation, protection order, wells stopped/reopened/disputed,
prosperity, divine appearance/oath, Beersheba covenant and Esau's Hittite wives.
