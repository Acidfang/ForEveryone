# CRACKHEAD GENESIS 27

## Title page

**THE VOICE IS JACOB'S.**

**THE HANDS ARE ESAU'S.**

**ARE YOU REALLY ESAU?**

**I AM.**

Source parent: Genesis 27:1–46, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 27.

Parent manuscript: `GENESIS/026-THE-TRUTH-CAME-WITH-A-DEATH-PENALTY.md`.

Primary CrackFlix: `S021 — THE CHECK FOUND BOTH ANSWERS. PICK ONE.`, episode
`S021-E001-GEN27 — THE VOICE IS JACOB; THE HANDS ARE ESAU`.

Routed CrackFlix:

- `S022 — GOD DID IT. MUM DID IT.`, episode `S022-E001-GEN27 — QUICK VENISON`;
- `S012 — I DID IT. YOUR FAULT.`, episode
  `S012-E002-GEN27 — HE TOOK THE BIRTHRIGHT I SOLD HIM`.

## Causal foundation

```text
ISAAC OLD / DIM EYES / CANNOT SEE
-> CALLS ELDER SON ESAU
-> REQUESTS HUNTED VENISON + SAVORY FOOD
-> INTENDS SOUL-BLESSING BEFORE UNKNOWN DEATH DAY
-> REBEKAH HEARS / ESAU LEAVES TO HUNT
-> REBEKAH RETELLS + COMMANDS JACOB
-> TWO YOUNG GOATS -> REBEKAH COOKS FOOD ISAAC LOVES
-> ESAU CLOTHES + GOAT SKINS PLACED ON JACOB
-> JACOB CARRIES FOOD/BREAD TO ISAAC
-> JACOB CLAIMS ESAU FIRSTBORN IDENTITY
-> JACOB CLAIMS LORD-GIVEN QUICK SUCCESS
-> ISAAC TESTS BY TOUCH
-> ISAAC: VOICE JACOB / HANDS ESAU
-> JACOB AGAIN CLAIMS ESAU IDENTITY
-> ISAAC EATS / DRINKS / SMELLS CLOTHING
-> ISAAC BLESSES JACOB UNDER ESAU IDENTITY
-> JACOB LEAVES / ESAU ARRIVES
-> ESAU IDENTIFIES HIMSELF
-> ISAAC DISCOVERS PRIOR RECIPIENT / RETAINS BLESSING
-> ESAU CRIES / REQUESTS BLESSING
-> ISAAC: BROTHER DECEITFULLY TOOK BLESSING
-> ESAU: JACOB TOOK BIRTHRIGHT + BLESSING
-> RETAINED PRIOR: ESAU SWORE / SOLD BIRTHRIGHT
-> ISAAC GIVES ESAU DISTINCT SWORD/SERVICE/BREAK-LOOSE BLESSING
-> SOURCE ATTRIBUTES ESAU HATRED
-> ESAU HEART-SPEECH: AFTER ISAAC MOURNING, KILL JACOB
-> ESAU WORDS REPORTED TO REBEKAH
-> REBEKAH ORDERS JACOB FLEE TO LABAN UNTIL ANGER TURNS
-> REBEKAH TELLS ISAAC LIFE-WEARINESS / HETHITE-WIFE CONCERN
-> DEPARTURE ACTION/DECLARED ISAAC REASON REMAINS GENESIS 28 FRONTIER
```

## Genesis 27:1–4 — VENISON BEFORE THE BLESSING

Isaac is old. His eyes are dim so he cannot see. The source does not give his
age here or say blindness is complete beyond `could not see`.

> **ISAAC JOE:** `MY SON?`

> **ESAU JOE:** `HERE I AM.`

> **ISAAC JOE:** `I AM OLD. I DON'T KNOW THE DAY OF MY DEATH.`
>
> `TAKE YOUR QUIVER AND BOW. HUNT VENISON.`
>
> `MAKE THE SAVORY FOOD I LOVE.`
>
> `BRING IT SO I MAY EAT AND MY SOUL MAY BLESS YOU BEFORE I DIE.`

The requested dependency is explicit: Esau hunts, Esau prepares, Isaac eats,
then Isaac blesses. Isaac does not say he is dying that day.

## Genesis 27:5–10 — REBEKAH HEARS AND REASSIGNS THE TASK

Rebekah hears Isaac speaking to Esau. Esau goes hunting.

> **REBEKAH JOE:** `I HEARD YOUR FATHER TELL ESAU TO BRING VENISON AND FOOD`
> `SO HE COULD BLESS HIM BEFORE THE LORD BEFORE DEATH.`
>
> `OBEY MY COMMAND.`
>
> `GET TWO GOOD YOUNG GOATS.`
>
> `I WILL MAKE THE FOOD YOUR FATHER LOVES.`
>
> `YOU WILL TAKE IT TO HIM SO HE BLESSES YOU BEFORE HIS DEATH.`

Her retelling adds `before the LORD`; that wording was not present in Isaac's
direct verse-4 speech. It is retained as Rebekah's report, not silently inserted
into Isaac's earlier line.

## Genesis 27:11–17 — CLOTHES, SKINS, FOOD

> **JACOB JOE:** `ESAU IS HAIRY. I AM SMOOTH.`
>
> `WHAT IF FATHER TOUCHES ME?`
>
> `I WILL SEEM A DECEIVER AND BRING A CURSE, NOT A BLESSING.`

> **REBEKAH JOE:** `LET YOUR CURSE BE ON ME.`
>
> `OBEY ME. GET THE GOATS.`

Jacob gets two young goats and brings them to Rebekah. She makes the savory
food Isaac loves. She takes Esau's good clothes from the house and puts them on
Jacob. She places the young-goat skins on Jacob's hands and smooth neck, then
puts food and bread in his hand.

The two goats begin as living Joe-faced goats and end represented by prepared
food and skins. The source does not narrate the killing act, so the ledger does
not assign who kills them or draw an invented slaughter panel.

## Genesis 27:18–20 — ESAU IDENTITY; GOD CREDIT

> **JACOB JOE:** `MY FATHER?`

> **ISAAC JOE:** `HERE I AM. WHO ARE YOU, MY SON?`

> **JACOB JOE:** `I AM ESAU YOUR FIRSTBORN.`
>
> `I HAVE DONE WHAT YOU ASKED.`
>
> `SIT AND EAT MY VENISON SO YOUR SOUL MAY BLESS ME.`

> **ISAAC JOE:** `HOW DID YOU FIND IT SO QUICKLY?`

> **JACOB JOE:** `THE LORD YOUR GOD GAVE ME SUCCESS.`

That answer completes S022 against the retained production chain:

```text
OBSERVED: REBEKAH DIRECTS GOATS / COOKS / DRESSES JACOB / HANDS HIM FOOD
JACOB REPORTS: I DID WHAT YOU ASKED / LORD GAVE ME QUICK SUCCESS
ISAAC'S REQUESTED ACT: ESAU HUNTS VENISON
```

No direct LORD act or speech occurs in the chapter. Jacob's attribution does not
become God-ledger fact merely because he says it.

Jacob's success-attribution boil grows a tiny Joe-faced divine receipt stamped
`GOATS SUPPLIED LOCALLY`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. Isaac still begins the identity test.

## Genesis 27:21–24 — THE CHECK RETURNS BOTH SONS

> **ISAAC JOE:** `COME NEAR SO I MAY FEEL YOU.`
>
> `I WILL CHECK WHETHER YOU ARE REALLY ESAU.`

Isaac feels Jacob.

> **ISAAC JOE:** `THE VOICE IS JACOB'S VOICE.`
>
> `THE HANDS ARE ESAU'S HANDS.`

The check has not produced one clean identity. Isaac does not recognize Jacob
because the hands are hairy like Esau's, and he moves toward blessing.

> **ISAAC JOE:** `ARE YOU REALLY MY SON ESAU?`

> **JACOB JOE:** `I AM.`

That answer plus the retained conflicting check completes S021. Isaac's own
test establishes both identities; the process accepts the asserted Esau branch
without resolving Jacob's voice.

The identity-verification boil becomes the full Joe face, which is useless
because every living participant already has that face.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. The food, wine, kiss, smell and
blessing still proceed.

## Genesis 27:25–29 — JACOB RECEIVES THE BLESSING

Jacob brings the food. Isaac eats. Jacob brings wine. Isaac drinks. Isaac asks
for a kiss. Jacob kisses him. Isaac smells Esau's clothing and blesses the son
before him as a LORD-blessed-field smell.

The blessing asks or declares:

- dew of sky, earth's fatness, grain and new wine;
- peoples' service and nations' bowing;
- lordship over brothers and service from mother's sons;
- curse on cursers and blessing on blessers.

These are Isaac's blessing words, not direct God speech and not all completed
States at the moment spoken.

## Genesis 27:30–35 — ESAU ARRIVES ONE MOMENT LATE

As soon as Isaac finishes and Jacob has just left, Esau returns, makes savory
food and brings it in.

> **ESAU JOE:** `ARISE AND EAT YOUR SON'S VENISON SO YOUR SOUL MAY BLESS ME.`

> **ISAAC JOE:** `WHO ARE YOU?`

> **ESAU JOE:** `I AM YOUR SON, YOUR FIRSTBORN, ESAU.`

Isaac trembles violently.

> **ISAAC JOE:** `WHO BROUGHT ME VENISON BEFORE YOU?`
>
> `I ATE IT ALL AND BLESSED HIM.`
>
> `YES, HE WILL BE BLESSED.`

Esau gives an exceedingly great and bitter cry.

> **ESAU JOE:** `BLESS ME TOO, MY FATHER.`

> **ISAAC JOE:** `YOUR BROTHER CAME WITH DECEIT AND TOOK YOUR BLESSING.`

Discovery does not retract the blessing. Isaac explicitly retains it.

## Genesis 27:36–38 — THE BIRTHRIGHT HE SOLD

> **ESAU JOE:** `HE HAS SUPPLANTED ME TWICE.`
>
> `HE TOOK AWAY MY BIRTHRIGHT.`
>
> `NOW HE HAS TAKEN MY BLESSING.`
>
> `HAVEN'T YOU RESERVED A BLESSING FOR ME?`

The blessing claim follows the completed identity deception. The birthright
claim has a different retained parent:

```text
GENESIS 25: JACOB SAYS SELL / ESAU SAYS ABOUT-TO-DIE
-> JACOB REQUIRES OATH
-> ESAU SWEARS
-> ESAU SELLS BIRTHRIGHT
GENESIS 27: ESAU SAYS JACOB TOOK BIRTHRIGHT AWAY
```

This exactly repeats S012's `I DID IT. YOUR FAULT.` root.

> **CAPTAIN CRACKHEAD FLY:** `SKIP.`

Glazed eyes. Nothing skips. Isaac still lists what his first blessing assigned.

> **ISAAC JOE:** `I MADE HIM YOUR LORD.`
>
> `I GAVE HIS BROTHERS TO HIM AS SERVANTS.`
>
> `I SUSTAINED HIM WITH GRAIN AND WINE.`
>
> `WHAT CAN I DO FOR YOU?`

> **ESAU JOE:** `DO YOU HAVE ONLY ONE BLESSING?`
>
> `BLESS ME TOO.`

Esau lifts his voice and weeps. S012 remains complete despite Captain's absent
attention.

Esau's retained-transaction boil displays a Joe-faced birthright receipt with
his oath printed on it.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. Isaac answers Esau.

## Genesis 27:39–40 — ESAU'S DISTINCT BLESSING

Isaac gives Esau a distinct blessing:

- dwelling related to earth's fatness and sky's dew;
- life by the sword;
- service to his brother;
- a future break-loose State that shakes the yoke from his neck.

The exact relation of `fatness` wording across translations remains rooted in
this ENGWEBP source. This blessing does not revoke Jacob's retained blessing.

## Genesis 27:41–45 — KILL STATEMENT AND FLIGHT COMMAND

The source attributes Esau's hatred to Jacob's blessing and records Esau saying
in his heart:

> **ESAU JOE, SOURCE-ATTRIBUTED HEART SPEECH:** `AFTER THE DAYS OF MOURNING FOR`
> `MY FATHER, I WILL KILL JACOB.`

The words are then reported to Rebekah. The source does not identify the
reporter or mechanism, so an unresolved reporting carrier is retained without
inventing overheard public speech.

> **REBEKAH JOE:** `ESAU COMFORTS HIMSELF BY PLANNING TO KILL YOU.`
>
> `FLEE TO MY BROTHER LABAN IN HARAN.`
>
> `STAY A FEW DAYS UNTIL HIS FURY AND ANGER TURN AWAY.`
>
> `WHEN HE FORGETS WHAT YOU DID, I WILL SEND FOR YOU.`
>
> `WHY SHOULD I LOSE YOU BOTH IN ONE DAY?`

This is Rebekah's stated reason and selected destination for Jacob's flight. No
departure occurs yet in this chapter.

## Genesis 27:46 — A SECOND STATED PROBLEM, ACTION STILL OPEN

Rebekah tells Isaac:

> **REBEKAH JOE:** `I AM WEARY OF MY LIFE BECAUSE OF THE DAUGHTERS OF HETH.`
>
> `IF JACOB MARRIES A DAUGHTER OF HETH LIKE THESE, WHAT GOOD WILL MY LIFE BE?`

This references the Hittite-wife grief State from Genesis 26. It does not mention
Esau's kill statement or Laban flight plan.

The two stated problems are retained without collapsing them:

```text
TO JACOB: FLEE TO LABAN BECAUSE ESAU PLANS TO KILL YOU
TO ISAAC: LIFE-WEARINESS IF JACOB TAKES HETHITE WIFE
```

Genesis 27 stops before Isaac selects, states or performs a sending action.
Therefore no contradiction episode is closed here. Genesis 28 must supply the
next State before the relation can be routed.

## Character and world-ledger changes

- Isaac: old/dim-eyed; commissions Esau's venison; receives disguised Jacob;
  records conflicting voice/hands evidence; accepts repeated Esau claim; eats,
  drinks, smells and blesses; discovers deception; retains Jacob's blessing;
  gives Esau distinct sword/service/break-loose blessing.
- Rebekah: overhears; retells with bounded wording difference; commands goats;
  cooks/dresses Jacob; accepts proposed curse; receives kill-plan report; orders
  Laban flight; separately states Hethite-wife life-weariness to Isaac.
- Jacob: follows preparation; claims Esau identity twice; attributes quick
  success to LORD; receives first blessing; leaves before Esau arrives.
- Esau: hunts/prepares; arrives after blessing; identifies himself; cries/weeps;
  requests blessing; says Jacob took sold birthright; receives distinct blessing;
  source attributes hatred and heart-spoken kill plan.
- two young goats: living Joe-faced animals obtained from flock; later food and
  skins used in deception; unshown killing actor remains unresolved.
- unresolved reporter: carries Esau's source-attributed words to Rebekah; no
  identity, hearing route or dialogue is invented.
- Laban/Haran: named destination through Rebekah's retained sibling relation;
  Laban does not act or speak in this chapter.

## Fuck-up pass

- dim eyes -> `IDENTITY SCANNER: AUDIO CONFLICT / HAIR PASS`.
- quiver -> visibly shivering arrow container labelled `QUIVERING`.
- savory food -> `CRACKHEAD SOUL-BLESSING ACTIVATION MEAL`.
- two young goats -> Joe-faced interns issued `TEMPORARY VENISON` badges.
- goat skins -> `ESAU HAND EMULATORS / VOICE DRIVER NOT INSTALLED`.
- firstborn -> `FIRST-BORN LOGIN`, accepting Jacob's password `I AM`.
- kiss/smell test -> `MULTI-FACTOR AUTHENTICATION / FACTORS DISAGREE`.
- dew and fatness -> cans marked `SKY DEW` and `EARTH FAT`.
- exceedingly bitter cry -> a Joe-faced lemon shouting from a loudspeaker.
- one blessing -> `CRACKHEAD LICENCE: SINGLE USE / SECOND TIER AVAILABLE`.
- birthright receipt -> `SOLD BY ESAU / REPORTED STOLEN BY JACOB`.
- a few days -> calendar extending into unexplained continuity.
- daughters of Heth -> `HEALTH DAUGHTERS`, issuing Hittite marriage warnings.
- Haran -> `HAIR-RUN`, destination arrow made of goat hair.

## God-line boundary

No God or divine messenger appears, acts or speaks directly in Genesis 27.
Jacob attributes quick success to `the LORD your God`; Rebekah reports blessing
`before the LORD`; Isaac invokes LORD/God in blessing. All remain character
speech. No Genesis 27 God-line record is invented.

## FIR verification

- All 46 verse markers are covered in order.
- Isaac's unknown death day is not changed into immediate death.
- Rebekah's overhearing precedes command, preparation and disguise.
- Her retelling's added `before the LORD` wording remains report-specific.
- Jacob's curse concern and Rebekah's curse-acceptance words are retained without
  inventing a transferred curse.
- S022 closes against the actual goat/cooking/disguise chain, not an invented
  God act.
- S021 closes only after Isaac states both identity signals and Jacob repeats
  the Esau claim.
- Touch, voice, food, wine, kiss and smell remain separate evidence/actions.
- Jacob's blessing completes before he leaves and Esau enters.
- Isaac explicitly retains Jacob's blessing after discovery.
- S012 links Esau's prior sworn sale to his later took-away claim; blessing and
  birthright claims are not falsely merged.
- `SKIP` is allowed by retained S012 and changes nothing.
- Esau's second blessing remains distinct and does not revoke the first.
- Heart speech, hatred and Rebekah life-weariness remain source attributions,
  not fly-inferred facial States.
- The unidentified reporter remains unresolved.
- Rebekah's kill-flight and Hethite-wife statements remain distinct; no episode
  closes before Genesis 28 supplies departure.
- Captain appears after completed contradictions, says only `YOINK!`, is
  boilless and changes nothing.
- No direct God line, divine validation, hidden motive or premature departure is
  invented.
- Manuscript remains held and unpublished.

Continuation required: Genesis 28 receives Isaac's explicit Paddan Aram wife
command and sending, Jacob's departure, Esau's observation and Ishmael-line
marriage, Bethel dream/stairway, direct God promise, stone/pillar/oil act and
Jacob's conditional vow.
