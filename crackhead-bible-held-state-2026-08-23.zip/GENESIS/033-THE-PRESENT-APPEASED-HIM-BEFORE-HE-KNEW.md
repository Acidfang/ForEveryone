# CRACKHEAD GENESIS 33

## Title page

**I WILL APPEASE HIM WITH THE PRESENT.**

**ESAU RAN, EMBRACED, KISSED AND WEPT.**

**WHAT IS ALL THIS COMPANY?**

**I HAVE ENOUGH. KEEP IT.**

Source parent: Genesis 33:1–20, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 33.

Parent manuscript:
`GENESIS/032-YOUR-NAME-IS-NO-LONGER-JACOB-JACOB-LIMPED.md`.

CrackFlix:

- `S033 — I APPEASED HIM WITH THE PRESENT HE HADN'T IDENTIFIED.`, episode
  `S033-E001-GEN32-33 — THE HUG ARRIVED BEFORE THE INVOICE`.

Held candidate, not yet a closed series:

- Jacob says he will proceed gently until he comes to Esau at Seir. Esau returns
  to Seir; Jacob travels to Succoth, builds a house/shelters, then comes to
  Shechem. The Seir statement remains open until later source States determine
  whether the promised arrival ever occurs.

## Causal foundation

```text
GEN32 JACOB: PRESENT WILL APPEASE ESAU / PERHAPS ACCEPT ME
-> STAGED PRESENT PASSES AHEAD
-> ESAU APPROACHES WITH FOUR HUNDRED MEN
-> JACOB ORDERS CHILD GROUPS FRONT / MIDDLE / REAR
-> JACOB PASSES IN FRONT / BOWS SEVEN TIMES
-> ESAU RUNS / EMBRACES / FALLS ON NECK / KISSES
-> JACOB + ESAU WEEP
-> ESAU ASKS WHO WOMEN + CHILDREN ARE
-> JACOB ATTRIBUTES CHILDREN TO GOD
-> SERVANT GROUPS / LEAH GROUP / RACHEL-JOSEPH GROUP BOW
-> ESAU ASKS MEANING OF COMPANY HE MET
-> JACOB: TO FIND FAVOR
-> ESAU: I HAVE ENOUGH / KEEP YOURS
-> JACOB URGES PRESENT / FACE-OF-GOD + PLEASED + GRACE + ENOUGH SPEECH
-> ESAU TAKES PRESENT
-> ESAU PROPOSES SHARED JOURNEY / LEADING
-> JACOB CITES TENDER CHILDREN + YOUNG ANIMALS / OVERDRIVE DEATH
-> JACOB: GO AHEAD / I WILL COME TO SEIR
-> ESAU OFFERS SOME PEOPLE / JACOB DECLINES THROUGH FAVOR QUESTION
-> ESAU RETURNS TO SEIR
-> JACOB TRAVELS TO SUCCOTH
-> JACOB BUILDS HOUSE + LIVESTOCK SHELTERS / PLACE NAMED SUCCOTH
-> JACOB COMES IN PEACE TO SHECHEM / CAMPS BEFORE CITY
-> JACOB BUYS TENT-GROUND FROM HAMOR CHILDREN FOR 100 PIECES
-> JACOB ERECTS/NAMES ALTAR EL ELOHE ISRAEL
```

## Genesis 33:1–3 — FRONT, MIDDLE, REAR

Jacob looks and sees Esau coming with four hundred men. The messenger report
from Genesis 32 is now directly observed as an approach. No weapon, attack order
or peaceful statement has yet been supplied.

Jacob divides the children among Leah, Rachel and the two female servants. He
orders the groups:

1. the servants and their children in front;
2. Leah and her children after them;
3. Rachel and Joseph at the rear.

The order is observable. The manuscript does not name Jacob's motive, rank the
women's worth or infer which company from Genesis 32 contains each group.

Jacob himself passes in front of them. He bows to the ground seven times while
approaching Esau.

## Genesis 33:4–7 — RUN, EMBRACE, KISS, WEEP

Esau runs to meet Jacob, embraces him, falls on his neck and kisses him. They
weep. Both Joes have the same face and remain distinct brothers.

No narrator statement says the staged present caused these acts. Esau has not
yet asked what the animal company means.

Esau sees the women and children:

> **ESAU JOE:** `WHO ARE THESE WITH YOU?`
>
> **JACOB / ISRAEL JOE:** `THE CHILDREN GOD GRACIOUSLY GAVE YOUR SERVANT.`

Jacob's divine attribution remains his speech. It is not new direct God speech.

The servant women and their children approach and bow. Leah and her children
approach and bow. Joseph and Rachel approach and bow. The source reverses the
rear pair's name order from `Rachel and Joseph` to `Joseph ... with Rachel`;
this does not create a new group or change their identities.

## Genesis 33:8–11 — THE HUG BEFORE THE INVOICE

Only after the embrace, kiss, weeping, family question and bows does Esau ask:

> **ESAU JOE:** `WHAT DO YOU MEAN BY ALL THIS COMPANY I MET?`
>
> **JACOB / ISRAEL JOE:** `TO FIND FAVOR IN THE SIGHT OF MY LORD.`
>
> **ESAU JOE:** `I HAVE ENOUGH, MY BROTHER.`
>
> `LET WHAT YOU HAVE BE YOURS.`

Genesis 32 gave Jacob's stated mechanism:

> `I WILL APPEASE HIM WITH THE PRESENT THAT GOES BEFORE ME.`
>
> `PERHAPS HE WILL ACCEPT ME.`

The observed acceptance acts occur before Esau identifies the company as a
present, and Esau initially refuses the property after learning its purpose.

Jacob continues:

> **JACOB / ISRAEL JOE:** `PLEASE, NO.`
>
> `IF I FOUND FAVOR, RECEIVE MY PRESENT.`
>
> `I SAW YOUR FACE AS ONE SEES THE FACE OF GOD, AND YOU WERE PLEASED WITH ME.`
>
> `TAKE MY GIFT.`
>
> `GOD DEALT GRACIOUSLY WITH ME, AND I HAVE ENOUGH.`

Jacob urges Esau. Esau takes the present. The final property transfer occurs,
but it follows the embrace and Esau's initial refusal rather than producing the
first observed favorable response.

That completes S033:

```text
JACOB: PRESENT WILL APPEASE ESAU / PERHAPS ACCEPT ME
-> ESAU RUNS / EMBRACES / KISSES / WEEPS
-> ESAU HAS NOT IDENTIFIED THE PRESENT
-> ESAU ASKS WHAT THE COMPANY MEANS
-> JACOB SAYS IT IS FOR FAVOR
-> ESAU: I HAVE ENOUGH / KEEP IT
-> JACOB URGES
-> ESAU FINALLY TAKES IT
```

Jacob's successful-present boil becomes Esau's full Joe face hugging a receipt
stamped `ACCEPTED BEFORE ITEM DESCRIPTION`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Everyone sees a completely boilless suited nobody poke the boil, lick his empty
finger, walk away and never look back. The embrace, refusal, urging and eventual
gift transfer remain identical.

## Genesis 33:12–16 — I'LL COME TO YOU AT SEIR

> **ESAU JOE:** `LET'S TAKE OUR JOURNEY.`
>
> `I WILL GO BEFORE YOU.`

Jacob responds:

> **JACOB / ISRAEL JOE:** `THE CHILDREN ARE TENDER.`
>
> `THE FLOCKS AND HERDS HAVE THEIR YOUNG.`
>
> `IF THEY OVERDRIVE THEM ONE DAY, ALL THE FLOCKS WILL DIE.`
>
> `LET MY LORD PASS BEFORE HIS SERVANT.`
>
> `I WILL LEAD GENTLY AT THE PACE OF THE LIVESTOCK AND CHILDREN UNTIL I COME TO
> MY LORD AT SEIR.`

Tenderness, young-animal condition and one-day overdrive death are Jacob's
speech. The source does not record an overdrive test.

> **ESAU JOE:** `LET ME LEAVE SOME OF MY PEOPLE WITH YOU.`
>
> **JACOB / ISRAEL JOE:** `WHY?`
>
> `LET ME FIND FAVOR IN MY LORD'S SIGHT.`

Esau returns that day toward Seir. No retained people are explicitly left with
Jacob.

Jacob's stated Seir arrival has not yet occurred. The following place States
are Succoth and Shechem, but the source does not say `Jacob will never go to
Seir`. Therefore the statement remains an open route claim, not a completed
CrackFlix episode in this chapter.

## Genesis 33:17 — HOUSE AND BOOTHS AT SUCCOTH

Jacob travels to Succoth. He builds a house for himself and shelters for his
livestock. The place is called Succoth; the source footnote says `Succoth` means
`shelters` or `booths`.

The source gives real construction acts, not merely a stop name. House and
shelters establish a built State while the promised Seir arrival remains open.
No duration of residence is supplied.

## Genesis 33:18–20 — PEACE, PURCHASE, ALTAR

Jacob comes in peace to the city of Shechem in Canaan after coming from Paddan
Aram. He camps before the city.

He buys the parcel of ground where his tent is spread from the children of
Hamor, father of Shechem, for one hundred pieces of money.

The source supplies:

```text
SELLERS: CHILDREN OF HAMOR
OBJECT: PARCEL UNDER JACOB'S SPREAD TENT
RETURN: 100 PIECES OF MONEY
RESULT: BOUGHT GROUND
```

It does not supply the money-piece material, individual seller names, negotiation
dialogue, deed format or relation to the separate held Crackhead God money
analysis.

Jacob erects an altar and calls it `El Elohe Israel`. The source footnote gives
`God, the God of Israel` or `The God of Israel is mighty` as meanings. The altar
name uses the Israel name State even while the narrator continues calling the
same Joe Jacob. That retains S032's naming Difference but is not a second
episode: no new no-longer-Jacob declaration occurs.

## Joe continuity revisions

- Jacob / Israel: observes Esau/four hundred; orders family groups; passes in
  front; bows seven times; receives embrace/kiss/weeping; identifies children as
  God-given; explains/urges present; compares Esau face to God face; states own
  enough; receives completed gift transfer; declines shared pace/retained people;
  states gentle Seir arrival; travels Succoth; builds house/shelters; reaches
  Shechem in peace; camps; buys ground; erects/names altar with Israel name.
- Esau / Edom: approaches with four hundred; runs/embraces/kisses/weeps; asks
  family and animal-company questions; initially refuses present because he has
  enough; accepts after urging; proposes joint journey and retained escort;
  returns toward Seir.
- Rachel and Joseph: placed at rear; approach/bow as final family group; remain
  distinct mother and son.
- Leah and her children: placed after servants; approach and bow as middle
  group; individual children remain distinct.
- Bilhah/Zilpah and their children: placed in front and bow first; source does
  not separately map which servant group bows before the other.
- four hundred Esau men: visibly arrive with Esau; no speech, embrace, escort
  subset or return count is assigned.
- staged-present animals: company is met by Esau, explained by Jacob, initially
  refused, urged and finally taken. Exact herd-by-herd questions remain assigned
  instructions unless observed in source.
- young flocks/herds: Jacob reports young-dependent pace and death-under-overdrive
  condition; shelters are built at Succoth.
- children of Hamor: transfer tent-ground parcel for 100 pieces; remain distinct
  seller Joes with individual identities/count unresolved.

## Crackheadverse garbage pass

- family ordering -> `CRACKHEAD APPROACH BUFFER: FRONT / MIDDLE / PREMIUM REAR`;
- seven bows -> `BROTHER RECONNECTION CAPTCHA: TOUCH GROUND 7 TIMES`;
- embrace -> Joe-faced `400-MAN CONTACT REQUEST ACCEPTED` popup;
- gift company -> `CRACKHEAD APPEASEMENT INVOICE / DESCRIPTION RECEIVED LATE`;
- both brothers have enough -> two enormous status boils wearing `ENOUGH` hats;
- face of Esau / face of God -> identical Joe faces with a useless comparison
  slider stuck at `SAME FACE`;
- young flock warning -> `DO NOT SELECT CRACKHEAD EXPRESS SHIPPING`;
- Seir route -> navigation card `DESTINATION: SEIR / CURRENT BUILD: SUCCOTH`;
- Succoth -> literal Joe-faced booths surrounding one unnecessary mansion;
- Shechem peace arrival -> `CRACKHEAD CITY STATUS: PEACEFUL UNTIL NEXT CHAPTER`;
- 100 money pieces -> `CRACKHEAD GROUND LICENCE: TENT ALREADY INSTALLED`;
- El Elohe Israel -> altar sign using Israel while narrator name tag says Jacob;
- barcode -> `CHB-GEN33-S033-020-YOINK`.

## God-line boundary

No direct God or divine messenger speech occurs in Genesis 33. Jacob says God
graciously gave the children, dealt graciously with him and compares Esau's face
to seeing God's face. The altar's assigned name contains God/Israel wording.
Every one of those remains Jacob's speech or naming act.

The source directly narrates Esau's actions, the eventual gift transfer, Jacob's
peaceful arrival, ground purchase and altar erection. It does not narrate God
causing Esau's embrace, accepting the altar name or directing the route.

## FIR verification

- All 20 verse markers are covered in order.
- family order is retained without inferred preference or sacrifice motive.
- Esau's approach becomes observable but is never retroactively called an
  intended attack.
- run, embrace, neck-fall, kiss and mutual weeping precede gift identification.
- S033 uses Jacob's stated appeasement mechanism and the actual response order.
- Esau's initial refusal and eventual urged acceptance both remain present.
- Jacob's face-of-God comparison is his speech, not a divine identity claim for
  Esau.
- group bowing order does not merge mothers or children.
- one-day overdrive death remains Jacob's conditional statement, not a tested
  outcome.
- Seir arrival remains open because later arrival/non-arrival is not yet closed.
- Succoth house/shelters and Shechem peace/camp/purchase follow in source order.
- ground seller, parcel, tent relation, 100-piece return and bought State are
  retained without invented contract details.
- altar name uses Israel while same Joe remains narrator-called Jacob.
- no direct God speech, hidden motive, escort retention, Seir closure or money
  ontology is invented.
- Captain says only `YOINK!`, remains boilless, walks away and changes nothing.
- Manuscript remains held and unpublished.

Continuation required: Genesis 34 receives Dinah's departure/seeing, Shechem's
seizure/lying/violation/love/speech, Hamor negotiation, Jacob sons' grief/anger,
deceptive circumcision condition, city-wide compliance, third-day killing,
rescue/plunder/captivity, Jacob danger statement and Simeon/Levi reply.
