# CRACKHEAD GENESIS 45

## Title page

**YOU SOLD ME.**

**IT WASN'T YOU. GOD SENT ME.**

Source parent: Genesis 45:1–28, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 45.

Prepared evidence: `.chapter-work/CHB-GEN-045/job.json` and `source.usfm`.

Parent manuscript: `GENESIS/044-I-PUT-THE-CUP-THERE-YOU-STOLE-IT.md`.

CrackFlix routing:

- existing `S046 — THE MIDIANITES SOLD HIM. THE ISHMAELITES SOLD HIM.`,
  episode `S046-E002-GEN45 — NOW THE BROTHERS SOLD HIM`;
- existing `S022 — GOD DID IT. MUM DID IT.`, episode
  `S022-E003-GEN45 — YOU SOLD ME, BUT GOD SENT ME`.

## Causal foundation

```text
JUDAH OFFERS SELF FOR BENJAMIN
-> JOSEPH CANNOT CONTROL HIMSELF
-> JOSEPH CLEARS NON-BROTHERS / WEEPS LOUDLY
-> JOSEPH DISCLOSES IDENTITY / ASKS FATHER LIFE
-> BROTHERS CANNOT ANSWER / SOURCE ATTRIBUTES TERROR
-> JOSEPH: I AM THE BROTHER YOU SOLD INTO EGYPT
-> GENESIS 37 EXPLICIT SALE ACTORS: MIDIANITE MERCHANTS
-> JOSEPH: DO NOT GRIEVE / GOD SENT ME TO PRESERVE LIFE
-> JOSEPH: IT WAS NOT YOU WHO SENT ME, BUT GOD
-> RETAINED HUMAN SALE/TRANSFER + PHARAOH APPOINTMENT CHAINS REMAIN
-> JOSEPH ORDERS FATHER/HOUSEHOLD MOVE TO GOSHEN
-> BROTHERS SEE/SPEAK / JOSEPH AND BENJAMIN WEEP / ALL BROTHERS TALK
-> PHARAOH HEARS / ORDERS CANAAN RETURN + HOUSEHOLD RELOCATION
-> JOSEPH SUPPLIES WAGONS/PROVISION/CLOTHING/SILVER/DONKEY LOADS
-> BROTHERS RETURN TO JACOB
-> REPORT JOSEPH ALIVE/RULER
-> JACOB DOES NOT BELIEVE
-> BROTHERS REPORT ALL WORDS / JACOB SEES JOSEPH WAGONS
-> JACOB REVIVES / SAYS JOSEPH ALIVE / COMMITS TO GO SEE HIM
```

## Genesis 45:1–4 — I AM JOSEPH

Joseph cannot control himself, orders everyone except the brothers out and
makes himself known. He weeps loudly enough that Egyptians and Pharaoh's house
hear. He says he is Joseph and asks whether his father lives. The brothers
cannot answer; the source attributes terror at his presence.

Joseph asks them to come near. They do. He repeats:

> **JOSEPH JOE:** `I AM JOSEPH, YOUR BROTHER, WHOM YOU SOLD INTO EGYPT.`

The identity asymmetry closes: Joseph's brothers now receive his living identity
from his own mouth. Their terror and inability to answer are source States; no
private thought, apology or recognition mechanism is invented.

The seller statement adds a third seller ledger to S046. Genesis 37 explicitly
names Midianite merchants as the actors who drew Joseph from the pit and sold
him for silver; Genesis 39 says Ishmaelites sold him to Potiphar; Joseph now
assigns sale into Egypt to the brothers. No transfer bridge merges those acts.

A Joe-faced fly opens CrackFlix:

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

He presses `SKIP`; his eyes glaze. Joseph keeps speaking.

## Genesis 45:5–8 — YOU DID IT. IT WASN'T YOU.

Joseph tells them not to grieve or be angry with themselves for selling him
there, then says God sent him before them to preserve life. He states two famine
years have occurred and five remain without plowing or harvest. He repeats that
God sent him to preserve a remnant and save them.

Then:

> **JOSEPH JOE:** `IT WASN'T YOU WHO SENT ME HERE, BUT GOD.`

Within the same speech Joseph retains `you sold me here` and then excludes
`you` as sender. The prior human chain remains: brothers conspire/propose/listen;
merchants draw, transfer and sell; Potiphar buys; later Pharaoh appoints Joseph
over Egypt. Joseph assigns the sending/preservation and authority result to God.

This is S022 again: a result is assigned to God while distinct retained actors
perform the producing transfer and appointment acts. Joseph's interpretation
does not erase those acts or become narrator-assigned divine causation.

Captain remains glazed as the famine explanation and God-sending speech
continue. Nothing skips.

The seller boil becomes a Joe-faced shipping ledger with three `SOLD BY` fields
and a fourth stamp: `ACTUALLY SENT BY GOD`.

Captain's eyes clear.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes, licks his empty finger, walks away and never looks back. Joseph still
sends for Jacob and the household.

## Genesis 45:9–13 — MOVE THE WHOLE HOUSE

Joseph commands the brothers to hurry to Jacob and deliver his words: God made
Joseph lord of Egypt; Jacob should come without waiting, dwell near Joseph in
Goshen with children, grandchildren, flocks, herds and all possessions; Joseph
will provide through the remaining five famine years.

He points to their eyes and Benjamin's eyes as witnesses that his own mouth is
speaking. He commands them to report his Egypt glory and everything they have
seen, then hurry Jacob down.

These are relocation commands and future provision statements. Arrival,
settlement and five-year provision remain open.

## Genesis 45:14–15 — NOW THEY TALK

Joseph and Benjamin fall on one another's necks and weep. Joseph kisses and
weeps on all brothers. After that, the brothers talk with him.

The source supplies the sequence but not the conversation content, forgiveness
agreement, apology or each brother's separate response.

## Genesis 45:16–20 — PHARAOH OFFERS EGYPT

Pharaoh's house hears Joseph's brothers came. The report pleases Pharaoh and
his servants. Pharaoh orders Joseph to tell the brothers to load animals, return
to Canaan, bring father and households, receive Egypt's good and eat its fat.
He commands Egyptian wagons for children/wives/Jacob and tells them not to
concern themselves with belongings because Egypt's good is theirs.

The offer is not treated as completed settlement. Its performance begins with
wagons and later travel.

## Genesis 45:21–24 — WAGONS, CLOTHES, SILVER, DON'T QUARREL

The sons of Israel comply. Joseph gives Pharaoh-commanded wagons and road
provision. Each brother receives clothing changes; Benjamin receives three
hundred silver pieces and five clothing changes. Jacob receives ten male-donkey
loads of Egypt goods and ten female-donkey loads of grain, bread and provision.
All living animals have Joe's face.

Joseph sends the brothers away and tells them not to quarrel on the road. No
quarrel is narrated in this chapter; the warning is not converted into one.

## Genesis 45:25–28 — ALIVE NEEDS WAGONS

The brothers reach Jacob in Canaan and say Joseph is alive and rules all Egypt.
Jacob's heart faints because he does not believe them. They then tell all
Joseph's words. Jacob sees the wagons Joseph sent to carry him, and his spirit
revives.

Israel says:

> **ISRAEL JOE:** `IT IS ENOUGH. JOSEPH MY SON IS STILL ALIVE. I WILL GO AND
> SEE HIM BEFORE I DIE.`

This is a changed evidence State:

```text
REPORT ONLY: JOSEPH ALIVE/RULER
-> JACOB DOES NOT BELIEVE
-> FULL JOSEPH WORDS + JOSEPH-SENT WAGONS OBSERVED
-> JACOB REVIVES
-> JACOB STATES JOSEPH ALIVE + COMMITS TO GO
```

The earlier false death belief closes. The promised journey and meeting do not.

## Joe continuity ledger

- Joseph discloses his identity to the brothers but not yet to Jacob directly.
- the brothers move from inability to answer/terror to talking with Joseph and
  carrying his report; conversation contents remain absent.
- Benjamin receives reciprocal weeping plus unequal silver/clothing gifts;
  no brother complaint or explanation is supplied.
- Judah's substitution request is overtaken by Joseph disclosure; no slavery or
  explicit acceptance/rejection line is added.
- Jacob changes from Joseph-dead belief to Joseph-alive belief after reported
  words plus visible wagons and commits to travel.
- Pharaoh and servants become explicit relocation sponsors.
- wagons and goods are nonliving carriers; animals are distinct Joe-faced lives.
- Captain remains permanently boilless and causally unnecessary.

## Bullshit pass

- banner: `ARTICLE 45 — CRACKHEAD SELLER ATTRIBUTION CONSOLIDATION`;
- shipping ledger: `BROTHERS / MIDIANITES / ISHMAELITES / GOD — SELECT ALL`;
- CrackFlix: `S046 + S022 / SKIP REQUEST / SPEECH CONTINUES`;
- Goshen brochure: `MOVE EVERYTHING / DON'T WORRY ABOUT EVERYTHING`;
- wagon certificate: `PROOF OF ALIVE — FOUR WHEELS MINIMUM`;
- Benjamin gift tag: `300 SILVER + FIVE OUTFITS / STILL SAME FACE`;
- barcode: `CHB-GEN45-S046E002-S022E003-28-YOINK`;
- footer: `BIG BAG RELOCATION — PACK NOTHING, BRING EVERYONE`.

## Reconstruction boundary

- all 28 verse markers are represented in order;
- S046 retains three explicit seller attributions without merging actors;
- S022 retains Joseph's God-sending/God-appointment interpretation as character
  speech beside the observed human transfer/appointment chain;
- SKIP is eligible from retained series and changes nothing;
- Joseph's disclosure closes brother recognition asymmetry, not Jacob meeting;
- terror, inability to answer and Joseph control failure are source-attributed;
- brother conversation contents and reconciliation terms are not invented;
- Pharaoh's offer and Joseph's provision are not projected beyond performed
  wagons/gifts/road provision;
- Jacob disbelief-to-belief follows new words and visible wagon evidence and is
  not treated as simultaneous contradiction;
- travel, settlement and reunion remain for Genesis 46;
- publication remains held and unpublished.

Continuation required: Genesis 46 performs Jacob's Egypt journey, direct God
speech at Beersheba, household inventory and Joseph/Jacob reunion.
