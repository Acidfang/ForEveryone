# CRACKHEAD GENESIS 35

## Title page

**YOUR NAME WILL NOT BE JACOB ANY MORE.**

**JACOB SET UP A PILLAR.**

**BENJAMIN WAS BORN NEAR EPHRATH.**

**THESE SONS WERE BORN IN PADDAN ARAM.**

Source parent: Genesis 35:1–29, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 35.

Parent manuscript:
`GENESIS/034-BECOME-ONE-PEOPLE-KILL-ALL-THE-MALES.md`.

CrackFlix routing:

- existing `S032 — YOUR NAME IS NO LONGER JACOB. JACOB.`, episode
  `S032-E002-GEN35 — GOD RENAMES HIM AGAIN`;
- new `S038 — BORN NEAR EPHRATH. BORN IN PADDAN ARAM.`, episode
  `S038-E001-GEN35 — THE TWELFTH SON MOVED BEFORE THE INVENTORY`.

Held, not routed:

- Genesis 34 Jacob predicted Canaanite/Perizzite gathering, striking and
  household destruction. Genesis 35 supplies divine terror on surrounding
  cities and no pursuit during this travel, but the prediction had no explicit
  deadline. Preserve the non-pursuit as a changed State without declaring the
  entire future prediction false or closed.
- Jacob's stated future arrival to Esau at Seir remains uncompleted. This
  chapter takes Jacob through Bethel, the Ephrath road and Mamre/Hebron.
- Israel hears that Reuben lay with Bilhah. No reply, consequence, Bilhah
  speech or consent State follows in this chapter. Carry the act and hearing
  forward without inventing closure.

## Causal foundation

```text
GOD COMMANDS JACOB: ARISE / BETHEL / LIVE / ALTAR
-> JACOB COMMANDS HOUSEHOLD: FOREIGN GODS AWAY / PURIFY / CHANGE GARMENTS
-> HOUSEHOLD GIVES FOREIGN GODS + EAR RINGS TO JACOB
-> JACOB HIDES THEM UNDER SHECHEM OAK
-> HOUSEHOLD TRAVELS
-> TERROR OF GOD ON SURROUNDING CITIES
-> CITIES DO NOT PURSUE JACOB'S SONS
-> JACOB + ALL WITH HIM ARRIVE AT LUZ/BETHEL
-> JACOB BUILDS ALTAR / NAMES EL BETH EL
-> DEBORAH DIES / IS BURIED / OAK NAMED ALLON BACUTH
-> GOD APPEARS AGAIN / BLESSES JACOB
-> GOD AGAIN SAYS JACOB NAME WILL NOT BE JACOB / NAMES ISRAEL
-> GOD STATES ALMIGHTY / FRUITFUL-MULTIPLY / NATIONS-KINGS / LAND PROMISE
-> GOD GOES UP
-> JACOB SETS PILLAR / DRINK OFFERING / OIL / NAMES BETHEL
-> HOUSEHOLD LEAVES BETHEL TOWARD EPHRATH
-> RACHEL HARD LABOR
-> MIDWIFE STATES ANOTHER SON
-> RACHEL NAMES BENONI WHILE DYING
-> JACOB NAMES CHILD BENJAMIN
-> RACHEL DIES / IS BURIED / JACOB SETS GRAVE PILLAR
-> ISRAEL TRAVELS / TENTS BEYOND EDER
-> REUBEN LIES WITH BILHAH
-> ISRAEL HEARS
-> SOURCE STATES JACOB HAS TWELVE SONS
-> SOURCE LISTS SONS BY MOTHERS, INCLUDING BENJAMIN
-> SOURCE STATES THESE SONS WERE BORN TO JACOB IN PADDAN ARAM
-> JACOB ARRIVES AT ISAAC IN MAMRE/HEBRON
-> ISAAC DIES AT 180
-> ESAU + JACOB BURY ISAAC
```

## Genesis 35:1–5 — PUT THEM UNDER THE OAK

God directly addresses Jacob:

> **CRACKHEAD GOD:** `ARISE, GO UP TO BETHEL, AND LIVE THERE.`
>
> **CRACKHEAD GOD:** `MAKE AN ALTAR THERE TO GOD, WHO APPEARED TO YOU WHEN
> YOU FLED FROM ESAU YOUR BROTHER.`

The command supplies four observable requirements: arise, travel to Bethel,
live there and make an altar. It also identifies the earlier appearance by the
Esau-flight relation. No new description of that earlier appearance is added.

Jacob addresses his household and everyone with him:

> **JACOB / ISRAEL JOE:** `PUT AWAY THE FOREIGN GODS THAT ARE AMONG YOU.`
>
> **JACOB / ISRAEL JOE:** `PURIFY YOURSELVES, AND CHANGE YOUR GARMENTS.`
>
> **JACOB / ISRAEL JOE:** `LET'S ARISE AND GO UP TO BETHEL.`

Jacob says he will make an altar to the God who answered him in his distress
and was with him on his way. That causal attribution belongs to Jacob's speech.

The people give Jacob all foreign gods in their hands and the rings in their
ears. The source does not identify which Joe owned which object, how the
objects were acquired, whether every earring was religious, or what purification
procedure and replacement garments looked like.

Jacob hides the objects under the oak by Shechem. He does not destroy them in
the observed text. The Joe-faced foreign-god objects and Joe-faced ear rings
remain under the Joe-faced oak; identical faces do not merge their identities.

They travel. A terror of God is on the surrounding cities, and those cities do
not pursue Jacob's sons. This is a narrator-assigned divine act and observable
non-pursuit.

Jacob's Genesis 34 prediction remains retained exactly:

```text
PREDICTED: CANAANITE/PERIZZITE GATHER -> STRIKE -> DESTROY
OBSERVED DURING THIS TRAVEL: DIVINE TERROR -> SURROUNDING CITIES DO NOT PURSUE
FUTURE BEYOND THIS TRAVEL: UNRESOLVED
```

No attack, pardon, repentance, legal judgment or divine approval of Genesis 34
is inserted.

## Genesis 35:6–8 — ALTAR, REVELATION, DEBORAH'S OAK

Jacob and everyone with him arrive at Luz, identified as Bethel in Canaan.
Jacob builds the commanded altar and calls the place El Beth El because God was
revealed to him there when he fled his brother.

The travel and altar requirements complete. The source does not separately
state how long Jacob lives at Bethel.

Deborah is introduced as Rebekah's nurse. She dies and is buried below Bethel
under an oak. The oak is called Allon Bacuth. The source footnotes no meaning
here, so this manuscript does not manufacture one.

Deborah receives the same Joe face as every living being. Her first explicit
chapter appearance is not rewritten as the beginning of her life, employment
or relationship with Rebekah.

No Captain interruption is placed on Deborah's death or burial.

## Genesis 35:9–15 — NOT JACOB ANY MORE, AGAIN

God appears to Jacob again after his return from Paddan Aram and blesses him.
God directly says:

> **CRACKHEAD GOD:** `YOUR NAME IS JACOB.`
>
> **CRACKHEAD GOD:** `YOUR NAME SHALL NOT BE JACOB ANY MORE, BUT YOUR NAME
> WILL BE ISRAEL.`

God names him Israel.

This is the same contradiction type already retained in S032. Genesis 32's
encounter speaker already said the same Joe's name would no longer be Jacob,
named him Israel, and the source continued calling him Jacob. Genesis 35 now
performs the rename again.

A Joe-faced fly in the corner opens his private CrackFlix ledger:

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

He presses `SKIP`. His eyes glaze. Nothing skips.

God continues speaking while Captain zones out:

> **CRACKHEAD GOD:** `I AM GOD ALMIGHTY.`
>
> **CRACKHEAD GOD:** `BE FRUITFUL AND MULTIPLY.`
>
> **CRACKHEAD GOD:** `A NATION AND A COMPANY OF NATIONS WILL BE FROM YOU,
> AND KINGS WILL COME OUT OF YOUR BODY.`
>
> **CRACKHEAD GOD:** `THE LAND WHICH I GAVE TO ABRAHAM AND ISAAC, I WILL
> GIVE IT TO YOU, AND TO YOUR OFFSPRING AFTER YOU.`

Those future nation, kings, multiplication, land and offspring States remain
promises at this chapter boundary. They are not backfilled from later history.

God goes up from Jacob at the place where God spoke with him.

The source then calls the same Joe `Jacob`. Jacob sets up a stone pillar,
pours a drink offering and oil on it, and calls the place Bethel.

Captain's eyes clear at the narrator label:

> **CAPTAIN CRACKHEAD:** `YOINK!`

He is now an unexplained boilless nobody in a superhero suit. He pokes the
rename boil, licks his empty finger, walks away and never looks back. Jacob's
pillar, offering, place name and subsequent journey remain identical.

That completes `S032-E002-GEN35`:

```text
PRIOR OCCURRENCE RETAINED: NO LONGER JACOB -> SOURCE CALLS HIM JACOB
-> GOD AGAIN: YOUR NAME IS JACOB / NOT JACOB ANY MORE / ISRAEL
-> SKIP PRESSED
-> GOD SPEECH AND WORLD CONTINUE
-> SOURCE: JACOB SET UP A PILLAR
-> SAME JOE RETAINS BOTH NAME STATES
```

## Genesis 35:16–20 — BENONI / BENJAMIN

They leave Bethel. While still some distance from Ephrath, Rachel enters hard
labor. The midwife says:

> **MIDWIFE JOE:** `DON'T BE AFRAID, FOR NOW YOU WILL HAVE ANOTHER SON.`

The source says Rachel's soul is departing and explicitly explains that she
dies. While that occurs, Rachel names the child Benoni. The source footnote says
Benoni means `son of my trouble`.

The child's father names him Benjamin. The source footnote says Benjamin means
`son of my right hand`.

Both naming acts are retained in order. The source does not record Jacob
denying that Rachel named the child, nor the child responding, so the two-name
sequence is not forced into a contradiction series.

Rachel dies and is buried on the road to Ephrath, also called Bethlehem. Jacob
sets a pillar on her grave. The source says it remains Rachel's grave pillar to
its own present day; this does not authorize a claim about the reader's date.

No Captain gag, boil praise or bullshit label is placed over hard labor,
Rachel's death or burial.

## Genesis 35:21–22 — ISRAEL HEARD

Israel travels and spreads his tent beyond the tower of Eder.

While Israel lives in that land, Reuben goes and lies with Bilhah, his father's
concubine. Israel hears of it.

The chapter supplies no Bilhah speech, consent State, location within the land,
witness, report carrier, Israel reply or immediate consequence. The act cannot
be expanded beyond the source verbs and relations.

```text
REUBEN GOES
-> REUBEN LIES WITH BILHAH
-> ISRAEL HEARS
-> NO CHAPTER-LOCAL RESPONSE
```

This remains an open causal chain.

## Genesis 35:23–26 — BORN HERE; ALL BORN THERE

The source states that Jacob's sons are twelve and lists them by maternal
relation:

- Leah: Reuben, Simeon, Levi, Judah, Issachar and Zebulun;
- Rachel: Joseph and Benjamin;
- Bilhah, Rachel's servant: Dan and Naphtali;
- Zilpah, Leah's servant: Gad and Asher.

Reuben remains explicitly Jacob's firstborn. The inventory does not erase the
Reuben/Bilhah act immediately before it.

The source then says:

> `THESE ARE THE SONS OF JACOB, WHO WERE BORN TO HIM IN PADDAN ARAM.`

Benjamin is inside `these sons`. The same chapter has just located Benjamin's
birth on the road from Bethel while there was still distance to Ephrath.
Jacob had already come from Paddan Aram before the Bethel appearance.

That completes S038:

```text
RACHEL LABORS ON ROAD FROM BETHEL NEAR EPHRATH
-> CHILD BORN / NAMED BENONI THEN BENJAMIN
-> INVENTORY INCLUDES BENJAMIN AMONG JACOB'S TWELVE SONS
-> SOURCE: THESE SONS WERE BORN TO JACOB IN PADDAN ARAM
-> ONE LISTED BIRTH LOCATION DOES NOT MATCH THE JUST-NARRATED LOCATION
```

Benjamin's birthplace boil grows into a Joe-faced road sign. One arrow reads
`EPHRATH: STILL SOME DISTANCE`; the other reads `PADDAN ARAM: APPARENTLY HERE
NOW`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Others see the suited boilless nobody poke the sign-shaped boil, lick an empty
finger, walk away and never look back. The twelve-son inventory remains printed
exactly as before.

## Genesis 35:27–29 — ISAAC'S DEATH AND BURIAL

Jacob comes to Isaac his father at Mamre, Kiriath Arba/Hebron, where Abraham
and Isaac lived as foreigners.

Isaac's days are stated as 180 years. Isaac gives up the spirit, dies, is
gathered to his people, and is described as old and full of days.

Esau and Jacob bury their father together. The source does not supply Rebekah's
location, Isaac's deathbed speech, an inheritance transfer, mourning duration,
burial disagreement or a Seir arrival by Jacob.

No Captain beat is inserted into Isaac's death or burial.

## Joe continuity ledger

- Jacob and Israel remain two active names of one Joe, never separate people.
- God directly commands Bethel travel/altar, causes terror on surrounding
  cities, appears, blesses, renames, promises and goes up.
- Jacob's household/all-with-him perform the foreign-god and earring transfer
  and Bethel travel; individual object ownership remains unresolved.
- surrounding-city Joes do not pursue; no pursuit is not converted into speech
  or motive.
- Deborah remains Rebekah's nurse and dies; her earlier life is not invented.
- Rachel gives birth, names Benoni and dies; her identity is not reduced to the
  grave or naming disagreement.
- Benjamin is the same newborn across both names and the later inventory.
- the midwife remains a distinct unnamed Joe.
- Reuben and Bilhah remain distinct Joes; the source act supplies no consent or
  response State.
- the twelve named sons remain distinct identities despite one Joe face.
- Isaac dies at 180; Esau and Jacob jointly bury him.
- Captain remains permanently boilless and socially unnecessary.

## Bullshit pass

- banner: `THE CRACKHEAD BIBLE — ARTICLE 35 — SECOND RENAME SERVICE CALL`;
- CrackFlix display: `S032 / EPISODE 2 / SKIP REQUEST RECEIVED / WORLD NOT
  NOTIFIED`;
- Bethel pillar label: `CRACKHEAD NAME UPDATE TERMINAL — OLD NAME STILL IN USE`;
- oak inventory sticker: `FOREIGN GODS + EAR RINGS — BURIED, NOT DELETED`;
- map warning: `EPHRATH MAY BE LOCATED IN PADDAN ARAM DURING INVENTORY MODE`;
- barcode: `CHB-GEN35-S032E002-S038E001-YOINK`;
- footer: `BIG BAG CONTINUITY HOLDS ALL LOCATIONS UNTIL SOMEBODY CHECKS`.

## Reconstruction boundary

- all 29 source verse markers are represented by ordered required States;
- direct God speech and narrator-assigned divine acts remain God-only;
- Jacob's speech about prior divine help remains character attribution;
- Genesis 34 retaliation prediction remains open despite chapter-local
  non-pursuit;
- Genesis 33 Seir statement remains open;
- S032 is reused rather than duplicated, and SKIP occurs only because its prior
  rename/continued-old-name segment is retained;
- S038 uses the source's own Benjamin birth location and inclusive inventory;
- Rachel/Isaac deaths and Bilhah's unvoiced State receive no exploitative gag or
  invented interiority;
- future promises remain open, not projected backward from later chapters;
- publication remains held and unpublished.

Continuation required: Genesis 36 receives Esau/Edom's wives, children,
Seirward separation, chiefs, Horite lineages and Edomite kings.
