# CRACKHEAD GENESIS 13

## Title page

**TOO MUCH STUFF. ONE FIELD. PICK A SIDE.**

Source parent: Genesis 13:1–18, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 13.

Parent manuscript: `GENESIS/012-SISTER-IN-PLAGUES-OUT.md`.

CrackFlix crossover: none closed in this chapter.

## Causal foundation

```text
EGYPT EXPULSION WITH ALL HOLDINGS
-> ABRAM/SARAI/LOT RETURN SOUTH
-> ABRAM VERY RICH IN LIVESTOCK/SILVER/GOLD
-> RETURN TO BETHEL/AI ALTAR -> CALL ON GOD
-> LOT ALSO HAS FLOCKS/HERDS/TENTS
-> SHARED LAND CAPACITY < COMBINED POSSESSIONS
-> HERDSMEN STRIFE
-> ABRAM PROPOSES NO-STRIFE SEPARATION + LOT FIRST CHOICE
-> LOT OBSERVES WATERED JORDAN PLAIN
-> LOT CHOOSES PLAIN / TRAVELS EAST
-> ABRAM AND LOT SEPARATE
-> ABRAM REMAINS CANAAN; LOT MOVES TOWARD SODOM
-> GOD RENEWS LAND/OFFSPRING PROMISE AFTER SEPARATION
-> ABRAM WALKS/MOVES TO MAMRE-HEBRON -> ALTAR
```

## Genesis 13:1–4 — RETURN WITH THE RECEIPTS

Abram leaves Egypt for the South with Sarai, A Lot Joe and everything he has.
He is very rich in livestock, silver and gold.

He journeys back to the original tent place between Bet-Hell and Aye and the
altar he built earlier. There he calls on God's name.

The Egypt goods remain in his current inventory because Genesis 12 records no
reclamation. The manuscript does not decide whether every item came from
Pharaoh or predated Egypt.

Background ledger: `CRACKHEAD NET WORTH — TOO MANY JOES TO FIT IN FIELD`.

## Genesis 13:5–7 — CAPACITY FAILURE

A Lot Joe also has flocks, herds and tents. The land cannot support both
households living together because their possessions are too great.

```text
AVAILABLE LAND CAPACITY
< ABRAM LIVESTOCK/POSSESSIONS + LOT LIVESTOCK/POSSESSIONS
-> COLOCATION FAILS
```

Strife occurs between Abram's herdsmen and Lot's herdsmen. Canaanites and
Perizzites also live in the land.

No speaker, insult, grazing act, property rule or aggressor is supplied for the
strife. Do not invent one.

## Genesis 13:8–9 — ABRAM'S SPLIT MECHANISM

> **ABRAM JOE:** `NO STRIFE BETWEEN US OR OUR HERDSMEN.`
>
> `WE'RE RELATIVES.`
>
> `THE WHOLE LAND IS THERE. SEPARATE FROM ME.`
>
> `YOU GO LEFT, I GO RIGHT. YOU GO RIGHT, I GO LEFT.`

Abram gives Lot the first observable directional choice. This is a conflict
resolution act; no later complaint about Lot's selection occurs in this
chapter.

## Genesis 13:10–13 — A LOT PICKS THE WATER

Lot looks and sees the entire Jordan plain well-watered everywhere, before God
destroys Sodom and Gomorrah. It is compared to God's garden and Egypt toward
Zoar.

Lot chooses the Jordan plain for himself and travels east. The households
separate.

Abram lives in Canaan. Lot lives among plain cities and moves his tent as far as
Sodom. Sodom's men are described as exceedingly wicked and sinners against God.

The future destruction reference is narrator chronology, not knowledge assigned
to Lot at his choice Moment. No hidden greed, ignorance or moral intention is
invented.

Wordplay map: Jordan -> **Joe-Dan**, Sodom -> **So-Dumb**, Gomorrah ->
**Gone-More-Ah**, Zoar -> **So-Far**.

## Genesis 13:14–17 — LOOK, DUST, WALK

After Lot separates, God tells Abram to look north, south, east and west from
his current place.

> **CRACKHEAD GOD:** `ALL THE LAND YOU SEE: YOU AND YOUR OFFSPRING, FOREVER.`
>
> `YOUR OFFSPRING WILL BE LIKE EARTH DUST.`
>
> `COUNT THE DUST, THEN COUNT THEM.`
>
> `GET UP. WALK THE LENGTH AND WIDTH. I'LL GIVE IT TO YOU.`

The offspring remain promised rather than observed. Sarai's childless State has
not changed in this chapter.

God's instruction creates a land-observation/walking boundary, not a modern
survey, title registry or coordinate polygon.

## Genesis 13:18 — MAMRE STATE

Abram moves his tent to Mamre's oaks in Hebron, lives there and builds an altar
to God.

Display: **Mammary Oaks, He-Bro**, every acorn with Joe's face. Source addresses
Mamre and Hebron remain retained.

## Character and world-ledger changes

- Abram: returns rich from Egypt; revisits altar; experiences herdsman capacity
  conflict; proposes separation and grants Lot directional choice; remains in
  Canaan; receives renewed promise; moves to Mamre/Hebron and builds altar.
- Lot: holds independent flocks/herds/tents; observes and selects watered Jordan
  plain; travels east; lives among plain cities; tents toward Sodom.
- Sarai: returns from Egypt with Abram; no speech or reproductive State change.
- herdsmen: distinct household worker groups with observable strife but no
  individually supplied acts or speech.
- Canaanites/Perizzites: current co-residents constrain the fiction from treating
  land as empty.

## Fuck-up pass

- Lot -> A Lot Joe.
- Bethel -> Bet-Hell.
- Ai -> Aye.
- Jordan -> Joe-Dan.
- Sodom -> So-Dumb.
- Gomorrah -> Gone-More-Ah.
- Zoar -> So-Far.
- Mamre/Hebron -> Mammary Oaks / He-Bro.
- land capacity -> `CRACKHEAD SHARED FIELD LICENCE: SEATS EXCEEDED`.

## FIR verification

- All 18 verse markers are covered in order.
- Egypt exit precedes retained wealth and return to earlier altar.
- Both households' possessions precede land-capacity failure and strife.
- Abram's separation offer precedes Lot's observation and choice.
- Lot's choice precedes directional movement and household separation.
- Narrator's future Sodom destruction reference is not assigned to Lot.
- God speaks after Lot separates.
- Land/offspring remain promises, not falsely completed ownership or population.
- Canaanite and Perizzite presence remains visible.
- No contradiction series, Captain crack or hidden motive is manufactured.
- Manuscript remains held and unpublished.

Continuation required: Genesis 14 receives the four-king/five-king war,
valley/slime-pit flight, Sodom/Gomorrah goods and Lot capture, Abram's armed
rescue, Melchizedek blessing/tithe, and Abram's refusal of Sodom's goods.
