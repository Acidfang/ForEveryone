# CRACKHEAD GENESIS 24

## Title page

**WE CAN'T SPEAK BAD OR GOOD. TAKE HER.**

Source parent: Genesis 24:1–67, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 24.

Parent manuscript: `GENESIS/023-THE-FREE-FOUR-HUNDRED-SHEKEL-FIELD.md`.

CrackFlix: `S017 — WE CAN'T SAY YES OR NO. YES.`, episode
`S017-E001-GEN24 — WE CAN'T SPEAK BAD OR GOOD. TAKE HER.`

## Causal foundation

```text
ABRAHAM OLD / BLESSED IN ALL THINGS
-> ELDER HOUSE-SERVANT GIVEN WIFE-FINDING OATH
-> NO CANAANITE WIFE / GO TO COUNTRY + RELATIVES
-> WOMAN'S UNWILLINGNESS EXPLICITLY RELEASES SERVANT
-> ISAAC MUST NOT BE TAKEN BACK THERE
-> SERVANT SWEARS / TAKES TEN CAMELS + GOODS / TRAVELS
-> SERVANT STATES WATER-AND-CAMELS TEST AT WELL
-> REBEKAH ARRIVES BEFORE SPEECH FINISHES
-> GIVES SERVANT WATER / DRAWS UNTIL ALL CAMELS FINISH
-> JEWELRY / IDENTITY / LODGING QUESTIONS
-> BETHUEL-NAHOR-MILCAH LINE CONFIRMED
-> LABAN BRINGS PARTY INTO HOUSE
-> SERVANT REFUSES FOOD UNTIL MESSAGE TOLD
-> OATH + TEST + COMPLETION REPORTED TO HOUSEHOLD
-> LABAN + BETHUEL: CAN'T SPEAK BAD OR GOOD
-> LABAN + BETHUEL: TAKE HER AND GO
-> GIFTS / MEAL / OVERNIGHT STAY
-> MORNING DEPARTURE REQUEST
-> BROTHER + MOTHER REQUEST TEN-DAY DELAY
-> SERVANT OBJECTS
-> REBEKAH ASKED WHETHER SHE WILL GO WITH THIS MAN
-> REBEKAH: I WILL GO
-> HOUSEHOLD SENDS / BLESSES HER
-> REBEKAH + NURSE + LADIES TRAVEL WITH SERVANT PARTY
-> ISAAC AND REBEKAH SEE EACH OTHER
-> SERVANT REPORTS ALL HE DID
-> ISAAC TAKES REBEKAH / SHE BECOMES WIFE
-> LOVE + COMFORT AFTER SARAH'S DEATH RECORDED
```

## Genesis 24:1–9 — THE OATH HAS AN EXIT

Abraham is old and well advanced in age. The LORD has blessed him in all
things. Abraham addresses the elder servant who rules everything in his house.
The source does not name this servant here, so no name is imported.

> **ABRAHAM JOE:** `PUT YOUR HAND UNDER MY THIGH.`
>
> `SWEAR BY THE LORD, GOD OF HEAVEN AND EARTH.`
>
> `DO NOT TAKE A CANAANITE WIFE FOR ISAAC.`
>
> `GO TO MY COUNTRY AND MY RELATIVES. TAKE A WIFE FOR HIM THERE.`

> **ELDER SERVANT JOE:** `WHAT IF THE WOMAN ISN'T WILLING TO FOLLOW ME?`
>
> `MUST I TAKE ISAAC BACK TO THE LAND YOU CAME FROM?`

> **ABRAHAM JOE:** `DO NOT TAKE MY SON THERE AGAIN.`
>
> `THE LORD TOOK ME FROM MY FATHER'S HOUSE, SPOKE TO ME, AND SWORE THAT THIS`
> `LAND WOULD GO TO MY OFFSPRING.`
>
> `HE WILL SEND HIS ANGEL BEFORE YOU.`
>
> `IF THE WOMAN ISN'T WILLING, YOU ARE CLEAR OF THIS OATH.`
>
> `ONLY DO NOT TAKE MY SON THERE AGAIN.`

The servant puts his hand under Abraham's thigh and swears. Abraham's statements
about prior divine speech and a future angel are Abraham's retained testimony in
this scene. No angel is independently shown or made to talk in this chapter.

The woman's unwillingness is an explicit oath-release condition. It remains in
the causal chain when the household later speaks and when Rebekah is finally
asked about immediate departure.

## Genesis 24:10–14 — TEN CAMELS AND A PRIVATE TEST

The servant takes ten of Abraham's camels and a variety of Abraham's goods. He
travels to Mesopotamia, to Nahor's city, and makes the camels kneel outside the
city beside a well at evening, when women come to draw water.

> **ELDER SERVANT JOE:** `LORD, GOD OF MY MASTER ABRAHAM, GIVE ME SUCCESS TODAY.`
>
> `I WILL ASK A YOUNG WOMAN FOR A DRINK.`
>
> `IF SHE GIVES ME A DRINK AND OFFERS WATER TO THE CAMELS TOO, LET HER BE THE`
> `ONE APPOINTED FOR ISAAC.`

This is the servant's spoken test and requested interpretation. It does not let
the fly declare God's unshown mechanism, private answer or control of Rebekah.

## Genesis 24:15–21 — SHE DOES THE WHOLE TEST

Before the servant finishes speaking, Rebekah comes out carrying a pitcher. Her
retained line is Bethuel <- Milcah + Nahor <- Abraham's brother relation. The
source describes her as very beautiful, a virgin, and not known by a man. She
goes down, fills the pitcher and comes back up.

> **ELDER SERVANT JOE:** `PLEASE GIVE ME A LITTLE WATER.`

> **REBEKAH JOE:** `DRINK, MY LORD.`

She hurries, lowers the pitcher and gives him a drink.

> **REBEKAH JOE:** `I WILL DRAW FOR YOUR CAMELS TOO, UNTIL THEY FINISH DRINKING.`

She empties the pitcher into the trough, runs back to the well, and draws for
all ten camels. Every camel is a living Joe-faced camel. Their faces do not
reduce the amount of water Rebekah actually carries.

The servant watches silently. The source supplies his stated aim—to learn
whether the LORD prospered the journey—but the comic shows only watching and
silence. It does not draw an invisible conclusion for him before his next act.

## Genesis 24:22–31 — JEWELRY FIRST, LINEAGE CONFIRMED

After the camels finish, the servant takes a half-shekel gold ring and two gold
bracelets weighing ten shekels.

> **ELDER SERVANT JOE:** `WHOSE DAUGHTER ARE YOU?`
>
> `IS THERE ROOM IN YOUR FATHER'S HOUSE FOR US TO STAY?`

> **REBEKAH JOE:** `I AM BETHUEL'S DAUGHTER.`
>
> `MILCAH BORE HIM TO NAHOR.`
>
> `WE HAVE ENOUGH STRAW, FEED, AND ROOM.`

The servant bows and worships the LORD. He says the LORD has not forsaken
kindness and truth toward Abraham and has led him to Abraham's relatives. These
are his public words after the observed test and lineage answer.

Rebekah runs and reports the words to her mother's house. Her brother Laban sees
the ring and bracelets, hears Rebekah's report, and runs to the servant at the
spring. Sequence is retained; no reason for his run is selected.

> **LABAN JOE:** `COME IN, YOU BLESSED OF THE LORD.`
>
> `WHY ARE YOU OUTSIDE? I PREPARED THE HOUSE AND ROOM FOR THE CAMELS.`

## Genesis 24:32–49 — NO FOOD UNTIL THE MESSAGE

The servant enters. The camels are unloaded and receive straw and feed. Water is
provided for the servant's feet and the accompanying men's feet. Food is set
before him.

> **ELDER SERVANT JOE:** `I WILL NOT EAT UNTIL I HAVE TOLD MY MESSAGE.`

> **LABAN JOE:** `SPEAK ON.`

The servant reports, in order:

- Abraham's wealth and the LORD's blessing;
- Sarah bearing Isaac in old age;
- Abraham giving all he has to Isaac;
- the non-Canaanite relative-house wife oath;
- the possibility that the woman will not follow;
- Abraham's angel/prospered-way statement and oath-release boundary;
- the servant's well test;
- Rebekah arriving before he finished speaking in his heart;
- her water offer and completed camel watering;
- her Bethuel/Nahor/Milcah identity answer;
- his placement of the ring on her nose and bracelets on her hands;
- his worship and right-way conclusion.

The retelling is preserved as a report. Its compressed wording does not replace
the already retained first occurrence, and the servant has not watched this as
a prior CrackFlix episode. Captain has no `SKIP` event here.

> **ELDER SERVANT JOE:** `IF YOU WILL DEAL KINDLY AND TRULY WITH MY MASTER,`
> `TELL ME.`
>
> `IF NOT, TELL ME. THEN I CAN TURN RIGHT OR LEFT.`

## Genesis 24:50–51 — WE CAN'T SPEAK; HERE IS OUR DECISION

Laban and Bethuel answer:

> **LABAN AND BETHUEL JOES:** `THE THING PROCEEDS FROM THE LORD.`
>
> `WE CAN'T SPEAK TO YOU BAD OR GOOD.`
>
> `REBEKAH IS BEFORE YOU.`
>
> `TAKE HER AND GO.`
>
> `LET HER BE YOUR MASTER'S SON'S WIFE, AS THE LORD HAS SPOKEN.`

Their own uninterrupted answer completes S017. They say they cannot speak bad
or good, then speak an affirmative disposition and direct the transfer and
marriage. No idiom, motive, authority theory or hidden definition is needed to
make both observable States coexist.

Laban's household-decision boil displays a tiny Joe face and an official
`NO COMMENT / APPROVED` seal.

> **CAPTAIN CRACKHEAD:** `YOINK!`

To the room: poke, lick finger, walk away, no look back. To Captain: crack
crystal eaten. He changes no answer, gift, departure, willingness or marriage.
This is S017's first retained episode, so there is no `SKIP`.

## Genesis 24:52–61 — ASK HER AFTER THE DECISION

The servant hears the answer and bows to the earth before the LORD. He gives
silver, gold and clothing to Rebekah, and precious things to her brother and
mother. The party eats, drinks and stays overnight.

In the morning:

> **ELDER SERVANT JOE:** `SEND ME AWAY TO MY MASTER.`

> **REBEKAH'S BROTHER AND MOTHER JOES:** `LET HER STAY WITH US AT LEAST TEN DAYS.`
>
> `AFTER THAT SHE WILL GO.`

> **ELDER SERVANT JOE:** `DON'T HINDER ME.`
>
> `THE LORD HAS PROSPERED MY WAY. SEND ME BACK TO MY MASTER.`

They call Rebekah and ask her directly:

> **HOUSEHOLD JOES:** `WILL YOU GO WITH THIS MAN?`

> **REBEKAH JOE:** `I WILL GO.`

Her answer closes her observed willingness to depart now. The comic does not
rewrite verses 50–51 as though she delivered Laban and Bethuel's earlier words,
and it does not invent an unrecorded objection to the marriage.

They send Rebekah with her nurse, the servant and his men. They bless her as a
future mother of vast descendants whose offspring possess enemies' gate.
Rebekah rises with her ladies. They ride the Joe-faced camels and follow the
servant.

## Genesis 24:62–67 — THE MARRIAGE CLOSES

Isaac comes from Beer Lahai Roi and lives in the South. He goes into the field
to meditate at evening, looks up, and sees camels approaching. Rebekah looks up,
sees Isaac, and gets off her camel.

> **REBEKAH JOE:** `WHO IS THAT MAN WALKING ACROSS THE FIELD TO MEET US?`

> **ELDER SERVANT JOE:** `IT IS MY MASTER.`

Rebekah takes her veil and covers herself. The servant tells Isaac everything
he did. The source does not supply that report's wording or Isaac's reply.

Isaac brings Rebekah into Sarah's tent, takes her, and she becomes his wife. The
source records that Isaac loves her and is comforted after his mother's death.
Those attributed States are retained without invented courtship, ceremony,
private dialogue or a claim about what either face visibly proves.

## Character and world-ledger changes

- Abraham: now old/advanced; sends his ruling elder servant under oath; excludes
  Canaanite wife selection and Isaac's return; retains unwilling-woman release.
- unnamed elder servant: rules Abraham's possessions; swears; leads ten camels
  and men; states/observes the well test; gives jewelry; reports the mission;
  refuses food before message; secures household answer; requests departure;
  returns Rebekah and reports all acts to Isaac.
- Rebekah: Bethuel's daughter in Milcah/Nahor line; draws for servant and ten
  camels; identifies household; receives jewelry/clothes; says she will go;
  travels with nurse/ladies; meets and marries Isaac.
- Isaac: receives all Abraham has according to servant report; resides in the
  South; comes from Beer Lahai Roi; meditates in field; receives servant report;
  takes/loves Rebekah; is comforted after Sarah's death.
- Bethuel: answers with Laban; says no bad/good speech possible; immediately
  directs Rebekah's departure/marriage.
- Laban: enters as Rebekah's brother; prepares lodging; hears mission; answers
  with Bethuel; receives precious things; joins mother in delay request.
- Rebekah's unnamed mother: household report recipient; receives precious
  things; joins ten-day request and departure.
- Rebekah's unnamed nurse and ladies: travel with her; no speech is invented.
- ten camels: transported goods/party, drank Rebekah's drawn water, were lodged,
  fed and ridden; individual lineages remain unresolved.
- servant's accompanying men: receive foot water, eat/stay, and return with him.

## Fuck-up pass

- Mesopotamia -> `MESSY-POT-AMIA`, where every pot has Joe's face.
- Nahor -> `NAH-OR CITY`, with two gates labelled `NAH` and `OR`.
- thigh oath -> `CRACKHEAD TERMS AND CONDITIONS: PLACE HAND HERE`.
- ten camels -> `TEN-CAMEL LOAD TEST / RESULTS: THIRSTY`.
- pitcher -> an actual baseball pitcher repeatedly throwing water into a trough.
- half-shekel ring -> `50% SHEKEL / 100% NOSE`.
- bracelets -> `CRACKHEAD GPS HANDLES`.
- Laban -> `LAY-BAN JOE`, standing beneath a ban he laid down himself.
- Bethuel -> `BET-YOU-WILL JOE`, already holding an `I WILL` departure ticket.
- Beer Lahai Roi -> `BEER, LA-HI, ROY`, three Joe-faced field signs.
- Sarah's tent -> `PREVIOUS OCCUPANT: SARAH JOE / CONTINUITY NOT INCLUDED`.
- household answer docket -> `WE CANNOT DECIDE / DECISION ATTACHED`.

## God-line boundary

Genesis 24 directly narrates that the LORD had blessed Abraham in all things.
The remaining divine acts in the chapter are spoken attributions, prayers,
prior-speech reports and household interpretations. No God or angel appears or
speaks directly in the chapter, so no new God dialogue is invented.

## FIR verification

- All 67 verse markers are covered in order.
- Abraham's oath conditions retain country, relatives, no-Canaanite-wife,
  no-Isaac-return and woman's-unwillingness release boundaries.
- The servant's prayer/test precedes Rebekah's action; her action completes every
  stated water element before lineage is confirmed.
- Silent observation is not converted into a visible private conclusion.
- Jewelry, identity question and lodging answer retain their source order.
- The servant's household speech remains a report and does not erase the first
  occurrence or create a false CrackFlix repeat.
- S017 closes only when `can't speak bad or good` is followed by `take her and
  go` in the same answer.
- Rebekah's verse-58 willingness remains distinct from the verse-50/51 household
  decision and closes the immediate departure dispute.
- The servant's party, nurse, ladies and ten living Joe-faced camels are retained.
- Isaac receives the servant's report before marriage.
- Love and comfort remain source-attributed States without mind-reading prose.
- Captain appears only after S017 completes, says only `YOINK!`, has no boils,
  triggers no act and changes no outcome.
- No `SKIP`, direct God speech, visible angel or unrelated contradiction is made.
- Manuscript remains held and unpublished.

Continuation required: Genesis 25 receives Abraham's later wife/children,
concubine-son gifts and eastern sending, Abraham's death/burial, Ishmael's
descendants/death, Rebekah's twins, birthright sale and the first Esau/Jacob
household distinctions.
