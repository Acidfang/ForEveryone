# CRACKHEAD GENESIS 32

## Title page

**YOUR NAME WILL NO LONGER BE CALLED JACOB.**

**JACOB ASKED HIM.**

**JACOB CALLED THE PLACE PENIEL.**

**JACOB LIMPED AWAY.**

Source parent: Genesis 32:1–32, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 32.

Parent manuscript:
`GENESIS/031-DONT-SPEAK-GOOD-OR-BAD-KEEP-TALKING.md`.

CrackFlix:

- `S031 — ALL THAT YOU SEE IS MINE. IT WENT WITH JACOB.`, episode
  `S031-E001-GEN31-32 — LABAN WENT HOME, THE INVENTORY DIDN'T`;
- `S032 — YOUR NAME IS NO LONGER JACOB. JACOB.`, episode
  `S032-E001-GEN32 — THE NARRATOR DIDN'T GET THE RENAME`.

## Causal foundation

```text
GEN31 LABAN: DAUGHTERS + CHILDREN + FLOCKS + ALL VISIBLE ARE MINE
-> LABAN RETURNS TO HIS PLACE
-> JACOB CONTINUES ON HIS WAY
-> JACOB STILL HAS CATTLE + DONKEYS + FLOCKS + SERVANTS
-> JACOB STILL HAS PEOPLE + FLOCKS + HERDS + CAMELS
-> GEN31 OWNERSHIP FRICTION CLOSES
-> GOD'S ANGELS MEET JACOB
-> JACOB NAMES PLACE MAHANAIM / TWO CAMPS
-> JACOB SENDS MESSENGERS TO ESAU WITH SERVANT/LORD/FAVOR MESSAGE
-> MESSENGERS REPORT ESAU COMING WITH FOUR HUNDRED MEN
-> SOURCE: JACOB GREATLY AFRAID + DISTRESSED
-> JACOB DIVIDES PEOPLE + ANIMALS INTO TWO COMPANIES
-> JACOB PRAYS RETURN PROMISE + UNWORTHINESS + DELIVERANCE + OFFSPRING PROMISE
-> JACOB SELECTS EXACT ANIMAL PRESENT
-> SERVANTS STAGE SEPARATE HERDS + REPEATED ESAU MESSAGE
-> PRESENT PASSES AHEAD / JACOB STAYS IN CAMP
-> JACOB MOVES TWO WIVES + TWO SERVANTS + ELEVEN SONS + POSSESSIONS OVER JABBOK
-> JACOB REMAINS ALONE
-> MAN WRESTLES JACOB UNTIL DAYBREAK
-> MAN DOES NOT PREVAIL / TOUCHES THIGH HOLLOW / THIGH STRAINS
-> MAN REQUESTS RELEASE / JACOB REQUIRES BLESSING
-> MAN ASKS JACOB NAME / JACOB ANSWERS
-> MAN RENAMES JACOB ISRAEL / STATES GOD-AND-MEN FIGHT + PREVAILING
-> JACOB ASKS MAN NAME / MAN ASKS WHY / BLESSES JACOB
-> SOURCE CONTINUES CALLING HIM JACOB
-> JACOB NAMES PENIEL / REPORTS GOD FACE-TO-FACE + PRESERVED LIFE
-> SUN RISES / JACOB CROSSES LIMPING
-> SOURCE CONTINUES CALLING HIS THIGH JACOB'S
-> CHILDREN OF ISRAEL FOOD CUSTOM RETAINED TO SOURCE PRESENT
```

## Genesis 32:1–2 — GOD'S ARMY / TWO CAMPS

Jacob goes on his way. Angels of God meet him. Every angel is a distinct living
Joe-faced angel; shared face does not merge the army.

> **JACOB JOE:** `THIS IS GOD'S ARMY.`

Jacob calls the place Mahanaim. The source footnote says Mahanaim means `two
camps`. Jacob supplies the army identification; the narrator supplies the
meeting. No angel speech, rank, destination or intervention is invented.

## Genesis 32:3–6 — ESAU IS COMING WITH FOUR HUNDRED MEN

Jacob sends human messengers ahead to Esau in Seir, the field of Edom. These
messenger Joes remain distinct from the angels who just met him.

> **JACOB JOE TO HIS MESSENGERS:** `TELL MY LORD ESAU:`
>
> `YOUR SERVANT JACOB LIVED AS A FOREIGNER WITH LABAN UNTIL NOW.`
>
> `I HAVE CATTLE, DONKEYS, FLOCKS, MALE SERVANTS AND FEMALE SERVANTS.`
>
> `I SENT TO TELL MY LORD SO I MAY FIND FAVOR IN YOUR SIGHT.`

The inventory closes Genesis 31's carried ownership friction. Laban said every
visible flock and all else was his, then returned to his place. Jacob now
continues with cattle, donkeys, flocks and servants still explicitly his.

The messengers return:

> **MESSENGER JOES:** `WE CAME TO YOUR BROTHER ESAU.`
>
> `HE IS COMING TO MEET YOU.`
>
> `FOUR HUNDRED MEN ARE WITH HIM.`

The report establishes approach and count. It does not say attack, peace,
weapons, Esau's words or the four hundred men's purpose.

## Genesis 32:7–12 — TWO COMPANIES AND THE PRAYER

The source directly attributes great fear and distress to Jacob. This is source
testimony, not a facial inference.

Jacob divides the people with him, flocks, herds and camels into two companies.
This confirms the travelling inventory remains with Jacob after Laban's return.

That completes S031:

```text
LABAN: THE DAUGHTERS / CHILDREN / FLOCKS / ALL YOU SEE ARE MINE
-> LABAN RETURNS TO HIS PLACE
-> JACOB GOES ON HIS WAY
-> JACOB: I HAVE CATTLE / DONKEYS / FLOCKS / SERVANTS
-> PEOPLE / FLOCKS / HERDS / CAMELS REMAIN WITH JACOB
```

Jacob's inherited-inventory boil becomes a full Joe face wearing a luggage tag:
`ALL LABAN'S / CURRENTLY WITH JACOB`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Everyone else sees a completely boilless suited nobody poke the boil, lick an
empty finger, walk away and never look back. The two companies and every
property relation remain unchanged.

> **JACOB JOE:** `IF ESAU STRIKES ONE COMPANY, THE OTHER WILL ESCAPE.`

That is Jacob's conditional plan. No strike occurs in this chapter.

Jacob prays:

> **JACOB JOE:** `GOD OF ABRAHAM, GOD OF ISAAC, LORD:`
>
> `YOU SAID, "RETURN TO YOUR COUNTRY AND RELATIVES, AND I WILL DO YOU GOOD."`
>
> `I AM NOT WORTHY OF THE LEAST OF YOUR LOVING KINDNESSES AND TRUTH.`
>
> `I CROSSED THIS JORDAN WITH ONLY MY STAFF.`
>
> `NOW I HAVE BECOME TWO COMPANIES.`
>
> `PLEASE DELIVER ME FROM ESAU.`
>
> `I FEAR HE WILL STRIKE ME AND THE MOTHERS WITH THE CHILDREN.`
>
> `YOU SAID YOU WOULD DO ME GOOD AND MAKE MY OFFSPRING LIKE UNCOUNTABLE SEA
> SAND.`

The quoted promises, worthiness statement, fear and requested deliverance are
Jacob's prayer. They are not new narrator-presented God speech or a completed
Esau attack.

## Genesis 32:13–21 — FIVE HUNDRED FIFTY PLUS THE COLTS

Jacob stays that night and selects a present for Esau:

- 200 female goats and 20 male goats;
- 200 ewes and 20 rams;
- 30 milk camels with their colts;
- 40 cows and 10 bulls;
- 20 female donkeys and 10 foals.

The listed adults and specified foals total 550 before the unnumbered camel
colts. The manuscript retains the unresolved colt count rather than pretending
the whole present totals 550.

Every animal has Joe's face. Species, sex, offspring relation, herd separation
and count remain distinct.

Jacob delivers each herd separately to servants and commands space between the
herds. He gives the foremost servant a response for Esau's anticipated
questions:

> **SERVANT JOE'S ASSIGNED WORDS:** `THEY ARE YOUR SERVANT JACOB'S.`
>
> `THIS IS A PRESENT TO MY LORD ESAU.`
>
> `JACOB IS BEHIND US.`

Jacob gives the same speech instruction to the second, third and all following
herd groups.

> **JACOB JOE:** `I WILL APPEASE HIM WITH THE PRESENT AHEAD OF ME.`
>
> `AFTERWARD I WILL SEE HIS FACE.`
>
> `PERHAPS HE WILL ACCEPT ME.`

This is Jacob's stated plan and uncertainty. The present passes ahead. Jacob
stays that night in camp. Genesis 33 must supply Esau's actual response.

## Genesis 32:22–23 — ELEVEN SONS OVER JABBOK

Jacob rises that night and takes:

- his two wives;
- his two female servants;
- his eleven sons.

He crosses the Jabbok ford and sends them and everything he has over the stream.
The source says `eleven sons`; Dinah is neither deleted nor silently converted
into a son. Her precise Jabbok placement is unresolved at this wording boundary.

This crossing preserves the Genesis 31 wives, children and property with Jacob's
party after Laban's total-ownership claim.

## Genesis 32:24–26 — THE MAN TOUCHES THE HIP

Jacob is left alone. A man wrestles with him until daybreak. The man is a living
Joe-faced man. The source does not narratively name him as God or an angel here.

The source says the man sees that he does not prevail against Jacob. The man
touches the hollow of Jacob's thigh. Jacob's thigh is strained while they
wrestle.

> **THE WRESTLING MAN JOE:** `LET ME GO. DAY IS BREAKING.`
>
> **JACOB JOE:** `I WON'T LET YOU GO UNLESS YOU BLESS ME.`

The request, refusal and condition are observable. The manuscript does not
invent why daybreak matters, how the touch strains the thigh or whether the
injury constitutes winning.

## Genesis 32:27–29 — JACOB IN; ISRAEL OUT

> **THE WRESTLING MAN JOE:** `WHAT IS YOUR NAME?`
>
> **JACOB JOE:** `JACOB.`
>
> **THE WRESTLING MAN JOE:** `YOUR NAME WILL NO LONGER BE CALLED JACOB.`
>
> `IT WILL BE ISRAEL.`
>
> `YOU HAVE FOUGHT WITH GOD AND WITH MEN AND HAVE PREVAILED.`

Israel is a new name State for the same Joe identity. It is not a new face,
body, history or separate Joe.

> **JACOB / ISRAEL JOE:** `PLEASE TELL ME YOUR NAME.`
>
> **THE WRESTLING MAN JOE:** `WHY DO YOU ASK MY NAME?`

The man blesses him there. The man's name remains unresolved. Jacob supplied his
name when asked; the man responds to the reciprocal request with a question.
That information asymmetry is retained but not independently labelled a
contradiction without a shared disclosure rule.

## Genesis 32:30–32 — JACOB AFTER JACOB ENDS

Immediately after the no-longer-Jacob declaration, the source says:

> `JACOB CALLED THE PLACE PENIEL.`

Jacob says:

> **JACOB / ISRAEL JOE:** `I HAVE SEEN GOD FACE TO FACE, AND MY LIFE IS
> PRESERVED.`

Peniel means `face of God` in the source footnote. `I have seen God` is Jacob's
interpretation of the encounter; it does not rewrite the narrator's `a man`
identity boundary or supply the man's refused name.

The sun rises as he passes Peniel. He limps because of his thigh. The source
then calls the injured body part `Jacob's thigh`.

That completes S032:

```text
MAN: YOUR NAME WILL NO LONGER BE CALLED JACOB
-> SAME SOURCE: JACOB ASKED
-> SAME SOURCE: JACOB CALLED THE PLACE PENIEL
-> SAME SOURCE: JACOB'S THIGH
-> ISRAEL NAME STATE IS ACTIVE / JACOB NAME CONTINUES
```

Israel/Jacob's rename boil becomes his entire Joe face wearing two identical
name badges, one crossed out and still being used.

> **CAPTAIN CRACKHEAD:** `YOINK!`

The limping renamed Joe sees a boilless suited nobody poke the boil, lick his
finger and leave. Captain does not heal the thigh, select a preferred name or
change the food custom.

The source says that, to its present day, the children of Israel do not eat the
sinew of the hip on the thigh hollow because the man touched Jacob's thigh
there. This source-present custom is retained as a descendant people State. It
does not prove that the eleven sons immediately announce or perform it at the
ford.

## Joe continuity revisions

- Jacob / Israel: continues with Laban-claimed inventory; meets angels and names
  Mahanaim; sends/receives Esau messengers; is source-attributed afraid and
  distressed; divides camp; prays; selects and stages gifts; crosses wives,
  servants, eleven sons and property; remains alone; wrestles; receives hip
  injury; refuses release without blessing; gives Jacob name; receives Israel
  name; asks reciprocal name; receives blessing; names Peniel; reports seeing
  God/preserved life; crosses limping.
- Esau / Edom: receives approach message through messengers; is reported coming
  with four hundred men; receives staged present approach. No speech, attack,
  acceptance or motive is imported before Genesis 33.
- wrestling man: wrestles until daybreak; source says he does not prevail;
  touches/strains thigh; requests release; asks/renames/blesses; states
  God-and-men fighting/prevailing; refuses name by question. Source identity
  remains `a man`; Jacob's God interpretation remains Jacob's speech.
- angels of God: meet Jacob; receive Jacob's army identification; no speech or
  intervention is invented.
- human messenger Joes: carry Jacob's lord/servant/inventory/favor speech to
  Esau and return with the four-hundred-men approach report.
- Jacob servants: receive separated animal herds and repeated response script;
  pass ahead. No spontaneous speech or knowledge beyond instructions is added.
- Rachel, Leah, Bilhah and Zilpah: cross in the two-wife/two-servant party;
  individual order, speech and reaction remain unresolved.
- eleven sons: cross Jabbok as a stated group; Dinah's unmentioned placement
  remains unresolved rather than erased.
- present animals: retain all species/sex/count/offspring/herd divisions and Joe
  faces; camel-colt count remains unresolved.
- children of Israel: receive a source-present hip-sinew food custom with
  producing touch relation; population chronology is not backfilled into the
  eleven sons' immediate dialogue.

## Crackheadverse garbage pass

- Mahanaim -> `CRACKHEAD DUAL-CAMP OPERATING SYSTEM` with two Joe-faced tents;
- angels -> `CRACKHEAD ARMY: NO ORDERS ATTACHED`;
- four hundred men -> `ESAU CONTACT STATUS: 400 FRIEND REQUESTS PENDING`;
- two companies -> `IF ONE GETS DELETED, OPEN BACKUP CAMP`;
- prayer -> `CRACKHEAD RETURN-PROMISE SUPPORT TICKET`;
- 550 plus camel colts -> invoice `TOTAL: 550 + FUCK KNOWS HOW MANY LITTLE
  CAMELS`;
- separated herds -> five increasingly ridiculous Joe-faced gift popups;
- Jabbok -> `JAB-BOX`, a literal ford with a boxing bell nobody rings;
- wrestling -> `CRACKHEAD DAWN-LIMITED NAME-MIGRATION SERVICE`;
- hip touch -> `ONE-TOUCH LEG UPDATE / RESTART REQUIRED`;
- Jacob/Israel badges -> `OLD NAME DISABLED` beside `CURRENTLY USING OLD NAME`;
- Peniel -> Joe-faced sign `FACE OF GOD / MAN'S NAME UNAVAILABLE`;
- hip sinew -> `CRACKHEAD MENU ITEM: PERMANENTLY OUT SINCE ARTICLE 32.32`;
- barcode -> `CHB-GEN32-S031-S032-032-YOINK`.

## God and messenger boundary

Genesis 32 narrates angels of God meeting Jacob but supplies them no speech.
Jacob quotes prior return/good and offspring promises inside his prayer. Those
quotes remain Jacob's current speech, not a fresh narrator-presented God address.

The wrestling speaker is called `a man` by the narrator. He says Jacob fought
with God and men; Jacob later says he saw God face to face. Those statements are
retained exactly at their speakers. The manuscript does not silently relabel the
man as Crackhead God, an angel or any selected ontology, and therefore does not
put the man's dialogue in the God-only ledger as direct God speech.

## FIR verification

- All 32 verse markers are covered in order.
- Genesis 31 total-ownership friction closes only after Genesis 32 explicitly
  retains Jacob's inventory and companies.
- S031 keeps the ownership claim, Laban departure and Jacob inventory in one
  cross-chapter causal chain.
- angels and human messengers remain different Joe groups.
- Esau's approach is not converted into an attack or peace outcome.
- fear/distress are source attribution; Esau motive is not inferred.
- all gift counts are retained and unnumbered camel colts remain unnumbered.
- repeated servant script is not turned into observed Esau dialogue before the
  servants reach him.
- two wives, two servants and eleven sons remain the exact crossing inventory;
  Dinah is not erased.
- the narrator's `man`, the man's God-and-men statement and Jacob's God
  interpretation remain distinct source claims.
- injury touch, release request, blessing condition, name exchange, renaming,
  blessing and limp remain ordered.
- Israel is a name revision of Jacob, never a new Joe.
- S032 uses the source's own continued Jacob wording after no-longer-Jacob.
- the children-of-Israel custom retains its source-present time boundary.
- Captain says only `YOINK!`, is boilless, walks away and changes nothing.
- no attack, acceptance, healing, identity ontology or custom performance is
  invented.
- Manuscript remains held and unpublished.

Continuation required: Genesis 33 receives Esau's actual approach, family
ordering, seven bows, embrace/kiss/weeping, gift/children questions, acceptance,
travel-separation proposal, Succoth house/booths, Shechem arrival, field purchase
and altar naming.
