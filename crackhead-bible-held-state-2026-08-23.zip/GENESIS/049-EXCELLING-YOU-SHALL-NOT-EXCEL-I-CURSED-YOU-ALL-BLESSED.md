# CRACKHEAD GENESIS 49

## Title page

**EXCELLING IN DIGNITY. EXCELLING IN POWER.**

**YOU SHALL NOT EXCEL.**

**CURSED BE THEIR ANGER. I BLESSED EVERYONE.**

Source parent: Genesis 49:1–33, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 49.

Prepared evidence: `.chapter-work/CHB-GEN-049/job.json` and `source.usfm`.

Parent manuscript: `GENESIS/048-EPHRAIM-AND-MANASSEH-ARE-MINE-WHO-ARE-THESE.md`.

CrackFlix routing:

- new `S057 — YOU ARE EXCELLING. YOU SHALL NOT EXCEL.`, episode
  `S057-E001-GEN49 — REUBEN'S PERFORMANCE REVIEW`;
- new `S058 — I CURSED YOU. I BLESSED EVERYONE.`, episode
  `S058-E001-GEN49 — TWELVE INDIVIDUAL BLESSINGS INCLUDING THE CURSE`.

## Causal foundation

```text
JACOB CALLS SONS / ANNOUNCES DAYS-TO-COME SPEECH
-> REUBEN CALLED FIRSTBORN / EXCELLING DIGNITY+POWER
-> REUBEN TOLD SHALL NOT EXCEL DUE FATHER-BED ACT
-> SIMEON+LEVI LINKED TO VIOLENCE / MEN+CATTLE ACTS
-> THEIR ANGER CURSED / FUTURE DIVISION+SCATTERING PREDICTED
-> JUDAH PRAISE/ENEMY/BOW/LION/SCEPTER/ABUNDANCE PREDICTIONS
-> ZEBULUN SEA/SIDON PREDICTION
-> ISSACHAR DONKEY/REST/FORCED-LABOR PREDICTION
-> DAN JUDGE/SERPENT PREDICTION
-> JACOB ADDRESSES LORD: WAITED FOR SALVATION
-> GAD ATTACK/COUNTERATTACK PREDICTION
-> ASHER FOOD PREDICTION
-> NAPHTALI DOE/FAWNS SAYING
-> JOSEPH VINE/ARCHER/STRONG-BOW/DIVINE-BLESSING SPEECH
-> BENJAMIN WOLF/PREY/PLUNDER PREDICTION
-> NARRATOR: THESE ARE TWELVE TRIBES / FATHER BLESSED EVERY ONE
-> JACOB COMMANDS MACHPELAH BURIAL / RETELLS PURCHASE+BURIALS
-> JACOB FINISHES / FEET INTO BED / LAST BREATH / GATHERED
```

## Genesis 49:1–2 — WHAT WILL HAPPEN LATER

Jacob calls his sons to gather so he may tell what will happen in days to come.
He addresses them as sons of Jacob and tells them to listen to Israel their
father. Jacob and Israel remain one Joe identity.

The speech announces its future boundary. A prediction is not converted into a
performed history merely because Jacob says it.

## Genesis 49:3–4 — EXCELLING / NOT EXCELLING

Jacob calls Reuben his firstborn, might and beginning of strength:

> **JACOB:** `EXCELLING IN DIGNITY, AND EXCELLING IN POWER.`

The next line says:

> **JACOB:** `YOU SHALL NOT EXCEL.`

Jacob connects the reversal to Reuben going up to and defiling his father's
bed/couch, retaining Genesis 35's act.

```text
REUBEN IS EXCELLING IN DIGNITY
-> REUBEN IS EXCELLING IN POWER
-> REUBEN SHALL NOT EXCEL
-> SAME SPEAKER / SAME ADDRESSEE / SAME SPEECH
```

S057 completes. Reuben's performance review grows a Joe-faced boil with both
`EXCEEDS EXPECTATIONS` and `CANNOT EXCEL` checked.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain pokes, licks, walks away and never looks back. Reuben's retained bed act
and Jacob's future consequence statement remain unchanged.

## Genesis 49:5–7 — SIMEON AND LEVI

Jacob calls Simeon and Levi brothers whose swords are weapons of violence. He
rejects joining their council/assembly and says they killed men in anger and
hamstrung cattle in self-will. He curses their fierce anger and cruel wrath,
then predicts division in Jacob and scattering in Israel.

Genesis 34 supplies the retained city-killing and plunder chain. This chapter
adds the cattle-hamstring claim; it does not retroactively fabricate a missing
Genesis 34 verse or assign that act to an individually named brother.

The curse is on anger/wrath in the wording. The predicted division/scattering
remains future.

## Genesis 49:8–12 — JUDAH

Jacob predicts brother praise, enemy-neck control and father-son bows to Judah.
He calls Judah a lion's cub/lion/lioness, predicts enduring scepter/ruler staff
until its recipient comes, and predicts peoples' obedience.

The speech adds a foal/colt bound to vine, garments washed in wine/grape blood,
wine-red eyes and milk-white teeth. Every animal and face-like vine/grape may
have Joe's face. None of these images proves a performed animal transformation,
monarchy, enemy defeat or future ruler in Genesis 49.

## Genesis 49:13–21 — ZEBULUN THROUGH NAPHTALI

- Zebulun: future sea/ship haven and Sidon border.
- Issachar: strong donkey between saddlebags; sees good rest/pleasant land,
  shoulders burden and becomes forced-labour servant.
- Dan: future judge among Israel tribes; serpent/adder bites horse heels and
  drops a rider.
- Jacob addresses the LORD: `I HAVE WAITED FOR YOUR SALVATION.` This is Jacob's
  speech to God, not God's speech back.
- Gad: troop presses him; he presses their heel.
- Asher: rich food and royal dainties.
- Naphtali: doe set free bearing beautiful fawns.

Each living person, donkey, serpent, adder, horse, rider and doe/fawn is
Joe-faced. Metaphorical identity remains Jacob's wording and does not merge a
son with an animal or establish a performed future act.

## Genesis 49:22–26 — JOSEPH

Jacob calls Joseph a fruitful vine by a spring with branches over a wall. He
says archers grieved, shot at and persecuted him, while Joseph's bow remained
strong and his arms were strengthened by the Mighty One of Jacob.

Jacob attributes shepherd/stone, help and future blessings to the God of his
father and the Almighty. He lists heaven, deep, breasts and womb blessings and
says his blessings exceed ancestral blessings and will rest on Joseph, the one
separated from brothers.

The divine strengthening/help/blessing relations remain Jacob's attribution and
prediction. No God or angel speaks or appears. The archers and exact shooting
occurrence are not identified elsewhere by this chapter and remain unresolved.

## Genesis 49:27 — BENJAMIN

Jacob calls Benjamin a ravenous wolf who devours prey in morning and divides
plunder at evening. The saying does not perform a transformation, attack or
plunder event in this chapter.

## Genesis 49:28 — CURSED / EVERYONE BLESSED

The narrator calls these people the twelve tribes of Israel and says their
father spoke and blessed them, everyone according to his own blessing.

The completed mismatch retains the actual contents:

```text
REUBEN: SHALL NOT EXCEL
SIMEON+LEVI: CURSED ANGER / DIVIDED / SCATTERED
-> NARRATOR: HE BLESSED THEM
-> NARRATOR: EVERYONE ACCORDING TO HIS OWN BLESSING
-> NO EXCLUSION OF REBUKE/CURSE RECIPIENTS FROM EVERYONE
```

S058 completes. A twelve-column blessing ledger grows Joe-faced boils in the
cells labelled `CURSE` and `SHALL NOT EXCEL` while its total reads
`12/12 BLESSED`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain pokes, licks and leaves. All twelve sayings remain in the ledger.

## Genesis 49:29–32 — THE BURIAL ADDRESS

Jacob commands the sons to bury him with his fathers in the Ephron Hittite
field cave at Machpelah before Mamre in Canaan, bought by Abraham from Ephron.
He identifies it as the burial place of Abraham/Sarah, Isaac/Rebekah and Leah,
and repeats that the field/cave were purchased from the children of Heth.

This expands Genesis 47's not-Egypt burial oath into an exact retained address.
It is a command, not yet a burial act. Rachel remains buried on the Ephrath road,
not silently moved into Machpelah.

## Genesis 49:33 — JACOB DIES

Jacob finishes charging his sons, gathers his feet into the bed, breathes his
last and is gathered to his people.

His living State changes to deceased. Joseph's promised hand-closes-eyes act is
not narrated here and remains unresolved. Embalming, mourning, procession and
burial belong to Genesis 50 and are not imported.

## Character and world-ledger changes

- Jacob/Israel completes the twelve addressed sayings, Machpelah command and
  death; his burial remains open.
- Reuben retains firstborn/excellence wording, prior bed act and predicted loss.
- Simeon/Levi retain Genesis 34 violence plus new cattle claim and future
  division/scattering prediction.
- Judah, Zebulun, Issachar, Dan, Gad, Asher, Naphtali, Joseph and Benjamin each
  receive distinct sayings/predictions without premature fulfillment.
- the twelve sons are called twelve tribes without merging person and later
  collective identities.
- Abraham/Sarah, Isaac/Rebekah and Leah remain deceased/buried at Machpelah;
  Rachel remains at Ephrath/Bethlehem road.
- all living humans and animals share Joe's face but never identity.

## Bullshit pass

- banner: `ARTICLE 49 — CRACKHEAD ANNUAL FAMILY PERFORMANCE REVIEW`;
- Reuben form: `EXCELLING / NOT ELIGIBLE TO EXCEL`;
- Simeon/Levi award: `CURSED ANGER — BLESSING CATEGORY`;
- Judah forecast: `LION STAFF WINE LAUNDRY DIVISION`;
- animal desk: `DONKEY / SNAKE / HORSE / DOE / WOLF — ALL JOE`;
- tribe counter: `12 SONS = 12 TRIBES / FUTURE LOADING`;
- burial GPS: `MACH-PEEL-AH / BEFORE MAM-RE / RECEIPT ATTACHED`;
- barcode: `CHB-GEN49-S057E001-S058E001-33-YOINK`;
- footer: `BIG BAG OF INDIVIDUAL BLESSINGS — CURSES INCLUDED`.

## FIR verification

- all 33 verse markers are represented in order;
- every son's addressed speech remains distinct and ordered;
- performed prior acts, present labels and future predictions are separated;
- S057 uses adjacent same-speaker/same-person excel wording;
- S058 preserves explicit curse/loss contents against the narrator's everyone-
  blessing total without redefining blessing;
- Jacob's LORD line remains character address, not God speech;
- all divine help/blessing language remains Jacob attribution/prediction;
- no future tribe, territory, monarchy, war or animal image is marked performed;
- the Machpelah command preserves exact people/place/purchase lineage;
- Jacob's death closes; eye-closing and burial remain unresolved;
- publication remains held and unpublished.

Continuation required: Genesis 50 performs embalming, mourning, Pharaoh-approved
Machpelah procession/burial, brother fear/message/submission, Joseph's renewed
God-intent interpretation and Joseph's death/coffin State.
