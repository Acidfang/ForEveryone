# CRACKHEAD GENESIS 19

## Title page

**DON'T DO THAT TO THEM. DO IT TO THESE.**

Source parent: Genesis 19:1–38, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 19.

Parent manuscript: `GENESIS/018-I-DIDNT-LAUGH.md`.

CrackFlix: `S014 — DON'T DO THAT TO THEM. DO IT TO THESE.`, episode
`S014-E001-GEN19 — THEY ARE UNDER MY ROOF`.

Content boundary: the source contains threatened group sexual violence, Lot's
offer of his daughters, intoxication and incest. The reconstruction preserves
the acts and missing consent without graphic production or comedy aimed at the
people threatened or used.

## Causal foundation

```text
TWO ANGELS ARRIVE AT SODOM -> LOT INVITES -> ANGELS INITIALLY REFUSE
-> LOT URGES -> HOUSE / FEAST / EATING
-> CITY MEN SURROUND HOUSE -> DEMAND VISITORS FOR SEX
-> LOT EXITS / SHUTS DOOR
-> CALLS ACT WICKED
-> OFFERS TWO DAUGHTERS TO SAME MOB
-> PROTECTS VISITORS BECAUSE UNDER HIS ROOF
-> MOB REJECTS / THREATENS LOT / PRESSES DOOR
-> ANGELS PULL LOT IN / SHUT DOOR / STRIKE MOB BLIND
-> DESTRUCTION WARNING -> LOT WARNS SONS-IN-LAW
-> NO EXIT BY SONS-IN-LAW RETAINED
-> MORNING HURRY -> LOT LINGERS
-> ANGELS TAKE FOUR HANDS -> OUTSIDE CITY
-> ESCAPE / NO LOOKING BACK / NO PLAIN / MOUNTAINS
-> LOT REQUESTS LITTLE CITY -> ZOAR SPARED
-> LOT REACHES ZOAR AT SUNRISE
-> FIRE/SULFUR -> CITIES/PLAIN/INHABITANTS/GROWTH OVERTHROWN
-> LOT'S WIFE LOOKS BACK -> PILLAR OF SALT
-> ABRAHAM OBSERVES FURNACE-LIKE SMOKE
-> GOD REMEMBERS ABRAHAM -> LOT SENT OUT
-> LOT LEAVES ZOAR FOR MOUNTAIN CAVE WITH DAUGHTERS
-> FIRSTBORN PROPOSES WINE + SEX + LINE PRESERVATION
-> NIGHT ONE: FIRSTBORN / LOT UNAWARE
-> NIGHT TWO: YOUNGER / LOT UNAWARE
-> BOTH CONCEIVE
-> MOAB BORN -> MOABITE LINE
-> BEN AMMI BORN -> AMMONITE LINE
```

## Genesis 19:1–3 — TWO ANGELS AT THE GATE

Two angels arrive at Sodom in the evening. Lot is sitting in the city gate. He
sees them, rises, meets them and bows face-down.

> **LOT JOE:** `MY LORDS, COME INTO YOUR SERVANT'S HOUSE.`
>
> `STAY THE NIGHT. WASH YOUR FEET. LEAVE EARLY.`

> **TWO ANGEL JOES:** `NO. WE'LL STAY IN THE STREET.`

Lot urges them greatly. They enter his house. Lot makes a feast, bakes
unleavened bread, and they eat.

Genesis 18 ended with men traveling toward Sodom; Genesis 19 calls these two
arrivals angels. The continuity candidate is retained, but the text does not
explicitly number the prior three and say which two these are.

## Genesis 19:4–8 — WICKED FOR THEM, GOOD FOR THESE

Before the visitors lie down, Sodom's men surround the house—young and old,
all the people from every quarter.

> **SODOM MEN:** `WHERE ARE THE MEN WHO CAME TO YOU TONIGHT?`
>
> `BRING THEM OUT SO WE MAY HAVE SEX WITH THEM.`

Lot goes outside and shuts the door behind him.

> **LOT JOE:** `PLEASE, MY BROTHERS. DON'T ACT SO WICKEDLY.`
>
> `I HAVE TWO VIRGIN DAUGHTERS.`
>
> `LET ME BRING THEM OUT. DO TO THEM WHAT SEEMS GOOD TO YOU.`
>
> `ONLY DON'T DO ANYTHING TO THESE MEN.`
>
> `THEY CAME UNDER THE SHADOW OF MY ROOF.`

The contradiction closes in Lot's own sequence: the mob's threatened act is
called wicked; the daughters are offered to that mob for what it calls good;
the visitors alone receive the stated roof protection. No daughter speaks and
no transfer of consent or protection is recorded.

Lot's roof-shaped status boil displays a tiny Joe face.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. Captain sees a crack crystal; the
others see only the poke and lick. The offer and mob response remain unchanged.

This is S014's first retained episode. There is no `SKIP`.

## Genesis 19:9–11 — THE DOOR

> **SODOM MEN:** `STAND BACK!`
>
> `THIS FOREIGNER APPOINTS HIMSELF A JUDGE.`
>
> `WE'LL DEAL WORSE WITH YOU THAN WITH THEM.`

They press Lot and approach to break the door. The visitors reach out, pull Lot
inside and shut it. They strike the men at the door with blindness, small and
great. The men wear themselves out trying to find the door.

The mob does not accept Lot's offered substitution. The angels' intervention,
not Captain, changes the physical State.

## Genesis 19:12–14 — GET OUT

The visitors ask whether Lot has anyone else in the city—sons-in-law, sons,
daughters or anyone belonging to him—and tell him to bring them out. They say
the outcry has become great before the LORD and the LORD sent them to destroy
the place.

Lot warns the sons-in-law pledged to marry his daughters:

> **LOT JOE:** `GET UP! GET OUT! THE LORD WILL DESTROY THE CITY!`

The source says Lot seemed to them to be joking. It records no departure by the
sons-in-law. Their thoughts, later location and deaths are not separately
observed or filled in.

## Genesis 19:15–17 — PHYSICALLY EXTRACTED

At morning the angels hurry Lot:

> **TWO ANGEL JOES:** `GET UP. TAKE YOUR WIFE AND YOUR TWO DAUGHTERS HERE.`
>
> `LEST YOU BE CONSUMED IN THE CITY'S INIQUITY.`

Lot lingers. The men grab Lot's hand, his wife's hand and both daughters' hands,
take them out and set them outside the city. The source attributes this to the
LORD's mercy; the visible chain is lingering followed by physical extraction.

> **ANGEL JOE:** `ESCAPE FOR YOUR LIFE.`
>
> `DON'T LOOK BEHIND YOU.`
>
> `DON'T STAY ANYWHERE IN THE PLAIN.`
>
> `ESCAPE TO THE MOUNTAINS OR BE CONSUMED.`

## Genesis 19:18–23 — THE LITTLE CITY

Lot says he cannot escape to the mountain without evil overtaking him and asks
to flee to a nearby little city.

> **ANGEL JOE:** `REQUEST GRANTED.`
>
> `I WILL NOT OVERTHROW THAT CITY.`
>
> `HURRY. I CAN'T DO ANYTHING UNTIL YOU GET THERE.`

The city is called Zoar, meaning `little`. The sun has risen when Lot reaches
it. The conditional delay and arrival are both retained before destruction.

`I can't` is the speaker's stated action boundary, not a universal limit silently
extended beyond this event.

## Genesis 19:24–26 — FIRE, SULFUR, SALT

The LORD rains sulfur and fire from the sky on Sodom and Gomorrah. The cities,
the plain, their inhabitants and ground growth are overthrown.

Lot's wife looks back from behind him and becomes a pillar of salt.

The rule precedes the look; the look precedes the changed body. The source does
not state her reason, words, duration of looking or later awareness. The pillar
has Joe's face because it is a living Joe interpreted as a faced salt object.

No contradiction is required: instruction, violation and consequence agree as
an observable chain.

## Genesis 19:27–29 — ABRAHAM'S VIEW

Abraham returns early to the place where he stood before the LORD. He looks
toward Sodom, Gomorrah and the plain. Smoke rises from the land like furnace
smoke.

The source states that when God destroyed the plain's cities, God remembered
Abraham and sent Lot out from the overthrow of the cities where Lot lived.

Abraham sees smoke. The text does not record him seeing Lot, the angels, the
salt pillar or a righteous-population count. Genesis 18's ten-person condition
is not retroactively declared met or unmet without a source count.

## Genesis 19:30–32 — THE CAVE PLAN

Lot leaves Zoar with his two daughters and lives in a mountain cave. The source
says he was afraid to live in Zoar; the fly records the move and does not add a
cause beyond that source attribution.

> **FIRSTBORN DAUGHTER JOE:** `OUR FATHER IS OLD.`
>
> `THERE ISN'T A MAN ON THE EARTH TO COME IN TO US IN THE WAY OF ALL THE EARTH.`
>
> `LET'S MAKE FATHER DRINK WINE.`
>
> `WE'LL LIE WITH HIM TO PRESERVE OUR FATHER'S FAMILY LINE.`

This is the firstborn daughter's stated plan. Recent survival in Zoar remains
part of the history; the manuscript does not silently turn her statement into
an independently verified census of Earth.

## Genesis 19:33–36 — TWO NIGHTS

On the first night the daughters make Lot drink wine. The firstborn lies with
him. The source states Lot does not know when she lies down or rises.

The next day the firstborn reports the act and proposes the same wine mechanism
for the younger daughter. On the second night they again make Lot drink wine;
the younger lies with him; again Lot does not know when she lies down or gets up.

Both daughters become pregnant by their father.

The source explicitly records Lot's lack of awareness. No consent from Lot is
recorded. The two nights remain separate occurrences because different actors
and Moments produce each conception. There is no `SKIP`: repetition alone does
not manufacture a contradiction show.

Production stays outside the cave. Two ledger cards—`NIGHT ONE` and `NIGHT TWO`—
record wine, entry, exit and absent awareness without depicting sex.

## Genesis 19:37–38 — TWO PEOPLE ROOTS

The firstborn bears Moab. The source identifies him as father of the Moabites
to the narrator's `this day`.

The younger bears Ben Ammi. The source identifies him as father of the children
of Ammon to that same narrative horizon.

Birth does not erase the conception mechanism or make either later population
responsible for its ancestor's acts.

## Character and world-ledger changes

- Lot: sits at Sodom gate; houses angels; offers daughters after condemning the
  mob's demand; is threatened and rescued; warns sons-in-law; lingers and is
  physically extracted; negotiates Zoar; later moves to a mountain cave; is
  intoxicated and unaware during two sexual acts.
- Lot's wife: extracted by hand; receives no-look-back instruction; looks back;
  becomes salt pillar. Her personal name remains unresolved.
- firstborn daughter: threatened by Lot's offer; extracted; later states and
  executes the two-night lineage plan; conceives and bears Moab.
- younger daughter: threatened by Lot's offer; extracted; participates in the
  second night; conceives and bears Ben Ammi.
- two Sodom angels: receive hospitality, stop the breach, blind attackers,
  announce destruction, extract the family and grant Zoar request.
- Sodom men: surround house, demand visitors, reject substitution, threaten Lot,
  press door and are struck blind.
- Moab and Ben Ammi: born as individual Joes and named population roots.
- Sodom/Gomorrah/plain: destruction closes the prior report/inspection branch;
  Zoar remains explicitly spared at Lot's arrival boundary.

## Fuck-up pass

- Lot -> `A LOT JOE`, with one household form containing far too much.
- Sodom -> `SOD 'EM` turf depot, now closed.
- Zoar -> `SO-R`, a very little emergency city printed in tiny type.
- pillar of salt -> `CRACKHEAD SEASONING MONUMENT / DO NOT LOOK BACK FOR REFILL`.
- blindness at door -> Joe-faced door keeps moving on the map.
- cave -> `CRACKHEAD LINEAGE CONTINUITY FACILITY`, an awful label on an awful
  event, not a joke at its subjects.
- Moab -> `MO-AB JOE`.
- Ben Ammi -> `BEN-AND-ME JOE`.
- smoke like furnace -> `CRACKHEAD CITY STATUS: COOKED`.

## FIR verification

- All 38 verse markers are covered in order.
- Angel arrival, Lot's invitation, refusal, urging, entry, feast and eating
  retain their necessary transitions.
- Mob demand precedes Lot's condemnation and daughter offer; S014 closes only
  from Lot's own incompatible target treatment.
- Daughters' absent consent at the offer remains absent.
- Captain appears after contradiction completion, says only `YOINK!`, has no
  boil and changes nothing.
- Door breach attempt precedes angelic intervention and blindness.
- Warning precedes lingering; extraction precedes escape instruction; Zoar
  request and arrival precede destruction.
- No-look-back rule precedes looking back and salt-pillar change.
- Abraham's observed smoke is not expanded into unobserved city details.
- Both intoxication nights and both absent-awareness statements are retained;
  no graphic scene or consent is invented.
- Moabite and Ammonite lineage statements do not transfer ancestral acts to
  descendants.
- Manuscript remains held and unpublished.

Continuation required: Genesis 20 receives Gerar, Sarah's repeated sister
presentation, Abimelech's dream warning, integrity defense, restoration,
payments, prayer and reopened wombs.
