# CRACKHEAD GENESIS 6

## Title page

**DELETE EVERYTHING. KEEP THIS JOE. BUILD THE BASTARD.**

Source parent: Genesis 6:1–22, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 6.

Parent manuscript: `GENESIS/005-AND-THEN-HE-DIED.md`.

CrackFlix crossover: none closed in this chapter.

## Causal foundation

```text
HUMANS MULTIPLY + DAUGHTERS BORN
-> GOD'S SONS SEE / SELECT / TAKE WIVES
-> GOD STATES 120-YEAR HUMAN DAYS BOUNDARY
-> NEPHILIM + CHILDREN + MIGHTY/RENOWNED PEOPLE
-> GOD OBSERVES GREAT WICKEDNESS + CONTINUAL EVIL HEART-THOUGHTS
-> GOD REGRETS MAKING HUMANS + GRIEVES
-> GOD STATES DESTRUCTION OF HUMANS/ANIMALS/CREEPERS/BIRDS
-> NO-AH FINDS FAVOUR
-> NO-AH HISTORY: RIGHTEOUS + BLAMELESS AMONG HIS TIME + WALKS WITH GOD
-> EARTH CORRUPT + FILLED WITH VIOLENCE
-> GOD OBSERVES ALL FLESH CORRUPTED WAY
-> GOD TELLS NO-AH THE END + FLOOD
-> SHIP SPECIFICATION + COVENANT + PASSENGER/FOOD REQUIREMENTS
-> NO-AH DOES ALL COMMANDED
```

## Genesis 6:1–2 — POPULATION AND TAKEN WIVES

Humans multiply across the ground. Daughters are born. God's sons see that
human daughters are beautiful and take whichever they want as wives.

The source does not identify the sons' biology, institutional authority,
consent process, selection count or private motives. They are rendered as
Joe-faced living beings labelled `GOD'S SONS — IDENTITY DOCUMENTS PENDING`.

What is observable remains:

```text
THEY SEE -> THEY WANT -> THEY TAKE AS WIVES
```

The manuscript neither excuses nor supplements that sequence.

## Genesis 6:3 — ONE HUNDRED AND TWENTY

> **CRACKHEAD GOD:** `MY SPIRIT ISN'T STRIVING WITH HUMAN JOE FOREVER.`
>
> `HE'S FLESH. HIS DAYS ARE ONE HUNDRED AND TWENTY YEARS.`

The statement enters the ledger exactly here. This chapter does not decide
whether `days` means individual lifespan, remaining time before judgment or
another supplied scope. Later States must resolve any application.

Label: `CRACKHEAD HUMAN WARRANTY — 120 YEARS / TERMS UNRESOLVED`.

## Genesis 6:4 — NEPH-I-LIMB JOE

Nephilim—source note: alternatively giants—exist on Earth in those days and
also afterward. When God's sons have children with human daughters, the
children are described as mighty people of old and people of renown.

Display name: **Neph-I-Limb Joes**. Production gives each too many or too few
Joe-faced limbs. The lineage and descriptors remain unchanged; body geometry is
unresolved production garbage.

No later angel, demon, alien or genetic theory is imported into this chapter.

## Genesis 6:5–7 — GOD SEES, REGRETS, DECIDES

God sees great human wickedness on Earth and every imagination of human
heart-thought continually only evil. The observation precedes the response.

God is sorry that he made humans on Earth and is grieved in his heart.

> **CRACKHEAD GOD:** `I MADE THIS.`
>
> `I SAW WHAT IT BECAME.`
>
> `I'M WIPING HUMAN JOE OFF THE GROUND.`
>
> `ANIMALS. CREEPING THINGS. SKY BIRDS. THE LOT.`
>
> `I'M SORRY I MADE THEM.`

The Genesis 1 `very good` observation and Genesis 6 regret have different
retained world States between them. The comic does not erase the intervening
human acts to manufacture an instantaneous contradiction.

Every animal, creeping thing and bird shown has Joe's face. None receives an
invented statement of responsibility.

## Genesis 6:8–10 — BUT NO-AH

No-Ah Joe finds favour in God's eyes. His generation history describes him as
righteous, blameless among the people of his time, and walking with God. He is
father of Shem Joe, Ham Joe and Japheth Joe.

These are source descriptors, not a claim that he has never performed any act
outside the chapter's evidence boundary.

No-Ah's inventory gains `walk-with-God`, connecting him to E-NOCH Joe's earlier
relation without merging the two identities.

## Genesis 6:11–13 — THE EARTH IS FULL

The earth is corrupt before God and filled with violence. God observes that all
flesh has corrupted its way.

> **CRACKHEAD GOD:** `THE END OF ALL FLESH IS IN FRONT OF ME.`
>
> `THE EARTH IS FULL OF THEIR VIOLENCE.`
>
> `I'M DESTROYING THEM WITH THE EARTH.`

This is a God-only decision line because the source assigns it to God. It drives
the ark command and flood plan; it is not Captain commentary.

The apparent scope between `all flesh` and the separately favoured No-Ah family
is retained for downstream covenant/passenger States. The manuscript does not
silently redefine `all`.

## Genesis 6:14–16 — CRACKHEAD SHIP SPECIFICATION 001

God commands No-Ah to make a ship from gopher wood:

- rooms inside;
- pitch sealing inside and outside;
- length: 300 cubits;
- width: 50 cubits;
- height: 30 cubits;
- roof finished to one cubit upward;
- door in its side;
- lower, second and third levels.

The source note addresses one cubit as approximately 18 inches / 46 cm. The
manuscript retains cubits as the construction authority and the approximation
as source metadata, not permission to pretend a missing build tolerance exists.

The gopher wood is covered in tiny gopher faces because a gopher is interpreted
as having a face. Nobody notices. Label: `100% CRACKHEAD GOPHER COMPATIBLE`.

The ship is not yet called an ark by the source text used here; this manuscript
uses ship and the continuity address `ARK PROJECT` only as a reader index.

## Genesis 6:17–18 — FLOOD AND COVENANT

> **CRACKHEAD GOD:** `I'M BRINGING FLOOD WATER ON EARTH.`
>
> `EVERY EARTH THING UNDER THE SKY WITH LIFE-BREATH DIES.`
>
> `BUT I'M ESTABLISHING MY COVENANT WITH YOU.`

No-Ah, his sons, his wife and his sons' wives are to enter the ship.

The covenant is promised here but its later terms and sign are not imported
backward. `COVENANT-ID: OPEN / DETAILS CONTINUE`.

## Genesis 6:19–21 — LIVING AND FOOD INVENTORY

No-Ah must bring two of every living flesh sort, male and female, to keep them
alive:

- birds after their kinds;
- livestock after their kinds;
- ground-creeping things after their kinds.

Two of every sort will come to No-Ah. He must gather every kind of eaten food
for himself and them.

Every passenger creature has Joe's face. Species identity remains visible
through body, scale, movement and kind relation; face identity never resolves
the kind.

The requirement creates a held inventory, not an assertion that every item is
already aboard:

```text
REQUIRED -> NOT YET OBSERVED LOADED
```

## Genesis 6:22 — DID

No-Ah does everything God commands him.

```text
COMMAND -> NO-AH DID ALL COMMANDED
```

The chapter closes obedience broadly but does not expose every construction
Moment or demonstrate the flood beginning. Genesis 7 must reconstruct entry and
water arrival separately.

No-Ah's mannerism is now source-derived: when given a complete construction and
preservation command, he performs it. This is not generic compliance assigned
to every future No-Ah occurrence without a connected command.

## Character and world-ledger changes

- God's sons: observed collective identity with see/want/take/children acts;
  ontology unresolved.
- human daughters: multiply as individually unresolved Joes; taken-wife and
  childbearing relations retained.
- Neph-I-Limb Joes: mighty/renowned old people linked to the stated parent
  occurrence; later identity claims forbidden without evidence.
- No-Ah: favour, righteous/blameless-at-time descriptors, walking with God,
  shipbuilding command, covenant promise, passenger/food inventory and complete
  obedience.
- Shem, Ham and Japheth: sons and required ship entrants; their wives become
  separate unnamed Joe identities.
- world: corruption and violence precede the divine destruction decision.
- technology: sealed multi-level gopher-wood ship enters through explicit
  dimensions and construction relations.

## Fuck-up pass

- Noah -> No-Ah Joe continues.
- Nephilim -> Neph-I-Limb Joes.
- gopher wood -> literal Joe-faced gopher presentation; wood relation retained.
- cubit -> elbow-to-finger `CRACKHEAD ARM RULER` background instrument.
- ark/ship -> `CRACKHEAD SHIP SPECIFICATION 001`.
- pitch -> background tin labelled `CRACKHEAD PERFECTLY LEGAL PITCH`.
- covenant -> `COVENANT-ID: OPEN` until later terms emerge.

## FIR verification

- All 22 verse markers are covered in order.
- Population and wife-taking precede the 120-year statement and Nephilim State.
- Observed wickedness/corruption/violence precedes regret and destruction plan.
- No-Ah's favour and history distinguish the preserved family path.
- Every ship dimension, level, opening and sealing requirement is retained.
- Flood announcement precedes covenant and passenger requirements.
- Required inventory is distinguished from observed loading.
- `No-Ah did` closes commanded performance without inventing unseen methods.
- Ambiguous sons-of-God, Nephilim and 120-year identities remain unresolved.
- No contradiction or Captain crack is manufactured.
- Manuscript remains held and unpublished.

Continuation required: Genesis 7 receives clean/unclean animal counts, seven-day
warning, family and animal entry, No-Ah's age, flood chronology, divine door
closure, water rise and death/destruction outcomes.
