# CRACKHEAD GENESIS 11

## Title page

**BUILD IT SO WE DON'T SCATTER. GET SCATTERED FOR BUILDING IT.**

Source parent: Genesis 11:1–32, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 11.

Parent manuscript: `GENESIS/010-NATIONS-INVENTORY.md`.

CrackFlix crossover: `S010 — PREVENTED IT INTO HAPPENING`.

## Causal foundation

```text
WHOLE EARTH: ONE LANGUAGE / ONE SPEECH
-> EASTWARD TRAVEL -> SHINAR PLAIN -> SETTLEMENT
-> BRICKS BURNED + TAR MORTAR
-> CITY/TOWER/NAME PROJECT
-> STATED PURPOSE: PREVENT SCATTERING
-> GOD DESCENDS / INSPECTS
-> ONE PEOPLE + ONE LANGUAGE + BEGINNING CAPABILITY OBSERVED
-> GOD CONFUSES LANGUAGE -> MUTUAL SPEECH NOT UNDERSTOOD
-> GOD SCATTERS POPULATION -> CITY BUILDING STOPS
-> BABEL NAMED FROM CONFUSION/SCATTERING
-> GENESIS 10 LANGUAGE/NATION RESULT NOW HAS PRODUCING PARENT
-> SHEM AGE LINE -> TERAH -> ABRAM/NAHOR/HARAN
-> HARAN DIES; MARRIAGES; SARAI CHILDLESS
-> TERAH HOUSEHOLD LEAVES UR TOWARD CANAAN -> STOPS AT HARAN
-> TERAH DIES AT HARAN
```

## Genesis 11:1–2 — ONE LANGUAGE BEFORE THE INVENTORY

The whole Earth has one language and one speech. The population travels east
(source note: LXX reads from the east), finds a plain in Shinar and lives there.

Genesis 10 catalogued the later plural language/nation State. Genesis 11 opens
the earlier parent State that produces it. The two chapters are not forced into
simultaneous chronology.

Shinar renders **Shin-Argh**, a flat plain covered with Joe-faced shins. Nobody
asks why.

## Genesis 11:3 — CRACKHEAD BRICK TECHNOLOGY

The Joes tell one another to make bricks and burn them thoroughly. Brick
replaces stone; tar replaces mortar.

> **BUILDER JOES:** `BRICK IT. BURN IT PROPERLY.`
>
> `NO STONE? BRICK.`
>
> `NO MORTAR? TAR.`

This creates a material/process inventory: clay source remains unstated; formed
brick, thorough burning and tar-joint use are observed.

## Genesis 11:4 — THE ANTI-SCATTER PROJECT

> **BUILDER JOES:** `CITY.`
>
> `TOWER TO THE SKY.`
>
> `OUR OWN NAME.`
>
> `THEN WE WON'T GET SCATTERED EVERYWHERE.`

The source supplies three project outputs and the explicit anti-scattering
condition. It does not supply tower height, design, labour structure, king,
religion or private motive beyond their own words.

Background permit: `CRACKHEAD TOW-ER — TOWING THE SKY SINCE ISSUE #00011`.

## Genesis 11:5–7 — GOD INSPECTS THE BUILD

God comes down to see the city and tower the human Joes built.

> **CRACKHEAD GOD:** `ONE PEOPLE. ONE LANGUAGE.`
>
> `THIS IS WHAT THEY'VE STARTED.`
>
> `NOW WHAT THEY PLAN WON'T BE WITHHELD FROM THEM.`
>
> `LET'S GO DOWN AND CONFUSE THE LANGUAGE.`
>
> `THEY WON'T UNDERSTAND EACH OTHER.`

The inspection precedes the intervention. The comic does not decide whether
the capability statement is praise, fear, limit theory or another motive.

God-only line trigger: a single-language people has begun the retained project;
God states the capability observation and confusion act at this exact Moment.

## Genesis 11:8–9 — THE PROJECT PRODUCES ITS OPPOSITE

God scatters them from there across the surface of all Earth. They stop building
the city. The place is called Babel because God confused all-Earth language
there and scattered them from there.

Display name: **Babble**, where every speech balloon becomes mutually useless
gibberish. Source identity `Babel` remains the city address.

Completed observable friction:

```text
BUILDERS: BUILD CITY/TOWER SO WE ARE NOT SCATTERED
BUILDERS: BUILD CITY/TOWER
GOD: INSPECTS CITY/TOWER
GOD: CONFUSES LANGUAGE + SCATTERS BUILDERS
```

This creates `S010-E001 — BUILD IT SO WE ARE NOT SCATTERED`.

Captain's eyes clear after scattering completes. He appears boilless in his
unexplained suit.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes a builder's boil, licks his finger, walks away eating the crack crystal
he sees, and never looks back. The Joes cannot coordinate a response. Removing
Captain changes nothing.

## Genesis 11:10–26 — SHEM-TO-TERAH CLOCK

The nation catalogue narrows to the lineage that will produce Abram.

| Joe | Age at named child | Named child | Years afterward | Extra children |
|---|---:|---|---:|---|
| Shem Joe | 100, two years after flood | Arpachshad Joe | 500 | sons/daughters |
| Arpachshad Joe | 35 | Shelah Joe | 403 | sons/daughters |
| Shelah Joe | 30 | Eber Joe | 403 | sons/daughters |
| Eber Joe | 34 | Peleg Joe | 430 | sons/daughters |
| Peleg Joe | 30 | Reu Joe | 209 | sons/daughters |
| Reu Joe | 32 | Serug Joe | 207 | sons/daughters |
| Serug Joe | 30 | Nahor Joe [ancestor] | 200 | sons/daughters |
| Nahor Joe [ancestor] | 29 | Terah Joe | 119 | sons/daughters |
| Terah Joe | 70 | Abram / Nahor / Haran | not stated here | three named sons |

The source does not say all three sons were born in the same year merely because
they share the age-70 verse. Their exact birth order/timing remains unresolved.

The earlier Nahor Joe and Terah's son Nahor Joe are different identities because
their parent roots differ.

## Genesis 11:27–30 — TERAH HOUSEHOLD

Terah fathers Abram Joe, Nahor Joe and Haran Joe. Haran fathers Lot Joe, then
dies in his birth land, Ur of the Chaldees, while Terah remains alive.

Abram marries Sarai Joe. Nahor marries Milcah Joe, daughter of Haran Joe and
sister/line relative to Iscah Joe as stated.

Sarai is barren and has no child. This is an observable reproductive State, not
a motive, fault, diagnosis or permanent future result.

Display labels:

- Ur -> `ERR of the Call-Deez`;
- Lot -> `A LOT JOE`;
- Sarai -> `SORRY JOE` only on a broken AI name badge; source name retained.

## Genesis 11:31–32 — STARTED FOR CANAAN, STOPPED AT HARAN

Terah takes Abram, Lot and Sarai from Ur of the Chaldees intending to go to
Canaan. They reach Haran and live there.

```text
SELECTED DESTINATION: CANAAN
OBSERVED ARRIVAL/SETTLEMENT: HARAN
```

The chapter supplies no statement that the Canaan destination was abandoned.
Genesis 12 must continue the movement.

Terah's total days are 205 years. He dies in Haran.

Person Haran and place Haran are distinct identities despite identical English
spelling. A place does not become a Joe unless production interprets a face on
it; the ledger still does not merge them.

## Nation-ledger closure

Genesis 11 supplies the producing transition for Genesis 10:

```text
ONE LANGUAGE
-> CONFUSION / FAILED MUTUAL UNDERSTANDING
-> SCATTERING
-> PLURAL LANGUAGES / LANDS / NATIONS
```

Specific language names and which family received which speech remain
unresolved. Nation inventories retain plural-language existence without
inventing vocabulary.

## Fuck-up pass

- Shinar -> Shin-Argh.
- Babel -> Babble.
- tower -> Tow-er.
- bricks/mortar -> `CRACKHEAD BRICK SUBSTITUTION STANDARD`.
- Ur -> Err.
- Chaldees -> Call-Deez.
- Lot -> A Lot Joe.
- Haran person/place -> identical label, explicit different identity icons.
- language confusion -> speech balloons remain visible but mutually useless.

## FIR verification

- All 32 verse markers are covered in order.
- One-language State precedes Shinar settlement and construction.
- Material substitution precedes city/tower project.
- Anti-scatter purpose is stated before the act that produces scattering.
- God inspects before confusing and scattering.
- Confusion precedes stopped building and Babel naming.
- Genesis 10 plural inventory now traverses to a Genesis 11 producing parent.
- Every Shem-to-Terah age and child relation is retained.
- Duplicate Nahor and Haran labels do not merge identities.
- Sarai's childless State remains observable and unresolved.
- Ur departure, Canaan intention, Haran arrival and Terah death stay distinct.
- S010 and Captain occur only after completed scattering friction.
- Manuscript remains held and unpublished.

Continuation required: Genesis 12 receives God's call and promises to Abram,
Haran departure at 75, Canaan travel/altars, famine, Egypt wife/sister plan,
Sarai's taking, gifts/plagues, Pharaoh confrontation and expulsion.
