# CRACKHEAD GENESIS 36

## Title page

**ESAU'S WIVES: JUDITH, BASEMATH, MAHALATH.**

**ESAU'S WIVES: ADAH, OHOLIBAMAH, BASEMATH.**

**NO RENAME, DEATH, DIVORCE OR IDENTITY BRIDGE INCLUDED.**

Source parent: Genesis 36:1–43, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 36.

Parent manuscript:
`GENESIS/035-YOUR-NAME-WILL-NOT-BE-JACOB-JACOB-SET-UP-A-PILLAR.md`.

CrackFlix routing:

- new `S039 — THE WIFE LEDGER CHANGED NAMES.`, episode
  `S039-E001-GEN36 — THREE WIVES IN, THREE DIFFERENT WIFE SLOTS OUT`.

Identity overlaps held without forced merger:

- Genesis 26 Basemath daughter of Elon and Genesis 36 Adah daughter of Elon
  occupy similar father/wife relations under different names;
- Genesis 28 Mahalath daughter of Ishmael and sister of Nebaioth and Genesis 36
  Basemath daughter of Ishmael and sister of Nebaioth occupy the same described
  relation under different names;
- Genesis 36 Korah appears among Eliphaz chiefs and among Oholibamah's sons;
- Timna appears as Eliphaz's concubine and Lotan's sister;
- names Anah, Dishon, Timna, Oholibamah, Kenaz and Teman recur across person,
  lineage, chief, family, place or territorial slots.

Same spelling and Joe face do not prove same identity. Different origin does
not prove a rename. Every occurrence retains its supplied parents and relations
until the source supplies an identity bridge.

## Causal foundation

```text
SOURCE IDENTIFIES ESAU AS EDOM
-> SOURCE LISTS THREE CANAAN/ISHMAEL-LINE WIVES
-> THREE WIVES BEAR FIVE NAMED SONS IN CANAAN
-> ESAU TAKES WIVES / SONS / DAUGHTERS / HOUSEHOLD / LIVESTOCK / POSSESSIONS
-> ESAU GOES TO LAND AWAY FROM JACOB
-> REASON SUPPLIED: COMBINED SUBSTANCE TOO GREAT / TRAVEL LAND CANNOT BEAR LIVESTOCK
-> ESAU LIVES IN SEIR HILL COUNTRY
-> SOURCE IDENTIFIES ESAU AS FATHER OF EDOMITES
-> SONS / GRANDSONS / CONCUBINE / MATERNAL BRANCHES LISTED
-> ESAU-LINE CHIEFS LISTED BY MATERNAL BRANCH
-> SEIR-HORITE INHABITANT LINEAGES LISTED
-> ANAH FINDS HOT SPRINGS WHILE FEEDING ZIBEON'S DONKEYS
-> HORITE CHIEFS LISTED
-> EDOM KINGS LISTED AS PRE-ISRAEL-KING SUCCESSION
-> EACH OF SEVEN KINGS DIES / NEXT REIGNS IN HIS PLACE
-> HADAR REIGNS AFTER BAAL HANAN / NO DEATH FOR HADAR STATED
-> ESAU-DERIVED CHIEFS LISTED BY FAMILIES / PLACES / NAMES / HABITATIONS
-> SOURCE CLOSES: ESAU FATHER OF EDOMITES
```

## Genesis 36:1–5 — THE NEW WIFE PAGE

The chapter opens by identifying Esau as Edom and calling the following record
the history of his generations.

It then says Esau took wives from the daughters of Canaan and lists:

- Adah, daughter of Elon the Hittite;
- Oholibamah, daughter of Anah, daughter of Zibeon the Hivite;
- Basemath, daughter of Ishmael and sister of Nebaioth.

The source assigns births:

- Adah bears Eliphaz;
- Basemath bears Reuel;
- Oholibamah bears Jeush, Jalam and Korah.

These five sons are explicitly stated born to Esau in Canaan.

The retained earlier wife ledger says:

```text
GENESIS 26
JUDITH = BEERI HITTITE DAUGHTER = ESAU WIFE
BASEMATH = ELON HITTITE DAUGHTER = ESAU WIFE

GENESIS 28
MAHALATH = ISHMAEL DAUGHTER / NEBAIOTH SISTER
-> ADDED TO ESAU'S EXISTING WIVES
-> JUDITH + BASEMATH REMAIN EXISTING WIVES

GENESIS 36
ADAH = ELON HITTITE DAUGHTER = ESAU WIFE
OHOLIBAMAH = ANAH/ZIBEON HIVITE LINE = ESAU WIFE
BASEMATH = ISHMAEL DAUGHTER / NEBAIOTH SISTER = ESAU WIFE
```

No observed bridge says Judith became Oholibamah, Basemath daughter of Elon
became Adah, Mahalath became Basemath, any wife died, any marriage ended, or
the list changed scope. The manuscript therefore neither merges nor silently
replaces the Joes.

That completes S039:

```text
EARLIER SOURCE: WIVES JUDITH + BASEMATH; MAHALATH ADDED
-> ALL THREE RETAINED AS WIVES
-> LATER SOURCE: ESAU'S WIVES ADAH + OHOLIBAMAH + BASEMATH
-> PARENT RELATIONS MOVE BETWEEN NAMES
-> NO SOURCE IDENTITY-TRANSITION ACT
```

Esau's wife-ledger boil grows into three Joe-faced filing cabinets. Every
drawer is labelled `BASEMATH`, but each label points to a different father.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Everyone sees the completely boilless suited nobody poke the filing-cabinet
boil, lick an empty finger, walk away and never look back. Every wife and child
relation remains exactly where the source placed it.

## Genesis 36:6–8 — TOO MUCH TO LIVE TOGETHER

Esau takes his wives, sons, daughters, all household members, livestock, all
animals and all possessions gathered in Canaan. He goes into a land away from
his brother Jacob.

The source supplies the relation:

```text
ESAU SUBSTANCE + JACOB SUBSTANCE
-> TOO GREAT TO DWELL TOGETHER
-> TRAVEL LAND CANNOT BEAR THEM BECAUSE OF LIVESTOCK
-> ESAU MOVES AWAY
-> ESAU LIVES IN SEIR HILL COUNTRY
```

This is not routed as contradiction. `Too great` and `couldn't bear` are source
statements. The source does not supply acreage, animal counts, grazing rate,
ownership dispute, negotiation, departure date or Jacob speech.

Esau living in Seir does not complete Jacob's Genesis 33 statement that Jacob
would come to Esau at Seir. Jacob's arrival remains unobserved.

The source again states Esau is Edom.

## Genesis 36:9–14 — EDOMITE DESCENT

Esau is identified as father of the Edomites in Seir hill country.

The first descendant branches are retained:

- Adah -> Eliphaz -> Teman, Omar, Zepho, Gatam, Kenaz;
- Timna, concubine to Eliphaz -> Amalek;
- Basemath -> Reuel -> Nahath, Zerah, Shammah, Mizzah;
- Oholibamah -> Jeush, Jalam, Korah.

The text calls Timna's child Amalek part of Adah's descendant branch. It does
not name Timna's parents at that point. Verse 22 later calls Lotan's sister
Timna. Same name is retained as an overlap candidate, not proof of one Joe.

Every named descendant has Joe's face. Maternal branch, parent edge and birth
act keep the identities separate.

## Genesis 36:15–19 — THE ESAU CHIEFS

The source assigns chief status by branch:

- Eliphaz/Adah branch: Teman, Omar, Zepho, Kenaz, Korah, Gatam, Amalek;
- Reuel/Basemath branch: Nahath, Zerah, Shammah, Mizzah;
- Oholibamah branch: Jeush, Jalam, Korah.

Korah appears in two branch lists. The source does not say one Korah moved,
held two maternal relations, or that the two are distinct. The ledger retains
`Korah-of-Eliphaz-list` and `Korah-of-Oholibamah` as separate addressable
occurrences with identity equivalence unresolved.

The repeated name alone is not crack. No Captain appears.

These are called the sons and chiefs of Esau/Edom. Chief status does not erase
the supplied wife/mother branch.

## Genesis 36:20–30 — SEIR AND THE HORITES

The chapter switches Root from Esau's descendants to Seir the Horite and the
land's inhabitants.

Seir's listed sons/chiefs are Lotan, Shobal, Zibeon, Anah, Dishon, Ezer and
Dishan. Their retained branches are:

- Lotan -> Hori, Heman; Lotan's sister: Timna;
- Shobal -> Alvan, Manahath, Ebal, Shepho, Onam;
- Zibeon -> Aiah, Anah;
- Anah -> Dishon, Oholibamah;
- Dishon -> Hemdan, Eshban, Ithran, Cheran;
- Ezer -> Bilhan, Zaavan, Akan;
- Dishan -> Uz, Aran.

The source singles out Anah son of Zibeon:

```text
ANAH FEEDS ZIBEON'S DONKEYS IN WILDERNESS
-> ANAH FINDS HOT SPRINGS
```

No search plan, ownership claim, water use, temperature, mechanism or public
announcement is supplied. The donkeys are living Joe-faced donkeys and remain
distinct individuals despite unresolved count.

The seven Seir sons are then listed as Horite chiefs according to their chiefs
in Seir. Similar spellings `Dishon` and `Dishan` remain different source names.

## Genesis 36:31–39 — KINGS BEFORE ISRAEL'S KINGS

The source explicitly frames this as kings who reigned in Edom before any king
reigned over the children of Israel. That is a source-present chronological
comparison, not dialogue from a Genesis 36 character.

The succession is:

1. Bela son of Beor, city Dinhabah;
2. Bela dies -> Jobab son of Zerah of Bozrah reigns in his place;
3. Jobab dies -> Husham of Temanite land reigns in his place;
4. Husham dies -> Hadad son of Bedad reigns in his place; Hadad struck Midian
   in Moab's field; city Avith;
5. Hadad dies -> Samlah of Masrekah reigns in his place;
6. Samlah dies -> Shaul of Rehoboth by the river reigns in his place;
7. Shaul dies -> Baal Hanan son of Achbor reigns in his place;
8. Baal Hanan dies -> Hadar reigns in his place; city Pau; wife Mehetabel,
   daughter of Matred, daughter of Mezahab.

Seven death-to-successor edges are explicit. Hadar's death is not stated.
No hereditary relation between successive kings is inferred merely from
`reigned in his place`. Jobab's father Zerah is not silently merged with
Reuel's son Zerah.

The king inventory supplies no coronation, election, conquest, reign length,
law, tax, palace or reason for succession.

## Genesis 36:40–43 — CHIEFS BY HABITATION

The closing chief inventory is organized according to families, places, names
and habitations in the land of possession:

- Timna, Alvah, Jetheth;
- Oholibamah, Elah, Pinon;
- Kenaz, Teman, Mibzar;
- Magdiel, Iram.

These labels overlap earlier personal names. The source does not provide enough
relations to identify each closing chief with an earlier person, descendant,
family or place. Each remains separately addressed in the closing territorial
inventory.

The chapter closes by identifying these as Edom chiefs and Esau as father of
the Edomites.

## Joe continuity ledger

- Esau and Edom remain one Joe/name relation.
- Judith daughter of Beeri, Basemath daughter of Elon and Mahalath daughter of
  Ishmael retain their earlier identity Roots.
- Adah daughter of Elon, Oholibamah daughter of Anah/Zibeon and Basemath
  daughter of Ishmael enter as source-described Genesis 36 wife identities.
- no same-face or same-name overlap authorizes merging wives, Korahs, Timnas,
  Anahs, Dishons, Zerahs, chiefs, cities or territories.
- Esau's sons, daughters, household members and animals all have Joe faces;
  unnamed groups retain distinct roles.
- all five sons, nine named grandsons, Amalek, Esau chiefs, Horite branches,
  kings, king relations and territorial chiefs remain traceable.
- Hadar remains reigning at the final king-list State because no death or
  successor is stated.
- Captain remains boilless and changes nothing.

## Bullshit pass

- banner: `THE CRACKHEAD BIBLE — ARTICLE 36 — EDOM SPREADSHEET INCIDENT`;
- wife database warning: `SAME NAME DOES NOT MATCH PRIMARY KEY`;
- CrackFlix tile: `S039 / RELATIONAL DATABASE WITHOUT RELATIONS`;
- Seir land sign: `CAPACITY EXCEEDED — MOVE ONE ENTIRE HOUSEHOLD`;
- Anah's hot springs label: `CRACKHEAD GEOTHERMAL DONKEY DISCOVERY PROGRAM`;
- king ledger: `DIED -> REIGNED IN HIS PLACE`, repeated seven times by a
  Joe-faced rubber stamp;
- barcode: `CHB-GEN36-S039-EDOM-43-YOINK`;
- footer: `BIG BAG GENEALOGY — DUPLICATE DISPLAY NAMES PERMITTED`.

## Reconstruction boundary

- all 43 source verse markers are represented in ordered lineage/state blocks;
- wife relations from Genesis 26, 28 and 36 remain as separate source parents;
- S039 records the missing identity transition without selecting which names
  refer to the same people;
- every same-name overlap remains unresolved unless a parent/effect bridge is
  explicit;
- Esau's move is sourced to capacity/livestock and is not moralized;
- Jacob's Seir arrival statement remains open;
- Genesis 35 Reuben/Bilhah and divine-promise chains remain open and are not
  imported into Esau's genealogy;
- no direct God speech, divine act or divine approval occurs in Genesis 36;
- death and succession edges are exact; Hadar is not declared dead;
- publication remains held and unpublished.

Continuation required: Genesis 37 returns to Jacob's household with Joseph's
report, robe, dreams, brother hostility, pit, sale/transfer and Jacob's mourning.
