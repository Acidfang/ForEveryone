# CRACKHEAD GENESIS 18

## Title page

**I DIDN'T LAUGH.**

Source parent: Genesis 18:1–33, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 18.

Parent manuscript: `GENESIS/017-NEW-NAMES-CUT-THE-HOUSE.md`.

CrackFlix: `S013 — I DIDN'T DO THAT.`, episode
`S013-E001-GEN18 — I DIDN'T LAUGH`.

## Causal foundation

```text
LORD APPEARS BY MAMRE OAKS + ABRAHAM AT TENT DOOR
-> ABRAHAM SEES THREE MEN -> RUNS / BOWS / INVITES
-> WATER + REST + BREAD OFFER ACCEPTED
-> SARAH MAKES CAKES + SERVANT DRESSES CALF
-> BUTTER / MILK / CALF SERVED -> VISITORS EAT
-> SARAH LOCATION QUESTION -> TENT ANSWER
-> NEXT-YEAR SON STATEMENT -> SARAH HEARS
-> OLD / PAST CHILDBEARING STATE
-> SARAH LAUGHS
-> LORD ASKS WHY SHE LAUGHED + RESTATES SON PROMISE
-> SARAH SAYS "I DIDN'T LAUGH"
-> SPEAKER SAYS "YOU DID LAUGH"
-> MEN RISE / LOOK TOWARD SODOM -> ABRAHAM ESCORTS
-> LORD STATES ABRAHAM/FUTURE-HOUSEHOLD RELATION
-> SODOM/GOMORRAH CRY AND SIN REPORT
-> LORD STATES DESCENT / INSPECTION / KNOWLEDGE TEST
-> MEN GO TOWARD SODOM; ABRAHAM REMAINS BEFORE LORD
-> RIGHTEOUS/WICKED QUESTION
-> THRESHOLD 50 -> 45 -> 40 -> 30 -> 20 -> 10
-> EACH THRESHOLD RECEIVES NON-DESTRUCTION COMMITMENT
-> LORD LEAVES AFTER COMMUNING
-> ABRAHAM RETURNS TO HIS PLACE
```

## Genesis 18:1–5 — THREE MEN AT MAMRE

The LORD appears to Abraham by Mamre's oaks while Abraham sits at his tent door
in the day's heat. Abraham looks up and sees three men standing near him. He
runs from the door, meets them and bows to the earth.

> **ABRAHAM JOE:** `MY LORD, IF I HAVE FOUND FAVOR IN YOUR SIGHT, PLEASE DON'T
> PASS BY YOUR SERVANT.`
>
> `LET A LITTLE WATER BE FETCHED. WASH YOUR FEET. REST UNDER THE TREE.`
>
> `I'LL GET BREAD. REFRESH YOUR HEARTS. THEN GO YOUR WAY.`

> **VISITOR JOES:** `VERY WELL. DO AS YOU SAID.`

The source opens with the LORD's appearance, then describes three men. It does
not provide a visitor-by-visitor identity map. Every visitor has Joe's face;
the manuscript does not manufacture three gods, one disguised person or an
anatomical merger.

## Genesis 18:6–8 — A PIECE OF BREAD

Abraham hurries to Sarah.

> **ABRAHAM JOE:** `QUICKLY. THREE SEAHS OF FINE MEAL. KNEAD IT. MAKE CAKES.`

Three seahs is about 21 litres by the source footnote. Abraham runs to the herd,
takes a tender good calf and gives it to a servant, who hurries to dress it.
Abraham sets butter, milk and the dressed calf before the visitors. He stands
under the tree while they eat.

The promised `piece of bread` becomes cakes, calf, butter and milk. That is an
observable expansion, but no punishment, complaint or incompatible rule closes;
it is not forced into a contradiction series.

Background menu: `CRACKHEAD LITTLE BREAD COMBO — INCLUDES 21 LITRES OF FLOUR
AND ONE ENTIRE CALF`.

## Genesis 18:9–10 — WHERE IS SARAH?

> **VISITOR JOES:** `WHERE IS SARAH, YOUR WIFE?`

> **ABRAHAM JOE:** `THERE. IN THE TENT.`

One speaker says he will certainly return about this time next year and Sarah
will have a son. Sarah hears from the tent door behind him.

The singular speaker is not assigned a visitor number. The next-year promise
continues Genesis 17 without completing the birth.

## Genesis 18:11–15 — I DIDN'T LAUGH

Abraham and Sarah are old and advanced in age. Sarah is past the age of
childbearing. Sarah laughs within herself.

The source also supplies an internal sentence about age and pleasure. The fly
does not hear it, so it stays source-retained rather than becoming dialogue.

> **CRACKHEAD GOD:** `WHY DID SARAH LAUGH?`
>
> `IS ANYTHING TOO HARD FOR THE LORD?`
>
> `AT THE SET TIME I WILL RETURN. SARAH WILL HAVE A SON.`

> **SARAH JOE:** `I DIDN'T LAUGH.`

> **CRACKHEAD GOD:** `NO. YOU DID LAUGH.`

The source states Sarah denied it because she was afraid. That causal statement
is retained as source testimony; no facial expression, secret motive or extra
fear behaviour is invented.

The contradiction completes when the retained laugh is followed by Sarah's
denial. The correction does not erase either Moment.

Sarah turns toward the reader.

> **SARAH JOE:** `I DIDN'T MEAN THAT.`

*shrug*

Sarah's largest boil opens one Joe-faced eye.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes it, licks his finger, walks away and does not look back. Captain sees a
crack crystal. Everyone else sees the poke and lick. Nothing changes.

This is S013's first retained episode. There is no `SKIP`.

## Genesis 18:16–22 — REPORT, THEN INSPECTION

The men rise, look toward Sodom and begin traveling. Abraham goes with them to
see them on their way.

The LORD states that Abraham will become a great and mighty nation and that all
nations will be blessed in him. The stated chain continues through Abraham
commanding his children and household to keep the LORD's way, doing
righteousness and justice, so the LORD may bring what was spoken.

The LORD then states:

> **CRACKHEAD GOD:** `THE CRY OF SODOM AND GOMORRAH IS GREAT.`
>
> `THEIR SIN IS VERY GRIEVOUS.`
>
> `I WILL GO DOWN AND SEE WHETHER THEIR DEEDS MATCH THE REPORT.`
>
> `IF NOT, I WILL KNOW.`

Report precedes inspection. The report source, reported deeds and inspection
result are not yet supplied. Genesis 19 must close what actually happens.

The men turn and go toward Sodom. Abraham remains before the LORD. The chapter
does not resolve the visitor/LORD identity map that it did not supply earlier.

## Genesis 18:23–26 — FIFTY

Abraham comes near.

> **ABRAHAM JOE:** `WILL YOU CONSUME THE RIGHTEOUS WITH THE WICKED?`
>
> `WHAT IF FIFTY RIGHTEOUS JOES ARE IN THE CITY?`
>
> `SHOULDN'T THE JUDGE OF ALL THE EARTH DO RIGHT?`

> **CRACKHEAD GOD:** `IF I FIND FIFTY RIGHTEOUS JOES IN SODOM, I WILL SPARE THE
> WHOLE PLACE FOR THEIR SAKE.`

Abraham's question distinguishes population classes before the destruction
decision. It does not assert that fifty have been found.

## Genesis 18:27–32 — CRACKHEAD DESTRUCTION DISCOUNT

Abraham identifies himself as dust and ashes and lowers the proposed count.
Each offer receives its own answer:

| Proposed righteous count | LORD's stated result |
|---:|---|
| 45 | will not destroy if 45 are found |
| 40 | will not do it for 40's sake |
| 30 | will not do it if 30 are found |
| 20 | will not destroy for 20's sake |
| 10 | will not destroy for 10's sake |

Abraham twice asks that the Lord not be angry and says he will speak again. The
sequence stops at ten. No source line states why Abraham stops, how many
righteous residents exist or whether any threshold has been met.

Crackhead signage updates after every answer:

`CITY-SAVING MINIMUM: 50 / 45 / 40 / 30 / 20 / 10 — STOCK NOT YET COUNTED`.

This is negotiation by conditional restatement, not contradiction. Every lower
threshold is a later accepted condition; it does not make the earlier answer
false at its Moment.

## Genesis 18:33 — BOTH LEAVE

The LORD goes his way after communing with Abraham. Abraham returns to his
place.

The negotiation is closed. Sodom's inspection, population test and outcome
remain unresolved until the next chapter.

## Character and world-ledger changes

- Abraham: provides visitor hospitality, directs meal preparation, stands while
  they eat, reports Sarah's location, escorts visitors, receives Sodom report,
  asks righteous/wicked question and negotiates threshold from fifty to ten.
- Sarah: prepares cakes, hears next-year promise, laughs, denies laughing and is
  directly corrected; no invented internal dialogue is rendered.
- three visitor men: accept hospitality, eat, ask Sarah's location, rise and
  travel toward Sodom; individual identity mapping remains unresolved.
- unnamed servant: receives calf and hurries to dress it; no name, origin,
  clothing or speech supplied.
- Sodom and Gomorrah population: great cry and grievous sin are reported;
  inspection and righteous count remain open.
- Abraham's future household: receives a future righteousness/justice teaching
  relation through the LORD's statement; it is not yet observed execution.

## Fuck-up pass

- Mamre -> `MAM-RAY OAKS`, each acorn with Joe's face.
- three seahs -> three literal Joe-faced seas poured into the flour bowl.
- tender calf -> `CRACKHEAD TENDER PROCUREMENT CALF / NO TENDER ATTACHED`.
- Sodom -> `SOD 'EM`, on a turf-company city map.
- Gomorrah -> `GO-MORE-AH`, pointing farther away every time it is read.
- righteous threshold -> `CRACKHEAD BULK SALVATION PRICING`.
- dust and ashes -> Abraham's customer-account tier.
- visitor departure -> `THANK YOU FOR EATING / INSPECTION TEAM THIS WAY`.

## FIR verification

- All 33 verse markers are covered in order.
- LORD appearance, three-men description and singular/plural speech changes are
  retained without invented identity mapping.
- Invitation precedes preparation, food precedes eating, and eating precedes
  the Sarah inquiry.
- Sarah hears the promise before laughing; laughter precedes denial; denial
  precedes correction.
- S013 uses only the retained act and later denial. Source-reported internal
  speech/fear is not substituted for fly observation.
- Captain appears only after contradiction completion, says only `YOINK!`, is
  boilless and changes nothing.
- First S013 episode has no `SKIP`.
- Sodom/Gomorrah report precedes announced inspection; no Genesis 19 outcome is
  imported.
- Thresholds remain ordered 50, 45, 40, 30, 20, 10 with every response retained.
- Conditional threshold revisions are not misclassified as contradiction.
- Manuscript remains held and unpublished.

Continuation required: Genesis 19 receives two angels at Sodom, Lot's
hospitality, city-men demand, attempted substitution, threatened breach,
angelic extraction, destruction, Zoar, pillar-of-salt event and Moab/Ammon
conceptions.
