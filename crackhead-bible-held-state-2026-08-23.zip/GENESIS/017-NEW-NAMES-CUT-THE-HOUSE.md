# CRACKHEAD GENESIS 17

## Title page

**NEW NAMES. CUT THE WHOLE HOUSE.**

Source parent: Genesis 17:1–27, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 17.

Parent manuscript: `GENESIS/016-I-GAVE-HER-YOUR-FAULT.md`.

CrackFlix crossover: none closed in this chapter.

## Causal foundation

```text
ABRAM AGE 99
-> LORD APPEARS: GOD ALMIGHTY / WALK / BLAMELESS / COVENANT / MULTIPLY
-> ABRAM FALLS FACE-DOWN
-> MULTINATIONAL FATHER PROMISE
-> ABRAM NAME ENDS -> ABRAHAM NAME BEGINS
-> FRUITFULNESS / NATIONS / KINGS / GENERATIONAL COVENANT / CANAAN PROMISE
-> COVENANT-KEEPING REQUIREMENT
-> EVERY MALE CIRCUMCISED
-> EIGHTH-DAY + HOUSE-BORN + MONEY-BOUGHT SCOPE
-> UNCIRCUMCISED-MALE CUT-OFF CONSEQUENCE
-> SARAI NAME ENDS -> SARAH NAME BEGINS
-> SARAH SON / NATIONS / KINGS PROMISE
-> ABRAHAM FALLS FACE-DOWN AND LAUGHS
-> SOURCE REPORTS INTERNAL AGE QUESTIONS
-> ABRAHAM ASKS FOR ISHMAEL
-> GOD DISTINGUISHES ISAAC COVENANT FROM ISHMAEL BLESSING
-> ISAAC NEXT-YEAR SET TIME
-> GOD FINISHES AND GOES UP
-> SAME-DAY HOUSEHOLD EXECUTION
-> ABRAHAM 99 + ISHMAEL 13 + EVERY HOUSE MALE CIRCUMCISED
```

## Genesis 17:1–2 — AGE 99

When Abram is 99, the LORD appears.

> **CRACKHEAD GOD:** `I AM GOD ALMIGHTY.`
>
> `WALK BEFORE ME. BE BLAMELESS.`
>
> `I WILL MAKE MY COVENANT BETWEEN ME AND YOU.`
>
> `I WILL MULTIPLY YOU EXCEEDINGLY.`

The age is current State. The multiplication remains promised State.

## Genesis 17:3–8 — ABRAM → ABRAHAM

Abram falls on his face. God states the covenant:

- Abram will father a multitude of nations;
- he will no longer be called Abram;
- his name will be Abraham because God has made him father of a multitude;
- nations and kings will come from him;
- the covenant will continue through his offspring's generations;
- Canaan, where Abraham is traveling, is promised as everlasting possession;
- God will be God to Abraham and his offspring.

This is one Joe with a changed source name, not a replacement Joe.

The `have made` wording and still-future nations remain together. The manuscript
does not invent already-existing descendants to make the tense uniform.

The title card attempts an official update:

`CRACKHEAD IDENTITY LEDGER: ABRAM + HA = ABRAHAM / FACE FIELD UNCHANGED: JOE`.

## Genesis 17:9–14 — COVENANT IN THE FLESH

God requires Abraham and his offspring to keep the covenant. Every male is to
be circumcised in the flesh of the foreskin as its token.

The scope includes:

- every male at eight days old through the generations;
- every male born in the house;
- every male bought with money from a foreigner who is not Abraham's offspring.

The uncircumcised male is to be cut off from his people for breaking the
covenant.

The text records household ownership and requires the act across that boundary.
It records no individual speech or consent from the house-born or money-bought
men. No modern consent, medical, legal or moral conclusion is inserted into the
source event; the missing speech remains missing.

The covenant sign is not the covenant's cause. Command precedes execution.

Background equipment: `CRACKHEAD EVERLASTING COVENANT ENROLMENT — CUT-OFF CLAUSE
MAY ALSO CUT YOU OFF`.

## Genesis 17:15–16 — SARAI → SARAH

> **CRACKHEAD GOD:** `DO NOT CALL YOUR WIFE SARAI.`
>
> `HER NAME IS SARAH.`
>
> `I WILL BLESS HER AND GIVE YOU A SON BY HER.`
>
> `SHE WILL BE A MOTHER OF NATIONS. KINGS WILL COME FROM HER.`

Sarai Joe becomes Sarah Joe. Her retained Hagar history, marriage, kinship and
life Moments remain attached to the same identity.

God addresses Abraham about the name. The source records no Sarah speech or
observed reception in this chapter.

## Genesis 17:17–18 — THE LAUGH AND THE REQUEST

Abraham falls on his face and laughs.

The source reports that Abraham says in his heart whether a child will be born
to a hundred-year-old man and whether 90-year-old Sarah will give birth. A fly
cannot hear that sentence. It remains in the source ledger but is not converted
into spoken comic dialogue or used as an observed contradiction.

Abraham then speaks to God:

> **ABRAHAM JOE:** `OH, THAT ISHMAEL MIGHT LIVE BEFORE YOU!`

The laugh precedes the spoken Ishmael request. The manuscript does not decide
whether one explains the other.

## Genesis 17:19–21 — TWO SONS, DISTINCT STATES

> **CRACKHEAD GOD:** `NO. SARAH WILL BEAR YOU A SON.`
>
> `CALL HIM ISAAC.`
>
> `I WILL ESTABLISH MY EVERLASTING COVENANT WITH HIM AND HIS OFFSPRING.`
>
> `AS FOR ISHMAEL: I HAVE HEARD YOU.`
>
> `I HAVE BLESSED HIM. I WILL MAKE HIM FRUITFUL AND MULTIPLY HIM.`
>
> `HE WILL FATHER TWELVE PRINCES. I WILL MAKE HIM A GREAT NATION.`
>
> `BUT I WILL ESTABLISH MY COVENANT WITH ISAAC.`
>
> `SARAH WILL BEAR HIM AT THIS SET TIME NEXT YEAR.`

Isaac means `he laughs`. The promise produces a named future Joe, not a current
birth. Ishmael's blessing is affirmed while the covenant line is assigned to
Isaac. Neither branch is deleted to simplify the other.

## Genesis 17:22 — CONVERSATION CLOSED

God finishes talking and goes up from Abraham.

That observable departure closes the speech event. No portal specification,
altitude or transport system is supplied. Production labels the empty sky
`CRACKHEAD ASCENSION EXIT — THIS WAY UP`, and the arrow has Joe's face.

## Genesis 17:23–27 — SAME DAY

On that same day Abraham takes:

- Ishmael;
- all males born in his house;
- all males bought with his money;
- every male among the men of his house.

He circumcises them as God said. Abraham is 99. Ishmael is 13. Abraham and
Ishmael are circumcised the same day, and every house-born and money-bought male
is circumcised with him.

The repeated `same day` statements establish execution timing. They are not
duplicate occurrences to skip: verses 23–27 progressively identify membership,
ages and completion of the one household event.

No procedure, instrument, operator distribution, wound care or reaction is
specified. The comic may show a closed `CRACKHEAD COVENANT COMPLIANCE TENT` and
the before/after attendance ledger. It must not fabricate bodily detail.

## Character and world-ledger changes

- Abram/Abraham: same Joe; name changes at 99; receives multinational covenant,
  land and circumcision terms; laughs; speaks Ishmael request; hears Isaac and
  Ishmael branch distinction; executes household command the same day.
- Sarai/Sarah: same Joe; name changes by divine statement; receives promised
  blessing, son, nations and kings; no chapter speech retained.
- Ishmael: age 13; Abraham requests life-before-God for him; receives blessing,
  fruitfulness, twelve-prince and great-nation promise; circumcised same day.
- Isaac: named future son of Abraham and Sarah; next-year birth and everlasting
  covenant promised; not yet born.
- Abraham's house males: house-born and money-bought membership made explicit;
  all undergo the commanded same-day act without retained individual speech.
- Canaan: reaffirmed as promised possession while Abraham is still described as
  traveling there.

## Fuck-up pass

- Abram -> Abraham through `CRACKHEAD NAME EXPANSION PACK: +HA`.
- Sarai -> Sarah through `CRACKHEAD TERMINAL LETTER REPLACEMENT: I/O -> H`.
- God Almighty -> `CRACKHEAD ALL-MIGHTY SERVICE ACCOUNT`.
- circumcision -> `SIR-COME-DECISION`, printed on an irreversible decision form.
- Isaac -> `EYE-SACK JOE`; the sack has Joe's face.
- twelve princes -> `CRACKHEAD ROYAL MULTIPACK — 12, CONTENTS PENDING`.
- everlasting possession -> warranty card with no present-delivery checkbox.
- household ledger barcode -> `GEN17-ALL-MALES-SAME-DAY-NO-SKIP`.

## FIR verification

- All 27 verse markers are covered in order.
- Abram/Abraham and Sarai/Sarah remain continuous identities across name change.
- Promise, token requirement, noncompliance consequence and same-day execution
  remain distinct causal States.
- House-born and money-bought men remain within the source scope; their absent
  speech is not replaced.
- Abraham's visible laugh is retained; source-reported heart speech is not
  misrepresented as fly-observed dialogue.
- Isaac's future identity is not treated as a completed birth.
- Ishmael blessing and Isaac covenant are both retained without merger.
- Repeated same-day verses remain elaborations of one occurrence, not SKIP
  candidates.
- No social contradiction, CrackFlix episode or Captain appearance is invented.
- Manuscript remains held and unpublished.

Continuation required: Genesis 18 receives the Mamre visitors, meal service,
Sarah's laugh and denial, Abraham's Sodom inquiry, and the descending population
threshold from fifty to ten.
