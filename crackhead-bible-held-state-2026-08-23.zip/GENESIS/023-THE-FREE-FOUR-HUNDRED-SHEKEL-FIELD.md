# CRACKHEAD GENESIS 23

## Title page

**I GIVE IT TO YOU. THAT WILL BE FOUR HUNDRED SHEKELS.**

Source parent: Genesis 23:1–20, ENGWEBP USFM.

Source file: `source/engwebp-usfm/02-GENengwebp.usfm`, chapter 23.

Parent manuscript: `GENESIS/022-YOUR-ONLY-SON-THE-OTHER-ONE-LIVES.md`.

CrackFlix: `S016 — I GIVE IT TO YOU. THAT WILL BE 400.`, episode
`S016-E001-GEN23 — THE FREE FOUR-HUNDRED-SHEKEL FIELD`.

## Causal foundation

```text
SARAH LIFE LENGTH 127 -> DEATH AT KIRIATH ARBA / HEBRON
-> ABRAHAM MOURNS / WEEPS
-> ABRAHAM RISES FROM BEFORE DEAD
-> STRANGER/FOREIGNER STATUS DECLARED
-> BURIAL-POSSESSION REQUEST TO HETH
-> HETH CALLS ABRAHAM GOD'S PRINCE / OFFERS BEST TOMBS
-> ABRAHAM BOWS
-> REQUESTS EPHRON / MACHPELAH CAVE AT FULL PRICE
-> EPHRON PUBLICLY SAYS FIELD + CAVE GIVEN
-> ABRAHAM BOWS / REPEATS PRICE OFFER
-> EPHRON NAMES 400-SHEKEL VALUE
-> ABRAHAM WEIGHS 400 SHEKELS TO EPHRON
-> FIELD + CAVE + ALL BORDER TREES DEEDED
-> HETH / CITY-GATE WITNESSES RETAINED
-> ABRAHAM BURIES SARAH IN MACHPELAH CAVE
-> FIELD/CAVE REAFFIRMED AS BURIAL POSSESSION
```

## Genesis 23:1–2 — SARAH DIES AT 127

Sarah's life lasts 127 years. She dies at Kiriath Arba, also called Hebron, in
Canaan. Abraham comes to mourn and weep for her.

Death, arrival, mourning and weeping are separate observable States. The source
does not provide Sarah's cause of death, final words, burial instruction or
Abraham's internal thoughts.

Sarah remains the same Joe whose Sarai/Sarah, Hagar, sister/wife, laughter and
Isaac histories were retained. Death changes her living State; it does not
replace her with `dead Sarah` as a new identity.

No comedy is placed on Sarah's body or Abraham's mourning. The background
continuity stamp merely reads: `SARAH JOE — LIFE LEDGER CLOSED AT 127`.

## Genesis 23:3–6 — I NEED A BURIAL POSSESSION

Abraham rises from before his dead and addresses the children of Heth:

> **ABRAHAM JOE:** `I AM A STRANGER AND FOREIGNER LIVING WITH YOU.`
>
> `GIVE ME A POSSESSION FOR A BURIAL PLACE.`
>
> `THEN I CAN BURY MY DEAD OUT OF MY SIGHT.`

> **CHILDREN OF HETH JOES:** `YOU ARE A PRINCE OF GOD AMONG US.`
>
> `BURY YOUR DEAD IN THE BEST OF OUR TOMBS.`
>
> `NONE OF US WILL WITHHOLD A TOMB FROM YOU.`

Their tomb-access response does not yet establish Abraham's requested property
possession. Use permission and deeded ownership remain distinct.

## Genesis 23:7–9 — FULL PRICE REQUESTED

Abraham rises, bows to the people of the land and asks them to entreat Ephron
son of Zohar.

> **ABRAHAM JOE:** `LET EPHRON SELL ME MACHPELAH'S CAVE.`
>
> `IT IS AT THE END OF HIS FIELD.`
>
> `LET HIM SELL IT AT FULL PRICE, HERE AMONG YOU, AS MY BURIAL POSSESSION.`

The requested object is initially the cave. The requested process is explicitly
a witnessed full-price sale.

## Genesis 23:10–11 — I GIVE YOU THE FIELD

Ephron the Hittite is sitting among Heth's children. He answers publicly before
everyone entering his city gate:

> **EPHRON JOE:** `NO, MY LORD. HEAR ME.`
>
> `I GIVE YOU THE FIELD.`
>
> `I GIVE YOU THE CAVE IN IT.`
>
> `BEFORE MY PEOPLE, I GIVE IT TO YOU.`
>
> `BURY YOUR DEAD.`

The offer expands cave to field plus cave and repeats `give` three times. At
this Moment no money has moved and no deeded-transfer statement has closed.

## Genesis 23:12–16 — WHAT IS 400 SHEKELS BETWEEN US?

Abraham bows before the people and answers Ephron publicly:

> **ABRAHAM JOE:** `I WILL GIVE THE FIELD'S PRICE.`
>
> `TAKE IT FROM ME. I WILL BURY MY DEAD THERE.`

> **EPHRON JOE:** `MY LORD, LISTEN.`
>
> `WHAT IS LAND WORTH FOUR HUNDRED SHEKELS OF SILVER BETWEEN ME AND YOU?`
>
> `BURY YOUR DEAD.`

The source footnote estimates four hundred shekels as about four kilograms or
8.8 pounds of silver.

Abraham listens and weighs to Ephron the exact silver Ephron named publicly:
four hundred shekels by the current merchants' standard.

That completed payment closes S016:

```text
EPHRON: I GIVE FIELD + CAVE
EPHRON: LAND IS WORTH 400 SHEKELS
ABRAHAM: WEIGHS 400 SHEKELS TO EPHRON
NEXT STATE: PAID DEED
```

No motive, bargaining custom or sarcasm is required. `Give` and the actual
price-required transfer process are both observable.

Ephron's merchant-standard status boil grows a tiny weighing scale with Joe's
face.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Poke. Lick finger. Walk away. No look back. The silver remains weighed, the
witnesses remain present and title still transfers.

This is S016's first retained episode. There is no `SKIP`.

## Genesis 23:17–18 — WHAT THE DEED CONTAINS

After payment, Ephron's Machpelah property before Mamre is deeded to Abraham:

- the field;
- the cave in the field;
- every tree in the field;
- every tree within all its borders.

The transfer occurs in the presence of Heth's children and everyone entering
the city gate.

The trees are living Joes and each has Joe's face somewhere the generator thinks
a tree face belongs. That production garbage does not change the border or deed.

The chapter supplies no written tablet, survey units, signatures, tax, future
access rule or merchant-standard definition. Public hearing, weighed payment,
listed assets and witnessed possession are the retained transfer mechanism.

## Genesis 23:19–20 — BURIAL AND REAFFIRMATION

After the deed, Abraham buries Sarah in the cave of Machpelah's field before
Mamre—Hebron—in Canaan.

The chapter closes by reaffirming that Heth's children deeded the field and cave
to Abraham as a burial-place possession.

```text
PROPERTY FIRST
-> BURIAL SECOND
-> PROPERTY PURPOSE REAFFIRMED
```

The source does not record who closes the cave, a funeral attendance list,
further mourning, or any speech at burial.

## Character and world-ledger changes

- Sarah: dies at age 127 at Kiriath Arba/Hebron; living State closes; buried at
  Machpelah after property transfer.
- Abraham: mourns/weeps; states stranger/foreigner status; requests owned burial
  place; negotiates full-price cave/field purchase; weighs four hundred shekels;
  receives witnessed title; buries Sarah.
- Ephron: identified as Hittite son of Zohar; publicly offers/gives field and
  cave; names four-hundred-shekel value; receives weighed silver; property is
  deeded from his holding.
- Zohar: enters as Ephron's named father; no additional history or speech.
- children of Heth: call Abraham God's prince, offer tomb access, mediate/witness
  negotiation and establish deeded burial possession.
- city-gate entrants: witness the public offer, price, payment and title.
- Machpelah field/cave/trees: move from Ephron's holding to Abraham's burial
  possession with borders and components retained.
- Kiriath Arba/Hebron/Mamre: source place-name relations remain explicit without
  importing modern coordinates.

## Fuck-up pass

- Kiriath Arba -> `CARRY-AT-ARBOUR`, a funeral-direction sign pointing at trees.
- Heth -> `HEALTH JOES`, running a burial-property desk.
- Ephron -> `E-FRONT JOE`, seated at the front of the city-gate transaction.
- Zohar -> `SO-HARD JOE`, because giving things for 400 shekels is difficult.
- Machpelah -> `MATCH-PLAYER CAVE`, property-matching service with one listing.
- four hundred shekels -> `CRACKHEAD COMPLIMENTARY PRICE: 400`.
- current merchants' standard -> a current electrical meter weighing silver.
- all border trees -> Joe-faced living boundary posts trying to stay inside the deed.
- title receipt -> `GIFT PURCHASE COMPLETED / AMOUNT FREE: 400 SHEKELS`.

## God-line boundary

No God or divine-messenger speech/action occurs in Genesis 23. No God-only line
is invented merely because Heth's children call Abraham a `prince of God`.

## FIR verification

- All 20 verse markers are covered in order.
- Sarah's death precedes mourning; mourning precedes burial negotiation.
- Tomb-use offer is not mistaken for owned burial possession.
- Abraham requests full-price sale before Ephron's gift language.
- S016 closes only after Ephron names value, Abraham weighs payment and paid deed
  follows; motive/custom is not invented.
- Field, cave, every tree and all borders remain in the property object.
- Public Heth/city-gate witness boundary is retained.
- Payment/title precede Sarah's burial.
- Captain appears after the paid contradiction completes, says only `YOINK!`,
  is boilless and changes nothing.
- No God line, SKIP or unrelated contradiction is manufactured.
- Manuscript remains held and unpublished.

Continuation required: Genesis 24 receives Abraham's elder-servant oath,
country/kin wife mission, well test, Rebekah's water action, jewelry, household
negotiation, departure consent/timing dispute, Isaac meeting and marriage.
