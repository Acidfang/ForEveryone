# CRACKHEAD EXODUS 4

## Title page

**THEY WILL NOT BELIEVE ME OR LISTEN.**

**THE PEOPLE BELIEVED AND HEARD.**

Source parent: Exodus chapter 4, verses 1–31, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 4.

Prepared evidence: `.chapter-work/CHB-EXO-004/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/003-I-CAME-DOWN-TO-DELIVER-THEM-I-AM-SENDING-YOU.md`.

CrackFlix routing: new `S062 — THEY WON'T BELIEVE ME. THEY BELIEVED.`, episode
`S062-E001-EXO4 — MOSES PREDICTED THEIR RESPONSE`.

## Causal foundation

```text
GOD: ELDERS WILL LISTEN
-> MOSES: THEY WILL NOT BELIEVE/LISTEN
-> ROD/SNAKE/ROD SIGN
-> LEPROUS-HAND/RESTORED-HAND SIGN
-> RIVER-WATER/BLOOD SIGN INSTRUCTION
-> MOSES: SLOW SPEECH
-> LORD: MADE MOUTH / GO / I TEACH
-> MOSES: SEND SOMEONE ELSE
-> LORD ANGER / AARON SPOKESMAN APPOINTMENT / ROD
-> MOSES ASKS JETHRO RETURN PERMISSION / RECEIVES PEACE
-> LORD: LIFE-SEEKERS DEAD
-> MOSES TAKES WIFE + SONS + DONKEY / RETURNS EGYPT
-> LORD: DO WONDERS / I HARDEN PHARAOH / HE WILL NOT RELEASE
-> FIRSTBORN-SON RELEASE/DEATH MESSAGE
-> LODGING: LORD MEETS / WANTS TO KILL HIM
-> ZIPPORAH CIRCUMCISES SON / CASTS FORESKIN AT FEET / BLOOD SPEECH
-> HE LETS HIM ALONE
-> LORD SENDS AARON / BROTHERS MEET + KISS
-> MOSES TRANSFERS WORDS/SIGNS
-> MOSES+AARON GATHER ELDERS
-> AARON SPEAKS / SIGNS PERFORMED
-> PEOPLE BELIEVE / HEAR / BOW / WORSHIP
```

## Exodus 4:1–9 — THREE SIGN ROUTES

Moses says Israel will not believe or listen and will deny the LORD appeared.
The LORD asks what is in his hand. Moses answers `A ROD.` At command he throws
it down; it becomes a Joe-faced living snake and Moses runs. At command he takes
its tail; it becomes a rod again.

The LORD says this sign is so they may believe. Moses then puts a hand inside
his cloak; it emerges leprous/white as snow. Repeating the act restores it like
his other flesh. God supplies conditional sign order: if first is not believed,
the latter may be; if neither is believed, river water poured on dry land will
become blood. The third sign is instructed, not yet performed here.

## Exodus 4:10–17 — SEND SOMEONE ELSE

Moses says he was and remains slow of speech/tongue. The LORD says he makes the
human mouth and mute/deaf/seeing/blind States, then commands Moses to go and
promises to be with his mouth and teach speech.

Moses asks for someone else. The LORD's anger burns. God appoints Aaron the
Levite—Moses' brother who speaks well—as spokesman, promises presence with both
mouths, and describes Aaron as Moses' mouth and Moses as God to Aaron. Moses
must carry the sign rod. No disability mechanism or moral explanation is added.

## Exodus 4:18–23 — RETURN AND FIRSTBORN MESSAGE

Moses asks Jethro for permission to see whether his Egypt brothers still live;
Jethro says go in peace. The LORD separately tells Moses to return because all
men seeking his life are dead. Moses takes wife and sons on a donkey and returns
toward Egypt with God's rod.

The LORD orders every wonder before Pharaoh, says he will harden Pharaoh's heart
so Pharaoh will not release the people, and supplies a future message: Israel
is God's firstborn son; because Pharaoh refuses release for service, God will
kill Pharaoh's firstborn son. Message delivery, refusal and death remain future.

## Exodus 4:24–26 — HIM

At a lodging place the LORD meets Moses and wants to kill `him`. Zipporah takes
flint, circumcises her son, casts the foreskin at `his` feet and says
`BRIDEGROOM OF BLOOD`. Then `he` lets `him` alone; she repeats the phrase because
of circumcision.

The source does not resolve every pronoun, name the son, state a prior offence,
give Zipporah an instruction, or explain why her act changes the encounter.
Those exact missing relations remain unresolved. No crack is imagined.

## Exodus 4:27–31 — THEY BELIEVED

The LORD tells Aaron to meet Moses in the wilderness. Aaron meets and kisses him
at God's mountain. Moses transfers all sending words and sign instructions.
They gather Israel's elders. Aaron speaks all LORD words and performs the signs
before the people.

The people believe. They hear that the LORD visited Israel and saw affliction;
they bow and worship.

That completes S062:

```text
GOD: THEY WILL LISTEN
-> MOSES: THEY WILL NOT BELIEVE OR LISTEN
-> WORDS + SIGNS PRESENTED
-> PEOPLE BELIEVE AND HEAR
```

The contradiction is in Moses' asserted future versus the observed result, not
in a secretly disbelieving population.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain pokes Moses' prediction boil, licks his finger, walks away and never
looks back. The people remain believing, bowed and worshipping.

## Character and world-ledger changes

- Moses performs two signs, receives a third instruction, continues objections,
  receives Aaron/rod provisions, departs Midian and reaches the elder audience.
- Aaron becomes a named Levite brother/spokesman, meets/kisses Moses, receives
  words, speaks and performs signs before the people.
- Zipporah travels, circumcises an unnamed son and speaks twice; target/pronoun/
  causal mechanism remain unresolved.
- Jethro grants peaceful departure; the Reuel/Jethro name bridge stays open.
- Moses' wife, plural sons, donkey, rod/snake and Israel audience remain
  separate living identities/objects under Joe-face genetics.

## Bullshit pass

- rod: `CRACKHEAD STAFF / SNAKE MODE / TAIL RESET`;
- cloak: `HAND DIAGNOSTIC PORT / WHITE / RESTORE`;
- mouth routing: `MOSES -> AARON -> PEOPLE / GOD MODE LABEL INCLUDED`;
- donkey: `CRACKHEAD FAMILY RETURN VEHICLE`;
- lodging warning: `TARGET: HIM / REASON: NOT INSTALLED`;
- flint: `BRIDEGROOM-OF-BLOOD HOTFIX`;
- belief display: `MOSES FORECAST: NO / OBSERVED: YES`;
- barcode: `CHB-EXO4-S062E001-31-YOINK`.

## FIR verification

- all 31 verse markers are represented in order;
- performed signs and conditional/unperformed third sign remain distinct;
- all LORD speech/anger/action remains God-only and source-bounded;
- Moses' speech condition and objections remain his statements;
- future hardening/refusal/firstborn death are not imported as outcomes;
- lodging pronouns, target and circumcision mechanism remain unresolved;
- Aaron's performed speech/sign chain precedes observed belief/hearing;
- S062 closes only at the people's actual response;
- Captain changes nothing and has no boil;
- publication remains held and unpublished.

Continuation required: Exodus 5 reconstructs the first Pharaoh audience,
refused worship request, no-straw/same-brick order, officer punishment,
complaint chain and Moses' no-deliverance report.
