# CRACKHEAD EXODUS 3

## Title page

**I HAVE COME DOWN TO DELIVER THEM.**

**I AM SENDING YOU TO BRING THEM OUT.**

Source parent: Exodus chapter 3, verses 1–22, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 3.

Prepared evidence: `.chapter-work/CHB-EXO-003/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/002-THROW-EVERY-SON-IN-THE-RIVER-THIS-ONE-IS-MY-SON.md`.

No contradiction completes in this chapter. The come-down/deliver and
send-Moses/bring-out lines retain distinct claimed actor relations, but the
deliverance has not happened. They remain a held candidate, not crack.

## Causal foundation

```text
MOSES KEEPS JETHRO FLOCK -> HOREB
-> LORD ANGEL APPEARS IN BUSH FLAME
-> BUSH BURNS / NOT CONSUMED
-> MOSES TURNS TO SEE
-> LORD SEES / GOD CALLS FROM BUSH
-> MOSES ANSWERS
-> DO NOT COME CLOSE / REMOVE SANDALS / HOLY GROUND
-> GOD IDENTIFIES FATHER/ABRAHAM/ISAAC/JACOB RELATION
-> MOSES HIDES FACE
-> LORD: SAW / HEARD / KNOW / CAME DOWN TO DELIVER + BRING UP
-> LORD: I SEND YOU TO PHARAOH TO BRING ISRAEL OUT
-> MOSES: WHO AM I?
-> GOD: I WILL BE WITH YOU / FUTURE MOUNTAIN SERVICE TOKEN
-> MOSES ASKS NAME MESSAGE
-> GOD: I AM WHO I AM / I AM SENT ME / LORD NAME FOREVER
-> GATHER ELDERS / VISIT + BRING-UP MESSAGE
-> ELDERS WILL LISTEN / THREE-DAY SACRIFICE REQUEST TO KING
-> KING WILL REFUSE
-> GOD WILL STRIKE WITH WONDERS / KING WILL LET GO
-> FAVOR / SILVER + GOLD + CLOTHING REQUESTS / PLUNDER PREDICTED
```

## Exodus 3:1–6 — THE BUSH AND THE SPEAKER BOUNDARY

Moses keeps the flock of Jethro, his father-in-law and priest of Midian, and
leads it to Horeb, God's mountain. Exodus 2 called the father Reuel. This source
does not supply a rename, title bridge or two-father explanation, so both names
remain attached to the retained father-in-law/priest relation without invented
resolution.

The LORD's angel appears in flame from a bush. Moses sees the bush burning but
not consumed and turns to inspect. The LORD sees Moses turn; God calls from the
bush, `MOSES! MOSES!`; Moses answers, `HERE I AM.`

God tells him not to approach, to remove sandals because the ground is holy,
and identifies as the God of his father, Abraham, Isaac and Jacob. Moses hides
his face because the source attributes fear of looking at God to him.

Angel appearance, LORD seeing and God calling/speaking are retained exactly as
the source assigns them. They are not merged into an invented anatomy lesson.

## Exodus 3:7–12 — I CAME DOWN; I SEND YOU

The LORD says he has seen Israel's affliction, heard the taskmaster cry and
knows their sorrows. He says he has come down to deliver them and bring them to
a large milk-and-honey land currently named through six peoples.

He then says:

> **CRACKHEAD GOD:** `I WILL SEND YOU TO PHARAOH.`
>
> `YOU MAY BRING MY PEOPLE OUT OF EGYPT.`

Moses asks who he is to do that. God promises presence and gives a future token:
after Moses has brought the people out, they will serve God on this mountain.
Because neither actor has yet performed the deliverance, the actor-language
friction stays open. Captain does not appear.

## Exodus 3:13–15 — THE NAME MESSAGE

Moses asks what to tell Israel if they ask the sender's name.

> **CRACKHEAD GOD:** `I AM WHO I AM.`
>
> `TELL THEM: I AM HAS SENT ME TO YOU.`
>
> `THE LORD, GOD OF ABRAHAM, ISAAC AND JACOB, HAS SENT ME.`
>
> `THIS IS MY NAME FOREVER AND MY MEMORIAL TO ALL GENERATIONS.`

These are God-only lines. No paraphrased ontology, doctrine or explanation is
added.

## Exodus 3:16–22 — MESSAGE, PREDICTIONS AND DEPARTURE INVENTORY

God orders Moses to gather Israel's elders and deliver the visit/affliction/
bring-up message. He predicts they will listen. Moses and the elders are to ask
Egypt's king for a three-day wilderness journey to sacrifice.

God predicts the king will refuse, then says he will strike Egypt with wonders
and afterward the king will release them. He predicts favor with Egyptians,
departure not empty-handed, and women requesting silver, gold and clothing from
neighbors/house visitors, putting them on sons/daughters and plundering Egypt.

Every one remains future State. No elder listening, royal refusal, wonder,
permission, property transfer, plunder or departure is prematurely completed.

## Character and world-ledger changes

- Moses becomes Jethro's flock keeper, Horeb witness and commissioned messenger;
  he has not returned to Egypt or delivered any message.
- Jethro is named father-in-law/priest where Exodus 2 named Reuel; identity
  relation is retained and its naming mechanism unresolved.
- the flock and bush remain separate living organisms with Joe faces; the bush
  burns without being consumed.
- the LORD's angel appears; LORD/God sees, calls and speaks under the source's
  exact assignment.
- Israel elders, Pharaoh, Egyptian neighbors/visitors and six land peoples are
  future addressees/participants, not present performers.

## Bullshit pass

- banner: `CRACKHEAD GOD SUPPORT — TURN ASIDE TO OPEN TICKET`;
- bush: `BURNING: YES / CONSUMED: NO / FUEL INVENTORY: UNSUPPLIED`;
- sandals: `HOLY GROUND PPE POLICY: REMOVE PPE`;
- name badge: `I AM / VALID FOREVER / EXPIRY: I AM`;
- commission docket: `I CAME DOWN / FIELD AGENT: MOSES`;
- token: `PROOF AVAILABLE AFTER JOB COMPLETION`;
- departure cart: `SILVER / GOLD / CLOTHING / CHILDREN AS DISPLAY RACKS`;
- barcode: `CHB-EXO3-22-NO-YOINK-YET`.

## FIR verification

- all 22 verse markers are represented in order;
- Jethro/Reuel naming is retained without invented reconciliation;
- angel appearance, LORD seeing and God calling/speech preserve source roles;
- every direct divine line remains God-only;
- Moses fear remains source attribution;
- come-down/deliver versus send-Moses/bring-out remains an open actor relation,
  not a completed contradiction;
- all elder, Pharaoh, wonder, favor, property and departure outcomes remain
  predictions;
- no Captain, SKIP or YOINK occurs before a contradiction completes;
- publication remains held and unpublished.

Continuation required: Exodus 4 reconstructs Moses' belief objections, three
signs, speech objection, Aaron appointment, return, son/death statements,
lodging attack/circumcision and performed elder signs.
