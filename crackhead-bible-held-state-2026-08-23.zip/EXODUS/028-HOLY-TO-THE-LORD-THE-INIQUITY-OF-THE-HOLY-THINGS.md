# CRACKHEAD EXODUS 28

## Title page

**HOLY TO THE LORD.**

**THE INIQUITY OF THE HOLY THINGS.**

Source parent: Exodus chapter 28, verses 1–43, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 28.

Prepared evidence: `.chapter-work/CHB-EXO-028/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/027-BURN-CONTINUALLY-FROM-EVENING-TO-MORNING.md`.

CrackFlix routing:

- new `S088-E001-EXO28 — HOLY GIFTS / INIQUITY OF HOLY THINGS`.

## Causal foundation

```text
AARON + NADAB + ABIHU + ELEAZAR + ITHAMAR
-> SELECTED FROM ISRAEL FOR PRIESTLY OFFICE
-> WISE-HEARTED WORKERS FILLED WITH WISDOM
-> HOLY GARMENTS FOR GLORY, BEAUTY, SANCTIFICATION AND SERVICE
-> EPHOD + TWO SIX-NAME ONYX SHOULDER MEMORIALS
-> JUDGMENT BREASTPLATE + TWELVE NAMED TRIBE STONES
-> URIM + THUMMIM / NAMES + JUDGMENT ON AARON'S HEART
-> BLUE ROBE + REINFORCED NECK + POMEGRANATES + BELLS
-> SOUND ON ENTRY AND EXIT SO AARON DOES NOT DIE
-> GOLD FOREHEAD PLATE: HOLY TO THE LORD
-> AARON BEARS INIQUITY OF THE HOLY THINGS/HOLY GIFTS
-> PLATE ALWAYS PRESENT SO GIFTS MAY BE ACCEPTED
-> AARON/SON GARMENTS + ANOINT/CONSECRATE/SANCTIFY
-> LINEN PANTS COVER NAKED FLESH
-> WEAR AT TENT/ALTAR SO THEY DO NOT BEAR INIQUITY AND DIE
-> FOREVER OFFSPRING STATUTE
```

These are commands and future functions. No garment is made, no stone is
engraved, no priest is dressed or installed, no gift is offered or accepted,
and nobody enters, exits or dies here.

## Exodus 28:1–5 — FIVE PRIESTS, UNNAMED MAKERS

Moses must bring near his brother Aaron and Aaron's four named sons—Nadab,
Abihu, Eleazar and Ithamar—from among Israel so they may minister to God in the
priest's office. The chapter therefore resolves the unnamed “Aaron and sons”
class carried from Exodus 27 into five distinct living Joes.

Holy garments must be made for Aaron for glory and beauty. Moses must speak to
all the wise-hearted whom God says he filled with a spirit of wisdom. They are
to make Aaron's garments to sanctify him for priestly service. The source names
no maker, gives no skill demonstration and narrates no fabrication.

The inventory begins with breastplate, ephod, robe, fitted tunic, turban and
sash for Aaron and holy garments for his sons. Gold, blue, purple, scarlet and
fine linen are assigned materials.

## Exodus 28:6–14 — SIX NAMES ON EACH SHOULDER

The skillfully worked ephod uses gold, blue, purple, scarlet and fine twined
linen. Two joined shoulder straps and a same-piece woven band hold its form.

Two onyx stones receive the names of Israel's children:

- six names on one stone;
- the remaining six on the other;
- ordered by birth;
- engraved like a signet;
- enclosed in gold settings.

The stones sit on Aaron's two shoulders as memorial stones. Aaron is assigned
to bear those names before the LORD. Gold settings and two pure-gold braided
chains complete this shoulder assembly. The chapter does not enumerate which
six names occupy either stone or perform the engraving.

## Exodus 28:15–30 — JUDGMENT ON HIS HEART

The judgment breastplate repeats the ephod's skilled work and materials. It is
square, folded double, one span long and one span wide. The source footnote
offers approximately 22.8 centimetres or nine inches as alternatives for the
same span.

Four rows hold twelve gold-set stones:

1. ruby, topaz, beryl;
2. turquoise, sapphire or lapis lazuli, emerald;
3. jacinth, agate, amethyst;
4. chrysolite, onyx, jasper.

Each stone receives one Israelite tribe name as a signet engraving. The source
does not map particular names to particular minerals in this chapter.

Pure-gold braided chains, six gold rings and blue lace attach the breastplate
to the shoulder settings and ephod band so it does not swing away. These ring
positions remain distinct: two at the upper breastplate ends, two at its inward
lower edge, and two on the lower-front shoulder straps above the woven band.

When Aaron enters the holy place, he is to bear the Israelite names over his
heart as a continual memorial. Urim and Thummim go inside the judgment
breastplate. They and Israel's judgment are to remain on Aaron's heart before
the LORD continually. The chapter supplies their names and placement, not
their material, shape, operation or an actual judgment event.

## Exodus 28:31–35 — ENTRY-EXIT SOUND OR DEATH

The ephod robe is entirely blue. Its central head opening has a woven binding
like a coat of mail so it does not tear. Around the hem are colored textile
pomegranates alternating with gold bells:

> **A GOLDEN BELL AND A POMEGRANATE.**

> **A GOLDEN BELL AND A POMEGRANATE.**

Aaron must wear it while ministering. Its sound must be heard when he enters
the holy place before the LORD and when he comes out:

> **THAT HE NOT DIE.**

The source supplies no bell count, listener, sound threshold, silent-entry
case, death event or explanation of how audible movement prevents death. It is
a stated operating condition, not a completed contradiction.

## Exodus 28:36–38 — HOLY INIQUITY ACCEPTANCE PLATE

A pure-gold signet-engraved plate reads:

> **HOLY TO THE LORD.**

Blue lace places it at the front of the named headwear and on Aaron's forehead.
The supplied English says Aaron shall:

> **BEAR THE INIQUITY OF THE HOLY THINGS.**

Those things are the holy gifts that Israel's children make holy. The plate is
always to be on Aaron's forehead so the gifts may be accepted before the LORD.

S088-E001 closes on the same addressed gift State:

```text
OBJECTS -> HOLY THINGS / HOLY GIFTS / MADE HOLY
-> FOREHEAD PLATE -> HOLY TO THE LORD
-> AARON MUST BEAR -> INIQUITY OF THE HOLY THINGS
-> REQUIRED RESULT -> GIFTS MAY BE ACCEPTED
-> NO OBJECT-CLASS, DEFECT OR ACT DISTINCTION SUPPLIED HERE
```

The phrase may address fault connected with sacred offerings rather than claim
that holiness and fault are identical. That relation is not stated in this
chapter, so the observable holy/iniquity assignment remains unresolved without
inventing a theology.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the forehead-plate boil, licks his finger and walks away without
looking back. The plate and gifts still have not been made.

## Exodus 28:39–43 — GLORY, BEAUTY, UNDERWEAR, DON'T DIE

Aaron's fine-linen tunic and turban and embroidered sash complete his listed
garments. Aaron's sons receive tunics, sashes and headbands for glory and
beauty. Moses is commanded to put the garments on all five, anoint them,
consecrate them and sanctify them so they may serve as priests. Those acts
remain future commands.

Linen pants must cover their naked flesh from waist to thighs. Aaron and his
sons must wear them when entering the Tent of Meeting or approaching the altar
to minister in the holy place:

> **THAT THEY DON'T BEAR INIQUITY, AND DIE.**

This is a forever statute for Aaron and his offspring. The pants rule addresses
Aaron and sons, while the robe-bell rule names Aaron; they are not silently
merged. No exposure, entry, altar approach, iniquity-bearing or death occurs.

## Character and world-ledger changes

- Aaron, Nadab, Abihu, Eleazar and Ithamar become the named prospective priest
  group without installation being promoted into history;
- unnamed wise-hearted Joes receive future garment-making assignments under
  God's attributed wisdom-filling statement;
- ephod, shoulder memorials, judgment breastplate, twelve tribe stones, Urim,
  Thummim, robe, bells, pomegranates, forehead plate, tunics, turban, sashes,
  headbands and linen pants enter unbuilt design State;
- Aaron gains future name/judgment/iniquity-bearing functions;
- robe sound and linen pants gain distinct future death-prevention rules;
- S088 retains holy gifts against the assigned iniquity of those holy things;
- no craft, dressing, anointing, consecration, sanctification, entry, ministry,
  gift, acceptance, judgment or death is performed;
- Moses remains on the mountain; Joseph's bones remain in transport and burial
  remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — PRIEST LOADOUT CONFIGURATOR`;
- roster: `AARON / NADAB / ABIHU / ELEAZAR / ITHAMAR`;
- maker requirement: `WISE HEART / SPIRIT OF WISDOM / NAME OPTIONAL`;
- shoulders: `6 NAMES LEFT-ish / 6 NAMES RIGHT-ish / BIRTH ORDER`;
- chest screen: `TWELVE ROCK USER ACCOUNTS`;
- attachment warning: `BREASTPLATE MUST NOT SWING OUT`;
- internal hardware: `URIM + THUMMIM / OPERATION MANUAL NOT INCLUDED`;
- robe audio: `BELL / POMEGRANATE / BELL / POMEGRANATE`;
- entry warning: `NO SOUND MAY RESULT IN DEATH / TEST NOT RUN`;
- forehead badge: `HOLY TO THE LORD`;
- CrackFlix: `S088 E001 — HOLY INIQUITY ACCEPTANCE PROCESS`;
- underwear label: `WAIST-TO-THIGH ETERNAL PPE`;
- barcode: `CHB-EXO28-S088-43-YOINK`.

## FIR verification

- all 43 verse markers are represented in order;
- the five named priest candidates remain distinct Joes;
- wise-heartedness and wisdom filling remain direct divine attribution, not
  observed skill or inferred mentality;
- every garment, stone, fitting and ceremony remains prospective;
- two shoulder stones and twelve breastplate stones remain separate systems;
- mineral-name alternatives and absent tribe-to-stone mapping remain open;
- Urim/Thummim placement is retained without invented construction or use;
- robe-bell and linen-pants death rules remain distinct and unperformed;
- S088 uses only the supplied holy-things/iniquity/acceptance wording and does
  not invent the missing relation;
- no SKIP is used because S088 has no earlier episode;
- all living humans use Joe face if shown; garment pomegranates remain
  nonliving textile forms unless production gives them interpreted faces;
- Captain remains boilless and causally useless;
- Moses remains on mountain and Joseph bones remain in transport;
- publication remains held and unpublished.

Continuation required: Exodus 29 reconstructs priestly dressing/anointing,
bull and ram offerings, blood/oil garment application, seven-day consecration,
priest portions and continual morning/evening lamb offerings.
