# CRACKHEAD EXODUS 35

## Title page

**WHOEVER IS WILLING, BRING IT.**

**THEY BROUGHT IT.**

Source parent: Exodus chapter 35, verses 1–35, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-EXO-035/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/034-I-WILL-WRITE-WRITE-THESE-WORDS-HE-WROTE.md`.

CrackFlix routing: none. No contradiction completes and no SKIP is valid.

## Causal foundation

```text
MOSES ASSEMBLES ALL ISRAEL
-> SABBATH/DEATH/NO-FIRE RULE RELAYED
-> WILLING-HEART OFFERING REQUESTED
-> COMPLETE BUILD INVENTORY RELAYED
-> CONGREGATION DEPARTS
-> WILLING CONTRIBUTORS RETURN
-> GOLD/TEXTILES/HIDES/METALS/WOOD/STONES/OIL/SPICES BROUGHT
-> WISE-HEARTED WOMEN SPIN MATERIAL
-> BEZALEL/OHOLIAB NAMED TO PEOPLE
-> DIVINE SKILL ATTRIBUTION REPEATED
-> TEACHING CAPACITY ATTRIBUTED
-> WORKFORCE + MATERIALS NOW PRESENT
-> OBJECT CONSTRUCTION NOT YET NARRATED
```

## Exodus 35:1–3 — SIX DAYS, THEN NO FIRE

Moses assembles all Israel and relays words attributed to the LORD. Work may be
done six days. The seventh is holy solemn Sabbath rest. Whoever works then is
to be put to death. No fire may be kindled in Israel's habitations on Sabbath.

The six/seventh/death rule repeats retained covenant State and adds the explicit
no-kindling rule. No Sabbath day, fire, worker, offence, executor or death occurs
in this chapter. Repetition alone is not a contradiction and cannot invoke
SKIP.

## Exodus 35:4–9 — MATERIAL REQUEST

Moses tells the congregation to take an offering for the LORD. Anyone of a
willing heart may bring:

- gold, silver and bronze;
- blue, purple, scarlet and fine linen;
- goats' hair;
- red-dyed ram skins and sea-cow hides;
- acacia wood;
- lamp oil;
- spices for anointing oil and sweet incense;
- onyx and setting stones for ephod and breastplate.

Willingness and heart/spirit movement remain source-attributed States. The text
does not identify a coercion test, contribution quota or private motive.

## Exodus 35:10–19 — MAKE THE WHOLE INVENTORY

Every wise-hearted man is called to come and make all commanded objects:

- Tabernacle layers, clasps, boards, bars, pillars and sockets;
- ark, poles, mercy seat and screening veil;
- table, poles, vessels and show bread;
- lampstand, vessels, lamps and oil;
- incense altar, poles, oil, incense and door screen;
- burnt-offering altar, bronze grating, poles, vessels, basin and base;
- court hangings, pillars, sockets and gate screen;
- Tabernacle/court pins and cords;
- Aaron's and sons' holy service garments.

This is a relayed work order. Nothing in verses 10–19 says an object is already
finished.

## Exodus 35:20–29 — THEY ACTUALLY BRING IT

The congregation leaves Moses and contributors return. Men and women described
as willing bring gold brooches, earrings, signet rings, armlets and other gold
jewels. People possessing the requested textiles, hair and hides bring them.
Silver, bronze and acacia holders bring those materials.

Wise-hearted women spin blue, purple, scarlet and fine linen with their hands
and bring the spun material. Women whose hearts are described as stirred in
wisdom spin goats' hair. The rulers bring onyx/setting stones, spices and oil
for light, anointing and incense.

The narrator closes the collection act collectively: Israelite men and women
whose hearts made them willing bring a freewill offering for the work commanded
through Moses.

The source supplies categories, not amounts, contributor identities, ownership
histories or proof that every requested quantity is sufficient. Material receipt
is performed; object completion is not.

## Exodus 35:30–35 — THE WORKERS ARE ANNOUNCED

Moses publicly identifies Bezalel son of Uri son of Hur of Judah as called by
name. He attributes Spirit of God, wisdom, understanding, knowledge and all
workmanship to Bezalel, including gold/silver/bronze work, stone cutting/setting,
wood carving and skilled design.

Moses says teaching has been put in the hearts of Bezalel and Oholiab son of
Ahisamach of Dan. He attributes wisdom for engraving, skilled work,
embroidery in the four named textile types, weaving and every skilled work.

These are attributed capabilities and public appointments. Women have already
performed spinning; Bezalel/Oholiab construction or teaching has not yet been
narrated in this chapter.

## Character and world-ledger changes

- Moses assembles Israel, relays Sabbath/build commands and publicly announces
  Bezalel/Oholiab skills and teaching capacity;
- willing men and women advance from prospective contributors to actual
  material contributors;
- wise-hearted women become the first narrated sanctuary-production workers by
  spinning and bringing textile/goat-hair material;
- rulers contribute stones, spices and oil;
- Bezalel/Oholiab retain identity and divine skill attribution and gain public
  teaching assignment;
- material State advances from unspecified availability to received categories,
  while quantities/sufficiency remain unresolved;
- every sanctuary object remains unbuilt at chapter end;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — COMMUNITY BUILD MATERIAL DROP`;
- Sabbath warning: `NO WORK / NO FIRE / DEATH POLICY STILL PROSPECTIVE`;
- donation UI: `WILLING HEART REQUIRED / QUANTITY FIELD MISSING`;
- inventory: `GOLD TO GOAT HAIR / BRING WHATEVER THE BLUEPRINT EATS`;
- textile status: `WOMEN SPUN IT / ACTUAL PRODUCTION DETECTED`;
- rulers crate: `ROCKS + SMELL + LAMP JUICE`;
- Bezalel badge: `CALLED BY NAME / ALL CRAFT / CAN TEACH`;
- Oholiab badge: `DAN / CO-TEACHER / OUTPUT NEXT CHAPTER`;
- CrackFlix: `NO CRACK FOUND / DO NOT IMAGINE CRACK`;
- barcode: `CHB-EXO35-NO-CRACK-35-MATERIALS-RECEIVED`.

## FIR verification

- all 35 verse markers are represented in order;
- Sabbath repetition and no-fire addition remain rules without an invented case;
- voluntary heart/spirit/wisdom statements remain narrator/Moses attributions,
  not mind-reading;
- requested materials and actually brought materials remain distinguishable;
- no quantity or sufficiency is invented;
- spinning is performed and distinguished from later object fabrication;
- the full object inventory remains unbuilt;
- Bezalel, Uri, Hur, Oholiab and Ahisamach retain distinct identities;
- same-name Hur remains unresolved rather than merged;
- divine skill and teaching-heart claims remain attributed;
- no CrackFlix episode, SKIP, Captain or crack is manufactured;
- all living beings and living material-source organisms use Joe face if shown;
- publication remains held and unpublished.

Continuation required: Exodus 36 reconstructs worker entry, continuing daily
offerings, excess-material stoppage and the first completed Tabernacle fabric
and structural components.
