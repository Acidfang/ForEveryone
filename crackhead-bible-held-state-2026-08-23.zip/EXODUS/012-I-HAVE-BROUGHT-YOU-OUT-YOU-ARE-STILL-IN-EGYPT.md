# CRACKHEAD EXODUS 12

## Title page

**I HAVE BROUGHT YOUR ARMIES OUT OF EGYPT.**

**THEY ARE STILL IN EGYPT.**

Source parent: Exodus chapter 12, verses 1–51, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 12.

Prepared evidence: `.chapter-work/CHB-EXO-012/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/011-ONE-MORE-PLAGUE-THEN-HE-WILL-THROW-YOU-OUT.md`.

CrackFlix routing:

- new `S070 — I HAVE DONE IT. IT HAS NOT HAPPENED YET.`;
- `S070-E001-EXO12 — I HAVE BROUGHT YOUR ARMIES OUT`;
- repeated `S067-E002-EXO12 — ALL LIVESTOCK DIED / FIRSTBORN LIVESTOCK DIED`.

## Causal foundation

```text
LORD ESTABLISHES FIRST MONTH
-> HOUSEHOLD LAMB SELECTION / KEEP / KILL / BLOOD / ROAST / EAT READY
-> LORD ANNOUNCES FIRSTBORN STRIKE + BLOOD PASSOVER
-> MEMORIAL / SEVEN-DAY UNLEAVENED ORDINANCE
-> LORD: THIS SAME DAY I HAVE BROUGHT YOUR ARMIES OUT
-> OBSERVED STATE: ISRAEL STILL IN EGYPT / PASSOVER NOT YET PERFORMED
-> MOSES RELAYS LAMB/BLOOD/STAY-INSIDE/PASSOVER/FUTURE-TEACHING RULES
-> PEOPLE BOW / WORSHIP / DO AS COMMANDED
-> MIDNIGHT LORD STRIKES EGYPT FIRSTBORN + LIVESTOCK FIRSTBORN
-> GREAT CRY / EVERY EGYPTIAN HOUSE HAS DEAD
-> PHARAOH CALLS MOSES/AARON / ORDERS ALL PEOPLE + LIVESTOCK OUT
-> EGYPTIANS URGE HASTE
-> DOUGH/TROUGHS/CLOTHES CARRIED
-> ISRAEL ASKS SILVER/GOLD/CLOTHING / EGYPTIANS GIVE / PLUNDER STATE
-> RAMESES -> SUCCOTH / 600,000 MEN + CHILDREN + MIXED MULTITUDE + LIVESTOCK
-> UNLEAVENED CAKES / THRUST OUT / NO PREPARED FOOD
-> 430-YEAR EGYPT RESIDENCE / TO-THE-DAY EXIT
-> PASSOVER PARTICIPATION ORDINANCE / CIRCUMCISION BOUNDARY / ONE LAW
-> ISRAEL DOES AS COMMANDED
-> SAME DAY LORD BRINGS ARMIES OUT
```

## Exodus 12:1–14 — CRACKHEAD PASSOVER OPERATING INSTRUCTIONS

The LORD speaks to Moses and Aaron in Egypt. The current month becomes the
first month. On day ten each father's house selects a lamb; small households
combine with a neighboring house according to people and eating count. The
animal is a one-year-old defect-free male from sheep or goats, held until day
fourteen and killed at evening.

Blood goes on two doorposts and lintel. The household eats fire-roasted meat
that night with unleavened bread and bitter herbs: not raw, not water-boiled,
head/legs/inner parts included. Nothing is to remain until morning; any
remainder is burned. Belts, sandals and staffs are on; eating is in haste.

The LORD states he will pass through Egypt, strike all firstborn human and
animal Joes, execute judgments on Egypt's gods, and pass over blood-marked
houses so no destroying plague strikes those occupants. This event is still
future in the instruction.

The day is established as a memorial feast through generations. Instructions
and execution remain separate ledgers.

## Exodus 12:15–20 — I HAVE BROUGHT THEM OUT

Seven days of unleavened bread are commanded. Yeast is removed on day one.
Eating leaven during the defined period carries a cut-off-from-Israel result.
First and seventh days are holy convocations with no work except each person's
food work. The fourteenth-evening through twenty-first-evening boundary is
given; no yeast is to be found in houses; foreigner and land-born persons are
named under the leaven rule.

Inside this pre-departure instruction the LORD states:

> **IN THIS SAME DAY I HAVE BROUGHT YOUR ARMIES OUT OF EGYPT.**

At that Moment:

- Israel remains in Egypt;
- the lamb/blood sequence has only been instructed;
- midnight has not occurred;
- Pharaoh has not ordered departure;
- Rameses-to-Succoth travel has not happened.

S070-E001 closes:

```text
CLAIMED STATE: I HAVE BROUGHT THEM OUT
-> OBSERVED CURRENT STATE: THEY ARE STILL IN EGYPT
-> ACTUAL EXIT OCCURS LATER
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the completed-tense calendar boil, licks his finger and walks away.
The instructions and eventual departure proceed unchanged. Later fulfillment
does not retroactively delete the earlier State mismatch.

## Exodus 12:21–28 — MOSES RELAYS / ISRAEL DOES

Moses calls Israel's elders and orders family lamb selection and killing.
Hyssop carries basin blood to lintel and doorposts. Nobody is to leave a house
until morning. Moses says the LORD will see blood, pass over the door and not
allow the destroyer into those houses.

The rule is retained for sons and future land service. Children will ask what
the service means; the supplied reply calls it the LORD's Passover sacrifice,
passing over Israel houses while striking Egyptians and sparing Israel houses.

The people bow and worship. Israel goes and does as the LORD commanded Moses
and Aaron. The source gives collective compliance, not an invented
house-by-house census or individual ritual dialogue.

## Exodus 12:29–33 — MIDNIGHT / GET OUT

At midnight the LORD strikes all firstborn in Egypt, from Pharaoh's throne to
the captive in the dungeon, and all firstborn livestock. Pharaoh, servants and
Egyptians rise. A great cry occurs; the supplied scope says there is no
Egyptian house without one dead.

Exodus 9 already reported all Egypt livestock dead. Replacement livestock was
never sourced, yet later livestock appeared, and now actual firstborn livestock
are struck. S067-E002 is another addressed occurrence:

`SKIP -> S067-E001-EXO9 / ALL LIVESTOCK DIED, THEN LIVESTOCK REMAINED`

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

His eyes glaze. Midnight and every death still occur. The LORD strikes the
firstborn livestock.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the livestock-death ledger boil, licks his finger and leaves.

Pharaoh calls for Moses and Aaron by night and orders Israel—people and
livestock—to leave and serve as requested, then asks a blessing. `CALLED FOR`
and direct speech do not prove Moses saw Pharaoh's face. The Exodus 10 face
statement therefore remains unresolved, not contradicted.

Egyptians urgently press Israel out, saying, `WE ARE ALL DEAD MEN.` This is
their speech; the source simultaneously depicts living Egyptians performing
the urging. No literal universal-death conclusion is assigned to the narrator.

## Exodus 12:34–39 — PROPERTY, DOUGH AND DEPARTURE

Israel carries unleavened dough and kneading troughs wrapped in clothing on
shoulders. They ask Egyptians for silver, gold and clothing as Moses instructed.
The LORD gives favor; Egyptians let them have what they ask. The source calls
the result plundering Egypt. Exodus 11's request/transfer future State closes.

Israel travels Rameses to Succoth: about 600,000 men on foot in addition to
children. A mixed multitude travels too, with flocks, herds and very much
livestock. Every person and animal remains a distinct Joe despite one shared
face.

They bake unleavened cakes because the dough was not leavened: they were thrust
out, could not wait and had prepared no other food. The previously announced
release/full-expulsion chain closes as performed.

## Exodus 12:40–42 — FOUR HUNDRED THIRTY YEARS

The source states Israel's Egypt residence was 430 years and that at the end,
to the day, all the LORD's armies went out. The night is to be observed through
generations for the LORD bringing them out.

Genesis 15 separately retained a 400-year offspring foreign/service/affliction
statement and fourth-generation statement. Those predicates and boundaries are
not identical to `children of Israel lived in Egypt 430 years`. Both measures
remain without an invented conversion, harmonization or contradiction.

This later actual exit resolves the future and completed-tense claim outcomes,
but preserves S070's earlier Moment.

## Exodus 12:43–50 — WHO EATS THE PASSOVER

The LORD supplies Passover participation rules:

- no foreigner eats;
- a money-bought male servant may eat after circumcision;
- a foreigner/temporary resident and hired servant do not eat;
- food remains in one house, no meat goes outside and no bone is broken;
- all Israel keeps it;
- a resident stranger who wants to keep it may do so after every male in his
  household is circumcised, becoming as land-born for this rule;
- no uncircumcised person eats;
- one law applies to land-born and resident stranger.

The source uses multiple translated status terms and supplies a condition that
changes eligibility. They are not flattened into one identity or manufactured
as a contradiction. Israel does as commanded.

## Exodus 12:51 — ACTUAL STATE

On that same day the LORD brings Israel out of Egypt by their armies.

```text
WAS: IN EGYPT
-> PASSOVER / MIDNIGHT / RELEASE / URGENT EXPULSION
-> TRAVEL RAMESES TO SUCCOTH
-> IS: BROUGHT OUT BY ARMIES
```

Joseph's bones remain in Egypt because this chapter never mentions or moves
them. The oath cannot be closed from general departure language alone.

## Character and world-ledger changes

- Moses/Aaron receive and transmit Passover/month/unleavened/participation
  rules; elders carry household instructions;
- Israel collectively bows, worships, performs the command, requests property,
  receives it and departs from Rameses to Succoth;
- lamb/goat Joes are selected, killed, eaten/burned under specified household
  handling; no individual animal identities are merged;
- the LORD performs the midnight firstborn strike and brings Israel out;
- Pharaoh moves from non-release to full people/livestock expulsion and blessing
  request, without a proved face encounter;
- Egyptian households receive firstborn death/great cry and urgently press
  Israel out; Egyptians transfer silver/gold/clothing;
- mixed-multitude Joes enter the travelling population as distinct identities;
- Egyptian livestock retains its unresolved replacement origin and repeated
  post-total-death State;
- S070 preserves the pre-exit completed-tense mismatch even after actual exit;
- Joseph's bones oath remains open.

## Bullshit pass

- banner: `CRACKHEAD PASSOVER — INSTALL BLOOD PATCH BEFORE MIDNIGHT`;
- lamb selector: `SHEEP OR GOAT / MALE / YEAR 1 / DEFECT DRIVER NONE`;
- meal mode: `RAW NO / BOILED NO / FIRE YES / SHOES ON`;
- calendar: `MONTH ONE CREATED WHILE USING MONTH ONE`;
- tense console: `BROUGHT OUT: YES / CURRENT LOCATION: EGYPT`;
- door security: `HYSSOP TWO-POST AUTHENTICATION / DO NOT EXIT`;
- Egypt alert: `FIRSTBORN OUTAGE / EVERY LIVING THING STILL JOE`;
- property receipt: `ASKED / GIVEN / PLUNDERED / NO CHANGE AVAILABLE`;
- dough warning: `YEAST BOOT INTERRUPTED BY FORCED EJECT`;
- eligibility form: `CIRCUMCISION DLC UNLOCKS PASSOVER ACCESS`;
- CrackFlix: `S067 EPISODE 2 — DEAD LIVESTOCK DIES AGAIN`;
- barcode: `CHB-EXO12-S067E002-S070E001-51-YOINK`.

## FIR verification

- all 51 verse markers are represented in order;
- instruction, relayed instruction, collective compliance and execution are
  separate observable States;
- S070 closes only at the completed-tense/current-location mismatch and remains
  retained after later resolution;
- S067-E002 points to the exact prior empty-class contradiction and still occurs;
- firstborn deaths and Egypt household scope are not extended beyond text;
- Pharaoh's call does not invent a face-to-face encounter;
- Egyptian `WE ARE ALL DEAD MEN` remains their speech, not narrator fact;
- silver/gold/clothing instruction, request and transfer chain closes in order;
- 400-year and 430-year measures remain distinct source predicates;
- translated foreigner/stranger/servant statuses and circumcision condition are
  preserved rather than flattened;
- direct LORD speech/actions remain God-only;
- Captain remains boilless and causally useless;
- Israel release/expulsion closes; Joseph bone transport remains open;
- publication remains held and unpublished.

Continuation required: Exodus 13 reconstructs firstborn consecration,
unleavened-memory teaching, route selection, Joseph bone transport, cloud/fire
guidance and the first actual closure of the Genesis 50 bones oath.
