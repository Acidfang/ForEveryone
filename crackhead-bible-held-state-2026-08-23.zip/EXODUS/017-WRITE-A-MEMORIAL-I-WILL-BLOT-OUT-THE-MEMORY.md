# CRACKHEAD EXODUS 17

## Title page

**WRITE THIS FOR A MEMORIAL IN A BOOK.**

**I WILL UTTERLY BLOT OUT THE MEMORY.**

Source parent: Exodus chapter 17, verses 1–16, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 17.

Prepared evidence: `.chapter-work/CHB-EXO-017/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/016-EVERY-DAY-THERE-SHALL-BE-NONE.md`.

CrackFlix routing: new `S076-E001-EXO17 — WRITE THE MEMORY / BLOT OUT THE MEMORY`.

## Causal foundation

```text
SIN WILDERNESS -> REPHIDIM UNDER LORD'S TRAVEL COMMAND
-> NO DRINKING WATER
-> PEOPLE QUARREL: GIVE US WATER
-> MOSES: WHY QUARREL WITH ME / TEST LORD?
-> PEOPLE THIRST / MURMUR / ATTRIBUTE EGYPT EXIT + THIRST-DEATH TO MOSES
-> MOSES CRIES: WHAT SHALL I DO? / ALMOST READY TO STONE ME
-> LORD: GO BEFORE PEOPLE + ELDERS + NILE-STRIKING ROD
-> LORD: I WILL STAND ON HOREB ROCK
-> MOSES STRIKES ROCK IN ELDERS' SIGHT
-> WATER COMES OUT FOR PEOPLE TO DRINK
-> PLACE NAMED MASSAH + MERIBAH FOR QUARREL/TEST QUESTION
-> AMALEK COMES + FIGHTS ISRAEL AT REPHIDIM
-> MOSES ORDERS JOSHUA: CHOOSE MEN / FIGHT TOMORROW
-> JOSHUA FIGHTS / MOSES + AARON + HUR ASCEND HILL
-> MOSES HAND UP: ISRAEL PREVAILS
-> MOSES HAND DOWN: AMALEK PREVAILS
-> HANDS HEAVY
-> STONE SEAT + AARON/HUR HOLD HANDS UNTIL SUNSET
-> JOSHUA DEFEATS AMALEK PEOPLE BY SWORD
-> LORD: WRITE MEMORIAL IN BOOK + REHEARSE TO JOSHUA
-> LORD: I WILL BLOT OUT MEMORY OF AMALEK
-> MOSES BUILDS/NAMES ALTAR LORD OUR BANNER
-> MOSES SPEECH: LORD SWORE GENERATIONAL WAR WITH AMALEK
```

## Exodus 17:1–3 — COMMANDED ROUTE / NO WATER

All Israel's congregation travels from the wilderness of Sin by stages,
according to the LORD's commandment, and camps at Rephidim. There is no water
for the people to drink.

The commanded route and the water absence are both observable. The source does
not state that every commanded camp must already contain water, so their
coexistence is friction in the journey but not a completed contradiction.

The people quarrel with Moses:

> **GIVE US WATER TO DRINK.**

Moses asks why they quarrel with him and test the LORD. The people are thirsty,
murmur against Moses and ask why he brought them, their children and livestock
out of Egypt to kill them with thirst.

`TO KILL US` is their stated purpose attribution. No thirst death occurs in the
chapter. Moses' participation in leading the people does not erase the retained
LORD exit acts, and the question does not say Moses acted alone; no false
exclusive actor contradiction is manufactured.

## Exodus 17:4–7 — HIT THE ROCK

Moses cries to the LORD:

> **WHAT SHALL I DO WITH THESE PEOPLE?**

> **THEY ARE ALMOST READY TO STONE ME.**

This is Moses' current risk statement. The people do not stone him in the
retained sequence.

The LORD tells Moses to walk before the people, take Israel's elders and carry
the rod with which he struck the Nile. The LORD says he will stand before Moses
on the rock in Horeb. Moses is to strike it; water will come out for the people
to drink.

Moses does so in the elders' sight. The source compresses the action as `DID
SO`; the complete command supplies the addressed strike/water/drink sequence.
No geology, pipe, pressure system, water source, rod energy or crackhead power
unit is inserted.

Moses names the place Massah and Meribah because Israel quarreled and tested the
LORD by saying:

> **IS THE LORD AMONG US, OR NOT?**

The source notes map Massah to testing and Meribah to quarreling. The question
remains a question even after earlier cloud/glory/manna States; it does not
assert absence and therefore does not independently close a contradiction.

## Exodus 17:8–13 — HAND-CONTROLLED WAR

Amalek comes and fights Israel at Rephidim. The source supplies no preceding
speech, demand, declared reason, army count or first-strike detail.

Moses tells Joshua to choose men and fight Amalek the next day. Moses will
stand on the hilltop with God's rod. Joshua obeys and fights. Moses, Aaron and
Hur go to the hilltop.

The battle State tracks Moses' hand:

```text
MOSES HOLDS HAND UP -> ISRAEL PREVAILS
MOSES LETS HAND DOWN -> AMALEK PREVAILS
MOSES' HANDS BECOME HEAVY
-> STONE PLACED / MOSES SITS
-> AARON + HUR HOLD ONE HAND EACH
-> HANDS STEADY UNTIL SUNSET
-> JOSHUA DEFEATS AMALEK + PEOPLE BY SWORD
```

That observed correlation and its intervention are the entire supplied battle
mechanism. The text does not say the rod emits energy, the hand transmits a
signal, the armies observe the hill, or why hand height corresponds to who
prevails. Crackhead Science can label the apparatus `CRACKHEAD WAR REMOTE`; it
cannot fill in the missing physics.

Joshua appears as the selected-men battle commander. Hur appears as the second
hand supporter. Neither receives lineage, prior history or extra dialogue in
this chapter.

## Exodus 17:14 — REMEMBER TO ERASE THE MEMORY

After Joshua's victory, the LORD tells Moses:

> **WRITE THIS FOR A MEMORIAL IN A BOOK.**

> **REHEARSE IT IN THE EARS OF JOSHUA.**

The content identifies Amalek and the battle relation. The same sentence gives
the purpose/future declaration:

> **I WILL UTTERLY BLOT OUT THE MEMORY OF AMALEK FROM UNDER THE SKY.**

S076-E001 closes inside the direct instruction:

```text
CREATE DURABLE WRITTEN MEMORIAL OF AMALEK EVENT
-> REHEARSE AMALEK EVENT TO JOSHUA
-> DECLARE FUTURE ERASURE OF AMALEK MEMORY
```

The book and rehearsal preserve the addressed memory while the declaration
states that memory will be blotted out. The source does not say the memorial
will be destroyed, excluded from `under the sky`, anonymized, or exempted.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the memorial boil, licks his finger and walks away without looking
back. The book remains written as commanded, Joshua still hears it, and the
future erasure remains future.

## Exodus 17:15–16 — BANNER / GENERATIONAL WAR

Moses builds an altar and names it `THE LORD OUR BANNER` / `THE LORD NISSI`.
The altar is a nonliving constructed object; its name does not turn it into the
LORD or a living organism.

Moses says the LORD has sworn that the LORD will have war with Amalek from
generation to generation. This is Moses' attributed oath report and future-war
statement.

Future generational war and future total memory erasure have no supplied
completion dates. War can precede a later erasure; the chapter does not show
both terminal States existing simultaneously. Their temporal relation therefore
remains unresolved and is not promoted into a second crack.

The memorial writing act itself is commanded but not separately narrated as
completed in this chapter. It remains required/open while the direct command
and its internal preserve/erase mismatch are retained.

Joseph's bones remain in transport and are neither mentioned nor buried.

## Character and world-ledger changes

- Israel moves from the Sin wilderness to Rephidim under commanded stages;
- thirst, water demand, quarrel and attributed thirst-death purpose enter the
  collective history without invented deaths;
- Moses performs the elder-witnessed rock strike and names Massah/Meribah;
- the rock-water mechanism remains source-bounded and unexplained;
- Amalek enters as a fighting collective at Rephidim without invented origin or
  motive;
- Joshua enters as named selected-men commander and defeats Amalek's force;
- Hur enters as named hilltop hand supporter alongside Aaron;
- Moses/Aaron/Hur gain the stone-seat/two-hand intervention history;
- S076 records memorial creation/rehearsal against memory-erasure declaration;
- an unnamed memorial book enters as commanded but unwritten-in-narration;
- `THE LORD OUR BANNER` altar enters as built/named object;
- future Amalek-memory erasure and generation-to-generation war stay open;
- Joseph bones remain moving; burial open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — REPHIDIM UTILITIES & DEFENCE`;
- campground sign: `SELECTED BY COMMAND / WATER SOLD SEPARATELY`;
- rock console: `CRACKHEAD HOREB TAP — HIT TO DISPENSE`;
- location merge: `MASSAH + MERIBAH / TESTING & COMPLAINTS DEPARTMENT`;
- war machinery: `CRACKHEAD MANUAL SIGNAL SUPERIORITY SYSTEM`;
- hilltop warning: `HAND DOWN MAY ALTER BATTLE WARRANTY`;
- Aaron/Hur service: `DUAL-JOE ARM UPTIME SUPPORT`;
- memorial office: `WRITE IT DOWN SO NOBODY REMEMBERS`;
- CrackFlix: `S076 E001 — PERMANENT DELETION RECORD`;
- altar banner: `THE LORD OUR BANNER — ACTUAL BANNER NOT INCLUDED`;
- barcode: `CHB-EXO17-S076E001-16-YOINK`.

## FIR verification

- all 16 verse markers are represented in order;
- command-route/no-water friction is retained without an invented water promise;
- thirst-death and almost-stoning claims remain attributed speech and are not
  converted into performed acts;
- water follows the stated rod/rock command sequence without invented science;
- Massah/Meribah naming retains source-provided relations;
- hand-up/hand-down battle relation remains observed correlation plus physical
  intervention, with no hidden mechanism asserted;
- Joshua, Hur and Amalek receive only their supplied roles and acts;
- S076 closes from written memorial + oral rehearsal + memory-erasure statement;
- memorial writing remains commanded, not falsely marked executed;
- future memory erasure and generational war remain temporally unresolved;
- direct LORD speech/actions and Moses' oath report remain distinct;
- Captain remains boilless, causally useless and does not alter any outcome;
- Joseph bones transport remains active and burial open;
- publication remains held and unpublished.

Continuation required: Exodus 18 reconstructs Jethro's arrival, Zipporah/sons
return, rescue reports, sacrifice/meal, Moses' all-day judgment process and the
delegated-ruler replacement system.
