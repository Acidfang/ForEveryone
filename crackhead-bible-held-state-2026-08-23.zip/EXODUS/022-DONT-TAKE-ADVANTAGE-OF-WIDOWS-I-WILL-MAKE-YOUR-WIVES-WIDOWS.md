# CRACKHEAD EXODUS 22

## Title page

**DON'T TAKE ADVANTAGE OF WIDOWS OR FATHERLESS CHILDREN.**

**I WILL KILL YOU. YOUR WIVES WILL BE WIDOWS. YOUR CHILDREN WILL BE FATHERLESS.**

Source parent: Exodus chapter 22, verses 1–31, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 22.

Prepared evidence: `.chapter-work/CHB-EXO-022/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/021-HE-SHALL-GO-OUT-FREE-HE-SHALL-SERVE-FOREVER.md`.

CrackFlix routing:

- new `S083-E001-EXO22 — PAY THE DOWRY TO MARRY / PAY WHEN MARRIAGE IS REFUSED`;
- new `S084-E001-EXO22 — PROTECT WIDOWS AND FATHERLESS / MAKE MORE OF THEM`.

## Causal foundation

```text
STOLEN/KILLED/SOLD LIVESTOCK -> FOURFOLD/FIVEFOLD RESTITUTION
-> BREAK-IN DEATH BLOODGUILT CHANGES WITH SUNLIGHT
-> THIEF OWES RESTITUTION / NO PROPERTY -> THIEF SOLD
-> LIVE STOLEN PROPERTY FOUND -> DOUBLE
-> ANIMAL GRAZING / FIRE LOSS -> BEST OR FULL RESTITUTION
-> DEPOSITED MONEY/STUFF -> FOUND THIEF DOUBLE / NO THIEF GOD-BOUNDARY TEST
-> LOST-PROPERTY CLAIMS -> BOTH PARTIES BEFORE GOD / CONDEMNED PARTY DOUBLE
-> DEPOSITED ANIMAL LOSS -> OATH/EVIDENCE/THEFT BRANCHES
-> BORROWED PROPERTY -> OWNER ABSENCE/PRESENCE/LEASE BRANCHES
-> UNPLEDGED VIRGIN ENTICED + SEX -> DOWRY FOR MARRIAGE
-> FATHER MAY REFUSE MARRIAGE -> SAME DOWRY-SCALE PAYMENT
-> SORCERY/BESTIALITY/OTHER-GOD SACRIFICE DEATH/DESTRUCTION RULES
-> ALIEN PROTECTED BY ISRAEL'S ALIEN HISTORY
-> WIDOW/FATHERLESS PROTECTED -> THEIR CRY HEARD
-> OFFENDER KILLED -> OFFENDER'S WIFE WIDOW / CHILDREN FATHERLESS
-> POOR-PERSON LOAN: NO CREDITOR CONDUCT / NO INTEREST
-> GARMENT COLLATERAL RETURNED BY SUNSET SO BORROWER CAN SLEEP
-> NO BLASPHEMY / NO RULER CURSE
-> HARVEST/PRESS OFFERING NOT DELAYED
-> FIRSTBORN SON/CATTLE/SHEEP GIVEN; ANIMAL SEVEN DAYS WITH MOTHER, EIGHTH TO GOD
-> HOLY MEN DO NOT EAT FIELD-TORN MEAT; GIVE IT TO DOGS
```

Every case is conditional speech. No theft, break-in, killing, sale,
restitution, grazing loss, fire, deposit, dispute, oath, borrowing, sexual act,
marriage, execution, oppression, loan, pledge, offering or feeding act is
narrated as performed in this chapter.

## Exodus 22:1–4 — THIEF ACCOUNTING / SUNLIGHT SWITCH

The theft schedule distinguishes outcomes:

- stolen ox killed or sold: five oxen paid for one;
- stolen sheep killed or sold: four sheep paid for one;
- thief caught breaking in and struck dead before the sunlight condition: no
  bloodshed guilt;
- if the sun has risen on the thief: the striker is guilty of bloodshed;
- thief makes restitution;
- thief with nothing is sold for the theft;
- live stolen ox, donkey or sheep found in the thief's hand: double payment.

Night/day, dead/sold/live property and ability-to-pay are explicit changed
conditions. They do not form cracks merely because the outcomes differ.

The rule does not identify a thief, homeowner, sale buyer, adjudicator, time,
price or actual animal. Every conditional living Joe retains a distinct identity.

## Exodus 22:5–6 — YOUR ANIMAL / YOUR FIRE / THEIR FIELD

A person who lets an animal eat another person's field or vineyard owes
restitution from the best of the responsible person's own field and vineyard.

A person whose kindled fire spreads through thorns and consumes grain shocks,
standing grain or field must make restitution.

The source supplies responsibility through release/kindling and resulting
consumption. It does not specify quantity, valuation, intent, weather, fence,
fire mechanism or payment event.

## Exodus 22:7–13 — KEEP THIS / PROVE WHAT HAPPENED

For money or stuff delivered to a neighbor for safekeeping:

- a found thief pays double;
- if no thief is found, the house master comes near to God to determine whether
  he put his hand on the neighbor's goods.

Every trespass claim involving ox, donkey, sheep, clothing or another lost
thing—where someone says, `This is mine`—brings both parties before God. The
party God condemns pays double.

For a donkey, ox, sheep or other animal delivered to a neighbor for keeping:

- if it dies, is injured or is driven away unseen, the LORD's oath stands
  between the parties; the owner accepts it and no restitution is due;
- if it is stolen, restitution is made to the owner;
- if torn in pieces, the keeper brings the remains as evidence and does not pay
  for what was torn.

These are evidence branches, not narrated findings. `Come near to God`, `God
condemns`, `oath of the LORD`, acceptance and the identity of the actor who
makes theft restitution receive no invented courtroom mechanism.

## Exodus 22:14–15 — BORROWED, ATTENDED OR LEASED

If borrowed property is injured or dies while its owner is absent, the borrower
makes restitution. If the owner is with it, the borrower does not. If it was
leased, the lease covers the stated relation.

Owner presence and lease status are explicit boundary changes. No item, owner,
borrower, damage, death, lease amount or restitution occurs.

## Exodus 22:16–17 — PAY TO MARRY / PAY WITHOUT MARRIAGE

If a man entices an unpledged virgin and lies with her:

> **HE SHALL SURELY PAY A DOWRY FOR HER TO BE HIS WIFE.**

But her father may utterly refuse to give her to him. If he does:

> **HE SHALL PAY MONEY ACCORDING TO THE DOWRY OF VIRGINS.**

S083-E001 closes at the rule level:

```text
SEX WITH UNPLEDGED VIRGIN
-> DOWRY PAYMENT STATED FOR HER TO BECOME HIS WIFE
-> FATHER MAY REFUSE THAT MARRIAGE
-> DOWRY-SCALE PAYMENT REMAINS REQUIRED
```

The payment survives the loss of its first stated marriage result. The source
does not supply the woman's speech, father's decision criteria, dowry amount,
actual marriage, refusal or payment.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the dowry boil, licks his finger and walks away without looking back.
The ordinance schedule continues.

## Exodus 22:18–20 — THREE TERMINAL OFFENCES

The direct rules say:

- do not allow a sorceress to live;
- whoever has sex with an animal shall be put to death;
- whoever sacrifices to any god except the LORD alone shall be utterly
  destroyed.

No sorceress identity, act, animal, sacrifice, other god, accusation, trial,
death or destruction occurs here. The Joe-face rule does not merge the human
and animal participants in the prohibited sexual act.

## Exodus 22:21–24 — DON'T PRODUCE WHAT YOU PROTECT

Israel must not wrong or oppress an alien because Israel were aliens in Egypt.
That reason is direct divine speech; no present alien or oppression event is
enumerated.

The people must not take advantage of any widow or fatherless child. If they do
and those people cry to God, God says he will hear. His wrath will grow hot and:

> **I WILL KILL YOU WITH THE SWORD.**

The stated result is:

> **YOUR WIVES SHALL BE WIDOWS, AND YOUR CHILDREN FATHERLESS.**

S084-E001 closes:

```text
RULE PROTECTS WIDOWS + FATHERLESS CHILDREN FROM EXPLOITATION
-> EXPLOITED WIDOW/FATHERLESS CRY
-> GOD KILLS OFFENDER
-> OFFENDER'S WIFE BECOMES WIDOW
-> OFFENDER'S CHILDREN BECOME FATHERLESS
```

The enforcement mechanism creates new members of the same protected classes.
No exploitation, cry, heated wrath, sword killing or family-status change is
performed in the chapter.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the protection boil, licks his finger and walks away without looking
back. The hypothetical families remain hypothetical.

## Exodus 22:25–27 — THE LOAN MAY NOT TAKE THE BED

When lending to a poor person among God's people:

- do not act as a creditor toward that person;
- do not charge interest;
- if the neighbor's garment is taken as collateral, return it before sunset.

God identifies the garment as the person's only covering and skin garment,
asks what the person would sleep in, and says he will hear the person's cry
because he is gracious.

The chapter does not narrate a loan, debt, interest, collateral transfer,
sunset return, sleep deprivation or cry. Taking collateral and returning it the
same day are parts of one constrained process, not contradictory ownership
claims.

## Exodus 22:28–31 — SPEECH, FIRST OUTPUTS AND DOG FOOD

The final rules say:

- do not blaspheme God;
- do not curse a ruler of the people;
- do not delay offerings from harvest and press outflow;
- give firstborn sons to God;
- do likewise with firstborn cattle and sheep: seven days with the mother,
  eighth day given to God;
- be holy men to God;
- do not eat field meat torn by animals;
- cast that meat to the dogs.

Exodus 13's firstborn-son redemption procedure remains retained. `Give your
firstborn sons to me` does not state that the existing redemption procedure is
cancelled, so no child sacrifice or contradiction is invented.

The torn-animal evidence rule in verse 13 and torn-meat dog disposal in verse
31 can coexist sequentially. The source does not identify one carcass as both
objects, so no DEDUP or performed disposal is claimed.

Firstborn cattle, sheep, mothers, field predators and dogs are living Joes.
Shared face does not merge their roles. No offering subject, exact harvest,
press liquid, firstborn transfer, torn carcass or dog-feeding event occurs.

## Character and world-ledger changes

- Israel receives theft, restitution, custody, borrowing and fire/grazing loss
  conditions;
- owners, neighbors, keepers, borrowers, lessors, claimants and condemned
  parties gain conditional evidence/payment roles;
- the unpledged virgin, father and responsible man gain conditional
  dowry/marriage/refusal relations;
- aliens, widows, fatherless children and poor borrowers gain explicit
  protection relations;
- S083 records marriage-purpose payment continuing after marriage refusal;
- S084 records protected widow/fatherless statuses reproduced by enforcement;
- rulers, harvest/press outputs, firstborn sons and firstborn livestock gain
  speech/offering timing boundaries;
- field-torn meat becomes prohibited human food and prospective dog food;
- no conditional person, offence, loss, ruling or sanction becomes history;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — LIABILITY MATRIX CONTINUES SCROLLING`;
- livestock theft shop: `OX x5 / SHEEP x4 / LIVE STOCK x2`;
- break-in sensor: `SUN UP = BLOODGUILT ENABLED`;
- insolvent thief option: `SELL USER TO COMPLETE RESTITUTION`;
- field insurance: `REPLACE WITH YOUR BEST SHIT`;
- custody portal: `THIEF NOT FOUND — ESCALATE TO GOD`;
- evidence upload: `TORN PIECES ACCEPTED`;
- owner-presence switch: `WITH IT = NO / NOT WITH IT = PAY`;
- CrackFlix: `S083 E001 — NON-MARRIAGE DOWRY PLAN`;
- vulnerable-person support: `CRY DIRECTLY TO GOD`;
- enforcement result: `NEW WIDOWS + NEW FATHERLESS CHILDREN`;
- CrackFlix: `S084 E001 — PROTECTION CLASS REPLENISHMENT`;
- collateral timer: `RETURN BEFORE SUNSET / USER NEEDS PANTS TO SLEEP`;
- offering queue: `HARVEST + PRESS + FIRSTBORN — DO NOT DELAY`;
- dog menu: `FIELD-TORN JOE MEAT ONLY`;
- barcode: `CHB-EXO22-S083-S084-31-YOINK-YOINK`.

## FIR verification

- all 31 verse markers are represented in order;
- all offences, losses, findings, payments and sanctions remain conditional;
- night/day break-in outcomes remain changed-condition branches;
- killed/sold/live theft outcomes remain distinct;
- custody, oath, evidence, borrowing, owner-presence and lease branches are not
  collapsed;
- S083 retains the stated marriage purpose and the father's explicit refusal
  branch without inventing the woman's position;
- terminal-offence rules do not create performed offenders or victims;
- S084 closes only from protection rule, cry/hearing, killing and resulting
  widow/fatherless relations in the same divine statement;
- no present alien, widow, orphan, poor borrower or ruler is invented;
- firstborn giving does not erase retained redemption procedure;
- torn evidence and dog-food disposal are not forced into one object;
- every hypothetical living human and animal uses Joe's face if shown;
- Captain remains boilless and causally useless;
- Joseph bones transport remains active and burial open;
- publication remains held and unpublished.

Continuation required: Exodus 23 reconstructs truth/majority/judgment rules,
enemy-property assistance, poor/stranger protections, Sabbath cycles, three
annual feasts, messenger obedience, land entry and progressive dispossession.
