# CRACKHEAD EXODUS 19

## Title page

**WHEN THE TRUMPET SOUNDS LONG, THEY SHALL COME UP.**

**DON'T LET THEM COME UP.**

Source parent: Exodus chapter 19, verses 1–25, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 19.

Prepared evidence: `.chapter-work/CHB-EXO-019/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/018-YOU-SIT-ALONE-THEY-STAND-ALL-DAY.md`.

CrackFlix routing:

- new `S077-E001-EXO19 — TRUMPET SAYS COME UP / LORD SAYS DON'T COME UP`;
- new `S078-E001-EXO19 — THEY CAN'T COME UP / DON'T LET THEM COME UP`.

## Causal foundation

```text
THIRD MONTH / REPHIDIM -> SINAI WILDERNESS / CAMP BEFORE MOUNTAIN
-> MOSES ASCENDS / LORD CALLS FROM MOUNTAIN
-> DELIVERANCE CLAIM + CONDITIONAL COVENANT/POSSESSION/PRIEST-KINGDOM/HOLY-NATION MESSAGE
-> MOSES SETS WORDS BEFORE ELDERS
-> ALL PEOPLE: ALL LORD SPOKEN WE WILL DO
-> MOSES REPORTS PEOPLE WORDS TO LORD
-> LORD: THICK CLOUD SO PEOPLE HEAR ME WITH MOSES + BELIEVE MOSES FOREVER
-> MOSES AGAIN TELLS PEOPLE WORDS TO LORD
-> LORD: SANCTIFY TODAY/TOMORROW / WASH / READY THIRD DAY
-> LORD WILL DESCEND IN SIGHT OF ALL PEOPLE
-> SET MOUNTAIN BOUNDS / DON'T ASCEND OR TOUCH / TOUCHER DIES
-> NO HAND TOUCHES OFFENDER / STONE OR SHOOT HUMAN OR ANIMAL
-> WHEN TRUMPET SOUNDS LONG THEY SHALL COME UP TO MOUNTAIN
-> MOSES DESCENDS / SANCTIFIES / PEOPLE WASH
-> MOSES: READY THIRD DAY / NO SEXUAL RELATIONS
-> THIRD-DAY THUNDER/LIGHTNING/THICK CLOUD/EXCEEDINGLY LOUD TRUMPET
-> CAMP TREMBLES
-> MOSES LEADS PEOPLE TO MEET GOD / THEY STAND AT LOWER MOUNTAIN
-> LORD DESCENDS IN FIRE / MOUNTAIN SMOKES + QUAKES
-> TRUMPET GROWS LOUDER / MOSES SPEAKS / GOD ANSWERS BY VOICE
-> LORD CALLS MOSES TO TOP / MOSES ASCENDS
-> LORD: GO DOWN / WARN PEOPLE NOT BREAK THROUGH TO GAZE / PRIESTS SANCTIFY
-> MOSES: PEOPLE CAN'T COME UP / YOU WARNED + BOUNDS/SANCTIFICATION
-> LORD: GO DOWN / BRING AARON UP / DON'T LET PRIESTS OR PEOPLE COME UP
-> MOSES DESCENDS / TELLS PEOPLE
```

## Exodus 19:1–2 — SINAI ARRIVAL

In the third month after Israel's Egypt exit, on the same day relation supplied
by the source, the people leave Rephidim, enter Sinai wilderness and camp before
the mountain.

No exact day number within the month is stated. The `same day` phrase is
retained without manufacturing a calendar conversion.

## Exodus 19:3–8 — THE CONDITIONAL MESSAGE

Moses goes up to God. The LORD calls from the mountain and gives an exact relay
for the house of Jacob/children of Israel.

The message says the people saw what the LORD did to Egypt and that he bore
them on eagles' wings and brought them to himself. The source does not narrate
literal eagle transport; `eagles' wings` remains divine speech imagery attached
to the completed journey.

Then comes a conditional relation:

```text
IF INDEED OBEY LORD VOICE + KEEP COVENANT
-> OWN POSSESSION AMONG ALL PEOPLES
-> KINGDOM OF PRIESTS
-> HOLY NATION
```

The LORD also states all earth is his. The condition's future performance is
not closed here.

Moses calls the elders and sets all the commanded words before them. All the
people answer together:

> **ALL THAT THE LORD HAS SPOKEN WE WILL DO.**

Moses reports their words to the LORD. This is a collective commitment at this
Moment. Later performance must be observed rather than assumed, but no breach
has yet completed inside Exodus 19.

## Exodus 19:9–15 — HEAR / WASH / BOUNDS

The LORD says he will come to Moses in a thick cloud so the people may hear him
speak and believe Moses forever. The source then says Moses tells the people's
words to the LORD again. It does not provide a second distinct reply from the
people, so no duplicate audience speech is invented.

The LORD orders:

- sanctify the people today and tomorrow;
- have them wash clothes;
- have them ready for the third day;
- set bounds all around the mountain;
- forbid ascent onto or touching the mountain border;
- put any human or animal toucher to death;
- do not touch the offender by hand; stone or shoot through instead.

Then the access condition changes:

> **WHEN THE TRUMPET SOUNDS LONG, THEY SHALL COME UP TO THE MOUNTAIN.**

Moses descends, sanctifies the people and they wash clothes. He adds readiness
by the third day and no sexual relations with a woman. The chapter does not
state which part of that final instruction is a direct quotation versus Moses'
administration, nor does it record compliance person by person.

## Exodus 19:16–20 — THE TRUMPET SOUNDS

On third-day morning there are thunder, lightning, thick cloud and an
exceedingly loud trumpet. Everyone in camp trembles. Moses leads the people out
to meet God; they stand at the lower part of the mountain.

The LORD descends on Sinai in fire. The whole mountain smokes like a furnace
and quakes greatly. The trumpet sound grows louder and louder. Moses speaks and
God answers by voice.

The signal required by the earlier access condition has now occurred and is
continuing:

```text
RULE: WHEN TRUMPET SOUNDS LONG -> THEY SHALL COME UP TO MOUNTAIN
-> THIRD DAY: TRUMPET EXCEEDINGLY LOUD
-> TRUMPET GROWS LOUDER AND LOUDER
```

The LORD comes to the mountaintop and calls Moses up. Moses goes up. The people
remain at the lower part.

Thunder, lightning, fire, smoke, quake, trumpet and voice remain separately
observed effects. No weather generator, loudspeaker, volcanic diagnosis,
frequency machine or literal divine anatomy is inferred.

## Exodus 19:21–25 — COME UP / DON'T COME UP

After the long/louder trumpet condition, the LORD tells Moses to go down and
warn the people not to break through to gaze at the LORD or many will perish.
Priests who come near must sanctify themselves or the LORD will break out on
them.

The later instruction prohibits the access the earlier signal released.
S077-E001 closes:

```text
BEFORE SIGNAL: DON'T ASCEND/TOUCH
-> WHEN LONG TRUMPET SOUNDS: THEY SHALL COME UP
-> LONG/LOUDER TRUMPET SOUNDS
-> LORD: WARN PEOPLE NOT TO BREAK THROUGH
-> LORD: DON'T LET PEOPLE OR PRIESTS COME UP
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the trumpet-access boil, licks his finger and walks away without
looking back. The people remain below and Moses remains responsible for the
boundary.

Moses responds:

> **THE PEOPLE CAN'T COME UP TO MOUNT SINAI.**

He gives the retained reason: the LORD already warned them to set bounds and
sanctify the mountain.

The LORD does not accept that completed-control answer as closure. He repeats:

> **GO DOWN.**

> **DON'T LET THE PRIESTS AND THE PEOPLE BREAK THROUGH TO COME UP.**

S078-E001 closes:

```text
MOSES: PEOPLE CANNOT COME UP BECAUSE BOUNDARY ALREADY INSTALLED
-> LORD: GO DOWN AND PREVENT PEOPLE/PRIESTS FROM COMING UP
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the cannot-happen/prevent-it boil, licks his finger and walks away
without looking back. Moses goes down and tells the people.

Aaron alone is newly authorized to come up with Moses. Priests and people are
not. The chapter does not narrate Aaron's ascent yet.

The LORD's earlier `in sight of all people` descent and later no-breakthrough-
to-gaze warning are retained as supporting visual-boundary friction, not a
third contradiction. The people observe mountain effects while the forbidden
act is breaking through to gaze at the LORD; the source does not prove those
are identical observation scopes.

## Character and world-ledger changes

- Israel moves Rephidim to Sinai wilderness and camps below the mountain;
- conditional covenant/possession/priest-kingdom/holy-nation terms enter State;
- all-people commitment is recorded without importing future compliance;
- Moses performs repeated mountain ascent/descent, relay and boundary acts;
- Sinai gains sanctified perimeter, human/animal death rule and trumpet-based
  access condition;
- people wash clothes, are sanctified, receive readiness/sexual-abstinence
  instruction and tremble at third-day effects;
- priests enter as an existing near-LORD class without names, appointment
  history or lineage supplied here;
- Aaron gains exclusive future ascent permission with Moses;
- S077 records signaled ascent permission followed by continued prohibition;
- S078 records asserted impossibility followed by renewed prevention command;
- no human or animal boundary violation/death occurs in the chapter;
- Joseph bones remain in transport; burial open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — SINAI ACCESS CONTROL BETA`;
- covenant signup: `CLICK OBEY TO BECOME PRIEST-KINGDOM`;
- laundry notice: `WASH GARMENTS / GOD ARRIVES THIRD DAY`;
- perimeter warning: `DO NOT TOUCH OFFENDER / PLEASE STONE REMOTELY`;
- animal sign: `JOE-FACED LIVESTOCK ALSO NOT AUTHORIZED`;
- trumpet panel: `ACCESS SIGNAL: EXTREMELY LOUD AND GETTING LOUDER`;
- gate display: `COME UP: YES / COME UP: ABSOLUTELY NOT`;
- CrackFlix: `S077 E001 — SIGNAL-BASED DENIAL`;
- Moses control report: `BREACH IMPOSSIBLE / SEND SECURITY AGAIN`;
- CrackFlix: `S078 E001 — CAN'T HAPPEN PREVENTION PLAN`;
- Aaron pass: `PLUS-ONE OVERRIDE / NOT YET USED`;
- barcode: `CHB-EXO19-S077-S078-25-YOINK-YOINK`.

## FIR verification

- all 25 verse markers are represented in order;
- covenant outcomes remain conditional and future performance stays open;
- all-people promise is retained at its exact Moment;
- direct LORD speech, Moses relays/addition and narrator effects remain distinct;
- trumpet permission does not close until the long/loud signal actually occurs;
- S077 preserves the initial prohibition, signal exception, performed signal and
  renewed prohibition;
- S078 preserves Moses' installed-boundary reason and LORD's repeated prevention;
- sight/gaze scopes are not silently merged into a third episode;
- priests are not backfilled with appointment history;
- Aaron permission is not marked as an ascent act;
- no boundary offender or death is invented;
- every living human and possible animal shown has Joe's face;
- Captain remains boilless and causally useless;
- Joseph bones transport remains active and burial open;
- publication remains held and unpublished.

Continuation required: Exodus 20 reconstructs the direct commandments, people's
distance request, Moses mediation, altar material rules and the relation between
the anti-image command and later altar construction instructions.
