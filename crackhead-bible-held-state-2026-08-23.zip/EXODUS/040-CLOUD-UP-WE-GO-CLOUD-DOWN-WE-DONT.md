# CRACKHEAD EXODUS 40

## Title page

**CLOUD UP: WE GO.**

**CLOUD DOWN: WE DON'T.**

Source parent: Exodus chapter 40, verses 1–38, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-EXO-040/job.json` and `source.usfm`.

Parent manuscript: `EXODUS/039-TWELVE-NAMES-GOLD-FRUIT-BELLS-AND-MOSES-SIGNS-OFF.md`.

CrackFlix routing:

- `S091-E002-EXO40 — PRIEST-FLESH OIL APPLICATION DECLARED COMPLETE`;
- `SKIP -> S091-E001-EXO30`.

## Causal foundation

```text
LORD COMMANDS FIRST-MONTH-FIRST-DAY INSTALL
-> STRUCTURE / FURNITURE / COURT PLACEMENT ORDER GIVEN
-> OBJECT + PRIEST ANOINTING ORDER GIVEN
-> MOSES DOES ALL COMMANDED
-> TABERNACLE RAISED AND FURNISHED
-> BREAD SET / LAMPS LIT / INCENSE BURNED / OFFERINGS MADE
-> BASIN FILLED / MOSES + AARON + SONS WASH
-> COURT CLOSES INSTALLATION
-> CLOUD COVERS TENT / GLORY FILLS TABERNACLE
-> MOSES CANNOT ENTER WHILE CLOUD STAYS
-> CLOUD UP = ISRAEL TRAVELS
-> CLOUD STAYS = ISRAEL STAYS
-> DAY CLOUD / NIGHT FIRE REMAINS VISIBLE
```

## Exodus 40:1–15 — INSTALLATION COMMAND

The LORD directly tells Moses to raise the Tabernacle of the Tent of Meeting on
the first day of the first month; install and veil the covenant ark; arrange
the table; bring and light the lampstand; place the gold incense altar and door
screen; place the burnt altar; put the water-filled basin between altar and
Tent; and raise the surrounding court and gate screen.

Moses is commanded to anoint the Tabernacle, everything in it, all furniture,
the burnt altar and vessels, and the basin/base. The stated result is holy,
with the burnt altar most holy.

He is also told to bring Aaron and sons to the door, wash them, dress Aaron in
holy garments, anoint/sanctify him, put tunics on his sons and anoint them as
their father was anointed. The stated result is priestly ministry and an
everlasting priesthood through their generations. Those effects remain direct
divine claims.

This repeats the retained S091 friction: named men must receive the exact holy
oil while its rule says it shall not be poured on man's flesh without expressly
stating the priest-flesh exception.

## Exodus 40:16–21 — MOSES DOES IT; ARK GOES IN

The source says Moses did according to all the LORD commanded. On year two,
month one, day one, the Tabernacle is raised. Moses lays sockets, boards, bars
and pillars, then spreads the tent covering and roof.

He puts the covenant into the ark, sets its poles and mercy seat, brings the ark
inside, raises the veil and screens it.

The `all` completion includes the commanded object and priest anointing acts,
although the source does not separately narrate the oil's contact method or
each person's application. S091-E002 therefore records performed application
at the source-declared boundary without inventing missing mechanics.

Captain presses:

> **SKIP -> S091-E001**

His eyes glaze. Moses still does everything commanded.

Captain Crackhead: **YOINK!**

He pokes Aaron's anointing boil, licks his finger and walks away without
looking back. The priest installation State remains unchanged.

## Exodus 40:22–29 — TABLE, LIGHT, INCENSE, OFFERINGS

Moses places the table north of the veil and orders the bread on it before the
LORD. He places the lampstand opposite it on the south and lights the lamps. He
places the gold altar before the veil and burns sweet-spice incense. He raises
the entrance screen, places the burnt altar at the Tent door and offers burnt
and meal offerings.

The formerly completed-but-unused furnishings now become placed and used.
Offering animal/material identity, quantities and procedure are not supplied
here and are not invented.

## Exodus 40:30–33 — BASIN, WASHING, COURT

Moses places the basin between Tent and altar, fills it with washing water, and
Moses, Aaron and Aaron's sons wash hands and feet there when entering the Tent
or approaching the altar. Moses raises the court and gate screen, finishing
the work.

The washing event is observed. The earlier no-death outcome remains a divine
rule claim; this chapter records no death test.

## Exodus 40:34–35 — OCCUPIED; MOSES LOCKED OUT

The cloud covers the Tent, and the source says the LORD's glory fills the
Tabernacle. Moses cannot enter because the cloud stays on it and the glory
fills it.

Moses' earlier access and present non-entry do not conflict: the source supplies
the changed cloud/glory condition. The mechanism of incapacity remains
attributed and unexplained.

## Exodus 40:36–38 — THE TRAVEL SIGNAL

Across Israel's journeys, cloud lifted from the Tabernacle means the children
of Israel travel onward. Cloud not lifted means they do not travel until the
day it lifts. The LORD's cloud is visible over the Tabernacle by day, with fire
in it by night, before all Israel.

This establishes the travel-state rule; it does not narrate a specific new
departure in verse 36. Destination, route, journey count and next lifting time
remain open.

## Character and world-ledger changes

- the commanded Tabernacle becomes erected on year two/month one/day one;
- covenant enters the ark; ark, mercy seat, veil, table/bread, lampstand/lamps,
  gold altar/incense, door screen, burnt altar/offerings, basin/water and court
  all become installed or operated as narrated;
- Moses' all-commanded completion advances Aaron/sons washing, dressing and
  holy-oil anointing while retaining missing application mechanics;
- S091 gains a performed priest-flesh oil occurrence with exact pointer to E001;
- Moses, Aaron and sons actually wash hands and feet for Tent/altar approach;
- cloud coverage and attributed glory occupation prevent Moses' entry;
- cloud-lift/travel and cloud-stay/wait becomes Israel's retained journey rule;
- outside-camp Tent and newly erected Tabernacle/Tent are not silently merged;
- Exodus construction reaches installed operational State;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — INSTALL.EXE`;
- date field: `YEAR 2 / MONTH 1 / DAY 1 / DEPLOY`;
- ark dialog: `COVENANT INSERTED / LID ON / VEIL ENABLED`;
- table: `BREAD ORDERED`;
- lamp panel: `SEVEN OUTPUTS: ON`;
- smell altar: `INCENSE PROCESS RUNNING`;
- basin: `WATER PRESENT / HANDS + FEET VERIFIED`;
- CrackFlix: `SKIP -> S091-E001 / MEN STILL ANOINTED`;
- occupancy alert: `CLOUD FULL / MOSES ACCESS DENIED`;
- journey controller: `CLOUD UP = MOVE / CLOUD DOWN = PARK`;
- night mode: `FIRE INSIDE CLOUD / ALL ISRAEL CAN SEE`;
- barcode: `CHB-EXO40-S091-E002-38-1SKIP-1YOINK-BOOK-CLOSED`.

## FIR verification

- all 38 verse markers are represented in order;
- every placement/anointing/washing command in verses 1–15 is retained as
  direct LORD speech;
- divine holiness/priesthood effects remain attributed claims;
- the source's all-commanded completion is retained without inventing oil
  contact mechanics;
- S091-E002 is a performed occurrence and points exactly to S091-E001;
- SKIP changes neither installation nor application;
- Captain says exactly `YOINK!`, has no boils and changes nothing;
- year/month/day, erection sequence and every furnishing placement are retained;
- bread, lamps, incense, offerings and washing become actual acts without
  invented quantities or procedures;
- cloud-caused entry prevention is a changed condition, not a contradiction;
- travel verses establish a repeated rule without inventing a departure here;
- outside-camp Tent identity remains unresolved rather than merged;
- every living being and interpreted face uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Leviticus 1 begins the Tent-from-inside offering rules
from the erected operational boundary.
