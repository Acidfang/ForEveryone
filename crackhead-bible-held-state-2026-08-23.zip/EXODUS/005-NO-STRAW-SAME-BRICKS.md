# CRACKHEAD EXODUS 5

## Title page

**NO STRAW SHALL BE GIVEN.**

**DELIVER THE SAME NUMBER OF BRICKS.**

Source parent: Exodus chapter 5, verses 1–23, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 5.

Prepared evidence: `.chapter-work/CHB-EXO-005/job.json` and `source.usfm`.

Parent manuscript: `EXODUS/004-THEY-WONT-BELIEVE-ME-THEY-BELIEVED.md`.

CrackFlix routing: new `S063 — NO INPUT. SAME OUTPUT.`, episode
`S063-E001-EXO5 — NO STRAW; SAME BRICKS`.

## Causal foundation

```text
MOSES+AARON: LORD SAYS LET PEOPLE GO FOR WILDERNESS FEAST
-> PHARAOH: DO NOT KNOW LORD / WILL NOT RELEASE
-> THREE-DAY SACRIFICE REQUEST + PESTILENCE/SWORD WARNING
-> PHARAOH: RETURN TO BURDENS / PEOPLE MANY / YOU MAKE THEM REST
-> SAME-DAY ORDER: STOP GIVING STRAW
-> PEOPLE MUST GATHER OWN STRAW
-> REQUIRE SAME PRIOR BRICK NUMBER / DIMINISH NOTHING
-> HEAVIER WORK / IGNORE "LYING WORDS"
-> TASKMASTERS/OFFICERS DELIVER ORDER
-> PEOPLE SCATTER THROUGH EGYPT FOR STUBBLE
-> DAILY QUOTA AS WHEN STRAW EXISTED
-> ISRAEL OFFICERS BEATEN FOR MISSED YESTERDAY/TODAY QUOTA
-> OFFICERS REPORT NO STRAW + BEATING + FAULT
-> PHARAOH REPEATS IDLE / NO STRAW / SAME BRICKS
-> OFFICERS SEE TROUBLE
-> OFFICERS BLAME MOSES+AARON / DEATH-RISK CLAIM
-> MOSES ASKS LORD WHY TROUBLE/SENDING
-> MOSES: PHARAOH TROUBLED PEOPLE / NO RESCUE AT ALL
```

## Exodus 5:1–5 — THE FIRST PHARAOH AUDIENCE

Moses and Aaron deliver the LORD-attributed feast/release message. Pharaoh says
he does not know the LORD, will not listen and will not let Israel go. They ask
for a three-day wilderness sacrifice journey and state pestilence/sword risk.
That risk remains their speech; no such event occurs here.

Pharaoh tells Moses/Aaron to return people to burdens and says the many people
are being made to rest. The Exodus 3 refusal prediction now has an observable
matching refusal, but prediction correspondence is not a contradiction.

## Exodus 5:6–14 — REMOVE STRAW, PRESERVE QUOTA, BEAT OFFICERS

The same day Pharaoh orders taskmasters and Israel officers to stop supplying
straw. Workers must gather it themselves. Pharaoh explicitly retains the prior
brick number and forbids any reduction, calls the people idle, orders heavier
work and labels the message lying words.

Taskmasters/officers repeat the order. People scatter across Egypt gathering
stubble. Taskmasters demand the daily quota `AS WHEN THERE WAS STRAW`. Israel
officers are beaten and questioned for failing yesterday's and today's prior
quota.

This completes S063:

```text
PRIOR PROCESS: SUPPLIED STRAW + BRICK QUOTA
-> SUPPLIED STRAW REMOVED
-> WORKERS MUST ADD STRAW-GATHERING WORK
-> OLD BRICK QUOTA PRESERVED WITHOUT DIMINUTION
-> MISSED OLD QUOTA
-> OFFICERS BEATEN FOR THE MISS
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain pokes the quota boil, licks his finger, walks away and never looks back.
No straw returns and nobody's quota changes.

## Exodus 5:15–19 — THE POLICY EXPLAINS ITSELF AGAIN

Israel officers ask Pharaoh why servants receive no straw, are ordered to make
bricks and are beaten, and assign fault to Pharaoh's people. Pharaoh repeats
`YOU ARE IDLE`, orders work, confirms no straw and requires the same number of
bricks. The officers see they are in trouble under the unchanged daily quota.

This is the same S063 episode, not a new occurrence. Captain's display points:

`SKIP -> S063-E001 / NO STRAW; SAME BRICKS`

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

His eyes glaze while Pharaoh finishes. Nothing skips. No second YOINK is needed
for the same retained policy occurrence.

## Exodus 5:20–23 — RESULT REPORTED UPWARD

The officers meet Moses/Aaron and ask the LORD to judge them, saying they made
Israel abhorrent to Pharaoh/servants and put a sword in their hand to kill.
Those causal/death claims remain officer speech.

Moses returns to the LORD and asks why God brought trouble and sent him. He says
that since the Pharaoh audience, Pharaoh has troubled the people and God has not
rescued them at all. Within this chapter, no rescue has occurred. The broader
deliverance promise remains open rather than contradicted by an unfinished act.

## Character and world-ledger changes

- Moses/Aaron complete first Pharaoh message and receive refusal; Moses later
  reports the worsened observed State to the LORD.
- Pharaoh moves from predicted refuser to observed refuser and imposes the
  no-straw/same-quota system.
- taskmasters transmit/enforce urgency and beat Israel officers.
- Israel officers transmit policy, are beaten, appeal to Pharaoh, receive the
  repeated rule and confront Moses/Aaron.
- workers scatter through Egypt for stubble while retaining brick work.

## Bullshit pass

- banner: `CRACKHEAD BRICK SERVICE — MATERIALS NOT INCLUDED`;
- quota form: `INPUT: 0 STRAW / OUTPUT: SAME BRICKS / EXCUSES: LYING`;
- efficiency upgrade: `ADDITIONAL GATHERING WORK / ZERO SCHEDULE CHANGE`;
- officer review: `WHY MISSED? / BEAT FIRST / ROOT CAUSE ATTACHED`;
- CrackFlix: `S063-E001 — SUPPLY CHAIN OPTIMISATION`;
- barcode: `CHB-EXO5-S063E001-23-YOINK`.

## FIR verification

- all 23 verse markers are represented in order;
- Pharaoh refusal is observed and does not retroactively perform later release;
- pestilence/sword, idleness, lying, stench/death and divine-trouble relations
  remain attributed speech;
- S063 uses explicit removed straw, retained quota, added gathering, failure and
  punishment States;
- repeated policy explanation uses addressed SKIP and remains same episode;
- Moses' no-rescue statement is true at the chapter boundary and does not close
  or cancel the unfinished deliverance promise;
- God does not speak or directly act in this chapter;
- publication remains held and unpublished.

Continuation required: Exodus 6 reconstructs the divine response, name/covenant
speech, Israel non-listening under anguish, renewed commission, Moses objection
and the Reuben/Simeon/Levi-to-Moses/Aaron genealogy.
