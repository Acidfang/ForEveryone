# CRACKHEAD EXODUS 2

## Title page

**THROW EVERY SON IN THE RIVER.**

**I DREW THIS HEBREW SON OUT. HE IS MY SON.**

Source parent: Exodus chapter 2, verses 1–25, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 2.

Prepared evidence: `.chapter-work/CHB-EXO-002/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/001-DEAL-WISELY-SO-THEY-DONT-MULTIPLY-THEY-MULTIPLIED-MORE.md`.

CrackFlix routing: new `S061 — THROW EVERY SON IN THE RIVER. THIS ONE IS MY
SON.`, episode `S061-E001-EXO2 — PHARAOH'S DAUGHTER DREW HIM OUT`.

## Causal foundation

```text
PHARAOH ORDER: EVERY BORN SON -> RIVER
-> LEVI MAN + LEVI WOMAN / SON BORN
-> MOTHER HIDES SON THREE MONTHS
-> CANNOT HIDE LONGER
-> PAPYRUS BASKET + TAR/PITCH / CHILD IN REEDS BY RIVER
-> SISTER WATCHES
-> PHARAOH DAUGHTER BATHES / SEES / SERVANT FETCHES
-> OPENS / SEES CRYING CHILD / COMPASSION
-> PHARAOH DAUGHTER IDENTIFIES HEBREW CHILD
-> SISTER OFFERS HEBREW NURSE / MOTHER CALLED
-> PHARAOH DAUGHTER PAYS MOTHER TO NURSE CHILD
-> CHILD GROWS / BROUGHT TO PHARAOH DAUGHTER
-> BECOMES HER SON / NAMED MOSES: DRAWN OUT OF WATER
-> GROWN MOSES SEES EGYPTIAN STRIKE HEBREW
-> LOOKS BOTH WAYS / SEES NO ONE / KILLS EGYPTIAN / HIDES BODY
-> NEXT DAY TWO HEBREWS FIGHT / MOSES QUESTIONS WRONGDOER
-> WRONGDOER NAMES PRIOR KILLING / MOSES SAYS MATTER KNOWN
-> PHARAOH HEARS / SEEKS TO KILL MOSES
-> MOSES FLEES TO MIDIAN / WELL
-> SEVEN DAUGHTERS DRAW WATER / SHEPHERDS DRIVE THEM AWAY
-> MOSES HELPS / WATERS FLOCK
-> DAUGHTERS REPORT EGYPTIAN DELIVERED THEM
-> REUEL CALLS MOSES / MOSES DWELLS / RECEIVES ZIPPORAH
-> ZIPPORAH BEARS GERSHOM / MOSES NAMES FOREIGNER STATE
-> EGYPT KING DIES
-> ISRAEL SIGHS/CRIES UNDER BONDAGE
-> GOD HEARS / REMEMBERS COVENANT / SEES / UNDERSTANDS
```

## Exodus 2:1–10 — THE RIVER RETURNED A SON TO PHARAOH'S HOUSE

An unnamed Levi-house man takes an unnamed Levi daughter as wife. She conceives,
bears a son, sees that he is fine and hides him three months. The chapter does
not yet supply the parents' later names.

When she can no longer hide him, she makes a papyrus basket, coats it with tar
and pitch, puts the child inside and lays it among reeds by the river bank. His
unnamed sister stands far away to observe what happens.

Pharaoh's daughter comes to bathe. Her maidens walk beside the river. She sees
the basket and sends her servant to fetch it. She opens it, sees the crying baby,
has compassion and says:

> **PHARAOH'S DAUGHTER JOE:** `THIS IS ONE OF THE HEBREWS' CHILDREN.`

The sister offers to call a Hebrew nurse. Pharaoh's daughter says `GO`; the
sister calls the child's own mother. Pharaoh's daughter orders the mother to
nurse the child for her and promises wages. The mother takes and nurses him.

When the child grows, his mother brings him to Pharaoh's daughter. He becomes
her son. She names him Moses and says she drew him out of the water.

That completes S061 against the still-active Exodus 1 order:

```text
PHARAOH: EVERY BORN SON -> RIVER
-> PHARAOH DAUGHTER KNOWS THIS IS A HEBREW CHILD
-> DRAWS HIM OUT OF WATER
-> PAYS HIS MOTHER TO NURSE HIM
-> MAKES HIM HER SON
```

The text does not say Pharaoh's daughter knows the order, opposes her father or
intends resistance. S061 needs none of those claims. The authority-house result
and the universal order are both observable.

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain pokes the royal-adoption boil, licks his finger, walks away and never
looks back. Moses remains alive and adopted.

## Exodus 2:11–15 — NO ONE SAW; THE MATTER IS KNOWN

After Moses grows, he goes to his brothers and sees their burdens. He sees an
Egyptian striking a Hebrew, looks both ways, sees no one, kills the Egyptian and
hides the body in sand.

The next day he sees two Hebrew men fighting and asks the one doing wrong why he
strikes his fellow. The man asks who made Moses prince/judge and whether Moses
plans to kill him as he killed the Egyptian.

Moses is afraid and says the matter is known. Pharaoh hears and seeks to kill
him. Moses flees Pharaoh, lives in Midian and sits by a well.

`He saw no one` is bounded to Moses' prior visual check. The later speaker's
knowledge does not prove who observed, how information travelled or that Moses
claimed nobody could ever know. No fake contradiction or reporter is invented.

## Exodus 2:16–22 — THE EGYPTIAN IN MIDIAN

The priest of Midian has seven daughters. They draw water and fill troughs for
their father's flock. Shepherds drive them away; Moses stands, helps them and
waters the flock.

They return early to their father Reuel and report that `an Egyptian` delivered
them and watered the flock. This is their identification of Moses, not a source
identity replacement. Reuel asks why they left the man and tells them to call
him to eat bread.

Moses is content to dwell with Reuel. Reuel gives his daughter Zipporah to
Moses. She bears a son; Moses names him Gershom because he has lived as a
foreigner in a foreign land.

## Exodus 2:23–25 — GOD HEARD, REMEMBERED, SAW AND UNDERSTOOD

During the many days, the king of Egypt dies. Whether this is the Exodus 1 king
or a later same-title Joe is not independently identified beyond the continuous
king-of-Egypt role.

The children of Israel sigh and cry because of bondage. Their cry comes to God.
The source directly narrates that God hears their groaning, remembers the
covenant with Abraham, Isaac and Jacob, sees the children of Israel and
understands.

These are God-only source acts without direct dialogue. Exodus 2 does not yet
narrate release, Moses' return or Joseph's bone transport.

## Character and world-ledger changes

- Moses advances from unnamed hidden Levi son to nursed child, Pharaoh-daughter
  son, named adult, Egyptian killer, exposed fugitive, Midian resident, husband
  and father.
- Moses' mother, father and sister remain unnamed but distinct; the mother is
  paid to nurse her own child after the sister arranges contact.
- Pharaoh's daughter identifies Moses as Hebrew, extracts/adopts him and remains
  distinct from her servant and maidens.
- the killed Egyptian, struck Hebrew and two fighting Hebrew men remain distinct
  Joes; no witness or information route is invented.
- Reuel, Zipporah, six other daughters, shepherds and flock enter the Midian
  State; every person and animal retains separate identity.
- Gershom becomes a distinct named son of Moses and Zipporah.
- the king of Egypt dies; Israel remains in bondage while divine
  hearing/remembrance/seeing/understanding becomes the open Exodus 3 parent.

## Bullshit pass

- banner: `CRACKHEAD EXODUS 2 — RIVER RETURNS DEPARTMENT`;
- basket: `CRACKHEAD SON SHIPPING / TAR + PITCH / DO NOT SUBMERGE`;
- nurse invoice: `MOTHER HIRED TO PERFORM MOTHER`;
- royal form: `ITEM: HEBREW SON / SOURCE: WATER / STATUS: MY SON`;
- sand grave: `NO ONE SAW / CUSTOMER FEEDBACK RECEIVED NEXT DAY`;
- Midian well: `EGYPTIAN JOE WATERED IT / IDENTITY CONTINUITY INCLUDED`;
- Gershom card: `GUEST-ROOM JOE / FOREIGNER IN FOREIGN LAND`;
- divine ledger LEDs: `HEARD / REMEMBERED / SAW / UNDERSTOOD`;
- barcode: `CHB-EXO2-S061E001-25-YOINK`.

## FIR verification

- all 25 verse markers are represented in order;
- Exodus 1 river order remains the exact parent of S061 rather than being
  restated as an invented death-purpose or daughter knowledge State;
- the child is identified as Hebrew, drawn from water, nursed and adopted by
  Pharaoh's daughter before S061 closes;
- unnamed parents/sister, Pharaoh daughter/servants, Hebrew men, Midian family,
  shepherds and animals remain distinct;
- Moses' no-one-seen check is not expanded into an unsupported universal claim;
- Moses' fear and foreigner statement remain attributed interiority/speech;
- the daughters' Egyptian identification does not replace Moses' Hebrew/Levite
  lineage;
- God's hearing, remembrance, seeing and understanding are narrator-assigned
  source acts; God does not speak directly;
- bondage, deliverance, return and Joseph bone oath remain open;
- publication remains held and unpublished.

Continuation required: Exodus 3 reconstructs Moses shepherding at Horeb, the
burning bush encounter, God-only commission/name lines, elder/Pharaoh message,
predicted refusal, signs and Egypt-property departure instructions.
