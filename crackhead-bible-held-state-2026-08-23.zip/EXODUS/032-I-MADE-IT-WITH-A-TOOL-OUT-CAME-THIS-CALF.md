# CRACKHEAD EXODUS 32

## Title page

**HE FASHIONED IT WITH AN ENGRAVING TOOL.**

**I THREW IT INTO THE FIRE, AND OUT CAME THIS CALF.**

Source parent: Exodus chapter 32, verses 1–35, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 32.

Prepared evidence: `.chapter-work/CHB-EXO-032/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/031-I-CALLED-BEZALEL-BY-NAME-GODS-FINGER-WROTE-THE-TABLETS.md`.

CrackFlix routing:

- `S092-E001-EXO32 — WHO BROUGHT US OUT? MOSES / CALF / LORD`;
- `S093-E001-EXO32 — ENGRAVING TOOL / MAGIC FIRE CALF`.

No SKIP is valid. Both contradiction types occur here for the first retained
time.

## Causal foundation

```text
MOSES DELAYS DESCENDING
-> PEOPLE ASK AARON TO MAKE GODS
-> AARON ORDERS GOLD REMOVED AND BROUGHT
-> PEOPLE BRING GOLD
-> AARON RECEIVES IT
-> AARON FASHIONS IT WITH AN ENGRAVING TOOL
-> AARON MAKES ONE MOLDED CALF
-> PEOPLE ASSIGN THE EGYPT EXIT TO THE CALF
-> AARON BUILDS ALTAR / PROCLAIMS LORD FEAST
-> OFFERINGS + EATING + DRINKING + PLAY
-> LORD REPORTS THE CALF STATE TO MOSES
-> LORD PROPOSES CONSUMPTION / MOSES APPEALS
-> LORD RELENTS FROM THE ANNOUNCED HARM
-> MOSES DESCENDS WITH TWO GOD-WRITTEN TABLETS
-> MOSES SEES CALF/DANCING
-> MOSES BREAKS TABLETS
-> MOSES BURNS / GRINDS / SCATTERS CALF ON WATER
-> MOSES MAKES ISRAEL DRINK
-> AARON REPORTS GOLD INTO FIRE / CALF CAME OUT
-> LEVITES KILL ABOUT THREE THOUSAND
-> MOSES SEEKS ATONEMENT
-> LORD ORDERS CONTINUED LEADING AND FUTURE PUNISHMENT
-> LORD STRIKES PEOPLE BECAUSE OF CALF AARON MADE
```

## Exodus 32:1–6 — MAKE US GODS

The people see that Moses delays coming down. They gather to Aaron and ask him
to make gods to go before them. They call Moses the man who brought them from
Egypt and say they do not know what became of him.

Aaron tells them to remove the gold rings from the ears of wives, sons and
daughters and bring them to him. The people remove and bring the rings. Aaron:

- receives the gold;
- fashions it with an engraving tool;
- makes it a molded calf.

The people call the calf their gods and say it brought Israel from Egypt.
Aaron sees, builds an altar before it and proclaims a feast to the LORD for the
next day. They rise, offer burnt and peace offerings, eat, drink and rise to
play. The source supplies no private belief, intoxication, sexual act or hidden
reason behind “play.”

## Exodus 32:7–14 — YOUR PEOPLE / YOUR PEOPLE

The LORD tells Moses to descend because `your people, whom you brought up out
of Egypt` corrupted themselves. God reports the calf, worship, sacrifices and
the people's calf-origin claim. God calls them stiff-necked and tells Moses to
leave him alone so wrath may consume them and Moses may become a great nation.

Moses asks why wrath burns against `your people, whom you have brought out of
Egypt`. He asks what Egyptians would say and invokes Abraham, Isaac and Israel
and the sworn descendants/land promise. The LORD relents from the harm stated
against the people. The announced consumption does not occur here.

S092-E001 closes without guessing a theology:

```text
PEOPLE: MOSES BROUGHT US OUT
PEOPLE: THIS NEW CALF BROUGHT US OUT
LORD TO MOSES: YOU BROUGHT YOUR PEOPLE OUT
MOSES TO LORD: YOU BROUGHT YOUR PEOPLE OUT
-> ONE RETAINED EXIT / MULTIPLE INCOMPATIBLE OWNERS
```

Captain Crackhead appears only after the claims coexist. `YOINK!` He pokes the
calf-origin boil, licks his finger and walks away without looking back. Everyone
else continues exactly as before.

## Exodus 32:15–20 — THE TABLETS DO NOT SURVIVE THE DESCENT

Moses turns and descends carrying the two tablets. They are written on both
sides. The tablets are God's work and the writing is God's writing engraved on
them. Joshua hears the people and calls it war noise. Moses says it is neither
victory nor defeat but singing.

When Moses sees the calf and dancing, his anger burns. He throws the tablets
from his hands and breaks them below the mountain. The delivered-tablet State
therefore changes to two broken tablets; the source does not say their fragments
or writing disappear.

Moses takes the calf, burns it, grinds it to powder, scatters the powder on the
water and makes Israel drink. No chemical mechanism, dose, vessel, bodily
result or individual refusal is supplied.

## Exodus 32:21–24 — OUT CAME THIS CALF

Moses asks Aaron what the people did to him that he brought so great a sin on
them. Aaron tells Moses not to be angry, says Moses knows the people are set on
evil, and repeats their request and uncertainty about Moses.

Aaron then reports:

> **I SAID, WHOEVER HAS GOLD, TAKE IT OFF.**

> **THEY GAVE IT TO ME.**

> **I THREW IT INTO THE FIRE.**

> **OUT CAME THIS CALF.**

The earlier observed chain remains:

```text
AARON RECEIVED GOLD
-> AARON FASHIONED IT WITH AN ENGRAVING TOOL
-> AARON MADE THE MOLDED CALF
```

Aaron's later account removes both observed fabrication acts and substitutes
an emergence from fire. S093-E001 closes on the recorded act/account mismatch.
No motive, lie diagnosis, memory failure or supernatural fabrication is added.

Aaron turns toward the reader:

> **I DIDN'T MEAN THAT.**

*shrug*

Crack.

Captain Crackhead: **YOINK!**

He pokes Aaron's account boil, licks his finger and walks away without looking
back. Aaron and Moses continue without any Captain-caused change.

## Exodus 32:25–29 — GATE TO GATE

Moses sees the people are out of control; the narrator attributes their lost
restraint and enemy derision to Aaron. Moses stands at the camp gate and calls
those on the LORD's side. All sons of Levi gather to him.

Moses attributes a command to the LORD: each man is to wear his sword, travel
gate to gate and kill brother, companion and neighbour. The Levites do according
to Moses' word. About three thousand men fall that day. Moses tells them to
consecrate themselves to the LORD, each against son and brother, so a blessing
may be given that day.

The source records the deaths. It does not identify each killer or dead Joe,
map kin relations, supply resistance, describe wounds, or say Captain affects
the event.

## Exodus 32:30–35 — THE BOOK, THE ANGEL, THE PLAGUE

The next day Moses tells the people they committed a great sin and says he will
go to the LORD, perhaps to make atonement. He tells the LORD the people made
gold gods and asks for forgiveness, otherwise asking to be blotted from God's
written book.

The LORD says the one who sinned will be blotted out, orders Moses to lead the
people to the previously stated place, says the angel will go before him, and
retains future punishment for the day of visitation. The LORD then strikes the
people because of what they did with the calf Aaron made.

The source does not identify the plague's symptoms, number affected, duration,
deaths, recovery, book contents, blotting act, angel identity or visit date.
The final narrator wording retains Aaron as the calf maker; it does not adopt
Aaron's fire-emergence account.

## Character and world-ledger changes

- Aaron advances from prospective priest/dispute address to observed gold
  collector, engraver, calf maker, altar builder and feast proclaimer;
- Aaron's later fire account is retained as speech and conflicts with his
  observed manufacture without an invented motive;
- Moses descends, breaks the tablets, destroys the calf, makes Israel drink,
  calls the Levites, reports the killing command and seeks atonement;
- Joshua hears the camp and supplies a war-noise assessment; Moses supplies a
  singing assessment;
- Israel supplies gold, worships/sacrifices, eats/drinks/plays, loses restraint,
  suffers about three thousand deaths and is struck by the LORD;
- the Levite group gathers and performs the gate-to-gate killing;
- the one molded calf is nonliving, although any depicted face receives Joe's
  face under Crackheadverse face interpretation;
- the two delivered tablets become broken tablets below the mountain;
- S092 records competing ownership of the completed Egypt exit;
- S093 records Aaron's observed manufacture against his retrospective account;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — GOLD SUPPORT TICKET ESCALATION`;
- calf label: `ONE UNIT / GODS PLURAL / LEGACY EXIT PROVIDER`;
- Aaron workstation: `CRACKHEAD ATOMIC ENGRAVING / FIRE IMPORT ENABLED`;
- CrackFlix: `S092 E001 — WHO EXPORTED ISRAEL?`;
- CrackFlix: `S093 E001 — MANUAL BUILD / AUTOMATIC FIRE BUILD`;
- tablet warning: `TWO-SIDED DIVINE STORAGE / DROP TEST FAILED`;
- calf disposal: `BURN -> POWDER -> WATER -> USER INGESTION`;
- Levite counter: `APPROX. 3000 / IDENTITIES NOT EXPORTED`;
- book dialog: `DELETE ME INSTEAD / REQUEST DENIED`;
- barcode: `CHB-EXO32-S092-S093-35-2YOINK`.

## FIR verification

- all 35 verse markers are represented in order;
- seeing, saying, making, breaking, burning, grinding, drinking, killing,
  interceding and striking remain distinct observed or attributed acts;
- Moses, Aaron, Joshua, Levites, Israel, named ancestors, LORD and angel are not
  merged;
- one calf called plural gods is retained as wording but not promoted to a
  separate contradiction without a supplied number ontology;
- announced consumption changes after Moses' appeal and is not mislabeled as a
  contradiction;
- S092 retains all supplied Egypt-exit claimants without choosing a secret real
  speaker meaning;
- S093 compares the observed engraving/making chain only with Aaron's later
  account and invents no motive;
- the direct divine speech and Moses-attributed killing command remain
  distinguished from narrator-confirmed action;
- no SKIP is used because neither exact contradiction was previously retained;
- Captain appears only after each contradiction completes, says exactly
  `YOINK!`, has no boils, pokes/licks/walks away and changes nothing;
- all living beings use Joe face if shown;
- publication remains held and unpublished.

Continuation required: Exodus 33 reconstructs the commanded departure, angel
escort, absent divine presence, ornaments, Tent of Meeting and Moses' requests.
