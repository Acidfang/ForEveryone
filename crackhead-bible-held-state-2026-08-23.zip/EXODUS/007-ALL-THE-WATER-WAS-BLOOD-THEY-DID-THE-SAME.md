# CRACKHEAD EXODUS 7

## Title page

**BLOOD THROUGHOUT ALL EGYPT.**

**THE MAGICIANS DID THE SAME THING.**

Source parent: Exodus chapter 7, verses 1–25, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 7.

Prepared evidence: `.chapter-work/CHB-EXO-007/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/006-THEY-DIDNT-KNOW-MY-NAME-THEY-USED-MY-NAME.md`.

CrackFlix routing: new `S065 — ALL THE INPUT WAS CONVERTED. THEY CONVERTED
MORE.`, episode `S065-E001-EXO7 — ALL WATER BLOOD; MAGICIANS SAME`.

## Causal foundation

```text
LORD MAKES MOSES AS GOD TO PHARAOH / AARON PROPHET
-> HARDENING + SIGNS + JUDGMENTS + FUTURE EXIT SPEECH
-> MOSES/AARON OBEY / AGES 80 + 83
-> AARON ROD -> SERPENT BEFORE PHARAOH
-> WISE MEN/SORCERERS/MAGICIANS DO SAME / RODS -> SERPENTS
-> AARON ROD SWALLOWS THEIR RODS
-> PHARAOH HEART HARDENED / DOES NOT LISTEN
-> LORD: STUBBORN/REFUSES
-> RIVER-BANK RELEASE MESSAGE + BLOOD SIGN
-> AARON STRETCHES ROD OVER ALL EGYPT WATERS
-> RIVER WATERS TURN BLOOD BEFORE PHARAOH/SERVANTS
-> FISH DIE / RIVER FOUL / CANNOT DRINK
-> BLOOD THROUGHOUT ALL EGYPT
-> MAGICIANS DO SAME THING
-> PHARAOH HEART HARDENED / DOES NOT LISTEN / GOES HOME
-> EGYPTIANS DIG AROUND RIVER FOR DRINKING WATER
-> SEVEN DAYS AFTER LORD STRIKES RIVER
```

## Exodus 7:1–7 — GOD, PROPHET AND AGES

The LORD says Moses is made as God to Pharaoh and Aaron is Moses' prophet.
Moses must transmit commands; Aaron must speak release. God states future
hardening, multiplied signs/wonders, non-listening, judgments, exit and Egyptian
knowledge. Moses and Aaron do as commanded. Moses is eighty and Aaron
eighty-three at the Pharaoh speech boundary.

These role labels do not merge Moses with God or Aaron with a different Joe.

## Exodus 7:8–13 — SERPENT CONTEST

At the LORD's instruction Aaron casts his rod before Pharaoh/servants; it becomes
a Joe-faced living serpent. Pharaoh calls wise men, sorcerers and Egyptian
magicians. By enchantments each casts a rod and each becomes a separate serpent.
Aaron's rod swallows their rods.

The source supplies replication and swallowing but no enchantment mechanics,
rod recovery, serpent death or later magician inventory. Pharaoh's heart is
hardened and he does not listen, as the LORD had spoken. This clause does not
explicitly name an acting hardener, so none is inserted.

## Exodus 7:14–21 — ALL THE WATER TO BLOOD

The LORD calls Pharaoh's heart stubborn/refusing and orders a river-bank message.
The message repeats release for wilderness service and says the river strike
will identify the LORD. Fish death, foul river and undrinkable water are stated.

God orders Aaron's rod/hand stretched over Egypt's rivers, streams, pools, ponds
and all water so they become blood, including wood/stone vessels. Moses/Aaron
obey. The river is struck before Pharaoh and servants; all river water becomes
blood. Fish die, river becomes foul, Egyptians cannot drink, and blood is
throughout all Egypt.

## Exodus 7:22–25 — SAME THING AFTER ALL

Egypt's magicians do the same thing with enchantments. The immediately retained
same thing is water-to-blood, while the scoped water State says all Egypt water
and vessels became blood.

That completes S065:

```text
ALL SCOPED WATER -> BLOOD
-> BLOOD THROUGHOUT ALL EGYPT
-> MAGICIANS DO SAME WATER->BLOOD ACT
-> NO REMAINING WATER INPUT OR SOURCE ADDRESS SUPPLIED BEFORE THEIR ACT
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain pokes a blood-filled water jug boil, licks his finger, walks away and
never looks back. The magicians' act and missing input address remain unchanged.

Pharaoh's heart is hardened; he does not listen, returns home and does not take
it to heart. Egyptians then dig around the river for drinkable water because
river water cannot be drunk. This digging happens after the magician act and
cannot retroactively supply it. Seven days pass after the LORD strikes the river.

## Character and world-ledger changes

- Moses/Aaron gain stated ages and perform the Pharaoh serpent/blood acts under
  their source-assigned speech/rod routing.
- Pharaoh receives signs, remains non-listening and returns home.
- wise men/sorcerers/magicians replicate both observable transformation types;
  mechanisms and exact inputs remain unresolved.
- every serpent and fish is a distinct Joe-faced living organism; fish change
  to dead and serpent/rod outcomes remain source-bounded.
- Egyptians become water diggers after the river becomes undrinkable.

## Bullshit pass

- banner: `CRACKHEAD PLAGUE DEMO — WATER LICENCE REVOKED`;
- serpent contest: `AARON ROD ATE COMPETITOR INVENTORY`;
- magician console: `DO SAME / INPUT FIELD BLANK`;
- water scope: `RIVERS STREAMS POOLS PONDS WOOD STONE: BLOOD`;
- drinking support: `DIG BESIDE BROKEN WATER`;
- seven-day progress bar: `RIVER STRUCK / PHARAOH HOME`;
- barcode: `CHB-EXO7-S065E001-25-YOINK`.

## FIR verification

- all 25 verse markers are represented in order;
- Moses/God and Aaron/prophet role language does not merge identities;
- magician replication is retained without invented mechanism;
- hardening clauses remain attached to exact divine prediction or narrator
  passive wording;
- water scope, observed blood and magician same-act order close S065;
- later digging is not moved backward to supply magician input;
- every fish/serpent/person remains identity-distinct;
- direct LORD speech/action remains God-only;
- Israel exit and Joseph bone transport remain open;
- publication remains held and unpublished.

Continuation required: Exodus 8 reconstructs frogs, magician replication,
Pharaoh's removal request/promise/reversal, lice limit, fly distinction and
in-land sacrifice negotiations.
