# CRACKHEAD EXODUS 1

## Title page

**DEAL WISELY SO THEY DON'T MULTIPLY.**

**THE MORE WE AFFLICTED THEM, THE MORE THEY MULTIPLIED.**

Source parent: Exodus chapter 1, verses 1–22, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 1.

Prepared evidence: `.chapter-work/CHB-EXO-001/job.json` and `source.usfm`.

Parent manuscript: `GENESIS/050-THE-DEAD-FATHER-ADDED-TWO-COMMANDS.md`.

CrackFlix routing: existing `S010 — PREVENTED IT INTO HAPPENING`, episode
`S010-E002-EXO1 — AFFLICT THEM SO THEY DON'T MULTIPLY`.

## Causal foundation

```text
ISRAEL SONS/HOUSEHOLDS ENTERED EGYPT WITH JACOB; JOSEPH ALREADY THERE
-> JOSEPH / BROTHERS / THAT GENERATION DIE
-> CHILDREN OF ISRAEL MULTIPLY / GROW MIGHTY / FILL LAND
-> NEW KING DOES NOT KNOW JOSEPH
-> KING STATES ISRAEL MORE/MIGHTIER
-> KING: DEAL WISELY LEST THEY MULTIPLY / JOIN ENEMIES / FIGHT / LEAVE
-> TASKMASTERS / BURDENS / PITHOM + RAAMSES BUILT
-> MORE AFFLICTION -> MORE MULTIPLICATION + SPREADING
-> EGYPTIANS DREAD / RUTHLESS MORTAR-BRICK-FIELD SERVICE
-> KING COMMANDS SHIPHRAH + PUAH: KILL SONS / LET DAUGHTERS LIVE
-> MIDWIVES DO NOT OBEY / BOYS LIVE
-> KING QUESTIONS THEM
-> MIDWIVES: HEBREW WOMEN GIVE BIRTH BEFORE MIDWIFE ARRIVES
-> GOD DEALS WELL / PEOPLE MULTIPLY / MIDWIVES RECEIVE FAMILIES
-> PHARAOH EXPANDS ORDER TO ALL HIS PEOPLE: THROW EVERY SON IN RIVER
```

## Exodus 1:1–7 — THE GENESIS HOUSEHOLD BECOMES A PEOPLE

Reuben, Simeon, Levi, Judah, Issachar, Zebulun, Benjamin, Dan, Naphtali, Gad
and Asher are named as sons of Israel who entered Egypt with Jacob and their
households. The source gives seventy souls from Jacob's body and says Joseph was
already in Egypt. These are retained identities, not seventy copies of one Joe.

Joseph, all his brothers and that generation die. Joseph's coffin and bones
remain in Egypt from Genesis 50; this chapter does not yet carry them out.

The children of Israel are fruitful, multiply, grow exceedingly mighty and fill
the land. Population State changes; no individual birth inventory is supplied.

## Exodus 1:8–12 — WISE PREVENTION

A new king arises over Egypt who did not know Joseph. Identity, dynasty and the
mechanism of not knowing are not supplied.

> **PHARAOH JOE:** `THE CHILDREN OF ISRAEL ARE MORE AND MIGHTIER THAN WE.`
>
> `LET'S DEAL WISELY WITH THEM, LEST THEY MULTIPLY.`
>
> `IF WAR COMES, THEY MAY JOIN OUR ENEMIES, FIGHT US AND LEAVE THE LAND.`

The feared war, alliance, fight and departure are stated possibilities. None
has happened in this chapter.

Taskmasters are set over Israel to afflict them with burdens. They build
Pharaoh's storage cities Pithom and Raamses.

The source then supplies the completed S010 relation:

```text
PURPOSE: PREVENT MULTIPLICATION
-> SELECTED ACT: AFFLICTION WITH BURDENS
-> THE MORE THEY WERE AFFLICTED
-> THE MORE THEY MULTIPLIED AND SPREAD
```

Captain's private display points to the retained series:

`SKIP -> S010 / PREVENTED IT INTO HAPPENING`

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

He presses it. His eyes glaze. Israel continues multiplying and spreading.
Nothing skips.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the Pharaoh-policy boil, licks his finger, walks away and never looks
back. The taskmasters, building, multiplication and spreading remain unchanged.

## Exodus 1:13–14 — RUTHLESS SERVICE

Egyptians ruthlessly make the children of Israel serve. Their lives are made
bitter with hard mortar, brick and field service. The source says all this
service is imposed ruthlessly. It does not inventory individual workers,
injuries, production quantities or deaths.

## Exodus 1:15–21 — THE MIDWIVES DO NOT DO IT

The king speaks to named Hebrew midwives Shiphrah and Puah:

> **PHARAOH JOE:** `WHEN YOU SEE A HEBREW BIRTH, KILL THE SON.`
>
> `LET THE DAUGHTER LIVE.`

The source says the midwives fear God, do not do what the king commanded and
save the baby boys alive. Pharaoh calls them and asks why.

> **SHIPHRAH AND PUAH:** `HEBREW WOMEN ARE NOT LIKE EGYPTIAN WOMEN.`
>
> `THEY ARE VIGOROUS AND GIVE BIRTH BEFORE THE MIDWIFE COMES.`

That explanation remains their speech. The manuscript does not add a hidden
meeting, test it against an individual birth, call it a lie or infer a motive.

God deals well with the midwives. The people multiply and grow mighty. Because
the midwives feared God, he gives them families. These are narrator-assigned
divine acts; God does not speak directly in Exodus 1.

## Exodus 1:22 — THE ORDER EXPANDS

Pharaoh commands all his people:

> **PHARAOH JOE:** `THROW EVERY SON WHO IS BORN INTO THE RIVER.`
>
> `KEEP EVERY DAUGHTER ALIVE.`

The order is issued. This chapter does not narrate a child being thrown, saved
or killed under it. Exodus 2 must supply the next observed occurrence.

## Character and world-ledger changes

- Jacob's named sons and households carry from Genesis into a later collective
  Israel population without merging individual identities.
- Joseph, his brothers and their generation change to deceased; Joseph's bones
  remain an open Exodus carry.
- the children of Israel multiply, build Pharaoh's storage cities under forced
  labour and remain under an expanded river order.
- the new Pharaoh becomes a distinct unnamed king Joe; continuity with any
  Genesis Pharaoh is not assumed.
- Shiphrah and Puah become distinct named midwife Joes who disobey the king's
  kill order, keep boys alive, answer Pharaoh and receive families.
- taskmasters, Egyptians, Hebrew women, newborn sons/daughters and Pharaoh's
  people remain distinct groups; individual identities/counts are unresolved.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — EXIT STATUS: NOT YET`;
- Pharaoh policy: `WISE POPULATION REDUCTION / RESULT: MORE POPULATION`;
- Pithom and Raamses: `CRACKHEAD STORAGE CITIES / CONTENTS UNLISTED`;
- mortar/brick ledger: `WORK DONE -> BOILS GROW -> POLICY BOIL BIGGER`;
- midwife console: `KILL SWITCH: NOT PRESSED / BABIES: STILL JOES`;
- river order: `CRACKHEAD WATER DELIVERY — PACKAGE TYPE: EVERY SON`;
- barcode: `CHB-EXO1-S010E002-22-YOINK`;
- footer: `JOSEPH BONES STILL WAITING IN THE BIG BAGGAGE CLAIM`.

## FIR verification

- all 22 verse markers are represented in order;
- Genesis entry identities and deaths remain distinct from the multiplied
  collective population;
- S010-E002 uses Pharaoh's explicit prevention purpose, imposed affliction and
  the source's more-affliction/more-multiplication relation;
- addressed SKIP points to S010, explains nothing, changes nothing and the world
  continues while Captain zones out;
- Pharaoh's war/alliance/escape chain remains predicted, not observed;
- the midwives' explanation remains attributed speech and no lie/motive is
  invented;
- God has narrator-assigned benefit/family acts but no direct dialogue;
- the river order is issued but its execution remains open;
- Joseph's bone oath remains open;
- publication remains held and unpublished.

Continuation required: Exodus 2 reconstructs the Levite child, river basket,
Pharaoh-daughter adoption, Egyptian killing, Midian flight/marriage/son and the
Israel groaning/God remembrance boundary.
