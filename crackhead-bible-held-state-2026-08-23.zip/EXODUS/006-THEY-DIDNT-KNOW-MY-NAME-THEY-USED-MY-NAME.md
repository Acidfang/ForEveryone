# CRACKHEAD EXODUS 6

## Title page

**BY MY NAME THE LORD I WAS NOT KNOWN TO THEM.**

**ABRAHAM USED THE NAME THE LORD.**

Source parent: Exodus chapter 6, verses 1–30, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 6.

Prepared evidence: `.chapter-work/CHB-EXO-006/job.json` and `source.usfm`.

Parent manuscript: `EXODUS/005-NO-STRAW-SAME-BRICKS.md`.

CrackFlix routing: new `S064 — THEY DIDN'T KNOW MY NAME. THEY USED MY NAME.`,
episode `S064-E001-EXO6 — THE PATRIARCHS USED LORD`.

## Causal foundation

```text
MOSES REPORTS NO RESCUE
-> LORD: STRONG HAND WILL MAKE PHARAOH RELEASE/DRIVE OUT
-> GOD: I AM LORD
-> APPEARED TO ABRAHAM/ISAAC/JACOB AS GOD ALMIGHTY
-> BY NAME LORD NOT KNOWN TO THEM
-> RETAINED PATRIARCH SPEECH/NAMING USES LORD
-> COVENANT / GROANING HEARD / REMEMBERED
-> SEVENFOLD FUTURE BRING-OUT/RID/REDEEM/TAKE/BE/GIVE MESSAGE
-> MOSES SPEAKS TO ISRAEL
-> ISRAEL DOES NOT LISTEN DUE ANGUISH + CRUEL BONDAGE
-> LORD ORDERS PHARAOH RELEASE MESSAGE
-> MOSES OBJECTS: ISRAEL DIDN'T LISTEN / UNCIRCUMCISED LIPS
-> LORD COMMANDS MOSES+AARON
-> REUBEN FAMILY
-> SIMEON FAMILY
-> LEVI->GERSHON/KOHATH/MERARI FAMILY/AGES
-> AMRAM+JOCHEBED -> AARON+MOSES
-> AARON+ELISHEBA -> NADAB/ABIHU/ELEAZAR/ITHAMAR
-> KORAHITE + UZZIEL LINES
-> ELEAZAR+PUTIEL DAUGHTER -> PHINEHAS
-> GENEALOGY RE-IDENTIFIES THIS AARON+MOSES
-> LORD REPEATS PHARAOH SPEECH ORDER
-> MOSES REPEATS UNCIRCUMCISED-LIPS OBJECTION
```

## Exodus 6:1–8 — NAME, COVENANT AND PROMISES

The LORD answers Moses: Pharaoh will release and drive Israel out by a strong
hand. God identifies as the LORD, says he appeared to Abraham, Isaac and Jacob
as God Almighty, but was not known to them by his name the LORD. He cites the
Canaan covenant, Israel groaning and covenant remembrance.

The retained Genesis record contains Abraham directly invoking `the LORD God
Most High` in Genesis 14 and naming `The LORD Will Provide` in Genesis 22. Those
are patriarch speech/naming acts, not later narrator labels.

That completes S064 at the textual boundary:

```text
EXODUS 6: PATRIARCHS NOT KNOWN BY NAME LORD
-> GENESIS: ABRAHAM DIRECTLY USES/ASSIGNS LORD NAME
-> NO NAME-CHANGE OR TRANSLATION BRIDGE IN SELECTED SOURCE STATE
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

Captain pokes the name-tag boil, licks his finger, walks away and never looks
back. God continues speaking.

God orders Moses to tell Israel seven future relations: bring out, rid from
bondage, redeem, take as people, be their God, bring into sworn land, and give
it as heritage. None is prematurely completed here.

## Exodus 6:9–13 — THEY DID NOT LISTEN THIS TIME

Moses delivers the message. Israel does not listen because the source assigns
anguish of spirit and cruel bondage. This does not contradict Exodus 4's prior
belief/hearing: a later message follows Pharaoh's worsened labor policy and the
source supplies a changed condition.

The LORD orders Moses to tell Pharaoh to release Israel. Moses objects that
Israel did not listen and asks how Pharaoh will listen to uncircumcised lips.
The LORD commands Moses and Aaron concerning Israel, Pharaoh and bringing out.

## Exodus 6:14–25 — THE LINEAGE ADDRESS

The genealogy lists, in order:

- Reuben's sons Hanoch, Pallu, Hezron and Carmi;
- Simeon's sons Jemuel, Jamin, Ohad, Jachin, Zohar and Shaul, whose mother is a
  Canaanite woman;
- Levi's sons Gershon, Kohath and Merari; Levi lives 137 years;
- Gershon's sons Libni and Shimei;
- Kohath's sons Amram, Izhar, Hebron and Uzziel; Kohath lives 133 years;
- Merari's sons Mahli and Mushi;
- Amram takes his father's sister Jochebed; she bears Aaron and Moses; Amram
  lives 137 years;
- Izhar's sons Korah, Nepheg and Zichri;
- Uzziel's sons Mishael, Elzaphan and Sithri;
- Aaron takes Elisheba, daughter of Amminadab and sister of Nahshon; she bears
  Nadab, Abihu, Eleazar and Ithamar;
- Korah's sons Assir, Elkanah and Abiasaph;
- Eleazar takes an unnamed daughter of Putiel; she bears Phinehas.

Every named Joe is a distinct identity despite one face. Reused names such as
Hezron remain lineage-addressed rather than automatically merged.

## Exodus 6:26–30 — THESE ARE THAT MOSES AND AARON

The source explicitly reconnects the genealogy to `that Aaron and Moses` who
were commanded to bring Israel out by armies and who spoke to Pharaoh. It then
returns to the LORD's Egypt-day command to tell Pharaoh everything and Moses'
repeated uncircumcised-lips objection.

The repetition remains the same commission/objection chain, not a second
occurrence and not SKIP: it restores the narrative address after genealogy.

## Character and world-ledger changes

- Moses receives renewed promises/command, delivers Israel message, observes
  non-listening and repeats his lips objection.
- Aaron remains commissioned and gains explicit Amram/Jochebed sibling lineage,
  Elisheba marriage and four named sons.
- Jochebed and Amram become the previously unnamed Exodus 2 parents; no sister
  name is supplied here.
- Reuben, Simeon and Levi branches gain exact named family identities/ages.
- Korahite, Uzziel, Aaron-priest and Phinehas lines enter the inventory without
  importing their later acts.

## Bullshit pass

- banner: `CRACKHEAD FAMILY ADDRESS RESOLUTION SERVICE`;
- divine name badge: `NOT KNOWN / PREVIOUSLY USED`;
- promises display: `OUT / RID / REDEEM / TAKE / BE / BRING / GIVE`;
- Israel receiver: `MESSAGE RECEIVED / LISTENING: NO / ANGUISH ATTACHED`;
- lips warning: `CIRCUMCISION STATUS: METAPHORICAL INPUT UNSUPPLIED`;
- genealogy printer: `THESE ARE THAT MOSES AND AARON`;
- barcode: `CHB-EXO6-S064E001-30-YOINK`.

## FIR verification

- all 30 verse markers are represented in order;
- S064 compares direct God speech with retained direct patriarch speech/naming,
  without inventing theology, language history or alternate semantics;
- all seven promise relations remain future;
- Exodus 4 belief and Exodus 6 non-listening remain different Moments with a
  supplied changed condition;
- every genealogy identity/relation/age remains distinct and ordered;
- genealogy re-identification preserves Moses/Aaron continuity;
- direct LORD speech remains God-only;
- Pharaoh release and deliverance remain open;
- publication remains held and unpublished.

Continuation required: Exodus 7 reconstructs Moses/Aaron roles/ages, rod-serpent
contest, magician replication, hardening/non-listening and Nile blood onset.
