# CRACKHEAD EXODUS 31

## Title page

**I CALLED BEZALEL BY NAME.**

**GOD'S FINGER WROTE THE TABLETS.**

Source parent: Exodus chapter 31, verses 1–18, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 31.

Prepared evidence: `.chapter-work/CHB-EXO-031/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/030-MAKE-THE-OIL-DO-NOT-MAKE-ANY-LIKE-IT.md`.

CrackFlix routing: none. No contradiction completes.

## Causal foundation

```text
GOD CALLS BEZALEL BY NAME
-> BEZALEL SON OF URI / GRANDSON OF HUR / JUDAH
-> GOD ATTRIBUTES SPIRIT/WISDOM/UNDERSTANDING/KNOWLEDGE/WORKMANSHIP
-> GOLD/SILVER/BRONZE + STONE SETTING + WOOD CARVING
-> GOD APPOINTS OHOLIAB SON OF AHISAMACH / DAN WITH HIM
-> GOD ATTRIBUTES WISDOM TO ALL WISE-HEARTED MAKERS
-> COMPLETE SANCTUARY/GARMENT/OIL/INCENSE BUILD INVENTORY ASSIGNED
-> ISRAEL MUST KEEP SABBATH AS GENERATIONAL SIGN
-> PROFANE/WORK ON SABBATH -> DEATH + CUT-OFF RULES
-> SIX WORK DAYS / SEVENTH SOLEMN REST
-> PERPETUAL COVENANT / CREATION-REST-REFRESHED SIGN
-> GOD FINISHES SPEAKING ON SINAI
-> GOD GIVES MOSES TWO STONE COVENANT TABLETS
-> TABLETS WRITTEN WITH GOD'S FINGER
```

The craft commission and Sabbath enforcement remain speech. The two stone
tablets, however, are actually given to Moses at the end of the chapter.

## Exodus 31:1–6 — THE WORKERS GET NAMES

God calls Bezalel by name and supplies a lineage:

- Bezalel;
- son of Uri;
- son of Hur;
- tribe of Judah.

God says he filled Bezalel with God's Spirit in wisdom, understanding,
knowledge and all workmanship. The assigned work includes skilled design,
gold, silver, bronze, stone cutting/setting, wood carving and every kind of
workmanship.

Oholiab is appointed with him:

- Oholiab;
- son of Ahisamach;
- tribe of Dan.

God also says he put wisdom into every wise-hearted worker so they may make all
that was commanded. These are direct divine attributions and appointments.
They do not prove a completed object, observed performance, private thought or
worker response.

The Hur in Bezalel's ancestry has the same supplied name as the Hur who helped
Moses and later received dispute responsibility. This chapter does not state
that they are the same Joe. Their identity relation remains unresolved rather
than merged by name alone.

## Exodus 31:7–11 — BUILD EVERYTHING PREVIOUSLY UNBUILT

The named and wise-hearted makers receive the whole retained inventory:

- Tent of Meeting;
- covenant ark and mercy seat;
- all Tent furniture;
- table and vessels;
- pure lampstand and vessels;
- incense altar;
- burnt-offering altar and vessels;
- basin and base;
- Aaron's and sons' finely worked holy garments;
- anointing oil;
- sweet-spice incense.

They must do according to all God commanded Moses. This assigns execution
without stating who makes each component, whether Bezalel personally performs
every craft, how the group is organized, or that materials have been received.
Every listed object and formula remains unmade at this Moment.

## Exodus 31:12–17 — THE SIGN WITH A DEATH PENALTY

Israel must certainly keep God's Sabbaths as a sign between God and Israel
through generations so they may know that the LORD sanctifies them. Sabbath is
holy. The enforcement language states:

- everyone who profanes it shall surely be put to death;
- whoever does any work in it shall be cut off from the people;
- six days work shall be done;
- the seventh is solemn Sabbath rest, holy to the LORD;
- whoever works on the Sabbath shall surely be put to death.

Death and cut-off are both supplied consequences. The source does not say they
are different sentences, define profaning beyond the work case, nominate an
executor, or narrate an offender. They do not disagree cleanly enough to create
separate crack: verse 15 directly repeats death for the work condition.

Israel must observe Sabbath through generations as a perpetual covenant and a
sign forever. The stated creation relation is:

> **IN SIX DAYS THE LORD MADE HEAVEN AND EARTH.**

> **ON THE SEVENTH DAY HE RESTED, AND WAS REFRESHED.**

“Was refreshed” is a source-attributed divine State change. It does not state
that God was tired, depleted, forced to stop or unable to continue. Earlier
Almighty naming does not itself make refreshing impossible, so no contradiction
is manufactured from an unstated incapacity claim.

## Exodus 31:18 — SPEECH FINISHED, TABLETS DELIVERED

When God finishes speaking with Moses on Sinai, God gives him:

- two tablets;
- tablets of the covenant;
- stone tablets;
- written with God's finger.

This closes the open tablet-delivery boundary from Exodus 24. The text does not
repeat the inscription, describe tablet dimensions/weight, show the writing
act, define divine anatomy, identify which hand/finger, or say Moses has left
the mountain.

The delivery is performed:

```text
EXODUS 24 -> TABLETS PROMISED
-> EXODUS 25-31 -> MOUNTAIN SPEECH CONTINUES
-> SPEECH FINISHES
-> TWO GOD-WRITTEN STONE TABLETS GIVEN TO MOSES
-> MOSES STILL ON SINAI AT DELIVERY
```

No crack completes. Captain does not appear.

## Character and world-ledger changes

- Bezalel enters as a named Judah craft Joe with explicit father/grandfather
  lineage and divine skill attribution;
- Oholiab enters as a named Dan craft Joe with explicit father lineage and
  appointment beside Bezalel;
- the unnamed wise-hearted worker group retains divine wisdom attribution and
  receives the complete object/formula commission;
- same-name Hur identity remains unresolved;
- Israel receives generational Sabbath sign/covenant, work, death and cut-off
  rule State;
- creation history gains direct seventh-day rested/refreshed wording;
- God finishes the retained Sinai instruction speech;
- Moses actually receives two God-written stone covenant tablets;
- no sanctuary craft act, Sabbath offence, death or exclusion occurs;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — AUTHORIZED CONTRACTORS + WEEKEND POLICY`;
- Bezalel badge: `CALLED BY NAME / JUDAH / ALL WORKMANSHIP ENABLED`;
- Oholiab badge: `APPOINTED WITH HIM / DAN / JOB DESCRIPTION ATTACHED TO HIM`;
- team setting: `WISE HEARTS PRELOADED BY ADMIN`;
- build queue: `TENT + ARK + FURNITURE + TWO ALTARS + BASIN + CLOTHES + OIL + SMELL`;
- Sabbath dashboard: `6 RUN / 1 STOP / PERPETUAL`;
- warning: `WORK DETECTED -> DEATH/CUT-OFF OUTPUT`; 
- creation status: `RESTED / REFRESHED / NO BATTERY LEVEL PROVIDED`;
- tablet pack: `2 x STONE / GOD-FINGER HANDWRITING / DIMENSIONS NULL`;
- barcode: `CHB-EXO31-NO-CRACK-18-TABLETS-DELIVERED`.

## FIR verification

- all 18 verse markers are represented in order;
- Bezalel, Uri, Hur, Oholiab and Ahisamach remain distinct named Joes;
- same-name Hur occurrences are not merged without identity evidence;
- God-attributed wisdom/Spirit/knowledge remains attribution, not mind-reading;
- commission does not become completed craftsmanship;
- all listed sanctuary objects preserve their earlier distinct lineages;
- Sabbath sign, holiness, work, death, cut-off and perpetual-covenant wording is
  retained without an invented case or enforcement process;
- divine rested/refreshed wording is retained without inventing fatigue;
- tablet promise advances to actual delivery, while tablet contents and Moses'
  descent remain open;
- no CrackFlix series, SKIP, Captain or crack is manufactured;
- all living humans use Joe face if shown;
- publication remains held and unpublished.

Continuation required: Exodus 32 reconstructs the delayed Moses request,
golden calf manufacture/worship, competing origin claims, intercession,
tablet destruction, calf processing/drinking, Levite killing and plague.
