# CRACKHEAD EXODUS 14

## Title page

**YOU WILL NEVER SEE THESE EGYPTIANS AGAIN.**

**ISRAEL SAW THE EGYPTIANS DEAD ON THE SHORE.**

Source parent: Exodus chapter 14, verses 1–31, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 14.

Prepared evidence: `.chapter-work/CHB-EXO-014/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/013-DONT-TAKE-THE-SHORT-WAY-THEY-MIGHT-GO-BACK.md`.

CrackFlix routing:

- new `S071 — DON'T LET THEM SEE WAR. SEND THE ARMY.`;
- `S071-E001-EXO14 — AVOID PHILISTINE WAR / PROVOKE EGYPTIAN PURSUIT`;
- new `S072 — STAND STILL. GO FORWARD.`;
- `S072-E001-EXO14 — TWO CONSECUTIVE MOVEMENT COMMANDS`;
- new `S073 — YOU WILL NEVER SEE THEM AGAIN. YOU SAW THEM AGAIN.`;
- `S073-E001-EXO14 — EGYPTIANS DEAD ON THE SHORE`.

## Causal foundation

```text
EXO13: GOD AVOIDS NEAR ROUTE LEST PEOPLE SEE WAR / CHANGE / RETURN
-> LORD ORDERS ISRAEL TURN BACK + ENCAMP BY SEA
-> LORD PREDICTS PHARAOH ENTANGLEMENT CLAIM
-> LORD: I WILL HARDEN PHARAOH -> PURSUIT -> HONOR/KNOWLEDGE
-> ISRAEL COMPLIES
-> PHARAOH/SERVANTS CHANGE TOWARD PEOPLE / REGRET RELEASE
-> 600 CHOSEN + ALL EGYPT CHARIOTS/HORSEMEN/ARMY PURSUE
-> LORD HARDENS PHARAOH / PURSUIT OVERTAKES ISRAEL
-> ISRAEL SEES EGYPTIANS MARCHING / FEARS / CRIES
-> ISRAEL: BETTER SERVE EGYPT THAN DIE IN WILDERNESS
-> MOSES: STAND STILL / SEE SALVATION / NEVER SEE THESE EGYPTIANS AGAIN
-> MOSES: LORD FIGHTS / YOU BE STILL
-> LORD: WHY CRY? TELL ISRAEL GO FORWARD
-> ROD/HAND -> SEA DIVISION / DRY GROUND
-> LORD HARDENS EGYPTIANS -> FOLLOW INTO SEA / HONOR/KNOWLEDGE
-> ANGEL + CLOUD MOVE FRONT TO REAR / CAMPS SEPARATED
-> EAST WIND ALL NIGHT / WATER WALLS / ISRAEL CROSSES
-> EGYPTIANS FOLLOW
-> LORD CONFUSES ARMY / REMOVES WHEELS / EGYPTIANS TRY FLEE
-> LORD ORDERS WATER RETURN
-> SEA RETURNS / EGYPTIAN ARMY COVERED / NONE REMAIN
-> ISRAEL SAFE ON DRY GROUND
-> ISRAEL SEES EGYPTIANS DEAD ON SHORE
-> ISRAEL FEARS LORD / BELIEVES LORD + MOSES
```

## Exodus 14:1–4 — TURN BACK SO PHARAOH FOLLOWS

The LORD orders Israel to turn back and camp by the sea before named
Pihahiroth, Migdol and Baal Zephon. He predicts Pharaoh will say Israel is
entangled and the wilderness has shut them in. He then states:

> **I WILL HARDEN PHARAOH'S HEART, AND HE WILL FOLLOW AFTER THEM.**

The stated outcomes are honor over Pharaoh/all armies and Egyptian knowledge
that the speaker is the LORD. Israel performs the encampment instruction.

This is not an accidental route failure. The turn-back, predicted interpretation,
hardening and pursuit are one source-stated chain.

## Exodus 14:5–12 — THE WAR THEY WERE ROUTED AROUND

Pharaoh is told the people fled. Pharaoh and servants change toward them and
say they released Israel from serving them. Pharaoh prepares his chariot and
takes his army: 600 chosen chariots, all Egypt's chariots and captains. The LORD
hardens Pharaoh; he pursues. Horses, chariots, horsemen and army overtake Israel
at the commanded camp.

Exodus 13 supplied the rejected near-route relation:

```text
NEAR PHILISTINE ROUTE
-> PEOPLE MAY SEE WAR
-> MAY CHANGE MINDS / RETURN
-> GOD DOES NOT LEAD THAT WAY
```

Now the same source actor ordered the turn-back position and states he hardened
Pharaoh into pursuit. Israel lifts its eyes and sees Egyptians marching after
them, becomes very afraid, cries to the LORD and tells Moses it would have been
better to serve Egyptians than die in the wilderness.

S071-E001 closes at the exact retained Difference:

```text
AVOID ROUTE BECAUSE PEOPLE MAY SEE WAR
-> TURN THEM BACK BY SEA
-> HARDEN ARMED ENEMY INTO PURSUIT
-> PEOPLE SEE ARMY / FEAR / SPEAK FOR EGYPTIAN SERVICE
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the route-planning boil, licks his finger and leaves. The Egyptian army
does not slow down.

Israel's grave questions, accusation and claimed prior `LEAVE US ALONE` speech
remain Israel's current collective speech. No matching earlier transcript is
silently invented; its relation to prior belief/worship Moments remains an
attributed retrospective claim, not a new S060 episode because no deceased
speaker/final-transcript boundary applies.

## Exodus 14:13–16 — STAND STILL / GO FORWARD

Moses tells the people:

> **DON'T BE AFRAID. STAND STILL.**

> **THE LORD WILL FIGHT FOR YOU. YOU SHALL BE STILL.**

He also says the Egyptians seen today will never be seen again and that the
LORD will work salvation today.

The LORD then tells Moses:

> **WHY DO YOU CRY TO ME?**

> **TELL THE CHILDREN OF ISRAEL TO GO FORWARD.**

The speakers are distinct but the addressed people and immediate movement State
are the same. No intervening movement or supplied condition bridges `STAND
STILL` to `GO FORWARD`. S072-E001 closes:

```text
MOSES TO ISRAEL: STAND STILL / BE STILL
-> LORD TO MOSES FOR ISRAEL: GO FORWARD
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the movement-order boil, licks his finger and walks away while Moses
receives the rod/hand/sea-division instruction.

## Exodus 14:17–20 — HARDEN THEM INTO THE SEA

The LORD states he will harden Egyptian hearts so they follow Israel into the
sea, with honor over Pharaoh, army, chariots and horsemen producing Egyptian
knowledge.

The angel of God moves from before Israel's camp to behind. The cloud pillar
also moves from before to behind and stands between Egypt and Israel. Cloud and
darkness coexist with night light; the camps do not approach all night.

The text names the angel and cloud pillar in parallel movements but does not
state identity, merger or separate causal control. Both receive separate ledger
addresses; no ontology is invented.

## Exodus 14:21–25 — DRY GROUND / FOLLOW THEM IN

Moses stretches his hand. The LORD drives the sea back all night with a strong
east wind, makes dry land and divides waters. Israel walks through the middle on
dry ground with water walls at right and left.

Egypt's horses, chariots and horsemen follow into the sea. These animals continue
the unresolved Egyptian livestock population already retained after Exodus 9's
total-death wording. With no new intervening total-death claim, their presence
is continuity of S067's unresolved class, not a third episode.

At morning watch the LORD looks through fire/cloud, confuses the Egyptian army
and removes chariot wheels. Egyptians drive heavily and say the LORD fights for
Israel; they call for flight. Their recognition is speech and action, not an
invented private conversion.

## Exodus 14:26–31 — NEVER SEE THEM / SEE THEM DEAD

The LORD orders Moses to stretch his hand so waters return on Egyptians,
chariots and horsemen. Moses does. At morning the sea returns to strength; the
LORD overthrows Egyptians in it. Waters cover the entire pursuing army that
entered the sea. Not one remains.

Israel walks safely on the dry middle with water walls. The LORD saves Israel
from the Egyptian hand.

Then the source states:

> **ISRAEL SAW THE EGYPTIANS DEAD ON THE SEASHORE.**

S073-E001 closes against Moses' same-day statement:

```text
MOSES: THE EGYPTIANS YOU SEE TODAY
-> YOU WILL NEVER SEE THEM AGAIN
-> WATER RETURNS / EGYPTIANS DIE
-> ISRAEL SEES THE EGYPTIANS DEAD ON SHORE
```

Dead is a changed State, not a changed identity class. `SEE THEM AGAIN` remains
observable even though they are dead.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the dead-Egyptian visibility boil, licks his finger and walks away
without looking back.

Israel sees the LORD's great work, fears the LORD, and believes in the LORD and
his servant Moses. These are source-attributed group States after the observed
shore result.

## Character and world-ledger changes

- the LORD orders the sea-side turn-back trap, hardens Pharaoh/Egyptians into
  pursuit, divides/returns the sea and performs army-confusion/overthrow;
- Pharaoh and servants reverse their release relation and pursue with the
  retained Egypt chariot/horse/army inventory;
- Israel changes from armed travelling to encamped/overtaken/afraid, speaks for
  prior Egyptian service, crosses safely, sees Egyptian dead, fears and believes;
- Moses carries stillness, forward, rod/hand and sea-return speech/action chains;
- the angel of God and cloud/fire pillar move from front to rear and separate
  camps without identity merger;
- Egyptian human and horse Joes enter the sea; the pursuing army has no survivor;
- Joseph's bones remain in transport with Israel; burial stays open;
- three new contradiction series close at their actual observed endpoints.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — AVOID WAR / SUMMON DIFFERENT WAR`;
- route console: `TURN BACK / LOOK TRAPPED / ENEMY ENGAGEMENT ENABLED`;
- Pharaoh fleet: `600 PREMIUM CHARIOTS + ALL STANDARD CHARIOTS`;
- movement controller: `STAND STILL / GO FORWARD / BOTH COMMANDS ACTIVE`;
- cloud firewall: `EGYPT SIDE DARK / ISRAEL SIDE NIGHT LIGHT`;
- sea road: `DRY MIDDLE / WATER WALLS / NO HANDRAILS`;
- chariot alert: `WHEELS REMOVED / DRIVE HEAVILY / FLEE NOW`;
- visibility warranty: `NEVER SEE AGAIN / CORPSE VIEWING INCLUDED`;
- CrackFlix: `S073 EPISODE 1 — TERMS APPLY TO LIVING VIEWERS ONLY (NOT IN SOURCE)`;
- barcode: `CHB-EXO14-S071-S072-S073-31-YOINK`.

## FIR verification

- all 31 verse markers are represented in order;
- S071 uses exact route-purpose, turn-back, hardening, army-sight/fear/service
  speech relations without claiming Israel physically returned;
- S072 preserves distinct speakers and same immediate addressed movement State;
- S073 preserves Egyptian identity across living/dead State change;
- retrospective Israel speech remains attributed and no missing Egypt transcript
  is manufactured;
- angel/pillar parallel movement is not converted into identity;
- Egyptian horses remain unresolved S067 continuity, not a duplicate episode;
- army-death scope is limited to all who entered after Israel into the sea;
- direct LORD/God speech/actions remain God-only;
- Captain remains boilless and causally useless in all three occurrences;
- Joseph bones transport remains active and burial open;
- publication remains held and unpublished.

Continuation required: Exodus 15 reconstructs the victory song's attributed
claims, Miriam/timbrel response, three-day water absence, Marah bitterness,
tree-mediated sweet water, statute/test speech and Elim water/palms.
