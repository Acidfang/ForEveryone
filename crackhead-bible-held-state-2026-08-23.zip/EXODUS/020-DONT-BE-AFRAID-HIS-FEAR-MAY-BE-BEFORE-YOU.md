# CRACKHEAD EXODUS 20

## Title page

**DON'T BE AFRAID.**

**GOD CAME SO HIS FEAR MAY BE BEFORE YOU.**

Source parent: Exodus chapter 20, verses 1–26, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 20.

Prepared evidence: `.chapter-work/CHB-EXO-020/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/019-WHEN-THE-TRUMPET-SOUNDS-COME-UP-DONT-COME-UP.md`.

CrackFlix routing:

- new `S079-E001-EXO20 — DON'T BE AFRAID / HIS FEAR MAY BE BEFORE YOU`;
- new `S080-E001-EXO20 — DESCENDED ON SINAI / TALKED FROM HEAVEN`.

## Causal foundation

```text
GOD SPEAKS ALL WORDS
-> IDENTIFIES LORD/GOD + EGYPT/BONDAGE EXIT ACTOR
-> NO OTHER GODS
-> NO IDOL/IMAGE OF HEAVEN/EARTH/WATER THINGS
-> NO BOW/SERVICE / JEALOUS + GENERATIONAL INIQUITY/KINDNESS RELATIONS
-> NO NAME MISUSE
-> REMEMBER SABBATH / SIX-DAY LABOR + SEVENTH-DAY NO-WORK HOUSEHOLD SCOPE
-> CREATION/REST/BLESS/HOLY REASON
-> HONOR FATHER/MOTHER + LONG-LAND-DAYS CONDITION
-> NO MURDER / ADULTERY / STEAL / FALSE TESTIMONY / COVETING INVENTORY
-> PEOPLE PERCEIVE THUNDER/LIGHTNING/TRUMPET/SMOKE
-> PEOPLE TREMBLE + STAY DISTANT
-> PEOPLE: MOSES SPEAK / WE LISTEN / GOD DON'T SPEAK LEST WE DIE
-> MOSES: DON'T BE AFRAID
-> MOSES: GOD CAME TO TEST + HIS FEAR BEFORE YOU + NO SIN PURPOSE
-> PEOPLE REMAIN DISTANT / MOSES APPROACHES THICK DARKNESS WHERE GOD WAS
-> LORD: YOU SAW I TALKED WITH YOU FROM HEAVEN
-> NO SILVER/GOLD GODS ALONGSIDE LORD
-> EARTH ALTAR + OFFERINGS/SHEEP/CATTLE + NAME/COME/BLESS RELATION
-> OPTIONAL STONE ALTAR: UNCUT / TOOL POLLUTES
-> NO ALTAR STEPS / NAKEDNESS NOT EXPOSED
```

## Exodus 20:1–2 — THE SPEAKER AND THE EXIT

God speaks all these words. The source directly identifies the speaker as the
LORD their God who brought them out of Egypt and the house of bondage.

The Aleph-Tav translation footnote is retained as a source note. It does not
create a character, spoken word, secret code or new divine name in the
narrative.

## Exodus 20:3–6 — GODS, IMAGES AND GENERATIONS

The direct commands establish:

- no other gods before the LORD;
- no self-made idol or image of anything in heaven above, earth beneath or
  water under earth;
- no bowing to or serving those objects.

The LORD calls himself jealous and states two generational relations:

- fathers' iniquity visited on children to third/fourth generation of those who
  hate him;
- loving kindness shown to thousands of those who love him and keep commands.

These are direct rule/sanction statements. No child offence, actual third- or
fourth-generation visit, idol construction, hatred, love or kindness event is
performed inside this chapter.

The universal living-thing Joe face is a production identity, not an idol made
by the source actors. A later Joe who manufactures or serves an image must be
tested at that actual occurrence; this command alone does not pre-create the
violation.

## Exodus 20:7 — NAME USE

The LORD prohibits misuse of his name and says the misuser will not be held
guiltless. The translation's alternate `take the name in vain` note remains a
note, not a second command or performed misuse.

## Exodus 20:8–11 — SIX ON / ONE OFF

The people are to remember and keep Sabbath holy. Six days are for labor and
all work; the seventh is Sabbath with no work by:

- the addressed person;
- son or daughter;
- male or female servant;
- livestock;
- stranger within the gates.

The reason given is that the LORD made heaven, earth, sea and all in them in six
days, rested the seventh, blessed Sabbath and made it holy.

This six-plus-one schedule agrees with the completed manna schedule in Exodus
16. It does not say work occurs `every day`, so S074 does not repeat here.

Every living livestock Joe remains separately addressable. The source does not
enumerate which animals, work types, gates or enforcement acts occur.

## Exodus 20:12–17 — HOUSEHOLD AND NEIGHBOR RULES

The direct commands continue:

- honor father and mother, with long days in the LORD-given land as the stated
  outcome relation;
- do not murder;
- do not commit adultery;
- do not steal;
- do not give false testimony against a neighbor;
- do not covet the neighbor's house, wife, male/female servant, ox, donkey or
  anything belonging to the neighbor.

The long-day/land result remains conditional and future. No offender, victim,
trial, property transfer, desire State or sanction is narrated here. Existing
earlier acts are not retroactively reclassified by silently transporting this
newly spoken rule backward in time.

Wife, servants, ox and donkey are listed within a neighbor-property boundary in
the command. The ledger preserves that wording without deciding modern legal,
moral or personhood categories for the source.

## Exodus 20:18–21 — DON'T FEAR / KEEP THE FEAR

All the people perceive thunder, lightning, trumpet sound and smoking mountain.
They tremble and remain at a distance. They tell Moses:

> **SPEAK WITH US YOURSELF, AND WE WILL LISTEN.**

> **DON'T LET GOD SPEAK WITH US, LEST WE DIE.**

That request changes the preferred communication carrier from direct God speech
to Moses. It does not deny that God already spoke verses 1–17.

Moses answers:

> **DON'T BE AFRAID.**

Then, in the same statement:

> **GOD HAS COME TO TEST YOU, SO HIS FEAR MAY BE BEFORE YOU, THAT YOU WON'T SIN.**

S079-E001 closes:

```text
PEOPLE TREMBLE + DISTANCE THEMSELVES
-> MOSES: DON'T BE AFRAID
-> MOSES: EVENT PURPOSE INCLUDES GOD'S FEAR REMAINING BEFORE THEM
```

The translation uses the same observable fear-word relation while the first
imperative removes fear and the stated mechanism retains it.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the fear-control boil, licks his finger and walks away without looking
back. The people remain at a distance. Moses approaches the thick darkness
where God was.

`TEST`, `FEAR` and `WON'T SIN` are Moses' supplied explanation. The chapter does
not narrate a completed test result or future sinlessness.

## Exodus 20:22–23 — MOUNTAIN GOD / HEAVEN VOICE

The retained immediate physical State is:

```text
EXODUS 19: LORD DESCENDS ON SINAI TO MOUNTAINTOP
-> EXODUS 20: MOSES APPROACHES THICK DARKNESS WHERE GOD WAS
```

The LORD then tells Moses to relay:

> **YOU YOURSELVES HAVE SEEN THAT I HAVE TALKED WITH YOU FROM HEAVEN.**

S080-E001 closes the unbridged speech-location change:

```text
LORD DESCENDED TO / WAS AT MOUNTAIN DARKNESS
-> SAME AUDIENCE RECEIVES GOD SPEECH
-> LORD LOCATES THAT TALKING FROM HEAVEN
```

The source provides no voice-routing mechanism, simultaneous-location rule or
statement equating mountain darkness with heaven.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the location boil, licks his finger and walks away without looking
back. Moses remains near the darkness and the message continues.

The LORD specifically prohibits making silver or gold gods alongside him. This
narrows material examples without cancelling the broader image command.

## Exodus 20:24–26 — BUILD THIS, BUT DON'T IMPROVE IT

The LORD commands an earth altar for burnt and peace offerings involving sheep
and cattle. Wherever the LORD records his name, he states he will come and
bless.

If a stone altar is made:

- it must not use cut stones;
- lifting a tool on it pollutes it.

The altar must not be approached by steps, so nakedness is not exposed to it.

An earth or uncut-stone altar is not called an image or god. Construction and
image-making are not equivalent by default, so no contradiction is invented
between verses 4 and 24–25. `Tool pollutes` is the stated material rule; no
metallurgy, ritual chemistry or quality theory is inserted.

Sheep and cattle are living Joe-faced sacrifice subjects. The commands do not
narrate a specific altar being built or any animal being sacrificed in this
chapter. The altar is nonliving but may receive a Joe face if the generated
image interprets part of it as a face.

Joseph's bones remain in transport and are neither mentioned nor buried.

## Character and world-ledger changes

- Israel receives the direct command collection as a current rule State;
- household members, servants, strangers, livestock and neighbor-property
  relations gain explicit Sabbath/civil behavior boundaries;
- the people perceive Sinai effects, tremble, remain distant and request Moses
  mediation;
- Moses gains fear/test/no-sin explanatory speech and approaches God's darkness;
- S079 records fear removal against fear-retention mechanism;
- S080 records mountain-presence against from-heaven speech location;
- earth/uncut-stone altar, offerings and no-step exposure rules enter future
  construction State;
- no command violation, altar construction, offering or sanction is performed;
- Joseph bones remain moving; burial open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — TERMS OF SERVICE SPOKEN ALOUD`;
- gods menu: `OTHER: NO / SILVER: NO / GOLD: ALSO NO`;
- image warning: `DO NOT MANUFACTURE HEAVEN/EARTH/WATER MERCH`;
- Sabbath roster: `YOU + KIDS + STAFF + LIVESTOCK + VISITOR: OFFLINE`;
- neighbor cart: `HOUSE/WIFE/SERVANTS/OX/DONKEY/ANYTHING — NOT YOUR CART`;
- mediation switch: `DIRECT GOD AUDIO: USER REQUESTED OFF`;
- CrackFlix: `S079 E001 — FEAR REMOVAL RETENTION SYSTEM`;
- location display: `GOD: MOUNTAIN DARKNESS / VOICE ORIGIN: HEAVEN`;
- CrackFlix: `S080 E001 — CLOUD VOICE ROUTER NOT INCLUDED`;
- altar kit: `EARTH DEFAULT / STONE OPTIONAL / TOOLS VOID WARRANTY`;
- step warning: `NO STAIRS / ALTAR DOESN'T NEED TO SEE THAT`;
- barcode: `CHB-EXO20-S079-S080-26-YOINK-YOINK`.

## FIR verification

- all 26 verse markers are represented in order;
- each command and its stated condition/sanction remains distinct;
- no later offence is projected backward into this rule-establishment Moment;
- Sabbath schedule does not falsely repeat S074;
- direct God words, people mediation request and Moses explanation remain
  separately attributed;
- S079 closes only from no-fear and fear-before-you relations in the same speech;
- test/no-sin outcome remains open;
- S080 retains immediate Exodus 19 mountain descent and Exodus 20 darkness State
  before the from-heaven speech claim;
- altar construction is not silently classified as image-making;
- no altar, offering, offender or sanction is invented as performed;
- living household, livestock, ox, donkey, sheep and cattle identities use Joe
  face whenever shown;
- Captain remains boilless and causally useless;
- Joseph bones transport remains active and burial open;
- publication remains held and unpublished.

Continuation required: Exodus 21 reconstructs servant release rules, bodily
injury/death liabilities, parental/abduction offences, retaliation schedule,
animal injury, pit liability and dangerous-ox responsibility.
