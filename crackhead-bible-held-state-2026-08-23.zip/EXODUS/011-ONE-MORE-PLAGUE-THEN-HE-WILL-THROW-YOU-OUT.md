# CRACKHEAD EXODUS 11

## Title page

**ONE MORE PLAGUE.**

**THEN HE WILL THROW YOU OUT.**

Source parent: Exodus chapter 11, verses 1–10, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 11.

Prepared evidence: `.chapter-work/CHB-EXO-011/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/010-LET-THEM-GO-I-HARDENED-HIM-HE-DIDNT.md`.

CrackFlix routing: no new series or episode. Exodus 11:10 restates the retained
S069 hardening/non-release aggregate and does not establish another occurrence.

## Causal foundation

```text
LORD ANNOUNCES ONE MORE PLAGUE
-> FUTURE: PHARAOH RELEASES / THRUSTS ALL OUT
-> PEOPLE INSTRUCTED TO ASK NEIGHBORS FOR SILVER/GOLD
-> LORD GIVES PEOPLE FAVOR / MOSES GREAT IN EGYPTIAN SIGHT
-> MOSES CONTINUES PHARAOH AUDIENCE
-> RELAYS MIDNIGHT LORD ENTRY
-> FUTURE: ALL EGYPT FIRSTBORN DIE / GREAT CRY
-> FUTURE: NO DOG MOVES TONGUE AGAINST ISRAEL HUMAN/ANIMAL
-> STATED PURPOSE: EGYPT/ISRAEL DISTINCTION KNOWN
-> FUTURE: PHARAOH SERVANTS BOW / ORDER DEPARTURE
-> MOSES SAYS HE WILL THEN GO
-> MOSES LEAVES PHARAOH IN HOT ANGER
-> LORD RESTATES PHARAOH NON-LISTENING / MULTIPLIED WONDERS
-> SOURCE SUMMARIZES WONDERS + LORD HARDENING + NON-RELEASE
```

## Exodus 11:1–3 — ASK THE NEIGHBORS

The LORD tells Moses one more plague will come on Pharaoh and Egypt. Afterwards
Pharaoh will release Israel and, when he does, will thrust them out altogether.
This is a future statement. The release and expulsion have not happened.

The people are instructed to ask male and female neighbors for silver and gold
jewels. The LORD gives the people favor in Egyptian sight. Moses is described as
very great in Egypt in the sight of Pharaoh's servants and the people.

Favor and greatness are source-attributed visible/social States. The source
does not report anyone's private admiration, agreement or motive. The jewelry
request is instructed here; transfer remains unresolved until observed later.

## Exodus 11:4–8 — THE SAME AUDIENCE CONTINUES

Moses says, `THIS IS WHAT THE LORD SAYS`, and relays that around midnight the
LORD will go into Egypt. This speech continues the Pharaoh audience from Exodus
10. Moses has not yet gone out. Therefore his prior `I WILL SEE YOUR FACE AGAIN
NO MORE` does not conflict with words spoken during the same meeting.

The announced scope is all firstborn in Egypt, from Pharaoh's throne line to the
female servant behind the mill, plus all firstborn livestock. A great Egypt-wide
cry is announced, unmatched before or after.

Against Israel, Moses says a dog will not bark or move its tongue against human
or animal Joes. The stated purpose is knowledge that the LORD distinguishes
Egyptians and Israel. Every dog, firstborn person and livestock organism has Joe
face while remaining a distinct identity.

Moses says Pharaoh's servants will come down, bow, order him and all followers
out, and that he will then depart. These acts remain future speech. The chapter
does not depict servant arrival, bowing, firstborn death, dog silence or Israel
departure.

Moses then goes out from Pharaoh in hot anger. This closes the current audience
without creating a new face encounter.

## Exodus 11:9–10 — THE SUMMARY IS NOT ANOTHER EPISODE

The LORD says Pharaoh will not listen so the LORD's wonders may be multiplied in
Egypt. The chapter concludes that Moses and Aaron did all these wonders before
Pharaoh, the LORD hardened Pharaoh's heart, and Pharaoh did not release Israel.

That final clause summarizes the retained wonder/hardening/non-release chain.
No newly performed wonder, renewed negotiation, new relief, changed audience or
new refusal is inserted between verses 9 and 10. Under DEDUP it remains attached
to S069's existing episodes rather than becoming `S069-E003`.

Captain Crackhead does not appear. A summary is not fresh crack, and announced
future acts cannot feed him before they occur.

## Character and world-ledger changes

- the LORD announces one final plague, future full expulsion, jewelry requests,
  midnight entry, firstborn death and Israel distinction;
- Israel men and women receive an instruction to ask corresponding neighbors
  for silver/gold, while actual requests/transfers remain open;
- source narration records LORD-given favor and Moses' greatness in Egyptian,
  servant and people sight without inventing private mental content;
- Moses completes the same Pharaoh audience opened in Exodus 10, relays the
  midnight announcement and exits in hot anger;
- Pharaoh's servants receive a future bow/departure role only;
- firstborn Joes across throne, servant and livestock positions remain living
  at chapter close because their deaths are still announced;
- Joe-faced dogs receive an announced non-bark/non-tongue-movement State, not a
  completed act;
- S069 remains unchanged: verse 10 is aggregate retention, not occurrence.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — FINAL PLAGUE PATCH NOTES (ANNOUNCED ONLY)`;
- exit forecast: `RELEASE MODE -> THROW EVERYONE OUT MODE`;
- neighbor form: `ASK NICELY / SILVER / GOLD / TRANSFER PENDING`;
- Moses status badge: `VERY GREAT IN THEIR SIGHT / NO INTERNAL TELEMETRY`;
- midnight schedule: `CRACKHEAD FIRSTBORN MAINTENANCE WINDOW`;
- dog console: `BARK 0 / TONGUE MOVEMENT 0 / EXECUTION PENDING`;
- face continuity warning: `SAME MEETING / STILL TALKING / LEAVE AT VERSE 8`;
- DEDUP card: `S069 SUMMARY / DO NOT BILL AS NEW EPISODE`;
- barcode: `CHB-EXO11-10-ANNOUNCED-NOT-DID-NO-YOINK`.

## FIR verification

- all 10 verse markers are represented in order;
- every future statement remains future at chapter close;
- the jewelry request instruction is not converted into observed transfer;
- favor/greatness retain narrator attribution without invented interiority;
- Exodus 10:29 and Exodus 11:4–8 remain one continuous audience, so no
  false face contradiction is created;
- firstborn, cry, dog silence, servant bowing and expulsion remain announced;
- verse 10 is deduplicated against S069 rather than treated as a new episode;
- no Captain appears because no fresh contradiction completes;
- direct LORD speech/actions remain God-only and Moses' relayed announcement is
  clearly attributed;
- Israel release and Joseph bone transport remain open;
- publication remains held and unpublished.

Continuation required: Exodus 12 reconstructs Passover instructions and acts,
midnight firstborn deaths, Pharaoh's night summons, Egyptian property transfer,
departure, mixed multitude, unleavened food, 430-year timing and Joseph bone
transport still remaining open.
