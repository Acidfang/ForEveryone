# CRACKHEAD EXODUS 26

## Title page

**MAKE THE TABERNACLE WITH TEN CHERUB CURTAINS.**

`CRACKFLIX: SKIP -> S086-E001 — AUTHORIZED FORBIDDEN IMAGE PACKAGE`

Source parent: Exodus chapter 26, verses 1–37, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 26.

Prepared evidence: `.chapter-work/CHB-EXO-026/job.json` and `source.usfm`.

Parent manuscript: `EXODUS/025-DONT-MAKE-AN-IMAGE-MAKE-TWO-CHERUBIM.md`.

CrackFlix routing:

- repeat `S086-E002-EXO26 — NO HEAVENLY IMAGES / CHERUB CURTAINS AND VEIL`;
- `SKIP` points to `S086-E001-EXO25`; it omits the already-retained
  explanation, causes nothing and does not remove this occurrence.

## Causal foundation

```text
TEN COLORED FINE-LINEN CURTAINS WITH SKILL-WORK CHERUBIM
-> EACH 28 x 4 CUBITS / TWO FIVE-CURTAIN GROUPS
-> 50 BLUE LOOPS EACH EDGE + 50 GOLD CLASPS -> ONE TABERNACLE UNIT
-> ELEVEN GOAT-HAIR CURTAINS, EACH 30 x 4
-> FIVE + SIX GROUPS / SIXTH DOUBLED AT FRONT
-> 50 LOOPS EACH EDGE + 50 BRONZE CLASPS -> ONE TENT UNIT
-> HALF-CURTAIN BACK OVERHANG + ONE-CUBIT SIDE OVERHANGS
-> RED RAM-SKIN COVER + SEA-COW-HIDE TOP COVER
-> UPRIGHT ACACIA BOARDS, EACH 10 x 1.5, TWO TENONS
-> SOUTH 20 BOARDS/40 SILVER SOCKETS
-> NORTH 20 BOARDS/40 SILVER SOCKETS
-> WEST 6 BOARDS + 2 CORNER BOARDS/16 SILVER SOCKETS
-> FIVE BARS PER SIDE / MIDDLE BAR END-TO-END
-> GOLD OVERLAY + GOLD RINGS/BARS
-> SET UP TO MOUNTAIN-SHOWN PLAN
-> COLORED FINE-LINEN CHERUB VEIL ON 4 GOLD-OVERLAID PILLARS
-> VEIL SEPARATES HOLY FROM MOST HOLY
-> ARK/MERCY SEAT INSIDE / TABLE NORTH + LAMP SOUTH OUTSIDE
-> COLORED EMBROIDERED DOOR SCREEN ON 5 GOLD-OVERLAID PILLARS
```

All relations are construction instructions. No curtain, clasp, covering,
board, socket, bar, veil, screen, room or furniture placement is completed here.

## Exodus 26:1–6 — TEN CURTAINS, ONE INNER UNIT

The inner tabernacle layer uses ten curtains made by a skillful worker from:

- fine twined linen;
- blue, purple and scarlet material;
- cherubim worked into them.

Every curtain is twenty-eight cubits long and four cubits wide. The cubit
footnote repeats the approximately 18-inch/46-centimetre arm measure. All ten
curtains share one measure.

They form two groups of five. On the facing edge of each group are fifty blue
loops aligned opposite one another. Fifty gold clasps join the groups so the
tabernacle becomes one unit.

The retained broad image prohibition from Exodus 20 now meets another explicit
cherub-image fabrication command. Captain has heard this exact contradiction
type before.

> **CAPTAIN CRACKHEAD:** `SKIP -> S086-E001`

His eyes glaze. The ten curtains, dimensions, loops and clasps continue being
specified. Nothing skips.

S086-E002 remains a distinct occurrence because these are skill-work textile
cherub images, not Exodus 25's two hammered-gold mercy-seat images.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the curtain-image boil, licks his finger and walks away without
looking back. Construction remains future.

The decorative cherub figures are nonliving faced images. Every interpreted
face receives Joe's face in production, without merging the repeated figures
or turning the fabric alive.

## Exodus 26:7–14 — ELEVEN GOAT CURTAINS AND TWO HIDE ROOFS

An outer tent layer uses eleven goat-hair curtains. Each is thirty cubits long
and four cubits wide. They form groups of five and six; the sixth curtain is
doubled at the tent front.

Fifty loops on each coupling edge and fifty bronze clasps join the outer tent
as one unit. Its surplus is allocated:

- a remaining half-curtain hangs over the back;
- one remaining cubit on each long side hangs over and covers the tabernacle.

Above this are:

- a red-dyed ram-skin covering;
- a sea-cow-hide covering.

The source does not repeat the `fine leather` alternative here, but the retained
material ambiguity from Exodus 25 remains attached to the same translated hide
term. No animal death, hair collection, dyeing, tanning, sewing or installation
is narrated.

Inner gold clasps and outer bronze clasps belong to different layers. `One
tabernacle` and `one tent` identify joined units without claiming the layers are
one material sheet.

## Exodus 26:15–25 — FORTY-EIGHT UPRIGHT BOARDS

Every upright acacia board is ten cubits long and one-and-a-half cubits wide,
with two joined tenons. The side inventory is:

- south: twenty boards and forty silver sockets;
- north: twenty boards and forty silver sockets;
- west rear: six ordinary boards plus two corner boards;
- west total: eight boards and sixteen silver sockets.

Each board has two sockets, one under each tenon. The two rear corner boards are
double beneath and whole to the top at one ring. The exact join geometry beyond
those words remains in the mountain-shown pattern.

The total is forty-eight boards and ninety-six silver sockets. This arithmetic
is derived directly from the three supplied side inventories; it does not add
materials or assert completed fabrication.

## Exodus 26:26–30 — FIVE BARS PER WALL, ONE THROUGH THE MIDDLE

Acacia bars are specified:

- five for one long side;
- five for the other long side;
- five for the west rear side.

For each wall, its middle bar passes through the boards from end to end. Boards
are gold-overlaid, their bar rings are gold, and the bars are gold-overlaid.

The tabernacle must be erected according to the mountain-shown plan. The words
do not identify which of each wall's five bars is the middle one beyond its
position/function, nor supply dimensions for bars, rings, gold thickness or
assembly tolerances.

## Exodus 26:31–35 — CHERUB VEIL / TWO ROOMS

A skillful worker makes a blue, purple, scarlet and fine-twined-linen veil with
cherubim. It hangs beneath the clasps on four acacia pillars overlaid with gold,
using gold hooks and four silver sockets.

This veil is another textile cherub-image command inside S086-E002. It is part
of the same chapter occurrence and is not DEDUPed into the ten curtains because
it has a distinct room-dividing function and support system.

The veil separates:

- holy place outside;
- most holy place inside.

Inside go the ark of the covenant and mercy seat. Outside, the table is on the
north and the lampstand opposite it on the south.

The ark, covenant and mercy seat remain prospective objects. `Bring the ark in`
does not prove it exists or contains tablets yet.

## Exodus 26:36–37 — FIVE-PILLAR ENTRANCE

The tent door receives an embroidered screen of blue, purple, scarlet and fine
twined linen. It hangs on five acacia pillars overlaid with gold, with gold hooks
and five bronze sockets.

Unlike the inner veil, the door screen is not said to contain cherubim, uses an
embroiderer rather than the skillful-worker phrase, has five rather than four
pillars, and uses bronze rather than silver sockets. The two barriers remain
distinct.

## Character and world-ledger changes

- skillful worker and embroiderer become prospective construction roles without
  named workers or performed labor;
- S086 gains E002 for textile cherub fabrication in curtains and veil;
- SKIP validly points to S086-E001 while doing nothing;
- inner ten-curtain/gold-clasp and outer eleven-curtain/bronze-clasp systems gain
  exact group, measurement and overhang relations;
- ram/sea-cow coverings and goat-hair material sources remain prospective;
- forty-eight-board/ninety-six-socket frame and fifteen-bar wall system enter
  design State;
- veil establishes holy/most-holy room boundary;
- ark/mercy seat, table and lampstand receive prospective placement addresses;
- five-pillar entrance screen enters design State;
- no designed component is promoted into completed inventory;
- Moses remains in mountain instruction State;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — TENT ASSEMBLY MANUAL PAGE 2 OF FUCK KNOWS`;
- inner pack: `10 CURTAINS / CHERUB PRINT / GOLD ZIP`;
- CrackFlix: `SKIP -> S086-E001 / PLAYBACK CONTINUES`;
- outer pack: `11 GOAT CURTAINS / BRONZE ZIP / ONE EXTRA FLAP`;
- roof stack: `GOAT / RED RAM / SEA COW`;
- frame calculator: `48 BOARDS / 96 SILVER FEET`;
- wall stabilizer: `5 BARS EACH / MIDDLE ONE GOES ALL THE WAY`;
- setup help: `REFER TO PATTERN ONLY MOSES SAW`;
- room divider: `CHERUB CURTAIN / HOLY THIS SIDE / MOST HOLY THAT SIDE`;
- furniture map: `ARK IN / TABLE NORTH / LAMP SOUTH`;
- front door: `5 GOLD POSTS / BRONZE SOCKS / NO CHERUB PRINT LISTED`;
- barcode: `CHB-EXO26-S086-E002-37-SKIP-YOINK`.

## FIR verification

- all 37 verse markers are represented in order;
- inner ten-curtain and outer eleven-curtain systems retain distinct materials,
  dimensions, groupings, loops and clasp metals;
- all overhangs and covering order remain exact;
- board/socket totals are derived only from supplied side counts;
- corner geometry remains source-bounded;
- five-bar groups and middle-bar function remain wall-specific;
- S086-E002 preserves new textile image objects rather than merging them with
  hammered-gold cherubim;
- `SKIP` points to exact retained S086-E001 and changes no State;
- curtain cherubim and veil cherubim remain distinct objects/functions inside
  the same occurrence;
- faced nonliving cherub images receive Joe face without becoming alive;
- holy/most-holy and north/south furniture placement remains future;
- veil and entrance screen retain different worker, pillar and socket details;
- no donor, worker, construction or installation is invented;
- Captain remains boilless and causally useless;
- Moses remains on mountain and Joseph bones remain in transport;
- publication remains held and unpublished.

Continuation required: Exodus 27 reconstructs bronze altar and utensils,
courtyard hangings/pillars/sockets, entrance screen and continuously maintained
pure-olive-oil lamp instructions.
