# CRACKHEAD EXODUS 10

## Title page

**LET THEM GO.**

**I HARDENED HIM.**

**HE DIDN'T LET THEM GO.**

Source parent: Exodus chapter 10, verses 1–29, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 10.

Prepared evidence: `.chapter-work/CHB-EXO-010/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/009-ALL-THE-LIVESTOCK-DIED-BRING-YOUR-LIVESTOCK-INSIDE.md`.

CrackFlix routing:

- new `S069 — LET THEM GO. I HARDENED HIM. HE DIDN'T.`;
- `S069-E001-EXO10 — LOCUST RELIEF / HARDEN / NO RELEASE`;
- `S069-E002-EXO10 — DARKNESS TERMS / HARDEN / NO RELEASE`.

## Causal foundation

```text
LORD: I HARDENED PHARAOH + SERVANTS FOR SIGNS/STORY/KNOWLEDGE
-> LORD THROUGH MOSES: HUMBLE / LET PEOPLE GO / LOCUST WARNING
-> SERVANTS: LET THE MEN GO / EGYPT DESTROYED
-> PHARAOH: GO SERVE / WHO GOES?
-> MOSES: YOUNG + OLD + SONS + DAUGHTERS + FLOCKS + HERDS
-> PHARAOH: MEN ONLY / DRIVES MOSES + AARON OUT
-> LORD ORDERS LOCUST ACT
-> EAST WIND / LOCUSTS / ALL HAIL-REMAINDER EATEN / NOTHING GREEN
-> PHARAOH: I SINNED / FORGIVE AGAIN / REMOVE THIS DEATH
-> MOSES PRAYS / WEST WIND REMOVES EVERY LOCUST
-> LORD HARDENS PHARAOH
-> PHARAOH DOES NOT RELEASE
-> LORD ORDERS DARKNESS / THREE DAYS / ISRAEL LIGHT
-> PHARAOH: PEOPLE MAY GO / LIVESTOCK STAYS
-> MOSES: LIVESTOCK GOES / PHARAOH MUST SUPPLY SACRIFICES
-> LORD HARDENS PHARAOH
-> PHARAOH WILL NOT RELEASE
-> PHARAOH: SEE MY FACE AGAIN -> DIE
-> MOSES: I WILL SEE YOUR FACE NO MORE
```

## Exodus 10:1–2 — THE STATED HARDENING PURPOSE

The LORD tells Moses to go to Pharaoh and directly says:

> **I HAVE HARDENED HIS HEART AND THE HEART OF HIS SERVANTS.**

The stated purposes are showing signs among them, telling sons and sons' sons
what was done to Egypt, and knowing that the speaker is the LORD. These are
God-only lines. The manuscript does not replace them with theology, psychology
or an invented defence.

This explicit actor relation continues Exodus 9. Earlier Pharaoh-self-hardening
and servant-hardening Moments remain preserved; one does not erase another.

## Exodus 10:3–11 — GO SERVE, BUT WHICH OF YOU?

Moses and Aaron relay the LORD's question about refusal to humble, repeat the
release-for-service demand, and warn that tomorrow locusts will cover the land,
eat the hail remainder and fill Egyptian houses in a way not seen by the named
ancestral sequence. Moses turns and leaves.

Pharaoh's servants ask how long Moses will be a snare, say Egypt is destroyed,
and tell Pharaoh to let **the men** go serve. Their destruction assessment and
recommended scope remain their speech.

Moses and Aaron are brought back. Pharaoh says `GO, SERVE` and asks who will go.
Moses inventories young, old, sons, daughters, flocks and herds because it is a
feast. Pharaoh rejects departure with little ones, says evil is before their
faces, permits only the men and says that is what they desire. Moses and Aaron
are driven out.

The full-family requirement is Moses' stated requirement. Pharaoh's men-only
offer is an observed restriction, not a completed contradiction by itself.

## Exodus 10:12–15 — NOTHING GREEN REMAINED

The LORD orders Moses to stretch his hand for locusts to eat every herb the hail
left. Moses stretches the rod. The LORD brings an east wind all day and night;
in the morning it carries Joe-faced locusts.

They cover all Egypt's borders and darken the land. The source calls them an
unmatched Egypt event, with no such locusts before or ever again. They eat every
herb and all tree fruit left by hail. Nothing green remains, tree or field herb,
throughout Egypt.

This completes the crop remainder opened in Exodus 9. It does not claim every
seed, root, stored food or future plant has ceased to exist.

## Exodus 10:16–20 — FORGIVE MY SIN AGAIN

Pharaoh calls Moses and Aaron in haste. He says he sinned against the LORD and
against them, asks forgiveness **again**, and asks prayer to remove `THIS
DEATH`. The exact sin-address remains Pharaoh's speech; no private repentance or
specific unstated promise is manufactured.

Moses leaves and prays. The LORD sends an exceedingly strong west wind. It takes
the locusts into the Red Sea/Sea of Reeds source-note address. Not one locust
remains in Egypt.

Then the source states:

> **THE LORD HARDENED PHARAOH'S HEART.**

> **HE DIDN'T LET THE CHILDREN OF ISRAEL GO.**

S069-E001 closes:

```text
LORD HARDENS PHARAOH
-> LORD DEMANDS RELEASE
-> LOCUST SEQUENCE AND COMPLETE RELIEF
-> LORD HARDENS PHARAOH
-> PHARAOH DOES NOT RELEASE
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the command/hardening boil, licks his finger and walks away. God,
Pharaoh and Israel proceed exactly the same without him.

## Exodus 10:21–23 — DARKNESS THAT MAY BE FELT

The LORD orders Moses to stretch his hand toward the sky for darkness that may
be felt. Moses does. Thick darkness covers all Egypt for three days. Egyptian
Joes do not see one another and nobody rises from place during the stated
period. Israel has light in their dwellings.

The text then moves to Pharaoh calling Moses. It does not state whether the
call occurred during darkness, after three days, in person or through a carrier.
No transmission mechanism is invented.

## Exodus 10:24–27 — GO, BUT LEAVE THE LIVESTOCK

Pharaoh now permits the people and little ones to go but requires flocks and
herds to remain. Moses says Pharaoh must also put sacrifices and burnt offerings
in their hands, all livestock must go, not a hoof may remain, and the exact
service selection will not be known until arrival.

The LORD hardens Pharaoh's heart. Pharaoh will not let them go.

CrackFlix points to the completed same relation:

`SKIP -> S069-E001-EXO10 / COMMAND RELEASE + HARDEN + NO RELEASE`

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

His eyes glaze. No negotiation, hardening or refusal is skipped. S069-E002
completes in full:

```text
LORD'S RELEASE COMMAND REMAINS
-> PHARAOH OFFERS RESTRICTED RELEASE
-> MOSES STATES ALL LIVESTOCK REQUIRED
-> LORD HARDENS PHARAOH
-> PHARAOH WILL NOT RELEASE
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the second command/hardening boil, licks his finger and leaves without
looking back.

## Exodus 10:28–29 — NO MORE FACE

Pharaoh orders Moses away and warns that seeing Pharaoh's face again means
death. Moses says Pharaoh has spoken well and that he will see Pharaoh's face no
more.

This is a prospective speech boundary at chapter close. It is not yet compared
to a later audience, carrier, quotation or chronology. No crack is generated
from something that has not happened.

## Character and world-ledger changes

- the LORD explicitly retains hardening of Pharaoh and servants as an act tied
  by direct speech to signs, intergenerational telling and knowledge;
- Pharaoh's servants speak against continued destruction and request a men-only
  release, then Pharaoh negotiates men-only and later people-without-livestock;
- Pharaoh repeats sin/forgiveness language but makes no locust-linked release
  promise in this chapter;
- Moses/Aaron state the full travelling population and livestock requirement;
- locusts consume the hail remainder and are then completely removed;
- Egyptian dwellings receive thick darkness for three days while Israel
  dwellings retain light;
- the final Pharaoh/Moses face statements remain open prospective commitments;
- every locust and every human/animal participant has authoritative Joe face;
  identities remain distinct despite the same face.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — ENABLE REFUSAL / DEMAND RELEASE`;
- Pharaoh admin panel: `HEART LOCK: GOD / RELEASE BUTTON: DISABLED`;
- family export form: `MEN ONLY / CHILD DLC REJECTED / HOOF COUNT: ZERO LEFT`;
- locust screen: `GREEN INVENTORY 0 / BUG INVENTORY 0 AFTER SUPPORT CALL`;
- ancestral replay: `TELL YOUR SON'S SON / CRACKFLIX FAMILY PLAN`;
- darkness label: `CRACKHEAD NIGHT MODE — TOUCH ENABLED`;
- source-note map: `RED SEA / SEA OF REEDS / SEA OF CATTLE FEED`;
- death warning: `FACE ID ATTEMPT = TERMINAL`;
- CrackFlix: `S069 EPISODE 2 — SAME ADMIN SETTINGS`;
- barcode: `CHB-EXO10-S069E001-E002-29-YOINK`.

## FIR verification

- all 29 verse markers are represented in order;
- hardening actor, release command and non-release result remain source-linked;
- S069 has two complete occurrences; episode two uses addressed noncausal SKIP;
- Pharaoh's sin/forgiveness request is not converted into an unstated promise;
- servant destruction/fear and Moses service requirements retain attribution;
- hail remainder closes as locust consumption without exceeding green-growth
  scope;
- locust removal is complete inside Egypt but no global extinction is claimed;
- darkness call timing/carrier remains unresolved;
- final face/death statements remain prospective and produce no premature crack;
- Captain remains boilless, unnoticed and causally useless;
- direct LORD speech/actions remain God-only;
- Israel release and Joseph bone transport remain open;
- publication remains held and unpublished.

Continuation required: Exodus 11 reconstructs the final-plague announcement,
Egyptian favor/property request, Moses' continuing Pharaoh speech boundary,
midnight firstborn scope and the stated exit outcome.
