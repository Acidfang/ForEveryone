# CRACKHEAD EXODUS 9

## Title page

**ALL THE LIVESTOCK DIED.**

**BRING YOUR LIVESTOCK INSIDE.**

Source parent: Exodus chapter 9, verses 1–35, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 9.

Prepared evidence: `.chapter-work/CHB-EXO-009/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/008-TAKE-IT-AWAY-I-WILL-LET-THEM-GO-NO.md`.

CrackFlix routing:

- new `S067 — ALL OF IT DIED. PUT THE REST OF IT INSIDE.`;
- `S067-E001-EXO9 — EGYPT'S DEAD LIVESTOCK NEEDS SHELTER`;
- repeated `S066-E003-EXO9 — HAIL RELIEF PROMISE`;
- new `S068 — I DID WRONG. I DID MORE WRONG.`;
- `S068-E001-EXO9 — I HAVE SINNED / SINNED YET MORE`.

## Causal foundation

```text
RELEASE DEMAND / FIELD-LIVESTOCK PESTILENCE WARNING
-> ISRAEL/EGYPT LIVESTOCK DISTINCTION / TOMORROW APPOINTED
-> ALL EGYPT LIVESTOCK DIES / NO ISRAEL LIVESTOCK DIES
-> PHARAOH VERIFIES ISRAEL STATE / REMAINS STUBBORN / NO RELEASE
-> FURNACE ASH -> DUST -> BOILS ON HUMAN/ANIMAL JOES
-> MAGICIANS CANNOT STAND / LORD HARDENS PHARAOH / NO LISTENING
-> RELEASE DEMAND / HAIL WARNING / SHELTER INSTRUCTION
-> EGYPTIAN SERVANTS SPLIT: SHELTER / FIELD
-> HAIL, THUNDER, LIGHTNING / FIELD DEATH AND CROP/TREE DAMAGE
-> GOSHEN HAS NO HAIL
-> PHARAOH: I SINNED / LORD RIGHTEOUS / WE WICKED
-> PHARAOH: STOP HAIL -> I WILL RELEASE / NO LONGER STAY
-> MOSES: HAIL WILL STOP / YOU DO NOT YET FEAR LORD
-> FLAX/BARLEY STRUCK / WHEAT/SPELT NOT GROWN
-> MOSES PRAYS / HAIL, THUNDER, RAIN CEASE
-> PHARAOH SEES RELIEF / SINS MORE / PHARAOH + SERVANTS HARDEN
-> NO RELEASE
```

## Exodus 9:1–7 — ALL EGYPT'S LIVESTOCK DIED

The LORD sends Moses to repeat the release-for-service demand. Refusal and
continued holding will be followed by grievous pestilence on Pharaoh's
livestock **in the field**: horses, donkeys, camels, herds and flocks. The LORD
states a distinction: nothing belonging to Israel will die. Tomorrow is set.

The next day the source states:

> **ALL THE LIVESTOCK OF EGYPT DIED.**

> **OF THE LIVESTOCK OF ISRAEL, NOT ONE DIED.**

Pharaoh sends to check. Not even one Israel animal is dead. His heart remains
stubborn and he does not release the people.

The warning's field scope and the result's universal Egypt wording are both
retained. Neither is silently rewritten to resolve the other.

## Exodus 9:8–12 — CRACKHEAD BOIL WEATHER

The LORD orders Moses and Aaron to take furnace ashes. Moses sprinkles them
toward the sky before Pharaoh. They become fine dust over Egypt, then boils and
blisters break out on human and animal Joes.

These plague boils have an observed ash/dust event in this chapter. That does
not delete the Crackheadverse organism or the ordinary inherited boils already
present in Joe genetics. They are different retained lineages occupying the
same gloriously useless word.

The magicians cannot stand before Moses because boils are on them and all the
Egyptians. The LORD hardens Pharaoh's heart. Pharaoh does not listen. This is
the first chapter clause that explicitly names the LORD as hardening actor;
prior explicit Pharaoh-self-hardening Moments remain intact.

Captain remains boilless. He does not harvest the visible plague boils merely
because the source calls them boils. No completed contradiction is addressed
there yet.

## Exodus 9:13–21 — WARNED TO SHELTER THE LIVESTOCK

The LORD orders an early-morning release message. Direct speech states the
plagues are being sent against Pharaoh's heart, servants and people so he may
know no one is like the LORD. It states Pharaoh and his people could have been
cut off by pestilence, but Pharaoh was made to stand so power and name would be
shown throughout Earth. Pharaoh is addressed as still exalting himself and not
releasing the people.

Hail is announced for tomorrow. Pharaoh is ordered to bring **all your
livestock** and everything in the field into shelter. Any human or animal left
outside will die.

The chapter has retained no purchase, birth, arrival, redistribution or other
new source for Egyptian livestock between verses 6 and 19. S067-E001 closes on
the observable address:

```text
ALL EGYPT LIVESTOCK DIED
-> NO NEW LIVESTOCK ORIGIN RETAINED
-> BRING ALL YOUR LIVESTOCK IN FROM THE FIELD
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the dead-livestock ledger's Joe-faced boil, licks his finger and walks
away. The livestock warning continues unchanged.

Pharaoh's servants divide by action. Those who fear the LORD's word move their
servants and livestock into houses. Those who do not respect the word leave
servants and livestock in the field. The source supplies these attributed
relations; it does not supply their private thoughts.

## Exodus 9:22–26 — HAIL AND SELECTIVE SHELTER

At command Moses stretches his rod toward the sky. The LORD sends thunder and
hail; lightning flashes to Earth. Severe hail and lightning strike Egypt.

Everything in the field is struck: human Joes, animal Joes, herbs and trees.
Trees break. The shelter warning and the servants' different acts remain part
of the causal chain. The source does not enumerate shelter interiors or count
survivors.

Only Goshen, where Israel lives, has no hail. This is a scoped territorial
State, not permission to invent weather outside the named places.

## Exodus 9:27–35 — I HAVE SINNED / I WILL LET YOU GO

Pharaoh calls Moses and Aaron and says:

> **I HAVE SINNED THIS TIME.**

> **THE LORD IS RIGHTEOUS. I AND MY PEOPLE ARE WICKED.**

He asks them to stop the thunder and hail and promises:

> **I WILL LET YOU GO. YOU SHALL STAY NO LONGER.**

Moses says he will leave the city, spread his hands to the LORD and the thunder
and hail will cease. Moses also says Pharaoh and his servants do not yet fear
the LORD God. This is Moses' stated knowledge, retained as his speech.

The flax and barley are struck because their supplied growth stages expose
them. Wheat and spelt are not struck because they have not grown up. No general
crop law beyond this source statement is invented.

Moses leaves, spreads his hands and the thunder, hail and rain cease.

Captain's private CrackFlix addresses the already completed relief-promise type:

`SKIP -> S066-E001-EXO8 / REMOVE IT AND I WILL RELEASE`

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

His eyes glaze. The world does not skip. Pharaoh sees the rain, hail and thunder
have ceased. He sins yet more; he and his servants harden their hearts. Pharaoh
does not let Israel go.

S066-E003 closes:

```text
STOP HAIL -> I WILL RELEASE
-> HAIL STOPS
-> HEARTS HARDEN
-> NO RELEASE
```

S068-E001 closes independently:

```text
PHARAOH: I HAVE SINNED / I AM WICKED
-> RELIEF COMPLETES
-> SOURCE: HE SINNED YET MORE
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the promise/confession boil once, licks his finger and leaves without
looking back. Pharaoh, servants and Israel continue exactly as they were going
to continue without him.

## Character and world-ledger changes

- Pharaoh verifies the Israel-livestock distinction, remains stubborn, later
  confesses sin/wickedness, promises release and then sins more/hardens again.
- Pharaoh's servants become explicit hail-warning actors: some shelter servants
  and livestock; others leave them outside; later servants join Pharaoh in
  hardening.
- Moses/Aaron carry pestilence, ash/boil and hail instructions; Moses performs
  ash casting, rod extension and prayer-relief acts.
- magicians move from lice failure to inability to stand because of boils.
- Egyptian livestock receives incompatible retained States without an invented
  replacement origin: all dead, then present for shelter.
- Israel livestock remains entirely alive in the stated inspection.
- field humans/animals/crops/trees, sheltered groups and Goshen remain distinct.
- plague boils have an ash/dust event; ordinary Crackheadverse boils retain
  their organism lineage; Captain remains absolutely boilless.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — TOTAL LIVESTOCK DEATH / SHELTER REMINDER`;
- inventory console: `EGYPT LIVESTOCK: 0 / LIVESTOCK TO MOVE: ALL`;
- weather warning: `CRACKHEAD HAIL PATCH — HOUSE DLC REQUIRED`;
- boil forecast: `FURNACE ASH + SKY = EXECUTIVE COMPLEXION EVENT`;
- magician attendance: `UNABLE TO STAND / BOILS TOO SUCCESSFUL`;
- crop firmware: `BARLEY RIPE / FLAX BLOOM / WHEAT-SPELT NOT BOOTED`;
- CrackFlix: `S066 EPISODE 3 — THE WEATHER PROMISE`;
- warning label: `SKIP EXPLANATION ONLY / PHARAOH STILL PHARAOHS`;
- barcode: `CHB-EXO9-S066E003-S067E001-S068E001-35-YOINK`.

## FIR verification

- all 35 verse markers are represented in order;
- field scope in the warning and universal Egypt scope in the death report are
  both retained without silent harmonization;
- later Egyptian livestock has no invented origin, creating S067-E001;
- plague-boil causation does not replace inherited organism-boil canon;
- Captain remains boilless and causally useless;
- LORD hardening and Pharaoh/self/servant hardening clauses retain their exact
  actors and Moments;
- shelter response groups are distinguished only by observed/attributed acts;
- S066-E003 points SKIP to the exact earlier contradiction and still occurs;
- Pharaoh's confession and subsequent narrator-assigned sin form S068-E001;
- direct LORD speech/actions remain God-only; Moses' fear assessment remains
  Moses speech;
- Israel release and Joseph bone transport remain open;
- publication remains held and unpublished.

Continuation required: Exodus 10 reconstructs locust scope, remaining crop
consumption, servant pressure, negotiation over who goes, darkness, livestock
terms and the final threatened audience.
