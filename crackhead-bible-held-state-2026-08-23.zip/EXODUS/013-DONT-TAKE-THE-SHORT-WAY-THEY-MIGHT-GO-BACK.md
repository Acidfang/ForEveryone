# CRACKHEAD EXODUS 13

## Title page

**DON'T TAKE THE SHORT WAY.**

**THEY MIGHT GO BACK.**

Source parent: Exodus chapter 13, verses 1–22, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 13.

Prepared evidence: `.chapter-work/CHB-EXO-013/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/012-I-HAVE-BROUGHT-YOU-OUT-YOU-ARE-STILL-IN-EGYPT.md`.

CrackFlix routing: no new series or episode. S070's exit claim is now an
already completed actual State, not a repeated contradiction. The route choice
has a source-supplied prospective dependency and is not contradictory.

## Causal foundation

```text
LORD CLAIMS ALL ISRAEL WOMB-OPENING FIRSTBORN HUMAN/ANIMAL
-> MOSES: REMEMBER EXIT DAY / NO LEAVEN / ABIB
-> FUTURE LAND ENTRY -> SEVEN-DAY SERVICE / SON TEACHING / SIGN/MEMORIAL
-> FUTURE LAND ENTRY -> FIRSTBORN ANIMAL SET-APART
-> DONKEY REDEEM-WITH-LAMB OR BREAK-NECK
-> HUMAN FIRSTBORN REDEEM
-> FUTURE SON QUESTION -> EXIT/FIRSTBORN EXPLANATION
-> PHARAOH HAS LET PEOPLE GO
-> NEAR PHILISTINE ROUTE EXISTS
-> GOD STATES POSSIBLE WAR-SIGHT -> MIND CHANGE -> RETURN TO EGYPT
-> GOD DOES NOT LEAD NEAR ROUTE
-> GOD LEADS AROUND BY WILDERNESS/RED SEA
-> ISRAEL GOES UP ARMED
-> MOSES TAKES JOSEPH'S BONES UNDER RETAINED OATH
-> SUCCOTH -> ETHAM / WILDERNESS EDGE
-> LORD GOES BEFORE BY CLOUD DAY / FIRE NIGHT
-> LIGHT + DAY/NIGHT TRAVEL
-> PILLARS DO NOT DEPART
```

## Exodus 13:1–2 — THE FIRSTBORN IS MINE

The LORD tells Moses to sanctify all Israel firstborn, whatever opens a womb,
human and animal, and says `IT IS MINE.` This is a direct God-only ownership and
set-apart command. The chapter has not yet performed every future consecration,
redemption, sacrifice or neck-breaking outcome.

Every firstborn human, donkey, lamb and other animal has Joe face while
remaining a separate organism and legal identity.

## Exodus 13:3–10 — REMEMBER THIS DAY

Moses tells the people to remember the day they came out of Egypt, the house of
bondage, attributing the exit to the LORD's strong hand. Today they leave in
Abib. No leavened bread is to be eaten.

When the LORD brings them into the named Canaanite, Hittite, Amorite, Hivite and
Jebusite land promised to their fathers—described as flowing with milk and
honey—they are to keep the service in this month:

- seven days unleavened bread;
- seventh-day feast;
- no visible leavened bread or yeast within their borders;
- tell a son the service is because of what the LORD did when the speaker came
  out of Egypt;
- retain it as hand sign, between-eyes memorial and mouth-law relation;
- keep it in season year by year.

The land entry, future sons' questions and later annual observances remain
future. The exit explanation is current retained history.

## Exodus 13:11–16 — REDEEM IT OR BREAK ITS NECK

The instruction again begins at future Canaan land entry. All male firstborn
animals are set apart to the LORD. A firstborn donkey must be redeemed with a
lamb or have its neck broken. Every human firstborn son is redeemed.

When a son later asks `WHAT IS THIS?`, the supplied answer traces:

```text
PHARAOH STUBBORNLY REFUSED RELEASE
-> LORD KILLED EGYPT FIRSTBORN HUMAN + LIVESTOCK
-> MALE WOMB-OPENERS SACRIFICED
-> HUMAN FIRSTBORN SONS REDEEMED
```

The response becomes hand sign and between-eyes symbol because the LORD brought
Israel out by strength of hand. The future child question and future individual
redemptions are not backfilled as performed.

## Exodus 13:17–18 — THE LONG WAY HAS A STATED ROOT

Pharaoh has let the people go. God does not lead them by the nearby Philistine
land route. The source supplies the reason as direct God speech:

> **LEST PERHAPS THE PEOPLE CHANGE THEIR MINDS WHEN THEY SEE WAR, AND RETURN TO EGYPT.**

The chain is prospective:

```text
NEAR ROUTE
-> POSSIBLE WAR SIGHT
-> POSSIBLE MIND CHANGE
-> POSSIBLE RETURN
-> ROUTE NOT SELECTED
```

No observed war, mind change or attempted return is claimed. God leads the
people around by the wilderness/Red Sea route instead. Israel goes up armed.
This is source-supplied route selection, not `SHORTER ROUTE AVAILABLE` crack.

## Exodus 13:19 — JOSEPH'S BONES MOVE

Moses takes Joseph's bones with him. The source explicitly points back to
Joseph making Israel swear:

> **GOD WILL SURELY VISIT YOU.**

> **YOU SHALL CARRY MY BONES AWAY FROM HERE WITH YOU.**

The chain opened in Genesis 50 now changes State:

```text
JOSEPH DIES / EMBALMED / COFFINED IN EGYPT
-> ISRAEL SWEARS FUTURE BONES TRANSPORT
-> GOD VISIT/EXIT CHAIN OCCURS
-> MOSES TAKES BONES WITH DEPARTING PEOPLE
-> TRANSPORT ACTIVE
-> BURIAL LOCATION/COMPLETION STILL OPEN
```

This is oath performance evidence, not contradiction. Joseph remains dead;
his bones are not a living Joe and do not receive a new face or personality.

## Exodus 13:20–22 — CRACKHEAD GPS

The people journey from Succoth and camp at Etham on the wilderness edge. The
LORD goes before them:

- by day, a cloud pillar leads the way;
- by night, a fire pillar gives light;
- the supplied result is travel by day and night;
- neither pillar departs from before the people.

The source does not state whether these are one changing pillar or two objects,
does not describe physics, and does not name a separate pillar organism. Anything
interpreted visually as having a face may receive Joe face in production, but
the ledger does not invent living status.

Captain Crackhead does not appear. Nothing in this chapter completes a new
claim/act mismatch.

## Character and world-ledger changes

- the LORD claims Israel firstborn and supplies consecration/redemption,
  remembrance, route and guidance rules;
- Moses becomes physical carrier of Joseph's bones, closing the transport-start
  requirement while burial remains open;
- Israel moves Succoth to Etham, armed, by the selected wilderness/Red Sea way;
- the people retain current exit memory and future land/child/annual teaching
  obligations;
- firstborn human and animal Joes receive distinct sacrifice/redemption rules;
- donkey firstborn receive the lamb-redemption-or-neck-breaking condition;
- named Canaan land peoples remain current inhabitants inside a future-entry
  statement, not erased scenery;
- cloud/fire pillars remain continuous observable guidance without invented
  ontology;
- no new CrackFlix occurrence is created.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — ROUTE OPTIMIZED FOR NOT TURNING AROUND`;
- firstborn registry: `OPENS WOMB -> LORD INVENTORY`;
- donkey service desk: `REDEEM WITH LAMB / OTHERWISE NECK SUPPORT ENDS`;
- bread scanner: `YEAST VISIBILITY RANGE: ALL BORDERS`;
- future-son script: `WHAT IS THIS? -> STRONG HAND FAQ`;
- route planner: `FASTEST: PHILISTINES / SELECTED: FUCKING AROUND`;
- Joseph cargo label: `BONES / OATH-TRACKED / BURIAL PENDING`;
- pillar navigation: `CLOUD DAY / FIRE NIGHT / RECALCULATING NEVER`;
- warning: `DO NOT GENERATE CRACK FROM A POSSIBILITY`;
- barcode: `CHB-EXO13-22-BONES-MOVING-NO-YOINK`.

## FIR verification

- all 22 verse markers are represented in order;
- firstborn commands are distinguished from later/future individual execution;
- future land entry, child questions and annual observance remain future;
- near-route rejection retains God's exact prospective reason without treating
  possibility as observed fact;
- no S010 prevention episode is created because the prevented outcome does not
  occur in the retained chapter;
- Joseph bones transport is directly observed and oath lineage closes only to
  `transport active`, not burial complete;
- cloud/fire continuity is retained without invented object count or physics;
- no Captain appears because no fresh contradiction completes;
- direct LORD/God speech/actions remain God-only;
- S070 receives actual-exit continuity but no repeated mismatch;
- publication remains held and unpublished.

Continuation required: Exodus 14 reconstructs the encampment reversal,
Pharaoh's pursuit, Israel's Egypt-service comparison, cloud/fire separation,
sea division/crossing, Egyptian pursuit, water return and observed deaths.
