# CRACKHEAD EXODUS 37

## Title page

**TWO GOLD CHERUBIM. ACTUALLY MADE.**

**THE FORBIDDEN AUTHORIZED OIL. ALSO MADE.**

Source parent: Exodus chapter 37, verses 1–29, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-EXO-037/job.json` and `source.usfm`.

Parent manuscript: `EXODUS/036-STOP-BRINGING-STUFF-WE-HAVE-TOO-MUCH.md`.

CrackFlix routing:

- `S086-E004-EXO37 — HAMMERED GOLD CHERUBIM MANUFACTURED`;
- `SKIP -> S086-E001-EXO25`;
- `S090-E002-EXO37 — AUTHORIZED FORBIDDEN OIL COMPOUNDED`;
- `SKIP -> S090-E001-EXO30`.

## Causal foundation

```text
BEZALEL MAKES ARK + POLES
-> MERCY SEAT MADE
-> TWO GOLD WINGED/FACED CHERUBIM MADE
-> TABLE + POLES + GOLD VESSELS MADE
-> ONE-PIECE GOLD LAMPSTAND + SEVEN LAMPS/TOOLS MADE
-> INCENSE ALTAR + POLES MADE
-> HOLY ANOINTING OIL MADE
-> PURE SWEET-SPICE INCENSE MADE
-> OBJECTS COMPLETE
-> PLACEMENT / ANOINTING / SERVICE STILL FUTURE
```

## Exodus 37:1–9 — ARK, MERCY SEAT, CHERUBIM

Bezalel personally makes the acacia ark, two-and-a-half by one-and-a-half by
one-and-a-half cubits. He overlays it inside/outside with pure gold, adds gold
molding and four gold rings, makes gold-overlaid acacia poles and places them in
the rings.

He makes the pure-gold mercy seat, two-and-a-half by one-and-a-half cubits, then
makes two hammered-gold cherubim as one piece with its ends. Their wings spread
above and cover the seat; their faced forms look toward one another and the
seat. Anything with a depicted face receives Joe's face.

Captain presses:

> **SKIP -> S086-E001**

His eyes glaze. Bezalel keeps hammering the faces and wings. The new objects
exist anyway. S086-E004 closes when the two images are made.

Captain Crackhead: **YOINK!**

He pokes the gold-cherub boil, licks his finger and walks away without looking
back. The ark assembly remains unchanged.

## Exodus 37:10–16 — TABLE AND VESSELS

The acacia table is made two by one by one-and-a-half cubits, overlaid in pure
gold with molding, hand-width border and second molding. Four gold rings at the
feet receive gold-overlaid acacia carrying poles. Pure-gold dishes, spoons,
bowls and pouring pitchers are made.

No show bread, liquid, carrying, placement or table service occurs yet.

## Exodus 37:17–24 — ONE TALENT OF LAMPSTAND

The lampstand is one beaten work of pure gold: base, shaft, cups, buds and
flowers. Six side branches extend three and three. Each branch has three
almond-blossom cups with bud/flower; the central lampstand has four. Three
under-pair buds join the six branches. Seven lamps, snuffers and snuff dishes
are made of pure gold. Lampstand and vessels use one talent, approximately
thirty kilograms in the source footnote.

No oil is put in the lamps and none is lit.

## Exodus 37:25–28 — INCENSE ALTAR

The square acacia incense altar is one by one by two cubits with one-piece
horns. Its top, sides and horns are pure-gold overlaid with gold molding. Two
gold rings receive gold-overlaid acacia poles.

No incense is burned, altar placed or blood applied.

## Exodus 37:29 — PERFUMER OUTPUT

The maker produces holy anointing oil and pure sweet-spice incense according to
the perfumer's art. This is performed formula manufacture.

The incense prohibition previously supplied an explicit `for yourselves`
boundary, so authorized sacred manufacture does not conflict with it.

The oil command, however, required this exact holy composition while its rule
categorically prohibited making any like it without expressly stating the
authorized original-batch exception. S090-E002 advances that retained friction
from command to actual manufacture.

Captain presses:

> **SKIP -> S090-E001**

His eyes glaze while the oil is compounded. Nothing skips.

Captain Crackhead: **YOINK!**

He pokes the oil-batch boil, licks his finger and walks away without looking
back. The oil remains made but unapplied. S091 does not advance because no
priest flesh is anointed here.

## Character and world-ledger changes

- Bezalel becomes the explicitly named ark maker;
- collective `he` after the named ark act remains linked to the chapter maker
  context without claiming Bezalel personally performed every object where the
  source does not repeat his name;
- ark, mercy seat, two cherubim, table/vessels, lampstand/tools, incense altar,
  holy oil and incense all become completed;
- carrying poles are installed in ark rings and made for table/altar;
- S086 gains an actual hammered-gold cherub episode with exact pointer to E001;
- S090 gains actual oil manufacture with exact pointer to E001;
- S091 remains open because oil application has not occurred;
- all placement, anointing, filling, lighting, burning and priestly service
  remain future;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — FURNITURE FACTORY`;
- ark label: `ACACIA CORE / GOLD INSIDE OUT / POLES PRELOADED`;
- CrackFlix: `SKIP -> S086-E001 / GOLD FACES STILL HAMMERED`;
- cherub camera: `TWO JOE FACES LOOKING AT THE LID`;
- table kit: `DISH / SPOON / BOWL / POUR THING / FOOD NULL`;
- lampstand: `ONE TALENT / SEVEN OUTPUTS / POWER NOT CONNECTED`;
- smell altar: `1x1x2 / NO SMELL YET`;
- CrackFlix: `SKIP -> S090-E001 / OIL STILL COMPOUNDED`;
- formula status: `HOLY OIL YES / PURE INCENSE YES / USERS NOT ANOINTED`;
- barcode: `CHB-EXO37-S086-E004-S090-E002-29-2SKIP-2YOINK`.

## FIR verification

- all 29 verse markers are represented in order;
- Bezalel's named ark act is retained without silently assigning every later
  pronoun act to him as exclusive maker;
- every dimension, material, ring/pole and lamp/branch relation is retained;
- S086-E004 is a distinct performed gold-image occurrence and points exactly to
  S086-E001;
- S090-E002 is performed formula manufacture and points exactly to S090-E001;
- SKIP changes neither manufacture nor world State;
- incense's explicit personal-use boundary prevents an invented contradiction;
- no S091 episode exists because no oil application occurs;
- completed objects do not become placed, filled, lit, burned, anointed or used;
- Captain says exactly `YOINK!`, has no boils and affects nothing;
- every living being and interpreted face uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Exodus 38 reconstructs burnt altar, basin from women's
mirrors, court, material accounting and named Ithamar oversight.
