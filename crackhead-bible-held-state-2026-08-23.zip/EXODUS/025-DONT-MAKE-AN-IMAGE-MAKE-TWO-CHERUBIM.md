# CRACKHEAD EXODUS 25

## Title page

**DON'T MAKE AN IMAGE OF ANYTHING IN HEAVEN.**

**MAKE TWO CHERUBIM WITH WINGS AND FACES.**

Source parent: Exodus chapter 25, verses 1–40, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 25.

Prepared evidence: `.chapter-work/CHB-EXO-025/job.json` and `source.usfm`.

Parent manuscript: `EXODUS/024-THEY-SAW-GOD-AND-ATE-AND-DRANK.md`.

CrackFlix routing:

- new `S086-E001-EXO25 — NO HEAVENLY IMAGES / MAKE TWO CHERUBIM`.

## Causal foundation

```text
LORD SPEAKS TO MOSES
-> TAKE OFFERING ONLY FROM WILLING-HEART PEOPLE
-> EXACT MATERIAL INVENTORY
-> PEOPLE MAKE SANCTUARY -> GOD MAY DWELL AMONG THEM
-> BUILD TO SHOWN TABERNACLE/FURNITURE PATTERN
-> ARK: ACACIA + DIMENSIONS + GOLD INSIDE/OUT + MOLDING
-> FOUR RINGS + PERMANENT GOLD-COVERED CARRY POLES
-> FUTURE COVENANT GOES INSIDE
-> PURE-GOLD MERCY SEAT MATCHES ARK TOP DIMENSIONS
-> TWO HAMMERED-GOLD CHERUBIM, ONE PIECE, WINGS/FACES
-> MERCY SEAT ON ARK / COVENANT INSIDE
-> GOD MEETS/SPEAKS ABOVE SEAT BETWEEN CHERUBIM
-> TABLE: ACACIA + DIMENSIONS + GOLD + RIM/MOLDING
-> FOUR RINGS + GOLD-COVERED POLES + PURE-GOLD UTENSILS
-> PRESENCE BREAD ALWAYS BEFORE GOD
-> LAMPSTAND: ONE HAMMERED PURE-GOLD PIECE
-> SIX SIDE BRANCHES + SHAFT + ALMOND CUPS/BUDS/FLOWERS
-> SEVEN LAMPS + GOLD TOOLS + ONE TALENT TOTAL
-> MAKE EVERYTHING TO MOUNTAIN-SHOWN PATTERN
```

All objects remain commanded designs. No offering is collected, no sanctuary or
furniture is constructed, no covenant is inserted, no bread is set, no lamp is
lit and no meeting occurs in this chapter.

## Exodus 25:1–9 — WILLING MATERIALS FOR A PLACE TO LIVE

The LORD tells Moses to take an offering from every Israelite whose heart makes
that person willing. The accepted inventory is:

- gold, silver and bronze;
- blue, purple and scarlet material;
- fine linen and goats' hair;
- red-dyed ram skins;
- sea-cow hides, with `fine leather` retained as the source footnote
  alternative;
- acacia wood;
- lamp oil;
- spices for anointing oil and sweet incense;
- onyx and setting stones for ephod and breastplate.

The people are to make God a sanctuary so he may dwell among them. It and all
furniture must follow the pattern God shows Moses.

Willingness is source-attributed to the prospective giver's heart. No giver,
amount, collection, refusal, material origin, sanctuary worker or completed
dwelling State appears here.

Ram, sea cow and goat source animals are living Joes when shown alive. Their
hair/skins/hides are materials after separation and are not new living
identities.

## Exodus 25:10–16 — ARK / KEEP THE HANDLES INSTALLED

The ark specification is:

- acacia wood;
- length two-and-a-half cubits;
- width one-and-a-half cubits;
- height one-and-a-half cubits;
- pure-gold overlay inside and outside;
- gold molding around it;
- four cast-gold rings at four feet, two per side;
- acacia poles overlaid with gold, inserted through side rings for carrying;
- poles remain in the rings and are never removed;
- the future covenant God gives Moses goes inside.

The cubit footnote defines a cubit as an arm-based length and approximately 18
inches or 46 centimetres. It is a translation aid, not a second required unit
system or evidence that an arm was used in construction.

The poles' permanent installation is a transport-readiness rule, not proof that
the ark is already moving. The covenant/tablets remain future at this Moment.

## Exodus 25:17–22 — DON'T MAKE IMAGES / PUT FACES ON THIS ONE

The mercy seat is pure gold, two-and-a-half cubits long and one-and-a-half
cubits wide. Two hammered-gold cherubim are made at its two ends as one piece
with it.

The cherubim have:

- wings spread upward and covering the mercy seat;
- faces toward one another;
- faces also directed toward the mercy seat.

The retained Exodus 20 command said:

> **YOU SHALL NOT MAKE FOR YOURSELF AN IDOL, NOR ANY IMAGE OF ANYTHING THAT IS IN HEAVEN ABOVE, THE EARTH BENEATH, OR THE WATER UNDER THE EARTH.**

The new direct command says:

> **YOU SHALL MAKE TWO CHERUBIM OF HAMMERED GOLD.**

S086-E001 closes at the command layer:

```text
EXODUS 20: NO IMAGE OF ANY HEAVEN/EARTH/WATER THING
-> EXODUS 25: MANUFACTURE TWO NAMED WINGED/FACED CHERUBIM IN GOLD
-> NO EXPLICIT IMAGE-RULE EXCEPTION OR OBJECT-CLASS BRIDGE SUPPLIED
```

The earlier rule also used `for yourself` and prohibited bowing/serving. The
new object is commanded for God's sanctuary rather than private worship. That
purpose difference is retained, but the broad fabrication wording and the
specific fabrication command remain observably unbridged.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the image-policy boil, licks his finger and walks away without looking
back. The cherubim are still only specifications.

The manufactured cherubim are nonliving images unless a later source gives
them life. Because they have faces, each face receives Joe's face in production.
Their two image identities remain distinct despite the shared face.

The mercy seat goes on the ark and the future covenant inside. God says he will
meet Moses there and speak from above the seat, between the two cherubim, giving
commands for Israel. This is a future communication location, not a completed
meeting or proof that God inhabits the images.

## Exodus 25:23–30 — GOLD TABLE / BREAD ALWAYS

The table specification is:

- acacia wood;
- two cubits long, one cubit wide, one-and-a-half cubits high;
- pure-gold overlay and surrounding gold molding;
- hand-width rim with its own surrounding gold molding;
- four gold rings at four foot-corners near the rim;
- acacia carrying poles overlaid with gold;
- pure-gold dishes, spoons, ladles and pouring bowls.

Presence bread is to be set before God always. The text supplies no bread
recipe, count, replacement interval, baker, eater or performed placement.

Unlike the ark poles, the table poles are not explicitly required to remain in
their rings. The similar transport systems are not silently made identical.

## Exodus 25:31–40 — ONE TALENT, ONE PIECE, SEVEN LIGHTS

The lampstand is hammered from pure gold as one piece including base, shaft,
cups, buds and flowers.

Its form includes:

- six side branches: three from each side;
- three almond-blossom-like cups with bud and flower on each side branch;
- four almond-blossom-like cups with buds and flowers on the central
  lampstand;
- one bud under each pair of branches, three paired positions total;
- all branches and buds one beaten piece with the stand;
- seven lamps giving light to the space in front;
- pure-gold snuffers and snuff dishes;
- one talent of pure gold for lampstand and accessories.

The talent footnote gives approximately 30 kilograms, 66 pounds or 965 Troy
ounces. These are alternate unit expressions for the same source measure, not
three separate gold allocations.

Moses must ensure everything follows the pattern shown on the mountain. The
source does not reproduce the visual pattern beyond the verbal specification,
identify the craft worker, state fabrication tolerances or narrate construction.

The almond-like cups, buds and flowers are nonliving decorative forms. They may
receive Joe faces if production interprets faces, but they do not become living
almond trees or flowers.

## Character and world-ledger changes

- willing Israelites gain prospective offering roles without an offering act;
- sanctuary, tabernacle pattern and furniture pattern enter commanded State;
- ark, permanent poles, future covenant contents and mercy seat gain exact
  material/dimension/function relations;
- two manufactured cherub images gain wing/face/orientation relations;
- S086 records broad no-image fabrication against commanded cherub fabrication;
- mercy-seat/between-cherubim becomes a future God/Moses speech address;
- table, transport equipment, utensils and always-present bread enter commanded
  State;
- one-piece seven-lamp lampstand and one-talent gold allocation enter commanded
  State;
- no designed object is promoted into completed inventory;
- Moses remains in the mountain/cloud instruction State;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — GOD'S FLAT-PACK SANCTUARY CATALOGUE`;
- donation portal: `WILLING HEARTS ONLY / MATERIAL LIST EXTREMELY SPECIFIC`;
- hide dropdown: `SEA COW OR FINE LEATHER — TRANSLATOR UNSURE`;
- dwelling condition: `BUILD HOUSE SO GOD CAN MOVE IN`;
- ark size: `2.5 x 1.5 x 1.5 CUBITS / ARM SOLD SEPARATELY`;
- carry poles: `DO NOT REMOVE HANDLES EVER`;
- image policy: `NO IMAGES / CHERUB IMAGE KIT x2`;
- CrackFlix: `S086 E001 — AUTHORIZED FORBIDDEN IMAGE PACKAGE`;
- divine audio address: `ABOVE LID / BETWEEN GOLD JOES`;
- table setting: `PRESENCE BREAD: ALWAYS / RECIPE: NOT INCLUDED`;
- lamp geometry: `3 LEFT + 3 RIGHT + SHAFT = 7 LIGHTS`;
- gold budget: `ONE TALENT / 30 KG / 66 LB / SAME FUCKING GOLD`;
- final warning: `MATCH THE PATTERN YOU SAW BUT WE CAN'T SEE`;
- barcode: `CHB-EXO25-S086-40-YOINK`.

## FIR verification

- all 40 verse markers are represented in order;
- willing-heart condition remains attributed and no donor is invented;
- complete offering material inventory and translation alternatives are
  retained;
- sanctuary purpose and mountain-pattern authority remain future instructions;
- ark/table/lampstand dimensions, materials, rings, poles and accessories remain
  separately addressed;
- permanent ark poles are not generalized to table poles;
- future covenant placement is not recorded as performed;
- S086 preserves both the broad Exodus 20 image rule and the specific cherub
  construction command, including their purpose difference;
- no cherub construction, life, worship or divine inhabitation is invented;
- the two faced cherub images receive Joe face in production but remain
  nonliving distinct objects;
- mercy-seat speech location remains future;
- presence bread `always` remains an obligation, not observed continuity;
- seven lamp count and one-talent alternate measures remain exact;
- shown pattern is not invented beyond supplied words;
- Captain remains boilless and causally useless;
- Moses remains on mountain and Joseph bones remain in transport;
- publication remains held and unpublished.

Continuation required: Exodus 26 reconstructs ten-curtain tabernacle layers,
loops/clasps, goat-hair tent, ram/sea-cow coverings, acacia frames, bars, veil,
room division, furniture placement and entrance screen specifications.
