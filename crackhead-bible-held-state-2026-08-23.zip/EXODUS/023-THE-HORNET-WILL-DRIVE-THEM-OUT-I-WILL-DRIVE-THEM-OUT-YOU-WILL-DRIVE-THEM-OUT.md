# CRACKHEAD EXODUS 23

## Title page

**THE HORNET WILL DRIVE THEM OUT.**

**I WILL DRIVE THEM OUT.**

**YOU SHALL DRIVE THEM OUT.**

Source parent: Exodus chapter 23, verses 1–33, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 23.

Prepared evidence: `.chapter-work/CHB-EXO-023/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/022-DONT-TAKE-ADVANTAGE-OF-WIDOWS-I-WILL-MAKE-YOUR-WIVES-WIDOWS.md`.

CrackFlix routing:

- new `S085-E001-EXO23 — HORNET / GOD / ISRAEL ALL DRIVE THEM OUT`.

## Causal foundation

```text
NO FALSE REPORT/MALICIOUS WITNESS/CROWD-PERVERTED JUSTICE
-> NO POOR-PERSON FAVOR / NO POOR-PERSON JUSTICE DENIAL
-> RETURN ENEMY'S STRAY LIVESTOCK / HELP HATER'S BURDENED DONKEY
-> NO FALSE CHARGE / INNOCENT KILLING / BRIBE / ALIEN OPPRESSION
-> SIX-YEAR LAND USE / SEVENTH-YEAR FALLOW FOR POOR THEN FIELD ANIMALS
-> SIX-DAY WORK / SEVENTH-DAY REST FOR PEOPLE + WORK ANIMALS
-> DO ALL GOD SAID / OTHER-GOD NAMES NOT INVOKED
-> THREE ANNUAL FEASTS / ALL MALES APPEAR / NOT EMPTY
-> SACRIFICE, FAT, FIRSTFRUIT AND YOUNG-GOAT/MOTHER-MILK RULES
-> GOD SENDS ANGEL TO GUARD/BRING
-> LISTEN/OBEY / ANGEL WILL NOT PARDON / GOD'S NAME IN ANGEL
-> CONDITIONAL DIVINE ENMITY AGAINST ENEMIES
-> ANGEL LEADS TO SIX PEOPLES / GOD CUTS THEM OFF
-> NO THEIR-GOD SERVICE / OVERTHROW/PILLARS
-> SERVE LORD -> BREAD/WATER/HEALTH/FERTILITY/DAYS PROMISES
-> TERROR/CONFUSION/ENEMY RETREAT
-> HORNET DRIVES THREE PEOPLES OUT
-> GOD DOES NOT DRIVE THEM OUT IN ONE YEAR
-> GOD DRIVES THEM OUT LITTLE BY LITTLE
-> GOD DELIVERS INHABITANTS / ISRAEL DRIVES THEM OUT
-> NO COVENANT / NO RESIDENCE / NO OTHER-GOD SNARE
```

This chapter establishes commands, schedules and future conditional promises.
It narrates no lawsuit, enemy-property encounter, Sabbath year, feast, offering,
angel journey, land entry, displacement, covenant, blessing or failure as
completed.

## Exodus 23:1–3 — DON'T LET THE CROWD WRITE THE VERDICT

The direct justice rules prohibit:

- spreading a false report;
- joining the wicked as a malicious witness;
- following a crowd to do evil;
- testifying with a multitude to pervert justice;
- favoring a poor man in his cause.

The poor-person rule concerns favoritism, not denial of a valid claim. It does
not conflict with verse 6's later prohibition against denying poor people
justice. No report, witness, crowd, court, poor claimant or verdict appears.

## Exodus 23:4–5 — ENEMY ROADSIDE ASSISTANCE

If a person's enemy's ox or donkey is found straying, it must be returned. If
the donkey of someone who hates the person is seen fallen under its burden, the
observer must not leave him and must help.

Enemy/hater status does not remove the property-return or assistance duties.
No enemy identity, hatred act, animal, burden, encounter, return or assistance
is performed. Each hypothetical animal remains its own Joe.

## Exodus 23:6–9 — JUSTICE ISN'T A POOR-PERSON BONUS OR PENALTY

The people must not:

- deny justice to poor people in lawsuits;
- approach a false charge;
- kill the innocent and righteous;
- take a bribe;
- oppress an alien.

God says he will not justify the wicked. The stated bribe mechanism is that it
blinds those with sight and perverts righteous words. Israel's knowledge of an
alien's heart is attributed to Israel's former alien State in Egypt.

`Do not favor a poor man` and `do not deny justice to your poor people` bound
opposite distortions. Neither supplies an actual correct verdict, so no crack or
imagined case is created.

## Exodus 23:10–13 — SIX ON / ONE OPEN

For six years land is sown and its increase gathered. In the seventh year it is
left resting and fallow so poor people may eat and field animals may eat what
they leave. The same applies to vineyard and olive grove.

For six days work is performed. On the seventh day people rest so ox and donkey
rest and the servant's son and alien are refreshed.

These year and day cycles use the same six-plus-one form at different scales.
They agree with the retained Sabbath schedule and do not repeat S074's
`every-day` wording.

The people must carefully do all God has said and must not invoke other gods'
names or let those names be heard from their mouths. The chapter says `other
gods` as a class; it does not make an Israelite invoke a particular forbidden
name.

## Exodus 23:14–19 — THREE APPEARANCES AND THE GOAT RECIPE BAN

Three annual feast appearances are established:

- unleavened bread for seven days at the appointed Abib time, linked to the
  Egypt exit;
- harvest/firstfruits of field labor;
- ingathering at year end.

All males appear before the Lord GOD three times yearly, and no one appears
empty. Sacrifice blood is not offered with leavened bread; feast fat does not
remain overnight; the first of firstfruits enters the LORD's house.

A young goat must not be boiled in its mother's milk. Goat and mother are
distinct living Joes. The milk is not a living identity. No feast attendance,
gift, sacrifice, fat storage, house entry or boiling attempt occurs here.

The future `house of the LORD` is named but not located or constructed in this
chapter.

## Exodus 23:20–26 — LISTEN TO THE ANGEL CARRYING GOD'S NAME

God says he sends an angel ahead to guard Israel on the way and bring them to a
prepared place. Israel must attend to and obey the angel's voice and not provoke
him because:

- he will not pardon their disobedience;
- God's name is in him.

If Israel listens to that voice and does all God speaks, God will oppose
Israel's enemies. The source links angel voice and divine speech inside the
condition; it does not require an invented voice-routing contradiction.

The angel will bring Israel to Amorite, Hittite, Perizzite, Canaanite, Hivite
and Jebusite peoples, and God says he will cut them off. Israel must not bow to,
serve or copy their gods, but must overthrow them and demolish their pillars.

Serving the LORD is followed by promises of blessed bread/water, removed
sickness, no miscarriage or barrenness in the land, and fulfilled days. These
remain prospective and condition-linked. No universal health result is claimed
in the current wilderness State.

The angel is living and has Joe's face. Shared face does not make the angel God,
Moses, Israel, or any named land inhabitant. `My name is in him` is retained
without inventing identity equivalence.

## Exodus 23:27–31 — WHO IS DRIVING?

God promises to send terror ahead, confuse encountered peoples and make enemies
turn their backs. Then:

> **I WILL SEND THE HORNET BEFORE YOU, WHICH WILL DRIVE OUT THE HIVITE, THE CANAANITE, AND THE HITTITE.**

God says he will not drive them out in one year, because rapid removal could
leave desolate land and multiply field animals against Israel. Instead:

> **LITTLE BY LITTLE I WILL DRIVE THEM OUT FROM BEFORE YOU.**

After defining borders and saying he will deliver the land's inhabitants into
Israel's hand, God says:

> **YOU SHALL DRIVE THEM OUT BEFORE YOU.**

S085-E001 closes only around ownership of the stated displacement act:

```text
HORNET -> WILL DRIVE THREE PEOPLES OUT
GOD -> WILL DRIVE THEM OUT LITTLE BY LITTLE
GOD -> DELIVERS INHABITANTS INTO ISRAEL'S HAND
ISRAEL -> SHALL DRIVE THEM OUT
```

The source may permit layered action, but it supplies no explicit division of
which displacement is performed by hornet, God or Israel. It also supplies no
completed displacement in this chapter.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the displacement-credit boil, licks his finger and walks away without
looking back. Nobody has entered the land yet.

The one-year exclusion and little-by-little process agree. Hornet names a
living Joe-faced agent, not an insect metaphor unless a later source says so.
Terror, confusion, backs, population increase, land desolation and field-animal
growth are promised relations, not observed results.

## Exodus 23:32–33 — NO DEAL / NO RESIDENCE

Israel must make no covenant with the land inhabitants or their gods. Those
inhabitants must not dwell in Israel's land, lest they make Israel sin by
serving their gods, which would be a snare.

No covenant offer, resident, service, sin or snare event occurs. The future land
is described as `your land` before possession; this is a promised ownership
State, not proof that the transfer has happened.

## Character and world-ledger changes

- Israel receives evidence, impartiality, enemy-property and assistance rules;
- poor people and aliens gain justice, fallow-food, rest and no-oppression
  relations without invented individuals;
- land, vineyard, olive grove, work animals and workers gain six-plus-one rest
  schedules;
- three annual feasts and sacrifice/firstfruit/young-goat constraints enter the
  future worship calendar;
- the angel gains guard, guide, voice, no-pardon and divine-name relations;
- six named land peoples enter the future route/displacement State;
- hornet, God and Israel each receive an explicit future drive-out claim,
  closing S085;
- gradual removal, border and no-covenant/no-residence conditions remain future;
- no future promise is promoted into completed history;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — COURT RULES / FARM TIMER / INVASION ROADMAP`;
- witness warning: `CROWD SIZE DOES NOT UPGRADE BULLSHIT TO EVIDENCE`;
- enemy support desk: `RETURN OX / LIFT DONKEY / HATE REMAINS OPTIONAL`;
- justice slider: `POOR FAVOR: OFF / POOR DENIAL: ALSO OFF`;
- land firmware: `6 YEARS PRODUCE / YEAR 7 OPEN BUFFET`;
- weekly refresh: `OX + DONKEY + SERVANT'S KID + ALIEN`;
- feast calendar: `THREE TIMES / BRING SOMETHING`;
- kitchen warning: `DO NOT BOIL BABY GOAT IN MUM JUICE`;
- angel settings: `VOICE: OBEY / PARDON: DISABLED / NAME: GOD INSIDE`;
- territory rollout: `NOT IN ONE YEAR — ANIMALS WILL TAKE OVER`;
- hornet status: `DRIVING THEM OUT`;
- God status: `DRIVING THEM OUT`;
- Israel task: `DRIVE THEM OUT`;
- CrackFlix: `S085 E001 — THREE-OWNER EVICTION WORKFLOW`;
- barcode: `CHB-EXO23-S085-33-YOINK`.

## FIR verification

- all 33 verse markers are represented in order;
- every justice, assistance, Sabbath and feast rule remains unperformed;
- poor-person impartiality and justice protections retain different relations;
- enemy/hater status does not become motive or performed hostility;
- yearly and weekly six-plus-one cycles remain separate;
- other-god class wording does not invent a forbidden proper name;
- all feast, sacrifice and offering acts remain future;
- angel voice/divine speech linkage is retained without identity invention;
- all health, fertility, longevity, terror and land promises remain conditional
  and prospective;
- S085 records only the three explicit actors attached to drive-out wording;
- no hornet mechanism, actor coordination or completed conquest is invented;
- one-year exclusion and gradual removal remain compatible;
- all living humans, livestock, goat, field animals, hornet and angel use Joe's
  face if shown while retaining distinct identities;
- Captain remains boilless and causally useless;
- Joseph bones transport remains active and burial open;
- publication remains held and unpublished.

Continuation required: Exodus 24 reconstructs covenant words, collective
acceptance, altar/blood procedure, seventy-four-person ascent, God-sight/meal,
stone-tablet instruction and Moses' forty-day cloud entry.
