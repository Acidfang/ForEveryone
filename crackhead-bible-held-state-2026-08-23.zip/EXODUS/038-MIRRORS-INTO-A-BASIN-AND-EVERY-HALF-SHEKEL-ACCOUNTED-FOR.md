# CRACKHEAD EXODUS 38

## Title page

**MIRRORS INTO A BASIN.**

**603,550 JOES. HALF A SHEKEL EACH. RECEIPTS INCLUDED.**

Source parent: Exodus chapter 38, verses 1–31, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-EXO-038/job.json` and `source.usfm`.

Parent manuscript: `EXODUS/037-TWO-GOLD-CHERUBIM-AND-THE-FORBIDDEN-OIL-ACTUALLY-MADE.md`.

CrackFlix routing: none. No completed observable contradiction occurs.

## Causal foundation

```text
BRONZE ALTAR + TOOLS + POLES MADE
-> WOMEN'S MIRRORS BECOME BRONZE BASIN + BASE
-> COURT + GATE + PINS MADE
-> MATERIALS COUNTED UNDER MOSES / LEVITES / ITHAMAR
-> BEZALEL AND OHOLIAB NAMED IN WORK ACCOUNT
-> GOLD / SILVER / BRONZE TOTALS RECORDED
-> HALF-SHEKEL SILVER LINKED TO 603,550 COUNTED MEN
-> SILVER AND BRONZE LINKED TO FINISHED COMPONENTS
-> CONSTRUCTION ACCOUNT EXISTS
```

## Exodus 38:1–7 — BRONZE BURNT-OFFERING ALTAR

The maker constructs a square acacia altar five cubits by five and three cubits
high. Its four horns are one piece with it and the whole is overlaid with
bronze. Bronze pots, shovels, basins, forks and fire pans are made with a bronze
network grate reaching halfway up. Four rings receive bronze-overlaid acacia
poles. The poles are inserted for carrying. The altar is hollow and plank-made.

No offering, fire, blood, carrying or service occurs.

## Exodus 38:8 — MIRROR BASIN

The bronze basin and bronze base are made from mirrors belonging to ministering
women assembled at the Tent of Meeting door. The women are living Joes and use
Joe's face. The source records their ministry and the conversion of the mirrors
into the basin; it does not state who transferred each mirror, what their
ministry comprised, or whether this Tent is identical to the presently active
outside-camp Tent.

No washing occurs.

## Exodus 38:9–20 — COURT

The maker constructs the linen court: one hundred cubits on south and north,
fifty on west and east. South and north each have twenty pillars and twenty
bronze sockets. West has ten and ten. The east gate is flanked by two
fifteen-cubit, three-pillar sections.

Court hangings are fine twined linen. Pillar hooks, fillets, bands and capital
overlay are silver; sockets are bronze. The embroidered gate screen is blue,
purple, scarlet and fine twined linen, twenty cubits long and five high, with
four pillars and four bronze sockets. Every Tabernacle and court pin is bronze.

No final erection, location survey, entry or court service occurs.

## Exodus 38:21–23 — WHO COUNTED AND WHO MADE

The material account is counted at Moses' command for Levite service under
Ithamar son of Aaron the priest. Bezalel son of Uri son of Hur of Judah is
credited with making all the LORD commanded Moses. Oholiab son of Ahisamach of
Dan is with him as engraver, skilled worker and blue/purple/scarlet/fine-linen
embroiderer.

This expands the retained work account; it does not erase the collective
workers already observed making components, prove Bezalel performed every hand
act exclusively, or prove a same-name Hur identity.

## Exodus 38:24–31 — MATERIAL LEDGER

The sanctuary work uses twenty-nine talents and seven hundred thirty sanctuary
shekels of offered gold.

Counted-congregation silver is one hundred talents plus one thousand seven
hundred seventy-five sanctuary shekels. Every counted man aged twenty and over
pays one beka—half a shekel—and the count is 603,550. The one hundred talents
become one hundred sanctuary/veil sockets, one talent per socket. The remaining
1,775 shekels become pillar hooks, capital overlay and fillets.

Offered bronze totals seventy talents plus 2,400 shekels. It becomes Tent-door
sockets, the bronze altar and grate, altar vessels, court/gate sockets, and all
Tabernacle/court pins.

The arithmetic relation is retained as the source's account. The chapter does
not supply modern precision beyond its own footnotes, individual payer names,
individual gold/bronze contributors, waste, leftovers or an independent audit.

## Character and world-ledger changes

- burnt-offering altar, tools, grate and installed carrying poles become
  completed but unused;
- ministering women are observed assembled at the Tent door, and their mirrors
  are observed as the material source of the completed basin/base;
- the linen court, embroidered gate and bronze pins become completed but not
  erected or used;
- Ithamar gains an explicit material-account oversight role under Moses'
  command and Levite service;
- Bezalel receives whole-command work credit while Oholiab's named craft role
  and the previously observed worker collective remain intact;
- the equal half-shekel command from Exodus 30 becomes performed for 603,550
  counted men aged twenty and over;
- exact offered gold, counted silver and offered bronze totals are recorded and
  silver/bronze are linked to named outputs;
- no contradiction, SKIP, crack or Captain appearance occurs;
- placement, erection, washing, offering and service remain future;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — DEPARTMENT OF RECEIPTS`;
- altar plate: `5x5x3 / HOLLOW / BRONZE / FIRE NULL`;
- mirror bin: `REFLECTIONS IN / WASH BASIN OUT`;
- court sign: `FINE LINEN PERIMETER / BRONZE FEET / SILVER BITS`;
- accounting terminal: `COMMAND: MOSES / SERVICE: LEVITES / HAND: ITHAMAR`;
- silver register: `603,550 x HALF-SHEKEL / EVERY JOE SAME PRICE`;
- socket printer: `100 TALENTS -> 100 SOCKETS / VERY SUBTLE`;
- audit stamp: `GOLD 29T+730 / SILVER 100T+1775 / BRONZE 70T+2400`;
- barcode: `CHB-EXO38-31-NOCRACK-RECEIPTS-HELD`.

## FIR verification

- all 31 verse markers are represented in order;
- every altar dimension, material, tool, grate, ring, pole and hollow-plank
  relation is retained;
- the mirrors remain attributed to the ministering women and their unspecified
  ministry/transfer is not invented;
- outside-camp Tent and construction-context Tent identity is not silently
  merged;
- every court dimension, count and material relation is retained;
- Moses-command, Levite-service and Ithamar-hand relations remain distinct;
- Bezalel's whole-work credit does not erase Oholiab or collective worker acts;
- gold, silver, bronze, count, half-shekel and output allocations are retained;
- source accounting is not upgraded into an independently verified external
  fact;
- completed parts do not become erected, washed in, sacrificed on or serviced;
- no unsupported contradiction is manufactured, so Captain does not appear;
- every living being and interpreted face uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Exodus 39 reconstructs priestly garments, inscribed
gold plate and completion/inspection of the commanded work.
