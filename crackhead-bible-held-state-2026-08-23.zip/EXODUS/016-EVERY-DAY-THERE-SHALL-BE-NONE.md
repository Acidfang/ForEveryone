# CRACKHEAD EXODUS 16

## Title page

**GATHER A DAY'S PORTION EVERY DAY.**

**ON THE SEVENTH DAY THERE SHALL BE NONE.**

Source parent: Exodus chapter 16, verses 1–36, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 16.

Prepared evidence: `.chapter-work/CHB-EXO-016/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/015-YOU-HAVE-GUIDED-THEM-THERE-YOU-WILL-BRING-THEM-THERE.md`.

CrackFlix routing:

- new `S074-E001-EXO16 — EVERY DAY / NO SEVENTH DAY`;
- new `S075-E001-EXO16 — LET NO ONE LEAVE IT / SOME LEFT IT`.

## Causal foundation

```text
ELIM -> WILDERNESS OF SIN / SECOND MONTH DAY 15
-> WHOLE CONGREGATION MURMURS AGAINST MOSES + AARON
-> ISRAEL SPEECH: EGYPT DEATH / MEAT POTS / FULL BREAD / WILDERNESS HUNGER-DEATH
-> LORD: RAIN BREAD / GATHER DAY'S PORTION EVERY DAY / TEST LAW
-> SIXTH DAY: TWICE DAILY AMOUNT
-> MOSES + AARON ANNOUNCE EVENING MEAT / MORNING BREAD / LORD HEARD
-> CONGREGATION APPROACHES / GLORY APPEARS IN CLOUD
-> LORD DIRECTLY CONFIRMS EVENING MEAT / MORNING BREAD
-> EVENING QUAIL COVER CAMP
-> MORNING DEW -> SMALL ROUND THING
-> PEOPLE: WHAT IS IT? / MOSES: LORD'S BREAD
-> OMER PER HEAD / MORE-LESS GATHERED / MEASURED NO EXCESS-NO LACK
-> MOSES: LET NO ONE LEAVE IT UNTIL MORNING
-> SOME LEAVE IT / WORMS + FOUL / MOSES ANGRY
-> DAILY MORNING GATHER / HOT SUN MELTS IT
-> SIXTH DAY DOUBLE / RULERS REPORT
-> MOSES: SABBATH / STORE REMAINDER OVERNIGHT
-> STORED FOOD DOES NOT FOUL / NO WORMS
-> SIX DAYS GATHER / SEVENTH DAY NONE
-> SOME GO TO GATHER / FIND NONE
-> LORD: HOW LONG REFUSE COMMANDMENTS? / STAY IN PLACE
-> PEOPLE REST SEVENTH DAY
-> HOUSE NAMES IT MANNA / DESCRIPTION + TASTE
-> OMER KEPT FOR GENERATIONS / AARON PUTS BEFORE TESTIMONY
-> NARRATOR JUMPS: ISRAEL EATS MANNA 40 YEARS TO CANAAN BORDER
-> OMER = ONE TENTH EPHAH
```

## Exodus 16:1–3 — THE EGYPT DINNER REVIEW

All Israel's congregation leaves Elim and reaches the wilderness of Sin,
between Elim and Sinai, on the fifteenth day of the second month after leaving
Egypt.

The whole congregation murmurs against Moses and Aaron. Israel says it wishes
it had died by the LORD's hand in Egypt while sitting by meat pots and eating
bread to the full. It says Moses and Aaron brought the assembly into the
wilderness to kill it with hunger.

Those are current collective statements. The retained Egypt chapters do not
independently narrate this meat-pot/full-bread scene, and the present chapter
does not complete the predicted whole-assembly hunger death. No memory motive,
sarcasm or actual murder plan is supplied.

## Exodus 16:4–12 — EVERY DAY BEGINS

The LORD tells Moses:

> **I WILL RAIN BREAD FROM THE SKY FOR YOU.**

> **THE PEOPLE SHALL GO OUT AND GATHER A DAY'S PORTION EVERY DAY.**

The stated operation tests whether they will walk in the LORD's law. The very
next instruction says the sixth-day preparation will be twice the daily
gathering. That is an explicit sixth-day modification, not yet a contradiction
with the everyday collection because the seven-day boundary has not completed.

Moses and Aaron tell Israel that evening will establish that the LORD brought
them out of Egypt, and morning will show the LORD's glory because the LORD has
heard their murmurings. Moses says the murmuring addressed to them is against
the LORD, not them. This is Moses' stated routing of the complaint; it does not
erase that verse 2 also records the people murmuring against Moses and Aaron.

Aaron calls the congregation close. They look toward the wilderness, and the
LORD's glory appears in the cloud. The LORD directly says he heard the
murmuring and orders the message: evening meat, morning bread, then knowledge
that he is their God.

## Exodus 16:13–18 — WHAT IS IT?

Quail come in the evening and cover the camp. In the morning dew lies around
the camp. When it is gone, a small round frost-like thing remains on the
wilderness surface.

Israel sees it and asks one another:

> **WHAT IS IT?**

They do not know what it is. Moses identifies it as the bread the LORD has
given them to eat and relays the collection command: one omer per head,
according to each person's eating and the number in each tent.

Some gather more and some less. When measured by an omer, the much-gatherer has
nothing over and the little-gatherer has no lack. The source states the measured
result; it does not supply a transfer actor, volume-change mechanism or
individual collection table.

## Exodus 16:19–21 — DON'T KEEP IT / THEY KEEP IT

Moses says:

> **LET NO ONE LEAVE ANY OF IT UNTIL THE MORNING.**

Some do not listen. They leave some until morning. It breeds worms and becomes
foul. Moses is angry with them.

S075-E001 closes at the performed opposite act:

```text
UNIVERSAL INSTRUCTION: NO ONE LEAVES IT OVERNIGHT
-> SOME RECIPIENTS LEAVE IT OVERNIGHT
-> FOOD BREEDS WORMS / BECOMES FOUL
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the rule-breaking boil, licks his finger and walks away without
looking back. The worms, smell, anger and following collection schedule remain
unchanged.

Morning by morning, each person gathers according to eating. When the sun gets
hot, the remaining surface food melts.

## Exodus 16:22–24 — THIS TIME, KEEP IT

On the sixth day the people gather two omers per person. Congregation rulers
report the double amount to Moses.

Moses identifies the next day as a solemn rest and holy Sabbath to the LORD.
They may bake or boil the food and must lay the remainder up until morning.
They do so. This time it does not become foul and has no worms.

The overnight act now has an explicitly changed day, quantity and instruction:

```text
ORDINARY-DAY RETENTION AGAINST INSTRUCTION -> WORMS + FOUL
SIXTH-TO-SABBATH RETENTION UNDER INSTRUCTION -> NO WORMS / NOT FOUL
```

That is an observable conditional food State, not a same-boundary
contradiction. No preservation chemistry is invented.

## Exodus 16:25–30 — EVERY DAY ENDS

Moses says to eat the stored portion because it is Sabbath. He says none will
be found in the field that day:

> **SIX DAYS YOU SHALL GATHER IT.**

> **ON THE SEVENTH DAY IS THE SABBATH. IN IT THERE SHALL BE NONE.**

This completes S074-E001 against the LORD's earlier `EVERY DAY` collection
instruction:

```text
LORD: GATHER A DAY'S PORTION EVERY DAY
-> SIXTH DAY DOUBLE
-> MOSES' LORD-RULE: GATHER SIX DAYS
-> SEVENTH DAY: THERE SHALL BE NONE
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the calendar boil, licks his finger and walks away without looking
back. Day seven remains day seven and still contains no manna.

Some people go out to gather on the seventh day and find none. The LORD asks
Moses how long `you` refuse to keep his commandments and laws, states the
sixth-day two-day bread provision, and orders everyone to remain in place on
the seventh day. The people then rest.

The attempted collection does not contradict `THERE SHALL BE NONE`; finding
none confirms it. The plural blame is retained exactly as direct speech without
inventing whether `you` addresses Moses, the whole people or only the subset.

## Exodus 16:31 — MANNA

The house of Israel names the substance `Manna`. The source note links the word
to `What is it?` It is described as white coriander seed and as tasting like
honey wafers.

This closes the naming State; it does not retroactively make the people know
the object before asking.

## Exodus 16:32–34 — THE POT AND THE TESTIMONY

Moses relays a LORD command to preserve an omer throughout the generations so
later people may see the wilderness bread. Moses tells Aaron to put an
omer-full in a pot and lay it before the LORD. Aaron lays it before the
Testimony to be kept.

`THE TESTIMONY` is named here without this chapter narrating its construction,
arrival or location. The pot placement is retained as a source act; no missing
container system or timeline is invented. Its non-spoilage duration is not
explicitly measured here.

## Exodus 16:35–36 — FORTY YEARS IN ONE VERSE

The narrator states that Israel ate manna for forty years, until reaching an
inhabited land and the borders of Canaan. This is a future-duration summary
relative to the current wilderness-of-Sin sequence. It does not teleport the
next chapter's active Israel State to Canaan or silently complete every event
between.

The source defines one omer as one tenth of an ephah. That measurement relation
is retained. The translation's approximate modern-unit footnotes remain source
notes rather than new narrative objects.

Joseph's bones remain in transport. The forty-year summary neither names their
carrier nor closes their burial.

## Character and world-ledger changes

- Israel moves Elim to the wilderness of Sin and receives a dated second-month
  State;
- whole-congregation murmuring and Egypt meat-pot/full-bread/hunger-death speech
  remain attributed;
- LORD, Moses and Aaron establish the manna test, daily amount, sixth-day double
  and seventh-day rest relations;
- S074 records `EVERY DAY / NO SEVENTH DAY`;
- S075 records instruction against overnight retention followed by some people
  retaining it;
- quail, dew, manna, omer measurement, heat melting and conditional overnight
  preservation enter inventory;
- the house of Israel names manna; no individual namer is invented;
- Aaron receives and places the generational omer pot before the Testimony;
- `Testimony` enters as a named but not yet constructed/provenanced object;
- the narrator preserves a separate forty-year manna-duration summary without
  overwriting the active Exodus 16 camp chronology;
- Joseph's bones remain moving; burial stays open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — SIN WILDERNESS CATERING DIVISION`;
- complaint menu: `EGYPT MEAT POT / ALL-YOU-CAN-EAT MEMORY SPECIAL`;
- sky printer: `CRACKHEAD DAILY BREAD DISPENSER — TEST MODE`;
- collection terminal: `MORE IN / LESS IN / ONE OMER OUT`;
- spoilage label: `DO NOT STORE — EXCEPT WHEN TOLD TO STORE`;
- worms: living Joe-faced `MORNING QUALITY INSPECTORS`;
- Sabbath screen: `EVERY DAY™ — AVAILABLE SIX DAYS`;
- CrackFlix: `S074 E001 — CALENDAR TERMS AND CONDITIONS`;
- mystery-food package: `MANNA: WHAT IS IT? YES.`;
- evidence pot: `GENERATIONS DISPLAY SAMPLE / TESTIMONY ADDRESS PENDING`;
- continuity warning: `FORTY YEARS SHOWN / NEXT CHAPTER STILL NEXT DAY-CHAIN`;
- barcode: `CHB-EXO16-S074-S075-36-YOINK-YOINK`.

## FIR verification

- all 36 verse markers are represented in order;
- Israel's Egypt-food and hunger-death claims remain attributed speech;
- direct LORD speech, Moses/Aaron relays and narrator acts remain distinct;
- S074 closes only after every-day and seventh-day-none States both exist;
- S075 closes only after the prohibited overnight retention is performed;
- the sixth/Sabbath preservation exception retains its changed condition and is
  not manufactured into a contradiction;
- seventh-day attempted gathering confirms rather than contradicts no manna;
- `you refuse` retains its unresolved plural address;
- measured manna equality has no invented redistribution mechanism;
- Testimony provenance remains unresolved;
- forty-year summary does not overwrite the active chapter-to-chapter Moment;
- all living quail, worms and people are Joe-faced; nonliving manna may receive
  Joe face only through visual face interpretation;
- Captain remains boilless and causally useless;
- Joseph bones transport remains active and burial open;
- publication remains held and unpublished.

Continuation required: Exodus 17 reconstructs Rephidim water conflict, rock
water sequence, Massah/Meribah naming, Amalek battle, raised-hand outcome and
the memorial/altar relations.
