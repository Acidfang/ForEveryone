# CRACKHEAD EXODUS 36

## Title page

**STOP BRINGING STUFF.**

**WE HAVE TOO MUCH.**

Source parent: Exodus chapter 36, verses 1–38, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-EXO-036/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/035-WHOEVER-IS-WILLING-BRING-IT-THEY-BROUGHT-IT.md`.

CrackFlix routing:

- `S086-E003-EXO36 — CHERUB CURTAINS AND VEIL ACTUALLY MADE`;
- `SKIP -> S086-E002-EXO26` omits the already-retained command-layer
  explanation and changes nothing.

## Causal foundation

```text
WORKERS CALLED
-> OFFERINGS TRANSFERRED FROM MOSES TO WORKERS
-> PEOPLE CONTINUE BRINGING EVERY MORNING
-> WORKERS REPORT MORE THAN ENOUGH
-> MOSES ORDERS CAMP-WIDE STOP
-> PEOPLE RESTRAINED FROM BRINGING
-> MATERIAL CONFIRMED SUFFICIENT + EXCESS
-> TEN CHERUB CURTAINS MADE AND COUPLED
-> ELEVEN GOAT-HAIR CURTAINS + TWO HIDE COVERINGS MADE
-> ACACIA BOARD/SOCKET/BAR FRAME MADE
-> CHERUB VEIL + PILLARS/SOCKETS MADE
-> EMBROIDERED DOOR SCREEN + PILLARS/SOCKETS MADE
-> ARK/FURNITURE/ALTARS/COURT/GARMENTS STILL NOT MADE HERE
```

## Exodus 36:1–7 — PLEASE STOP DONATING

Bezalel, Oholiab and every wise-hearted worker described as receiving divine
wisdom/understanding are assigned the sanctuary work. Moses calls them and all
whose hearts are described as stirred to come and work. They receive from Moses
the offerings Israel brought. People continue bringing freewill offerings every
morning.

Workers leave their respective work and tell Moses the people have brought much
more than enough. Moses orders a camp-wide proclamation that no man or woman
make anything else for the sanctuary offering. The people are restrained from
bringing. The narrator confirms the material is sufficient for all the work and
too much.

This is not a contradiction between `bring` and `stop bringing`. Sufficiency is
the explicit changed condition. No contributor is punished, rejected by name or
shown attempting to violate the stop.

## Exodus 36:8–13 — TEN CHERUB CURTAINS

The wise-hearted workers make ten equal curtains from fine twined linen, blue,
purple and scarlet, with skill-work cherubim. Each is twenty-eight by four
cubits. Five are coupled together and the other five together. Fifty opposing
blue loops and fifty gold clasps join them so the Tabernacle fabric becomes one
unit.

The broad no-image rule and commanded cherub fabrication were already retained
as S086. Here manufacture finally occurs.

Captain presses:

> **SKIP -> S086-E002**

His eyes glaze. The workers keep weaving every cherub. SKIP does nothing.

When the performed image manufacture completes, S086-E003 closes.

Captain Crackhead: **YOINK!**

He pokes the textile-cherub boil, licks his finger and walks away without
looking back. The coupled curtains remain a unit.

## Exodus 36:14–19 — ELEVEN MORE CURTAINS AND TWO SKINS

Eleven equal goat-hair curtains, each thirty by four cubits, form the covering.
Five and six are coupled separately; fifty opposing loops and fifty bronze
clasps join the tent as one unit. A red-dyed ram-skin covering and a sea-cow-hide
covering are made above it.

The living goats, rams and sea cows retain Joe faces in any depicted source
scene. The processed materials are not living characters.

## Exodus 36:20–34 — BOARDS, SOCKETS, BARS, GOLD

Workers make upright acacia boards, each ten by one-and-a-half cubits with two
joined tenons:

- twenty south boards over forty silver sockets;
- twenty north boards over forty silver sockets;
- six west/rear boards plus two corner boards;
- the eight rear boards stand over sixteen silver sockets.

They make five bars for each side/rear set, including the middle bar passing end
to end. Boards and bars are overlaid with gold; gold rings receive the bars.

The source narrates fabrication, not final site erection, load testing,
transport, alignment tolerance or occupation.

## Exodus 36:35–38 — VEIL AND DOOR SCREEN

Workers make the blue/purple/scarlet/fine-linen skill-work veil with cherubim.
Four gold-overlaid acacia pillars, gold hooks and four cast silver sockets serve
it. This second performed cherub-image object remains inside S086-E003 rather
than becoming a duplicate episode.

They make an embroidered blue/purple/scarlet/fine-linen tent-door screen and
five pillars/hooks. Pillar capitals and fillets are gold-overlaid; the five
sockets are bronze.

## Character and world-ledger changes

- Bezalel, Oholiab and wise-hearted workers advance from attributed readiness to
  called, material-receiving, actually working builders;
- workers report material excess to Moses;
- Moses issues a stop command and the people stop bringing;
- contribution sufficiency changes from unresolved to confirmed sufficient and
  excessive;
- curtain, covering, board/socket/bar frame, veil and door-screen components
  become completed objects;
- the fabric Tabernacle and goat-hair tent are each coupled as a unit;
- S086 gains a performed third episode with exact SKIP pointer to E002;
- ark, furniture, altars, basin, court and priest garments remain unbuilt here;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — DONATION BUFFER OVERFLOW`;
- morning queue: `FREEWILL INPUT STILL ARRIVING`;
- worker ticket: `MORE THAN ENOUGH / PLEASE DISABLE USERS`;
- camp alert: `STOP MAKING OFFERING STUFF`;
- inventory status: `SUFFICIENT + TOO MUCH`;
- CrackFlix: `SKIP -> S086-E002 / LOOM CONTINUES`;
- fabric build: `10 CURTAINS + 100 LOOPS + 50 GOLD CLASPS = ONE`;
- roof build: `11 GOAT CURTAINS + 100 LOOPS + 50 BRONZE CLASPS = ONE`;
- wall build: `48 BOARDS / 96 SILVER SOCKETS / GOLD EVERYTHING ELSE`;
- door mode: `VEIL CHERUB / FRONT EMBROIDERED`;
- barcode: `CHB-EXO36-S086-E003-38-SKIP-YOINK`.

## FIR verification

- all 38 verse markers are represented in order;
- worker wisdom/heart State remains attributed while calling, receiving,
  reporting and fabrication are observed;
- continued offering and stopping offering are separated by confirmed excess;
- no contradiction is manufactured from that changed condition;
- exact curtain/loop/clasp/board/socket/bar/pillar counts and dimensions are
  retained;
- S086-E003 is new because commanded cherub objects are now actually made;
- SKIP points exactly to S086-E002, omits explanation only and changes nothing;
- curtain and veil cherub fabrication share one occurrence/work phase rather
  than duplicating episodes;
- completed structural/textile components do not become a completed furnished
  or erected sanctuary;
- worker identity remains collective where the source uses `he/they` without a
  named allocation;
- Captain says exactly `YOINK!`, has no boils and affects nothing;
- all living beings/material-source organisms use Joe face if shown;
- publication remains held and unpublished.

Continuation required: Exodus 37 reconstructs the ark, mercy seat/cherubim,
table, lampstand, incense altar, anointing oil and incense manufacture.
