# CRACKHEAD EXODUS 33

## Title page

**THE LORD SPOKE TO MOSES FACE TO FACE.**

**YOU CANNOT SEE MY FACE AND LIVE.**

Source parent: Exodus chapter 33, verses 1–23, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 33.

Prepared evidence: `.chapter-work/CHB-EXO-033/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/032-I-MADE-IT-WITH-A-TOOL-OUT-CAME-THIS-CALF.md`.

CrackFlix routing:

- `S094-E001-EXO33 — I WILL NOT GO / MY PRESENCE WILL GO`;
- `S095-E001-EXO33 — FACE TO FACE / FACE CANNOT BE SEEN`.

No SKIP is valid: both exact contradiction types are new.

## Causal foundation

```text
LORD ORDERS MOSES + PEOPLE TO DEPART
-> ANGEL PROMISED BEFORE THEM
-> SIX PEOPLES PROMISED DRIVEN OUT
-> LORD SAYS HE WILL NOT GO AMONG ISRAEL
-> PEOPLE HEAR / MOURN / REMOVE JEWELRY
-> MOSES USES OUTSIDE-CAMP TENT OF MEETING
-> PEOPLE WATCH / CLOUD DESCENDS / LORD SPEAKS
-> LORD SPEAKS TO MOSES FACE TO FACE
-> MOSES REQUESTS KNOWN COMPANION / WAY / PRESENCE
-> LORD SAYS PRESENCE WILL GO + REST
-> MOSES REQUIRES PRESENCE FOR DEPARTURE/DISTINCTION
-> LORD AGREES BECAUSE FAVOR + NAME-KNOWLEDGE
-> MOSES REQUESTS GLORY
-> LORD PROMISES GOODNESS + NAME PROCLAMATION
-> LORD SAYS FACE CANNOT BE SEEN BY LIVING MAN
-> ROCK/CLEFT/HAND/BACK/FACE VIEWING PROCEDURE PROMISED
```

## Exodus 33:1–6 — GO WITHOUT ME

The LORD tells Moses to depart with the people whom Moses brought from Egypt
toward the land sworn to Abraham, Isaac and Jacob. God promises to send an
angel before them and drive out Canaanite, Amorite, Hittite, Perizzite, Hivite
and Jebusite Joes. The destination is called a land flowing with milk and
honey.

God says he will not go up among the people because they are stiff-necked and
he might consume them on the way. The people hear this evil news, mourn and do
not put on jewelry. God tells Moses to have Israel remove jewelry so God may
know what to do to them. Israel strips off jewelry from Horeb onward.

The chapter supplies removal, not disposal, ownership transfer or destruction.
The knowledge wording is direct divine speech; no omniscience axiom is imported
to manufacture another contradiction.

## Exodus 33:7–11 — THE OUTSIDE TENT

Moses used to take a tent and pitch it far outside camp, calling it the Tent of
Meeting. Everyone seeking the LORD went outside to it. This tent is currently
operational; it is not silently merged with the still-unbuilt commanded
Tabernacle inventory.

When Moses goes to the Tent, all people rise at their own tent doors and watch
until he enters. The cloud pillar descends, stands at the Tent door and the LORD
speaks with Moses. The people see the pillar, rise and worship from their doors.

The LORD speaks to Moses `face to face, as a man speaks to his friend`. Moses
returns to camp. Joshua son of Nun, explicitly a young man and Moses' servant,
does not depart from the Tent.

## Exodus 33:12–17 — I WILL NOT GO / I WILL GO

Moses says God ordered him to bring up the people but has not made known whom
he will send with him. Earlier `an angel` supplies a role but not an individual
identity, so Moses' `whom` statement is not rewritten into a false contradiction.

Moses quotes God as knowing him by name and saying he found favor. He asks to
be shown God's way so he may know God and continue finding favor, and asks God
to consider the nation God's people.

God answers:

> **MY PRESENCE WILL GO WITH YOU.**

> **I WILL GIVE YOU REST.**

Moses says that if God's presence does not go, God should not carry them from
there. He says presence with them is how his and the people's favor and
separation from all earth's peoples would be known. God agrees to do the thing
Moses spoke, because Moses found favor and is known by name.

S094-E001 closes on the changed announced escort State:

```text
LORD: I WILL NOT GO UP AMONG YOU
-> PEOPLE MOURN / REMOVE JEWELRY
-> MOSES REQUESTS WAY + PRESENCE
-> LORD: MY PRESENCE WILL GO WITH YOU
```

The dialogue supplies an intervening appeal and changed answer. It does not
supply a hidden mechanism that makes `will not go` and `will go` the same
State.

Captain Crackhead: **YOINK!**

He pokes the presence-revision boil, licks his finger and walks away without
looking back. The promised journey remains unperformed.

## Exodus 33:18–23 — FACE TO FACE / NO FACE

Moses asks to see God's glory. God says all goodness will pass before Moses,
the LORD's name will be proclaimed, and grace and mercy will be assigned to
whom God chooses.

God then says:

> **YOU CANNOT SEE MY FACE.**

> **MAN MAY NOT SEE ME AND LIVE.**

The retained current chapter already states that the LORD spoke with Moses
`face to face`, and Moses remains alive. S095-E001 closes at that wording
boundary. No idiom, anatomy, vision theory, translation repair or doctrinal
distinction is supplied by the chapter.

God describes a future viewing procedure: Moses will stand on a rock; when
glory passes, God will place Moses in a rock cleft, cover him with God's hand,
then remove the hand so Moses sees God's back but not God's face. None of this
procedure occurs yet.

*shrug*

Crack.

Captain Crackhead: **YOINK!**

He pokes the face-to-face boil, licks his finger and walks away without looking
back. Moses remains alive and the promised glory pass remains future.

## Character and world-ledger changes

- Moses gains an outside-camp Tent practice, direct cloud-door conversations,
  return-to-camp movement, presence/way/glory requests and future rock-cleft
  viewing instructions;
- Joshua is explicitly son of Nun, young, Moses' servant and continuously
  present at the Tent when Moses returns to camp;
- Israel mourns, leaves jewelry off, strips jewelry from Horeb onward, watches
  Moses and worships at individual tent doors;
- the outside-camp Tent of Meeting remains distinct from the unbuilt sanctuary;
- the cloud pillar visibly descends and stands at the Tent door;
- the angel remains future and individually unidentified;
- six named land peoples remain future displacement targets;
- S094 records the changed no-presence/presence escort announcement;
- S095 records face-to-face speech against lethal face visibility;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — ESCORT PACKAGE SUBJECT TO MOSES`;
- route notice: `DEPART HERE / MILK + HONEY / SIX TENANTS PENDING`;
- service tier: `ANGEL BEFORE YOU / IDENTITY NULL`;
- warning: `GOD AMONG USERS MAY CONSUME USERS`;
- jewelry mode: `HOREB ONWARD: ACCESSORIES DISABLED`;
- Tent label: `CRACKHEAD MEETING TENT / OUTSIDE CAMP / NOT THE OTHER ONE`;
- cloud status: `DOOR CONNECTION ACTIVE`;
- CrackFlix: `S094 E001 — PRESENCE PLAN REVISED LIVE`;
- CrackFlix: `S095 E001 — FACE MODE / DO NOT VIEW FACE`;
- rock procedure: `CLEFT + HAND + BACK VIEW / EXECUTION PENDING`;
- barcode: `CHB-EXO33-S094-S095-23-2YOINK`.

## FIR verification

- all 23 verse markers are represented in order;
- departure, angel, displacement and land promises remain future;
- divine threat/knowledge/favor/grace/mercy claims remain attributed speech;
- observed mourning, jewelry removal, Tent movement, cloud descent, watching
  and worship are not expanded with motives;
- the current outside-camp Tent is not merged with the unbuilt Tabernacle;
- `an angel` does not become a known individual identity;
- S094 retains the intervening Moses requests and changed answer rather than
  pretending the two statements are simultaneous;
- S095 uses the source's exact face wording and observed continued life without
  importing an idiomatic or theological repair;
- future goodness/name/glory/rock/cleft/hand/back procedure is not marked done;
- no SKIP is used because neither exact contradiction was previously retained;
- Captain says exactly `YOINK!`, has no boils, pokes/licks/walks away, and has
  no effect;
- all living beings use Joe face if shown;
- publication remains held and unpublished.

Continuation required: Exodus 34 reconstructs replacement tablets, proclaimed
name/attributes, covenant commands, Moses' forty-day fast and shining face.
