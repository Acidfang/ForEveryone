# CRACKHEAD EXODUS 8

## Title page

**TAKE THEM AWAY. I WILL LET THE PEOPLE GO.**

**THEY WERE TAKEN AWAY. HE DIDN'T LET THEM GO.**

Source parent: Exodus chapter 8, verses 1–32, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 8.

Prepared evidence: `.chapter-work/CHB-EXO-008/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/007-ALL-THE-WATER-WAS-BLOOD-THEY-DID-THE-SAME.md`.

CrackFlix routing: new `S066 — REMOVE IT AND I WILL DO IT. REMOVED. DIDN'T.`,
episodes `S066-E001-EXO8 — FROG RELIEF PROMISE` and
`S066-E002-EXO8 — FLY RELIEF PROMISE`.

## Causal foundation

```text
RELEASE DEMAND / FROG WARNING
-> AARON RAISES FROGS / MAGICIANS DO SAME
-> PHARAOH: REMOVE FROGS -> I WILL RELEASE
-> PHARAOH SETS TOMORROW
-> MOSES PRAYS / LORD ACTS / FROGS DIE / RESPITE
-> PHARAOH HARDENS / DOES NOT LISTEN
-> AARON STRIKES DUST -> LICE ON PEOPLE/ANIMALS
-> MAGICIANS TRY / CANNOT / SAY GOD'S FINGER
-> PHARAOH HEART HARDENED / DOES NOT LISTEN
-> RELEASE DEMAND / FLY WARNING / GOSHEN DIVISION
-> FLIES CORRUPT EGYPT / GOSHEN EXCEPTION CLAIMED
-> PHARAOH OFFERS IN-LAND SACRIFICE
-> MOSES STATES STONING RISK / THREE-DAY REQUIREMENT
-> PHARAOH: WILL RELEASE, NOT FAR / PRAY
-> MOSES WARNS NO MORE DECEIT
-> MOSES PRAYS / LORD REMOVES ALL FLIES / NONE REMAIN
-> PHARAOH HARDENS / DOES NOT RELEASE
```

## Exodus 8:1–15 — FROG RELIEF PROMISE

The LORD orders release and predicts frogs throughout Pharaoh's borders, houses,
beds, servants, people, ovens and troughs. Aaron stretches rod over waters;
Joe-faced frogs cover Egypt. Magicians do the same and bring up more frogs.
Their source water/mechanism remains unresolved after Exodus 7; no bridge is
invented.

Pharaoh asks Moses/Aaron to entreat removal and says he will release Israel for
sacrifice. Pharaoh chooses tomorrow. Moses prays; the LORD acts according to
Moses' word. Frogs die outside the river, are heaped, and the land stinks.

When Pharaoh sees respite, he hardens his heart and does not listen. S066-E001
closes:

```text
REMOVE FROGS -> I WILL RELEASE
-> FROGS REMOVED / RESPITE OBSERVED
-> PHARAOH HARDENS
-> NO RELEASE
```

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the promise boil, licks his finger and leaves. Frogs remain dead and
Israel remains held.

## Exodus 8:16–19 — THE MAGICIANS COULD NOT

At command Aaron strikes dust; all dust becomes lice throughout Egypt, on human
and animal Joes. Magicians try with enchantments and cannot produce lice. They
tell Pharaoh `THIS IS GOD'S FINGER.` This is their attribution, not God speech.
Pharaoh's heart remains hardened and he does not listen.

Replication in prior plagues and failure here are distinct observed States. No
limit or mechanism is invented.

## Exodus 8:20–24 — FLIES AND GOSHEN DIVISION

The LORD orders another river-side release message and warns flies. He says
Goshen, where his people dwell, will be set apart without flies as a division/
sign. Grievous flies enter Pharaoh/servant houses and corrupt Egypt. The source
does not separately inventory every Goshen house, so the no-fly Goshen State
remains divine statement plus scoped narrative contrast, not invented census.

## Exodus 8:25–32 — FLY RELIEF PROMISE

Pharaoh offers sacrifice inside Egypt. Moses says this is inappropriate because
the sacrifice is an Egyptian abomination and predicts stoning if done before
them; he repeats the three-day wilderness route.

Pharaoh says he will let them go, limits distance and asks prayer. Moses promises
tomorrow's removal and warns Pharaoh not to deal deceitfully again by refusing.
Moses prays. The LORD removes flies from Pharaoh, servants and people; not one
remains.

Captain's CrackFlix points to the completed prior type:

`SKIP -> S066-E001 / REMOVE IT AND I WILL RELEASE`

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

He zones out while the last fly disappears. Pharaoh then hardens his heart and
does not let the people go. Nothing skipped.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the second promise boil, licks his finger, walks away and never looks
back.

## Character and world-ledger changes

- Moses/Aaron perform frog/lice/fly message, prayer and rod chains.
- Pharaoh makes and reverses two relief-linked release commitments, with an
  in-land/limited-distance negotiation between them.
- magicians replicate frogs, fail at lice and attribute the lice to God's finger.
- frogs change from living invasion to dead heaps except river remainder; lice
  remain on people/animals; flies are completely removed after corrupting Egypt.
- Goshen becomes explicitly distinguished from affected Egyptian territory.

## Bullshit pass

- banner: `CRACKHEAD PLAGUE SUPPORT — RELIEF RESETS TERMS`;
- frog dashboard: `BED OVEN TROUGH / TOMORROW / HEAP MODE`;
- magician error: `LICE DRIVER NOT INSTALLED / GOD'S FINGER DETECTED`;
- Goshen map: `FLY-FREE ZONE / EVERY FLY HAS JOE FACE ELSEWHERE`;
- promise button: `LET GO AFTER REMOVAL / AUTO-UNTICK ON RESPITE`;
- CrackFlix: `S066 EPISODE 2 — SAME SHIT, DIFFERENT BUG`;
- barcode: `CHB-EXO8-S066E001-E002-32-YOINK`.

## FIR verification

- all 32 verse markers are represented in order;
- frog replication and lice failure remain separate observed magician States;
- both S066 episodes require explicit release promise, completed relief and
  subsequent non-release;
- the second occurrence uses addressed SKIP and still fully occurs;
- Pharaoh is explicit actor hardening his heart in both relief reversals;
- magician God-finger and Moses stoning-risk claims remain character speech;
- Goshen distinction is not expanded beyond source scope;
- every living plague organism has Joe face and separate identity;
- direct LORD speech/actions remain God-only;
- Israel release and Joseph bone transport remain open;
- publication remains held and unpublished.

Continuation required: Exodus 9 reconstructs livestock death scope, surviving
livestock, boils, hail warning, selective shelter, Pharaoh confession/promise,
relief and renewed hardening.
