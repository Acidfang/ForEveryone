# CRACKHEAD EXODUS 29

## Title page

**YOU SHALL SANCTIFY THEM.**

**I WILL SANCTIFY THEM.**

Source parent: Exodus chapter 29, verses 1–46, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 29.

Prepared evidence: `.chapter-work/CHB-EXO-029/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/028-HOLY-TO-THE-LORD-THE-INIQUITY-OF-THE-HOLY-THINGS.md`.

CrackFlix routing:

- new `S089-E001-EXO29 — MOSES SANCTIFIES / GOD SANCTIFIES`;
- contextual evidence revises, but does not close, retained `S087-E001`.

## Causal foundation

```text
ONE DEFECT-FREE BULL + TWO DEFECT-FREE RAMS
-> THREE UNLEAVENED WHEAT/OIL BREAD FORMS IN ONE BASKET
-> AARON/SONS WASHED + DRESSED + CROWNED
-> AARON ANOINTED / FIVE RECEIVE PERPETUAL PRIESTHOOD
-> BULL: HANDS / KILL / HORN+BASAL BLOOD / INNER FAT ALTAR
-> BULL BODY+SKIN+DUNG OUTSIDE CAMP / SIN OFFERING
-> RAM ONE: HANDS / KILL / ALTAR BLOOD / WASH+PIECE / WHOLE BURN
-> RAM TWO: HANDS / KILL / RIGHT EAR+THUMB+TOE BLOOD / ALTAR BLOOD
-> ALTAR BLOOD + ANOINTING OIL ON FIVE JOES AND GARMENTS
-> CONSECRATION PORTIONS + BREAD IN THEIR HANDS / WAVE / BURN
-> BREAST TO MOSES / BREAST+THIGH FUTURE PRIEST PORTION
-> AARON GARMENTS PASS TO SUCCESSOR SON / SEVEN-DAY WEARING
-> RAM MEAT BOILED HOLY PLACE / PRIESTS EAT AT TENT DOOR
-> STRANGER EXCLUDED / MORNING REMAINDER BURNED BECAUSE HOLY
-> DO ALL THIS SEVEN DAYS
-> DAILY SIN-OFFERING BULL / ALTAR CLEANSE+ANOINT+SANCTIFY
-> ALTAR MOST HOLY / WHATEVER TOUCHES IT BECOMES HOLY
-> TWO YEARLING LAMBS DAILY: MORNING + EVENING
-> MATCHED FLOUR/OIL/WINE WITH EACH / CONTINUAL GENERATIONS
-> GOD MEETS/SPEAKS/SANCTIFIES/DWELLS
```

The complete sequence is commanded prospectively. No animal, ingredient,
garment, altar, Tent, priestly installation, daily offering, meeting or divine
dwelling is performed in this chapter.

## Exodus 29:1–9 — WASH, DRESS, POUR OIL

To make Aaron and his sons holy for priestly ministry, Moses must take one
young bull and two rams without defect. Fine wheat flour supplies three
unleavened forms:

- bread;
- cakes mixed with oil;
- wafers anointed with oil.

They share one basket and are brought with the three living animals. The source
does not identify wheat growers, bakers, oil source, basket maker, animal
owners or acquisition acts.

At the Tent door, Moses must wash Aaron and his four sons with water. He then
dresses Aaron in tunic, ephod robe, ephod, breastplate and woven band, places
the turban and holy crown, and pours anointing oil on Aaron's head. The sons
receive tunics, belts and headbands. The priesthood is assigned to Aaron and
sons by perpetual statute, and Moses must consecrate them. Every action remains
future because the Tent, garments and installation have not yet been made.

## Exodus 29:10–14 — BULL SPLIT THREE WAYS

Aaron and sons put their hands on the bull's head. Moses kills it before the
LORD at the Tent door. Its blood has two destinations:

- some goes on the altar horns by Moses' finger;
- all remaining blood is poured at the altar base.

Fat covering the innards, liver covering, both kidneys and their fat burn on
the altar. Bull meat, skin and dung burn outside the camp. The bull is a sin
offering. “All blood” follows removal of the horn portion; the text does not
say the horn-applied blood is also poured back off the horns.

## Exodus 29:15–18 — RAM ONE, WHOLE BURN

The first ram receives the five priests' hands on its head, is killed, and its
blood is sprinkled around the altar. Moses cuts it into pieces, washes its
innards and legs, restores them beside the pieces and head, and burns the whole
ram on the altar. It is a burnt offering, a pleasant aroma and a fire offering
to the LORD.

“Whole” describes the altar destination after the specified cutting and
washing; it does not erase those intermediate changes or make this the second
ram.

## Exodus 29:19–28 — RAM TWO, RIGHT-SIDE BLOOD AND PORTIONS

The second ram also receives the priests' hands and is killed. Its blood goes
to each priest's:

- right ear tip;
- right-hand thumb;
- right-foot big toe;

and around the altar. Blood already on the altar is then combined with
anointing oil and sprinkled on Aaron, his garments, his sons and their
garments. The five Joes and their clothes are thereby assigned a future holy
State.

From this consecration ram, Moses takes the fat tail, organ-covering fats,
liver covering, both kidneys and fat, and right thigh. One plain loaf, one
oiled cake and one wafer come from the basket. All go into Aaron's and his
sons' hands and are waved before the LORD. Moses takes them back and burns them
on the existing burnt offering as a pleasant fire offering.

The consecration ram's breast is separately waved and becomes Moses' portion.
The waved breast and raised thigh are sanctified as Aaron-and-sons portions;
the rule continues as their forever portion from Israel's peace-offering wave
offerings. The right thigh included in the installation burn and the continuing
raised-thigh rule are retained in their stated scopes rather than assumed to be
one simultaneously consumed piece.

## Exodus 29:29–34 — SUCCESSOR CLOTHES AND HOLY LEFTOVERS

Aaron's holy garments pass to his sons after him. The son replacing him as
priest wears them for seven days when entering the Tent to minister. No son is
selected as successor here, and Aaron has not yet worn them once.

The consecration ram's meat is boiled in a holy place. Aaron and sons eat it
with basket bread at the Tent door. They eat the things by which atonement was
made to consecrate and sanctify them. A stranger may not eat because the food
is holy. Any meat or bread remaining until morning is burned and may not then
be eaten, also because it is holy.

The temporal condition changes at morning:

```text
BEFORE MORNING + AUTHORIZED PRIEST -> EAT HOLY FOOD
REMAINS UNTIL MORNING -> DO NOT EAT / BURN HOLY FOOD
```

That is one bounded rule with a stated change, not says-eat/does-not-eat crack.

## Exodus 29:35–37 — SEVEN DAYS TO MAKE THE ALTAR MOST HOLY

Moses must do all commanded installation acts to Aaron and sons across seven
days. Every day requires a bull sin offering for atonement. Moses cleanses the
altar while making atonement for it and anoints it to sanctify it. Seven days
of atonement and sanctification produce a most-holy altar:

> **WHATEVER TOUCHES THE ALTAR SHALL BE HOLY.**

No touching subject, transfer mechanism, accidental contact or post-contact
State is supplied. The altar's cleansing does not prove visible dirt, prior
misconduct or an actually built altar.

## Exodus 29:38–42 — CONTINUAL MEANS MORNING AND EVENING HERE

The altar's generational daily offering uses two one-year-old lambs:

- one in the morning;
- the other in the evening.

Each receives a tenth ephah of fine flour mixed with a quarter hin of beaten
oil and a quarter hin of wine as drink offering. The footnotes estimate one
ephah at 22 litres or two-thirds bushel and one quarter-hin at about 1.6 litres.
The evening lamb repeats the morning meal/drink pattern.

This twice-daily system is expressly called both:

> **DAY BY DAY CONTINUALLY**

and:

> **A CONTINUAL BURNT OFFERING THROUGHOUT YOUR GENERATIONS.**

That supplies new contextual evidence for S087:

```text
EXODUS 27 -> LAMP BURNS CONTINUALLY / TENDED EVENING-MORNING
EXODUS 29 -> OFFERING IS CONTINUAL / ACTS OCCUR MORNING+EVENING
-> CONTINUAL CAN LABEL A RECURRING SCHEDULE IN THIS SOURCE CONTEXT
-> DIFFERENT OBJECT AND PROCESS
-> NO EXPLICIT APPLICATION BACK TO THE LAMP
```

S087's original English friction remains a retained Moment, but its lexical
frontier is narrower now. No new S087 episode and no SKIP are manufactured.

## Exodus 29:42–46 — WHO SANCTIFIES THEM?

At the Tent door, God says he will meet Moses and speak there. He will meet
Israel there; the place will be sanctified by his glory. He then says:

> **I WILL SANCTIFY THE TENT OF MEETING AND THE ALTAR.**

> **I WILL ALSO SANCTIFY AARON AND HIS SONS.**

That directly follows commands assigning Moses the same priestly result:

> **YOU SHALL SANCTIFY THEM.** — Exodus 28:41

> **THIS IS THE THING THAT YOU SHALL DO TO THEM TO MAKE THEM HOLY.** — Exodus 29:1

> **YOU SHALL CONSECRATE THEM SEVEN DAYS.** — Exodus 29:35

S089-E001 closes at the ownership boundary:

```text
MOSES -> PERFORMS PRESCRIBED INSTALLATION -> SANCTIFIES AARON/SONS
GOD -> I WILL SANCTIFY AARON/SONS
-> SAME FUTURE RESULT ASSIGNED TO DISTINCT ACTORS
-> PROCEDURE MAY BE GOD'S INSTRUMENT
-> SOURCE DOES NOT EXPRESSLY ALLOCATE OR EQUATE THE TWO CLAIMED ACTS
```

This resembles S085's multiple-owner outcome structure, but S085 is retained
as an exact displacement relation among hornet, God and Israel. Sanctification
has a different object, actors and dependency chain, so it receives S089 rather
than contaminating that series.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the seven-day sanctification boil, licks his finger and walks away
without looking back. Moses is still receiving instructions.

God says he will dwell among Israel and be their God. They will know him as the
LORD who brought them from Egypt so he might dwell among them. The chapter does
not narrate the Tent's completion, meeting, sanctification, dwelling or this
future knowledge State.

## Character and world-ledger changes

- Aaron, Nadab, Abihu, Eleazar and Ithamar gain an exact prospective washing,
  dressing, blood/oil, eating and seven-day consecration sequence;
- one bull, two installation rams and recurring yearling lambs enter distinct
  living offering roles;
- Moses gains prospective washer, dresser, anointer, slaughterer, blood/oil
  applier, portion waver, altar cleanser and seven-day consecrator acts;
- Aaronic garments gain successor-son/seven-day wearing relation;
- priests gain breast/thigh peace-offering portion and restricted holy-food
  eating relation;
- altar gains seven-day atonement/anointing and touch-makes-holy rule;
- S087 gains later contextual lexical evidence without erasure or new episode;
- S089 records Moses/God dual assignment of priest sanctification;
- no commanded installation or service act becomes performed history;
- Moses remains on the mountain; Joseph's bones remain in transport.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — PRIEST INSTALL WIZARD 1 OF 7`;
- livestock cart: `1 BULL / 2 RAMS / DEFECT FIELD MUST BE EMPTY`;
- bread basket: `PLAIN / OIL-MIXED / OIL-PAINTED`;
- dressing order: `TUNIC > ROBE > EPHOD > CHEST ROCKS > HAT > CROWN`;
- blood UI: `HORNS / BASE / AROUND / RIGHT EAR / RIGHT THUMB / RIGHT TOE`;
- holy laundry warning: `SPRINKLE PRIESTS AND CLOTHES TOGETHER`;
- wave control: `PUT IN HANDS / WAVE / TAKE BACK / BURN`;
- leftovers: `MORNING DETECTED — INCINERATE BREAKFAST`;
- altar firmware: `TOUCH = HOLY`;
- schedule: `CONTINUAL = 06:00 LAMB + 18:00 LAMB IN THIS MODULE`;
- CrackFlix: `S089 E001 — SANCTIFICATION OWNERSHIP COLLISION`;
- barcode: `CHB-EXO29-S089-46-YOINK`.

## FIR verification

- all 46 verse markers are represented in order;
- bull, first ram, second ram and recurring lambs remain distinct living Joes;
- every blood, fat, flesh, bread, wave, burn and eating destination remains
  source-bounded;
- future commands are not converted into completed animal deaths or rituals;
- successor garments and the initial Aaron installation remain different times;
- holy-food eat/burn rules retain their explicit morning boundary;
- altar touch holiness remains a stated rule without invented contacts;
- Exodus 29's scheduled continual offering narrows S087's lexical uncertainty
  without silently resolving or duplicating the lamp episode;
- S089 remains distinct from S085 because exact root identity is protected;
- no SKIP is used because S089 has no earlier episode;
- all living humans and animals use Joe face if shown;
- Captain remains boilless and causally useless;
- divine future meeting, sanctifying and dwelling remain direct God claims;
- Moses remains on mountain and Joseph bones remain in transport;
- publication remains held and unpublished.

Continuation required: Exodus 30 reconstructs incense altar, census ransom,
bronze washing basin, holy anointing oil, restricted incense and their
death/plague/exclusion boundaries.
