# CRACKHEAD EXODUS 30

## Title page

**MAKE THE HOLY ANOINTING OIL.**

**WHOEVER COMPOUNDS ANY LIKE IT SHALL BE CUT OFF.**

Source parent: Exodus chapter 30, verses 1–38, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 30.

Prepared evidence: `.chapter-work/CHB-EXO-030/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/029-YOU-SANCTIFY-THEM-I-WILL-SANCTIFY-THEM.md`.

CrackFlix routing:

- new `S090-E001-EXO30 — MAKE THE FORMULA / MAKING IT GETS YOU CUT OFF`;
- new `S091-E001-EXO30 — POUR IT ON THE PRIESTS / NOT ON MAN'S FLESH`.

## Causal foundation

```text
INCENSE ALTAR -> 1 x 1 x 2 CUBITS / ACACIA / ONE-PIECE HORNS
-> PURE GOLD OVERLAY + MOLDING + TWO RINGS + GOLD POLES
-> BEFORE VEIL/MERCY-SEAT MEETING ADDRESS
-> SWEET INCENSE MORNING + EVENING WITH LAMP WORK
-> NO STRANGE INCENSE / BURNT / MEAL / DRINK OFFERING
-> ANNUAL HORN BLOOD ATONEMENT / MOST HOLY
-> CENSUS -> EACH COUNTED MAN PAYS HALF-SHEKEL SO NO PLAGUE
-> AGE 20+ / RICH NOT MORE / POOR NOT LESS
-> MONEY TO TENT SERVICE / MEMORIAL + SOUL ATONEMENT
-> BRONZE BASIN + WATER BETWEEN TENT AND ALTAR
-> PRIESTS WASH HANDS+FEET AT ENTRY/ALTAR SO THEY DO NOT DIE
-> MYRRH 500 + CINNAMON 250 + CANE 250 + CASSIA 500 + OIL 1 HIN
-> PERFUMER MAKES HOLY ANOINTING OIL
-> ANOINT TENT/FURNITURE/ALTARS/BASIN + AARON/SONS
-> OBJECTS MOST HOLY / TOUCH MAKES HOLY
-> DO NOT POUR ON MAN'S FLESH / DO NOT MAKE ANY LIKE IT
-> COPY OR PUT ON STRANGER -> CUT OFF
-> EQUAL GUM RESIN/ONYCHA/GALBANUM/FRANKINCENSE + SALT
-> PERFUMER MAKES PURE HOLY INCENSE
-> BEAT SMALL / PUT BEFORE COVENANT AT MEETING ADDRESS
-> DO NOT MAKE IT FOR YOURSELVES
-> MAKE COPY TO SMELL -> CUT OFF
```

Every object, payment, washing, mixture, anointing and exclusion is commanded
or conditional. Nothing in this chapter is built, counted, paid, washed,
compounded, applied, burned, copied, smelled or enforced.

## Exodus 30:1–10 — GOLD INCENSE ALTAR

The acacia incense altar is square, one cubit long, one wide and two high. Its
horns are one piece with it. The source footnote gives a cubit as approximately
46 centimetres or 18 inches. Pure gold covers top, sides and horns; a gold
molding surrounds it.

Two gold rings beneath the molding receive gold-overlaid acacia carrying poles.
Unlike the ark, the poles are not ordered to remain inserted. The altar is
placed before the veil near the covenant ark and mercy seat, at God's future
meeting address.

Aaron burns sweet-spice incense every morning while tending lamps and every
evening while lighting them. This morning/evening sequence is called perpetual
incense through generations, adding another direct example of continual-style
language applied to a recurring schedule rather than one uninterrupted act.

No strange incense, burnt offering, meal offering or drink offering belongs on
this altar. Once yearly Aaron applies atonement sin-offering blood to its horns.
The altar is most holy. Daily incense and annual blood remain distinct uses.

## Exodus 30:11–16 — COUNTING FEE OR PLAGUE

When Israel is counted, each counted man gives the LORD a ransom for his soul:

> **THAT THERE BE NO PLAGUE AMONG THEM WHEN YOU COUNT THEM.**

Every counted person aged twenty years and upward pays half a sanctuary shekel.
A shekel is twenty gerahs; the footnotes approximate a shekel at ten grams or
0.35 ounces and a gerah at 0.5 grams or 7.7 grains.

The rich may not give more and the poor may not give less. The same half-shekel
is an offering, soul atonement, Tent-service funding and memorial before the
LORD. The payment rule equalizes amount rather than burden; the chapter gives
no incomes, payer identities, count, collected total, plague event or unpaid
case.

## Exodus 30:17–21 — WASH HANDS AND FEET OR DIE

A bronze basin and bronze base stand between Tent and burnt-offering altar with
water inside. Aaron and sons wash hands and feet when entering the Tent or
approaching the altar to minister and burn a fire offering:

> **THEY SHALL WASH WITH WATER, THAT THEY DON'T DIE.**

The rule repeats for emphasis and becomes a forever generational statute. It
does not state whether one washing covers both movements, how much water is
needed, what contamination exists, how non-washing produces death, or that any
priest actually fails.

This is another death-prevention service condition, not an episode of the robe
bells or linen pants: the required object, body parts and triggering acts are
different.

## Exodus 30:22–30 — THE AUTHORIZED OIL BATCH

The holy anointing oil uses sanctuary-shekel measures:

- liquid myrrh: 500 shekels, about 5 kilograms or 11 pounds;
- fragrant cinnamon: 250 shekels;
- fragrant cane: 250 shekels;
- cassia: 500 shekels;
- olive oil: one hin, about 6.5 litres or 1.7 gallons.

A perfumer compounds it into holy anointing oil. Moses uses it on the Tent,
ark, table and articles, lampstand and accessories, incense altar,
burnt-offering altar and utensils, basin and base. The objects become most holy,
and whatever touches them shall be holy.

Moses must also:

> **ANOINT AARON AND HIS SONS, AND SANCTIFY THEM.**

This repeats Moses' side of S089 without the separate God claim inside this
chapter. It is therefore retained continuity, not a new episode or SKIP event.

## Exodus 30:31–33 — AUTHORIZED FORMULA, FORBIDDEN FORMULA

Israel is told that this exact substance is God's holy anointing oil through
their generations. Then:

> **IT SHALL NOT BE POURED ON MAN'S FLESH.**

> **DO NOT MAKE ANY LIKE IT, ACCORDING TO ITS COMPOSITION.**

> **WHOEVER COMPOUNDS ANY LIKE IT ... SHALL BE CUT OFF FROM HIS PEOPLE.**

S090-E001 closes on manufacturing:

```text
MOSES/PERFUMER -> SHALL MAKE EXACT COMPOSITION
-> ISRAEL -> DO NOT MAKE ANY LIKE EXACT COMPOSITION
-> WHOEVER MAKES ANY LIKE IT -> CUT OFF
-> AUTHORIZED-FIRST-BATCH EXCEPTION IS REQUIRED BY THE EARLIER COMMAND
-> NO EXPLICIT MAKER, BATCH, TIME OR PURPOSE EXCEPTION STATED IN THE BAN
```

The command sequence makes an exception reconstructable, but does not express
its boundary. The contradiction is the supplied broad enforcement wording
against the required manufacture, not a claim that the original maker is
actually cut off.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the formula boil, licks his finger and walks away without looking
back. No oil exists yet.

S091-E001 closes on flesh application:

```text
EXODUS 29 -> POUR OIL ON AARON'S HEAD
EXODUS 30 -> ANOINT AARON AND HIS SONS WITH THIS OIL
-> AARON/SONS -> LIVING MEN
-> THIS OIL -> SHALL NOT BE POURED ON MAN'S FLESH
-> STRANGER APPLICATION IS EXPRESSLY CUT OFF
-> PRIEST-FLESH EXCEPTION IS REQUIRED BUT NOT EXPRESSLY STATED
```

Head application might land on hair rather than exposed flesh, but anointing
all five priests still supplies no non-flesh application boundary. “Stranger”
narrows the enforcement example; it does not rewrite the preceding categorical
flesh sentence.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes Aaron's oil boil, licks his finger and walks away without looking
back. Aaron remains dry and uninstalled.

## Exodus 30:34–38 — INCENSE HAS THE MISSING PURPOSE EXCEPTION

The incense formula uses equal weights of gum resin, onycha, galbanum and pure
frankincense. A perfumer compounds it with salt into pure holy incense. Some is
beaten very small and placed before the covenant at the Tent meeting address.

The prohibition says:

> **YOU SHALL NOT MAKE THIS INCENSE ... FOR YOURSELVES.**

Whoever makes a copy to smell it is cut off. Unlike the oil-copy rule, this one
states the disallowed purpose. Sacred manufacture for the commanded meeting
use and personal manufacture for smelling occupy different observable scopes.
There is no incense-formula contradiction.

No ingredient source, scent, salt amount, batch mass, perfumer identity,
placement, copy, smelling act or exclusion occurs.

## Character and world-ledger changes

- incense altar and carrying system enter unbuilt design State;
- Aaron gains future twice-daily incense and annual horn-atonement duties;
- counted Israelite men aged twenty-plus gain equal half-shekel ransom rule;
- bronze basin gains exact position and hands/feet no-death washing function;
- perfumer gains two distinct future formulas: holy oil and holy incense;
- sanctuary objects gain future oil-anointing and touch-makes-holy relations;
- Aaron and sons gain another commanded oil-anointing relation;
- S090 records authorized oil manufacture against categorical copy enforcement;
- S091 records priest anointing against categorical no-man-flesh wording;
- incense self-use prohibition remains cleanly scoped and creates no series;
- no construction, census, payment, washing, compounding, anointing, incense
  burning or punishment is promoted into history;
- Moses remains on mountain; Joseph's bones remain in transport.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — PAY / WASH / OIL / SMELL ACCESS CONTROL`;
- gold altar: `1 x 1 x 2 / HORNS INCLUDED / NO FOOD OR DRINK`;
- incense scheduler: `MORNING LAMP WORK + EVENING LAMP WORK`;
- census checkout: `SOUL RANSOM HALF-SHEKEL / PLAGUE WARRANTY INCLUDED`;
- equality mode: `RICH +0 / POOR -0`;
- basin warning: `HANDS + FEET OR DIE`;
- oil recipe: `500 / 250 / 250 / 500 / 1 HIN`;
- oil license: `MAKE THIS / DO NOT MAKE THIS`;
- body warning: `AUTHORIZED PRIESTS ARE APPARENTLY NOT MAN-FLESH TODAY`;
- incense recipe: `FOUR EQUAL + SALT / PERSONAL SNIFFING DISABLED`;
- CrackFlix: `S090 E001 + S091 E001 — DOUBLE OIL FEATURE`;
- barcode: `CHB-EXO30-S090-S091-38-2YOINK`.

## FIR verification

- all 38 verse markers are represented in order;
- incense altar and burnt-offering altar remain distinct objects and uses;
- daily incense and annual blood atonement remain separate schedules;
- census ransom is conditional and no count/payment/plague is invented;
- rich/poor equality is amount equality only;
- basin hand/foot washing is not merged with garment death-prevention rules;
- oil and incense formulas, ingredients, purposes and penalties remain distinct;
- S090 preserves the required implicit authorized-batch exception without
  pretending the ban states it;
- S091 preserves the priest/stranger distinction without rewriting “man's
  flesh” into an unstated “ordinary man's flesh” phrase;
- S089 continuity is retained without manufacturing another episode;
- no SKIP is used because S090 and S091 are first occurrences;
- all living humans and ingredient-source organisms use Joe face if shown;
- Captain remains boilless and causally useless;
- Moses remains on mountain and Joseph bones remain in transport;
- publication remains held and unpublished.

Continuation required: Exodus 31 reconstructs named craftspeople, wisdom-filled
skill, Sabbath sign/death/cut-off rules and delivery of the two God-written
stone tablets.
