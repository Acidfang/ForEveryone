# CRACKHEAD EXODUS 21

## Title page

**HE SHALL GO OUT FREE.**

**HE SHALL SERVE FOREVER.**

Source parent: Exodus chapter 21, verses 1–36, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 21.

Prepared evidence: `.chapter-work/CHB-EXO-021/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/020-DONT-BE-AFRAID-HIS-FEAR-MAY-BE-BEFORE-YOU.md`.

CrackFlix routing:

- new `S081-E001-EXO21 — GO OUT FREE / KEEP YOUR FAMILY AND SERVE FOREVER`;
- new `S082-E001-EXO21 — OWNER SHALL DIE / OWNER MAY REDEEM HIS LIFE`.

## Causal foundation

```text
LORD CONTINUES ORDINANCES FOR MOSES TO SET BEFORE ISRAEL
-> HEBREW MALE SERVANT: SIX YEARS SERVICE / SEVENTH FREE WITHOUT PAYMENT
-> ENTRY HOUSEHOLD STATE DETERMINES EXIT HOUSEHOLD STATE
-> MASTER-GIVEN WIFE + CHILDREN REMAIN MASTER'S / MAN EXITS ALONE
-> MAN MAY REFUSE FREEDOM TO KEEP MASTER/WIFE/CHILDREN
-> GOD/DOORPOST/AWL PROCEDURE -> SERVICE FOREVER
-> SOLD DAUGHTER/FEMALE SERVANT HAS SEPARATE MARRIAGE/REDEMPTION/RIGHTS/EXIT RULES
-> DEATH, PARENT, KIDNAPPING, QUARREL, SERVANT-INJURY AND PREGNANCY-HARM RULES
-> LIFE/EYE/TOOTH/HAND/FOOT/BURN/WOUND/BRUISE RETALIATION SCHEDULE
-> SERVANT EYE/TOOTH DESTRUCTION -> SERVANT FREED
-> BULL HUMAN-DEATH LIABILITY CHANGES WITH PRIOR GORING KNOWLEDGE/CONFINEMENT
-> KNOWN DANGEROUS BULL KILLS -> BULL + OWNER DEATH
-> RANSOM MAY REDEEM OWNER'S LIFE
-> SON/DAUGHTER/SERVANT VICTIM RULES
-> UNCOVERED PIT AND BULL-ON-BULL LOSS ALLOCATION
```

These are spoken conditional ordinances. The chapter narrates no purchase,
sale, marriage, refusal, ear boring, attack, death, injury, birth, judgment,
fine, ransom, stoning, pit fall or animal collision as actually performed.

## Exodus 21:1–6 — FREE, WITHOUT THE FAMILY

The LORD introduces ordinances Moses is to set before the people.

If a Hebrew male servant is bought, he serves six years and in the seventh:

> **HE SHALL GO OUT FREE WITHOUT PAYING ANYTHING.**

His entry State controls what leaves with him:

- if he entered alone, he leaves alone;
- if he entered married, his wife leaves with him;
- if the master supplied a wife and she bore children, the wife and children
  remain the master's and the servant leaves alone.

The servant may plainly say:

> **I LOVE MY MASTER, MY WIFE, AND MY CHILDREN.**

> **I WILL NOT GO OUT FREE.**

The master then brings him to God and to a door or doorpost, bores his ear with
an awl, and:

> **HE SHALL SERVE HIM FOREVER.**

S081-E001 closes at the rule level:

```text
BOUGHT HEBREW SERVANT -> SEVENTH-YEAR FREE EXIT
-> MASTER-SUPPLIED WIFE/CHILDREN DO NOT EXIT WITH HIM
-> KEEPING THOSE RELATIONS REQUIRES REFUSING FREE EXIT
-> REFUSAL CHANGES SIX-YEAR SERVICE INTO FOREVER SERVICE
```

The source explicitly gives the servant the refusal speech. It does not narrate
a particular servant making it, does not supply the wife's or children's
speech, and does not say they are freed by his permanent service.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the release boil, licks his finger and walks away without looking
back. The ordinances continue unchanged.

## Exodus 21:7–11 — SOLD DAUGHTER / THREE EXIT FAILURES

If a man sells his daughter as a female servant, she does not leave under the
male-servant exit rule. The conditional branches are retained separately:

- a master who married her and is displeased must allow redemption;
- he has no right to sell her to a foreign people after dealing deceitfully;
- if she is married to his son, she is to be treated as a daughter;
- if he takes another wife, he must not reduce her food, clothing or marital
  rights;
- if he fails these three things, she may leave free without money.

`She shall not go out as the male servants do` and her separate failure-based
free exit define different procedures. They do not assert that she can never
leave, so no extra crack is manufactured.

No daughter's sale, marriage, foreign sale, second wife, deprivation,
redemption or exit occurs in this chapter.

## Exodus 21:12–17 — DEATH, REFUGE, PARENTS AND KIDNAPPING

The spoken sanctions establish:

- one who strikes a man so that he dies shall be put to death;
- if the death is unintentional and God allows it to happen, God will appoint a
  place to which the actor may flee;
- a scheming, presumptuous neighbor-killer is to be taken even from God's altar
  to die;
- attacking father or mother carries death;
- kidnapping someone and selling or retaining that person carries death;
- cursing father or mother carries death.

`God allows it to happen` is retained as direct divine wording. No mechanism,
specific death, refuge location, altar seizure, offender, execution or divine
motive is supplied here.

The permitted father-to-daughter sale in verse 7 is not silently equated with
kidnapping in verse 16. The source supplies different acts and no shared case.

## Exodus 21:18–21 — QUARREL INJURY / SERVANT PROPERTY

If men quarrel and one strikes another with stone or fist, and the injured man
does not die but is confined to bed, the striker is cleared when the injured
man rises and walks with a staff. The striker must still pay lost time and
provide healing until the victim is thoroughly healed.

If a man strikes his male or female servant with a rod and the servant dies
under his hand, the man is to be punished. If the servant gets up after a day
or two, the man is not punished because the servant is his property.

The source does not define the first punishment, identify the adjudicator, or
state that `punished` excludes death. It therefore cannot close a contradiction
against verse 12's death sanction without an actual ruling. `Gets up` is not
silently rewritten as delayed death.

## Exodus 21:22–27 — HARM FOR HARM / FREED FOR EYE OR TOOTH

If fighting men hurt a pregnant woman, cause premature birth and no harm
follows, the responsible actor is fined as demanded by the husband and allowed
by the judges. If harm follows, the schedule is:

- life for life;
- eye for eye;
- tooth for tooth;
- hand for hand;
- foot for foot;
- burning for burning;
- wound for wound;
- bruise for bruise.

If a master destroys a male or female servant's eye, the servant goes free for
the eye. If the master knocks out the servant's tooth, the servant goes free for
the tooth.

The retaliation schedule is spoken inside the pregnant-woman harm condition.
The servant rules supply a different injury-and-release condition. The chapter
does not state that the first schedule universally governs every later injury,
so `eye for eye` and `eye for freedom` are not merged into an invented case.

No fight, pregnancy, premature birth, harm, judge decision, payment, destroyed
eye, lost tooth or release is performed.

## Exodus 21:28–32 — THE BULL KNEW NOTHING / THE OWNER KNEW

If a bull gores a man or woman to death:

- the Joe-faced bull is stoned;
- its meat is not eaten;
- its owner is not held responsible.

If the bull had a past goring habit, that habit had been testified to its owner,
the owner failed to confine it, and it killed a man or woman:

- the bull is stoned;
- the owner is also put to death.

Then the same owner-death branch permits:

> **IF A RANSOM IS IMPOSED ON HIM, HE SHALL GIVE WHATEVER IS IMPOSED FOR THE REDEMPTION OF HIS LIFE.**

S082-E001 closes:

```text
KNOWN GORING HISTORY + NOTICE + NO CONFINEMENT + HUMAN DEATH
-> OWNER SHALL BE PUT TO DEATH
-> IF RANSOM IMPOSED, OWNER PAYS TO REDEEM THAT LIFE
```

The ransom condition is explicit; its amount, chooser, collection process and
actual use are not supplied.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the owner-liability boil, licks his finger and walks away without
looking back. No bull has appeared outside the ordinance.

The same judgment applies when the victim is a son or daughter. If the bull
gores a male or female servant, thirty shekels of silver are paid to the
servant's master and the bull is stoned. The source footnote converts thirty
shekels to about 300 grams or 10.6 ounces; it is a translator's measurement
note, not a second fine or performed weighing.

The servant branch does not state whether the known-goring and ransom branches
also apply. That scope remains unresolved rather than filled in.

## Exodus 21:33–36 — PIT AND BULL LOSS ROUTING

If a man opens or digs a pit, leaves it uncovered, and a bull or donkey falls
into it, the pit owner pays the animal owner and receives the dead animal.

If one man's bull kills another's bull, the owners sell the live bull and divide
its price, then divide the dead animal. If the killing bull was already known
to gore and its owner did not confine it, that owner pays bull for bull and
keeps the dead animal.

Prior knowledge and failure to confine change the loss allocation. This agrees
with the knowledge boundary in verses 28–30; it is not a contradiction.

Every bull and donkey is a distinct living Joe despite the shared face. Pits,
silver and dead bodies are nonliving, but anything visually interpreted as a
face may still receive Joe's face in production.

## Character and world-ledger changes

- Israel receives a conditional civil-liability schedule through Moses;
- Hebrew male servant entry/family/release/refusal/permanent-service relations
  enter the rule State;
- sold-daughter/female-servant redemption, marriage treatment, maintenance and
  failure-based exit relations enter the rule State;
- death, refuge, parent, kidnapping, quarrel, servant-injury and pregnancy-harm
  sanctions enter the rule State;
- judges, husbands, masters, owners and injured parties gain conditional roles;
- bulls and donkeys gain distinct first-event, known-danger, confinement,
  stoning, valuation and loss-allocation branches;
- S081 records free exit whose family-retention path ends in forever service;
- S082 records owner death whose ransom path redeems the same life;
- no hypothetical subject or conditional event is promoted into history;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — TERMS OF SERVICE: ACTUAL SERVANTS`;
- release desk: `YEAR 7: FREE*  *FAMILY MAY BE STORED SEPARATELY`;
- doorpost kiosk: `DECLINE FREEDOM / ACCEPT FOREVER / EAR PORT REQUIRED`;
- female plan: `NOT THE MALE PLAN / THREE-FAILURE EXIT INCLUDED`;
- parent support: `ATTACK/CURSE TICKET: TERMINAL`;
- injury menu: `TIME + HEALING / BODY PART MATCHING AVAILABLE`;
- property notice: `GETS UP IN 1–2 DAYS: OWNER ACCOUNT NOT CHARGED`;
- CrackFlix: `S081 E001 — FAMILY RETENTION SUBSCRIPTION`;
- bull dashboard: `FIRST GORE: OWNER OFF / KNOWN GORER: OWNER ALSO STONED`;
- death invoice: `RANSOM MAY REDEEM USER`;
- CrackFlix: `S082 E001 — CAPITAL PAYMENT OPTION`;
- pit warranty: `UNCOVERED HOLE INCLUDES DEAD ANIMAL`;
- livestock exchange: `DIVIDE LIVE PRICE / DIVIDE DEAD JOE`;
- barcode: `CHB-EXO21-S081-S082-36-YOINK-YOINK`.

## FIR verification

- all 36 verse markers are represented in order;
- every legal branch remains conditional and no example is narrated as fact;
- S081 closes only from the same male-servant release/family/refusal sequence;
- the servant's supplied love/refusal speech is not converted into hidden motive
  or generalized to a performed person;
- female-servant branches remain distinct from male-servant release;
- kidnapping is not equated with every authorized sale;
- unspecified punishment is not rewritten as a lesser sanction;
- `gets up` is not rewritten as delayed death;
- retaliation and servant-release injury scopes remain distinct;
- S082 closes only from owner-death and explicit ransom-redemption statements in
  the same known-dangerous-bull branch;
- first-event and prior-notice bull liabilities remain distinct;
- servant-victim scope beyond verse 32 remains unresolved;
- every living hypothetical human, bull and donkey uses Joe's face if shown;
- Captain remains boilless and causally useless;
- Joseph bones transport remains active and burial open;
- publication remains held and unpublished.

Continuation required: Exodus 22 reconstructs theft/restitution, livestock and
field loss, deposits/loans, sexual and religious offences, stranger/widow/orphan
treatment, lending/pledges, authority speech and firstborn/firstfruits rules.
