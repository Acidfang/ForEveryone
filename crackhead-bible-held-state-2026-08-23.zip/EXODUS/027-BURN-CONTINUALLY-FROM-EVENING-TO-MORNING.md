# CRACKHEAD EXODUS 27

## Title page

**CAUSE A LAMP TO BURN CONTINUALLY.**

**KEEP IT IN ORDER FROM EVENING TO MORNING.**

Source parent: Exodus chapter 27, verses 1–21, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 27.

Prepared evidence: `.chapter-work/CHB-EXO-027/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/026-MAKE-TEN-CHERUB-CURTAINS-SKIP-S086-E001.md`.

CrackFlix routing:

- new `S087-E001-EXO27 — BURN CONTINUALLY / MAINTAIN EVENING TO MORNING`.

## Causal foundation

```text
ACACIA ALTAR: 5 x 5 x 3 CUBITS / SQUARE
-> FOUR ONE-PIECE HORNS + BRONZE OVERLAY
-> BRONZE ASH/FIRE/MEAT/LIQUID VESSELS
-> BRONZE NETWORK GRATING + FOUR RINGS / HALFWAY HEIGHT
-> BRONZE-COVERED ACACIA CARRY POLES
-> HOLLOW PLANK BUILD TO MOUNTAIN-SHOWN PATTERN
-> COURT: 100 x 50 x 5 CUBITS
-> SOUTH/NORTH EACH 100-CUBIT LINEN + 20 PILLARS/SOCKETS
-> WEST 50-CUBIT LINEN + 10 PILLARS/SOCKETS
-> EAST 15-CUBIT SIDE + 20-CUBIT GATE + 15-CUBIT SIDE
-> EAST 3 + 4 + 3 PILLARS/SOCKETS
-> ALL COURT PILLARS: SILVER HOOKS/FILLETS + BRONZE SOCKETS
-> ALL SERVICE INSTRUMENTS/PINS BRONZE
-> ISRAEL BRINGS PURE BEATEN OLIVE OIL
-> LAMP BURNS CONTINUALLY
-> AARON/SONS KEEP IT EVENING TO MORNING
-> FOREVER GENERATIONAL STATUTE
```

Every component and duty is commanded. No altar, court, oil delivery, lamp
burning, priestly tending or generational continuation is performed here.

## Exodus 27:1–8 — HOLLOW BRONZE ALTAR

The altar is acacia wood, square, five cubits long, five wide and three high.
The source footnotes restate this as approximately 2.3 x 2.3 x 1.4 metres or
7.5 x 7.5 x 4.5 feet. These are alternative conversions of one design.

Its four corner horns are one piece with it, and the whole altar is overlaid in
bronze. Its bronze equipment includes:

- ash pots;
- shovels;
- basins;
- meat hooks;
- fire pans;
- a bronze-network grating;
- four grating rings at the corners.

The grating sits below the surrounding ledge and reaches halfway up the altar.
Acacia carrying poles overlaid with bronze enter the rings and occupy both sides
when the altar is carried. Unlike ark poles, these are not ordered to remain in
place permanently.

The altar is hollow with planks and must match the mountain-shown pattern. No
horn animal, meat source, ash, fire, blood, offering, carrying act or build
worker is supplied in this chapter. The altar horns are nonliving projections,
not living horned Joes.

## Exodus 27:9–19 — ONE-HUNDRED BY FIFTY COURT

The fine-twined-linen court is one hundred cubits long, fifty wide and five
high. Its perimeter is specified separately:

- south: 100 cubits, 20 pillars, 20 bronze sockets;
- north: 100 cubits, 20 pillars, 20 bronze sockets;
- west: 50 cubits, 10 pillars, 10 sockets;
- east: 15-cubit hanging/3 pillars/3 sockets, then 20-cubit embroidered gate/4
  pillars/4 sockets, then 15-cubit hanging/3 pillars/3 sockets.

The east pieces total fifty cubits and ten pillars/sockets. Around the court,
pillar hooks and fillets are silver and sockets bronze. All tabernacle service
instruments, tabernacle pins and court pins are bronze.

The perimeter inventory therefore supplies sixty pillars and sixty sockets:
twenty south, twenty north, ten west and ten east. That arithmetic does not
identify spacing, pillar material, socket mass, linen height variation or an
installed enclosure.

The gate screen repeats blue, purple, scarlet and fine twined linen worked by an
embroiderer. It is a new gate component, not the five-pillar tent-door screen
from Exodus 26.

## Exodus 27:20–21 — CONTINUOUS NIGHT SHIFT

Israel must bring Moses pure olive oil beaten for light:

> **TO CAUSE A LAMP TO BURN CONTINUALLY.**

In the Tent of Meeting, outside the veil before the covenant, Aaron and his sons
must:

> **KEEP IT IN ORDER FROM EVENING TO MORNING BEFORE THE LORD.**

The duty is a forever statute through their generations on Israel's behalf.

S087-E001 closes at the timing rule:

```text
REQUIRED LAMP STATE -> BURN CONTINUALLY
-> ASSIGNED KEEP-IN-ORDER WINDOW -> EVENING TO MORNING
-> NO DAYTIME TENDING, EXTINCTION/RELIGHTING RULE OR CONTINUAL=NIGHTLY BRIDGE
```

The source may use `continually` for repeated regular service, but the supplied
English State does not define that narrowing. The mismatch is retained without
claiming a lamp actually goes out in daytime.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the lamp-schedule boil, licks his finger and walks away without looking
back. The lamp has still not been built.

Olive trees are living Joes when shown alive; pressed oil is nonliving material.
Aaron and his sons are living distinct Joes. The source has not yet named which
sons hold this duty or narrated their installation.

## Character and world-ledger changes

- bronze altar, vessels, grating, poles and hollow pattern enter unbuilt design
  State;
- court perimeter gains exact four-side hanging/pillar/socket/gate relations;
- embroiderer receives another prospective screen assignment;
- all service instruments and structural pins gain bronze material rule;
- Israelites gain prospective pure beaten olive-oil delivery duty;
- Aaron and sons gain future evening-to-morning lamp-order duty;
- S087 records continual burn against bounded tending window;
- no component, oil, flame, priestly shift or forever performance is promoted
  into history;
- Moses remains in mountain instruction State;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — BRONZE OUTDOOR FURNITURE + NIGHT LIGHT`;
- altar dimensions: `5 x 5 x 3 / HOLLOW INSIDE / HORNS INCLUDED`;
- utensil pack: `ASH POT / SHOVEL / BASIN / MEAT HOOK / FIRE PAN`;
- carry mode: `INSERT BRONZE HANDLES WHEN MOVING`;
- courtyard calculator: `100 x 50 x 5 / 60 POSTS / 60 BRONZE SOCKS`;
- east gate equation: `15 + 20 + 15 = ENTRY SIDE`;
- metal policy: `HOOKS SILVER / SOCKS BRONZE / PINS BRONZE`;
- oil request: `PURE / OLIVE / BEATEN / DELIVER TO MOSES`;
- lamp status: `CONTINUALLY`;
- priest dashboard: `SHIFT HOURS EVENING-MORNING`;
- CrackFlix: `S087 E001 — 24/7 NIGHT-SHIFT LIGHTING`;
- barcode: `CHB-EXO27-S087-21-YOINK`.

## FIR verification

- all 21 verse markers are represented in order;
- altar dimensions, conversions, materials, vessels, grating and carrying
  system remain exact and unbuilt;
- altar horns are not made living;
- ark permanent-pole rule is not transferred to altar poles;
- court side inventories and east gate segmentation remain distinct;
- sixty-pillar/socket total is derived only from supplied counts;
- Exodus 26 door screen and Exodus 27 court gate remain different objects;
- S087 retains `continually` and `evening to morning` without inventing daytime
  extinction or a lexical resolution;
- oil delivery, lamp construction, priest installation and tending remain
  future;
- all prospective living humans and olive sources use Joe face if shown;
- Captain remains boilless and causally useless;
- Moses remains on mountain and Joseph bones remain in transport;
- publication remains held and unpublished.

Continuation required: Exodus 28 reconstructs Aaron/sons priest selection,
holy garments, ephod stones/chains, judgment breastplate and Urim/Thummim,
robe bells/pomegranates, forehead plate, tunics, underwear and death-prevention
wearing rules.
