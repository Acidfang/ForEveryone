# CRACKHEAD EXODUS 15

## Title page

**YOU HAVE GUIDED THEM TO YOUR HOLY HOME.**

**YOU WILL BRING THEM THERE.**

Source parent: Exodus chapter 15, verses 1–27, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 15.

Prepared evidence: `.chapter-work/CHB-EXO-015/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/014-YOU-WILL-NEVER-SEE-THEM-AGAIN-YOU-SEE-THEM-DEAD.md`.

CrackFlix routing: repeated `S070-E002-EXO15 — GUIDED TO THE HOLY HABITATION / WILL BRING THEM IN`.

## Causal foundation

```text
SEA CROSSING/EGYPTIAN DEATH COMPLETE
-> MOSES + ISRAEL SING TO LORD
-> SONG ATTRIBUTES TRIUMPH/HORSE-RIDER/SEA/POWER/WIND/HAND/WATERS
-> SONG QUOTES ENEMY INTENT
-> SONG: GOD HAS GUIDED REDEEMED PEOPLE TO HOLY HABITATION
-> CURRENT STATE: PEOPLE BESIDE RED SEA / NOT AT NAMED HABITATION
-> SONG: GOD WILL BRING/PLANT THEM IN FUTURE MOUNTAIN/SANCTUARY
-> NARRATOR RESTATES HORSES/CHARIOTS/HORSEMEN SEA ACT + ISRAEL DRY CROSSING
-> MIRIAM + WOMEN TIMBRELS/DANCE/ANSWER SONG
-> MOSES LEADS RED SEA -> SHUR
-> THREE DAYS / NO WATER
-> MARAH WATER FOUND / BITTER / UNDRINKABLE
-> PEOPLE MURMUR: WHAT SHALL WE DRINK?
-> MOSES CRIES / LORD SHOWS TREE / MOSES THROWS IT
-> WATER MADE SWEET
-> STATUTE/ORDINANCE/TEST + CONDITIONAL DISEASE/HEALING SPEECH
-> ELIM: 12 SPRINGS + 70 PALMS / CAMP BY WATER
```

## Exodus 15:1–12 — THE SONG IS SPEECH

Moses and Israel sing to the LORD. The source marks the following material as
their song and statements. The ledger therefore retains each claim as
attributed lyric rather than silently converting every image into narrator
mechanics.

They sing that the LORD:

- triumphed and threw horse/rider into sea;
- is strength, song, salvation, God, father-God, man of war and named LORD;
- cast Pharaoh's chariots/army into sea and chosen captains sank;
- used deeps, right hand, power, wrath and nostril blast;
- piled waters, stood floods upright and congealed deeps;
- answered the quoted enemy pursuit/overtake/plunder/desire/sword intention;
- blew wind so sea covered them and they sank like lead;
- is unmatched among gods, holy, praised and wonder-doing;
- stretched a right hand so earth swallowed them.

The previous chapter directly narrated sea division, water return and Egyptian
overthrow. `EARTH SWALLOWED`, `NOSTRIL BLAST`, `LIKE LEAD` and the enemy's full
internal-sounding script remain song speech. The singer may quote an enemy; the
source does not supply a prior enemy utterance with those exact lines. No
literal anatomy, material density or hidden transcript is invented.

## Exodus 15:13–18 — ALREADY THERE / WILL GO THERE

The song says:

> **YOU HAVE LED THE PEOPLE YOU HAVE REDEEMED.**

> **YOU HAVE GUIDED THEM IN YOUR STRENGTH TO YOUR HOLY HABITATION.**

At the retained Moment, Israel has just crossed the sea and has not entered the
future mountain/sanctuary location described later in the same song.

The song then attributes heard/trembling/pangs/dismay/melting/terror/dread to
Philistia, Edom, Moab and Canaan populations. These are singer claims; this
chapter does not narrate messengers reaching those peoples or independently
observe their responses.

Then the song says:

> **YOU WILL BRING THEM IN AND PLANT THEM IN THE MOUNTAIN OF YOUR INHERITANCE.**

> **THE SANCTUARY YOUR HANDS HAVE ESTABLISHED.**

S070-E002 closes:

```text
SONG: HAVE GUIDED THEM TO HOLY HABITATION
-> CURRENT: PEOPLE BESIDE SEA / FUTURE JOURNEY REMAINS
-> SAME SONG: WILL BRING THEM IN AND PLANT THEM THERE
```

Captain's CrackFlix points to the prior completed-before-execution mismatch:

`SKIP -> S070-E001-EXO12 / I HAVE DONE IT. IT HAS NOT HAPPENED YET.`

> **CAPTAIN CRACKHEAD:** `SEEN THIS BEFORE. SKIP.`

His eyes glaze. The entire future-location stanza is still sung.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the tense boil, licks his finger and walks away without looking back.
Israel remains beside the sea and later travel remains required.

The final lyric says the LORD will reign forever. This is future/general song
speech, not a chapter-bounded performed act requiring a new panel.

## Exodus 15:19–21 — MIRIAM'S ANSWER

The narrator restates the sea relation: Pharaoh's horses/chariots/horsemen went
in; the LORD returned waters; Israel walked on dry ground in the sea.

Miriam is introduced as prophetess and sister of Aaron. The source does not
explicitly identify her as the unnamed sister who watched Moses' basket, so the
ledger protects both roots and leaves that identity relation unresolved.

Miriam takes a tambourine. All women go after her with tambourines and dances.
She answers them with the opening triumph/horse/rider/sea refrain. This is a new
performance of the refrain, not a new contradiction occurrence.

## Exodus 15:22–24 — THREE DAYS / NO DRINKABLE WATER

Moses leads Israel onward from the Red Sea into Shur wilderness. They travel
three days and find no water. At Marah they find water but cannot drink it
because it is bitter; the place name is tied by the source note to `bitter`.

The people murmur against Moses:

> **WHAT SHALL WE DRINK?**

This is a direct resource question following three days without found water and
an undrinkable-water State. No ingratitude diagnosis, death prediction or
private motive is inserted.

## Exodus 15:25–26 — TREE IN / WATER SWEET

Moses cries to the LORD. The LORD shows him a tree. Moses throws it into the
waters, and the waters are made sweet.

The source supplies the sequence but not chemical mechanism, tree species,
quantity, taste measurement or who drinks. Crackhead science may label every
instrument `CRACKHEAD`, but it may not replace the observed chain:

```text
BITTER / CANNOT DRINK
-> LORD SHOWS TREE
-> MOSES THROWS TREE INTO WATER
-> WATER MADE SWEET
```

There a statute and ordinance are made and the people are tested. The following
speech gives a conditional chain: diligent listening, doing right, attending
commands and keeping statutes -> none of the diseases put on Egyptians put on
Israel. The speaker identifies as `THE LORD WHO HEALS YOU.`

The condition has not yet been evaluated over future acts, and no disease is
applied or healed in this chapter. `PUT DISEASES` and `HEALS` concern different
relations and do not alone form a contradiction.

## Exodus 15:27 — ELIM INVENTORY

Israel reaches Elim. The source counts 12 springs and 70 palm trees. They camp
there by the waters.

Springs and palms receive separate inventory addresses. Palm trees are living
and therefore Joe-faced. Water and springs are not declared organisms; a visual
interpretation may still put Joe face on anything perceived as having a face.

Joseph's bones remain in transport. The chapter neither buries nor relocates
them to a final resting place.

## Character and world-ledger changes

- Moses/Israel become collective song performers whose claims remain attributed;
- S070 gains a repeated singer-level completed-before-arrival occurrence;
- Miriam enters as named prophetess/Aaron sister, tambourine leader and refrain
  speaker; unnamed Exodus 2 sister identity remains unresolved;
- women enter as collective tambourine/dance performers without individual
  identities or dialogue invented;
- Israel travels Red Sea to Shur to Marah to Elim;
- Marah water changes bitter/undrinkable to sweet after the tree act;
- statute/ordinance/test and conditional disease/healing relation are established;
- Elim gains exact 12-spring/70-palm/camp inventory;
- Joseph bones remain moving with the people; burial open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS: THE MUSICAL — FACTS MAY RHYME`;
- lyric warning: `ATTRIBUTED SONG / NOT NARRATOR TELEMETRY`;
- enemy karaoke: `I WILL PURSUE / OVERTAKE / DIVIDE / DESTROY`;
- holy-home tracker: `ARRIVED: PAST TENSE / ARRIVAL: FUTURE TENSE`;
- CrackFlix: `S070 EPISODE 2 — DESTINATION PRE-COMPLETED`;
- Miriam equipment: `CRACKHEAD PROPHETESS TAMBOURINE MK I`;
- water report: `NONE -> BITTER -> TREE -> SWEET`;
- statute console: `LISTEN/DO/ATTEND/KEEP -> DISEASE FILTER`;
- Elim resort sign: `12 SPRINGS / 70 PALMS / ZERO ROOM SERVICE`;
- barcode: `CHB-EXO15-S070E002-27-YOINK`.

## FIR verification

- all 27 verse markers are represented in order;
- song claims, narrator statements and later direct speech remain distinct;
- S070-E002 closes from completed tense/current location/future tense without
  assuming what `holy habitation` physically is;
- SKIP points to exact S070-E001 and does nothing;
- foreign-population emotional States remain song attribution;
- Miriam is not silently merged with the unnamed Exodus 2 sister;
- bitter-to-sweet water chain retains source sequence without invented science;
- disease/healing condition remains untested future relation;
- no extra crack is manufactured from poetic imagery;
- direct LORD actions/speech remain God-only;
- Captain remains boilless and causally useless;
- Joseph bones transport remains active and burial open;
- publication remains held and unpublished.

Continuation required: Exodus 16 reconstructs food complaints, Egypt-pot speech,
bread-from-heaven instructions, daily/sixth/seventh collection States, manna
identity/naming, preserved omer and forty-year food duration.
