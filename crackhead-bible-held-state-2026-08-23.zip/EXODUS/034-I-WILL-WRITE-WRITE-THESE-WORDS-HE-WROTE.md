# CRACKHEAD EXODUS 34

## Title page

**I WILL WRITE ON THE TABLETS.**

**WRITE THESE WORDS. HE WROTE ON THE TABLETS.**

Source parent: Exodus chapter 34, verses 1–35, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-EXO-034/job.json` and `source.usfm`.

Parent manuscript: `EXODUS/033-FACE-TO-FACE-YOU-CANNOT-SEE-MY-FACE.md`.

CrackFlix routing:

- `SKIP -> S094-E001-EXO33` for the retained no-presence/presence negotiation;
- `S096-E001-EXO34 — I WILL WRITE / MOSES WRITE / HE WROTE`;
- `S097-E001-EXO34 — FORGIVING SIN / NEVER CLEARING THE GUILTY`.

## Causal foundation

```text
FIRST TABLETS BROKEN
-> MOSES CHISELS TWO REPLACEMENTS
-> MOSES ASCENDS ALONE
-> LORD DESCENDS / STANDS / PROCLAIMS NAME / PASSES
-> MERCY + GRACE + FORGIVENESS + NO-CLEARING + GENERATIONAL VISITATION SPOKEN
-> MOSES WORSHIPS / REQUESTS PRESENCE + PARDON + INHERITANCE
-> COVENANT + MARVELS + LAND RULES SPOKEN
-> FESTIVAL/FIRSTBORN/SABBATH/SACRIFICE RULES REPEATED
-> MOSES ORDERED TO WRITE WORDS
-> FORTY DAYS/NIGHTS WITHOUT BREAD OR WATER
-> COVENANT WORDS/TEN COMMANDMENTS WRITTEN ON TABLETS
-> MOSES DESCENDS WITH TABLETS
-> MOSES' FACE SHINES WITHOUT HIS KNOWLEDGE
-> AARON/ISRAEL FEAR, THEN RETURN WHEN CALLED
-> COMMANDS DELIVERED
-> VEIL ON AFTER SPEECH / OFF BEFORE LORD / ON AGAIN
```

## Exodus 34:1–4 — REPLACEMENT TABLETS

The LORD tells Moses to chisel two stone tablets like the first. God says he
will write on them the words that were on the tablets Moses broke. Moses must
be ready in the morning, ascend Sinai and present himself alone; no person may
be seen on the mountain and no flock or herd may graze before it.

Moses chisels the two tablets, rises early, ascends as commanded and carries
them in his hand. The replacement stone shaping is Moses' observed work. The
writing is still future at this point.

## Exodus 34:5–9 — THE NAME PASSES BY

The LORD descends in cloud, stands with Moses and proclaims the LORD's name.
The LORD passes before Moses and proclaims:

- merciful and gracious God;
- slow to anger;
- abundant in loving kindness and truth;
- keeping loving kindness for thousands;
- forgiving iniquity, disobedience and sin;
- by no means clearing the guilty;
- visiting fathers' iniquity on children and children's children through the
  third and fourth generation.

S097-E001 retains the unresolved allocation between forgiving sin and never
clearing the guilty. The source supplies neither a subject split, repentance
condition, payment system nor timing bridge.

Captain Crackhead: **YOINK!**

He pokes the forgiveness/no-clearing boil, licks his finger and walks away
without looking back. Moses continues.

Moses hurries, bows and worships. He asks the Lord to go among the stiff-necked
people, pardon iniquity/sin and take them as inheritance.

Captain presses private CrackFlix:

> **SKIP -> S094-E001**

His eyes glaze. Moses finishes the request. Nothing skips and nothing changes
because of Captain.

## Exodus 34:10–17 — COVENANT AND LAND BOUNDARIES

God announces a covenant and future unprecedented marvels visible to all people
around Israel. Israel must observe current commands. God promises to drive out
six named peoples.

Israel must not covenant with land inhabitants; it must break their altars,
pillars and Asherah poles and worship no other god. The LORD's name is stated as
Jealous. The supplied future chain warns that covenant, sacrifice invitation,
eating and intermarriage can lead Israel's sons into worship described as
prostitution after other gods. No such future act occurs here.

The command not to make cast idols repeats the retained rule after the calf
occurrence. A repeated rule plus a past violation is not automatically a new
contradiction occurrence; no new idol is made.

## Exodus 34:18–26 — REPEATED OPERATING RULES

The chapter repeats and retains:

- seven-day unleavened-bread feast in Abib because Israel came from Egypt;
- womb-openers and male firstborn livestock belong to the LORD;
- donkey firstborn redeemed with lamb or neck broken;
- all firstborn sons redeemed;
- no one appears empty;
- six work days and seventh-day rest, including plowing/harvest;
- feast of weeks with wheat firstfruits and year-end harvest feast;
- three annual appearances of all males before the Lord GOD;
- promised nation displacement, enlarged borders and no land desire during
  annual appearance;
- no sacrificial blood with leaven;
- no Passover sacrifice left to morning;
- first of firstfruits brought to God's house;
- no boiling a young goat in its mother's milk.

These are commands and promises, not performed festival, farming, redemption,
appearance, border, sacrifice, cooking or invasion events.

## Exodus 34:27–28 — WHO WRITES THE TABLETS

The LORD tells Moses:

> **WRITE THESE WORDS.**

God says the covenant with Moses and Israel is made according to these words.
Moses remains with the LORD forty days and nights and neither eats bread nor
drinks water. The narrator then says `he wrote on the tablets` the covenant
words, the Ten Commandments.

S096-E001 closes against verse 1:

```text
LORD: I WILL WRITE ON THE TABLETS
-> LORD TO MOSES: WRITE THESE WORDS
-> NARRATOR: HE WROTE ON THE TABLETS
```

The nearest grammatical actor in the continuing human stay is Moses, while the
pronoun itself remains supplied rather than silently renamed. Earlier tablets
were explicitly God's writing. No instrument, dictation relation or split
between separate documents is supplied here.

*shrug*

Crack.

Captain Crackhead: **YOINK!**

He pokes the writer-assignment boil, licks his finger and walks away without
looking back. The tablets remain written.

## Exodus 34:29–35 — SHINY MOSES FACE PROTOCOL

Moses descends Sinai carrying the two covenant tablets. He does not know the
skin of his face shines because of speaking with the LORD. Aaron and Israel see
the shining face and are afraid to approach. Moses calls them; Aaron and all
rulers return, then all Israel comes near. Moses gives them every command the
LORD spoke on Sinai.

When Moses finishes speaking, he puts a veil over his face. When he goes before
the LORD to speak, he removes it until coming out. He comes out, delivers the
commands, Israel sees the shining skin, and Moses replaces the veil until the
next entry.

The source supplies the shine relation and Moses' initial lack of knowledge. It
does not supply light intensity, heat, duration, fabric, fear motive beyond
observed fear, medical effect or whether the shine changes under the veil.

## Character and world-ledger changes

- Moses makes replacement tablets, ascends alone, stays forty days/nights
  without bread/water, descends carrying written tablets and begins a repeatable
  veil/meeting/speech cycle;
- Moses' face now observably shines after divine speech, initially without his
  knowledge;
- Aaron, rulers and Israel first fear approach, then return/come near when
  Moses calls and receive all commands;
- the replacement tablets advance from shaped stone to written covenant tablets
  and arrive in camp intact;
- the prior broken tablets remain a retained parent, not overwritten;
- S094 receives a valid continuation pointer without a new episode;
- S096 records unresolved replacement-tablet writer assignment;
- S097 records forgiveness against no-clearing wording;
- Joseph's bones remain in transport and burial remains open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — TABLET WARRANTY REPLACEMENT`;
- stone ticket: `CUSTOMER CHISELS / AUTHORSHIP MULTISELECT`;
- name card: `MERCY + GRACE + FORGIVE + NEVER CLEAR`;
- CrackFlix: `SKIP -> S094-E001 / REQUEST CONTINUES`;
- covenant patch notes: `SIX NATIONS / ALTARS DELETE / INTERMARRIAGE WARNING`;
- schedule: `3 APPEARANCES / LAND DESIRE FIREWALL ENABLED`;
- fast counter: `40 DAYS + 40 NIGHTS / INPUT 0 BREAD 0 WATER`;
- face warning: `CRACKHEAD RADIANCE / USER UNAWARE`;
- veil mode: `LORD IN = OFF / PEOPLE DONE = ON`;
- barcode: `CHB-EXO34-S094SKIP-S096-S097-35-2YOINK`.

## FIR verification

- all 35 verse markers are represented in order;
- replacement tablets preserve the first broken-tablet lineage;
- proclaimed attributes remain direct divine self-description;
- S097 does not invent a forgiveness/acquittal doctrine or subject partition;
- S094 pointer addresses the exact retained presence negotiation and changes no
  State;
- repeated covenant rules remain repetitions, not invented new occurrences;
- S096 preserves verse 1, verse 27 and verse 28 writer statements plus pronoun
  ambiguity;
- forty-day fasting, descent, shine, fear, calling, approach and veil operations
  remain observed source States;
- shining-face cause is retained exactly as narrator attribution;
- no future marvel, displacement, land occupation, festival or border-protection
  effect is marked performed;
- Captain has no boils, says exactly `YOINK!`, and affects nothing;
- all living beings use Joe face if shown;
- publication remains held and unpublished.

Continuation required: Exodus 35 reconstructs Sabbath repetition, voluntary
materials, named skilled workers and the beginning assembly for construction.
