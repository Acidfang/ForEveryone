# CRACKHEAD EXODUS 18

## Title page

**WHY DO YOU SIT ALONE?**

**WHY DO ALL THE PEOPLE STAND FROM MORNING TO EVENING?**

Source parent: Exodus chapter 18, verses 1–27, ENGWEBP USFM.

Source file: `source/engwebp-usfm/03-EXOengwebp.usfm`, chapter 18.

Prepared evidence: `.chapter-work/CHB-EXO-018/job.json` and `source.usfm`.

Parent manuscript:
`EXODUS/017-WRITE-A-MEMORIAL-I-WILL-BLOT-OUT-THE-MEMORY.md`.

CrackFlix routing: no closed contradiction episode.

## Causal foundation

```text
JETHRO HEARS GOD/LORD-DELIVERANCE REPORT
-> JETHRO HAS ZIPPORAH AFTER MOSES SENT HER AWAY + TWO SONS
-> GERSHOM NAME/FOREIGNER SPEECH RESTATED
-> ELIEZER NAMED / FATHER'S-GOD-HELP/PHARAOH-SWORD SPEECH
-> JETHRO + ZIPPORAH + SONS COME TO MOSES AT GOD'S MOUNTAIN
-> JETHRO ANNOUNCES ARRIVAL
-> MOSES MEETS/BOWS/KISSES / WELFARE QUESTIONS / TENT
-> MOSES REPORTS LORD ACTS/HARDSHIPS/DELIVERANCE
-> JETHRO REJOICES / BLESSES LORD / STATES LORD GREATER
-> JETHRO TAKES BURNT OFFERING + SACRIFICES FOR GOD
-> AARON + ELDERS EAT BREAD WITH JETHRO BEFORE GOD
-> NEXT DAY MOSES JUDGES ALONE
-> PEOPLE STAND AROUND FROM MORNING TO EVENING
-> JETHRO OBSERVES + QUESTIONS PROCESS
-> MOSES: PEOPLE INQUIRE OF GOD / MATTERS COME / I JUDGE + TEACH LAW
-> JETHRO: NOT GOOD / BOTH WILL WEAR AWAY / TOO HEAVY / CANNOT ALONE
-> COUNSEL: MOSES REPRESENT/BRING CAUSES/TEACH
-> SELECT ABLE GOD-FEARING TRUTH MEN HATING UNJUST GAIN
-> RULERS 1000/100/50/10
-> ALL-TIME JUDGMENT / GREAT TO MOSES / SMALL LOCALLY
-> CONDITION: IF THIS + GOD COMMANDS -> ENDURE + PEOPLE GO IN PEACE
-> MOSES LISTENS + DOES ALL JETHRO SAID
-> CHOOSES/INSTALLS RULERS
-> RULERS JUDGE / HARD TO MOSES / SMALL THEMSELVES
-> MOSES SENDS JETHRO / JETHRO RETURNS OWN LAND
```

## Exodus 18:1–6 — THE FAMILY ARRIVAL LEDGER

Jethro is identified as priest of Midian and Moses' father-in-law. He hears all
that God did for Moses and Israel and that the LORD brought Israel out of
Egypt.

Jethro had received Zipporah after Moses sent her away. Exodus 4 last showed
Zipporah and plural sons travelling toward Egypt and records no sending-away
act. Exodus 18 now reports that act retrospectively but supplies no time,
place, messenger, reason, route or words. The ledger retains the new report
without inserting it into an invented earlier panel.

The two sons are named:

- Gershom, already retained from Exodus 2, with Moses' foreigner-in-foreign-land
  naming speech restated;
- Eliezer, newly named here, with Moses' statement that his father's God helped
  and delivered him from Pharaoh's sword.

This Eliezer is Moses' son. He is not Abram's Damascus household-heir candidate
from Genesis 15 merely because the spelling matches.

Jethro comes with Zipporah and the sons to Moses in the wilderness at God's
mountain. He announces exactly who has arrived. The source calls him Jethro;
Exodus 2 called the priest/father relation Reuel. No name-change or
same-person declaration closes that relation, so both roots remain protected
and their exact equivalence remains unresolved.

## Exodus 18:7–12 — REPORT / RESPONSE / BREAD

Moses goes out, bows to and kisses his father-in-law. They ask each other about
welfare and enter the tent. The source does not separately narrate Moses
greeting Zipporah or either son, so no reunion dialogue or reaction is added.

Moses tells Jethro all the LORD did to Pharaoh and Egypt for Israel, the
hardships on the way and the LORD's deliverance. Jethro had already heard a
summary; Moses now performs a direct report. Because the exact earlier report
content is not supplied, this is not a verified duplicate segment and receives
no SKIP.

Jethro rejoices, blesses the LORD and states that the LORD delivered the people
and is greater than all gods because of the way `they` acted arrogantly. The
rejoicing, knowledge and comparison are source-attributed Jethro States; no
private conversion system or identity for `all gods` is invented.

Jethro takes a burnt offering and sacrifices for God. Aaron and all Israel's
elders come to eat bread with him before God. Animals implied by sacrifice are
living and Joe-faced if shown, but the source gives no species, count,
slaughter actor or portion inventory.

## Exodus 18:13–16 — ONE-JOE JUDGMENT DEPARTMENT

The next day Moses sits to judge the people. The people stand around him from
morning until evening.

Jethro observes the process and asks:

> **WHAT IS THIS THING YOU DO FOR THE PEOPLE?**

> **WHY DO YOU SIT ALONE?**

> **WHY DO ALL THE PEOPLE STAND AROUND YOU FROM MORNING TO EVENING?**

Moses answers that the people come to him to inquire of God. When they have a
matter, they come to him; he judges between a person and neighbor and makes
known God's statutes and laws.

The queue duration, single judge, dispute relation and teaching function are
observable. No case count, average service time, error rate, priority rule,
bribe, laziness diagnosis or failed judgment is supplied.

## Exodus 18:17–23 — FILTER / ISOLATE / RECONSTRUCT THE QUEUE

Jethro says the thing Moses does is not good. He predicts Moses and the people
will wear away because the work is too heavy and Moses cannot perform it alone.
The chapter has observed a morning-to-evening queue; it has not yet observed
either predicted party actually wearing away.

Jethro's counsel preserves Moses' required functions:

- represent the people before God;
- bring causes to God;
- teach statutes and laws;
- show the people the way to walk and work to do.

Then it isolates delegable judgment:

- select able men from all the people;
- selection description: fear God, truth, hate unjust gain;
- install rulers of thousands, hundreds, fifties and tens;
- let them judge at all times;
- route every great matter to Moses;
- let them judge every small matter themselves;
- share the load.

This is not `MOSES DOES NOTHING NOW`. It is a boundary rewrite:

```text
WAS: EVERY MATTER -> MOSES
DID: CLASSIFY + DISTRIBUTE JUDGES
IS: SMALL MATTER -> LOCAL RULER
    HARD/GREAT MATTER -> MOSES
    TEACHING/GOD-REPRESENTATION -> MOSES
```

Jethro's final outcome is conditional:

> **IF YOU DO THIS, AND GOD COMMANDS YOU SO,**

> **YOU WILL ENDURE, AND THE PEOPLE WILL GO TO THEIR PLACE IN PEACE.**

No direct God-command act appears in this chapter, and the terminal endurance
and peace States are not independently narrated. Therefore the condition
remains open. It cannot validly produce `JETHRO SAID IT / GOD DIDN'T` crack.

## Exodus 18:24–26 — THE NEW PROCESS RUNS

Moses listens to Jethro and does all that he said. He chooses able men from all
Israel and makes them heads/rulers over thousands, hundreds, fifties and tens.

The new process then runs:

```text
RULERS JUDGE AT ALL TIMES
-> HARD CASES GO TO MOSES
-> EVERY SMALL MATTER JUDGED BY RULERS
```

The implementation proves delegation and routing. It does not prove every
candidate possessed every stated character criterion, that God issued the
conditional command, that no queue remained, or that Moses/people endured in
peace. No contradiction closes in this chapter.

This is FIR performed inside the story: Jethro filters the observed all-day
load, isolates the relations that only Moses retains, reconstructs the rest as
bounded local judgment, and the new process executes without erasing the parent
process or Moses' remaining authority.

## Exodus 18:27 — JETHRO LEAVES

Moses lets his father-in-law depart. Jethro goes to his own land. Zipporah,
Gershom and Eliezer are not said to leave with him. Their exact post-arrival
location remains with the camp relation unless a later source moves them, but
individual tent placement is not invented.

Joseph's bones remain in transport. This chapter neither mentions nor buries
them.

## Character and world-ledger changes

- Jethro continues as named Midian priest/father-in-law while Reuel equivalence
  remains unresolved;
- Zipporah returns to Moses' camp after a newly reported, undated sending-away
  act;
- Gershom's identity and naming speech continue;
- Eliezer enters as a distinct second son of Moses/Zipporah;
- Moses/Jethro gain greeting, report, counsel, adoption and departure history;
- Aaron/elders join Jethro's sacrifice-adjacent bread meal before God;
- Israel's dispute/inquiry system changes from one all-day Moses queue to
  tiered rulers with hard-case escalation;
- selected rulers enter as collective officeholders without names or personal
  histories invented;
- no direct God speech or current visible God act occurs in this chapter;
- no contradiction series or episode is added;
- Joseph bones remain moving; burial open.

## Bullshit pass

- banner: `CRACKHEAD EXODUS — MIDIAN FAMILY & PROCESS CONSULTING`;
- arrival ticket: `WIFE + TWO SONS / PREVIOUS SEND EVENT NOT FOUND`;
- identity warning: `ELIEZER != E-LAZY-ER OF DAMASCUS`;
- report terminal: `HEARD ALL / PLEASE TELL ME ALL`;
- lunch sign: `BREAD BEFORE GOD — OFFERING SKU UNSPECIFIED`;
- queue display: `NOW SERVING: MORNING / ESTIMATED WAIT: EVENING`;
- Moses desk: `ONE-JOE WHOLE-NATION SUPPORT PLAN`;
- Jethro audit: `NOT GOOD / TOO HEAVY / PLEASE ADD JOES`;
- org chart: `1000 -> 100 -> 50 -> 10 -> SMALL HERE / HARD UPSTAIRS`;
- FIR sticker: `FILTER CASE / ISOLATE SIZE / RECONSTRUCT ROUTE`;
- CrackFlix screen: `NO CRACK FOUND — PROCESS ACTUALLY UPDATED`;
- barcode: `CHB-EXO18-NO-EPISODE-27`.

## FIR verification

- all 27 verse markers are represented in order;
- Jethro's hearing and Moses' later report are not declared exact duplicates;
- the Exodus 4-to-18 Zipporah sending gap is retained without backfilled event;
- Gershom continues and Moses-son Eliezer remains distinct from Genesis Eliezer;
- Reuel/Jethro exact identity remains unresolved;
- Jethro's joy/knowledge/theology remain attributed States;
- offering animal species/count and reunion reactions are not invented;
- single-judge load, counsel and implemented delegation preserve exact causal
  order;
- prediction of wearing away is not marked performed;
- God-command/endurance/peace condition remains open;
- implementation does not prove unobserved selection criteria or outcomes;
- no unsupported contradiction, SKIP, crack or Captain appearance is created;
- direct God boundary correctly records no direct speech in this chapter;
- Joseph bones transport remains active and burial open;
- publication remains held and unpublished.

Continuation required: Exodus 19 reconstructs Sinai arrival, covenant proposal,
people's reply, cloud/audience plan, consecration boundaries, mountain effects,
priest warnings and Moses' repeated boundary objection.
