# Crackhead Bible translation contract

## Root

Protect the biblical source address and the Crackheadverse root simultaneously.
The source remains what the source records. The Crackhead rendering is a new,
transformative child that does not silently rewrite its parent.

Front-matter boundary:

> `OFFENDED? IT'S NOT THE BIBLE! LOL.`

## Required retention

For every selected passage retain:

- book, chapter and verse range;
- speakers and observable acts;
- event order and dependencies;
- what changes and what remains;
- explicit promises, commands, prohibitions and consequences;
- unresolved ambiguity rather than an invented motive;
- every cross-passage causal parent required by the rendering.
- the time-bounded people/nation default ledger available to each character;
  use `../world/DEFAULT-PEOPLE-LEDGER.md` and retain `PRE-NATIONAL` when the
  source has not yet derived nations.
- every cross-religious or ancient-text witness relation under
  `../religion/OVERLAP-DEDUP.md`; the same act and its act-defining relations
  import the same canonical panel while every source root and local sequence
  remain separate.

## Crackhead translation

- Every living being has Joe's face.
- Living named characters resolve to retained Joe types; their source names
  remain in the source ledger.
- Crackhead dialogue derives from each Joe type's origin, retained life Moments,
  role, heard speech and current evidence boundary. Generic interchangeable
  profanity is not a voice.
- Proper names that cannot be Joe—places, nations, rivers, mountains, objects
  and institutions—receive slight reconstructable wordplay under
  `../books-of-old/NAMING-RULES.md`.
- Every chapter performs and records a fuck-up pass over names, ordinary words,
  commands and phrases after causal reconstruction and before bullshit.
- Biblical character types receive origin and life ledgers.
- Clothing and mannerisms derive from retained history and environment.
- A contradiction maps to one exact CrackFlix series in every context.
- A branch to another contradiction emits `SKIP -> <series>` only after the
  receiving series and continuation exist.
- God-only lines are spoken by Crackhead God only when their trigger derives.
- Nobody listens to God unless the source event observably requires a response;
  response still does not imply understanding or obedience.
- Captain can appear only as a useless observer. Removing him changes nothing.
- Biblical miracles and acts remain source events; the translation does not
  invent an alternative physical explanation for them.
- Foundation precedes bullshit.
- A shared act is never redrawn per religion: `SAME ACT ID -> SAME
  PANEL ID`. Witness-only details branch outside the shared panel.

## Origin-derived speech

For every speaking character retain a speech envelope:

```text
ORIGIN + LIFE HISTORY + ROLE + HEARD WORDS + CURRENT STATE
-> AVAILABLE VOCABULARY
-> SENTENCE SHAPE / RHYTHM
-> WHAT THIS JOE CAN ADDRESS
```

Source dialogue supplies the speech act and causal content. Crackhead rendering
may change wording, profanity, rhythm and literal interpretation while retaining
that act. A Joe cannot cite later doctrine, know an unseen event, adopt another
Joe type's mannerisms, or speak in the author's generic voice without a retained
path.

## No broken chains

Every comic panel, omitted segment, SKIP, cross-book reference and comic series
must be traversable in both directions:

```text
SOURCE PARENT -> CRACKHEAD STATE CHANGE -> RESULT
RESULT -> RETAINED MOMENTS -> SOURCE PARENT
```

If traversal fails, the translation remains incomplete.

## Tone

Ruthless, profane, absurd and self-directed. The work may mock every Joe,
including God-presenting Joe and author-presenting Joe. It may not manufacture a
causal claim merely to land a joke.
