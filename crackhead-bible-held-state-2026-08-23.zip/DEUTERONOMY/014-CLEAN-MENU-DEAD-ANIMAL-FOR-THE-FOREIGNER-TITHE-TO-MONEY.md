# CRACKHEAD DEUTERONOMY 14

## Title page

**CLEAN MENU. DEAD ANIMAL FOR THE FOREIGNER.**

**TITHE TOO HEAVY? TURN IT INTO MONEY.**

Source parent: Deuteronomy chapter 14, verses 1–29, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-014/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/013-THE-SIGN-WORKED-DONT-FOLLOW-HIM-INVESTIGATE-BEFORE-BURNING-THE-CITY.md`.

CrackFlix routing: none. Every food, carcass-recipient and tithe route remains a stated rule without an instantiated case.

## Causal foundation

```text
ISRAEL AS HOLY/CHOSEN CHILDREN
-> NO CUTTING SELF / BALDNESS BETWEEN EYES FOR DEAD

LAND ANIMAL
-> SPLIT HOOF + CHEWS CUD -> MAY EAT
-> ONLY ONE SELECTOR -> MAY NOT EAT / CARCASS NOT TOUCHED

WATER CREATURE
-> FINS + SCALES -> MAY EAT
-> OTHERWISE -> MAY NOT EAT

BIRD/WINGED CREATURE
-> CLEAN CLASS -> MAY EAT
-> LISTED UNCLEAN / WINGED CREEPING CLASS -> MAY NOT EAT

ANIMAL DIES OF ITSELF
-> ISRAEL DOES NOT EAT
-> GATE-FOREIGNER MAY RECEIVE/EAT OR FOREIGNER MAY BUY

ANNUAL FIELD INCREASE
-> TITHE + FIRSTBORN EATEN AT CHOSEN PLACE
-> IF DISTANCE/WEIGHT TOO GREAT: GOODS -> MONEY -> CHOSEN PLACE
-> MONEY -> SELECTED FOOD/DRINK -> HOUSEHOLD MEAL/REJOICING

EVERY THIRD YEAR
-> THAT YEAR'S TITHE STORED WITHIN GATES
-> LEVITE + FOREIGNER + FATHERLESS + WIDOW EAT/SATISFIED
```

## Deuteronomy 14:1–2 — CHILDREN, CHOSEN, NO MOURNING CUTS

Moses addresses Israel as children of the LORD and prohibits cutting themselves
or making baldness between the eyes for the dead. Holiness and selection as a
special possession are supplied as the relation. No death, mourning act,
cutting or shaving occurs.

## Deuteronomy 14:3–20 — THE TWO-FIELD FOOD FILTER

The land-animal permission requires both a split hoof and cud chewing. Ox,
sheep, goat, deer, gazelle, roebuck, wild goat, ibex, antelope and chamois are
listed as edible. Camel, hare and rabbit have the cud field without the split
hoof; pig has the split-hoof field without cud chewing. Those four are excluded,
and their carcasses are not to be touched.

The water selector permits fins plus scales and excludes creatures without both.
Clean birds may be eaten; the listed bird classes may not. Winged creeping
things are excluded while clean flying things are permitted.

These lists join the retained Leviticus 11 food-classification lineage. Similar
selectors and changed list wording do not instantiate animals, merge uncertain
species names or produce a contradiction.

## Deuteronomy 14:21 — SAME DEAD ANIMAL, DIFFERENT RECIPIENT ROUTES

Israel may not eat an animal that dies of itself. The animal may instead be
given to the foreigner within the gates to eat or sold to a foreigner. Recipient
identity selects the stated route; the routes are not silently merged. The same
verse repeats the prohibition on boiling a young goat in its mother's milk.

No animal dies, no carcass is touched, given, sold, bought or eaten, and no goat
is boiled.

## Deuteronomy 14:22–27 — IF THE TITHE IS TOO HEAVY, CARRY MONEY

Israel must tithe each year's field increase. Grain, new wine, oil and herd/flock
firstborn are assigned to a household meal at the place the LORD chooses, with
learning to fear the LORD stated as its purpose. The Levite must not be forsaken
because the Levite has no portion or inheritance with Israel.

If distance makes the goods too heavy to carry, the goods may be converted to
money. The money is bound in the hand, carried to the chosen place and spent on
cattle, sheep, wine, strong drink or whatever food the buyer desires. The
household then eats and rejoices there. Money is an explicit intermediate
carrier; conversion does not erase the tithe's source or destination.

No harvest, tithe, firstborn, conversion, journey, purchase, meal or rejoicing
occurs.

## Deuteronomy 14:28–29 — THIRD YEAR: LEAVE IT IN THE GATES

At the end of every third year, that year's tithe is brought out and stored
within the local gates. The Levite, foreigner, fatherless and widow may come,
eat and be satisfied. Blessing in the work of Israel's hand is stated as the
consequence.

The annual chosen-place route and every-third-year local route carry different
time selectors. Neither cancels the other, and no actual third-year deposit,
recipient arrival, meal, satisfaction or blessing result is narrated.

## Character and world-ledger changes

- mourning-body prohibitions join Israel's holy/chosen identity without a death case;
- land, water and bird food classes join Leviticus 11 without forced species equivalence;
- Israel eater, gate-foreigner recipient and foreign buyer remain distinct carcass routes;
- the young-goat/mother's-milk prohibition repeats without an occurrence;
- annual tithe goods may retain lineage through an explicit money conversion;
- chosen-place and third-year local tithe routes remain time-selected branches;
- Levite, foreigner, fatherless and widow support roles remain prospective;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every prospective living human, animal or flying/water-creature Joe and face-like non-divine coin, gate, hoof, scale, basket or bottle is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — HOLY MENU & TITHE ROUTER`;
- hoof display: `SPLIT: YES / CUD: YES / DINNER: YES`;
- pig warning: `ONE FIELD IS NOT TWO, DICKHEAD`;
- fish scanner: `FINS + SCALES OR FUCK OFF`;
- carcass desk: `ISRAEL: NO / GATE FOREIGNER: GIVE / FOREIGNER: SELL`;
- goat cooker: `MOTHER'S MILK INPUT REJECTED AGAIN`;
- distance alert: `TITHE MASS EXCEEDS HAND-CARRY LIMIT`;
- conversion terminal: `GOODS -> MONEY -> GOODS`;
- shopping prompt: `WHATEVER YOUR SOUL ASKS FOR`;
- third-year bin: `LEAVE THE WHOLE LOT IN THE GATES`;
- barcode: `CHB-DEU14-29-CLASSIFIERS-ROUTES-NOCASE-NOCRACK-HELD`.

## FIR verification

- all 29 verse markers are represented in order;
- holiness and mourning prohibitions remain attributed speech, not observed acts;
- animal classifiers remain exact conjunctive or listed-class selectors;
- uncertain animal names are not merged with later identities;
- the Israel/foreigner carcass routes remain recipient-specific;
- money conversion retains the source tithe and chosen-place destination;
- annual and third-year tithe branches retain their time selectors;
- no animal, meal, sale, tithe, conversion, distribution or blessing occurrence is invented;
- no unsupported contradiction machinery appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 15 joins seventh-year debt release, poor-person
support, released servant provisioning, firstborn use restrictions and another
non-blood carcass meal route.
