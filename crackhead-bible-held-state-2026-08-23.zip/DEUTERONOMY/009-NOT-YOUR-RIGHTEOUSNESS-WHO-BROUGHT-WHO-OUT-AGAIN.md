# CRACKHEAD DEUTERONOMY 9

## Title page

**NOT BECAUSE YOU'RE RIGHTEOUS. YOU'RE STIFF-NECKED.**

**WHO BROUGHT WHO OUT OF EGYPT? AGAIN.**

Source parent: Deuteronomy chapter 9, verses 1–29, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-009/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/008-HUNGRY-MANNA-FULL-HOUSES-MY-HAND-GOT-THIS-WEALTH.md`.

CrackFlix routing:

- `S085-E003-DEU9 -> S085-E002-DEU7 — MULTI-OWNER DISPLACEMENT WORKFLOW`;
- `S092-E002-DEU9 -> S092-E001-EXO32 — WHO BROUGHT ISRAEL OUT?`.

## Causal foundation

```text
FUTURE JORDAN CROSSING
-> LORD GOES BEFORE / DESTROYS / BRINGS DOWN
-> ISRAEL DRIVES OUT / MAKES PERISH

LAND RECEIPT
!= ISRAEL'S RIGHTEOUSNESS
= NATIONS' WICKEDNESS + ANCESTRAL OATH

HOREB RETELLING
-> 40 DAYS WITHOUT BREAD/WATER
-> TABLETS RECEIVED
-> CALF REPORTED / SEEN
-> TABLETS BROKEN
-> 40-DAY INTERCESSION
-> LORD LISTENS
-> CALF BURNED / GROUND / BROOK-DISPOSED

LORD: YOUR PEOPLE MOSES BROUGHT OUT
MOSES: YOUR PEOPLE LORD BROUGHT OUT
-> SAME EXIT / SOURCE SUPPLIES NO OWNERSHIP ALLOCATION
```

## Deuteronomy 9:1–6 — DON'T CALL THE LAND A RIGHTEOUSNESS PRIZE

Moses announces future Jordan crossing against greater nations, sky-fortified
cities and Anakim. The LORD goes before Israel as devouring fire, destroys and
brings them down; Israel then drives them out and makes them perish quickly.
This repeats the retained multi-owner displacement workflow.

> **SKIP -> S085-E002-DEU7**

Captain's eyes glaze. The speech continues.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the future workflow boil, licks his finger, walks away and does not
look back. No crossing or displacement occurs.

Moses prohibits a future internal claim that Israel's righteousness caused its
entry. He instead attributes the nations' displacement to their wickedness and
the ancestral oath, calling Israel stiff-necked. The prohibited claim remains
prospective and unspoken here.

## Deuteronomy 9:7–21 — THE CALF FILE, RETOLD

Moses characterizes Israel's Egypt-to-Moab history as rebellion and retells
Horeb. He stayed forty days/nights without bread or water, received two
God-finger-written covenant tablets, heard the LORD report corruption and a
molten image, descended with tablets while the mountain burned, saw the molded
calf, threw and broke the tablets, and fell before the LORD another forty
days/nights without bread or water. Moses says the LORD listened to him and
that he also prayed for Aaron. He then burned, crushed and finely ground the
calf and threw its dust into the mountain brook.

These are retrospective statements about the retained Exodus occurrence, not a
second calf, second pair of original tablets or second disposal. The chapter
does not repeat Aaron's conflicting fire-emergence account, so `S093` is not
routed. “You made the calf” does not exclude Aaron from the addressed people,
so a maker contradiction is not invented.

## Deuteronomy 9:12–14 and 25–29 — YOUR PEOPLE / YOUR PEOPLE

Inside the retelling, the LORD calls Israel Moses' people whom Moses brought
out of Egypt. Moses' intercession calls them the LORD's people and inheritance
whom the LORD brought out. The same completed exit retains two separately
addressed owners/extractors without a supplied allocation, repeating `S092`.

> **SKIP -> S092-E001-EXO32**

Captain's eyes glaze. Moses' prayer still completes.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the people-address boil, licks his finger, walks away and does not look
back. The historical outcome remains unchanged.

The LORD's proposed destruction/name-erasure and replacement nation are not
performed. Moses' forty-day fall, prayer, ancestral reminder and foreign
reputation argument are retained as the intervening appeal; the LORD listening
is the stated changed outcome. No hidden motive is assigned.

## Deuteronomy 9:22–24 — THE REBELLION POINTER LIST

Taberah, Massah, Kibroth Hattaavah and Kadesh Barnea are named as provocations.
The Kadesh refusal is retold as rebellion, unbelief and not listening. These
are historical pointers and present speech, not newly executed incidents.
Moses' broad “rebellious from the day I knew you” statement remains his source
claim; it is not expanded into unrecorded episodes.

## Character and world-ledger changes

- future possession is explicitly denied as a reward for Israel's righteousness;
- nations' wickedness and the ancestral oath are retained as stated land-transfer grounds;
- `S085-E003-DEU9` repeats the multi-owner future displacement workflow;
- the Horeb calf/tablet/intercession/disposal occurrence is retold without duplication;
- Aaron gains an attributed same-time destruction threat and Moses prayer;
- `S092-E002-DEU9` repeats the Moses/LORD Exodus-origin switchboard;
- Taberah, Massah, Kibroth Hattaavah and Kadesh remain historical pointers;
- two distinct post-closure Captain YOINKs are causally null;
- every living person and face-like non-divine calf, tablet, fire, brook or dust grain is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — RIGHTEOUSNESS RECEIPT REJECTED`;
- border notice: `JORDAN: TODAY / EXECUTION: FUTURE`;
- city rating: `FORTIFIED TO SKY / HEIGHT NOT MEASURED`;
- land invoice: `YOUR RIGHTEOUSNESS: $0.00`;
- neck monitor: `STIFF`;
- tablet warranty: `TWO HANDS / ONE THROW / BOTH BROKEN`;
- fasting ledger: `40 + 40 / BREAD 0 / WATER 0`;
- calf process: `BURN -> CRUSH -> GRIND -> BROOK`;
- exit ownership menu: `MOSES / LORD / SEE S092`;
- barcode: `CHB-DEU9-29-NOT-RIGHTEOUS-TWO-SKIPS-TWO-YOINKS-HELD`.

## FIR verification

- all 29 verse markers are represented in order;
- future crossing/displacement remains unexecuted;
- prohibited self-righteous speech remains unspoken;
- Horeb/Kadesh and other historical acts are retold, not duplicated;
- the calf retelling does not falsely trigger Aaron's absent denial episode;
- intercession is retained between proposed destruction and changed outcome;
- `S085` and `S092` SKIPs point to exact retained prior episodes and cause nothing;
- Captain appears only after each addressed contradiction and changes nothing;
- no maker exclusivity, divine motive or omitted historical act is invented;
- publication remains held and unpublished.

Continuation required: Deuteronomy 10 reconstructs replacement tablets, the
ark, Aaron's death/succession itinerary, Levite separation and the command to
circumcise the heart while the LORD performs heart circumcision later.
