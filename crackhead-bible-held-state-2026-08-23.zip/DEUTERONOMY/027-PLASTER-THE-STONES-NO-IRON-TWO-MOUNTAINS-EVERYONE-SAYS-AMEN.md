# CRACKHEAD DEUTERONOMY 27

## Title page

**PLASTER THE STONES. NO IRON. TWO MOUNTAINS.**

**EVERYONE SAYS “AMEN.”**

Source parent: Deuteronomy chapter 27, verses 1–26, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-027/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/026-BASKET-RECITAL-THIRD-YEAR-DECLARATION.md`.

CrackFlix routing: none. The Jordan/Ebal/Gerizim ceremony and every curse-response remain prospective speech.

## Causal foundation

```text
CROSS JORDAN
-> GREAT STONES -> PLASTER -> WRITE ALL LAW PLAINLY
-> MOUNT EBAL -> UNCUT-STONE ALTAR / NO IRON
-> OFFER -> EAT -> REJOICE

TODAY -> PEOPLE-OF-LORD DECLARATION + OBEY COMMAND

AFTER CROSSING
-> SIX TRIBES GERIZIM / SIX TRIBES EBAL
-> LEVITES SPEAK EACH CURSE LOUDLY
-> ALL PEOPLE ANSWER AMEN EACH TIME
```

## Deuteronomy 27:1–8 — CROSS, PLASTER, WRITE, BUILD, OFFER, EAT

Moses and Israel's elders command the people to keep today's commandment. On
the day Israel crosses the Jordan, great stones are erected, plastered and
written with all the law. After crossing, the stones are established on Mount
Ebal. An altar of uncut stones is built without iron tools; burnt and peace
offerings follow, then eating and rejoicing before the LORD. The law is written
very plainly.

The sequence is retained. No crossing, stone erection, plastering, writing,
altar building, offering, eating or rejoicing occurs.

## Deuteronomy 27:9–10 — TODAY'S PEOPLE DECLARATION

Moses and the Levitical priests tell Israel to be silent and listen: today they
have become the people of the LORD their God, therefore they must obey and do
the commandments and statutes commanded today. The declaration occurs as
speech; future obedience is not backfilled.

## Deuteronomy 27:11–14 — TWO MOUNTAINS, TWELVE NAMED TRIBAL POSITIONS

After crossing, Simeon, Levi, Judah, Issachar, Joseph and Benjamin are assigned
to Mount Gerizim for blessing. Reuben, Gad, Asher, Zebulun, Dan and Naphtali are
assigned to Mount Ebal for the curse. Levites are to address all Israel loudly.
No crossing, positioning, blessing or curse ceremony occurs.

## Deuteronomy 27:15–26 — EACH SPOKEN CURSE GETS ITS OWN “AMEN”

The future loud-voice list covers: a secret engraved or molten image; dishonor
of father or mother; moving a neighbor's landmark; misleading a blind person;
withholding justice from foreigner, fatherless or widow; the four separately
stated sexual-relation classes involving father's wife, an animal, a sister,
or mother-in-law; secret killing of a neighbor; taking a bribe to kill an
innocent person; and failure to uphold the law by doing it.

After every individual statement, all the people are to answer “Amen.” The
response is not compressed into one global reply, and the classes are not
merged. No image, dishonor, boundary move, deception, injustice, sexual act,
killing, bribe, law failure, curse pronouncement or Amen response occurs.

## Character and world-ledger changes

- ceremony order retains crossing before stone, altar, offering and meal acts;
- inscription stones and altar stones remain functionally distinct;
- altar stones are uncut and receive no iron tool;
- today’s people declaration is observed speech, while obedience remains required;
- named tribal positions remain six-and-six after crossing;
- every curse retains its own class and its own future collective Amen;
- no divine form is rendered;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every prospective living human, animal or plant Joe and face-like non-divine stone, plaster bucket, law mark, altar, iron tool, mountain, image, landmark, bribe or Amen bubble is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — STONE DEPLOYMENT / MOUNTAIN AUDIO TEST`;
- dependency: `JORDAN CROSSING REQUIRED`;
- inscription build: `PLASTER FIRST / WRITE VERY PLAINLY`;
- altar firewall: `IRON TOOL ACCESS DENIED`;
- topology: `GERIZIM 6 / EBAL 6`;
- Levite amplifier: `LOUD VOICE MODE`;
- response protocol: `ONE CURSE -> ONE AMEN`;
- class warning: `DO NOT MERGE THE FUCKING LINES`;
- barcode: `CHB-DEU27-26-STONES-MOUNTAINS-AMEN-NOCRACK-HELD`.

## FIR verification

- all 26 verse markers are represented in order;
- crossing gates every physical ceremony act;
- inscription and altar stones remain distinct;
- no iron tool, offering, meal or rejoicing is instantiated;
- today declaration remains speech and does not prove later obedience;
- all twelve named tribal placements are retained six-and-six;
- all twelve curse classes remain separately represented;
- every curse retains its own prospective collective Amen;
- no unsupported contradiction machinery appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 28 joins conditional blessings, conditional
curses, siege/captivity outcomes and covenant-word closure without executing them.
