# CRACKHEAD DEUTERONOMY 1

## Title page

**ELEVEN DAYS FROM HOREB.**

**FORTY YEARS LATER, HERE IS WHAT HAPPENED.**

Source parent: Deuteronomy chapter 1, verses 1–46, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-001/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/036-MARRY-WHO-YOU-THINK-BEST-INSIDE-THE-TRIBE.md`.

CrackFlix routing:

- `S097-E003-DEU1 -> S097-E002-NUM14 — PARDONED / WILDERNESS DEATH ACCOUNT RETOLD`
- `S068-E003-DEU1 -> S068-E002-NUM14 — WE SINNED / CURRENT COMMAND DISOBEYED RETOLD`

These are new speech occurrences recounting the retained Kadesh acts. They do
not manufacture a second historical rebellion, judgment, ascent or defeat.

## Causal foundation

```text
YEAR 40 / MONTH 11 / DAY 1 / MOAB
-> MOSES DECLARES THE LAW
-> RETELLS HOREB DEPARTURE + LEADERSHIP DELEGATION
-> RETELLS KADESH SCOUTING + REFUSAL
-> RETELLS EXCLUSION / CALEB-JOSHUA-CHILD EXCEPTIONS
-> RETELLS CONFESSION + CURRENT NO-GO COMMAND + DEFEAT
-> ISRAEL REMAINS MANY DAYS AT KADESH IN THE RETOLD HISTORY
```

## Deuteronomy 1:1–5 — THE RETROSPECTIVE ADDRESS BEGINS

Moses speaks to all Israel beyond the Jordan in the wilderness, with Arabah,
Suf, Paran, Tophel, Laban, Hazeroth and Dizahab retained as source locations.
The source states an eleven-day journey from Horeb by Mount Seir to Kadesh
Barnea. The address occurs in year forty, month eleven, day one, after the
completed defeats of Sihon at Heshbon and Og at Edrei. In Moab, Moses begins to
declare this law. Eleven days and forty years are separate source time grains;
the chapter does not state that continuous travel consumed forty years.

## Deuteronomy 1:6–8 — LONG ENOUGH AT THIS MOUNTAIN

Moses quotes the LORD at Horeb: Israel has lived long enough at the mountain.
The command is to turn, travel through the named Amorite, Arabah, hill,
lowland, South, seashore, Canaanite and Lebanon regions as far as Euphrates,
then enter and possess the land sworn to Abraham, Isaac, Jacob and their
offspring. This is retained retrospective command speech; it does not add a new
Horeb departure or complete the still-future western possession.

## Deuteronomy 1:9–18 — ONE MOSES CANNOT CARRY THE WHOLE CASE QUEUE

Moses recounts saying he could not bear the multiplied people, their problems,
burdens and strife alone. He blesses their multiplication, asks for wise,
understanding and respected tribal men, receives the people's spoken approval,
and appoints heads over thousands, hundreds, fifties and tens plus officers.

The judges are commanded to hear brother, brother and resident foreigner
fairly; hear small and great alike; show no partiality; fear no human face; and
send cases too hard for them to Moses. Appointment and command are completed
retrospective acts. No particular case, judgment or violation is invented.

## Deuteronomy 1:19–25 — TWELVE MEN RETURN WITH FRUIT AND GOOD-LAND WORDS

Israel travels from Horeb through the great and terrible wilderness to Kadesh
Barnea. Moses tells them the land is set before them and commands possession
without fear. The people propose sending searchers to report the route and
cities. Moses says the proposal pleased him, takes twelve—one per tribe—and
they search as far as Eshcol. They return holding fruit and say the land the
LORD gives is good. This retells the retained spy occurrence without inventing
new men, fruit or exploration.

## Deuteronomy 1:26–33 — GOOD LAND REPORTED; ASCENT REFUSED

Moses says the people would not go up and rebelled against the command. He
attributes to their tent speech the claim that the LORD hated them and brought
them from Egypt for Amorite destruction. He also recounts their report of
larger/taller people, sky-fortified cities and Anakim. The hate/destruction
statement remains the people's stated model; no divine motive is inferred.

Moses answers that they need not fear because the LORD would fight as in Egypt
and had carried them through the wilderness like a man carries his son. He
points to the preceding fire-by-night and cloud-by-day route finding. He then
says they still did not believe. The refusal and route history remain the same
retained Kadesh occurrence.

## Deuteronomy 1:34–40 — EXCLUSION, EXCEPTIONS AND THE TURN BACK

Moses recounts the LORD hearing the words and swearing that the addressed evil
generation would not see the good land. Caleb will see and receive the ground
he walked because he wholly followed. Moses says the LORD was angry with him
for the people's sakes and excluded him too. Joshua will enter and must be
encouraged because he will cause Israel to inherit. The children whom the
people predicted as captives will enter and possess. The addressed adults are
told to turn toward the Red Sea wilderness.

The chapter supplies these attributed words and outcome classes. It does not
erase the retained Numbers 20 water-event account, specify a single exclusive
cause for Moses' exclusion, or execute Joshua's future western inheritance.

The recalled exclusion belongs to the same pardon/judgment occurrence already
addressed at `S097-E002-NUM14`. Captain's private display reads:

> **SKIP -> S097-E002-NUM14**

His eyes glaze. Moses continues speaking. The judgment does not skip.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes a boil, licks his finger, walks away and does not look back. The
address continues unchanged.

## Deuteronomy 1:41–46 — WE SINNED; THEN WE IGNORED THE CURRENT COMMAND

The people answer that they sinned and will go up and fight. They put on war
weapons and presume to ascend. The LORD's current message through Moses is the
opposite: do not go or fight, because he is not among them and enemies will
strike them. Moses says they do not listen, rebel against that current command,
and go up anyway. Amorites chase them like bees and beat them down from Seir to
Hormah. They return and weep; the LORD does not listen. They remain many days
at Kadesh.

This is the same completed confession/current-disobedience occurrence retained
at `S068-E002-NUM14`, now spoken again in Deuteronomy:

> **SKIP -> S068-E002-NUM14**

Captain zones out. The ascent and defeat remain in the account.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes another boil, licks his finger, walks away and does not look back.

## Character and world-ledger changes

- Moses gains a dated Moab retrospective-law address;
- the eleven-day route statement remains distinct from the forty-year date;
- Horeb departure, delegated leadership and judicial rules are retold;
- the Kadesh scout, fruit, good-land report, refusal and defeat acts are not duplicated;
- people's hate/destruction assertion remains attributed speech, not fact;
- Caleb, Joshua, children, excluded generation and Moses retain distinct outcomes;
- the cause of Moses' exclusion is not collapsed into one exclusive account;
- `S097-E003` and `S068-E003` are retelling episodes pointing to the exact prior occurrence episodes;
- SKIP omits repeated explanation, changes nothing and does not create the event;
- Captain appears only after the completed contradiction is spoken, remains boilless and causally useless;
- every living being and face-like map, fruit, case queue, mountain, cloud, fire or weapon is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — PREVIOUSLY, ON FORTY YEARS OF THIS SHIT`;
- route display: `HOREB -> KADESH / ESTIMATED 11 DAYS / ACTUAL LEDGER YEAR 40`;
- leadership console: `ONE MOSES CAPACITY EXCEEDED — INSTALLING 1000/100/50/10 JOES`;
- court warning: `SMALL JOE = GREAT JOE / FACE-BASED PANIC DISABLED`;
- scout receipt: `12 SENT / FRUIT RETURNED / GOOD LAND CONFIRMED`;
- tent channel: `HE HATES US — SOURCE: PEOPLE IN TENTS`;
- CrackFlix: `SKIP -> S097-E002-NUM14 / SAME JUDGMENT, NEW SPEECH`;
- ascent warning: `CURRENT COMMAND: DO NOT GO / WE SINNED BUTTON PRESSED`;
- CrackFlix: `SKIP -> S068-E002-NUM14 / SAME HORMAH, NEW SPEECH`;
- bee pursuit label: `AMORITE HIVE RESPONSE UNIT`;
- barcode: `CHB-DEU1-46-RETROSPECTIVE-DEDUP-2SKIP-2YOINK-HELD`.

## FIR verification

- all 46 verse markers are represented in order;
- current address and historical acts remain separate Moments;
- source dates, places, people, command and outcome classes remain exact;
- future possession and Joshua inheritance are not backfilled;
- no judicial case or unsupported motive is invented;
- retelling episodes preserve rather than duplicate their historical parents;
- both SKIP pointers identify exact retained contradiction episodes;
- Captain changes no speech, judgment, ascent, defeat or outcome;
- publication remains held and unpublished.

Continuation required: Deuteronomy 2 continues the retrospective route through
Seir, Moab and Ammon, then recounts Sihon's refusal and completed defeat.
