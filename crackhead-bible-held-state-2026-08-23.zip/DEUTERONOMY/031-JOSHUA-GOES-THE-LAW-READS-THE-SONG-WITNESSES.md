# CRACKHEAD DEUTERONOMY 31

## Title page

**JOSHUA GOES. THE LAW READS.**

**THE SONG WITNESSES.**

Source parent: Deuteronomy chapter 31, verses 1–30, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-031/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/030-REMEMBER-RETURN-THE-WORD-IS-NEAR-CHOOSE-LIFE.md`.

CrackFlix routing: none. Succession acts, written carriers and current speeches are retained; predicted rebellion and consequences remain future.

## Causal foundation

```text
MOSES 120 + CANNOT CONTINUE + WILL NOT CROSS
-> LORD GOES BEFORE + JOSHUA CROSSES
-> PUBLIC MOSES COMMISSION SPEECH

MOSES WRITES LAW -> PRIESTS/ELDERS
-> EVERY 7 YEARS / RELEASE / BOOTHS / CHOSEN PLACE
-> READ TO ALL -> HEAR/LEARN/FEAR/DO

LORD SUMMONS MOSES + JOSHUA -> TENT
-> CLOUD-PILLAR APPEARANCE -> FUTURE REBELLION SPEECH
-> WRITE/TEACH SONG -> WITNESS
-> JOSHUA COMMISSIONED

LAW BOOK FINISHED
-> BESIDE ARK -> WITNESS
-> ELDERS/OFFICERS ASSEMBLED -> HEAVEN/EARTH WITNESS
-> MOSES SPEAKS FINISHED SONG
```

## Deuteronomy 31:1–8 — MOSES STOPS; JOSHUA CROSSES

Moses tells all Israel he is 120, can no longer go out and come in, and has
been told he will not cross Jordan. He says the LORD will cross before Israel,
destroy nations as with the retained Sihon/Og history, and that Joshua will
cross. Moses publicly calls Joshua, commands strength and courage, and says he
will bring the people into the sworn land while the LORD goes before him.

The speech and public succession address occur. Crossing, destruction,
dispossession and inheritance remain future; Sihon/Og acts are not repeated.

## Deuteronomy 31:9–13 — WRITE ONCE; READ EVERY SEVEN YEARS

Moses writes the law and delivers it to ark-bearing Levitical priests and
elders. He commands public reading at the end of each seven years, during the
release year and feast of booths, when Israel appears at the chosen place. Men,
women, little ones and resident foreigners assemble to hear, learn, fear and do;
children without prior knowledge also hear and learn throughout land life.

Writing and delivery occur. No seven-year endpoint, festival assembly, chosen
place, reading, hearing, learning or resulting obedience occurs.

## Deuteronomy 31:14–23 — TENT, CLOUD, PREDICTION, SONG, COMMISSION

The LORD tells Moses death approaches and commands Moses and Joshua to present
at the Tent for commissioning. They do. The LORD appears in a pillar of cloud
at the Tent door and predicts post-Moses other-god service, covenant breaking,
anger, hidden face, trouble and the people's future causal question. The cloud
is the exact rendered appearance carrier; no additional divine body is invented.

The LORD commands a song written, taught and placed in Israel's mouths as a
witness that will survive the predicted abundance-to-other-gods sequence.
Moses writes and teaches the song that day. Joshua son of Nun is commissioned
with strength/courage speech and the promise of divine presence. The Tent
presentation, cloud appearance, song writing/teaching and commissioning occur;
future rebellion and trouble do not.

## Deuteronomy 31:24–30 — THE BOOK GOES BESIDE THE ARK; THE SONG IS SPOKEN

Moses finishes writing all law words in a book, commands ark-bearing Levites to
place it beside the covenant ark as a witness, and cites observed rebellion
while he is alive before predicting greater post-death corruption. He summons
elders and officers, calls heaven and earth as witnesses, and predicts latter-
day evil from turning away. Moses then speaks the completed song's words in the
ears of all Israel's assembly.

Book completion, deposit command, assembly, witness call and finished song
speech occur. Actual physical deposit is required by the command but not
explicitly reported completed in this chapter, so it remains unresolved.
Post-death corruption and resulting evil remain predicted.

## Character and world-ledger changes

- Moses' age/capacity/no-crossing State gates Joshua succession;
- Moses' public Joshua speech and LORD's Tent commissioning remain distinct acts;
- seven-year law reading retains time, festival, location and full-audience selectors;
- pillar of cloud is the only observed divine appearance carrier;
- song writing/teaching and law-book completion occur as separate witness carriers;
- physical law-book deposit beside ark remains commanded, not confirmed;
- present rebellion statement and future rebellion prediction retain their time boundaries;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every living human, animal or plant Joe and face-like non-divine law book, ark, tent, cloud pillar, song sheet, calendar or witness badge is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — SUCCESSION / READ TIMER / DUAL WITNESS`;
- Moses status: `AGE 120 / CROSSING ACCESS DENIED`;
- Joshua route: `BE STRONG / GO OVER`;
- reading scheduler: `7 YEARS + RELEASE + BOOTHS + CHOSEN PLACE`;
- audience list: `MEN / WOMEN / LITTLE ONES / FOREIGNERS / CHILDREN`;
- cloud renderer: `DIVINE BODY FIELD: UNSUPPLIED`;
- song carrier: `MOUTH-REPLICATED WITNESS`;
- book carrier: `SIDE-OF-ARK ADDRESS / DEPOSIT NOT YET ACKNOWLEDGED`;
- barcode: `CHB-DEU31-30-JOSHUA-LAW-SONG-WITNESSES-NOCRACK-HELD`.

## FIR verification

- all 30 verse markers are represented in order;
- Sihon/Og history is not duplicated;
- public and Tent commissioning acts remain distinct;
- seven-year reading retains all timing/audience gates;
- no divine form beyond pillar of cloud is invented;
- song write/teach and law-book finish are completed acts;
- law-book physical deposit is not falsely closed;
- observed present rebellion and predicted future rebellion remain distinct;
- no unsupported contradiction machinery appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 32 joins the completed song, wilderness-find
history, jealousy/reversal predictions, divine-only vengeance and Moses' final
Nebo death instruction.
