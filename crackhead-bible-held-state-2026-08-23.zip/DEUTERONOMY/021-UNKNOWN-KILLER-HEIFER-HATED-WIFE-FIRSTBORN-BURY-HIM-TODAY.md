# CRACKHEAD DEUTERONOMY 21

## Title page

**UNKNOWN KILLER. MEASURE TO THE HEIFER.**

**HATED WIFE'S FIRSTBORN. BURY HIM TODAY.**

Source parent: Deuteronomy chapter 21, verses 1–23, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-021/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/020-NEW-HOUSE-GO-HOME-OFFER-PEACE-DONT-FIGHT-THE-FRUIT-TREES.md`.

CrackFlix routing: none. Every corpse, captive, inheritance, son and execution branch remains prospective.

## Causal foundation

```text
SLAIN PERSON FOUND + KILLER UNKNOWN
-> ELDERS/JUDGES MEASURE TO SURROUNDING CITIES
-> NEAREST CITY SELECTED
-> UNWORKED/UNYOKED HEIFER
-> UNPLOWED/UNSOWN RUNNING-WATER VALLEY
-> HEIFER NECK BROKEN
-> PRIESTS ATTEND
-> ELDERS WASH HANDS + DENY HAND/IMAGE KNOWLEDGE
-> ASK FORGIVENESS -> BLOOD FORGIVEN/PURGED

CAPTIVE WOMAN SEEN + DESIRED AS WIFE
-> HOUSE / SHAVED HEAD / TRIMMED NAILS / CAPTIVITY CLOTHES REMOVED
-> FULL MONTH MOURNING FATHER/MOTHER
-> THEN MARRIAGE
-> LATER NO DELIGHT -> FREE TO GO
-> NO SALE / NO SLAVE TREATMENT

TWO WIVES + HATED WIFE'S SON ACTUAL FIRSTBORN
-> BELOVED WIFE'S SON CANNOT BE PROMOTED
-> ACTUAL FIRSTBORN GETS DOUBLE PORTION

STUBBORN/REBELLIOUS SON + PARENT VOICES/CHASTENING REFUSED
-> BOTH PARENTS TAKE TO CITY ELDERS/GATE
-> STATE GLUTTON/DRUNKARD/REFUSAL
-> CITY MEN STONE TO DEATH

DEATH-WORTHY MAN EXECUTED + HUNG
-> NOT LEFT OVERNIGHT
-> BURIED SAME DAY
```

## Deuteronomy 21:1–9 — THE KILLER IS UNKNOWN; MEASURE THE DISTANCE

If a slain person is found in the inherited field and the striker is unknown,
elders and judges measure to surrounding cities. The nearest city's elders take
an unworked, unyoked heifer to an unplowed, unsown valley with running water and
break its neck. Levitical priests attend under their ministry, blessing and
controversy authority.

The elders wash their hands over the heifer and state that their hands did not
shed the blood and their eyes did not see it. They ask forgiveness for redeemed
Israel; forgiveness and removal of innocent blood are stated results of doing
the prescribed right act.

Unknown remains unknown. The procedure assigns the nearest-city response, not
the killing. No body, measurement, city, heifer, valley, priest, washing,
statement, forgiveness or purging event occurs.

## Deuteronomy 21:10–14 — CAPTIVE TO WIFE, OR RELEASED WITHOUT SALE

The prospective route begins after battle delivery and captivity when a man
sees a captive woman, is attracted to her and desires her as wife. She is
brought into his house, shaves her head, trims her nails, removes captivity
clothing and mourns father and mother for a full month. Only after that does the
text route marriage and sexual access.

If he later has no delight in her, she must be allowed to go where she desires.
He may not sell her for money or treat her as a slave; the text gives his having
humbled her as the reason. These statements are retained without adding consent,
motive, affection or justification not supplied by the source.

No battle, captive, attraction, grooming, mourning, marriage, intercourse,
release, sale or enslavement occurs.

## Deuteronomy 21:15–17 — LOVE DOES NOT REORDER THE FIRST BIRTH

If a man has beloved and hated wives with sons, and the hated wife's son is the
actual firstborn, the beloved wife's son may not receive firstborn priority.
The actual firstborn must be acknowledged with a double portion because the
right attaches to first birth.

Wife status and birth order are separate fields; preference cannot rewrite the
recorded order. No family, hatred, love, birth, inheritance or transfer occurs.

## Deuteronomy 21:18–21 — BOTH PARENTS BRING THE CASE TO THE GATE

The prospective son is stubborn and rebellious, refuses both parents' voices
and continues not listening after chastening. Father and mother together seize
and bring him to city elders at the gate, stating his refusal, gluttony and
drunkenness. The city men are commanded to stone him to death; evil removal and
Israel hearing/fearing are stated effects.

No son, parental instruction, chastening, refusal, accusation, gate hearing,
stone, execution or public response occurs.

## Deuteronomy 21:22–23 — EXECUTED AND HUNG DOES NOT MEAN LEFT OVERNIGHT

If a man commits a death-worthy sin, is executed and is hung on a tree, the body
may not remain overnight. It must be buried the same day. The source calls the
hanged person accursed of God and links same-day removal to avoiding defilement
of inherited land.

Execution precedes hanging in the stated chain. No crime, conviction, death,
hanging, body exposure, burial or land defilement occurs.

## Character and world-ledger changes

- unknown-field-death procedure preserves unknown killer identity;
- nearest-city responsibility is selected by measurement, not inferred causation;
- heifer, valley, priest, handwashing and elder speech remain unperformed;
- captive-wife route retains full month, later release, no-sale and no-slave constraints;
- actual first birth overrides wife preference for the double portion;
- rebellious-son route requires both parental history and joint gate presentation;
- executed/hung body receives a same-day burial deadline;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every prospective living human, animal or plant Joe and face-like non-divine tape measure, heifer yoke, nail, garment, inheritance ticket, stone, tree or corpse carrier is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — NEAREST CITY / BIRTH ORDER / BODY CLOCK`;
- murder dashboard: `KILLER: UNKNOWN — DO NOT AUTOFILL`;
- distance meter: `CORPSE -> NEAREST CITY`;
- heifer spec: `WORK: 0 / YOKE: 0`;
- valley spec: `PLOWED: 0 / SOWN: 0 / WATER: RUNNING`;
- captive timer: `FULL MONTH — SKIP DISABLED`;
- exit lock: `NO DELIGHT -> FREE / SALE: FORBIDDEN`;
- inheritance sorter: `FAVOURITE WIFE DOES NOT EDIT TIMESTAMP`;
- son case intake: `FATHER + MOTHER + PRIOR CHASTENING`;
- body timer: `SUNSET DEADLINE — BURY THE BASTARD TODAY`;
- barcode: `CHB-DEU21-23-UNKNOWN-FIRSTBORN-BODY-NOCASE-NOCRACK-HELD`.

## FIR verification

- all 23 verse markers are represented in order;
- unknown killer remains unknown and nearest-city selection does not assert guilt;
- every heifer/valley/priest/elder selector remains exact;
- captive-wife coercive route is retained without invented consent or justification;
- release/no-sale/no-slave constraints remain attached to later no-delight state;
- wife preference does not replace actual birth order;
- rebellious-son parent/history/gate chain remains prospective;
- execution precedes hanging and same-day burial remains required;
- no corpse, captive, family, son or executed person is instantiated;
- no unsupported contradiction machinery appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 22 joins lost-property return, fallen-animal
assistance, clothing boundaries, nest protection, roof parapets, mixed-material
rules and sexual-case evidence routes.
