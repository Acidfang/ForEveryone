# CRACKHEAD DEUTERONOMY 3

## Title page

**SIXTY CITIES. ONE IRON BED.**

**YOUR LAND IS GIVEN. NOW CROSS OVER AND FINISH EARNING IT.**

Source parent: Deuteronomy chapter 3, verses 1–29, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-003/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/002-BUY-THE-WATER-DONT-TOUCH-THE-LAND-OFFER-PEACE-HARDEN-REFUSAL.md`.

CrackFlix routing: `S070-E004-DEU3 -> S070-E003-NUM32 — EAST LAND GIVEN / CROSSING STILL REQUIRED`.

## Causal foundation

```text
OG COMES TO BATTLE AT EDREI
-> LORD SAYS DO AS TO SIHON
-> OG + PEOPLE STRUCK / NONE REMAIN
-> 60 FORTIFIED CITIES + VILLAGES TAKEN
-> INHABITANTS DESTROYED / LIVESTOCK + PLUNDER RETAINED

EAST LAND ALLOCATED TO REUBEN / GAD / HALF-MANASSEH
-> WIVES / CHILDREN / LIVESTOCK MAY LIVE THERE
-> ARMED MEN MUST CROSS BEFORE BROTHERS
-> RETURN ONLY AFTER WESTERN REST + POSSESSION

MOSES ASKS TO CROSS
-> LORD: ENOUGH / SPEAK NO MORE
-> MOSES MAY VIEW FROM PISGAH BUT NOT CROSS
-> JOSHUA MUST BE COMMISSIONED / ENCOURAGED / STRENGTHENED
```

## Deuteronomy 3:1–7 — OG'S KINGDOM IS TAKEN

Moses recounts Og and all Bashan coming to battle at Edrei. The LORD tells him
not to fear and commands the same treatment given Sihon. Og and all his people
are struck until none remains. Israel takes all sixty Argob cities—high walls,
gates and bars—plus many unwalled villages, destroys every inhabited city with
women and little ones, and keeps livestock and city plunder. This is the same
retained Og campaign, not a second conquest occurrence.

## Deuteronomy 3:8–11 — TWO KINGS, THREE MOUNTAIN NAMES, ONE IRON BED

The two conquered kingdoms extend from Arnon to Hermon and across the plain,
Gilead and Bashan to Salecah and Edrei. Sidonians call Hermon Sirion; Amorites
call it Senir. Different names remain attributed labels for the same addressed
mountain, not different mountains.

Og alone is said to have remained of the Rephaim remnant. His iron bedstead is
reported at Rabbah, nine cubits long and four wide by a man's cubit. Bed size is
not converted into Og's body size; its manufacture, ownership transfer and
route to Rabbah remain unstated.

## Deuteronomy 3:12–17 — EAST LAND DIVIDED

Moses recounts giving Aroer, half Gilead and cities to Reuben and Gad. The rest
of Gilead, Bashan and Argob goes to half-Manasseh. Jair's Argob seizure and
Havvoth Jair naming, Gilead to Machir, and Reuben/Gad boundaries through Arnon,
Jabbok, Arabah, Jordan, Chinnereth, Salt Sea and Pisgah are retained. Half-
Manasseh and the other Manasseh half remain distinct.

## Deuteronomy 3:18–20 — LAND GIVEN; ARMED WORK STILL REQUIRED

Moses says the LORD has given the east land to possess. Wives, little ones and
much livestock may remain in the granted cities. Armed men must cross before
their brothers until the LORD gives those brothers rest and they possess the
west-bank land; only then may the armed men return to their own possession,
which Moses says he has given them.

This retells the exact `S070-E003-NUM32` relation:

```text
LAND IS ALREADY GIVEN AS OWN POSSESSION
-> ARMED CROSSING + WESTERN SUBDUAL/REST STILL REQUIRED
-> ONLY THEN MAY RECIPIENTS RETURN TO THAT POSSESSION
```

> **SKIP -> S070-E003-NUM32**

Captain's eyes glaze. The command continues and the future crossing remains
future.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes an armed east-tribe Joe's boil, licks his finger, walks away and does
not look back. No land or duty changes.

## Deuteronomy 3:21–22 — JOSHUA GETS THE TWO-KING PREVIEW

Moses tells Joshua that his eyes saw what happened to both kings and says the
LORD will do likewise to the kingdoms across Jordan. Joshua must not fear
because the LORD fights for Israel. The future campaigns remain prediction and
instruction; none is imported here.

## Deuteronomy 3:23–29 — MOSES ASKS; THE ANSWER CLOSES

Moses recounts begging the Lord GOD to let him cross and see the good land,
mountain and Lebanon, after praising divine greatness and acts. He attributes
the LORD's anger to the people's sake. The answer is explicit: enough; speak no
more of this matter. Moses must ascend Pisgah, look in four directions and see
with his eyes, but will not cross Jordan. He must commission, encourage and
strengthen Joshua, who will cross and cause inheritance. Israel remains in the
valley near Beth Peor.

The request, refusal and alternate viewing/commissioning command form a closed
decision, not a contradiction. The chapter does not state that Moses ascends
Pisgah here or that Joshua completes the future crossing.

## Character and world-ledger changes

- Og's Edrei battle, defeat, people and city destruction are retold without duplication;
- sixty fortified cities and additional villages become retained conquest totals;
- Og's iron bed remains a measured object, not a body-size inference;
- east allocations and named boundaries remain exact;
- `S070-E004` retells already-given possession with outstanding cross-bank duty;
- Joshua gains two-king evidence plus future no-fear/fighting instruction;
- Moses gains a completed request/refusal and no-more-speech boundary;
- Pisgah viewing and Joshua crossing remain future;
- Captain remains boilless and causally useless;
- every living being and face-like city, bed, border, land grant or mountain is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — OG BED & BREAKFAST / BREAKFAST CANCELLED`;
- city counter: `60/60 FORTIFIED + VILLAGES DLC`;
- bed label: `9 x 4 CUBITS / OCCUPANT DIMENSIONS NOT INCLUDED`;
- mountain alias selector: `HERMON / SIRION / SENIR — SAME FUCKING MOUNTAIN`;
- east-land receipt: `GIVEN NOW / RETURN ACCESS AFTER WESTERN JOB`;
- CrackFlix: `SKIP -> S070-E003-NUM32 / PREVIOUSLY GIVEN`;
- Joshua tutorial: `TWO KINGS DEFEATED — REPEAT AFTER CROSSING`;
- prayer response: `ENOUGH / DO NOT RESUBMIT TICKET`;
- Pisgah viewport: `WEST / NORTH / SOUTH / EAST / CROSS BUTTON DISABLED`;
- barcode: `CHB-DEU3-29-OG60-IRONBED-S070-SKIP-YOINK-HELD`.

## FIR verification

- all 29 verse markers are represented in order;
- Og conquest is retold, not recreated;
- mountain names and tribal halves are not falsely split or merged;
- iron-bed dimensions do not become Og dimensions;
- land grant, residence permission, armed duty and return condition remain ordered;
- SKIP points to the exact prior occurrence episode and changes nothing;
- future west-bank acts and Pisgah ascent are not backfilled;
- Moses' request/refusal is not falsely classified as contradiction;
- Captain appears only after the completed retained friction;
- publication remains held and unpublished.

Continuation required: Deuteronomy 4 warns against adding/subtracting,
reconstructs Horeb's voice-without-form boundary and establishes refuge cities.
