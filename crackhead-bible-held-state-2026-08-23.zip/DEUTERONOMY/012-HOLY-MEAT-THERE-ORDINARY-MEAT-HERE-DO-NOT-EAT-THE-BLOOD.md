# CRACKHEAD DEUTERONOMY 12

## Title page

**HOLY MEAT THERE. ORDINARY MEAT HERE.**

**DO NOT EAT THE BLOOD ANYWHERE.**

Source parent: Deuteronomy chapter 12, verses 1–32, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-012/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/011-YOUR-EYES-SAW-IT-RAIN-IF-YOU-LISTEN-MOUNTAIN-CHOICE-LATER.md`.

CrackFlix routing: none. Distinct food/offer classes retain distinct location and blood routes.

## Causal foundation

```text
FUTURE DISPOSSESSION
-> DESTROY NATION WORSHIP PLACES/OBJECTS/NAMES
-> DO NOT COPY THAT WORSHIP

LORD CHOOSES ONE NAME/HABITATION PLACE
-> BURNT/SACRIFICE/TITHE/WAVE/VOW/FREEWILL/FIRSTBORN GO THERE
-> HOUSEHOLD + LEVITE EAT/REJOICE THERE

ORDINARY MEAT DESIRE + DISTANCE
-> KILL/EAT WITHIN ANY GATE
-> CLEAN + UNCLEAN MAY EAT
-> BLOOD NOT EATEN; POUR LIKE WATER

HOLY THINGS/VOWS
-> TAKE TO CHOSEN PLACE
-> OFFERING BLOOD TO ALTAR; PERMITTED MEAT EATEN

FUTURE NATION REMOVAL
-> DO NOT INQUIRE/COPY THEIR GOD SERVICE
-> CHILD-BURNING CITED AS PROHIBITED MODEL
```

## Deuteronomy 12:1–4 — DELETE THE OLD WORSHIP ADDRESSES

For future life in the possessed land, Israel must destroy the displaced
nations' god-service places on mountains, hills and under green trees; break
altars, smash pillars, burn Asherah poles, cut engraved images and remove their
names. Israel must not worship the LORD that way. These are future acts; no
western site or object is destroyed here.

## Deuteronomy 12:5–14 — SACRED INPUTS GO TO THE SELECTED PLACE

Israel must seek the future place the LORD chooses from the tribes for his name
and habitation. Burnt offerings, sacrifices, tithes, hand-wave offerings,
vows, freewill offerings and herd/flock firstborn are routed there. Household
members rejoice and eat there, including sons, daughters, male/female servants
and the gate-resident Levite who lacks portion/inheritance.

The chapter contrasts present “each does right in his own eyes” with the future
post-Jordan rest/safety system, and prohibits burnt offerings at every visible
place. The chosen place is not named and no offering or meal occurs.

## Deuteronomy 12:15–25 — ORDINARY MEAT CAN STAY LOCAL

Ordinary meat may be killed and eaten within every gate according to blessing
and desire. Clean and unclean people may both eat it like gazelle/deer. When
the border expands and the chosen place is distant, herd/flock meat may still
be locally killed and eaten.

Blood remains excluded: do not eat it; blood is life; do not eat life with
meat; pour it on earth like water. Sacred tithes, firstborn, vows, freewill and
wave offerings are separately prohibited from gate eating and routed to the
chosen place. Local ordinary meat and centralized sacred meals are different
classes, not contradictory permissions for one undifferentiated item.

No animal is killed, eaten or drained in this chapter.

## Deuteronomy 12:26–28 — HOLY THINGS TAKE THE ALTAR ROUTE

Holy things and vows must travel to the chosen place. Burnt-offering meat and
blood go on the altar; sacrifice blood is poured on the altar and permitted
meat is eaten. Observing all words selects future good for Israel and children.
The altar route and earth-like-water route address different offering classes;
no blood consumption is permitted in either.

## Deuteronomy 12:29–32 — DON'T COPY THE PEOPLE YOU REMOVED

After future nation removal and settlement, Israel must not become ensnared,
inquire how those nations served gods, or announce it will do likewise. Moses
attributes hated practices to them, including burning sons and daughters in
fire to their gods. This is reported conduct about the future-displaced nations,
not a newly observed named child-burning occurrence.

The chapter closes by repeating: do what is commanded; add nothing and take
nothing away. No modification act occurs.

## Character and world-ledger changes

- future worship-site destruction remains unperformed;
- one unnamed future chosen-place selector governs sacred offerings and meals;
- household/servant/Levite participation remains prospective;
- ordinary local meat and centralized sacred food retain separate classes;
- clean/unclean eater permission applies to ordinary meat without erasing other ritual classifications;
- blood remains consistently nonfood and receives class-dependent earth/altar routing;
- local-worship imitation and child-burning are prohibited/reported, not performed by Israel here;
- no-add/no-subtract repeats without a modification occurrence;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every prospective living human/animal and face-like non-divine altar, pillar, tree, gate or blood drop is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — MEAT ROUTER`;
- site cleanup: `MOUNTAIN / HILL / GREEN TREE / DELETE OLD NAMES`;
- sacred destination: `PLACE NOT YET SELECTED`;
- holy checkout: `TAKE IT THERE`;
- ordinary checkout: `ANY GATE / CLEAN + UNCLEAN`;
- blood warning: `LIFE FIELD / NOT A BEVERAGE`;
- blood outputs: `ORDINARY -> EARTH / OFFERING -> ALTAR`;
- Levite reminder: `NO PORTION / DO NOT FORSAKE`;
- imitation firewall: `DO NOT ASK HOW THEY DID IT`;
- command diff: `ADD 0 / REMOVE 0`;
- barcode: `CHB-DEU12-32-CLASS-ROUTING-NOCRACK-HELD`.

## FIR verification

- all 32 verse markers are represented in order;
- future land, site destruction, rest and chosen place remain unexecuted;
- sacred and ordinary food classes retain separate selectors and destinations;
- clean/unclean ordinary-eater permission is not generalized beyond its class;
- blood is never permitted as food and its two disposal routes remain class-bound;
- no animal, meal, offering, child-burning or worship-imitation occurrence is invented;
- the chosen place is not named;
- no-add/no-subtract remains command wording without a performed modification;
- no unsupported contradiction machinery appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 13 routes sign-performing enticers, intimate
family enticers and city-wide apostasy accusations through separate evidence,
killing and destruction procedures.
