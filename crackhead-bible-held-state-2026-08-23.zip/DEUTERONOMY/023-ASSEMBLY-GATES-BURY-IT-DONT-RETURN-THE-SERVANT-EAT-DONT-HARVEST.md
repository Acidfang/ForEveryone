# CRACKHEAD DEUTERONOMY 23

## Title page

**ASSEMBLY GATES. BURY IT. DON'T RETURN THE SERVANT.**

**EAT THERE. DON'T HARVEST IT.**

Source parent: Deuteronomy chapter 23, verses 1–25, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-023/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/022-RETURN-THE-DONKEY-BUILD-A-ROOF-RAIL-DONT-MERGE-THE-CASES.md`.

CrackFlix routing: none. Every admission, camp, servant, earnings, loan, vow and crop-access route remains prospective.

## Causal foundation

```text
PERSON/PEOPLE CLASS + GENERATION
-> LORD'S-ASSEMBLY ADMISSION ROUTE

WAR CAMP + NIGHT OCCURRENCE
-> OUTSIDE CAMP -> BATHE AT EVENING -> RETURN AFTER SUNSET
RELIEF OUTSIDE CAMP
-> DIG -> COVER

ESCAPED SERVANT ARRIVES
-> DO NOT RETURN -> MAY CHOOSE PLACE -> DO NOT OPPRESS

EARNINGS CLASS + VOW
-> HOUSE-OF-LORD ADMISSION ROUTE
BORROWER IDENTITY
-> INTEREST ROUTE
VOW SPOKEN
-> PAY/DO IT; NO VOW -> NO VOW SIN

NEIGHBOR'S VINEYARD/GRAIN ENTERED
-> EAT/PLUCK BY HAND
-> NO CONTAINER / NO SICKLE
```

## Deuteronomy 23:1–8 — ASSEMBLY ADMISSION IS CLASS- AND GENERATION-SELECTED

The text excludes an emasculated person, a person born of a forbidden union
through the tenth generation, and Ammonite or Moabite descendants forever from
the LORD's assembly. It attributes the Ammonite/Moabite route to withheld bread
and water and the hiring of Balaam; it says the LORD refused Balaam, turned the
curse into blessing because he loved Israel, and prohibits seeking their peace
or prosperity.

Edomites may not be abhorred because the text calls them brothers. Egyptians
may not be abhorred because Israel lived as foreigners in Egypt. Their
third-generation children may enter the assembly. These are separate named
routes; no assembly applicant, genealogy, admission, exclusion, hatred, peace
search or prosperity search occurs. The Balaam history is retained as speech
about prior events, not executed again.

## Deuteronomy 23:9–14 — THE WAR CAMP GETS A NIGHT ROUTE AND A SHIT ROUTE

When camped against enemies, Israel must avoid every evil thing. A man made
unclean by a night occurrence goes outside the camp, bathes at evening, and may
return after sunset. A separate outside place is assigned for relieving
oneself. A trowel travels with the weapons; the person digs, turns back and
covers the excrement.

The reason given is that the LORD walks in the camp to deliver Israel and hand
over enemies, so the camp must remain holy lest he see an unclean thing and
turn away. This is source-attributed divine walking without rendering a divine
form. No war camp, night occurrence, bathing, relief, digging, excrement,
divine appearance, delivery or enemy transfer occurs.

## Deuteronomy 23:15–16 — THE ESCAPED SERVANT IS NOT RETURNED

An escaped servant who comes from a master may not be delivered back. The
servant may dwell among Israel, choosing the place within a gate that pleases
him, and may not be oppressed. No servant, master, escape, arrival, selection,
return demand, residence or oppression occurs.

## Deuteronomy 23:17–18 — PROHIBITED ROLES AND PROHIBITED VOW EARNINGS

The text prohibits the specified female and male prostitution roles among
Israel and prohibits their hire or wages from entering the LORD's house for a
vow. The source footnote says the second wage term is literally “dog”; that
lexical note is retained without creating an animal, equating a person with an
animal, or replacing the source's rendered role. No prostitute, customer,
payment, vow, transfer or house entry occurs.

## Deuteronomy 23:19–20 — INTEREST ROUTES BY BORROWER IDENTITY

Interest on money, food or anything lent may not be charged to a brother. The
text permits charging a foreigner interest and links the brother route to
future blessing in the land. The identity selector is retained without
generalizing it into a universal loan rule. No brother, foreigner, loan,
interest charge, repayment, blessing or possession occurs.

## Deuteronomy 23:21–23 — YOUR MOUTH CAN CREATE THE PAYMENT DUTY

A vow made to the LORD must be paid without delay; the text says it will be
required and delay becomes sin. Refraining from a vow is not sin. What leaves
the lips as a freely promised offering must be observed and done. No vow,
promise, delay, payment, requirement or sin event occurs.

## Deuteronomy 23:24–25 — EAT FROM THE CROP; DON'T TURN ACCESS INTO HARVEST

On entering a neighbor's vineyard, a person may eat grapes to satisfaction but
may not put grapes into a container. In standing grain, the person may pluck
ears by hand but may not apply a sickle. Immediate eating access and removal or
harvest are different acts. No neighbor, entry, grape, grain, eating,
container-filling, hand-plucking or sickle use occurs.

## Character and world-ledger changes

- assembly entry retains exact person/people/generation selectors;
- Balaam history remains a retained prior-event report rather than a duplicate occurrence;
- night uncleanness and relief/excrement use separate outside-camp procedures;
- the source's divine walking is attributed but no divine form is rendered;
- escaped-servant residence choice blocks forced return and oppression;
- prostitution-role and earnings/vow exclusions remain prospective;
- brother and foreigner interest routes remain identity-selected;
- speaking a vow creates a duty while not vowing creates none;
- neighbor crop access permits immediate consumption, not storage or harvesting;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every prospective living human, animal or plant Joe and face-like non-divine gate, trowel, weapon, camp, wage, coin, vow, grape, container, grain or sickle is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — ASSEMBLY / CAMP / ACCESS CONTROL`;
- assembly terminal: `CLASS + GENERATION -> ADMIT / EXCLUDE`;
- history warning: `BALAAM EVENT ALREADY RAN — DO NOT DUPLICATE`;
- camp kit: `SWORD / TROWEL / COVER YOUR SHIT`;
- sunset gate: `BATH COMPLETE -> WAIT FOR SUN DOWN`;
- divine-camera warning: `NO FORM AVAILABLE`;
- servant router: `ESCAPED HERE -> RETURN DISABLED`;
- wage scanner: `VOW INPUT REJECTED`;
- loan switch: `BROTHER != FOREIGNER`;
- vow compiler: `MOUTH OUTPUT -> DUTY`;
- vineyard permission: `BELLY YES / BAG NO`;
- grain permission: `HAND YES / SICKLE NO`;
- barcode: `CHB-DEU23-25-ASSEMBLY-CAMP-SERVANT-ACCESS-NOCRACK-HELD`.

## FIR verification

- all 25 verse markers are represented in order;
- assembly classes and generation limits remain separate source routes;
- prior Balaam events are not duplicated;
- no hatred, genealogy or admission outcome is inferred;
- night and relief camp procedures retain their exact timing and tools;
- no divine form is invented from attributed walking;
- escaped-servant non-return, residence choice and non-oppression remain joined;
- the verse-18 lexical footnote is retained without inventing an animal occurrence;
- interest is routed by the source's borrower identity selector;
- vow/no-vow and spoken-duty branches remain distinct;
- immediate crop consumption is not merged with storage or harvest;
- no applicant, camp, servant, sex-work, loan, vow or crop case is instantiated;
- no unsupported contradiction machinery appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 24 joins divorce/remarriage, newlywed exemption,
pledge safeguards, kidnapping, skin-disease memory, wage timing and gleaning duties.
