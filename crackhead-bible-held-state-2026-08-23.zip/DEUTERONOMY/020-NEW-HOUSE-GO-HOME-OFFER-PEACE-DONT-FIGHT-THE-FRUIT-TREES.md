# CRACKHEAD DEUTERONOMY 20

## Title page

**NEW HOUSE? GO HOME.**

**OFFER PEACE. DON'T FIGHT THE FRUIT TREES.**

Source parent: Deuteronomy chapter 20, verses 1–20, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-020/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/019-AXE-HEAD-CITY-THREE-PLUS-THREE-DO-TO-THE-FALSE-WITNESS.md`.

CrackFlix routing: none. Every battle, exemption, city and siege branch remains prospective.

## Causal foundation

```text
BATTLE + MORE HORSES/CHARIOTS/PEOPLE
-> DO NOT FEAR
-> PRIEST SPEAKS: LORD GOES/FIGHTS/SAVES

OFFICER EXEMPTIONS
-> NEW HOUSE NOT DEDICATED -> GO HOME
-> VINEYARD FRUIT NOT USED -> GO HOME
-> PLEDGED WIFE NOT TAKEN -> GO HOME
-> FEARFUL/FAINT HEART -> GO HOME
-> THEN CAPTAINS APPOINTED

CITY APPROACHED
-> PROCLAIM PEACE
-> PEACE + OPENS -> FORCED LABOR/SERVICE
-> NO PEACE + WAR -> BESIEGE

DISTANT/NON-INHERITANCE CITY DELIVERED
-> MALES KILLED
-> WOMEN/CHILDREN/LIVESTOCK/PLUNDER TAKEN

NAMED INHERITANCE-PEOPLE CITY
-> NOTHING BREATHING SAVED

LONG SIEGE
-> FOOD TREE: DO NOT CUT / MAY EAT
-> KNOWN NON-FOOD TREE: MAY CUT -> BULWARK
```

## Deuteronomy 20:1–4 — MORE HORSES DOESN'T CANCEL THE PRIEST'S SPEECH

When Israel goes to battle and sees more horses, chariots and people, fear is
forbidden because the LORD who brought Israel from Egypt is said to be present.
At the battle approach, the priest tells Israel not to faint, fear, tremble or
be scared, and attributes fighting and saving to the LORD.

No enemy, army comparison, fear, priest approach, battle, divine fighting or
rescue occurs.

## Deuteronomy 20:5–9 — FOUR WAYS TO GO HOME BEFORE CAPTAINS ARE APPOINTED

Officers release four prospective classes: a man with a new undedicated house,
a planted vineyard whose fruit he has not used, a pledged wife he has not taken,
and a fearful/faint-hearted man whose heart may melt his brothers' hearts. The
first three routes name the risk that another person completes the interrupted
house, vineyard or marriage relation. After the speeches, captains are appointed
over the remaining people.

These are explicit exemption selectors, not desertions or completed losses. No
house, vineyard, engagement, fear, return, death or appointment occurs.

## Deuteronomy 20:10–15 — OFFER PEACE BEFORE THE DISTANT-CITY SIEGE

When approaching a city to fight it, Israel must proclaim peace. A peaceful
answer and opened city route its people into forced labor and service. Refusal
of peace plus war opens siege. If the LORD delivers that distant, non-
inheritance city, every male is struck; women, children, livestock and city
plunder are taken and may be used.

City response and city class jointly select the route. No city is approached,
offered peace, opened, subjected, besieged, delivered, killed or plundered.

## Deuteronomy 20:16–18 — THE NAMED INHERITANCE-CITY ROUTE IS DIFFERENT

Cities of the named Hittite, Amorite, Canaanite, Perizzite, Hivite and Jebusite
peoples in the given inheritance receive a distinct command: save alive nothing
that breathes and utterly destroy them. Prevention of teaching Israel their
religious practices is supplied as the purpose.

This rule is not silently applied to the distant-city branch. No named city,
person, teaching, copied practice, killing or destruction occurs.

## Deuteronomy 20:19–20 — THE TREE IS NOT BESIEGING YOU

During a long siege, food trees may be eaten from and may not be destroyed with
an axe. The source asks whether a field tree is a man that it should be besieged.
Trees known not to produce food may be cut and used to build siege works until
the city falls.

Food function selects protection; known non-food function selects possible
siege material. No tree, fruit, axe strike, bulwark, siege or city fall occurs.

## Character and world-ledger changes

- battle approach gains priest anti-fear speech and source-attributed LORD fighting/saving;
- undedicated-house, unused-vineyard, unconsummated-marriage and fearful-person exemptions remain distinct;
- captains are appointed only after exemption speech completes;
- every approached city first receives a peace proclamation;
- peace/open and refusal/war responses route service or siege;
- distant non-inheritance and named inheritance city classes retain separate outcomes;
- food and known non-food trees retain separate siege protections/uses;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every prospective living human, animal or plant Joe and face-like non-divine horse, chariot, house, vineyard, ring, sword, city, axe or bulwark is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — PRE-BATTLE FILTER / CITY ROUTER / TREE FIREWALL`;
- enemy scan: `HORSES + CHARIOTS + PEOPLE: MORE / FEAR: DISABLED`;
- exemption desk: `HOUSE / VINE / WIFE / HEART`;
- roster lock: `APPOINT CAPTAINS AFTER EVERYONE GOES HOME`;
- city handshake: `PEACE OFFER REQUIRED`;
- response router: `OPEN -> LABOR / WAR -> SIEGE`;
- geography warning: `DISTANT != INHERITANCE CLASS`;
- fruit-tree label: `THIS TREE IS NOT FUCKING BESIEGING YOU`;
- axe filter: `FOOD: NO CUT / NOT FOOD: BULWARK INPUT`;
- barcode: `CHB-DEU20-20-WAR-ROUTES-TREE-NOCASE-NOCRACK-HELD`.

## FIR verification

- all 20 verse markers are represented in order;
- pre-battle divine actions remain attributed future speech;
- all four exemptions retain exact unfinished relation/risk selectors;
- captain appointment follows the exemption stage;
- peace offer precedes the response-dependent city route;
- distant and named-inheritance cities are not merged;
- food and known non-food trees retain distinct selectors;
- no battle, return, peace, forced labor, siege, killing, plunder or tree cutting is invented;
- no unsupported contradiction machinery appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 21 joins the unsolved-murder heifer procedure,
captive-wife route, firstborn inheritance protection, rebellious-son judgment
and same-day burial of an executed body.
