# CRACKHEAD DEUTERONOMY 13

## Title page

**THE SIGN WORKED. DON'T FOLLOW HIM.**

**INVESTIGATE BEFORE BURNING THE WHOLE CITY.**

Source parent: Deuteronomy chapter 13, verses 1–18, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-013/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/012-HOLY-MEAT-THERE-ORDINARY-MEAT-HERE-DO-NOT-EAT-THE-BLOOD.md`.

CrackFlix routing: none. All three case systems remain prospective and retain explicit selectors.

## Causal foundation

```text
CASE A: PROPHET/DREAMER
SIGN/WONDER PREDICTED + COMES TO PASS
+ OTHER-GOD ENTICEMENT
-> DO NOT LISTEN
-> WALK/FEAR/KEEP/OBEY/SERVE/CLING TO LORD
-> ENTICER DEATH / EVIL REMOVED

CASE B: INTIMATE SECRET ENTICER
BROTHER/SON/DAUGHTER/WIFE/FRIEND SECRETLY ENTICES
-> NO CONSENT/LISTEN/PITY/SPARING/CONCEALMENT
-> ADDRESSEE FIRST HAND + PEOPLE AFTER
-> STONING DEATH -> ISRAEL HEARS/FEARS

CASE C: CITY REPORT
HEAR WICKED FELLOWS DREW CITY TO OTHER GODS
-> INQUIRE + INVESTIGATE + ASK DILIGENTLY
-> ONLY IF TRUE + CERTAIN + DONE
-> INHABITANTS/LIVESTOCK STRUCK
-> PLUNDER GATHERED + CITY/PLUNDER BURNED
-> FOREVER HEAP / NOT REBUILT / NOTHING RETAINED
```

## Deuteronomy 13:1–5 — A WORKING SIGN DOESN'T SELECT THE GOD

The first prospective case begins with a prophet or dreamer who supplies a sign
or wonder, the prediction comes to pass, and the same speaker calls for service
to unknown other gods. Israel must not listen. Moses attributes the situation
to divine testing of whole-heart/soul love and commands walking after, fearing,
keeping, obeying, serving and clinging to the LORD. The enticer is assigned
death for spoken rebellion and attempted diversion from the Egypt-redemption
route.

Prediction success and permitted allegiance are explicitly different fields.
The sign working while the instruction is rejected is therefore the stated test
design, not a contradiction. No prophet, dream, sign, speech or execution occurs.

## Deuteronomy 13:6–11 — THE PERSON YOU LOVE GETS NO SECRET EXCEPTION

The second case lists a mother's son/brother, son, daughter, bosom wife or
soul-like friend secretly enticing the addressee toward unknown near/far gods.
The response forbids consent, listening, pity, sparing and concealment. The
addressed person's hand goes first in killing, then all people's hands; the
specified mode is stoning, with hearing/fear/no-repeat stated as its effect.

These are conditional roles. No family member, spouse, friend, enticement,
accusation, stone, death or public response occurs here.

## Deuteronomy 13:12–14 — A REPORT IS NOT YET A CITY CONVICTION

The third case begins only after future receipt of a report that wicked fellows
from an Israelite city drew its inhabitants to unknown gods. The required gate
before consequences is explicit: inquire, investigate and ask diligently. Only
if the report is true, the thing certain and the abomination done does the
destruction branch open.

Hearing is therefore not treated as proof. No city, reporter, accused person,
witness, investigation, finding or certainty exists in this chapter.

## Deuteronomy 13:15–18 — THE TRUE-AND-CERTAIN CITY BRANCH

After the exact evidence gate, the city's inhabitants, contents and livestock
are assigned sword destruction. All plunder goes into the street middle; city
and plunder burn to the LORD; the site becomes a forever unrebuilt heap. No
devoted thing may cling to Israel's hand. Listening/keeping/right-doing and
zero retained plunder select turned anger, mercy, compassion and multiplication
under the ancestral oath.

This is an unexecuted branch, not a narrated massacre or fire.

## Character and world-ledger changes

- sign fulfillment and allegiance authorization become explicitly separate fields;
- the prophet/dreamer route retains divine-test attribution and prospective death outcome;
- intimate enticer identities remain conditional roles without instantiated people;
- first-hand/all-hands/stoning/hear-fear sequence remains unperformed;
- city hearsay is explicitly insufficient before inquiry/investigation/diligent asking;
- truth/certainty/completed-act selectors gate the city destruction branch;
- devoted plunder cannot be retained under the prospective mercy route;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every prospective living prophet, relative, friend, citizen, livestock Joe and face-like non-divine sign, stone, sword, street or heap is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — THREE-CASE ENTICEMENT ROUTER`;
- prophet check: `SIGN RESULT: TRUE / ALLEGIANCE: REJECTED`;
- test label: `WORKING DEMO IS NOT ROOT AUTHORITY`;
- family firewall: `BROTHER / CHILD / WIFE / BEST MATE — NO PRIVATE BYPASS`;
- hand order: `REPORTER FIRST / EVERYONE AFTER`;
- city intake: `HEARD != PROVED`;
- evidence gate: `INQUIRE / INVESTIGATE / ASK DILIGENTLY`;
- execution selector: `TRUE + CERTAIN + DONE`;
- plunder scanner: `NOTHING CLINGS TO HAND`;
- rebuild flag: `FALSE FOREVER`;
- barcode: `CHB-DEU13-18-THREE-PROSPECTIVE-CASES-NOCRACK-HELD`.

## FIR verification

- all 18 verse markers are represented in order;
- fulfilled prediction and allegiance authorization remain separate fields;
- divine-test purpose remains attributed source speech, not invented motive;
- no prophet, intimate enticer, reporter, city, accused person or victim is instantiated;
- city hearsay is not upgraded into truth or certainty;
- every killing/destruction/burning/mercy outcome retains its triggering selector;
- no stone, sword, plunder retention or public response occurs;
- no unsupported contradiction machinery appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 14 joins body-marking prohibition, clean/
unclean animal-food lists, dead-animal foreigner/sale routing, boiling-young-goat
prohibition and a chosen-place/three-year tithe system.
