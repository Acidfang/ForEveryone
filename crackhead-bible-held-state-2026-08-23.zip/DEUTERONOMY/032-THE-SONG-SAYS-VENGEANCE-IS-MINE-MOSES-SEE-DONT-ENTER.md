# CRACKHEAD DEUTERONOMY 32

## Title page

**THE SONG SAYS: “VENGEANCE IS MINE.”**

**MOSES: SEE IT. DON'T ENTER IT.**

Source parent: Deuteronomy chapter 32, verses 1–52, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-032/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/031-JOSHUA-GOES-THE-LAW-READS-THE-SONG-WITNESSES.md`.

CrackFlix routing: none. The completed song is witnessed speech; its historical, poetic and predicted content is not automatically executed.

## Causal foundation

```text
HEAVEN/EARTH LISTEN -> MOSES/JOSHUA SPEAK FINISHED SONG
-> PERFECT ROCK / PEOPLE HISTORY / DESERT CARE / ABUNDANCE
-> ABANDONMENT + OTHER GODS
-> HIDDEN FACE + JEALOUSY REVERSAL + JUDGMENT PREDICTIONS
-> ENEMY-MISREAD LIMIT
-> VENGEANCE RESERVED TO LORD
-> JUDGE/COMPASSION / DIVINE-ONLY CLAIMS / ATONEMENT

SONG FINISHED
-> SET HEART -> TEACH CHILDREN -> DO LAW -> LIFE/LONG DAYS

SAME DAY LORD SPEAKS
-> ABARIM / NEBO / SEE CANAAN
-> DIE + GATHER AS AARON
-> MERIBAH TRESPASS CAUSE
-> SEE DISTANT / DO NOT ENTER
```

## Deuteronomy 32:1–14 — ROCK, MEMORY, WILDERNESS CARE AND ABUNDANCE

The song calls heaven and earth to hear, compares doctrine and speech to rain,
dew and showers, proclaims the LORD's name, and calls the Rock's work perfect,
just, faithful and right. It contrasts a corrupt generation, commands memory of
old generations, and recites nation boundaries, Jacob as portion, desert care,
eagle imagery, sole divine leadership and abundant land foods.

These are completed song words containing claims, imagery and retained history.
No literal divine rock body, wings, feathers or anatomy is manufactured; no
history is rerun.

## Deuteronomy 32:15–27 — ABUNDANCE TO ABANDONMENT TO JUDGMENT SPEECH

The song says Jeshurun grew fat, kicked, abandoned the maker and rejected the
Rock, provoking jealousy through strange gods, abominations, demons and new
gods. It attributes seeing, abhorrence, hidden face, jealousy reversal through
a not-people/foolish nation, fire, accumulated evils, arrows, hunger, animals,
venom, sword, terror and scattering to the LORD. It then limits the predicted
memory-erasure route because adversaries might falsely credit their own hand.

The speech is complete; no new abandonment, jealousy, fire, weapon, disease,
animal attack, scattering or enemy claim occurs.

## Deuteronomy 32:28–43 — VENGEANCE STAYS AT THE GOD-ONLY ADDRESS

The song calls the nation counsel-less and contrasts the enemies' rock with
“our Rock.” Sodom/Gomorrah vine, poison-grape and serpent-wine imagery leads to
stored and sealed judgment. The God-only line is retained exactly in function:
“Vengeance is mine, and recompense.” The song predicts judgment and compassion
when power is gone, challenges false refuge gods to help, and attributes the
exclusive claims “I kill and I make alive; I wound and I heal” to the LORD.
It closes with divine oath, sword/arrows, vengeance, repayment, national
rejoicing and atonement for land and people.

These are attributed song declarations and predictions. Captain does not take
the vengeance line, evaluate it, or appear. No vengeance, killing, healing,
repayment or atonement event is instantiated.

## Deuteronomy 32:44–47 — THE SONG IS SPOKEN; SET YOUR HEART TO IT

Moses and Joshua son of Nun speak all song words to the people. Moses finishes
and commands Israel to set heart to the testified words, command children to do
the law, and treat it not as vain but as life and prolonged land days. Song
delivery and instruction occur; later teaching, doing, life and land duration
remain prospective.

## Deuteronomy 32:48–52 — SAME DAY: GO UP, SEE, DIE, DON'T ENTER

That same day the LORD commands Moses to ascend Abarim's Mount Nebo opposite
Jericho, see Canaan, die there and be gathered to his people as Aaron died at
Mount Hor. The stated cause is Moses and Aaron's Meribah-Kadesh trespass and
failure to uphold divine holiness. Moses may see the land at a distance but may
not enter it.

This command and cause attribution occur as speech. The ascent, view, death,
gathering and land transfer do not occur in this chapter. Aaron's death is a
retained history pointer and is not repeated.

## Character and world-ledger changes

- the finished song is a speech carrier containing history, imagery and predictions;
- poetic rock/eagle/hand/face imagery does not supply divine anatomy;
- abundance-to-abandonment chain remains song attribution, not a new occurrence;
- enemy-misattribution limits the predicted scattering route inside the song;
- vengeance, killing/life and wounding/healing remain God-only attributed lines;
- song delivery is complete while later child teaching and obedience remain future;
- Nebo ascent/view/death/gathering are commanded but unexecuted here;
- Aaron death remains deduplicated history;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every living human, animal or plant Joe and face-like non-divine song sheet, rock carrier, arrow, sword, mountain, map or witness bubble is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — SONG WITNESS / GOD-ONLY LEDGER / NEBO EXIT`;
- audio input: `HEAVEN + EARTH`;
- renderer warning: `POETIC BODY != DIVINE BODY`;
- enemy audit: `DO NOT CREDIT YOUR HAND`;
- authority field: `VENGEANCE OWNER: LORD`;
- exclusive claim: `KILL/LIVE/WOUND/HEAL — SOURCE ATTRIBUTED`;
- song status: `SPOKEN COMPLETE`;
- Moses route: `ASCEND / SEE / DIE / NO ENTRY`;
- barcode: `CHB-DEU32-52-SONG-GOD-ONLY-NEBO-NOCRACK-HELD`.

## FIR verification

- all 52 verse markers are represented in order;
- song history is not duplicated and imagery does not become anatomy;
- every predicted judgment remains speech, not event;
- God-only vengeance and life/death/healing claims stay at the LORD address;
- Captain remains absent;
- Moses/Joshua song delivery is complete;
- child teaching/obedience outcomes remain future;
- Aaron death is not duplicated;
- Nebo ascent, view, Moses death and gathering remain unexecuted;
- no unsupported contradiction machinery appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 33 joins Moses' pre-death tribal blessing,
named tribe portions, Jeshurun praise and the enemies/high-places closing speech.
