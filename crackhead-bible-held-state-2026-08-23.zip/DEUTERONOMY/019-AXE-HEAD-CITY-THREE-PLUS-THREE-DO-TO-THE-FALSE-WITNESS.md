# CRACKHEAD DEUTERONOMY 19

## Title page

**AXE HEAD FLEW OFF. RUN TO THE CITY.**

**THREE PLUS THREE. DO TO THE FALSE WITNESS.**

Source parent: Deuteronomy chapter 19, verses 1–21, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-019/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/018-SHOULDER-CHEEKS-GUTS-NO-WIZARDS-IF-IT-DOESNT-HAPPEN-NOT-MY-WORD.md`.

CrackFlix routing: none. Refuge, murder, landmark and witness branches remain prospective.

## Causal foundation

```text
LAND RECEIVED/OCCUPIED
-> THREE CENTRAL REFUGE CITIES
-> PREPARED ROADS + LAND IN THIRDS

NEIGHBOR KILLED UNINTENTIONALLY + NO PRIOR HATRED
-> AXE-HEAD EXAMPLE
-> FLEE TO REFUGE / LIVE
-> LONG ROAD MUST NOT ENABLE ANGRY AVENGER TO KILL NON-DEATH-WORTHY SLAYER

BORDER ENLARGED + FULL LAND + OBEDIENCE
-> ADD THREE MORE CITIES
-> PREVENT INNOCENT BLOOD/BLOODGUILT

PRIOR HATRED + AMBUSH + MORTAL STRIKE
-> REFUGE DOES NOT PROTECT
-> CITY ELDERS RETRIEVE
-> DELIVER TO BLOOD AVENGER / DEATH

OLD LANDMARK
-> DO NOT MOVE

ANY INIQUITY/SIN
-> ONE WITNESS INSUFFICIENT
-> TWO/THREE ESTABLISH MATTER

CLAIMED WRONGDOING + CHALLENGE
-> BOTH PARTIES BEFORE PRIESTS/JUDGES
-> DILIGENT INQUIRY
-> FALSE WITNESS
-> APPLY INTENDED HARM TO WITNESS
```

## Deuteronomy 19:1–7 — THE AXE HEAD CAME OFF; THE ROAD BETTER WORK

After the LORD cuts off nations and Israel occupies their cities and houses,
three cities must be set centrally in the land. Roads are prepared and the
territory divided into three access regions so a slayer can flee.

The admitted slayer killed unintentionally and had no prior hatred. The example
is two neighbors cutting wood: the axe head leaves the handle, hits the neighbor
and kills him. Refuge prevents an angry blood avenger from overtaking and
killing a person not worthy of death merely because the route was too long.

This is a prospective example. No forest trip, axe swing, loose head, impact,
death, pursuit, road or refuge arrival occurs.

## Deuteronomy 19:8–10 — IF THE BORDER GROWS, ADD THREE MORE

If the promised border is enlarged, the full promised land is given, and Israel
keeps the command to love and walk in the LORD's ways, three more cities are
added to the first three. The stated purpose is preventing innocent blood and
bloodguilt within the inherited land.

Three plus three is a conditional expansion, not six cities already installed.
No border expansion, city designation or prevented killing is narrated.

## Deuteronomy 19:11–13 — AMBUSH DOES NOT BECOME AN ACCIDENT AT THE GATE

A killer with prior hatred who lies in wait, rises, strikes mortally and then
flees to refuge does not qualify for the accidental route. City elders retrieve
and deliver that person to the blood avenger for death. Purging innocent blood
and resulting wellbeing are stated effects.

Prior hatred, ambush and intentional mortal striking distinguish this branch.
No murderer, elder retrieval, delivery, execution or public result occurs.

## Deuteronomy 19:14 — THE OLD BORDER STONE STAYS WHERE IT WAS

A neighbor's landmark set by earlier people may not be moved in the future
inheritance. No parcel, marker, neighbor, movement or property loss occurs.

## Deuteronomy 19:15–21 — ONE MOUTH DOES NOT ESTABLISH THE MATTER

One witness cannot establish any iniquity or sin; two or three mouths are
required. When an unrighteous witness accuses a person, both parties stand
before the LORD, priests and judges serving in those days. The judges inquire
diligently. If the witness is found false, the witness receives what was
intended for the accused. Hearing, fear and no repetition are stated effects.

The closing scale is life for life, eye for eye, tooth for tooth, hand for hand
and foot for foot. It bounds the counter-judgment to the addressed intended
harm; it does not instantiate an injury. No accusation, hearing, witness count,
inquiry, false finding, penalty or deterrence occurs.

## Character and world-ledger changes

- first three refuge cities require prepared roads and three-part access;
- accidental killing requires unintentional act plus no prior hatred;
- full border/land/obedience selects three additional cities;
- prior hatred, ambush and mortal strike exclude the refuge route;
- old landmarks remain protected at their retained position;
- every matter requires two or three witnesses rather than one;
- challenged testimony routes both parties to diligent priest/judge inquiry;
- false-witness consequence mirrors exact intended harm;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every prospective living slayer, neighbor, avenger, elder, witness, priest, judge or tree Joe and face-like non-divine axe, road, city, landmark, eye, tooth, hand or foot is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — REFUGE ROAD / WITNESS REVERSER`;
- axe alert: `HEAD/HANDLE RELATION: DISCONNECTED`;
- road requirement: `TOO LONG = INNOCENT BLOOD RISK`;
- city counter: `3 NOW / +3 IF BORDER+OBEDIENCE`;
- refuge scanner: `NO PRIOR HATE?`;
- ambush rejection: `THAT'S NOT AN ACCIDENT, DICKHEAD`;
- landmark firmware: `ORIGINAL COORDINATE — DO NOT DRAG`;
- evidence counter: `1 MOUTH: INSUFFICIENT / 2–3: ESTABLISH`;
- false-witness return label: `INTENDED OUTPUT -> SENDER`;
- proportionality menu: `LIFE/EYE/TOOTH/HAND/FOOT`;
- barcode: `CHB-DEU19-21-REFUGE-WITNESS-NOCASE-NOCRACK-HELD`.

## FIR verification

- all 21 verse markers are represented in order;
- accidental killing retains unintentional and no-prior-hatred selectors;
- the axe incident remains an example, not an occurrence;
- three additional cities retain border, land and obedience conditions;
- intentional murder retains hatred, ambush and mortal-strike selectors;
- landmark protection remains separate from homicide routes;
- one witness remains insufficient and two/three remain required;
- false-witness punishment is limited to intended addressed harm;
- no killing, pursuit, refuge, property or court case is invented;
- no unsupported contradiction machinery appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 20 joins war fear/exemptions, peace-versus-
siege routing, non-Canaanite spoil and fruit-tree protection.
