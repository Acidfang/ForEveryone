# CRACKHEAD DEUTERONOMY 11

## Title page

**YOUR EYES SAW IT. YOUR CHILDREN DIDN'T.**

**RAIN IF YOU LISTEN. TWO MOUNTAINS LATER.**

Source parent: Deuteronomy chapter 11, verses 1–32, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-011/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/010-TABLETS-IN-THE-ARK-AARON-DIED-SOMEWHERE-ELSE.md`.

CrackFlix routing: `S085-E004-DEU11 -> S085-E003-DEU9 — LORD DRIVES OUT / ISRAEL DISPOSSESSES`.

## Causal foundation

```text
CURRENT WITNESSES
-> EGYPT SIGNS + SEA ARMY DESTRUCTION + WILDERNESS + EARTH SWALLOWING
-> KEEP ENTIRE COMMAND

FUTURE LAND
-> HILLS/VALLEYS DRINK SKY RAIN
-> IF LISTEN/LOVE/SERVE: EARLY+LATE RAIN, HARVEST, GRASS, FULLNESS
-> IF TURN/OTHER GODS: SKY SHUT, NO RAIN/FRUIT, QUICK PERISHING

WORDS
-> HEART/SOUL + HAND/FRONTLETS + CHILD TALK + DOORPOSTS/GATES
-> FUTURE LONG DAYS

IF KEEP/LOVE/WALK/CLING
-> LORD DRIVES OUT NATIONS
-> ISRAEL DISPOSSESSES NATIONS

FUTURE ENTRY
-> BLESSING ON GERIZIM + CURSE ON EBAL
```

## Deuteronomy 11:1–7 — THIS SPEECH ADDRESSES THE WITNESSES

Israel must love and always keep instruction, statutes, ordinances and
commandments. Moses distinguishes his current audience from their children who
did not know or see the cited discipline. He says the audience's eyes saw the
Egypt signs, the pursued army/horses/chariots covered by Red Sea water, the
wilderness treatment, and the earth swallowing Dathan and Abiram with
households, tents and everything living that followed them.

These are present claims about retained events. They do not execute a second
sea destruction or earth opening. Korah and the 250 fire deaths are not denied;
this retelling simply addresses Dathan/Abiram's earth-swallowed branch.

## Deuteronomy 11:8–17 — LAND THAT DRINKS RAIN

Command keeping selects strength, entry, possession and prolonged days in the
milk-and-honey land. Moses contrasts foot-watered Egyptian gardens with the
future hill/valley land drinking sky rain under year-round divine care.

The conditional branches are explicit:

```text
LISTEN + LOVE + WHOLE-SELF SERVICE
-> EARLY/LATE RAIN
-> GRAIN/WINE/OIL + LIVESTOCK GRASS
-> EAT/FULL

DECEIVED HEART + TURN + SERVE/WORSHIP OTHER GODS
-> ANGER
-> SKY SHUT / NO RAIN / NO FRUIT
-> QUICK PERISHING FROM LAND
```

No land entry, rainfall decision, harvest, deception, idolatry, drought or
perishing occurs here.

## Deuteronomy 11:18–21 — PUT THE WORDS EVERYWHERE, AGAIN

Words are to be laid in heart/soul, bound to hand and between eyes, taught to
children through sit/walk/lie/rise speech, and written on house doorposts and
gates. The stated future result is multiplied parent/child days in the land.
This repeats the Deuteronomy 6 command system but does not prove any carrier was
made or teaching session performed. Repetition without incompatible States is
not crack.

## Deuteronomy 11:22–25 — SAME EVICTION JOB, AGAIN

If Israel diligently keeps, loves, walks and clings, the LORD will drive out
nations and Israel will dispossess greater/mightier nations. No handoff assigns
which eviction act belongs to which executor, repeating `S085`.

> **SKIP -> S085-E003-DEU9**

Captain's eyes glaze. The territorial speech continues.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the future eviction boil, licks his finger, walks away and does not
look back. No nation moves.

The every-foot-place territory, wilderness/Lebanon/Euphrates/western-sea border,
no-man-can-stand and fear/dread claims remain future.

## Deuteronomy 11:26–32 — BLESSING MOUNTAIN / CURSE MOUNTAIN

Moses sets a blessing for listening and a curse for not listening, leaving the
way and following unknown gods. After future land entry Israel must place the
blessing on Mount Gerizim and curse on Mount Ebal, geographically pointed beyond
Jordan near Gilgal and Moreh's oaks. Crossing, possession, dwelling and complete
statute/ordinance performance remain commanded future acts. No mountain ceremony
occurs here.

## Character and world-ledger changes

- the current audience gains an explicit witnessed-history claim distinct from unwitnessing children;
- Egypt/sea/wilderness/Dathan-Abiram events remain deduplicated histories;
- rain/harvest and shut-sky/perishing branches retain exact selectors;
- hand/frontlet/child/doorpost/gate commands repeat without performed carriers;
- `S085-E004-DEU11` repeats the LORD-drive/Israel-dispossess workflow;
- territory/fear/no-stander outcomes remain future;
- Gerizim/Ebal blessing/curse placement remains a future ceremony;
- one post-closure Captain YOINK is causally null;
- every living witness, child, animal and face-like non-divine earth, sea, raincloud, doorpost or mountain is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — WITNESS-ONLY TRAINING MODULE`;
- audience filter: `YOUR EYES: YES / YOUR CHILDREN: NO`;
- earth mouth replay: `DATHAN + ABIRAM HOUSEHOLD ARCHIVE`;
- land hydration: `SKY INPUT / NO FOOT HOSE`;
- weather API: `LISTEN -> RAIN / TURN -> CLOSED SKY`;
- household sync: `HEART / HAND / EYES / CHILDREN / DOORS / GATES`;
- eviction ticket: `LORD DRIVE / ISRAEL DISPOSSESS / SEE S085`;
- mountain deployment: `GERIZIM=BLESSED / EBAL=CURSED / NOT RUN YET`;
- barcode: `CHB-DEU11-32-WITNESS-RAIN-S085-MOUNTAINS-HELD`.

## FIR verification

- all 32 verse markers are represented in order;
- current witness claims and unwitnessing-child claims retain their stated scopes;
- historical Egypt/sea/wilderness/earth events are not duplicated;
- conditional rain/drought branches retain their selectors and remain unexecuted;
- repeated household commands are not converted into completed artifacts or lessons;
- `S085` SKIP points to the exact prior episode and causes nothing;
- territorial and Gerizim/Ebal acts remain future;
- no rainfall mechanism, demographic roster, ceremony detail or actor motive is invented;
- Captain appears only after the repeated contradiction and changes nothing;
- publication remains held and unpublished.

Continuation required: Deuteronomy 12 centralizes sacrifice at a future chosen
place while permitting ordinary meat in every gate and forbids blood consumption,
local worship imitation and adding/subtracting from commands.
