# CRACKHEAD DEUTERONOMY 22

## Title page

**RETURN THE DONKEY. BUILD A ROOF RAIL.**

**DON'T MERGE THE CASES.**

Source parent: Deuteronomy chapter 22, verses 1–30, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-022/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/021-UNKNOWN-KILLER-HEIFER-HATED-WIFE-FIRSTBORN-BURY-HIM-TODAY.md`.

CrackFlix routing: none. All property, safety, material and sexual-case branches remain prospective.

## Causal foundation

```text
BROTHER'S LOST THING FOUND
-> RETURN NOW, OR HOUSE UNTIL OWNER SEEKS
FALLEN DONKEY/OX SEEN
-> HELP LIFT

MEN'S/WOMEN'S CLOTHING
-> CROSS-CLASS WEARING PROHIBITED

NEST + MOTHER ON YOUNG/EGGS
-> RELEASE MOTHER / YOUNG MAY BE TAKEN

NEW HOUSE
-> ROOF RAIL -> PREVENT FALL/BLOODGUILT

VINEYARD -> NO TWO SEED KINDS
PLOW -> NO OX + DONKEY TOGETHER
CLOTH -> NO WOOL + LINEN TOGETHER
CLOAK -> FRINGES ON FOUR CORNERS

MARRIAGE/SEXUAL CASE
-> ROUTE BY CLAIM + EVIDENCE + MARITAL STATUS + LOCATION + FORCE + CRY/RESCUE
```

## Deuteronomy 22:1–4 — YOU SAW IT; YOU DON'T GET TO HIDE

A brother's stray ox or sheep must be returned. If the owner is distant or
unknown, the finder keeps it at home until the owner seeks it, then restores it.
The same route covers donkey, garment and every lost thing. A fallen donkey or
ox seen on the road must be lifted with its owner.

No lost object, owner, storage, return, fallen animal or lifting occurs.

## Deuteronomy 22:5 — THE SOURCE'S CLOTHING BOUNDARY

The text prohibits a woman wearing men's clothing and a man wearing women's
clothing, calling the act an abomination to the LORD. The clothing classes and
speaker judgment are retained exactly; no wearer, garment, act, identity motive
or enforcement event is invented.

## Deuteronomy 22:6–7 — TAKE THE YOUNG, RELEASE THE MOTHER

At a roadside tree or ground nest where a mother bird sits on young or eggs,
the mother may not be taken with them. The mother is released; the young may be
taken. Wellbeing and prolonged days are stated effects. No nest, bird, egg,
capture, release or effect occurs.

## Deuteronomy 22:8–12 — BUILD THE SAFETY RAIL; KEEP THE INPUTS SEPARATE

A new house requires a roof railing so a fall does not bring bloodguilt on the
house. A vineyard may not receive two seed kinds; ox and donkey may not plow
together; wool and linen may not be woven together. A cloak receives fringes on
its four corners.

These are four distinct building/agricultural/material/clothing rules. No house,
fall, seed, plowing team, cloth, cloak or fringe occurs.

## Deuteronomy 22:13–21 — HUSBAND'S ACCUSATION ROUTES THROUGH THE CLOTH CLAIM

A husband who has intercourse with his wife, hates her, gives her a bad name
and alleges missing virginity tokens opens a gate procedure. Her father and
mother present the claimed tokens; the father states the accusation and the
cloth is spread before city elders. If that evidence defeats the accusation,
the husband is chastised, fined one hundred shekels payable to her father, and
may never put her away.

If the allegation is found true under the stated token test, the text assigns
her death by stoning at her father's door. The source's evidence model and
punishment are retained without claiming medical reliability, truth outside
the case, or an actual person. No marriage, sex, hatred, accusation, cloth,
finding, fine, confinement or death occurs.

## Deuteronomy 22:22–27 — MARRIED, PLEDGED-CITY, PLEDGED-FIELD ARE DIFFERENT CASES

A man found lying with another man's married wife routes both to death. A
pledged virgin encountered in a city routes both to death under the text's
no-cry city selector. A pledged woman forced in a field routes only the man to
death; nothing is done to her, no death-worthy sin is assigned to her, and the
text says she cried with nobody there to save her.

These branches explicitly differ by marital status, location, force and the
source's cry/rescue inference. They are not merged or generalized. No encounter,
intercourse, force, cry, rescue opportunity, finding or death occurs.

## Deuteronomy 22:28–30 — UNPLEDGED GRABBING ROUTE AND FATHER'S-WIFE BOUNDARY

If a man finds an unpledged virgin, grabs her, has intercourse with her and they
are found, the text requires fifty shekels to her father, marriage and no future
divorce because he humbled her. The rule supplies no consent and none is
invented. The chapter closes by prohibiting taking a father's wife or uncovering
the father's skirt.

No woman, man, father, grabbing, sex, discovery, payment, marriage or divorce
occurs.

## Character and world-ledger changes

- lost-property and fallen-animal routes make seeing incompatible with hiding;
- clothing classes remain source-defined without an instantiated wearer;
- nest mother/young route, roof rail and mixed-input rules remain prospective;
- hostile-husband accusation retains parent evidence, cloth, elder and two outcome branches;
- married, pledged-city, pledged-field and unpledged cases remain distinct;
- no consent is added to forced or grabbing routes;
- all fines, marriages, no-divorce constraints and deaths remain unperformed;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every prospective living human, animal or plant Joe and face-like non-divine garment, nest, egg, railing, seed, plow, cloth, fringe, shekel or stone is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — RETURN DESK / ROOF SAFETY / CASE ROUTER`;
- lost-property switch: `SAW IT -> CAN'T HIDE`;
- donkey storage ticket: `OWNER UNKNOWN — HOLD UNTIL QUERY`;
- roof warning: `PARAPET REQUIRED / GRAVITY ENABLED`;
- field compiler: `TWO SEEDS: REJECTED`;
- plow coupling: `OX + DONKEY: INCOMPATIBLE HARNESS`;
- fabric scanner: `WOOL + LINEN: BUILD FAILED`;
- cloak job: `FOUR CORNERS -> FOUR FRINGES`;
- case warning: `STATUS + PLACE + FORCE + CRY != SAME FUCKING CASE`;
- evidence sheet: `SOURCE TEST RETAINED / RELIABILITY NOT INVENTED`;
- barcode: `CHB-DEU22-30-PROPERTY-SAFETY-CASE-ROUTES-NOCRACK-HELD`.

## FIR verification

- all 30 verse markers are represented in order;
- lost-owner-known/unknown and fallen-animal routes remain distinct;
- no clothing identity or motive is inferred;
- bird, roof and mixed-input rules remain unexecuted;
- hostile-husband accusation and claimed token evidence remain attributed case elements;
- source evidence is not upgraded into modern factual reliability;
- married, pledged-city, pledged-field and unpledged routes retain exact selectors;
- force and absence of rescue remain attached only to the field case;
- no consent is invented in the grabbing case;
- no person, sex act, accusation, evidence, punishment or marriage is instantiated;
- no unsupported contradiction machinery appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 23 joins assembly exclusions, camp sanitation,
escaped-servant protection, prostitution/interest/vow rules and neighbor crop access.
