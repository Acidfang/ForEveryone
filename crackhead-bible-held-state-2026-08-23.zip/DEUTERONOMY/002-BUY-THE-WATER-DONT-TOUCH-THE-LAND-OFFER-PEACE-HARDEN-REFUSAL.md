# CRACKHEAD DEUTERONOMY 2

## Title page

**BUY THEIR WATER. DON'T TOUCH THEIR LAND.**

**OFFER SIHON PEACE. HARDEN HIS REFUSAL. TAKE EVERYTHING.**

Source parent: Deuteronomy chapter 2, verses 1–37, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-002/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/001-ELEVEN-DAYS-FORTY-YEARS-WE-SINNED-THEN-WENT-ANYWAY.md`.

CrackFlix routing: `S122-E001-DEU2 — PEACE OFFER / HARDENED REFUSAL / TOTAL DELIVERY`.

## Causal foundation

```text
SEIR: PASS CAREFULLY / BUY FOOD + WATER / TAKE NO LAND
MOAB: DO NOT BATTLE / TAKE NO LAND
AMMON: DO NOT BOTHER / TAKE NO LAND
-> ALL THREE PROTECTED BOUNDARIES RETAINED

SIHON LAND: BEGIN TO POSSESS / CONTEND IN BATTLE
-> MOSES SENDS WORDS OF PEACE + PAID-PASSAGE OFFER
-> SIHON REFUSES
-> SOURCE: LORD HARDENED SPIRIT + HEART FOR DELIVERY
-> SIHON COMES TO BATTLE
-> SIHON / SONS / PEOPLE STRUCK; CITIES DESTROYED; PLUNDER TAKEN
-> AMMON BOUNDARY STILL UNTOUCHED
```

## Deuteronomy 2:1–8 — LONG ENOUGH AROUND SEIR

Moses recounts turning toward the Red Sea wilderness and circling Mount Seir
many days. The LORD says the circling is long enough and commands a northward
turn through Esau's border. Israel must be careful because Esau's children will
fear them, must not contend, and will receive none of Seir—not even a footprint.
Food and water are to be purchased for money. Moses attributes forty years of
provision and lack of nothing to the LORD. Israel passes by Seir through the
Arabah route from Elath and Ezion Geber toward Moab.

The passage and restraint are completed in the retelling. No purchase amount,
seller, individual transaction or fearful act is supplied.

## Deuteronomy 2:9–12 — MOAB'S LAND IS NOT ISRAEL'S LAND

The LORD commands Israel not to bother Moab or contend in battle because Ar is
Lot's children's possession. The source inserts a population-history ledger:
Emim formerly lived there, were great, numerous and tall, were classified as
Rephaim and called Emim by Moabites. Horites formerly lived in Seir; Esau's
children displaced and destroyed them and lived there. These names,
classifications and succession claims remain source-attributed; no body form,
date, population total or mechanism is invented.

## Deuteronomy 2:13–16 — THIRTY-EIGHT YEARS TO ZERED

Israel is told to cross Zered and does. The source measures thirty-eight years
from Kadesh Barnea until the crossing, when the war generation is consumed and
dead from the camp, and attributes their destruction to the LORD's hand. This
closes the retrospective generation interval without listing each death or
inventing a death schedule.

## Deuteronomy 2:17–23 — AMMON ALSO HAS A PROTECTED BORDER

After the war men are gone, the LORD commands passage over Ar and forbids
bothering or contending with Ammon because its land is Lot's children's
possession. Another source history calls earlier inhabitants Rephaim and records
the Ammonite name Zamzummim; it says the LORD destroyed them before Ammon, as
with Horites before Esau. It separately records Caphtorim displacing Avvim as
far as Gaza. These completed past claims remain distinct; Israel performs none
of those earlier displacements in this chapter.

## Deuteronomy 2:24–30 — WORDS OF PEACE INSIDE A BATTLE ROUTE

At Arnon, the LORD commands Israel to begin possessing Sihon's land and contend
in battle, and says dread of Israel will begin among peoples hearing the report.
Moses then sends Sihon words of peace: allow straight highway passage, sell food
and water, and let Israel cross toward the Jordan as Esau and Moab did.

Sihon refuses passage. The source immediately supplies this relation:

```text
LORD HARDENED SIHON'S SPIRIT
+ MADE HIS HEART OBSTINATE
-> SO HE MIGHT DELIVER SIHON INTO ISRAEL'S HAND
```

No hidden motive is inferred for Moses, Sihon or the LORD. The peaceful offer,
refusal, source-attributed hardening purpose and already-stated battle command
are simply retained together.

## Deuteronomy 2:31–37 — THE REFUSAL OPENS INTO TOTAL DELIVERY

The LORD says delivery has begun and repeats the possession command. Sihon and
all his people come to battle at Jahaz. Israel strikes Sihon, his sons and all
his people; takes every city; destroys every inhabited city including women and
little ones; leaves no one; and keeps livestock and city plunder. From Aroer and
the Arnon valley to Gilead, no city is too high. The chapter attributes the
delivery to the LORD.

Israel does not approach Ammon's land, the Jabbok banks, hill-country cities or
anywhere the LORD forbade. Protected borders and conquered Sihon territory are
not merged.

The completed friction is:

```text
WORDS OF PEACE OFFER PASSAGE
-> SOURCE ACTOR HARDENS RECIPIENT'S REFUSAL FOR DELIVERY
-> REFUSAL OCCURS
-> RECIPIENT AND ENTIRE ADDRESSED CITY POPULATION ARE DELIVERED/DESTROYED
```

This is `S122-E001-DEU2`. It is not routed to `S069`: Sihon is not narrated as
receiving a divine release command, and Moses—not the hardening actor—makes the
passage offer.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes Sihon's boil, licks his finger, walks away and does not look back. He
believes the boil is crack. The conquest and Ammon restraint remain unchanged.

## Character and world-ledger changes

- Israel gains completed Seir/Moab/Ammon restraint and Zered crossing states;
- source-attributed Emim/Horite/Zamzummim/Avvim/Caphtorim histories remain separate;
- the Kadesh-to-Zered war-generation interval closes at thirty-eight years;
- Moses gains a completed Sihon peace-message act;
- Sihon gains refusal, Jahaz battle, defeat and death states;
- Sihon's sons, people and inhabited cities receive the stated destruction outcome;
- livestock and city goods become Israelite plunder;
- Ammon's forbidden boundary remains respected;
- `S122` preserves different offerer and hardener actors;
- Captain is boilless, causally useless and appears only after completion;
- every living being and face-like border, coin, water, route, city or heart is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — BORDER CONTROL / WATER PURCHASE DIVISION`;
- Seir warning: `0.0 FOOTPRINTS OF LAND INCLUDED`;
- shop sign: `FOOD + WATER FOR MONEY / NO INVASION POINTS`;
- route timer: `KADESH -> ZERED: 38 YEARS / WAR JOE COUNTER: 0`;
- extinct-neighbour directory: `EMIM / HORITE / ZAMZUMMIM / AVVIM — PREVIOUS TENANTS`;
- peace ticket: `STRAIGHT THROUGH / PAID SNACKS / NO LEFT OR RIGHT`;
- hidden system label: `HARDEN REFUSAL FOR DELIVERY`;
- city status: `TOO HIGH: NONE / LEFT ALIVE: NONE / LIVESTOCK: BAGGED`;
- Ammon geofence: `STILL FUCKING WORKS`;
- barcode: `CHB-DEU2-37-3PROTECTED-1DELIVERED-S122-YOINK-HELD`.

## FIR verification

- all 37 verse markers are represented in order;
- present retrospective speech and earlier acts remain separated;
- all protected territories remain distinct from Sihon's conquered territory;
- population-history labels and acts retain source attribution;
- no purchase, fear response, body form or death schedule is invented;
- peace offer, refusal, hardening relation, battle and destruction remain ordered;
- `S122` is not falsely merged into the Pharaoh command/hardening series;
- Captain appears after completion and changes nothing;
- future western entry and later campaigns are not imported;
- publication remains held and unpublished.

Continuation required: Deuteronomy 3 recounts Og's defeat, east-land division,
Joshua's battle instruction and Moses' denied request to cross the Jordan.
