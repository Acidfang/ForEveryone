# CRACKHEAD DEUTERONOMY 18

## Title page

**SHOULDER. CHEEKS. GUTS.**

**NO WIZARDS. IF IT DOESN'T HAPPEN, NOT MY WORD.**

Source parent: Deuteronomy chapter 18, verses 1–22, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-018/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/017-TWO-WITNESSES-HIGH-COURT-NO-HORSE-WIFE-MONEY-PILE.md`.

CrackFlix routing: none. Priest, prohibited-practice and prophet rules remain prospective.

## Causal foundation

```text
LEVI HAS NO LAND PORTION
-> LORD/OFFERINGS ARE PORTION
-> SACRIFICE -> PRIEST GETS SHOULDER + CHEEKS + INNER PARTS
-> FIRST GRAIN/WINE/OIL/FLEECE -> PRIEST

LEVITE LEAVES LOCAL GATE BY OWN DESIRE
-> COMES TO CHOSEN PLACE
-> MINISTERS LIKE LEVITE BROTHERS
-> EQUAL EATING PORTION
-> FAMILY-PROPERTY SALE REMAINS ADDITIONAL

FUTURE LAND ENTRY
-> DO NOT COPY NATIONS
-> NO CHILD THROUGH FIRE / DIVINATION / FORTUNE / ENCHANTMENT /
   SORCERY / CHARM / SPIRIT CONSULTATION / WIZARD / NECROMANCY

HOREB PEOPLE REQUEST NO MORE DIRECT VOICE/FIRE
-> LORD SAYS THEY SPOKE WELL
-> FUTURE BROTHER-PROPHET LIKE MOSES
-> LORD WORDS IN MOUTH / PEOPLE LISTEN

PROPHET CLAIMS LORD-WORD
-> THING DOES NOT FOLLOW/HAPPEN
-> LORD DID NOT SPEAK IT
-> PRESUMPTUOUS / DO NOT FEAR PROPHET
```

## Deuteronomy 18:1–5 — NO LAND SHARE; HERE ARE THE PRIEST INPUTS

Levi has no ordinary portion or inheritance with Israel; the LORD and offerings
are stated as the inheritance. From an ox or sheep sacrifice, the priest's due
is shoulder, two cheeks and inner parts. First grain, new wine, oil and sheep
fleece also route to the priest because the LORD selected priest and sons to
stand and minister in the LORD's name.

No land allocation, sacrifice, animal part, crop, fleece, transfer, eating or
ministry occurs.

## Deuteronomy 18:6–8 — A LOCAL LEVITE MAY JOIN THE CHOSEN-PLACE SHIFT

A Levite who leaves any local gate and comes with full personal desire to the
chosen place may minister like the Levites already standing there. Equal eating
portions apply in addition to proceeds from sale of family possessions.

The local origin and family-property proceeds do not reduce the ministry or
food share. No Levite moves, sells, joins, ministers or eats.

## Deuteronomy 18:9–14 — DON'T LEARN THE NATIONS' INPUT METHODS

After future land entry, Israel may not imitate the listed national practices:
passing son or daughter through fire, divination, fortune-telling, enchantment,
sorcery, charming, familiar-spirit consultation, wizardry or necromancy. The
source calls practitioners abominable, attributes national displacement to
these practices and commands Israel to be blameless instead.

No child, practitioner, ritual, spirit, prediction, imitation or displacement
is newly instantiated.

## Deuteronomy 18:15–19 — YOU ASKED NOT TO HEAR THE FIRE AGAIN

Moses promises that the LORD will raise a prophet from Israelite brothers like
him, whom Israel must hear. The route is tied to the Horeb assembly request not
to hear the LORD's direct voice or see the great fire again lest the people die.
Moses reports the LORD saying they spoke well, promising a brother-prophet,
words placed in that prophet's mouth, and accountability for those who refuse
the commanded words.

The promise does not identify, raise, name or authenticate a particular later
person in this chapter. No later fulfillment is imported.

## Deuteronomy 18:20–22 — IF IT DOESN'T HAPPEN, IT WASN'T MY WORD

A prophet speaking an uncommanded word presumptuously in the LORD's name, or
speaking for other gods, is assigned death. The supplied recognition test is
observable: when the claimed LORD-word does not follow or happen, the LORD did
not speak it; the prophet spoke presumptuously and need not be feared.

This joins rather than conflicts with Deuteronomy 13:

```text
PREDICTION FAILS -> CLAIMED LORD-WORD REJECTED
PREDICTION SUCCEEDS -> RESULT FIELD PASSES, ALLEGIANCE STILL TESTED
```

Failure supplies rejection evidence. Success alone does not supply total
authorization. No prophet, prediction, elapsed deadline, outcome, refusal,
fear or death occurs here.

## Character and world-ledger changes

- Levi's non-land inheritance and offering portions gain exact shoulder/cheeks/inner-parts and first-produce routes;
- a willing gate Levite may join chosen-place ministry with equal food share;
- family-property proceeds remain additional rather than replacing that share;
- prohibited practice classes remain future exclusions without invented practitioners;
- the Horeb direct-voice request remains the parent of the prophet-like-Moses promise;
- no later identity is backfilled as the promised prophet;
- failed prediction and successful-sign tests remain asymmetric and compatible;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every prospective living human, animal or plant Joe and face-like non-divine shoulder, cheek, gut, fleece, coin, fire, crystal ball or prediction scroll is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — PRIEST CUTS / WIZARD FIREWALL / PROPHET TEST`;
- butcher ticket: `SHOULDER + 2 CHEEKS + GUTS -> PRIEST`;
- produce chute: `FIRST GRAIN / WINE / OIL / FLEECE`;
- Levite transfer screen: `LOCAL GATE -> CHOSEN SHIFT / EQUAL LUNCH`;
- property note: `SALE PROCEEDS DO NOT DELETE LUNCH`;
- occult firewall: `CHILD FIRE / MAGIC / DEAD CHAT — ALL PORTS CLOSED`;
- Horeb service request: `DIRECT VOICE TOO LOUD — MESSENGER MODE`;
- prophet output monitor: `DID IT HAPPEN?`;
- failure result: `NOT MY FUCKING WORD`;
- cross-test label: `SUCCESS IS NOT ROOT AUTHORITY`;
- barcode: `CHB-DEU18-22-PORTIONS-NOWIZARDS-FAILEDWORD-NOCRACK-HELD`.

## FIR verification

- all 22 verse markers are represented in order;
- priest portions and migrant-Levite equality retain exact sources and additions;
- no offering, sale, migration or ministry occurrence is invented;
- every prohibited practice remains a class rule without a practitioner case;
- Horeb speech is retained as historical parent, not repeated as a new event;
- the promised prophet remains unidentified and future;
- failed-prediction rejection does not become successful-prediction authorization;
- no prophet, word, outcome, execution or fear response occurs;
- no unsupported contradiction machinery appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 19 joins three refuge cities, accidental
killing, boundary-marker protection, witness sufficiency and false-witness
counter-judgment.
