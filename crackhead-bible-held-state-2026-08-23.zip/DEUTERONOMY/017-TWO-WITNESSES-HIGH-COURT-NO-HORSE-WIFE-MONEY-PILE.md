# CRACKHEAD DEUTERONOMY 17

## Title page

**TWO WITNESSES. HIGH COURT.**

**KING: NO HORSE, WIFE OR MONEY PILE.**

Source parent: Deuteronomy chapter 17, verses 1–20, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-017/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/016-THREE-FEASTS-DONT-SHOW-UP-EMPTY-DONT-BLIND-THE-JUDGE.md`.

CrackFlix routing: none. Every sacrifice, idolatry, court and kingship branch remains prospective.

## Causal foundation

```text
OX/SHEEP + DEFECT/EVIL THING
-> NOT SACRIFICED TO LORD

REPORT OF OTHER-GOD/SUN/MOON/STAR WORSHIP
-> DILIGENT INQUIRY
-> TRUE + CERTAIN + DONE
-> TWO OR THREE WITNESSES, NOT ONE
-> WITNESSES' HANDS FIRST / PEOPLE AFTER
-> STONING DEATH / EVIL REMOVED

LOCAL BLOOD/PLEA/STROKE MATTER TOO HARD
-> GO TO CHOSEN PLACE
-> LEVITICAL PRIESTS + CURRENT JUDGE
-> VERDICT/TEACHING
-> DO EXACTLY / NO RIGHT-LEFT DEPARTURE
-> PRESUMPTUOUS REFUSAL -> DEATH

LAND POSSESSED + PEOPLE REQUEST KING
-> LORD-CHOSEN ISRAELITE BROTHER
-> NO FOREIGNER
-> NO MULTIPLIED HORSES / EGYPT RETURN
-> NO MULTIPLIED WIVES / SILVER / GOLD
-> KING WRITES LAW COPY FROM PRIEST COPY
-> KEEPS + READS ALL LIFE
-> FEAR/OBEY/NO LIFTED HEART/NO DEVIATION
```

## Deuteronomy 17:1 — DEFECTIVE DOESN'T ENTER THE SACRIFICE ROUTE

An ox or sheep with a defect or evil thing may not be sacrificed to the LORD;
the source calls that an abomination. This joins the retained defective-animal
offering exclusions. No animal, defect inspection, sacrifice or rejection occurs.

## Deuteronomy 17:2–7 — HEARD IS NOT TRUE; ONE WITNESS IS NOT TWO

The prospective case begins with a man or woman within a future gate serving
and worshipping other gods, sun, moon or heavenly host. Being told and hearing
opens diligent inquiry, not punishment. Only if the matter is true, certain and
done does the death branch open. Death requires two or three witnesses; one
witness cannot support it. Witness hands go first, then the people's hands.

The procedure joins Deuteronomy 13's report/evidence gate without creating a
new occurrence. No worshipper, report, inquiry, witness, verdict, stone, death
or public response exists here.

## Deuteronomy 17:8–13 — TOO HARD LOCALLY? SEND THE RELATION UP

A blood-versus-blood, plea-versus-plea or stroke-versus-stroke controversy too
hard for a local gate goes to the chosen place. Levitical priests and the judge
serving in those days issue the verdict. Israel must perform the decision and
teaching without turning right or left.

A man who presumptuously refuses the ministering priest or judge is assigned
death, with public hearing, fear and no-more-presumption stated as effects. No
controversy, referral, court, verdict, refusal, death or deterrence occurs.

## Deuteronomy 17:14–17 — IF YOU ASK FOR A KING, HERE IS THE INPUT FILTER

After future entry, possession and settlement, Israel may say it will set a
king like surrounding nations. The king must be the LORD's choice, an Israelite
brother rather than a foreigner. He may not multiply horses or return people to
Egypt to multiply horses. He may not multiply wives so his heart turns, or
greatly multiply silver and gold.

The public request and divine/person eligibility selectors coexist: the people
request the office; the LORD selects the permitted person. No land entry,
request, selection, coronation, horse, Egypt journey, marriage or wealth pile
occurs.

## Deuteronomy 17:18–20 — THE KING HANDWRITES HIS OWN COPY

On taking the throne, the future king must write a copy of this law in a book
from the copy before the Levitical priests. It stays with him and he reads it
all his life to learn fear, keep and perform the law, avoid elevating his heart
above his brothers, and avoid right/left departure. Prolonged dynastic days are
the stated outcome.

No throne, king, book, copying, reading, learning, obedience or dynasty occurs.

## Character and world-ledger changes

- defective ox/sheep exclusion joins the retained offering classifier;
- idolatry allegation requires diligent inquiry, true/certain/done and two-or-three-witness gates;
- witness-first/public-after sequencing remains unperformed;
- hard local controversies route to priests and the serving judge at the chosen place;
- future Israelite kingship retains public-request, divine-choice and brother-identity selectors;
- horse/Egypt, wives, silver and gold limits remain prospective;
- the king's handwritten/read-for-life law copy becomes a future office requirement;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every prospective living person, animal or plant Joe and face-like non-divine witness statement, stone, verdict, throne, horse tack, coin or law book is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — EVIDENCE GATE / HIGH COURT / KING LIMITER`;
- animal scanner: `DEFECT DETECTED — SACRIFICE PORT CLOSED`;
- allegation intake: `HEARD != TRUE`;
- execution lock: `TRUE + CERTAIN + DONE + 2/3 MOUTHS`;
- hand order: `WITNESSES FIRST / EVERYONE AFTER`;
- appeal elevator: `TOO HARD -> GO UP TO THE PLACE`;
- verdict rails: `NO RIGHT / NO LEFT`;
- king selector: `BROTHER + LORD CHOICE`;
- royal limiter: `HORSES / WIVES / SILVER / GOLD — DO NOT MULTIPLY`;
- Egypt routing: `HORSE SHOP RETURN PATH DISABLED`;
- royal homework: `HANDWRITE THE FUCKING LAW`;
- barcode: `CHB-DEU17-20-EVIDENCE-COURT-KING-NOCASE-NOCRACK-HELD`.

## FIR verification

- all 20 verse markers are represented in order;
- defective-sacrifice exclusion remains unexecuted;
- heard report, diligent inquiry, truth/certainty and witness count remain distinct gates;
- one witness is not upgraded to sufficient evidence;
- high-court verdict and presumptuous-refusal branches remain prospective;
- public king request and divine person-selection remain separate steps;
- no historical monarch is imported into the future specification;
- horse, wife, wealth and law-copy limits remain exact;
- no animal, accused person, court party, king or outcome is invented;
- no unsupported contradiction machinery appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 18 joins priest/Levite portions, prohibited
divination practices, the prophet-like-Moses promise and prophet verification.
