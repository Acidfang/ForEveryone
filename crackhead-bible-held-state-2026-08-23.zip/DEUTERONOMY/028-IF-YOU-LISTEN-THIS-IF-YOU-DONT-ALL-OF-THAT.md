# CRACKHEAD DEUTERONOMY 28

## Title page

**IF YOU LISTEN: THIS.**

**IF YOU DON'T: ALL OF THAT.**

Source parent: Deuteronomy chapter 28, verses 1–68, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-028/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/027-PLASTER-THE-STONES-NO-IRON-TWO-MOUNTAINS-EVERYONE-SAYS-AMEN.md`.

CrackFlix routing: none. Blessing and curse packages are mutually conditioned prospective speech, not completed occurrences or a contradiction.

## Causal foundation

```text
DILIGENT LISTENING + OBSERVING + DOING + NO TURNING
-> BLESSINGS OVERTAKE
-> CITY/FIELD/BODY/GROUND/ANIMALS/BASKET/ENTRY/EXIT
-> ENEMY FLIGHT/BARNS/HOLY PEOPLE/RAIN/PROSPERITY/LENDING/HEAD

NOT LISTENING + NOT OBSERVING/DOING + FORSAKING
-> CURSES OVERTAKE
-> REVERSALS + DISEASE + DROUGHT + DEFEAT + LOSS + CAPTIVITY
-> FOREIGN ASCENT / ISRAEL DESCENT

NO JOYFUL SERVICE IN ABUNDANCE
-> ENEMY SERVICE IN LACK
-> DISTANT NATION -> SIEGE -> CONSUMPTION INVERSION

NOT DOING WRITTEN LAW / NOT FEARING NAME
-> EXTENDED PLAGUE PACKAGE -> FEW -> SCATTERED -> NO REST
-> EGYPT BY SHIPS -> OFFERED AS SLAVES -> NO BUYER
```

## Deuteronomy 28:1–14 — LISTEN, DO, DON'T TURN: BLESSING PACKAGE

Diligent listening, observing and doing, without turning right or left toward
other gods, gates the entire blessing package. It covers city and field; body,
ground, livestock and flock; basket and kneading trough; entry and exit; enemy
flight one-to-seven; barns and work; holy-people establishment; public name and
fear; abundant offspring, animals and ground; seasonal rain; lending without
borrowing; and head/above rather than tail/beneath.

Every result is conditional. No obedience, blessing, crop, birth, rain, loan,
enemy encounter, elevation or holy-status outcome occurs.

## Deuteronomy 28:15–24 — DON'T LISTEN: THE REVERSAL STARTS

Failure to listen, observe and do gates curses that overtake. City, field,
basket, trough, offspring, ground, animals, entry and exit reverse. The source
then attributes cursing, confusion, rebuke, pestilence, named sicknesses,
sword, blight and mildew, bronze sky, iron earth, and powder-and-dust rain until
destruction. No failure, curse, illness, weather change or destruction occurs.

## Deuteronomy 28:25–37 — DEFEAT, UNSAVED LOSS AND DISPLACEMENT

The prospective chain continues through one-to-seven military flight,
kingdom-wide tossing, unprotected bodies, Egypt boils/tumors/scurvy/itch,
madness/blindness/heart astonishment, oppression and robbery without a saver.
Betrothal, house and vineyard outputs go to others; ox, donkey and sheep are
lost; sons and daughters go to another people; an unknown nation consumes work;
unhealed boil covers the body; Israel and its future king are taken to an
unknown nation and become astonishment, proverb and byword.

The source's “boils of Egypt” and sore-boil language is retained as its
prospective affliction class. It does not alter Crackheadverse boil genetics or
instantiate a boil. No defeat, body, disease, theft, family loss, king, exile or
proverb occurrence happens.

## Deuteronomy 28:38–48 — OUTPUT COLLAPSE AND ROLE REVERSAL

Seed, vineyards, olives, children, trees and ground fruit are prospectively
lost to locusts, worms, dropping fruit and captivity. The foreigner rises while
Israel descends, lends while Israel borrows, and becomes head while Israel is
tail. The text repeats the cause as failure to listen and keep, then contrasts
unperformed joyful service amid abundance with future enemy service in hunger,
thirst, nakedness and lack under an iron yoke. No crop failure, captivity,
loan, hierarchy change, service, hunger or yoke occurs.

## Deuteronomy 28:49–57 — DISTANT NATION, FALLEN WALLS, SIEGE INVERSION

A distant eagle-like nation with an unknown language and fierce face is
prospectively brought against Israel. It consumes livestock and ground output,
leaves no grain, wine or oil, and besieges every gate until trusted walls fall.
The siege chain culminates in parents eating children and withholding that food
from close family under extreme lack. Tender man and tender woman branches are
separately stated. No nation identity is supplied, no siege begins, and no
consumption, motive, death or family act is instantiated.

## Deuteronomy 28:58–68 — BOOK FAILURE, SCATTERING, NO REST, EGYPT BY SHIP

Failure to do all written law and fear the named LORD gates long severe plagues,
Egypt diseases and even unlisted sicknesses. The many become few; the people
are plucked from the land, scattered end-to-end, and serve unknown wood-and-
stone gods. Among nations they find no ease: trembling heart, failing eyes,
pining soul, doubtful life, night-and-day fear, and wishing each time of day
away. The last route returns them to Egypt by ships despite the earlier
never-see-again statement; there they offer themselves as male and female
slaves and nobody buys.

All remain conditional predicted outcomes. The earlier speech and this stated
future route are preserved as separate Moments; because neither future outcome
is observed here, no completed contradiction is claimed.

## Character and world-ledger changes

- blessing and curse packages have different explicit input conditions;
- mirrored outputs are alternative branches, not simultaneous facts;
- every disease, boil, loss, captivity and siege outcome remains prospective;
- unknown distant nation stays unidentified;
- tender-man and tender-woman siege branches remain separate;
- unlisted plague class remains open rather than invented;
- Egypt-return speech retains its relation to prior never-see-again speech without claiming completion;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every prospective living human, animal or plant Joe and face-like non-divine basket, trough, barn, cloud, loan ticket, yoke, wall, ship or law book is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — CONDITIONAL PACKAGE MANAGER`;
- blessing input: `LISTEN + DO + DON'T TURN`;
- curse input: `NOT LISTEN + NOT DO`;
- mirror warning: `ALTERNATE BRANCHES != SAME STATE`;
- rain driver: `SKY TREASURE / POWDER MODE`;
- hierarchy switch: `HEAD/TAIL REVERSAL`;
- siege warning: `WALL TRUST FAILED`;
- plague field: `UNLISTED DOES NOT MEAN INVENT ONE`;
- Egypt route: `SHIP RETURN / BUYER COUNT ZERO`;
- barcode: `CHB-DEU28-68-CONDITIONAL-BLESS-CURSE-SIEGE-EXILE-NOCRACK-HELD`.

## FIR verification

- all 68 verse markers are represented in order;
- blessing verses 1–14 retain the complete obedience/no-turn trigger;
- curse verses 15–68 retain disobedience/forsaking/no-joy/book-failure triggers;
- mirrored consequences are not treated as simultaneous contradiction;
- all body, animal, crop, war, captivity, siege and exile outcomes remain future;
- source boil classes do not rewrite Crackheadverse boil canon;
- no distant nation, disease, unlisted plague or motive is invented;
- siege family branches remain non-graphic and separately attributed;
- Egypt-return and never-see-again statements remain separate unresolved speech Moments;
- no unsupported Captain or SKIP appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 29 joins Moab covenant assembly, retained
Egypt/wilderness history, hidden-root warning, land-desolation speech and the
secret/revealed boundary.
