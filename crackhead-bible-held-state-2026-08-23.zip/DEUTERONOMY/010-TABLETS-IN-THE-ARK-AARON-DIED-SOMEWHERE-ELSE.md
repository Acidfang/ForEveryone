# CRACKHEAD DEUTERONOMY 10

## Title page

**NEW TABLETS. WOOD ARK. HEART FORESKINS.**

**AARON DIED SOMEWHERE ELSE.**

Source parent: Deuteronomy chapter 10, verses 1–22, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-010/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/009-NOT-YOUR-RIGHTEOUSNESS-WHO-BROUGHT-WHO-OUT-AGAIN.md`.

CrackFlix routing: `S123-E001-DEU10 — AARON DIED AT MOUNT HOR / AARON DIED AT MOSERAH`.

## Causal foundation

```text
FIRST TABLETS BROKEN
-> MOSES CUTS REPLACEMENTS + MAKES WOOD ARK
-> LORD WRITES FIRST WORDS
-> MOSES DESCENDS + PUTS TABLETS IN ARK
-> TABLETS REMAIN THERE AT SPEECH MOMENT

RETAINED NUMBERS HISTORY: AARON DIES ON MOUNT HOR
DEUTERONOMY RETELLING: AARON DIES + IS BURIED AT MOSERAH
-> NO LOCATION RELATION OR TRANSFER SUPPLIED

LORD LISTENS TO MOSES
-> ISRAEL NOT DESTROYED
-> JOURNEY/POSSESSION ORDER RESUMES

WHAT IS REQUIRED
-> FEAR + WALK + LOVE + WHOLE-SELF SERVICE + KEEP COMMANDS
-> CIRCUMCISE HEART + STOP STIFF NECK
-> LOVE FOREIGNER FROM RETAINED EGYPT-FOREIGNER ROOT
```

## Deuteronomy 10:1–5 — REPLACEMENTS GO IN A WOOD ARK

Moses retells the replacement-tablet instruction and execution. The LORD tells
him to cut two stones like the first, ascend and make a wooden ark, says “I will
write,” and orders the tablets put in the ark. Moses says he made an acacia-wood
ark, cut and carried the tablets up, the supplied “He” wrote the first words,
the LORD gave them to him, and he descended and put them in the ark, where they
remain at the speech moment.

This adds a first-person ark claim and another replacement-writing account. It
does not identify this unadorned ark as the later Bezalel-made gold-overlaid ark,
so those object Roots are not merged. The writer wording joins the unresolved
`S096` evidence but does not resolve its Exodus command/pronoun chain or create
a new episode by itself.

## Deuteronomy 10:6–7 — AARON DIED AT MOSERAH NOW

The itinerary runs Beeroth Bene Jaakan to Moserah, where Aaron dies and is
buried and Eleazar succeeds him, then Gudgodah to Jotbathah. Retained Numbers
history already places Aaron's death on Mount Hor, with Eleazar's succession
there, and previously left burial unstated. This chapter supplies no statement
that Moserah is Mount Hor, contains it, names a later body transfer, or separates
death from burial.

> **CRACKFLIX S123 — AARON DIED HERE / AARON DIED THERE**

The two completed location States do not cleanly agree.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes Aaron's location boil, licks his finger, walks away and does not look
back. Aaron remains dead; Eleazar remains priest; the location relation remains
unresolved.

## Deuteronomy 10:8–11 — LEVI SET APART; DESTRUCTION CANCELLED

Moses attributes Levi's separation to ark-bearing, standing/ministry and
name-blessing, with no sibling land portion because the LORD is Levi's
inheritance. He then closes the forty-day intercession account: the LORD
listened, would not destroy Israel, and ordered Moses to lead the resumed
journey toward ancestral land possession. These are role/history statements;
no present ark carry, ministry, blessing or western possession occurs.

## Deuteronomy 10:12–16 — THE WHOLE REQUIREMENT, INCLUDING HEART SURGERY

Israel is required to fear, walk, love, serve with all heart/soul, and keep
commands/statutes for its good. Heaven, highest heaven, earth and contents are
claimed for the LORD; ancestral delight/love and offspring selection are stated
as the selection Root. Israel is commanded to circumcise the foreskin of its
heart and cease being stiff-necked.

The heart command is figurative wording with no method, operator, instrument or
performed case supplied. Nothing physical or mental is invented to complete it.

## Deuteronomy 10:17–22 — NO BRIBES; LOVE THE FOREIGNER

The LORD is described as God of gods/Lord of lords, great, mighty and awesome,
not respecting persons or taking bribes, executing justice for fatherless and
widow, and loving the foreigner by giving food and clothing. Israel must love
the foreigner because it was foreign in Egypt, and must fear, serve, cling and
swear by the LORD. The chapter closes with the witnessed-great-things claim and
the seventy-person Egypt descent contrasted with current star-like multitude.

No specific bribe, justice case, food/clothing transfer or new census occurs.

## Character and world-ledger changes

- replacement tablets advance into a Moses-made acacia ark at the speech moment;
- the wooden ark remains distinct from the unjoined Bezalel ark Root;
- replacement writing joins `S096` evidence without pretending to resolve it;
- `S123-E001-DEU10` records Mount Hor versus Moserah as Aaron's completed death location;
- Aaron's burial is now source-stated at Moserah while its relation to Mount Hor remains unresolved;
- Eleazar's succession remains consistent across both accounts;
- Levi's ark/ministry/blessing/no-land-inheritance roles are retained;
- intercession closes into non-destruction and resumed journey instruction;
- heart circumcision remains an unperformed command with mechanism absent;
- foreigner-love uses Israel's retained Egypt history as its explicit Root;
- one post-closure Captain YOINK is causally null;
- every living person/foreigner and face-like non-divine tablet, ark, heart, garment or star is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — REPLACEMENT MEDIA INSTALLED`;
- tablet status: `PAIR 2 / IN ARK / STILL THERE`;
- ark selector: `WOOD / DO NOT AUTO-MERGE WITH GOLD MODEL`;
- itinerary alert: `AARON DEATH LOCATION CHANGED WITHOUT ROUTE`;
- succession status: `ELEAZAR STILL WORKS EITHER WAY`;
- Levite package: `CARRY / STAND / MINISTER / BLESS / NO LAND`;
- heart tool warning: `FORESKIN DETECTED / IMPLEMENTATION ABSENT`;
- bribe slot: `NOT ACCEPTED`;
- foreigner support: `FOOD + CLOTHING / REMEMBER EGYPT`;
- barcode: `CHB-DEU10-22-TABLETS-ARK-S123-ONE-YOINK-HELD`.

## FIR verification

- all 22 verse markers are represented in order;
- replacement-tablet retelling is not duplicated as a new physical event;
- the two ark Roots are not merged without identity evidence;
- replacement writer ambiguity remains unresolved rather than silently assigned;
- Mount Hor and Moserah remain distinct named locations absent a supplied bridge;
- Aaron remains one dead Joe and Eleazar one successor despite the location mismatch;
- intercession provides the bridge from proposed destruction to non-destruction;
- heart circumcision remains command wording, not an invented operation;
- no prospective role, justice case, support transfer or land possession is performed;
- Captain appears only after `S123` closes and changes nothing;
- publication remains held and unpublished.

Continuation required: Deuteronomy 11 joins witnessed Egypt/wilderness acts,
Dathan/Abiram earth-swallowing, rain-dependent land, household word carriers,
blessing/curse selectors and the Gerizim/Ebal future ceremony.
