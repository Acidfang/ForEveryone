# CRACKHEAD DEUTERONOMY 26

## Title page

**BRING THE BASKET. SAY WHERE IT CAME FROM.**

**THIRD YEAR: DECLARE THE WHOLE ROUTE.**

Source parent: Deuteronomy chapter 26, verses 1–19, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-DEU-026/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/025-FORTY-MAX-DONT-MUZZLE-THE-OX-ONE-WEIGHT-REMEMBER-AMALEK.md`.

CrackFlix routing: none. Firstfruits and tithe executions remain conditional; the closing mutual declarations occur as speech.

## Causal foundation

```text
LAND ENTRY + POSSESSION + DWELLING
-> FIRSTFRUITS -> BASKET -> CHOSEN PLACE -> PRIEST -> ALTAR
-> HISTORICAL RECITAL -> SET DOWN -> WORSHIP -> SHARED REJOICING

THIRD-YEAR TITHE FINISHED + GIVEN TO NAMED RECIPIENTS
-> COMPLIANCE DECLARATION + EXCLUSION DECLARATION + BLESSING REQUEST

TODAY
-> LORD COMMANDS / ISRAEL DECLARES LORD AS GOD
-> LORD DECLARES ISRAEL HIS POSSESSION
-> FUTURE PRAISE/NAME/HONOR/HOLINESS OUTCOME SPOKEN
```

## Deuteronomy 26:1–11 — THE BASKET CARRIES A HISTORY ADDRESS

After Israel enters, possesses and dwells in the given land, first produce goes
into a basket and travels to the LORD's chosen place. The current priest
receives it and sets it before the altar. The presenter declares arrival in the
sworn land, then recites the forefather's descent to Egypt, population growth,
Egyptian oppression, Israel's cry, the LORD's hearing and seeing, the exodus,
and arrival in the milk-and-honey land. The first produce is set down, worship
follows, and the household rejoices with Levite and foreigner.

The recital points to retained history; it does not repeat those acts. Land
entry, possession, first harvest, basket, journey, priest transfer, altar
placement, worship and rejoicing remain future.

## Deuteronomy 26:12–15 — THIRD-YEAR DISTRIBUTION GETS A DECLARATION

After all third-year tithe is finished and given to Levite, foreigner,
fatherless and widow so they may eat within the gates, the giver declares that
the holy portion left the house and reached every named class. The declaration
also excludes eating it in mourning, removing it while unclean, or giving it
for the dead, and asserts obedience. It closes with a request for the LORD to
look from heaven and bless Israel and the sworn ground.

This is a conditional declaration script after a completed distribution. No
third year, tithe, recipient meal, declaration, excluded use, heavenly look or
blessing occurs.

## Deuteronomy 26:16–19 — TWO DECLARATIONS TODAY; FUTURE EFFECTS STAY FUTURE

Moses says the LORD commands these statutes and ordinances today and requires
whole-heart, whole-soul observance. Israel has declared today that the LORD is
their God and that they will walk, keep and listen. The LORD has declared today
that Israel is his own possession and should keep his commandments. The stated
future outcome is elevation above the nations in praise, name and honor, and a
holy people as spoken.

The mutual declarations are current attributed speech acts. Future obedience,
elevation, praise, name, honor and holiness effects are not backfilled as
completed.

## Character and world-ledger changes

- firstfruits execution is gated by land entry, possession and dwelling;
- the basket procession retains priest, altar, recital, worship and inclusive rejoicing order;
- historical recital preserves prior events without duplicating them;
- third-year declaration requires completed distribution to every named class;
- mourning/unclean/dead-use exclusions stay inside that declaration;
- Israel's declaration and the LORD's declaration occur today as distinct attributed speech;
- promised status effects remain future;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every prospective living human, animal or plant Joe and face-like non-divine fruit, basket, altar, tithe, house, statute or declaration carrier is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD DEUTERONOMY — BASKET / HISTORY / DISTRIBUTION RECEIPT`;
- trigger: `ENTRY + POSSESSION + DWELLING REQUIRED`;
- basket label: `FIRST OUTPUT / SOURCE LINEAGE ATTACHED`;
- recital warning: `HISTORY POINTER — DO NOT RE-EXECUTE EGYPT`;
- recipient checklist: `LEVITE / FOREIGNER / FATHERLESS / WIDOW`;
- declaration gate: `DISTRIBUTION MUST BE FINISHED FIRST`;
- exclusions: `MOURNING / UNCLEAN / DEAD ROUTES = NO`;
- mutual ledger: `ISRAEL SAID / LORD SAID`;
- future field: `PRAISE + NAME + HONOR — NOT YET VERIFIED`;
- barcode: `CHB-DEU26-19-BASKET-TITHE-DECLARATIONS-NOCRACK-HELD`.

## FIR verification

- all 19 verse markers are represented in order;
- land-entry prerequisites precede firstfruits execution;
- priest, altar, recital, worship and rejoicing retain order;
- Egypt/history acts are not duplicated;
- third-year declaration requires completed distribution;
- excluded tithe uses remain declarative conditions, not occurrences;
- today declarations remain distinct current speech acts;
- future elevation and holiness effects remain unresolved;
- no unsupported contradiction machinery appears;
- publication remains held and unpublished.

Continuation required: Deuteronomy 27 joins stone/plaster law inscription,
Ebal altar procedure, tribal positions and the spoken curse-response list.
