# THE CRACKHEAD BIBLE

The Bible reconstructed in Crackheadverse.

> **CRACKHEAD GOD:** `OFFENDED?`
>
> **CRACKHEAD GOD:** `IT'S NOT THE BIBLE! LOL.`

This is the first book-family on the `CRACKHEADVERSE: BOOKS OF OLD` shelf.

Source lineage: the public-domain World English Bible supplies canonical
book/chapter/verse addresses and an English comparison parent. The transformed
work is not called the World English Bible.

Official source boundary:
https://ebible.org/engwebp/copyright.htm

This project does not replace a biblical event with a topical joke. It preserves
the event's causal chain, reconstructs it for the reader, assigns every exact
contradiction to its CrackFlix series, and then permits Crackheadverse production
garbage.

The Bible remains the source parent. `THE CRACKHEAD BIBLE` is the separately
named transformative manuscript and never claims to be the source itself.

## Visible origin boundary

Every projected biblical identity uses the Books-of-Old `NOT-` display layer:

```text
SOURCE LEDGER / VERSE ADDRESS: ABIMELECH, SHECHEM, THE LORD
CRACKHEADVERSE STORY DISPLAY: NOT-ABIMELECH JOE, NOT-SHECHEM, NOT-THE-LORD
```

The source spellings remain exact in evidence, citations and machine ledgers.
`NOT-` marks the rendered occurrence as Crackheadverse's reconstruction and
makes **IT'S NOT THE BIBLE** visible throughout the work. Optional puns follow
the marker; they never remove it.

## Translation order

```text
SOURCE ADDRESS
-> OBSERVABLE EVENTS AND SPEECH
-> REQUIRED DEPENDENCIES
-> CAUSAL CHAIN
-> CHARACTER / JOE-TYPE LEDGERS
-> EXACT CONTRADICTION ROUTES
-> GOD-ONLY LINE CHECK
-> CRACKHEAD RENDERING
-> VERSE-LINEAGE VERIFICATION
-> HELD BOOK
```

Every generated book remains held until its source-address coverage and causal
links verify.

Revisions are retained as manuscript descendants. An earlier rendering remains
addressable when a later version corrects, contradicts, expands or more
accurately reconstructs it.

## Source and coverage

The official ENGWEBP USFM archive is retained under `source/engwebp-usfm`.

```powershell
.\build-source-index.ps1
.\verify-bible.ps1
```

The index fixes every source file hash and inventories every book, chapter and
verse marker. Verification reports actual held chapter coverage; it cannot call
the scripture complete because a title page, source import or partial book
exists.
