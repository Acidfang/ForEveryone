# CRACKHEAD 2 SAMUEL 5

## Title field

**NOT-JEBUSITES: NOT-DAVID CAN'T COME IN. NOT-DAVID TOOK THE STRONGHOLD.**

Source parent: 2 Samuel chapter 5, verses 1–25, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-005/job.json` and `source.usfm`. Parent: 2 Samuel 4. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. War, disability references and conquest remain restrained and non-graphic.

CrackFlix: new mental `S208-E001-2SA5`; no SKIP; one causally-null post-closure YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
ISRAEL TRIBES/ELDERS COME TO DAVID
-> BONE/FLESH + PRIOR LEADERSHIP + LORD-SPEECH CLAIM
-> COVENANT / DAVID ANOINTED KING OVER ISRAEL
-> AGE + REIGN DURATIONS RETAINED
-> DAVID/MEN GO AGAINST JERUSALEM JEBUSITES
-> JEBUSITES: DAVID CANNOT COME IN
-> DAVID TAKES ZION STRONGHOLD
-> WATERCOURSE/BLIND/LAME SAYING + HOUSE PROVERB
-> DAVID LIVES/BUILDS / GROWS GREAT
-> HIRAM SENDS MATERIALS/WORKERS / HOUSE BUILT
-> DAVID PERCEIVES LORD ESTABLISHED/EXALTED KINGDOM
-> MORE WIVES/CONCUBINES / NAMED CHILDREN
-> PHILISTINES SEEK DAVID / SPREAD IN REPHAIM
-> FIRST INQUIRY: GO UP / DELIVERY
-> DAVID STRIKES / ATTRIBUTES BREAKOUT / TAKES IMAGES
-> PHILISTINES RETURN
-> SECOND INQUIRY: DO NOT GO UP / CIRCLE / WAIT FOR SOUND
-> DAVID DOES SO / STRIKES GEBA TO GEZER
```

## Verses 1–5 — ALL-ISRAEL COVENANT / ANOINTING / DURATIONS

All Israel's tribes come to David at Hebron, call themselves his bone/flesh, cite his prior leadership under Saul and attribute shepherd/prince speech to LORD. Elders covenant with David before LORD and anoint him king over Israel. David is thirty at reign start and reigns forty years: seven years six months over Judah in Hebron and thirty-three over Israel/Judah in Jerusalem. Durations are retained as source States without inventing rounding mechanics.

## Verses 6–10 — “CAN'T COME IN” / STRONGHOLD TAKEN

David and men go against Jerusalem's Jebusites. They say the blind and lame will keep him out, thinking/saying, “David can't come in here.” Nevertheless David takes Zion's stronghold, called David's city.

This closes mental `S208-E001-2SA5`:

```text
JEBUSITE MODEL: DAVID CANNOT ENTER
OBSERVED NEXT STATE: DAVID TAKES THE STRONGHOLD
```

No hidden strategy or sincerity is inferred. First occurrence: no SKIP. One YOINK changes nothing.

David's same-day watercourse/Jebusite/blind/lame statement and the resulting “can't come into the house” saying are retained as quoted language. The source does not supply exact referents, completed strikes, a house-entry case or a medical rule; none are invented. David lives in the stronghold, names/builds the city and grows greater; narrator attributes this to LORD God of Armies being with him.

## Verses 11–16 — HOUSE / PERCEPTION / FAMILY

Hiram of Tyre sends messengers, cedar, carpenters and masons; they build David a house. David perceives LORD established him king and exalted the kingdom for Israel. The establishment/exaltation is explicitly David's perception; construction and kingship are observed carriers.

David takes more concubines/wives from Jerusalem and more sons/daughters are born. Named: Shammua, Shobab, Nathan, Solomon, Ibhar, Elishua, Nepheg, Japhia, Elishama, Eliada and Eliphelet. Individual mothers, consent and future acts are absent.

## Verses 17–21 — FIRST PHILISTINE OCCURRENCE

Philistines hear David is king, seek him and spread in Rephaim. David goes to the stronghold and asks LORD whether to go up and whether they will be delivered. LORD says go up and promises delivery. David strikes at Baal Perazim, says LORD broke enemies like waters, names the place; Philistines leave images and David's men take them. Images receive no living/divine form or effect.

## Verses 22–25 — SECOND DISTINCT PHILISTINE OCCURRENCE

Philistines come and spread again. David inquires again. LORD now says not to go up directly, but circle behind, approach mulberry trees, wait for marching sound in treetops, then act because LORD has gone before him. David performs the commanded route and strikes from Geba to Gezer.

This is a new inquiry for a new occurrence. Different instructions do not conflict. The source supplies the sound and attributed going-before relation but not a visible divine body or physical sound mechanism.

## Character and world-ledger changes

- NOT-DAVID gains all-Israel covenant/anointing, Jerusalem capture/residence/building, family growth, Hiram house and two inquiry/battle paths.
- NOT-JEBUSITES gain failed exclusion model and displaced stronghold State; their blind/lame language remains exact speech.
- NOT-HIRAM and workers gain completed house-supply/build acts.
- Named Jerusalem children gain birth lineage only.
- NOT-PHILISTINES gain two distinct Rephaim deployments, two defeats and abandoned-image State.

## Bullshit pass

Issue `2SA-005 / ACCESS DENIED BY CONFIDENCE POLICY`. NOT-JEBUSITES configure **EVEN THE BLIND AND LAME CAN BLOCK HIM**. NOT-DAVID acquires the whole server anyway, renames it, builds inward and installs imported cedar support. The second battle gets a different route because each ticket is occurrence-specific. Foundation unchanged.

## FIR verification

- FILTER: all 25 markers retained; 2 Samuel 6 excluded.
- ISOLATE: covenant/reign, Jerusalem claim/capture/sayings, building/perception/family, two Philistine occurrences.
- RECONSTRUCT: Jebusite impossibility model closes against capture; two inquiry answers remain distinct occurrence instructions.
- VERIFY: one new mental episode, no SKIP, one YOINK; obscure referents/mechanisms/futures unresolved; publication held.

## Required compound-eye facets

1. Israel tribes/elders bone-flesh/prior-leadership/LORD-speech statement.
2. Covenant and all-Israel anointing.
3. Age and reign durations.
4. David/men approach Jerusalem / Jebusite exclusion speech.
5. `S208-E001`: DAVID CAN'T ENTER / DAVID TAKES STRONGHOLD.
6. No SKIP / one separate mental-crack YOINK.
7. Watercourse/blind/lame speech and proverb, referents unresolved.
8. David residence/name/build/growth with narrator attribution.
9. Hiram materials/workers / house built.
10. David LORD-establishment perception.
11. More wives/concubines and eleven named children, restrained.
12. First Philistine seek/spread / David stronghold.
13. First inquiry: go up/delivery.
14. Baal Perazim strike/attribution/name / images taken.
15. Second Philistine spread.
16. Second inquiry: do not direct-go / circle / trees / sound.
17. David follows route / strikes Geba-Gezer.
18. 2 Samuel 5 held; chapter 6 excluded.

All eighteen facets appear simultaneously.

## Production boundary

One high-resolution 18-facet compound-eye image. `NOT-` display; living things Joe-faced; war/disability/conquest restrained; no divine body or idol life. Mental `S208-E001-2SA5`, no SKIP, one causally-null YOINK. Preserve quoted difficult saying, perception versus narration, exact names and distinct battle inquiries. Publication held; originator review required.

*shrug*

OK.
