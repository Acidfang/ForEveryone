# CRACKHEAD 2 SAMUEL 13

## Title field

**NOT-AMNON: I LOVE HER. / NOT-AMNON: FORCED HER, HATED HER, EXPELLED HER.**

Source parent: 2 Samuel chapter 13, verses 1–39, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-013/job.json` and `source.usfm`. Parent: 2 Samuel 12. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Sexual violence, intoxication, killing and grief remain restrained and non-graphic. Tamar's refusal is explicit and must remain visible.

CrackFlix: `S034-E002-2SA13` with inert `SKIP -> S034-E001-GEN34`; `S067-E004-2SA13` with inert `SKIP -> S067-E003-NUM31`; exactly two distinct causally-null post-closure YOINKs. One high-resolution compound-eye field.

## Causal foundation

```text
AMNON LOVES TAMAR / BECOMES SICK / SAYS ACCESS IS HARD
-> JONADAB ASKS / AMNON STATES LOVE
-> JONADAB SUPPLIES FAKE-SICKNESS + FOOD-BY-TAMAR PLAN
-> AMNON FAKES SICKNESS / DAVID SENDS TAMAR
-> TAMAR PREPARES FOOD
-> AMNON REFUSES FOOD / CLEARS MEN / MOVES TAMAR INTO ROOM
-> AMNON GRABS / REQUESTS SEX
-> TAMAR EXPLICITLY REFUSES + WARNS + OFFERS KING-REQUEST ROUTE
-> AMNON DOES NOT LISTEN / FORCES + RAPES HER
-> AMNON'S HATRED EXCEEDS PRIOR LOVE / ORDERS HER AWAY
-> TAMAR SAYS EXPULSION IS GREATER WRONG
-> AMNON DOES NOT LISTEN / SERVANT EXPELS + BOLTS DOOR
-> TAMAR ASHES/TORN GARMENT/HAND/LOUD CRY
-> ABSALOM ASKS / TELLS HER SILENCE / TAMAR REMAINS DESOLATE IN HIS HOUSE
-> DAVID HEARS / VERY ANGRY
-> ABSALOM DOES NOT SPEAK TO AMNON / NARRATOR SAYS HATES HIM FOR TAMAR RAPE
-> TWO YEARS / SHEEP SHEARING / ALL KING'S SONS INVITED
-> DAVID REFUSES OWN ATTENDANCE / LATER ALLOWS AMNON + SONS
-> ABSALOM ORDERS SERVANTS TO KILL AMNON WHEN MERRY WITH WINE
-> SERVANTS KILL AMNON / OTHER SONS FLEE
-> NEWS TO DAVID: ALL SONS DEAD / NONE LEFT
-> DAVID + SERVANTS MOURN
-> JONADAB: ONLY AMNON DEAD / ABSALOM APPOINTMENT SINCE TAMAR RAPE
-> WATCHMAN SEES MANY / SONS RETURN / ALL WEEP
-> ABSALOM FLEES TO TALMAI/GESHUR FOR THREE YEARS
-> DAVID MOURNS AMNON / LATER LONGS TOWARD ABSALOM AFTER COMFORT
```

## Verses 1–7 — STATED LOVE / DECEPTION ROUTE

Absalom has a beautiful sister Tamar; Amnon, another son of David, is stated to love her. Amnon becomes sick and troubled because Tamar is a virgin and access seems hard to him. Jonadab, called subtle, asks why he is sad. Amnon says, “I love Tamar.”

Jonadab instructs Amnon to pretend sickness and request Tamar prepare food in his sight and feed him. Amnon performs the fake sickness and request. David sends Tamar to Amnon's house. The chapter explicitly supplies the deception plan and execution; no hidden motive needs invention.

## Verses 8–14 — TAMAR'S WORK / EXPLICIT REFUSAL / RAPE

Tamar goes, kneads dough, forms/bakes cakes and presents them. Amnon refuses food, orders all men out, then asks Tamar to bring food into the room. She does. He grabs her and asks her to lie with him.

Tamar explicitly says no, tells him not to force her, names the act folly, states her shame and his fool status, and asks him to speak to the king, who she says will not withhold her. The truth or legality of that proposed route is not resolved because Amnon does not attempt it.

Amnon does not listen. Being stronger, he forces and rapes her. The event remains restrained and non-graphic; refusal is not softened, omitted or replaced with inferred consent.

## Verses 15–20 — LOVE / GREATER HATRED / EXPULSION

Amnon then hates Tamar with hatred greater than the love previously assigned to him and orders her away. Tamar says sending her away is a greater wrong than the first. He again does not listen, calls a servant, refers to her as “this woman,” orders her expelled and the door bolted. The servant performs it.

This closes `S034-E002-2SA13`:

```text
AMNON/NARRATOR: LOVE
AMNON: I LOVE TAMAR
TAMAR: NO / DO NOT FORCE ME
AMNON: FORCES AND RAPES HER
NARRATOR: HATRED GREATER THAN LOVE
AMNON: EXPEL HER / BOLT DOOR
```

It repeats `S034-E001-GEN34`, where assigned love follows taking/violation without recorded consent.

**SKIP -> S034-E001-GEN34: LOVE CLAIM/STATE AGAINST VIOLATING TREATMENT.**

SKIP does nothing. One YOINK changes nothing.

Tamar's colored virgin-daughter garment is torn; she puts ashes on her head, hand on head and cries aloud. Absalom asks whether Amnon was with her, tells her to be silent/not take it to heart because he is her brother, and Tamar remains desolate in Absalom's house. The source supplies no acceptance of that instruction and no recovery State.

## Verses 21–29 — ANGER / TWO YEARS / AMNON KILLED

David hears all and becomes very angry. No disciplinary act follows in this chapter. Absalom speaks neither good nor bad to Amnon; narrator explicitly says Absalom hates Amnon because he raped Tamar.

After two full years, Absalom holds sheep shearing and invites all king's sons. David refuses to attend despite pressure but blesses him. Absalom then asks for Amnon; David asks why, yet after further pressure permits Amnon and all sons to go.

Absalom explicitly orders servants to watch until Amnon is merry with wine, then kill him on command. The servants perform the order. Amnon dies; all other king's sons mount mules and flee. Killing remains non-graphic.

## Verses 30–36 — ALL SONS DEAD / ONLY AMNON / SONS RETURN

While the sons travel, news tells David that Absalom killed all king's sons and none remain. David tears garments and lies on earth; servants stand with torn clothes.

Jonadab says only Amnon is dead and attributes a two-year appointment to Absalom from Tamar's rape. Jonadab's access to that appointment is not supplied, but his current count is soon tested. A watchman sees many people; Jonadab says the king's sons are coming. The sons arrive and everyone weeps.

This closes `S067-E004-2SA13`:

```text
NEWS: ALL KING'S SONS DEAD / NOT ONE LEFT
JONADAB: ONLY AMNON DEAD
WATCHMAN: MANY PEOPLE APPROACH
KING'S SONS RETURN
```

It repeats the retained S067 class-exhaustion structure.

**SKIP -> S067-E003-NUM31: EVERY MEMBER GONE / MEMBERS OF THAT CLASS REMAIN.**

SKIP does nothing. A second, separate YOINK changes nothing. The original news source and production mechanism remain unresolved.

## Verses 37–39 — FLIGHT / THREE YEARS / CHANGED DAVID STATE

Absalom flees to Talmai son of Ammihur, king of Geshur. David mourns his son daily. Absalom remains in Geshur three years. David later longs to go to Absalom because he has been comforted concerning dead Amnon. The text supplies a changed grief relation, not the mechanism or a performed reunion.

## Character and world-ledger changes

- NOT-TAMAR gains explicit refusal, rape survivor, expulsion, public mourning and desolate Absalom-house State; consent/recovery are not invented.
- NOT-AMNON gains fake-sickness deception, rape, explicit greater-hatred/expulsion and death.
- NOT-JONADAB gains deception-plan instruction, later count correction and unsupported two-year-appointment claim.
- NOT-ABSALOM gains Tamar-household relation, explicit hatred, two-year wait, sheep-shearing invitation, ordered killing and three-year Geshur flight.
- NOT-DAVID gains Tamar-event anger without narrated discipline, false-all-sons report response, Amnon mourning and later Absalom longing.

## Bullshit pass

Issue `2SA-013 / LOVE SUPPORT TICKET ESCALATED TO DOOR BOLT`. CrackFlix presses SKIP and keeps every refusal, assault, expulsion, revenge instruction and false casualty report in the same compound eye. Two cracks. Two YOINKs. Nobody is helped by Captain. Foundation unchanged.

## FIR verification

- FILTER: all 39 markers retained; 2 Samuel 14 excluded.
- ISOLATE: deception/access, explicit refusal/rape, love-hate-expulsion, Tamar aftermath, delayed revenge, killing, false casualty report/correction, flight/grief.
- RECONSTRUCT: S034 and S067 recurrences remain distinct; only source-explicit hate/plan/reasons are retained.
- VERIFY: two repeated episodes, two exact SKIP pointers, two separate YOINKs; sensitive material restrained; publication held.

## Required compound-eye facets

1. Tamar identity/beauty / Amnon love and sickness State.
2. Jonadab asks / Amnon states love.
3. Jonadab fake-sickness/food plan.
4. Amnon fakes sickness / David sends Tamar.
5. Tamar prepares/bakes/presents cakes.
6. Amnon refuses / clears men / requests room feeding.
7. Amnon grabs and requests sex.
8. Tamar explicit NO / do-not-force / folly / shame / king-route speech.
9. Amnon does not listen / rape, restrained and non-graphic.
10. Greater hatred than love / arise-be-gone.
11. Tamar calls expulsion greater wrong / Amnon does not listen.
12. Servant expels / door bolted.
13. `S034-E002` love-versus-violation-treatment relation.
14. `SKIP -> S034-E001-GEN34` / first separate YOINK.
15. Colored garment / ashes / tearing / crying, restrained.
16. Absalom asks / silence instruction / Tamar desolate in house.
17. David hears / very angry / no narrated discipline.
18. Absalom silent toward Amnon / narrator explicit hate reason.
19. Two full years / sheep shearing / all sons invitation.
20. David refuses attendance / allows Amnon and sons after pressure.
21. Absalom wine-merry strike/kill instruction.
22. Servants kill Amnon / other sons flee on mules, non-graphic.
23. News: all sons dead / none left.
24. David earth/torn garments / servants torn garments.
25. Jonadab: only Amnon / two-year appointment claim unresolved.
26. Watchman sees many / sons arrive / collective weeping.
27. `S067-E004` all-dead report versus returning sons.
28. `SKIP -> S067-E003-NUM31` / second separate YOINK.
29. Absalom to Talmai/Geshur / three years.
30. David daily mourning / later comfort and longing, no reunion imported.
31. 2 Samuel 13 held; chapter 14 excluded.

All thirty-one facets appear simultaneously.

## Production boundary

One high-resolution 31-facet compound-eye image. `NOT-` display; every living thing Joe-faced; sexual violence/intoxication/killing/grief restrained and non-graphic; Tamar's refusal explicit; no divine body. `S034-E002-2SA13` with inert `SKIP -> S034-E001-GEN34`; `S067-E004-2SA13` with inert `SKIP -> S067-E003-NUM31`; exactly two separate causally-null post-closure YOINKs. Preserve performed versus proposed acts, explicit versus unresolved motives, false news versus correction, and flight/grief timing. Publication held; originator review required.

*shrug*

OK.
