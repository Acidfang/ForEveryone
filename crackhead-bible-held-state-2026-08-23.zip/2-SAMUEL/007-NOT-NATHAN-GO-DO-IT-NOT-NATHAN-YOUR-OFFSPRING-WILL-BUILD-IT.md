# CRACKHEAD 2 SAMUEL 7

## Title field

**NOT-NATHAN: GO. DO ALL THAT IS IN YOUR HEART. / NOT-NATHAN: YOUR OFFSPRING WILL BUILD IT.**

Source parent: 2 Samuel chapter 7, verses 1–29, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-007/job.json` and `source.usfm`. Parent: 2 Samuel 6. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. No divine body is rendered.

CrackFlix: new mental `S209-E001-2SA7`; no SKIP; one causally-null post-closure YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
DAVID RESTS IN CEDAR HOUSE / ARK REMAINS IN CURTAINS
-> DAVID STATES THE DIFFERENCE TO NATHAN
-> NATHAN: GO / DO ALL IN YOUR HEART / LORD IS WITH YOU
-> SAME NIGHT LORD WORD COMES TO NATHAN
-> HOUSE QUESTION + TENT HISTORY + NO PRIOR CEDAR DEMAND
-> DAVID HISTORY / FUTURE NAME, PLACE AND REST
-> LORD WILL MAKE DAVID A HOUSE
-> AFTER DAVID'S DAYS, OFFSPRING WILL BUILD HOUSE FOR LORD'S NAME
-> KINGDOM/THRONE/FATHER-SON/DISCIPLINE/KINDNESS PROMISES
-> NATHAN DELIVERS ALL WORDS/VISION
-> DAVID SITS BEFORE LORD
-> DAVID RECITES HISTORY AND PRAISE
-> DAVID ASKS THAT THE SPOKEN HOUSE BLESSING BE CONFIRMED
```

## Verses 1–3 — THE FIRST AUTHORIZATION

David lives in his cedar house and narrator says LORD has given rest from surrounding enemies. David tells Nathan the prophet that he lives in cedar while God's ark lives within curtains.

Nathan answers: “Go, do all that is in your heart, for the LORD is with you.” The source supplies no preceding inquiry, word or vision supporting that authorization. David does not begin building in this chapter.

## Verses 4–17 — SAME NIGHT / THE DIFFERENT HOUSE SEQUENCE

That same night LORD's word comes to Nathan. Nathan is told to deliver a message asking whether David should build a dwelling house, recounting tent/tabernacle movement and the absence of any prior demand to Israel's shepherds for a cedar house.

The message recounts taking David from sheep to prince, presence and enemy removal, then promises a great name, an appointed place for Israel, no further movement/affliction, and rest. LORD says LORD will make David a house. After David's days, an offspring from his body will be raised; that offspring will build a house for LORD's name. The offspring's kingdom/throne, father-son relation, possible discipline, retained loving kindness and David's house/kingdom/throne are spoken as future States. Their fulfillment and the meaning/scope of “forever” are unresolved here.

Nathan delivers all these words and the vision to David.

This closes mental `S209-E001-2SA7`:

```text
NATHAN: GO / DO ALL IN YOUR HEART / LORD IS WITH YOU
SAME-NIGHT WORD DELIVERED BY NATHAN: DAVID'S OFFSPRING WILL BUILD THE HOUSE
```

The address is Nathan's authorization: he attached divine support before the source records a divine word, then delivered a different builder sequence. No motive, deception or private belief is invented. The later message corrects the route before David performs the build. First occurrence: no SKIP. One YOINK changes nothing.

## Verses 18–24 — DAVID'S RESPONSE / RETAINED ATTRIBUTIONS

David goes in, sits before LORD and asks who he and his house are to have reached this State. He calls the future-house speech great, says LORD knows him, and attributes the work and disclosure to LORD's word and heart. He praises LORD and says no other God is known according to what “we have heard.”

David then recounts redemption, name-making, great/awesome acts, Egypt, nations/gods and Israel's establishment as LORD's people. These are David's prayer statements and attributions; the chapter does not replay those historical acts or render divine form.

## Verses 25–29 — CONFIRM WHAT YOU SPOKE

David asks LORD to confirm and do the spoken word concerning him and his house, magnify LORD's name, establish David's house, and bless it forever. The prayer occurs. Confirmation, future building, succession, discipline and forever outcomes remain future.

## Character and world-ledger changes

- NOT-DAVID gains cedar-house/rest State, ark-curtain comparison, receipt of Nathan's corrected message and a completed seated prayer.
- NOT-NATHAN gains an unsupported proceed authorization, same-night word/vision reception and completed delivery of the different builder sequence.
- David's unnamed future offspring remains future and uninstantiated.
- Israel gains promised place/rest/no-affliction speech only; no future fulfillment is imported.

## Bullshit pass

Issue `2SA-007 / HOUSE BUILDER AUTOCORRECT`. NOT-NATHAN approves the whole ticket from the subject line. Crackhead Overnight Compliance then returns: **WRONG HOUSE. WRONG BUILDER. SAME PROPHET.** Foundation unchanged.

## FIR verification

- FILTER: all 29 markers retained; 2 Samuel 8 excluded.
- ISOLATE: cedar/curtain statement, Nathan's first authorization, same-night word, David/offspring house sequence, Nathan delivery and David prayer.
- RECONSTRUCT: only Nathan's authorization closes against the later builder sequence; no unperformed building or future promise is treated as observed completion.
- VERIFY: one new mental episode, no SKIP, one YOINK; divine form, future outcomes and promise mechanisms unresolved; publication held.

## Required compound-eye facets

1. David in cedar house / rest from enemies / ark in curtains.
2. David states cedar-versus-curtain difference to Nathan.
3. Nathan: go, do all in your heart, LORD is with you.
4. Same-night LORD word comes to Nathan, no divine body.
5. Should you build me a house? / tent-tabernacle history.
6. No prior cedar-house demand to Israel shepherds.
7. David sheep-pen-to-prince history.
8. Presence/enemy-removal history and future great-name speech.
9. Future Israel place/plant/no-move/no-affliction speech.
10. LORD will make David a house / future rest.
11. Future offspring raised after David's days.
12. Offspring will build house for LORD's name.
13. Throne/father-son/discipline/kindness/forever promises, visibly future.
14. Nathan delivers all words and vision.
15. `S209-E001`: first authorization / different builder sequence.
16. No SKIP / one separate mental-crack YOINK at Nathan's boil.
17. David sits before LORD / who am I and what is my house.
18. David historical praise and attribution, not replayed history.
19. David asks confirmation/blessing of spoken house promise.
20. 2 Samuel 7 held; chapter 8 excluded.

All twenty facets appear simultaneously.

## Production boundary

One high-resolution 20-facet compound-eye image. `NOT-` display; every living thing Joe-faced; no divine body. Mental `S209-E001-2SA7`, no SKIP, one causally-null YOINK after the mismatch is complete. Keep Nathan's two speech Moments distinct, future promises visibly future, and David's prayer attributions separate from narrator acts. Publication held; originator review required.

*shrug*

OK.
