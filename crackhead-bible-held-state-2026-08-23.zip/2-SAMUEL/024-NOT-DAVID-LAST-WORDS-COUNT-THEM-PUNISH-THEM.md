# CRACKHEAD 2 SAMUEL 24

## Title field

**NOT-DAVID'S LAST WORDS, AGAIN / COUNT ISRAEL / YOU SINNED BY COUNTING / SEVENTY THOUSAND OTHER JOES**

Source parent: ENGWEBP 2 Samuel chapter 24, verses 1-25, USFM. Prepared evidence: `.chapter-work/CHB-2SA-024/job.json` and `source.usfm`. Parent: 2 Samuel 23. Exact identities remain evidence; visible names use `NOT-`. Every living thing, including cattle and the angel if visibly embodied by source, is Joe-faced. Pestilence, death and offerings remain restrained/non-graphic.

CrackFlix: new `S219-E001-2SA24`, new `S220-E001-2SA24`, and repeated `S009-E003-2SA24` with inert `SKIP -> S009-E002-2SA21`. Exactly three separate causally-null post-closure YOINKs. One high-resolution compound-eye field.

## Causal foundation

```text
2SA23 NARRATOR: THESE ARE DAVID'S LAST WORDS
-> 2SA24 DAVID SPEAKS REPEATEDLY

LORD ANGER AGAINST ISRAEL
-> LORD MOVES DAVID AGAINST THEM: GO, COUNT ISRAEL/JUDAH
-> DAVID ORDERS COUNT
-> JOAB OBJECTS
-> ORDER PREVAILS
-> NINE MONTHS + TWENTY DAYS
-> 800,000 ISRAEL + 500,000 JUDAH
-> DAVID: I HAVE SINNED GREATLY BY WHAT I HAVE DONE
-> LORD OFFERS THREE SANCTIONS
-> DAVID SELECTS LORD'S HAND
-> PESTILENCE / 70,000 PEOPLE DIE
-> LORD STOPS ANGEL AT JERUSALEM
-> DAVID: I SINNED; WHAT DID THESE SHEEP DO? HAND AGAINST ME/HOUSE
-> GAD ORDERS ALTAR
-> ARAUNAH OFFERS MATERIALS FREE
-> DAVID BUYS FOR 50 SHEKELS / BUILDS / OFFERS
-> LORD ENTREATED / PLAGUE REMOVED
```

## Verses 1–4 — command, objection and execution

Narrator says LORD's anger again burns against Israel and **he moves David against them, saying “Go, count Israel and Judah.”** David orders Joab to count so he may know the sum. Joab asks why David delights in it, but the king's word prevails and the officers depart.

The source supplies LORD as mover and the quoted count command. It does not supply how anger, movement, David's desire and responsibility divide.

## Verses 5–9 — completed census

The officers traverse Jordan, Aroer, Gad, Jazer, Gilead, Tahtim Hodshi, Dan Jaan, Sidon, Tyre, Hivite/Canaanite cities, Judah and Beersheba. They return after nine months and twenty days. Joab reports 800,000 Israelite sword-drawers and 500,000 Judahite men. The two classes and numbers remain exact; no population total beyond their stated addition is invented.

## Verse 10 — count becomes confessed sin

After the count, David's heart strikes him. He says to LORD: **“I have sinned greatly in that which I have done,”** asks that his iniquity be put away and says he acted foolishly.

This closes new `S220-E001-2SA24`: **GO, COUNT / COUNT COMPLETES / YOU SINNED BY DOING IT / CHOOSE A PUNISHMENT.** The command does not disappear when the completed act is classified for sanction. No SKIP; one separate post-closure YOINK changes nothing.

## Verses 11–14 — three sanctions and David's selection

LORD's word comes to Gad. Through Gad, LORD offers David three things. Gad lists seven famine years, three months fleeing foes, or three pestilence days and demands an answer. David says he is distressed, chooses falling into LORD's hand because his mercies are great, and rejects falling into man's hand. The exact selection does not explicitly name “pestilence,” but the next narrated state is pestilence; no missing wording is invented.

## Verses 15–17 — seventy thousand and the actor/sanction recurrence

LORD sends pestilence; 70,000 people die from Dan to Beersheba. When the angel stretches a hand toward Jerusalem, LORD relents and directly says **“It is enough. Now withdraw your hand.”** The source visibly locates the angel at Araunah's threshing floor.

David sees the angel and says: **“I have sinned, and I have done perversely; but these sheep, what have they done?”** He asks for the hand against himself and his father's house.

This closes repeated `S009-E003-2SA24`: **DAVID'S ACT AND CONFESSION / SEVENTY THOUSAND DISTINCT PEOPLE RECEIVE THE SANCTION / DAVID ASKS WHAT THEY DID.** The opening anger against Israel is retained, but no act by the 70,000 or transfer rule is supplied. Inert `SKIP -> S009-E002-2SA21` points to the already-retained actor/sanction mismatch; it removes no deaths or speech. One separate YOINK changes nothing.

## Cross-chapter closure — “last words” followed by words

Chapter 23's narrator said **“these are the last words of David.”** In this chapter David speaks commands, confession, selection, protest and purchase terms. The later speech is now observable.

This closes new `S219-E001-2SA24`: **THESE ARE DAVID'S LAST WORDS / DAVID SAYS MORE WORDS.** No chronology or genre repair is supplied by the selected text. No SKIP; one separate YOINK changes nothing.

## Verses 18–25 — altar, purchase and plague close

Gad tells David to build an altar at Araunah's threshing floor; narrator says David goes as LORD commanded. Araunah sees, bows and asks why. David says he will buy the floor to build an altar so the plague may stop.

Araunah offers cattle, sledges and yokes freely. David refuses the free materials because he will not offer what costs him nothing. He buys floor and oxen for fifty silver shekels, builds the altar and makes burnt and peace offerings. Narrator says LORD is entreated and the plague is removed. Payment and ritual are observed; the causal/physical mechanism of plague removal is not supplied.

## God-line boundary

Direct divine speech occurs in the count command and “It is enough; withdraw your hand.” LORD's offered choices reach David through Gad's nested quotation. Gad's altar instruction is narrator-described as LORD's command. Narrator attributes anger, movement, word delivery, pestilence, relenting, entreaty and plague removal to LORD. The source visibly supplies an angel; render only that addressed messenger form, never an invented God body.

## Character and world-ledger changes

- NOT-DAVID speaks after his retained “last words,” orders and receives the census, twice confesses, selects LORD's hand, protests the people's deaths, buys the floor and offers.
- NOT-JOAB objects, then completes the nine-month/twenty-day census.
- NOT-GAD carries the three-choice message and altar instruction.
- NOT-ARAUNAH offers property/materials, then receives David's paid purchase.
- 70,000 unnamed people die without supplied individual act.

## Bullshit pass

Issue `2SA-024 / LAST WORDS — UNLIMITED TALK PLAN`. Crackhead Census invoices 1,300,000 sword drawers and bills 70,000 unrelated accounts. Crackhead Mercy offers three packages; all deduct from someone else's ledger. Araunah's **FREE ALTAR STARTER KIT** is rejected for insufficient suffering. Foundation unchanged.

## FIR verification

- FILTER: all 25 markers retained; 1 Kings 1 excluded.
- ISOLATE: movement/command, completed count, confession, choice, plague, protest, purchase and closure.
- RECONSTRUCT: S219 cross-chapter speech mismatch; S220 command/sanction mismatch; S009 actor/sanction recurrence.
- VERIFY: one exact SKIP, three YOINKs, no inferred motive or mechanism; 2 Samuel closes; publication held.

## Required compound-eye facets

1. LORD anger/moves David/direct count command.
2. David orders Joab Dan-to-Beersheba count.
3. Joab hundredfold blessing/why-delight objection.
4. King's word prevails/officers depart.
5. Jordan/Aroer/Gad/Jazer route.
6. Gilead/Tahtim Hodshi/Dan Jaan/Sidon route.
7. Tyre/Hivite/Canaanite/Judah/Beersheba route.
8. Nine months/twenty days/return.
9. 800,000 Israel + 500,000 Judah report.
10. David heart-struck/great sin/foolish confession; `S220` relation.
11. LORD word to Gad.
12. Three-choice offer through Gad.
13. Seven-year/three-month/three-day options.
14. David distress/LORD-hand selection.
15. Pestilence/70,000 deaths, restrained.
16. Angel toward Jerusalem/LORD relents/direct stop speech.
17. David sees angel/confesses/what-have-they-done; `S009-E003` relation, inert `SKIP -> S009-E002`, and its separate YOINK.
18. Gad altar instruction.
19. David obeys stated LORD command.
20. Araunah sees/bows.
21. David purchase/altar/plague-stop purpose.
22. Araunah free cattle/sledges/yokes offer.
23. Araunah gives/acceptance wish.
24. David refuses costless offering/buys for fifty shekels.
25. Altar/offerings/LORD entreated/plague removed/book close, with `S219-E001` last-words/later-words inset and `S220-E001` inset; exactly their two additional separate YOINKs; 1 Kings 1 excluded.

All twenty-five facets appear simultaneously.

## Production boundary

One high-resolution 25-facet compound-eye image. `NOT-` display; every living thing Joe-faced; pestilence/death/offerings restrained; visible angel uses source-addressed messenger form; no divine body. Exactly `S219-E001-2SA24` and `S220-E001-2SA24` with no SKIP, plus `S009-E003-2SA24` with inert `SKIP -> S009-E002-2SA21`; exactly three separate causally-null post-closure YOINKs. Publication held; originator review required.

*shrug*

OK.
