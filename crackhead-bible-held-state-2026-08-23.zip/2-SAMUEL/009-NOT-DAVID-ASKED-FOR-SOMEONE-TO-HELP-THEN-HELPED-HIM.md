# CRACKHEAD 2 SAMUEL 9

## Title field

**NOT-DAVID ASKED FOR SOMEONE TO HELP. THEN HE HELPED HIM.**

Source parent: 2 Samuel chapter 9, verses 1–13, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-009/job.json` and `source.usfm`. Parent: 2 Samuel 8. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Disability language remains source-exact, restrained and non-graphic.

CrackFlix: no valid contradiction; no SKIP; no Captain; no YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
DAVID ASKS FOR A SURVIVOR OF SAUL'S HOUSE
-> STATED PURPOSE: KINDNESS FOR JONATHAN'S SAKE
-> ZIBA CALLED / IDENTIFIED
-> ZIBA REPORTS JONATHAN'S SON + LOCATION + FOOT DISABILITY
-> DAVID SENDS / MEPHIBOSHETH BROUGHT
-> MEPHIBOSHETH BOWS / IDENTIFIES AS SERVANT
-> DAVID SAYS DO NOT FEAR
-> PROMISES KINDNESS + SAUL'S LAND + CONTINUAL KING'S-TABLE BREAD
-> MEPHIBOSHETH RESPONDS
-> DAVID GIVES SAUL-HOUSE PROPERTY TO MEPHIBOSHETH
-> COMMANDS ZIBA/HOUSE TO FARM AND BRING HARVEST
-> ZIBA ACCEPTS COMMAND
-> MEPHIBOSHETH EATS AS ONE OF KING'S SONS
-> MICA + ZIBA-HOUSE SERVICE STATE
-> MEPHIBOSHETH LIVES IN JERUSALEM / EATS CONTINUALLY AT TABLE
```

## Verses 1–5 — SEARCH / REPORT / RETRIEVAL

David asks whether anyone remains of Saul's house so he may show kindness for Jonathan's sake. Saul-house servant Ziba is called and identifies himself. David repeats the search as “kindness of God.” Ziba reports Jonathan has a son with a foot disability and locates him at Machir son of Ammiel's house in Lo Debar. David sends and has him brought.

Ziba reports identity, condition and location. The source does not state how he knows, why Mephibosheth is there, Machir's relation beyond household location or Mephibosheth's prior resources.

## Verses 6–8 — MEETING / PROMISE

Mephibosheth, son of Jonathan and grandson of Saul, comes, falls on his face and shows respect. David names him; he answers as servant. David says not to fear, promises kindness for Jonathan's sake, restoration of all Saul's land and continual bread at David's table.

Mephibosheth bows and calls himself a dead dog while asking why David looks upon him. That is his exact self-description; it is not converted into literal species, worth, motive or private belief.

## Verses 9–13 — PROPERTY / LABOR / TABLE / RESIDENCE

David tells Ziba that he has given everything belonging to Saul and Saul's house to Mephibosheth. Ziba, his fifteen sons and twenty servants are commanded to till the land and bring harvest so Mephibosheth has bread, while Mephibosheth continually eats at David's table.

Ziba says he will do all commanded. Mephibosheth eats at the king's table like one of the king's sons. Mephibosheth has a young son named Mica; everyone in Ziba's house serves Mephibosheth. Mephibosheth lives in Jerusalem and continually eats at the king's table. Narrator again states his disability affects both feet.

David's stated kindness purpose is followed by retrieval, property assignment, agricultural support and table access. No observable contradiction closes. Future compliance beyond the narrated current State is not projected.

## Character and world-ledger changes

- NOT-DAVID gains completed survivor search, retrieval, reassurance, land transfer, service assignment and continuing table provision.
- NOT-MEPHIBOSHETH gains Jerusalem residence, restored Saul-house property, Ziba-house service, continual royal-table access and son Mica.
- NOT-ZIBA gains report, fifteen sons, twenty servants, agricultural command and stated acceptance.
- NOT-MACHIR gains prior household-location relation only; no motive or custody relation is inferred.

## Bullshit pass

Issue `2SA-009 / KINDNESS TICKET ACCIDENTALLY FULFILLED`. NOT-DAVID opens a Saul-house survivor lookup, finds the correct Joe, restores the attached land package and enables **CONTINUAL BREAD**. CrackFlix reports: **NO BULLSHIT FOUND.** It does not invent any. Foundation unchanged.

## FIR verification

- FILTER: all 13 markers retained; 2 Samuel 10 excluded.
- ISOLATE: search purpose, Ziba report, retrieval, promise, property/labor/table commands and resulting residence/service State.
- RECONSTRUCT: David's speech and acts agree; Ziba's future-oriented acceptance is not expanded beyond narrated service State.
- VERIFY: zero contradiction episodes; no CrackFlix/SKIP/Captain/YOINK; knowledge, motives and future conduct unresolved; publication held.

## Required compound-eye facets

1. David asks for Saul-house survivor / kindness for Jonathan.
2. Ziba called and identified.
3. Repeated kindness-of-God question / Jonathan-son report.
4. Foot-disability and Machir-house/Lo-Debar location report.
5. David sends / Mephibosheth brought.
6. Mephibosheth bows and identifies as servant.
7. Do not fear / kindness / land restoration / continual table promise.
8. Mephibosheth's dead-dog self-description, nonliteral and restrained.
9. Saul-house property given to Mephibosheth.
10. Ziba, fifteen sons and twenty servants assigned farming/harvest.
11. Ziba accepts / Mephibosheth eats like king's son.
12. Mica named / Ziba household serves Mephibosheth.
13. Jerusalem residence / continual table / both-feet disability State.
14. Explicit NO CONTRADICTION / NO SKIP / NO CAPTAIN / NO YOINK boundary.
15. 2 Samuel 9 held; chapter 10 excluded.

All fifteen facets appear simultaneously.

## Production boundary

One high-resolution 15-facet compound-eye image. `NOT-` display; every living thing Joe-faced; disability language restrained and non-graphic; no literal dog transformation. No CrackFlix, SKIP, Captain or YOINK. Preserve search purpose, exact family/service counts, property/labor/table relations and present-versus-future boundary. Publication held; originator review required.

*shrug*

OK.
