# CRACKHEAD 2 SAMUEL 10

## Title field

**NOT-DAVID SENT COMFORTERS. NOT-PRINCES: THEY ARE SPIES.**

Source parent: 2 Samuel chapter 10, verses 1–19, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-010/job.json` and `source.usfm`. Parent: 2 Samuel 9. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Humiliation, warfare and deaths remain restrained and non-graphic.

CrackFlix: `S050-E002-2SA10`, with inert `SKIP -> S050-E001-GEN42`; one causally-null post-closure YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
AMMON KING DIES / HANUN REIGNS
-> DAVID STATES KINDNESS-FOR-KINDNESS PURPOSE
-> DAVID SENDS SERVANTS TO COMFORT HANUN
-> PRINCES ASSERT SEARCH/SPY/OVERTHROW PURPOSE
-> HANUN SHAVES HALF-BEARDS / CUTS GARMENTS / SENDS SERVANTS AWAY
-> DAVID HEARS / SENDS MEETING ORDER / JERICHO WAIT
-> AMMON SEES ODIOUS STATE
-> HIRES THREE SYRIAN GROUPS + MAACAH + TOB FORCES
-> DAVID HEARS / SENDS JOAB + MIGHTY ARMY
-> AMMON AT GATE / ALLIES IN FIELD
-> JOAB SEES FRONT/BACK ARRAY / SPLITS FORCE WITH ABISHAI
-> MUTUAL-HELP PLAN + COURAGE SPEECH
-> SYRIANS FLEE JOAB
-> AMMON SEES FLIGHT / FLEES ABISHAI / ENTERS CITY
-> JOAB RETURNS JERUSALEM
-> SYRIANS REGROUP / HADADEZER BRINGS BEYOND-RIVER FORCE
-> DAVID GATHERS ISRAEL / CROSSES JORDAN / FIGHTS AT HELAM
-> SYRIANS FLEE / COUNTED DEATHS + SHOBACH DIES
-> HADADEZER-SERVANT KINGS SEE DEFEAT / MAKE PEACE / SERVE ISRAEL
-> SYRIANS FEAR FURTHER AMMON AID
```

## Verses 1–5 — COMFORTERS BECOME SPIES IN THE REPORT

Ammon's king dies and Hanun his son reigns. David states that he will show Hanun kindness because Hanun's father Nahash showed David kindness. David sends servants to comfort Hanun about his father; they arrive in Ammon.

Ammonite princes ask Hanun whether David really honors his father and assert that the servants were sent to search the city, spy it out and overthrow it. No searching, spying, military preparation or overthrow act by the servants is narrated.

This is `S050-E002-2SA10`:

```text
OBSERVED/STATED PURPOSE: KINDNESS + COMFORT CONCERNING DEAD FATHER
PRINCES' ASSERTED PURPOSE: SEARCH + SPY + OVERTHROW CITY
NO OBSERVED SPY ACT
```

This repeats `S050-E001-GEN42`, where a supplied ordinary purpose was replaced by a spy-purpose assertion without an observed spy act.

**SKIP -> S050-E001-GEN42: STATED PURPOSE REPLACED BY UNSUPPORTED SPY PURPOSE.**

SKIP explains nothing, deletes nothing and changes no outcome. The princes' private belief, sincerity and information source remain unknown. Hanun acts on the spoken claim: he shaves half of each servant's beard, cuts garments to the buttocks and sends them away. The servants' bodies remain non-graphic. After being told, David sends to meet them and instructs them to wait at Jericho until their beards grow because they are greatly ashamed. One post-closure YOINK changes nothing.

## Verses 6–14 — HIRED FORCES / TWO-SIDED ARRAY / FIRST FLIGHT

Ammon sees it has become odious to David and hires 20,000 footmen from Beth Rehob/Zobah, 1,000 with Maacah's king and 12,000 from Tob. Seeing-odious is the source's stated Ammon State; the exact observation carrier and hiring terms are absent.

David hears and sends Joab with the mighty army. Ammon arrays at the gate while its hired groups remain separately in the field. Joab sees battle before and behind, selects choice Israel men against Syrians and commits the remainder to Abishai against Ammon. He specifies reciprocal help if either opposing force is too strong, calls for courage/strength for people and God's cities, and says LORD may do what seems good.

Joab's force approaches; Syrians flee. Ammon sees the Syrian flight, flees Abishai and enters the city. Joab returns to Jerusalem. The first occurrence records deployment and flight, not a captured city or casualty count.

## Verses 15–19 — REGROUPING / HELAM / PEACE AND SERVICE

Syrians see they were defeated and regroup. Hadadezer brings Syrians from beyond the River to Helam under Shobach. David is told, gathers all Israel, crosses Jordan and comes to Helam. Syrians array and fight.

Syrians flee. David kills 700 charioteers and 40,000 horsemen and strikes Shobach, who dies there. The rendering is non-graphic. Kings serving Hadadezer see defeat, make peace with Israel and serve Israel. Syrians are then afraid to help Ammon again. Fear is explicitly narrated only at this final State; its internal mechanism is not invented.

## Character and world-ledger changes

- NOT-HANUN gains succession, receipt of comforters, humiliation act and later city-flight State.
- NOT-AMMONITE-PRINCES gain unsupported spy/overthrow assertion; no private belief is assigned.
- NOT-DAVID gains comfort mission, Jericho recovery instruction, later army gathering/Jordan crossing/Helam battle.
- NOT-JOAB and NOT-ABISHAI gain two-front allocation, mutual-help plan and first-flight outcome.
- NOT-HADADEZER and NOT-SHOBACH gain second Syrian deployment; Shobach dies.
- Hadadezer's servant kings gain observed defeat, peace and Israel-service States.

## Bullshit pass

Issue `2SA-010 / CONDOLENCE PENETRATION TEST`. NOT-DAVID sends **SORRY YOUR DAD DIED**. NOT-PRINCES run Crackhead Threat Intelligence and return **CITY OVERTHROW PAYLOAD DETECTED**. They manufacture the war from the alert, then purchase the enterprise defeat package twice. Foundation unchanged.

## FIR verification

- FILTER: all 19 markers retained; 2 Samuel 11 excluded.
- ISOLATE: succession/comfort mission, princes' assertion, humiliation/recovery, hired-force deployment, two-front first battle, regrouped Helam battle and peace/service closure.
- RECONSTRUCT: S050 recurrence is located at unsupported spy purpose; later military acts do not retroactively prove the servants spied.
- VERIFY: one repeated mental episode, one exact SKIP pointer, one causally-null YOINK; battle details and motives remain bounded; publication held.

## Required compound-eye facets

1. Ammon king dies / Hanun succeeds.
2. David states kindness-for-kindness purpose.
3. Servants sent and arrive to comfort Hanun.
4. Princes assert search/spy/overthrow purpose.
5. `S050-E002`: stated comfort purpose / unsupported spy-purpose model.
6. `SKIP -> S050-E001-GEN42`, inert and noncausal.
7. Hanun's half-beard/garment-cut/send-away act, restrained.
8. David hears / servants met / Jericho beard-growth wait / one separate YOINK.
9. Ammon odious State / hired groups with exact 20,000 + 1,000 + 12,000 counts.
10. David hears / Joab and mighty army sent.
11. Gate-versus-field two-sided battle array.
12. Joab choice-force/Abishai remainder split.
13. Reciprocal-help/courage/LORD-do-good speech.
14. Syrians flee Joab / Ammon sees and flees Abishai into city.
15. Joab returns Jerusalem; first battle has no imported casualty/capture State.
16. Syrians regroup / Hadadezer brings beyond-River force / Shobach leads.
17. David gathers Israel / crosses Jordan / Helam array and fight.
18. Syrian flight / 700 charioteers + 40,000 horsemen / Shobach death, non-graphic.
19. Servant kings see defeat / peace / service / Syrians fear further aid.
20. 2 Samuel 10 held; chapter 11 excluded.

All twenty facets appear simultaneously.

## Production boundary

One high-resolution 20-facet compound-eye image. `NOT-` display; every living thing Joe-faced; humiliation/war/deaths restrained and non-graphic; no divine body. `S050-E002-2SA10`, inert `SKIP -> S050-E001-GEN42`, exactly one causally-null post-closure YOINK. Preserve stated purpose versus asserted purpose, exact force/casualty counts, two distinct battles and final peace/service/fear State. Publication held; originator review required.

*shrug*

OK.
