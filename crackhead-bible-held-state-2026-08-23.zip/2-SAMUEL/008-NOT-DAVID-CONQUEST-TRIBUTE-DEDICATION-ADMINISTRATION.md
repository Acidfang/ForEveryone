# CRACKHEAD 2 SAMUEL 8

## Title field

**NOT-DAVID: CONQUEST. TRIBUTE. DEDICATION. ADMINISTRATION.**

Source parent: 2 Samuel chapter 8, verses 1–18, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-008/job.json` and `source.usfm`. Parent: 2 Samuel 7. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Warfare, deaths, animal injury and subjugation remain restrained and non-graphic.

CrackFlix: no valid contradiction; no SKIP; no Captain; no YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
DAVID STRIKES/SUBDUES PHILISTINES
-> DEFEATS/MEASURES MOAB / DEATH-LIFE GROUPS / SERVICE + TRIBUTE
-> STRIKES HADADEZER DURING DOMINION-RECOVERY ACT
-> TAKES FORCES / DISABLES MOST CHARIOT HORSES / RESERVES 100-CHARIOT SET
-> DAMASCUS SYRIANS HELP HADADEZER
-> DAVID STRIKES THEM / INSTALLS GARRISONS / SERVICE + TRIBUTE
-> GOLD SHIELDS + BRONZE TAKEN
-> TOI HEARS HADADEZER ARMY WAS STRUCK
-> JORAM SENT WITH GREETING/BLESSING/GIFTS
-> DAVID DEDICATES GIFTS + SUBDUED-NATION SILVER/GOLD TO LORD
-> VALLEY OF SALT STRIKE / REPUTATION
-> EDOM GARRISONS / SERVICE
-> DAVID REIGNS / EXECUTES JUSTICE AND RIGHTEOUSNESS FOR HIS PEOPLE
-> NAMED ADMINISTRATIVE ROLES
```

## Verses 1–2 — PHILISTINES AND MOAB

After the prior chapter, David strikes and subdues the Philistines and takes the “bridle of the mother city” from their hand. The exact object/place relation behind that phrase is unresolved.

David defeats Moab, has people lie on the ground, measures two lines for death and one full line to remain alive. Moabites become David's servants and bring tribute. The source supplies the selection geometry and outcome, not identities, offense, judgment procedure or motive. The rendering remains non-graphic.

## Verses 3–8 — HADADEZER / DAMASCUS / MATERIALS

David strikes Hadadezer son of Rehob, king of Zobah, while Hadadezer goes to recover dominion at the River. David takes 1,700 horsemen and 20,000 footmen, disables chariot horses and retains enough for 100 chariots.

Syrians of Damascus come to help Hadadezer; David strikes 22,000, installs garrisons, and the Syrians become servants bringing tribute. Narrator twice states that LORD gave David victory wherever he went. No divine form or victory mechanism is supplied.

David carries Hadadezer's servants' gold shields to Jerusalem and takes much bronze from Betah and Berothai.

## Verses 9–12 — TOI'S MESSAGE / DEDICATED MATERIALS

Toi king of Hamath hears David struck Hadadezer's army. Toi sends his son Joram to greet and bless David because David fought and struck Hadadezer, with whom Toi had wars. Joram brings silver, gold and bronze vessels.

David dedicates these to LORD along with silver and gold dedicated from Syria, Moab, Ammon's children, Philistines, Amalek and Hadadezer's plunder. Dedication is David's observed act; no divine receipt, ownership transfer mechanism or object effect is shown.

## Verses 13–14 — REPUTATION / EDOM

David earns a reputation after returning from striking 18,000 Syrians in the Valley of Salt. He installs garrisons throughout Edom; Edomites become servants. Narrator repeats that LORD gave David victory wherever he went.

The source separately names Syrians in the Valley of Salt and Edom in the following verse. Their relation, campaign chronology and the exact reputation content/audience are not supplied.

## Verses 15–18 — GOVERNMENT STATE

David reigns over all Israel and executes justice and righteousness for all his people. Joab is over the army; Jehoshaphat is recorder; Zadok and Ahimelech are priests; Seraiah is scribe; Benaiah is over Cherethites and Pelethites; David's sons are chief ministers.

“Justice and righteousness for all his people” is narrator language with an explicit recipient scope. This chapter supplies no individual domestic case to inspect, and it does not say conquered populations are included in “his people.” No contradiction is manufactured by importing a moral rule or merging scopes.

## Character and world-ledger changes

- NOT-DAVID gains Philistine/Moab/Hadadezer/Damascus/Valley-of-Salt/Edom campaign States, tribute, plunder dedication, reputation and all-Israel administrative State.
- NOT-MOABITES, NOT-SYRIANS and NOT-EDOMITES gain defeated/service/tribute or garrison States exactly as narrated.
- NOT-TOI and NOT-JORAM gain heard-report, diplomatic dispatch, greeting/blessing and gift delivery.
- NOT-JOAB, NOT-JEHOSHAPHAT, NOT-ZADOK, NOT-AHIMELECH, NOT-SERAIAH, NOT-BENAIAH and David's sons gain named offices only.

## Bullshit pass

Issue `2SA-008 / HOSTILE ASSET CONSOLIDATION`. NOT-DAVID processes several nations through **CRACKHEAD TERRITORY IMPORT**, deposits the shiny attachments into the LORD folder, then opens the org chart. No contradiction ticket generated. Foundation unchanged.

## FIR verification

- FILTER: all 18 markers retained; 2 Samuel 9 excluded.
- ISOLATE: each named campaign, aid response, garrison/service/tribute relation, material movement, diplomatic gift, dedication, reputation and office assignment.
- RECONSTRUCT: campaign scopes remain distinct; narrator divine attribution remains separate from observed human acts; justice scope is not expanded.
- VERIFY: zero contradiction episodes; no CrackFlix/SKIP/Captain/YOINK; ambiguous phrases/mechanisms remain unresolved; publication held.

## Required compound-eye facets

1. Philistine strike/subdual and mother-city bridle phrase, object relation unresolved.
2. Moab defeat / line measurement / two death lines and one life line, non-graphic.
3. Moab service and tribute.
4. Hadadezer dominion-recovery movement / David strike.
5. 1,700 horsemen / 20,000 footmen taken.
6. Chariot-horse disabling / enough retained for 100 chariots, restrained.
7. Damascus Syrians arrive to help / 22,000 struck, non-graphic.
8. Damascus garrisons / service / tribute / narrator victory attribution.
9. Gold shields to Jerusalem / bronze from Betah and Berothai.
10. Toi hears / Joram sent to greet and bless.
11. Silver/gold/bronze vessels delivered.
12. David dedicates gifts and named-nation silver/gold to LORD, no divine body.
13. Valley of Salt 18,000 strike / reputation, non-graphic.
14. Edom garrisons / service / repeated narrator victory attribution.
15. David all-Israel reign / justice and righteousness for his people.
16. Named army, recorder, priest, scribe, guard and minister offices.
17. Explicit NO CONTRADICTION / NO SKIP / NO CAPTAIN / NO YOINK boundary.
18. 2 Samuel 8 held; chapter 9 excluded.

All eighteen facets appear simultaneously.

## Production boundary

One high-resolution 18-facet compound-eye image. `NOT-` display; every living thing Joe-faced; warfare/deaths/animal injury/subjugation restrained and non-graphic; no divine body. No CrackFlix, SKIP, Captain or YOINK. Preserve all exact counts, campaign scopes, narrator attributions, dedication/material flows and office assignments. Publication held; originator review required.

*shrug*

OK.
