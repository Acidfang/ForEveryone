# CRACKHEAD 2 SAMUEL 2

## Title field

**NOT-ABNER: LET THEM FIGHT. WHY WON'T YOU STOP THE FIGHTING?**

Source parent: 2 Samuel chapter 2, verses 1–32, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-002/job.json` and `source.usfm`. Parent: 2 Samuel 1. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Battle and death remain restrained and non-graphic.

CrackFlix: new `S205-E001-2SA2`. No SKIP. Exactly one causally-null post-closure YOINK. Production: one high-resolution compound-eye field.

## Causal foundation

```text
DAVID INQUIRES -> LORD SAYS HEBRON
-> DAVID / WIVES / MEN / HOUSEHOLDS MOVE AND LIVE THERE
-> JUDAH ANOINTS DAVID KING
-> DAVID PRAISES JABESH BURIAL ACT / STATES OWN KINGSHIP
-> ABNER MAKES ISHBOSHETH KING OVER LISTED ISRAEL
-> JUDAH FOLLOWS DAVID
-> ABNER'S SERVANTS + JOAB'S SERVANTS MEET AT GIBEON POOL
-> ABNER PROPOSES YOUNG MEN COMPETE
-> JOAB ACCEPTS
-> 12 + 12 MUTUALLY STRIKE / FALL
-> SEVERE BATTLE / ABNER'S SIDE BEATEN
-> ASAHEL PURSUES ABNER
-> ABNER TWICE WARNS / ASAHEL REFUSES
-> ABNER STRIKES ASAHEL / ASAHEL DIES
-> JOAB + ABISHAI PURSUE
-> BENJAMIN REGROUPS WITH ABNER
-> ABNER ASKS WHY SWORD DEVOURS / WHY JOAB HAS NOT STOPPED BROTHERS
-> JOAB SAYS ABNER'S SPEECH CAUSED STOP BEFORE MORNING
-> TRUMPET / PURSUIT AND FIGHTING STOP
-> SIDES RETURN / COUNTS / ASAHEL BURIAL
```

## Verses 1–7 — HEBRON / DAVID ANOINTED / JABESH MESSAGE

David asks LORD whether to enter a Judah city; LORD says go up, then names Hebron. David goes with Ahinoam, Abigail, his men and their households; they live in Hebron's cities. Judah's men anoint David king over Judah.

Told Jabesh-Gilead buried Saul, David sends blessing, kindness/truth wishes, promises his own reward, tells them be strong/valiant, states Saul is dead and Judah has anointed him king. Future divine kindness and David's reward remain speech until observed.

## Verses 8–11 — TWO KINGSHIP STATES

Abner takes Saul's son Ishbosheth to Mahanaim and makes him king over Gilead, Ashurites, Jezreel, Ephraim, Benjamin and all Israel. Ishbosheth is forty and reigns two years. Judah follows David; David's Hebron reign over Judah is seven years and six months. The source does not supply the complete overlap chronology here; the durations are retained without forced synchronization.

## Verses 12–17 — PROPOSED COMPETITION BECOMES SEVERE BATTLE

Abner and Ishbosheth's servants travel from Mahanaim to Gibeon. Joab and David's servants meet them at the pool; the groups sit opposite.

Abner proposes that young men arise and compete. Joab agrees. Twelve from Benjamin/Ishbosheth and twelve from David's servants arise; each catches an opponent and strikes him, and they fall together. The place is named Helkath Hazzurim/field of daggers. Battle becomes very severe; Abner and Israel's men are beaten before David's servants.

## Verses 18–25 — ASAHEL PURSUIT / WARNINGS / DEATH / REGROUPING

Joab, Abishai and Asahel are present. Asahel, described as fast as a wild gazelle, pursues Abner without turning. Abner identifies him and twice tells him to turn away, first offering another young man's armor and then warning that he may strike him and be unable to face Joab.

Asahel refuses. Abner strikes him with the spear's back end; Asahel falls and dies. Passers stop at that place. Joab and Abishai pursue until sunset. Benjamin gathers behind Abner as one band on a hill. All violence remains non-graphic.

## Verses 26–28 — INITIATE CONTEST / DEMAND SOMEONE ELSE STOP IT

Abner calls to Joab: “Shall the sword devour forever?”, says the end will be bitter, and asks how long before Joab tells the people to stop following their brothers.

This closes new `S205-E001-2SA2`:

```text
ABNER: LET THE YOUNG MEN RISE AND COMPETE
-> MUTUAL DEATHS / SEVERE BATTLE / PURSUIT
ABNER: HOW LONG BEFORE YOU TELL THEM TO STOP?
```

Abner does speak to stop the pursuit and Joab responds. That changed State does not remove Abner's observed initiation. Joab says without Abner's speech the people would have continued until morning. Joab blows the trumpet; everyone stops pursuing and fighting. First series occurrence: no SKIP. One separate post-closure YOINK changes nothing.

## Verses 29–32 — RETURNS / COUNTS / BURIAL

Abner and men travel all night through Arabah, cross Jordan and return to Mahanaim. Joab gathers his people: nineteen of David's men plus Asahel are missing; David's servants struck Benjamin/Abner's men and 360 died. They carry Asahel to his father's Bethlehem tomb, bury him, travel all night, and reach Hebron at daybreak.

The counts are retained exactly. “Missing” and “died” are not silently converted into identical categories beyond the named Asahel death.

## Character and world-ledger changes

- NOT-DAVID gains Hebron residence and Judah-kingship State, plus the completed Jabesh message.
- NOT-ISHBOSHETH gains Abner-carried Israel-kingship State with exact listed territory and source durations.
- NOT-ABNER gains king-maker, contest initiator, twice-warning defender, Asahel killer, pursued commander and battle-stop requester acts.
- NOT-JOAB gains contest acceptance, pursuit and completed trumpet-stop acts.
- NOT-ASAHEL gains continuous pursuit, two refused warnings and dead/buried State.
- NOT-ABISHAI and the two force groups gain pursuit, regrouping, return and exact casualty-count States.
- Rival kingship chronology and later house relations remain unresolved.

## Bullshit pass

Issue `2SA-002 / OPTIONAL TEAM-BUILDING BECOMES CIVIL WAR`. NOT-ABNER schedules a 12-v-12 live demonstration, watches the demonstration become production, then opens a severity ticket against NOT-JOAB for not ending the service he started. NOT-JOAB processes the ticket with one trumpet. Foundation unchanged.

## FIR verification

- FILTER: all 32 markers retained; 2 Samuel 3 excluded.
- ISOLATE: Hebron route, dual kingships, Gibeon meeting, contest, battle, Asahel pursuit/death, stop speech, returns/counts/burial.
- RECONSTRUCT: Abner's proposed contest is the retained initiating act; later stop request is a real changed State, not erasure.
- VERIFY: one new episode, no SKIP, one YOINK; reign chronology and mechanisms unresolved; publication held.

## Required compound-eye facets

1. David inquiry / LORD go-to-Hebron answer.
2. David, wives, men and households move/live in Hebron.
3. Judah anoints David / Jabesh burial report.
4. David's Jabesh blessing/reward/strength message.
5. Abner transports and makes Ishbosheth king over listed Israel.
6. David/Judah and Ishbosheth/Israel reign-duration States; chronology unresolved.
7. Two forces meet/sit opposite at Gibeon pool.
8. Abner proposes competition / Joab accepts.
9. Twelve plus twelve mutually strike/fall; restrained.
10. Severe battle / Abner's side beaten.
11. Asahel pursues / Abner identifies and first warns.
12. Second warning / Asahel refuses.
13. Abner strikes / Asahel dies / passers stop, restrained.
14. Joab/Abishai pursue / Benjamin regroups.
15. `S205-E001`: LET THEM COMPETE / WHY HAVE YOU NOT STOPPED THEM.
16. No SKIP / one separate causally-null YOINK.
17. Joab counterfactual reply / trumpet / pursuit and fighting stop.
18. Abner's all-night Mahanaim return.
19. Joab count: 19 plus Asahel missing; opposing deaths 360.
20. Asahel burial / all-night Hebron return / 2 Samuel 3 excluded.

All twenty facets appear simultaneously in one zoomable compound-eye image.

## Production boundary

One high-resolution 20-facet compound-eye image. `NOT-` display; living things Joe-faced; battle/death non-graphic; no divine form. `S205-E001-2SA2`, no SKIP, one causally-null YOINK. Preserve initiation, warnings, refusals, changed stop State, exact counts and unresolved chronology. Originator review required; publication held.

*shrug*

OK.
