# CRACKHEAD 2 SAMUEL 23

## Title field

**NOT-DAVID'S LAST WORDS / NOT-DAVID'S THIRTY-SEVEN MIGHTY JOES**

Source parent: ENGWEBP 2 Samuel chapter 23, verses 1-39, USFM. Prepared evidence: `.chapter-work/CHB-2SA-023/job.json` and `source.usfm`. Parent: 2 Samuel 22. Exact identities remain evidence; visible names use `NOT-`. Every living thing—including the lion—is Joe-faced. Battle and death remain restrained/non-graphic.

CrackFlix: no completed contradiction, no episode, no SKIP, no Captain and no YOINK. One high-resolution compound-eye field with all 39 verse Moments co-present.

## Causal foundation

```text
NARRATOR: THESE ARE DAVID'S LAST WORDS
-> DAVID ATTRIBUTES HIS TONGUE-WORDS TO LORD'S SPIRIT / GOD OF ISRAEL
-> RIGHTEOUS-RULER / MORNING-LIGHT SPEECH
-> HOUSE / EVERLASTING-COVENANT SPEECH
-> UNGODLY-THORN / IRON / FIRE SPEECH
-> NARRATOR OPENS MIGHTY-MEN LEDGER
-> THREE PRIMARY WARRIOR ACTS
-> THREE MEN FETCH BETHLEHEM WATER AFTER DAVID'S LONGING
-> DAVID REFUSES TO DRINK / POURS IT TO LORD
-> ABISHAI AND BENAIAH DEEDS / RANK DISTINCTIONS
-> THIRTY LEDGER
-> URIAH THE HITTITE
-> THIRTY-SEVEN IN ALL
```

## Verses 1–7 — last-words carrier

Narrator calls these David's last words and introduces David's self-description. David says LORD's Spirit spoke by him and God's word was on his tongue; he then quotes what he says God/Rock told him about a righteous, God-fearing ruler resembling clear morning light after rain.

David asks whether his house is so with God, then speaks of an everlasting, ordered, sure covenant, salvation, desire and growth. He compares ungodly people with untouchable thorns handled by iron/spear and burned in place.

The divine statements are nested inside David's attributed last words. No independent direct-God occurrence or divine body is supplied. “Last words” is retained exactly; whether later source supplies later David speech is not decided inside this chapter.

## Verses 8–12 — the first three warrior accounts

Josheb Basshebeth/Adino is named chief and credited with killing eight hundred at one time. Eleazar remains when Israel withdraws, strikes until his hand freezes to his sword, and the people return only for plunder; narrator attributes great victory to LORD. Shammah stands in a lentil field after the people flee, defends it and kills Philistines; narrator again attributes great victory to LORD.

Counts and names remain source-exact. Violence is visible only as restrained aftermath/action symbols. Divine victory mechanism is unresolved.

## Verses 13–17 — water through an army

Three of the thirty chiefs reach David at Adullam while Philistines occupy the valley and Bethlehem. David says longingly that he wants water from the Bethlehem gate well. The three break through the army, draw it and bring it.

David refuses to drink, pours it to LORD and calls it the blood of men who risked their lives. His longing is not rewritten as an order; their motive is not invented. The water is actual water and his “blood” wording remains his valuation/metaphor. No contradiction is manufactured from request versus refusal because the source supplies risk recognition and offering as the changed state.

## Verses 18–23 — Abishai and Benaiah ranks

Abishai kills three hundred, gains a name among the three and becomes their captain, but narrator says he was not included as one of the three. Commander and membership remain distinct relations; no contradiction is forced.

Benaiah kills Ariel's two sons, a Joe-faced lion in a snowy pit, and a huge spear-holding Egyptian using the Egyptian's spear. He has a name among the three, is more honorable than the thirty, does not attain to the three, and David puts him over the guard. Rank phrases are preserved without flattening their different comparisons.

## Verses 24–39 — named thirty / thirty-seven total

Every listed name and origin is retained in its source verse facet: Asahel and Elhanan; Shammah and Elika; Helez and Ira; Abiezer and Mebunnai; Zalmon and Maharai; Heleb and Ittai; Benaiah and Hiddai; Abialbon and Azmaveth; Eliahba, Jashen's sons and Jonathan; Shammah and Ahiam; Eliphelet and Eliam; Hezro and Paarai; Igal and Bani; Zelek and Naharai; Ira and Gareb; then Uriah the Hittite. Narrator closes **thirty-seven in all**.

Uriah's placement inside David's mighty-men ledger visibly retains his prior service identity beside the already-retained David/Uriah history. That is evidence and ruthless irony, not a manufactured contradiction: the chapter supplies no rule claiming leaders cannot harm their own mighty men.

## God-line boundary

No independently narrated direct God speech occurs. David says LORD's Spirit spoke by him, God's word was on his tongue and God/Rock spoke to him; this is human-attributed divine speech nested in David's last-word carrier. Narrator separately attributes two great victories to LORD. Mechanism, form and exact speech-transmission relation remain unresolved.

## Character and world-ledger changes

- NOT-DAVID gains a retained last-words oracle, water-longing and poured-offering acts.
- The first three, water-fetching three, NOT-ABISHAI and NOT-BENAIAH retain distinct act and rank relations.
- The entire named roster remains per-verse, including NOT-URIAH as one of the mighty men.
- No rank labels are merged and no warrior motive is inferred.

## Bullshit pass

Issue `2SA-023 / LAST WORDS — TERMS AND CONDITIONS MAY CONTINUE SPEAKING`. Crackhead Personnel lists **THREE**, **OTHER THREE**, **THIRTY**, and **THIRTY-SEVEN IN ALL** in four incompatible-looking dropdowns that are not proven incompatible. Bethlehem Crackhead Water Delivery is free; drinking is not included. Foundation unchanged.

## FIR verification

- FILTER: all 39 markers retained; chapter 24 excluded.
- ISOLATE: David oracle carrier, warrior acts, water sequence, rank relations and complete roster.
- RECONSTRUCT: speech attribution remains nested; names/counts/ranks remain distinct.
- VERIFY: zero contradictions, episodes, SKIPs, Captain appearances and YOINKs; publication held.

## Required compound-eye facets

1. Narrator “last words” / David identity stack.
2. Spirit spoke by me / word on tongue attribution.
3. David quotes righteous God-fearing ruler speech.
4. Morning light/cloudless/rain-grass image.
5. House/covenant/salvation/desire/grow speech.
6. Ungodly thorns/untouchable by hand.
7. Iron/spear/fire handling image.
8. Josheb/Adino/eight hundred at one time.
9. Eleazar/three/Israel withdraws.
10. Eleazar hand-to-sword/LORD victory/people plunder.
11. Shammah/lentil plot/people flee.
12. Shammah defends/kills/LORD victory.
13. Three of thirty chiefs/Adullam/Rephaim.
14. David stronghold/Philistine Bethlehem garrison.
15. David's spoken longing for well water.
16. Three break through/draw/bring; David pours to LORD.
17. Blood-of-risked-lives explanation/refusal.
18. Abishai/three hundred/name among three.
19. Captain/more honorable/not one of three distinction.
20. Benaiah/two sons/Joe-faced lion/snow pit.
21. Huge Egyptian/staff/spear reversal.
22. Benaiah name among three.
23. More honorable than thirty/not attain three/guard.
24. Asahel/Elhanan.
25. Shammah/Elika.
26. Helez/Ira.
27. Abiezer/Mebunnai.
28. Zalmon/Maharai.
29. Heleb/Ittai.
30. Benaiah/Hiddai.
31. Abialbon/Azmaveth.
32. Eliahba/Jashen's sons/Jonathan.
33. Shammah/Ahiam.
34. Eliphelet/Eliam.
35. Hezro/Paarai.
36. Igal/Bani.
37. Zelek/Naharai/Joab armor-bearer relation.
38. Ira/Gareb.
39. Uriah the Hittite / thirty-seven in all / no-crack boundary / chapter 24 excluded.

All thirty-nine facets appear simultaneously.

## Production boundary

One high-resolution 39-facet compound-eye image. `NOT-` display; every living thing Joe-faced; violence restrained; David visibly carries the attributed divine speech; no divine body. Zero contradiction episodes, SKIPs, Captain appearances and YOINKs. Publication held; originator review required.

*shrug*

OK.
