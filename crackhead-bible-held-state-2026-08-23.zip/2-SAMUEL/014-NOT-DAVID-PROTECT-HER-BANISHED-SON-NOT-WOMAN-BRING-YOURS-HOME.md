# CRACKHEAD 2 SAMUEL 14

## Title field

**NOT-DAVID: PROTECT HER BANISHED SON. / NOT-WOMAN: BRING YOURS HOME.**

Source parent: 2 Samuel chapter 14, verses 1–33, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-014/job.json` and `source.usfm`. Parent: 2 Samuel 13. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Killing, grief, threats and fire remain restrained and non-graphic.

CrackFlix: `S044-E003-2SA14`, with inert `SKIP -> S044-E002-2SA12`; one causally-null post-closure YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
JOAB PERCEIVES KING HEART TOWARD ABSALOM
-> JOAB FETCHES TEKOA WOMAN / ORDERS MOURNING APPEARANCE
-> JOAB PUTS WORDS IN HER MOUTH
-> WOMAN PRESENTS WIDOW / TWO SONS / ONE KILLED OTHER / FAMILY SEEKS SURVIVOR CASE
-> DAVID PROMISES COMMAND / PROTECTION / LORD-OATH NO HAIR FALL
-> WOMAN MAPS DAVID'S WORD TO HIS OWN BANISHED ONE
-> WOMAN CONTINUES GOD/LIFE/KING SPEECH
-> DAVID ASKS WHETHER JOAB'S HAND IS IN THIS
-> WOMAN CONFIRMS JOAB URGED HER AND SUPPLIED WORDS
-> DAVID GRANTS JOAB'S REQUEST / ORDERS ABSALOM RETURN
-> JOAB BRINGS ABSALOM FROM GESHUR TO JERUSALEM
-> DAVID ORDERS ABSALOM OWN HOUSE / NO KING FACE
-> ABSALOM LIVES TWO YEARS JERUSALEM WITHOUT SEEING KING
-> ABSALOM SENDS FOR JOAB TWICE / JOAB DOES NOT COME
-> ABSALOM ORDERS JOAB BARLEY FIELD BURNED / SERVANTS BURN IT
-> JOAB COMES AND ASKS WHY
-> ABSALOM STATES REQUEST / GESHUR COMPARISON / SEE-KING OR KILL-ME CONDITION
-> JOAB REPORTS TO DAVID
-> DAVID CALLS ABSALOM
-> ABSALOM BOWS / DAVID KISSES HIM
```

## Verses 1–3 — JOAB BUILDS THE CARRIER

Joab perceives that the king's heart is toward Absalom. The perception is a narrator-stated Joab State; its mechanism is absent. Joab brings a wise woman from Tekoa and instructs her to act as a long-time mourner, wear mourning clothing and use no oil. He sends her to the king and puts the words in her mouth.

The mourning identity and coming family case are staged speech/action carriers. They are not upgraded into historical widow, husband or sons occurrences.

## Verses 4–11 — THE STAGED SON CASE / KING'S COMMITMENT

The woman falls before the king and asks for help. She says she is a widow whose husband is dead, that one of her two sons killed the other in a field fight, and that the family now demands the surviving son so they can kill him. She says that would extinguish the remaining coal and leave her husband neither name nor remainder.

David tells her to go home and promises a command. She assigns possible iniquity to herself and her father's house while calling the king and throne guiltless. David promises that anyone bothering her may be brought to him and will not bother her again. At her request that the king remember LORD so the blood avenger does not destroy more, David swears by the living LORD that not one hair of her son will fall.

These are commitments made against the staged case. No son, family pursuit, avenger or protection act is established outside the woman's supplied account.

## Verses 12–17 — THE JUDGMENT RETURNS TO DAVID

With permission to continue, the woman asks why David devised such a thing against God's people and says that by speaking this word he is like one guilty because he does not bring home his banished one. She speaks of universal death, spilled water that cannot be gathered, and attributes to God means by which a banished person is not outcast.

She then continues the staged case language: people made her afraid; she hoped the king would perform her request, deliver her and her son, and bring rest. She compares the king's discernment to an angel of God and wishes LORD with him. These remain her statements, not narrator-established divine speech, acts or ontology.

This is `S044-E003-2SA14`:

```text
DAVID HEARS A CONCEALED STAGED CASE ABOUT A BANISHED SURVIVING SON
DAVID COMMITS TO PROTECT AND PRESERVE THAT SON
WOMAN MAPS DAVID'S WORD TO DAVID'S OWN BANISHED SON STATE
```

It repeats `S044-E002-2SA12`, where David judged a concealed account before Nathan mapped it onto David's retained conduct.

**SKIP -> S044-E002-2SA12: JUDGMENT DELIVERED BEFORE THE JUDGE'S OWN RELATION IS REVEALED.**

SKIP does not remove the staged case, David's commitments, the reveal or any later act. One post-closure YOINK changes nothing.

## Verses 18–23 — JOAB REVEALED / ABSALOM RETURNED

David asks the woman not to hide what he asks and asks whether Joab's hand is with her in all this. She confirms Joab urged her and put all the words in her mouth, saying he acted to change the face of the matter. Her praise of David's angel-like wisdom and knowledge is her speech, not omniscience established by narration.

David tells Joab he has granted the thing and orders him to bring Absalom back. Joab bows, blesses David and says the performed request shows favor. Joab goes to Geshur and brings Absalom to Jerusalem.

## Verses 24–28 — RETURNED, BUT NO FACE

David orders Absalom to return to his own house without seeing the king's face. Absalom does so. Return to Jerusalem and exclusion from the king's presence are separately scoped States, so no contradiction is manufactured by collapsing them.

Narrator says nobody in Israel was praised as much as Absalom for beauty and that he had no defect from foot sole to head crown. His yearly cut hair weighed two hundred royal shekels. Three sons and one daughter, Tamar, were born to him; Tamar had a beautiful face. These are narrator descriptions. They do not create motive, moral worth or literal perfection beyond the selected body-description boundary.

Absalom lives two full years in Jerusalem without seeing the king's face.

## Verses 29–33 — TWO IGNORED SUMMONS / BARLEY FIRE / KING'S KISS

Absalom sends for Joab so Joab can carry a message to the king. Joab does not come. Absalom sends a second time; Joab again does not come.

Absalom points out Joab's adjacent barley field and orders his servants to set it on fire. They do. Joab then comes to Absalom's house and asks why the field was burned. The response follows a changed input: ignored summons are followed by destroyed barley. The chapter supplies no rule that Joab must answer a summons and no claim that fire caused nothing, so this is not a contradiction.

Absalom says he had sent for Joab to ask why he was brought from Geshur, says remaining there would have been better, and demands to see the king; if there is iniquity in him, the king may kill him. Joab reports to David. David calls Absalom; Absalom comes, bows to the ground, and David kisses him. No pardon, acquittal, restored office or motive is inferred from the kiss.

## Character and world-ledger changes

- NOT-JOAB gains staged-case construction, Tekoa-woman instruction, revealed authorship, Absalom retrieval, two non-responses, burned-field confrontation and final message delivery.
- NOT-TEKOA-WOMAN gains performed mourner carrier, supplied widow/sons case, incremental commitment requests, self-application reveal and Joab-authorship confirmation.
- NOT-DAVID gains staged-case protection commitments, self-application accusation, Joab identification, conditional Absalom return order and final audience/kiss.
- NOT-ABSALOM returns from Geshur to Jerusalem, remains two years outside David's presence, sends twice for Joab, orders the barley fire, states his audience-or-death condition, bows and receives David's kiss.
- NOT-TAMAR daughter of Absalom is retained as distinct from NOT-TAMAR sister of Absalom; no identity merge.
- Absalom's three unnamed sons, servants and Joab's barley remain exact source objects without invented names or outcomes.

## Bullshit pass

Issue `2SA-014 / CUSTOMER SUPPORT BY CONTROLLED BARLEY EVENT`. NOT-JOAB submits a widow ticket written entirely by NOT-JOAB. NOT-DAVID approves it. The ticket turns around and says **THIS IS ABOUT YOUR ACCOUNT, DICKHEAD.** Later, two ordinary messages expire, so NOT-ABSALOM upgrades to **BARLEY PRIORITY**. Foundation unchanged.

## FIR verification

- FILTER: all 33 markers retained; 2 Samuel 15 excluded.
- ISOLATE: staged case, king commitments, self-application reveal, Joab authorship, constrained return, two-year exclusion, ignored summons, fire and final audience.
- RECONSTRUCT: S044 recurrence closes only at the woman's self-application; return/no-face scopes and summons/fire response remain non-contradictory causal chains.
- VERIFY: one repeated episode, exact SKIP pointer, one YOINK; no staged facts promoted; publication held.

## Required compound-eye facets

1. Joab perceives king heart toward Absalom; mechanism unresolved.
2. Joab fetches NOT-TEKOA-WOMAN.
3. Mourning clothing/no oil/long-mourner acting instructions.
4. Joab puts words in her mouth.
5. Woman falls and asks NOT-DAVID for help.
6. Staged widow/dead husband/two sons setup.
7. Staged field fight / one son kills other, restrained.
8. Staged family demand to kill survivor / coal-name-remainder speech.
9. David promises house command.
10. Woman offers iniquity allocation / throne guiltless.
11. David promises protection from botherer.
12. Woman invokes LORD/blood avenger / David swears no hair falls.
13. Woman asks why David devised against God's people.
14. `S044-E003`: protect staged banished son / do not bring own banished son.
15. `SKIP -> S044-E002-2SA12`, inert and noncausal.
16. Water/death/God-means/banished speech, human attribution only.
17. Woman's fear/request/deliverance speech remains staged carrier.
18. Angel-like discernment praise / LORD-with-you wish.
19. David asks whether Joab's hand is in it.
20. Woman confirms Joab urged her and supplied every word.
21. One separate post-closure YOINK; Captain boilless and causally null.
22. David grants Joab request / orders Absalom back.
23. Joab bows/blesses / goes Geshur / brings Absalom Jerusalem.
24. David: own house, do not see my face / Absalom complies.
25. Absalom beauty/no-defect narrator State.
26. Annual haircut / two hundred royal shekels.
27. Three sons + daughter NOT-TAMAR; identity distinct from sister Tamar.
28. Two full Jerusalem years / no king face.
29. First and second summons / Joab does not come.
30. Adjacent barley / Absalom order / servants burn field.
31. Joab comes and asks why; changed input retained.
32. Absalom explains Geshur/audience/iniquity-kill condition.
33. Joab reports / David calls / Absalom bows / David kisses; chapter 15 excluded.

All thirty-three facets appear simultaneously.

## Production boundary

One high-resolution 33-facet compound-eye image. `NOT-` display; every living thing Joe-faced; killing, grief, threat and fire restrained/non-graphic; no divine body. `S044-E003-2SA14`, inert `SKIP -> S044-E002-2SA12`, exactly one causally-null post-closure YOINK. Preserve staged speech versus actual history, human divine attributions, scoped return/no-face States, distinct Tamar identities, changed-input Joab response and unresolved motives. Publication held; originator review required.

*shrug*

OK.
