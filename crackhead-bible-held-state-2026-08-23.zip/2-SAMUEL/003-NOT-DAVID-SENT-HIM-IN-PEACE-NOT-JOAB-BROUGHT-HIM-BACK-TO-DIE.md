# CRACKHEAD 2 SAMUEL 3

## Title field

**NOT-DAVID SENT HIM AWAY IN PEACE. NOT-JOAB BROUGHT HIM BACK TO DIE.**

Source parent: 2 Samuel chapter 3, verses 1–39, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-003/job.json` and `source.usfm`. Parent: 2 Samuel 2. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Sex, death and mourning remain restrained and non-graphic.

CrackFlix: new `S206-E001-2SA3`; no SKIP; one causally-null post-closure YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
LONG WAR / DAVID HOUSE STRONGER / SAUL HOUSE WEAKER
-> SIX NAMED SONS BORN TO DAVID IN HEBRON
-> ABNER STRONG IN SAUL HOUSE
-> ISHBOSHETH QUESTIONS ABNER ABOUT RIZPAH
-> ABNER ANGRY / STATES PRIOR LOYALTY / VOWS KINGDOM TRANSFER
-> ISHBOSHETH AFRAID / SILENT
-> ABNER OFFERS DAVID ALL-ISRAEL ALLIANCE
-> DAVID REQUIRES MICHAL
-> ISHBOSHETH TAKES MICHAL FROM PALTIEL / ABNER SENDS PALTIEL BACK
-> ABNER ADDRESSES ELDERS + BENJAMIN / COMES WITH TWENTY
-> DAVID FEASTS ABNER / ABNER PROMISES COVENANT GATHERING
-> DAVID SENDS ABNER AWAY IN PEACE
-> JOAB RETURNS / ACCUSES ABNER OF DECEPTION
-> JOAB SECRETLY RECALLS ABNER / DAVID DOES NOT KNOW
-> JOAB KILLS ABNER AT GATE
-> DAVID HEARS / DENIES RESPONSIBILITY / CURSES JOAB HOUSE
-> DAVID ORDERS PUBLIC MOURNING / FOLLOWS BIER / WEEPS / FASTS
-> PEOPLE UNDERSTAND KILLING NOT FROM KING
-> DAVID CALLS ABNER GREAT / HIMSELF WEAK / ZERUIAH SONS TOO HARD
```

## Verses 1–5 — WAR / HOUSE STRENGTH / SIX SONS

Long war continues between Saul's and David's houses. David's house grows stronger and Saul's weaker. Six sons are born to David in Hebron: Amnon/Ahinoam, Chileab/Abigail, Absalom/Maacah, Adonijah/Haggith, Shephatiah/Abital and Ithream/Eglah. No future biography is imported.

## Verses 6–11 — ACCUSATION / ANGER / OPEN TRANSITION

Abner strengthens himself in Saul's house. Ishbosheth asks why he went in to Saul's concubine Rizpah. The question does not establish the act. Abner becomes angry, cites kindness and his prior non-delivery of Ishbosheth to David, rejects the charged fault, and vows to perform the LORD-attributed transfer from Saul's house to David's throne over Israel and Judah. Ishbosheth is afraid and cannot answer.

This is an explicit changed allegiance State following the accusation, not a hidden contradiction. The alleged Rizpah act and Abner's stated divine history remain unverified carriers.

## Verses 12–21 — ALLIANCE / MICHAL TRANSFER / PEACEFUL DEPARTURE

Abner offers David an alliance and all-Israel transfer. David agrees on condition Michal is brought. David separately demands Michal from Ishbosheth, citing the hundred-foreskin marriage transaction. Ishbosheth takes her from husband Paltiel; Paltiel follows weeping to Bahurim until Abner orders him home. Michal's speech, consent and internal State are absent and not invented.

Abner tells Israel's elders they previously sought David, tells them to act using an attributed LORD saying, speaks to Benjamin, and reports their preferred State to David. He arrives at Hebron with twenty men; David provides a feast. Abner promises to gather Israel for covenant and desired reign. David sends him away, and he goes **in peace**.

## Verses 22–30 — PEACE CARRIER NULLIFIED BY SECRET RECALL AND KILLING

Joab returns from a raid with plunder and learns Abner came and left in peace. Joab challenges David and asserts Abner came to deceive and surveil him. The source provides no observation proving that asserted purpose; it remains Joab's mental model.

Joab leaves David, sends messengers after Abner and has him brought back from Sirah without David's knowledge. At Hebron Joab takes Abner aside as if to speak quietly and kills him for Asahel's blood. Verse 30 includes Joab and Abishai in the killing attribution.

New `S206-E001-2SA3` closes:

```text
KING SENDS ABNER AWAY IN PEACE
-> SUBORDINATE SECRETLY RECALLS HIM WITHOUT KING'S KNOWLEDGE
-> ABNER RETURNS AND IS KILLED
```

The peace was a completed departure State, not a guarantee that rewrites future causality. The later secret act produces its direct opposite outcome. First occurrence: no SKIP. One separate YOINK changes nothing.

## Verses 28–39 — DENIAL / CURSE / MOURNING / PUBLIC UNDERSTANDING

After hearing, David declares himself and kingdom guiltless before LORD, directs a continuing curse at Joab's father's house, orders Joab and people to tear clothes, wear sackcloth and mourn, follows Abner's bier, weeps at burial and laments. People urge him to eat; he swears not to taste food before sunset. People notice, are pleased, and all Israel understands that day the killing was not from the king.

David calls Abner a prince/great man, says he is weak though anointed king, calls Zeruiah's sons too hard for him and wishes LORD reward the evildoer. These are observed speech and public reactions. The future curse/reward, full political effect and later punishment remain unresolved.

## Character and world-ledger changes

- NOT-DAVID gains six-son household lineage, Michal demand, Abner treaty/feast/peace departure, public nonknowledge/nonresponsibility, mourning and weak-king speech.
- NOT-ABNER gains open allegiance transition, Michal/Paltiel routing, elder/Benjamin negotiations, covenant promise, peaceful departure, secret recall and dead State.
- NOT-ISHBOSHETH gains accusation, fear/silence and Michal transfer acts.
- NOT-MICHAL is transferred from NOT-PALTIEL; her unspoken State remains unresolved.
- NOT-JOAB gains deception accusation, unauthorized recall and killing; NOT-ABISHAI is included by verse-30 killing attribution.

## Bullshit pass

Issue `2SA-003 / PEACEFUL OFFBOARDING WITH UNAUTHORIZED CALLBACK`. NOT-DAVID closes the meeting **SENT IN PEACE**. NOT-JOAB opens a shadow ticket, recalls the guest, and completes a fatal exit interview. The king then deploys sackcloth compliance, public fasting and a permanent curse SLA he says he is too weak to enforce personally. Foundation unchanged.

## FIR verification

- FILTER: all 39 markers retained; 2 Samuel 4 excluded.
- ISOLATE: war/sons, accusation/transition, alliance/Michal, negotiations/feast/peace, secret recall/killing, denial/mourning/public response.
- RECONSTRUCT: Rizpah and deception remain unverified claims; peace-to-secret-death is the exact external mismatch.
- VERIFY: one new episode, no SKIP, one YOINK; future covenant/curse/reward unresolved; publication held.

## Required compound-eye facets

1. Long war / David house stronger / Saul house weaker.
2. Six named sons and mothers in Hebron.
3. Ishbosheth Rizpah question / act unverified.
4. Abner anger, prior-loyalty speech and kingdom-transfer vow.
5. Ishbosheth fear/silence.
6. Abner alliance offer / David Michal condition.
7. David demand / Ishbosheth takes Michal from Paltiel.
8. Paltiel follows weeping / Abner sends him back.
9. Abner elder/Benjamin communications and attributed LORD speech.
10. Abner plus twenty at Hebron / David feast.
11. Covenant-gathering promise / David sends Abner in peace.
12. Joab raid return / report of peaceful departure.
13. Joab deception/surveillance assertion marked unverified mental model.
14. Joab secret recall / David does not know.
15. Quiet-talk pretext / Joab kills Abner, restrained.
16. Verse-30 Joab+Abishai attribution / Asahel-blood relation.
17. `S206-E001`: SENT IN PEACE / SECRETLY RECALLED / KILLED.
18. No SKIP / one causally-null YOINK.
19. David guiltless declaration and Joab-house curse speech.
20. Sackcloth/bier/burial/weeping/lament.
21. David refuses food until sunset / people notice and approve.
22. Israel understands killing not from king.
23. Great-man/weak-king/sons-too-hard/reward speech.
24. 2 Samuel 3 held; chapter 4 excluded.

All twenty-four facets appear simultaneously.

## Production boundary

One high-resolution 24-facet compound-eye image. `NOT-` display; living things Joe-faced; sex/death non-graphic; divine speaker unrendered. `S206-E001-2SA3`, no SKIP, one causally-null YOINK. Preserve claims as claims, open allegiance transition, Michal silence, peace departure, David nonknowledge, exact killing attribution and public reaction. Publication held; originator review required.

*shrug*

OK.
