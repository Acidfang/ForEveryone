# CRACKHEAD 2 SAMUEL 11

## Title field

**NOT-DAVID: PUT HIM THERE SO HE DIES. / NOT-DAVID: THE SWORD EATS EVERYONE.**

Source parent: 2 Samuel chapter 11, verses 1–27, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-011/job.json` and `source.usfm`. Parent: 2 Samuel 10. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Sex, bathing, pregnancy, intoxication, war and deaths remain restrained and non-graphic. Consent is not invented.

CrackFlix: new `S210-E001-2SA11`; no SKIP; one causally-null post-closure YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
RETURN OF YEAR / JOAB + SERVANTS + ISRAEL SENT TO AMMON/RABBAH
-> DAVID STAYS JERUSALEM
-> DAVID SEES WOMAN BATHING FROM ROOF
-> INQUIRY RETURNS BATHSHEBA / ELIAM DAUGHTER / URIAH WIFE
-> DAVID SENDS MESSENGERS / TAKES HER / SEX / SHE RETURNS HOME
-> BATHSHEBA CONCEIVES / TELLS DAVID
-> DAVID SUMMONS URIAH THROUGH JOAB
-> WAR-STATUS QUESTIONS / HOUSE + FOOT-WASH ORDER / GIFT
-> URIAH SLEEPS AT KING-HOUSE DOOR
-> DAVID QUESTIONS / URIAH CITES ARK+ARMY FIELD STATE AND REFUSES HOUSE ACT
-> DAVID RETAINS URIAH TWO DAYS / MAKES HIM DRUNK
-> URIAH AGAIN SLEEPS WITH SERVANTS / NOT AT HOUSE
-> DAVID WRITES TARGETED DEATH ORDER / URIAH CARRIES IT
-> JOAB ASSIGNS URIAH AT VALIANT-MEN LOCATION
-> CITY MEN FIGHT / DAVID SERVANTS + URIAH DIE
-> JOAB BUILDS REPORT INSTRUCTION AROUND EXPECTED WRATH
-> MESSENGER REPORTS WALL SHOOTERS / SERVANT DEATHS / URIAH DEATH
-> DAVID: SWORD DEVOURS ONE AS ANOTHER / STRENGTHEN + OVERTHROW
-> BATHSHEBA MOURNS
-> DAVID TAKES HER INTO HOUSE / SHE BECOMES WIFE / BEARS SON
-> NARRATOR: DAVID'S ACT DISPLEASED LORD
```

## Verses 1–5 — RABBAH / ROOF / BATHSHEBA / PREGNANCY

At the return of the year, described as the time kings go out, David sends Joab, servants and all Israel; they destroy Ammon's children and besiege Rabbah. David stays in Jerusalem. The seasonal phrase does not state a universal rule that every king must personally depart, so no contradiction is inferred.

David rises at evening, walks his roof and sees a woman bathing, described as very beautiful. He inquires and receives her identity: Bathsheba daughter of Eliam, wife of Uriah the Hittite. David sends messengers and takes her; she comes in, he has sex with her, and she returns home. She had purified from uncleanness. The source does not state consent, refusal, coercion dialogue, messenger conduct or private motive; the comic does not fill those gaps.

Bathsheba conceives and sends David the statement: “I am with child.”

## Verses 6–13 — URIAH SUMMONED / TWO NON-RETURNS HOME

David tells Joab to send Uriah; Joab does. David asks how Joab, the people and war fare, then orders Uriah to his house to wash his feet. Uriah leaves and a king's gift follows, but he sleeps at the king-house door with the servants and does not go home.

After being told, David asks why. Uriah cites the ark, Israel, Judah, Joab and servants in tents/open field, then swears he will not go home to eat, drink and lie with his wife. This is Uriah's explicit reason; David's purpose in ordering the home visit is not stated.

David keeps Uriah through the next day, calls him to eat/drink and makes him drunk. Uriah still sleeps with the servants and does not go home. Intoxication is observed; no further mental State is inferred.

## Verses 14–17 — THE ADDRESSED DEATH ORDER

David writes Joab a letter and sends it in Uriah's hand. The letter says to place Uriah at the hottest front and retreat from him so he will be struck and die. This is an explicit targeted-death instruction.

Joab assigns Uriah where he knows valiant men are. City men fight; some of David's servants fall and Uriah dies. The source does not state that Joab performs the exact retreat instruction, which other servants are selected, or which fighter kills Uriah. The causal chain does retain David's order, Joab's addressed placement and the resulting death.

## Verses 18–25 — REPORT PACKAGING / “THE SWORD DEVOURS”

Joab sends a war report and instructs the messenger that, if David becomes angry about approaching the wall and cites Abimelech's millstone death at Thebez, the messenger should add that Uriah is dead. David's actual wrath and the hypothetical questions are not performed.

The messenger reports the field/gate movement, wall shooters, deaths among David's servants and Uriah's death. David answers that the sword devours one as well as another, tells Joab not to be displeased, and orders a stronger battle and overthrow of the city.

This closes `S210-E001-2SA11`:

```text
DAVID'S WRITTEN ORDER: TARGET URIAH / WITHDRAW / HE WILL DIE
URIAH DIES IN THE ADDRESSED BATTLE LOCATION
DAVID'S ACCOUNT: THE SWORD DEVOURS ONE AS WELL AS ANOTHER
```

The contradiction is between the retained selection of one person for death and David's undifferentiated fatality explanation. It does not require a guessed concealment motive. First occurrence: no SKIP. One YOINK changes nothing.

## Verses 26–27 — MOURNING / HOUSE / SON / NARRATOR JUDGMENT

Uriah's wife hears he is dead and mourns him. After mourning, David sends and takes her into his house; she becomes his wife and bears a son. The source supplies no ceremony, elapsed duration beyond mourning, consent statement or name for the son here.

Narrator says the thing David had done displeased LORD. This is a narrator-attributed divine evaluation, not a visible divine body or direct speech. Its more exact scope and consequences continue into chapter 12 and are not imported here.

## Character and world-ledger changes

- NOT-DAVID gains Bathsheba inquiry/taking/sex, Uriah summons/home orders/intoxication, targeted-death letter, generalized sword explanation, remarriage/son and narrator-displeasure State.
- NOT-BATHSHEBA gains bathing observation, retrieval/sex, pregnancy report, Uriah mourning, David-house wife State and unnamed son; consent/private motive remain unresolved.
- NOT-URIAH gains summons, two house non-returns with explicit field-solidarity reason, letter carriage, targeted placement and death.
- NOT-JOAB gains receipt of death instruction, known-valiant-men placement and conditional report packaging.
- unnamed fallen servants retain separate deaths; they are not collapsed into Uriah's targeted identity.

## Bullshit pass

Issue `2SA-011 / SWORD RANDOMIZER WITH MANUAL TARGET OVERRIDE`. NOT-DAVID writes **MAKE THIS SPECIFIC JOE DIE**, receives **SPECIFIC JOE DEAD**, then opens Crackhead Casualty Analytics: **SWORDS, EH? COULD BE ANYONE.** Foundation unchanged.

## FIR verification

- FILTER: all 27 markers retained; 2 Samuel 12 excluded.
- ISOLATE: Rabbah deployment, Bathsheba sequence, pregnancy report, Uriah home/non-home sequence, explicit death order, placement/deaths, report, generalized explanation, mourning/marriage/son and narrator judgment.
- RECONSTRUCT: targeted order versus undifferentiated sword account closes one contradiction; consent, concealment motive and unperformed hypothetical wrath are not invented.
- VERIFY: one new episode, no SKIP, one YOINK; sexual/violent material restrained; publication held.

## Required compound-eye facets

1. Seasonal return / Joab-servants-Israel to Ammon/Rabbah / David stays Jerusalem.
2. Evening roof walk / Bathsheba bathing observation, restrained.
3. Inquiry response: Bathsheba, Eliam daughter, Uriah wife.
4. Messengers/taking/sex/return/purification sequence, restrained and consent unresolved.
5. Pregnancy / “I am with child.”
6. David-to-Joab Uriah summons / Joab sends.
7. War-status questions / house-foot-wash order / gift.
8. Uriah sleeps at king-house door, not home.
9. David asks why / Uriah states ark-army-field reason and refusal.
10. Stay-today/tomorrow promise / two-day retention.
11. David makes Uriah drunk / Uriah again sleeps with servants, not home.
12. David writes targeted death letter / Uriah carries it.
13. Letter text: hottest battle / retreat / struck and die.
14. Joab assigns known valiant-men location.
15. City fight / unnamed servants and Uriah die, non-graphic.
16. Joab's conditional report instruction / hypothetical wrath and Abimelech reference visibly unexecuted.
17. Messenger actual field/gate/wall-shooter/death report.
18. `S210-E001`: targeted Uriah death order / “sword devours one as another.”
19. No SKIP / one separate post-closure YOINK.
20. Stronger battle / overthrow order; future result not imported.
21. Bathsheba hears and mourns Uriah.
22. David takes her home / wife / unnamed son.
23. Narrator: David's act displeased LORD; no divine body.
24. 2 Samuel 11 held; chapter 12 excluded.

All twenty-four facets appear simultaneously.

## Production boundary

One high-resolution 24-facet compound-eye image. `NOT-` display; every living thing Joe-faced; bathing/sex/pregnancy/intoxication/war/deaths restrained and non-graphic; consent unresolved; no divine body. New `S210-E001-2SA11`, no SKIP, exactly one causally-null post-closure YOINK. Preserve targeted order versus generalized explanation, separate unnamed deaths, hypothetical-versus-actual report and final narrator judgment. Publication held; originator review required.

*shrug*

OK.
