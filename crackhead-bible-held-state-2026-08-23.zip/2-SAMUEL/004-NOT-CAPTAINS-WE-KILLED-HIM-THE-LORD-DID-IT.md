# CRACKHEAD 2 SAMUEL 4

## Title field

**NOT-CAPTAINS: WE KILLED HIM. THE LORD DID IT.**

Source parent: 2 Samuel chapter 4, verses 1–12, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-004/job.json` and `source.usfm`. Parent: 2 Samuel 3. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Killing, body handling, execution and disability remain restrained and non-graphic.

CrackFlix: new mental `S207-E001-2SA4`; no SKIP; one causally-null post-closure YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
ISHBOSHETH HEARS ABNER DEAD -> HANDS FEEBLE / ISRAEL TROUBLED
-> RECHAB + BAANAH IDENTIFIED AS RAID CAPTAINS
-> BEEROTH / GITTAIM LINEAGE RETAINED
-> MEPHIBOSHETH FALL-IN-FLIGHT HISTORY RETAINED
-> CAPTAINS ARRIVE WHILE ISHBOSHETH RESTS
-> ENTER AS IF FETCHING WHEAT
-> STRIKE / KILL / REMOVE HEAD / ESCAPE
-> TRAVEL ALL NIGHT / BRING HEAD TO DAVID
-> CAPTAINS: LORD AVENGED YOU THROUGH THIS
-> DAVID CITES PRIOR NEWS-BRINGER EXECUTION
-> DAVID: WICKED MEN KILLED RIGHTEOUS PERSON IN BED
-> DAVID REQUIRES BLOOD / ORDERS EXECUTION
-> YOUNG MEN KILL / DISPLAY CAPTAINS
-> ISHBOSHETH HEAD BURIED IN ABNER GRAVE
```

## Verses 1–4 — COLLAPSE / CAPTAIN LINEAGE / MEPHIBOSHETH HISTORY

Ishbosheth hears Abner died in Hebron; his hands become feeble and Israel is troubled. Rechab and Baanah are identified as Ishbosheth's raiding-band captains, sons of Rimmon, Beerothites of Benjamin; Beerothites fled to Gittaim and remain foreigners there.

Jonathan's son Mephibosheth is retained: at five, news of Saul/Jonathan came from Jezreel; his nurse carried him in flight, he fell during the hurried escape and became lame in both feet. The nurse's motive, medical mechanism and later life are not invented.

## Verses 5–8 — ACCESS / KILLING / DIVINE-VENGEANCE CLAIM

Rechab and Baanah arrive at Ishbosheth's house in midday heat while he rests. They enter as though fetching wheat, strike him, later narration repeats that they enter his bedroom, kill and behead him, take the head, escape and travel all night through Arabah.

They bring the head to David and say it is the head of his enemy, Saul's son, and that **the LORD has avenged** David that day of Saul and his offspring.

The source observes their access, killing, object removal, travel and speech. It supplies no direct LORD command, act or attribution. New mental `S207-E001-2SA4`:

```text
CAPTAINS PERFORM SECRET BEDROOM KILLING
CAPTAINS ASSERT: LORD AVENGED DAVID THROUGH THIS OUTCOME
RETAINED DIVINE ACT/ORDER: NONE
```

The mental crack is the asserted causal State exceeding evidence. It does not prove what they privately believed or expected. First occurrence: no SKIP. One YOINK changes nothing.

## Verses 9–12 — DAVID'S PRECEDENT / CLASSIFICATION / EXECUTIONS

David swears by the living LORD who redeemed him from adversity. He cites the prior Ziklag messenger: the man reported Saul dead thinking he brought good news, and David killed him as the reward for his news. This is a retained history pointer, not a replay or new SKIP.

David calls Rechab and Baanah wicked men who killed a righteous person in his house on his bed, says he will require Ishbosheth's blood from their hands and rid the earth of them. He commands young men; they kill the captains, remove hands/feet and hang them by Hebron's pool. Ishbosheth's head is buried in Abner's grave. Presentation remains non-graphic.

David's righteousness/wickedness and LORD-redemption statements remain his speech. The executions and burial are observed. No divine endorsement or afterlife effect is inferred.

## Character and world-ledger changes

- NOT-ISHBOSHETH closes living State after feebleness, rest, secret attack, death and partial burial.
- NOT-RECHAB and NOT-BAANAH gain trusted-captain lineage, wheat-access appearance, killing, head delivery, divine-vengeance attribution and executed State.
- NOT-DAVID gains receipt, prior-precedent speech, wicked/righteous classification, blood-requirement order and burial routing.
- NOT-MEPHIBOSHETH gains five-year-old flight/fall/disability lineage; he remains alive.
- NOT-YOUNG-MEN gain execution/display acts.

## Bullshit pass

Issue `2SA-004 / UNSOLICITED HEAD DELIVERY WITH DIVINE INVOICE`. Two NOT-CAPTAINS use the wheat entrance, terminate the sleeping account holder, and submit his head as **LORD-AUTHORIZED CUSTOMER SUCCESS**. NOT-DAVID checks the previous reward schedule and pays them exactly the same way: termination. Foundation unchanged.

## FIR verification

- FILTER: all 12 markers retained; 2 Samuel 5 excluded.
- ISOLATE: Abner-death reaction, identities, Mephibosheth history, access/killing, delivery/claim, David response/execution/burial.
- RECONSTRUCT: divine vengeance is captains' unsupported causal assertion; David's moral/divine language remains his speech.
- VERIFY: one new mental episode, no SKIP, one YOINK; no motive/belief/divine effect invented; publication held.

## Required compound-eye facets

1. Abner-death news / Ishbosheth feeble hands / Israel troubled.
2. Rechab/Baanah raiding-captain and Beeroth/Gittaim lineage.
3. Five-year-old Mephibosheth carried in flight / fall / disability, restrained.
4. Midday arrival / Ishbosheth resting.
5. Wheat-fetching appearance / entry.
6. Bedroom strike/killing/head removal, non-graphic.
7. Escape / all-night Arabah travel.
8. Head delivered to David, non-graphic.
9. `S207-E001`: OUR KILLING / LORD AVENGED; no divine act supplied.
10. No SKIP / one separate causally-null mental-crack YOINK.
11. David cites prior Ziklag messenger reward.
12. David wicked/righteous/blood-requirement speech.
13. Ordered executions/display and Ishbosheth-head burial, non-graphic; chapter 5 excluded.

All thirteen facets appear simultaneously.

## Production boundary

One high-resolution 13-facet compound-eye image. `NOT-` display; living things Joe-faced; all violence/body/disability restrained and non-graphic; no divine form. Mental `S207-E001-2SA4`, no SKIP, one causally-null YOINK. Preserve actual acts, claimed LORD causation, David's separate classification, prior history pointer and Mephibosheth lineage. Publication held; originator review required.

*shrug*

OK.
