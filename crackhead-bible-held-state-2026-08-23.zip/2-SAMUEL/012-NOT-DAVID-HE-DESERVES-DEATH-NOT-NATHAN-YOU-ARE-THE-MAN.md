# CRACKHEAD 2 SAMUEL 12

## Title field

**NOT-DAVID: HE DESERVES DEATH. / NOT-NATHAN: YOU ARE THE MAN.**

Source parent: 2 Samuel chapter 12, verses 1–31, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-012/job.json` and `source.usfm`. Parent: 2 Samuel 11. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Death, illness, sex, warfare and forced labor remain restrained and non-graphic.

CrackFlix: `S044-E002-2SA12`, with inert `SKIP -> S044-E001-GEN38`; one causally-null post-closure YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
LORD SENDS NATHAN TO DAVID
-> NATHAN TELLS RICH-MAN / POOR-MAN / ONE-LAMB PARABLE
-> RICH MAN TAKES POOR LAMB FOR TRAVELER
-> DAVID ANGRY / DEATH + FOURFOLD JUDGMENT
-> NATHAN: YOU ARE THE MAN
-> DIRECT LORD SPEECH MAPS KINGSHIP/GIFTS + URIAH/WIFE ACTS
-> SWORD-HOUSE + PUBLIC-HOUSE EVIL SPEECH
-> DAVID: I SINNED
-> NATHAN: SIN PUT AWAY / DAVID WILL NOT DIE / CHILD WILL DIE
-> NATHAN DEPARTS
-> LORD STRIKES CHILD / CHILD VERY SICK
-> DAVID BEGS/FASTS/LIES ON GROUND / REFUSES FOOD
-> SEVENTH DAY CHILD DIES
-> SERVANTS FEAR REPORT / DAVID OBSERVES WHISPERING / ASKS / THEY CONFIRM
-> DAVID RISES/WASHES/ANOINTS/CHANGES/WORSHIPS/EATS
-> SERVANTS ASK ABOUT CHANGED ACT
-> DAVID EXPLAINS LIVE-CHILD HOPE / DEAD-CHILD FINALITY
-> DAVID COMFORTS BATHSHEBA / SEX / SOLOMON BORN
-> NARRATOR: LORD LOVES HIM / NATHAN CARRIES JEDIDIAH NAME
-> JOAB TAKES RABBAH ROYAL/WATER CITY
-> JOAB ASKS DAVID TO COMPLETE TAKE TO RETAIN NAME
-> DAVID GATHERS/FIGHTS/TAKES CITY
-> CROWN/PLUNDER / PEOPLE PUT TO FORCED WORK
-> DAVID + PEOPLE RETURN JERUSALEM
```

## Verses 1–6 — PARABLE / DAVID'S JUDGMENT

LORD sends Nathan to David. Nathan tells of a rich man with many animals and a poor man with one purchased/raised ewe lamb living with his children, eating/drinking/lying with the family like a daughter. When a traveler arrives, the rich man refuses his own stock, takes the poor man's lamb and prepares it.

David's anger burns. He swears the man deserves death and must restore fourfold because he acted without pity. The parable is Nathan's speech; no literal city, men, family, traveler or lamb is established outside that carrier.

## Verses 7–12 — “YOU ARE THE MAN” / DIRECT SPEECH

Nathan says, “You are the man,” then carries direct LORD speech: David was anointed/delivered/given house, wives, Israel and Judah, with more available. The speech asks why David despised LORD's word, says David struck Uriah, took Uriah's wife and killed him through Ammon's sword, then announces continuing sword in David's house and future public evil involving David's house/wives.

This is `S044-E002-2SA12`:

```text
DAVID HEARS A CONCEALED-IDENTITY TAKING ACCOUNT
DAVID: THE MAN DESERVES DEATH + FOURFOLD RESTORATION
NATHAN: YOU ARE THE MAN
NATHAN'S LORD-SPEECH CARRIER MAPS DAVID'S RETAINED URIAH/WIFE ACTS
```

It repeats `S044-E001-GEN38`, where an actor condemned a concealed-identity sexual/pregnancy occurrence before evidence returned the actor's own participation.

**SKIP -> S044-E001-GEN38: JUDGMENT DELIVERED BEFORE THE JUDGE'S OWN RELATION IS REVEALED.**

SKIP does not remove the parable, judgment, reveal or later outcomes. David's awareness before Nathan's reveal is not invented. One post-closure YOINK changes nothing.

## Verses 13–15a — CONFESSION / PUT-AWAY / DIFFERENT OUTCOMES

David says, “I have sinned against the LORD.” Nathan says LORD has put away David's sin and David will not die, but says the child born to him will die because the deed gave LORD's enemies occasion to blaspheme. Nathan departs.

David-not-dying and child-dying are explicitly different subjects. Pardon and consequence are separately spoken; no contradiction is manufactured by merging them. Enemy blasphemy is Nathan's attributed causal statement; no enemy speech is shown here.

## Verses 15b–23 — ILLNESS / DEATH / FASTING STATE CHANGE

Narrator says LORD strikes the child Uriah's wife bore to David; the child becomes very sick. David begs God, fasts and lies all night on the ground. Elders try to raise him, but he refuses and does not eat.

On day seven the child dies. Servants fear telling David, reasoning aloud that since he would not listen while the child lived, he may harm himself after hearing. Their predicted self-harm remains a mental model; David does not perform it. David sees whispering, perceives the death, asks, and receives confirmation.

David then rises, washes, anoints, changes clothes, enters LORD's house, worships, returns home and eats. Servants ask why his behavior reversed. David explains that while the child lived he fasted/wept because LORD might be gracious and the child might live; after death, fasting cannot bring him back. He says he will go to the child and the child will not return.

The changed act follows David's explicit changed condition and stated reasoning. It is not contradiction.

## Verses 24–25 — SOLOMON / JEDIDIAH

David comforts Bathsheba his wife and has sex with her; she bears a son named Solomon. The source does not state consent or exact timing. Narrator says LORD loved him and that a message was sent by Nathan, naming him Jedidiah for LORD's sake. Solomon and Jedidiah are joined to one child by the source; no identity split is created.

## Verses 26–31 — RABBAH COMPLETION / CROWN / WORK

Joab fights Rabbah and takes the royal city, then reports taking the city of waters. He tells David to gather the remaining people, encamp and take the city lest Joab take it and it bear his name. These completed/subsequent city-taking statements are retained as source-distinguished royal/water-city and final-city States; their exact geography is unresolved, so no contradiction is forced.

David gathers the people, fights and takes Rabbah. He removes the king's one-talent gold crown with precious stones; it is placed on David. He removes much plunder. People are brought out and put to work under saws, iron picks, iron axes and at the brick kiln; the same is done to Ammon's cities. The source wording is forced-work, not an execution statement. David and the people return to Jerusalem.

## Character and world-ledger changes

- NOT-NATHAN gains LORD-sent parable delivery, identity reveal, direct-speech carrier, confession response, child-death statement and later Jedidiah naming carrier.
- NOT-DAVID gains parable judgment/self-reveal, confession, seven-day fasting/worship/eating transition, Bathsheba comfort, Solomon fatherhood and Rabbah completion/crown/plunder State.
- NOT-BATHSHEBA gains child-loss mourning context only through the child's death, later comfort/sex and Solomon birth; private State remains unresolved.
- first unnamed child becomes sick and dies on day seven.
- NOT-SOLOMON/NOT-JEDIDIAH is one living child with two source names.
- NOT-JOAB gains royal/water-city capture and final-capture handoff to David.

## Bullshit pass

Issue `2SA-012 / JUDGMENT FORM WITH HIDDEN ACCOUNT OWNER`. NOT-DAVID selects **DEATH + 4X**. NOT-NATHAN clicks **SHOW CUSTOMER**. CrackFlix opens Genesis 38, fails to skip anything, and the whole complaint remains on screen. Foundation unchanged.

## FIR verification

- FILTER: all 31 markers retained; 2 Samuel 13 excluded.
- ISOLATE: parable/judgment/reveal, divine speech, confession/consequence, child illness/death, fasting transition, Solomon/Jedidiah and Rabbah completion.
- RECONSTRUCT: S044 recurrence is judgment against concealed own-related conduct; subject-distinct pardon/death and condition-driven fasting change are not contradictions.
- VERIFY: one repeated episode, exact SKIP pointer, one YOINK; sensitive content restrained; publication held.

## Required compound-eye facets

1. LORD sends Nathan / Nathan arrives; no divine body.
2. Rich/poor men and many-stock/one-lamb parable setup.
3. Lamb family life / traveler / rich man takes poor lamb.
4. David anger / death + fourfold judgment.
5. Nathan: “You are the man.”
6. `S044-E002`: concealed taking account / judge's own mapped conduct.
7. `SKIP -> S044-E001-GEN38`, inert and noncausal.
8. LORD-speech history of anointing/delivery/gifts.
9. LORD-speech Uriah/wife accusation and sword-house statement.
10. Future public-house/wives speech, visibly future.
11. David confession / Nathan sin-put-away / David-not-die.
12. Child-will-die statement / Nathan departure / one separate YOINK.
13. LORD strikes child / severe illness; no divine body.
14. David begs/fasts/ground / elders fail to raise/feed him.
15. Seventh-day child death / servants' self-harm prediction visibly unperformed.
16. Whispering / David perception/question / servants confirm death.
17. Rise/wash/anoint/change/worship/home/eat.
18. Servants ask about reversal.
19. David explains live-child hope versus dead-child finality.
20. David comforts Bathsheba / sex restrained / Solomon born.
21. LORD-loved narrator State / Nathan carries Jedidiah name.
22. Joab takes royal/water city and requests final capture handoff.
23. David gathers/fights/takes Rabbah.
24. One-talent jeweled crown / David / plunder.
25. Ammon people put to tool/brick-kiln work, restrained and not execution.
26. All return Jerusalem.
27. 2 Samuel 12 held; chapter 13 excluded.

All twenty-seven facets appear simultaneously.

## Production boundary

One high-resolution 27-facet compound-eye image. `NOT-` display; every living thing Joe-faced; illness/death/sex/war/forced labor restrained and non-graphic; no divine body. `S044-E002-2SA12`, inert `SKIP -> S044-E001-GEN38`, exactly one causally-null post-closure YOINK. Preserve parable versus mapped act, direct/narrator/human attribution types, subject-distinct outcomes, explained fasting transition, one-child/two-name identity and royal/water/final-city distinctions. Publication held; originator review required.

*shrug*

OK.
