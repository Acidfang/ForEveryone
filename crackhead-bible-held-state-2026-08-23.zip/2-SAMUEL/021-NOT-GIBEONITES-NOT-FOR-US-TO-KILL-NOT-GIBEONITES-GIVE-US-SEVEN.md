# CRACKHEAD 2 SAMUEL 21

## Title field

**NOT-GIBEONITES: IT IS NOT FOR US TO PUT ANY MAN TO DEATH. / NOT-GIBEONITES: GIVE US SEVEN; WE WILL HANG THEM.**

Source parent: ENGWEBP 2 Samuel chapter 21, verses 1-22, USFM. Prepared evidence: `.chapter-work/CHB-2SA-021/job.json` and `source.usfm`. Parent: 2 Samuel 20. Exact identities remain evidence; visible names use `NOT-`. Every living thing is Joe-faced. Execution, exposed remains and battle deaths remain restrained/non-graphic.

CrackFlix: repeated `S009-E002-2SA21` with inert `SKIP -> S009-E001`; new `S217-E001-2SA21` with no SKIP. Exactly two separate causally-null post-closure YOINKs. One high-resolution compound-eye field.

## Causal foundation

```text
THREE-YEAR FAMINE
-> DAVID SEEKS LORD
-> LORD: FAMINE FOR SAUL/BLOODY HOUSE BECAUSE SAUL KILLED GIBEONITES
-> DAVID ASKS GIBEONITE ATONEMENT TERMS
-> GIBEONITES: NOT SILVER/GOLD; NOT FOR US TO PUT ANY MAN TO DEATH
-> DAVID: WHATEVER YOU SAY
-> GIBEONITES: DELIVER SEVEN OF SAUL'S SONS; WE WILL HANG THEM
-> DAVID SPARES JONATHAN'S MEPHIBOSHETH FOR OATH
-> DAVID SELECTS SEVEN OTHER DESCENDANTS
-> GIBEONITES EXECUTE SEVEN
-> RIZPAH GUARDS REMAINS UNTIL SKY WATER
-> DAVID GATHERS SAUL/JONATHAN/SEVEN BONES
-> COLLECTIVE BURIAL / GOD ANSWERS PRAYER FOR LAND
-> FOUR PHILISTINE-GIANT BATTLE OCCURRENCES
-> DAVID FAINTS / ABISHAI KILLS ISHBIBENOB / MEN EXCLUDE DAVID FROM FUTURE BATTLE
-> SIBBECAI, ELHANAN, JONATHAN KILL THREE OTHERS
```

## Verses 1–3 — FAMINE AND ATTRIBUTED CAUSE

Three successive famine years occur. David seeks LORD. Direct LORD speech attributes the famine to Saul and his bloody house because Saul killed Gibeonites. Narrator separately says Israel had sworn to the non-Israelite Amorite remnant and Saul sought to kill them in zeal for Israel/Judah.

David asks the Gibeonites what he should do and how to make atonement so they may bless LORD's inheritance. The causal mechanism between historic act, famine, atonement and later response is not supplied beyond the direct speech/narrator sequence.

## Verses 4–9 — “NOT FOR US TO KILL” / SEVEN DEATHS

The Gibeonites say it is not a silver/gold matter and **“neither is it for us to put any man to death in Israel.”** David promises to do whatever they say. They then ask for seven sons of Saul to be delivered so **they will hang them** before LORD. David agrees.

This closes new `S217-E001-2SA21`: **NOT FOR US TO PUT ANY MAN TO DEATH / GIVE US SEVEN / WE WILL HANG THEM / THEY PUT SEVEN TO DEATH.** No retraction or delegated-execution bridge is supplied. One post-closure YOINK changes nothing.

David spares Jonathan's son Mephibosheth because of the David/Jonathan LORD-oath. He takes Rizpah's two sons and Merab's five sons. The Gibeonites execute all seven together at barley-harvest beginning. Presentation remains non-graphic.

The act attributed by LORD/narrator belongs to Saul. No act by these seven men is supplied. Their descent supplies selection but no explicit guilt or liability-transfer rule. This closes repeated `S009-E002-2SA21`:

**SKIP -> S009-E001: ONE JOE'S ACT / DISTINCT JOES RECEIVE THE SANCTION.**

SKIP omits the already-addressed explanation only; selection, execution, mourning, burial and prayer response continue. One separate YOINK changes nothing.

## Verses 10–14 — RIZPAH / BONES / BURIAL / PRAYER RESPONSE

Rizpah spreads sackcloth on rock and prevents birds by day and field animals by night from reaching the remains, from harvest beginning until water pours from the sky. David is told.

David retrieves Saul and Jonathan's bones from Jabesh Gilead, whose men had taken them from Beth Shan after Philistine display. The seven men's bones are gathered too. Saul/Jonathan are buried in Kish's tomb in Benjamin; all David commanded is performed. Narrator then says God answered prayer for the land. The text does not specify which prayer, rainfall timing relation, body-exposure rule or physical mechanism; none is invented.

## Verses 15–22 — FOUR GIANT-DESCENDANT BATTLES

War resumes. David fights and grows faint. Ishbibenob, armed with a new sword and a three-hundred-shekel bronze spear, intends to kill David; Abishai helps David and kills him. David's men swear David must not battle again so Israel's lamp is not quenched. Future compliance remains unresolved.

At Gob, Sibbecai kills Saph. In another Gob battle, Elhanan kills Goliath the Gittite's brother, whose spear resembles a weaver's beam. At Gath, a large man with six fingers per hand and six toes per foot—twenty-four total—defies Israel; Jonathan son of Shimei kills him. Narrator groups the four as born to the giant in Gath and fallen by David's and servants' hands. The individual actors remain explicit; collective “hand” language is not rewritten into four David strikes.

## God-line boundary

Direct LORD speech supplies the famine attribution. Narrator says God answered prayer after burial. Gibeonites propose hanging before LORD; David's sparing follows a LORD-oath; the wise causal/moral mechanism beyond these exact relations remains unresolved. No divine body is rendered.

## Character and world-ledger changes

- NOT-DAVID seeks LORD, promises Gibeonite terms, selects seven while sparing oath-protected Mephibosheth, later orders collective burial, fights and grows faint.
- NOT-GIBEONITES move from death-denial to request and performance of seven executions.
- NOT-RIZPAH protects remains continuously until sky water and triggers David's reported response.
- Seven selected descendants die without retained individual offence.
- NOT-ABISHAI, NOT-SIBBECAI, NOT-ELHANAN and NOT-JONATHAN gain distinct giant-descendant kill acts.

## Bullshit pass

Issue `2SA-021 / WE DON'T DO DEATH — SEVEN-PERSON MINIMUM`. Crackhead Atonement Procurement rejects silver, gold and causal transfer documentation. The six-finger Joe receives a factory label: **TWENTY-FOUR DIGITS — COUNTED, NOT WARRANTED**. Foundation unchanged.

## FIR verification

- FILTER: all 22 markers retained; chapter 22 excluded.
- ISOLATE: famine attribution, negotiated atonement, seven deaths, Rizpah vigil, burial/prayer response and four battles.
- RECONSTRUCT: S217 closes on denial/request/performance; S009 closes separately on actor/sanction identity mismatch.
- VERIFY: one exact SKIP, two YOINKs, no inherited guilt or divine mechanism invented; publication held.

## Required compound-eye facets

1. Three-year famine/year after year.
2. David seeks LORD/direct famine attribution.
3. Gibeonite remnant/oath/Saul kill attempt narrator State.
4. David asks atonement/blessing terms.
5. No silver/gold / not for us to kill.
6. David whatever-you-say promise.
7. Seven-sons request/we will hang / David agrees.
8. `S217-E001` denial versus request/performance.
9. First separate YOINK.
10. Oath-protected Mephibosheth spared.
11. Rizpah two + Merab five selected.
12. Seven delivered/executed at harvest, restrained.
13. Saul act versus seven distinct sanctioned men; `S009-E002`.
14. Inert `SKIP -> S009-E001`.
15. Second separate YOINK.
16. Rizpah sackcloth vigil/birds/animals/rain.
17. David told / Saul-Jonathan bones retrieved.
18. Seven bones gathered / Kish-tomb burial / God answers prayer.
19. David faint / Ishbibenob threat / Abishai rescue / no-more-battle oath.
20. Sibbecai kills Saph.
21. Elhanan kills Goliath's brother / Jonathan kills 24-digit defier.
22. Four collective closing relation; chapter 22 excluded.

All twenty-two facets appear simultaneously.

## Production boundary

One high-resolution 22-facet compound-eye image. `NOT-` display; every living thing Joe-faced; executions/remains/battles restrained and non-graphic; no divine body. Exactly `S217-E001-2SA21` no SKIP and `S009-E002-2SA21` with inert `SKIP -> S009-E001`; exactly two separate causally-null post-closure YOINKs. Publication held; originator review required.

*shrug*

OK.
