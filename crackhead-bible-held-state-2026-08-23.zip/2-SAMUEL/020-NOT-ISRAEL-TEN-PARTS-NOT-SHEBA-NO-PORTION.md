# CRACKHEAD 2 SAMUEL 20

## Title field

**NOT-ISRAEL: WE HAVE TEN PARTS IN DAVID. / NOT-SHEBA AND ALL NOT-ISRAEL: WE HAVE NO PORTION IN DAVID.**

Source parent: ENGWEBP 2 Samuel chapter 20, verses 1-26, USFM. Prepared evidence: `.chapter-work/CHB-2SA-020/job.json` and `source.usfm`. Parent: 2 Samuel 19. Exact identities remain evidence; visible names use `NOT-`. Every living thing is Joe-faced. Killing and body aftermath remain restrained and non-graphic.

CrackFlix: new `S214-E001-2SA20`, `S215-E001-2SA20`, and `S216-E001-2SA20`; no SKIPs; exactly three separate causally-null post-closure YOINKs. One high-resolution compound-eye field.

## Causal foundation

```text
ISRAEL: TEN PARTS / MORE CLAIM IN DAVID
-> SHEBA: NO PORTION / NO INHERITANCE IN DAVID
-> ALL ISRAEL LEAVES DAVID AND FOLLOWS SHEBA
-> DAVID CONFINES TEN CONCUBINES UNTIL DEATH
-> AMASA MISSES THREE-DAY MUSTER
-> ABISHAI/JOAB FORCE PURSUES SHEBA
-> JOAB GREETS, GRASPS AND KILLS AMASA
-> BODY MOVED/COVERED / PURSUIT RESUMES
-> SHEBA REACHES ABEL / FORCE BESIEGES AND BATTERS WALL
-> WISE WOMAN: YOU SEEK TO DESTROY CITY
-> JOAB: FAR BE IT THAT I DESTROY
-> CITY DELIVERS SHEBA / JOAB DEPARTS
-> JOAB OVER ALL ISRAEL'S ARMY
```

## Verses 1–2 — TEN PARTS / NO PORTION

Israel's men just said they have ten parts in David and more claim than Judah. Sheba blows a trumpet and says Israel has no portion or inheritance in David. All Israel's men leave David and follow Sheba; Judah remains.

New `S214-E001-2SA20`: **TEN PARTS AND MORE CLAIM / NO PORTION OR INHERITANCE / SAME ISRAEL MEN FOLLOW.** No share transfer or scope change is supplied. One post-closure YOINK changes nothing.

## Verse 3 — TEN CONCUBINES

David returns, confines the ten concubines previously left as housekeepers, provides food, has no sexual relation with them and keeps them in living widowhood until death. Consent and legal agency remain unresolved; confinement is not relabelled by inference.

## Verses 4–13 — AMASA / JOAB

David orders Amasa to gather Judah within three days. Amasa exceeds the deadline. David predicts greater Sheba harm and sends Abishai's force; Joab's men and attached forces pursue.

At Gibeon's stone, Joab's sword falls. Joab asks if Amasa is well, grasps his beard as if to kiss him, then strikes once and kills him. Presentation is restrained. Joab and Abishai continue. People stop at Amasa's body until it is moved and covered; then all follow Joab.

David had sworn Amasa would be captain continually **instead of Joab** and now used Amasa for the muster. Joab kills Amasa; the chapter closes with Joab over all Israel's army. New `S215-E001-2SA20`: **AMASA CONTINUALLY INSTEAD OF JOAB / JOAB KILLS AMASA / JOAB OVER ALL ARMY.** No retraction or reappointment is supplied. One separate post-closure YOINK changes nothing.

## Verses 14–22 — WALL / DENIAL / DELIVERY

Pursuit reaches Abel Beth Maacah. Joab's force besieges Sheba, builds a mound and batters the wall to throw it down.

A wise woman calls Joab, cites Abel's counsel reputation, identifies herself as peaceful/faithful and says he seeks to destroy a mother-city and swallow LORD's inheritance. Joab says, **“Far be it … that I should swallow up or destroy.”** He demands Sheba and promises departure.

New `S216-E001-2SA20`: **FORCE BESIEGES AND BATTERS WALL DOWN / COMMANDER SAYS FAR BE IT THAT I DESTROY.** The later narrower demand and withdrawal do not erase the operating destruction process. One separate post-closure YOINK changes nothing.

The woman promises Sheba's head. City residents kill Sheba and throw his head over the wall. Joab blows the trumpet, disperses the force and returns. Presentation remains non-graphic; individual killers are unnamed.

## Verses 23–26 — ADMINISTRATION

Joab is over Israel's army; Benaiah over Cherethites/Pelethites; Adoram over forced labor; Jehoshaphat recorder; Sheva scribe; Zadok and Abiathar priests; Ira chief minister. These are office States, not merit claims.

## God-line boundary

No direct LORD speech, divine form or narrator-described divine act occurs. The wise woman calls the city LORD's inheritance; the phrase remains her speech carrier.

## Character and world-ledger changes

- NOT-SHEBA initiates secession, reaches Abel and is killed after negotiation.
- NOT-DAVID confines ten women and deploys Amasa then Abishai.
- NOT-AMASA misses the deadline and is killed; the continual command becomes impossible.
- NOT-JOAB kills Amasa, resumes command, besieges Abel, negotiates and withdraws.
- NOT-WISE-WOMAN halts wall destruction through Sheba delivery.

## Bullshit pass

Issue `2SA-020 / TEN PARTS MINUS TEN PARTS = NO PORTION`. Crackhead HR lists **CONTINUAL EMPLOYMENT — UNTIL YOUR REPLACEMENT STABS YOU**. City Maintenance labels the collapsing wall **NOT DESTRUCTION**. Foundation unchanged.

## FIR verification

- FILTER: all 26 markers retained; chapter 21 excluded.
- ISOLATE: secession, confinement, failed muster, Amasa death, pursuit, siege negotiation and offices.
- RECONSTRUCT: three completed mismatches; greeting/kiss is not separately forced into contradiction.
- VERIFY: three new series, zero SKIPs, three YOINKs; restrained violence; publication held.

## Required compound-eye facets

1. Prior ten-parts/more-claim State.
2. Sheba trumpet/no portion/no inheritance.
3. All Israel follows Sheba/Judah stays; `S214-E001`.
4. First separate YOINK.
5. Ten concubines confined/provided/no access/until death.
6. Amasa three-day order.
7. Amasa late.
8. David harm model/Abishai pursuit.
9. Joab force leaves.
10. Gibeon/sword falls.
11. Joab well-question/beard/kiss.
12. Joab kills Amasa, restrained.
13. Pursuit continues.
14. Follow-Joab call.
15. Body moved/covered/pursuit resumes.
16. Continual-Amasa versus Joab killing/end command; `S215-E001`.
17. Second separate YOINK.
18. Sheba route/gathering.
19. Abel siege/mound/wall battering.
20. Woman calls/Joab listens.
21. Abel counsel/peaceful-faithful claim.
22. You seek destroy/LORD inheritance.
23. Far-be-it denial; `S216-E001`.
24. Third separate YOINK.
25. Sheba demand/delivery/trumpet withdrawal, restrained.
26. Complete administration list; chapter 21 excluded.

All twenty-six facets appear simultaneously.

## Production boundary

One high-resolution 26-facet compound-eye image. `NOT-` display; every living thing Joe-faced; violence restrained/non-graphic; no divine body. Exactly three new episodes, no SKIP, exactly three separate causally-null post-closure YOINKs. Publication held; originator review required.

*shrug*

OK.
