# CRACKHEAD 2 SAMUEL 15

## Title field

**NOT-ABSALOM: WHAT CITY? / NOT-ABSALOM: YOUR CASE IS GOOD AND RIGHT.**

Source parent: 2 Samuel chapter 15, verses 1–37, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-015/job.json` and `source.usfm`. Parent: 2 Samuel 14. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Conspiracy, threatened violence, flight and grief remain restrained and non-graphic.

CrackFlix: new series `S211`, episode `S211-E001-2SA15`; no SKIP; one causally-null post-closure YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
ABSALOM BUILDS CHARIOT/HORSES/FIFTY RUNNERS
-> STANDS EARLY BESIDE JUDGMENT GATE
-> CALLS EACH LITIGANT / ASKS CITY
-> HEARS TRIBE/CITY ORIGIN ONLY
-> DECLARES MATTERS GOOD AND RIGHT / NO KING DEPUTY
-> WISHES TO BE JUDGE / PROMISES JUSTICE
-> INTERRUPTS BOWS WITH HAND/HOLD/KISS
-> REPEATS TO ALL KING-JUDGMENT ARRIVALS
-> NARRATOR: STEALS HEARTS OF ISRAEL MEN
-> REQUESTS HEBRON TRIP TO PAY LORD VOW
-> DAVID: GO IN PEACE
-> ABSALOM GOES HEBRON / SENDS TRUMPET-KING SPIES
-> TWO HUNDRED INVITED MEN GO WITHOUT KNOWLEDGE
-> ABSALOM SUMMONS AHITHOPHEL WHILE OFFERING SACRIFICES
-> CONSPIRACY STRENGTHENS / PEOPLE INCREASE
-> MESSENGER TELLS DAVID ISRAEL HEARTS AFTER ABSALOM
-> DAVID ORDERS IMMEDIATE FLIGHT
-> HOUSEHOLD/PEOPLE LEAVE / TEN CONCUBINES KEEP HOUSE
-> FOREIGN FORCE PASSES / DAVID OFFERS ITTAI RETURN
-> ITTAI SWEARS DEATH/LIFE LOYALTY / DAVID ACCEPTS
-> WEEPING CROSSING TO WILDERNESS
-> ZADOK/LEVITES/ABIATHAR BRING ARK
-> DAVID SENDS ARK/PRIESTS/SONS BACK AS INFORMATION ROUTE
-> DAVID ASCENDS OLIVES WEEPING/COVERED/BAREFOOT
-> AHITHOPHEL-CONSPIRATOR REPORT
-> DAVID ASKS LORD TO TURN COUNSEL FOOLISH
-> HUSHAI ARRIVES
-> DAVID SENDS HUSHAI BACK TO DEFEAT COUNSEL + REPORT THROUGH PRIESTS/SONS
-> HUSHAI AND ABSALOM ENTER JERUSALEM
```

## Verses 1–6 — CASE VERDICT BEFORE CASE EVIDENCE

Absalom prepares a chariot, horses and fifty runners. He rises early beside the gate route used by people bringing suits to the king. For each person, he asks what city they come from. The person answers only that he belongs to one of Israel's tribes. Absalom then declares the person's matters good and right and says nobody deputized by the king will hear them. He wishes to be judge so every suit or cause can come to him and he can do justice.

When anyone approaches to bow, Absalom reaches out, holds and kisses him. He repeats this to all Israel arriving for the king's judgment. Narrator says Absalom steals the hearts of Israel's men.

This closes new mental series `S211`, **I KNOW YOUR CASE IS RIGHT. I DON'T KNOW YOUR CASE.**

```text
LITIGANT HAS A SUIT OR CAUSE
ABSALOM ASKS ONLY CITY/TRIBE ORIGIN
NO SUIT FACTS, OTHER PARTY, EVIDENCE OR JUDGMENT ARE HEARD
ABSALOM: YOUR MATTERS ARE GOOD AND RIGHT
CLAIM EXCEEDS THE RETAINED EVIDENCE HE COLLECTED
```

No later case result is needed to locate this crack: it is in Absalom's asserted model. No litigant's case is declared bad, and no motive or sincerity is inferred. There is no prior episode, so there is no SKIP. One post-closure YOINK changes nothing.

## Verses 7–12 — VOW TRIP / KINGSHIP SIGNAL / CONSPIRACY

At the source-stated end of forty years, Absalom asks David for permission to go to Hebron and pay a LORD-vow. He reports that while in Geshur he vowed to serve LORD if LORD brought him again to Jerusalem. David says, “Go in peace,” and Absalom goes.

Absalom sends spies throughout Israel with a trumpet-triggered instruction to announce that Absalom is king in Hebron. Two hundred invited Jerusalem men accompany him in simplicity and know nothing. He summons David's counselor Ahithophel from Giloh while offering sacrifices. The conspiracy becomes strong and people continually increase with Absalom.

The sacrifices preserve the stated vow-performance carrier, while the covert kingship operation is an additional observed act. The request does not say “only,” and no narrator motive labels the vow false; therefore no false-pretext contradiction is invented. Absalom's reported LORD-return condition is not upgraded into narrator divine causation; 2 Samuel 14 retained Joab as the observable retrieval actor.

## Verses 13–18 — REPORT / DAVID'S FLIGHT

A messenger tells David the hearts of Israel's men are after Absalom. David tells his Jerusalem servants to flee immediately, predicting no escape if Absalom overtakes them and predicting evil and a sword strike on the city. Those outcomes remain David's prospective model; none occurs in this chapter.

Servants accept David's chosen act. David and his household leave, while ten concubines remain to keep the house. The king and people pause at Beth Merhak. Servants, Cherethites, Pelethites and six hundred Gittites from Gath pass before him.

## Verses 19–23 — ITTAI CHOOSES THE FLIGHT

David asks Ittai why he should join, calls him foreigner and exile, and tells him to return with his brothers rather than wander after arriving only yesterday. David wishes mercy and truth with him. Ittai swears by LORD and the living king that he will stay wherever David is, for death or life. David accepts: “Go and pass over.” Ittai, his men and their little ones cross.

The country weeps loudly. David and all the people cross Kidron toward the wilderness. David's initial return direction and later acceptance follow Ittai's intervening refusal/commitment, so no contradiction is created.

## Verses 24–29 — ARK RETURNS / HUMAN CONDITIONAL MODEL

Zadok, Levites and Abiathar carry and set down God's covenant ark while people leave the city. David orders Zadok to return the ark. He says that if he finds favor in LORD's eyes, LORD will bring him back and show him the ark and habitation; if LORD has no delight in him, David accepts whatever seems good to LORD.

These are David's conditional statements, not observed future divine outcomes. David sends Zadok, Abiathar and their sons Ahimaaz and Jonathan back as an information path while he waits at the wilderness fords. They carry the ark back to Jerusalem and stay there.

## Verses 30–37 — WEEPING ASCENT / PRAYER / COUNTER-COUNSEL NETWORK

David ascends the Mount of Olives weeping, barefoot and head-covered; the people do likewise. Someone reports Ahithophel among Absalom's conspirators. David asks LORD to turn Ahithophel's counsel into foolishness. No answer or counsel outcome occurs yet.

At the worship summit, Hushai meets David with torn tunic and earth on his head. David says Hushai would burden the moving group but can return, declare service to Absalom, defeat Ahithophel's counsel, and report palace information to Zadok and Abiathar. Their sons can carry everything heard to David. Hushai enters Jerusalem as Absalom also enters. No successful deception, defeated counsel or transmitted report is imported from chapter 16 or 17.

## Character and world-ledger changes

- NOT-ABSALOM gains gate access work, evidence-free good/right case verdicts, heart-stealing narrator State, Hebron vow/sacrifice carrier, covert king announcement and growing conspiracy.
- NOT-DAVID gains conspiracy report, immediate flight order, ten-concubine house assignment, Ittai release/acceptance, ark return, conditional LORD-favor speech, priest-son information route, prayer and Hushai counter-counsel plan.
- NOT-ITTAI gains explicit foreigner/exile State, death-or-life loyalty oath and crossing with men/little ones.
- NOT-ZADOK, NOT-ABIATHAR, NOT-AHIMAAZ and NOT-JONATHAN gain ark-return and information-carrier assignments.
- NOT-HUSHAI gains torn/earth mourning arrival and selected return/counter-counsel/report role; execution remains future.
- NOT-AHITHOPHEL joins Absalom's conspiracy from David's counselor relation; counsel content/outcome remains future.
- Two hundred invited men retain explicit lack of knowledge and are not classified as knowing conspirators.

## Bullshit pass

Issue `2SA-015 / CASE REVIEW WITHOUT CASE`. NOT-ABSALOM's Crackhead Court intake form contains one field: **CITY?** The automated result is **YOU ARE RIGHT**. Fifty runners carry the empty evidence folder directly past the actual court. Later, NOT-DAVID deploys a priest-to-son-to-wilderness messaging architecture labeled **CRACKHEAD ZERO TRUST, TRUST ALL THESE JOES**. Foundation unchanged.

## FIR verification

- FILTER: all 37 markers retained; 2 Samuel 16 excluded.
- ISOLATE: gate campaign, evidence-free merits claim, Hebron operation, conspiracy growth, David flight, Ittai choice, ark return and Hushai information plan.
- RECONSTRUCT: new S211 closes at claim/evidence mismatch; vow plus sacrifices prevents invented false-pretext closure; future predictions/prayer/plan remain unresolved.
- VERIFY: one new mental episode, no SKIP, one YOINK; publication held.

## Required compound-eye facets

1. Absalom chariot/horses/fifty runners.
2. Early gate position beside judgment route.
3. Litigant arrives with suit for king.
4. Absalom asks city / answer supplies tribe-origin only.
5. `S211-E001`: “Your matters are good and right” with empty case-evidence carrier.
6. “No king deputy hears you” / wish to be judge.
7. Promise to do justice to every arriving cause.
8. Bow interrupted by hand/hold/kiss.
9. Repetition to all / narrator says hearts stolen.
10. One mental-crack YOINK; Captain boilless and causally null; no SKIP.
11. Forty-year marker / Hebron vow-payment request.
12. Reported Geshur vow / conditional LORD return/serve speech.
13. David “Go in peace” / Absalom goes Hebron.
14. Spies + trumpet + “Absalom king in Hebron.”
15. Two hundred invited/uninformed men.
16. Ahithophel summoned while sacrifices offered.
17. Conspiracy strong / people continually increase.
18. Messenger: Israel hearts after Absalom.
19. David flee/hurry prediction; threatened sword visibly future.
20. Servants ready / household exits.
21. Ten concubines remain to keep house.
22. Beth Merhak pause / forces pass / six hundred Gittites.
23. David tells Ittai return: foreigner/exile/yesterday.
24. Ittai death-or-life oath.
25. David accepts / Ittai, men and little ones cross.
26. Country weeps / Kidron crossing / wilderness route.
27. Zadok/Levites/Abiathar bring/set ark while people pass.
28. David orders ark back / conditional favor-return speech.
29. Conditional no-delight/acceptance speech, human model only.
30. Zadok-seer / priests and sons return assignment.
31. David waits at wilderness fords for word.
32. Ark returns Jerusalem / priests stay.
33. Olives ascent: weeping, covered, barefoot.
34. Ahithophel conspiracy report / David prayer; outcome absent.
35. Hushai arrives at worship summit, torn tunic/earth.
36. Hushai return/servant-cover/counter-counsel plan.
37. Priests/sons report chain / Hushai and Absalom enter Jerusalem; chapter 16 excluded.

All thirty-seven facets appear simultaneously.

## Production boundary

One high-resolution 37-facet compound-eye image. `NOT-` display; every living thing Joe-faced; conspiracy, threat, flight and grief restrained/non-graphic; no divine body. New mental `S211-E001-2SA15`, no SKIP, exactly one causally-null post-closure YOINK. Preserve uninformed invitees, sacrifices alongside conspiracy, prospective predictions, human divine models, Ittai's intervening choice and unexecuted Hushai plan. Publication held; originator review required.

*shrug*

OK.
