# CRACKHEAD 2 SAMUEL 18

## Title field

**NOT-DAVID: DEAL GENTLY WITH NOT-ABSALOM. / NOT-JOAB: THREE DARTS.**

Source parent: ENGWEBP 2 Samuel chapter 18, verses 1-33, USFM. Prepared evidence: `.chapter-work/CHB-2SA-018/job.json` and `source.usfm`. Parent: 2 Samuel 17. Exact source identities remain in evidence; visible names use `NOT-`. Every living thing is Joe-faced. Battle and death remain restrained and non-graphic.

CrackFlix: new `S212-E001-2SA18`; repeated `S067-E005-2SA18` with inert `SKIP -> S067-E004-2SA13`; repeated `S186-E003-2SA18` with inert `SKIP -> S186-E002-1SA28`. Exactly three causally-null post-closure YOINKs. One high-resolution compound-eye field.

## Causal foundation

```text
DAVID COUNTS / APPOINTS / SENDS THREE FORCE DIVISIONS
-> PEOPLE REFUSE DAVID'S PARTICIPATION / DAVID AGREES / STAYS AT GATE
-> DAVID PUBLICLY COMMANDS THREE CAPTAINS: DEAL GENTLY WITH ABSALOM
-> OBSERVER RESTATES COMMAND: NO ONE TOUCH ABSALOM
-> BATTLE / 20,000 / FOREST OUTCOME
-> ABSALOM CAUGHT IN OAK / OBSERVER REPORTS / REFUSES REWARD TO STRIKE
-> JOAB THRUSTS THREE DARTS / TEN ARMOR BEARERS STRIKE AND KILL
-> TRUMPET / PURSUIT STOPS / PIT / STONE HEAP / FLIGHT
-> ABSALOM'S LIFETIME PILLAR SPEECH: I HAVE NO SON
-> RETAINED 2 SAMUEL 14 STATE: THREE SONS BORN TO ABSALOM
-> AHIMAAZ REQUESTS NEWS RUN / JOAB REFUSES TODAY / CUSHITE RUNS
-> AHIMAAZ REPEATS REQUEST / JOAB SAYS RUN / AHIMAAZ RUNS AND OUTRUNS
-> WATCHMAN REPORTS TWO RUNNERS
-> AHIMAAZ REPORTS VICTORY BUT NOT ABSALOM OUTCOME
-> CUSHITE REPORTS VICTORY AND INDICATES ABSALOM'S DEATH
-> DAVID WEEPS / WISHES HE DIED IN ABSALOM'S PLACE
```

## Verses 1–5 — FORCE AND PUBLIC COMMAND

David counts the people, appoints captains and sends thirds under Joab, Abishai and Ittai. He says he will go. The people say he must not because he is worth ten thousand; David agrees, remains beside the gate and watches the units leave.

David commands all three captains, audibly before all the people: **“Deal gently for my sake with the young man Absalom.”** The later observer restates the command as **“no one touch”** Absalom. The two phrasings remain distinct source speech.

## Verses 6–17 — COMMAND / KILLING

Battle spreads through Ephraim forest. Israel is defeated before David's servants; twenty thousand are reported killed, and narrator says the forest devoured more than the sword. The mechanism and exact allocation remain unresolved.

Absalom's head catches in an oak while his mule continues. A man reports him to Joab. Joab asks why the man did not strike him and offers a hypothetical reward. The man refuses even a larger hypothetical payment, cites the public no-touch command and says Joab would stand against him.

Joab takes three darts and thrusts them through the still-living Absalom. Ten armor bearers surround, strike and kill him. This closes new series `S212`:

```text
PUBLIC COMMAND: DEAL GENTLY / NO ONE TOUCH
COMMANDED CAPTAIN: THREE DARTS
CAPTAIN'S MEN: STRIKE AND KILL
```

No SKIP: first retained occurrence. Captain Crackhead arrives only after the killing completes, says **“YOINK!”**, pokes a boil, licks his finger and walks away without looking back. He changes nothing.

Joab blows the trumpet and stops pursuit. Absalom is placed in a forest pit beneath a stone heap; Israel flees to tents. Presentation remains non-graphic.

## Verse 18 — NO SON / THREE SONS

Narrator says Absalom had erected and named a pillar during his lifetime because he said, **“I have no son to keep my name in memory.”** Retained 2 Samuel 14:27 says three sons were born to Absalom. No death, disqualification, chronology bridge or alternate Absalom is supplied.

This is `S067-E005-2SA18`:

**SKIP -> S067-E004-2SA13: SCOPED CHILD CLASS DECLARED EMPTY WHILE RETAINED MEMBERS REMAIN.**

SKIP only points to the repeated contradiction; the pillar, speech, prior sons and later news continue. One separate post-closure YOINK changes nothing.

## Verses 19–23 — NO NEWS TODAY / RUN

Ahimaaz asks to run with news that LORD avenged the king of enemies. Joab says Ahimaaz must carry no news today because the king's son is dead, then sends the Cushite to report what he saw.

Ahimaaz asks again. Joab questions the unrewarded run. Ahimaaz repeats that he will run. Joab says, **“Run!”** Ahimaaz runs and overtakes the Cushite.

This is `S186-E003-2SA18`:

**SKIP -> S186-E002-1SA28: EXPLICIT REFUSAL / REPEATED REQUEST / REFUSED ACT PERFORMED.**

SKIP changes no causal history. One separate post-closure YOINK changes nothing.

## Verses 24–33 — TWO RUNNERS / TWO REPORTS / GRIEF

David sits between the gates. A watchman observes one runner, then another. David infers news; the watchman identifies the first runner's style as Ahimaaz. David calls Ahimaaz good and predicts good news.

Ahimaaz says all is well and attributes delivery from the raised hands to LORD. Asked about Absalom, he reports seeing tumult but not knowing its meaning, then stands aside.

The Cushite announces good news and attributes vengeance to LORD. Asked about Absalom, he answers by wishing the king's enemies become as that young man is. David understands the death, goes above the gate, weeps and repeatedly wishes he had died instead. Victory-news and son-death scopes remain together; the mixed report is not forced into another contradiction.

## God-line boundary

No direct LORD speech, divine body or narrator-described divine act occurs. Ahimaaz and the Cushite each attribute victory/vengeance to LORD. Their reports remain human attribution carriers; mechanism and independent verification are unresolved.

## Character and world-ledger changes

- NOT-DAVID organizes force, accepts gate position, issues the gentle-treatment command, receives two reports and enters grief.
- NOT-JOAB violates the public command, performs the three-dart act, stops pursuit, refuses then permits Ahimaaz's run.
- NOT-ABSALOM is caught, killed and buried beneath a stone heap; his pillar/no-son speech joins the retained three-son State.
- The unnamed observer refuses payment to strike and cites the command.
- NOT-AHIMAAZ and NOT-CUSHITE complete distinct news runs and reports.

## Bullshit pass

Issue `2SA-018 / GENTLE THREE-DART CUSTOMER CARE`. CrackFlix News Delivery says **NO NEWS TODAY** directly above the **RUN** button. The NOT-ABSALOM Memorial Child Count displays `0 (3 RETAINED)`. Foundation unchanged.

## FIR verification

- FILTER: all 33 verse markers retained; 2 Samuel 19 excluded.
- ISOLATE: force/battle, public command/kill, pillar/sons, messenger refusal/run, two reports and grief.
- RECONSTRUCT: three independently completed contradictions; no motive, divine mechanism, forest mechanism or chronology bridge invented.
- VERIFY: S212 new; S067 and S186 exact recurrences; two exact SKIPs; three separate YOINKs; publication held.

## Required compound-eye facets

1. David count/captains.
2. Three divisions under Joab/Abishai/Ittai.
3. David offers to go.
4. People refuse / worth ten thousand.
5. David agrees / gate / units pass.
6. Public “deal gently” command.
7. Battle in Ephraim forest.
8. Israel defeated / 20,000.
9. Forest-more-than-sword narrator State.
10. Absalom caught / mule continues.
11. Observer reports hanging.
12. Joab asks why no strike / reward offer.
13. Observer refuses / cites no-touch command.
14. Observer says Joab would oppose him.
15. Joab's three darts, restrained.
16. Ten armor bearers kill, restrained; `S212-E001` closes.
17. First separate post-closure YOINK; Captain boilless/causally null.
18. Trumpet / pursuit stops.
19. Pit / stone heap / tents, restrained.
20. Pillar and “no son.”
21. Retained three sons; `S067-E005`.
22. Inert `SKIP -> S067-E004-2SA13`.
23. Second separate post-closure YOINK.
24. Ahimaaz first request / Joab no-news-today refusal.
25. Cushite sent and runs.
26. Ahimaaz repeats / Joab permits / outruns; `S186-E003`.
27. Inert `SKIP -> S186-E002-1SA28`.
28. Third separate post-closure YOINK.
29. David/watchman first runner.
30. Second runner / Ahimaaz identification / good-news prediction.
31. Ahimaaz all-well/victory attribution/tumult-but-unknown/stands aside.
32. Cushite good-news attribution and Absalom-death indication.
33. David weeps and wishes substitution; chapter 19 excluded.

All thirty-three facets appear simultaneously.

## Production boundary

One high-resolution 33-facet compound-eye image. `NOT-` display; every living thing Joe-faced; battle/death restrained and non-graphic; no divine body. Exactly `S212-E001-2SA18`, `S067-E005-2SA18`, `S186-E003-2SA18`; exactly two inert SKIPs to the retained pointers; exactly three separate causally-null post-closure YOINKs. Publication held; originator review required.

*shrug*

OK.
