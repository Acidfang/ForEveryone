# CRACKHEAD 2 SAMUEL 6

## Title field

**NOT-UZZAH TOUCHED THE ARK. NOT-DAVID STOPPED. THEN NOT-DAVID BROUGHT IT UP.**

Source parent: 2 Samuel chapter 6, verses 1–23, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-006/job.json` and `source.usfm`. Parent: 2 Samuel 5. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Death, sacrifice, disability and marital conflict remain restrained and non-graphic.

CrackFlix: none. Zero SKIP, Captain and YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
DAVID GATHERS 30,000 / GOES FOR ARK
-> ARK SET ON NEW CART / UZZAH + AHIO DRIVE / MUSIC
-> CATTLE STUMBLE
-> UZZAH REACHES / HOLDS ARK
-> NARRATOR: LORD ANGER / GOD STRIKES FOR ERROR
-> UZZAH DIES
-> DAVID DISPLEASED / NAMES PEREZ UZZAH
-> DAVID AFRAID / ASKS HOW ARK COMES TO HIM
-> REFUSES CITY ROUTE / DIVERTS TO OBED-EDOM
-> THREE MONTHS / NARRATOR BLESSING
-> DAVID HEARS BLESSING REPORT
-> DAVID BRINGS ARK WITH JOY / BEARERS / SACRIFICE
-> DANCE / EPHOD / SHOUT / TRUMPET
-> MICHAL OBSERVES / DESPISES IN HEART
-> ARK SET IN TENT / OFFERINGS / BLESSING / FOOD DISTRIBUTION
-> DAVID RETURNS TO HOUSEHOLD
-> MICHAL ACCUSES UNCOVERING / DAVID RESPONDS
-> MICHAL HAS NO CHILD TO DEATH
```

## Verses 1–5 — FIRST TRANSPORT

David gathers thirty thousand chosen Israelite men and goes with the people from Baale Judah to bring up God's ark, named for LORD of Armies above the cherubim. They set it on a new cart from Abinadab's hill house. Uzzah and Ahio drive; Ahio walks before it. David and Israel play cypress instruments, harps, strings, tambourines, castanets and cymbals.

No visible divine/cherub body is rendered from the naming language. The cart, cattle and instruments can receive Joe-like faces only as wrong-context face objects; they are not thereby living unless source life is explicit.

## Verses 6–11 — TOUCH / DEATH / FEAR / DIVERSION

At Nacon's threshing floor cattle stumble. Uzzah reaches for and holds the ark. Narrator says LORD's anger burns, God strikes him for his error, and he dies beside the ark. The act, attribution and outcome are exact; Uzzah's motive and physical mechanism are absent.

David is displeased at the outbreak, names the place Perez Uzzah, becomes afraid and asks how the ark could come to him. He will not move it into David's city and carries it aside to Obed-Edom's house. It remains three months; narrator says LORD blesses Obed-Edom and all his house.

No contradiction closes: refusal is current route selection following death, not a universal future prohibition.

## Verses 12–19 — NEW REPORT / SECOND TRANSPORT / ARRIVAL / DISTRIBUTION

David is told LORD blessed Obed-Edom's house because of the ark. He then brings the ark to David's city with joy. The second occurrence names ark **bearers**, six paces, an ox/calf sacrifice, David dancing in a linen ephod, Israel shouting and trumpet sound. The source does not explain the cart-to-bearers process change.

Michal watches from a window, sees David leaping/dancing and despises him in her heart—an explicitly narrated private State, not an inference.

The ark is placed in David's prepared tent. David offers burnt/peace offerings, blesses people in LORD's name and gives every man and woman bread, dates and raisins. Everyone returns home. Offering and blessing mechanisms are not invented.

## Verses 20–23 — HOUSEHOLD ARGUMENT / CHILDLESS STATE

David returns to bless his household. Michal meets him and says the king gloriously uncovered himself before servants' maids like a vain fellow. David says he acted before LORD, who chose him above her father/house, and will celebrate; he says he will be more undignified/worthless in his own sight and the maids will honor him.

The source earlier says David wore a linen ephod but supplies no full garment geometry; Michal's “uncovered” statement is not disproved. The maids' future honor is not observed. Narrator closes that Michal had no child until death; no causal connector to the argument, biological mechanism or later death event is supplied.

## Character and world-ledger changes

- NOT-UZZAH closes living State through ark touch, narrator-attributed strike and death.
- NOT-DAVID gains first transport, displeasure/fear/diversion, report-triggered second transport, dance, offerings/distribution and household argument.
- NOT-OBED-EDOM and house gain three-month ark residence and narrator-attributed blessing State.
- NOT-MICHAL gains observed dance view, explicit despising-heart State, accusation dialogue and lifetime childless closure.
- NOT-AHIO, Israel, bearers, musicians and recipients gain exact transport/music/distribution acts.

## Bullshit pass

Issue `2SA-006 / NEW CART INCIDENT AND THREE-MONTH CANARY DEPLOYMENT`. The new cart hits instability; NOT-UZZAH touches production and dies. NOT-DAVID diverts the ark into NOT-OBED-EDOM's house for three months, receives a positive health report, then deploys again using bearers, six-step sacrifice checks and full-volume dancing. Foundation unchanged.

## FIR verification

- FILTER: all 23 markers retained; 2 Samuel 7 excluded.
- ISOLATE: first transport, touch/death, fear/diversion, blessing/report, second transport, arrival/distribution, Michal argument/childless State.
- RECONSTRUCT: changed route follows new evidence; garment claim remains unresolved; childlessness lacks supplied cause.
- VERIFY: zero contradiction/CrackFlix/SKIP/Captain/YOINK; publication held.

## Required compound-eye facets

1. 30,000 gathered / named ark retrieval.
2. New cart / Uzzah-Ahio / music.
3. Cattle stumble / Uzzah holds ark.
4. Narrator anger/strike/error / Uzzah death, restrained.
5. David displeased / Perez Uzzah name.
6. David fear/question / refuses city route.
7. Obed-Edom diversion / three months / narrator blessing.
8. Blessing report reaches David.
9. Second transport with bearers / six paces / sacrifice.
10. David ephod dance / Israel shout/trumpet.
11. Michal window observation / narrated heart State.
12. Ark tent placement / offerings / blessing.
13. Bread/date/raisin distribution / people depart.
14. David returns to bless household.
15. Michal uncovered/glory accusation.
16. David selection/celebration/undignified/future-honor reply.
17. Michal childless-to-death State / cause unresolved / chapter 7 excluded.

All seventeen facets appear simultaneously.

## Production boundary

One high-resolution 17-facet compound-eye image. `NOT-` display; living things Joe-faced; death/sacrifice/disability/conflict restrained; divine/cherub form unrendered. Zero contradiction/CrackFlix/SKIP/Captain/YOINK. Preserve first/second transports, narrator attributions, David changed State, Michal explicit heart State, garment uncertainty and causally unlinked childlessness. Publication held; originator review required.

*shrug*

OK.
