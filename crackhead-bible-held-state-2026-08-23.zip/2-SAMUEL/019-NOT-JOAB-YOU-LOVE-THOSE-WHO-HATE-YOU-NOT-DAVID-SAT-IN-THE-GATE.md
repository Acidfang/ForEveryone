# CRACKHEAD 2 SAMUEL 19

## Title field

**NOT-JOAB: YOU LOVE THOSE WHO HATE YOU. / NOT-DAVID: WEEPS, THEN SITS IN THE GATE.**

Source parent: ENGWEBP 2 Samuel chapter 19, verses 1-43, USFM. Prepared evidence: `.chapter-work/CHB-2SA-019/job.json` and `source.usfm`. Parent: 2 Samuel 18. Exact source identities remain in evidence; visible names use `NOT-`. Every living thing is Joe-faced.

CrackFlix: repeated mental `S154-E006-2SA19` with inert `SKIP -> S154-E005-1SA17`; new unresolved-account `S213-E001-2SA19` with no SKIP. Exactly two separate causally-null post-closure YOINKs. One high-resolution compound-eye field.

## Causal foundation

```text
DAVID WEEPS FOR ABSALOM
-> VICTORY BECOMES PUBLIC MOURNING / PEOPLE ENTER ASHAMED
-> JOAB ASSERTS DAVID LOVES HATERS, HATES LOVERS, PREFERS ABSALOM-LIVE/ALL-SERVANTS-DEAD
-> JOAB ORDERS GATE APPEARANCE / PREDICTS DESERTION
-> DAVID SITS AT GATE / PEOPLE RETURN BEFORE HIM
-> ISRAEL DEBATES RESTORING DAVID
-> DAVID USES PRIESTS TO ADDRESS JUDAH / PROMISES AMASA JOAB'S COMMAND
-> JUDAH INVITES RETURN / DAVID REACHES JORDAN
-> SHIMEI CONFESSES / ABISHAI REQUESTS DEATH / DAVID REFUSES AND SWEARS LIFE
-> MEPHIBOSHETH ARRIVES WITH NEGLECTED GROOMING/CLOTHING
-> DAVID ASKS WHY HE DID NOT COME
-> MEPHIBOSHETH: ZIBA DECEIVED AND SLANDERED ME; I INTENDED TO RIDE WITH KING
-> RETAINED ZIBA: MEPHIBOSHETH STAYED FOR EXPECTED KINGDOM
-> DAVID DIVIDES LAND / MEPHIBOSHETH YIELDS ALL
-> BARZILLAI ESCORTS / REFUSES JERUSALEM REWARD / SENDS CHIMHAM
-> KING ACCEPTS / CROSSING / FAREWELL
-> JUDAH AND ISRAEL DISPUTE WHO HAD GREATER RETURN CLAIM
```

## Verses 1–8 — GRIEF / JOAB'S MIND MODEL / GATE

Joab is told David weeps for Absalom. The people hear the king grieves; victory becomes mourning, people enter covertly as if ashamed, and David covers his face and cries for his son.

Joab says David shamed servants who saved the royal household. He then asserts David **loves those who hate him**, **hates those who love him**, regards princes and servants as nothing, and would be pleased if Absalom lived while everyone else died. David has expressed grief; no statement or other carrier supplies those private love, hate or hypothetical-preference States.

This closes `S154-E006-2SA19`:

**SKIP -> S154-E005-1SA17: OBSERVED ACT USED TO ASSERT UNOBSERVED PRIVATE FEELING/INTENT AS FACT.**

Joab orders David to comfort the servants and swears by LORD that otherwise no man will remain that night. David arises and sits at the gate; people come before him. The threatened departure does not occur. One post-closure YOINK changes nothing.

## Verses 9–15 — RESTORATION ROUTE

Israel's tribes dispute restoration: they remember David's prior deliverance, their own anointing of now-dead Absalom, and ask why David is not brought back. David sends through Zadok and Abiathar to Judah's elders, calls them bone and flesh, and promises Amasa continual army command instead of Joab. Judah answers as one man and invites David and servants to return. David reaches Jordan; Judah reaches Gilgal to conduct the crossing. The narrator's bowed-heart phrase retains its human-message carrier; mechanism beyond the delivered appeal is unresolved.

## Verses 16–23 — SHIMEI CONFESSES / DAVID SWEARS LIFE

Shimei arrives with a thousand Benjaminites; Ziba, fifteen sons and twenty servants cross before the king, and a ferry carries the household. Shimei falls down, asks David not to remember his prior perversity, says he knows he sinned, and identifies himself as first from Joseph's house to meet the king.

Abishai again proposes Shimei's death for cursing LORD's anointed. David refuses any execution that day, says he knows he is king, tells Shimei he will not die and swears it. This is a changed public relation after confession, not a contradiction. Any later act must retain this oath as parent.

## Verses 24–30 — TWO INCOMPATIBLE DEPARTURE ACCOUNTS

Mephibosheth arrives with feet, beard and clothes ungroomed/unwashed since David departed. Asked why he did not go, he says his servant deceived him: because he is lame, he intended a donkey to be saddled so he could ride with David, but Ziba slandered him.

Retained 2 Samuel 16 records Ziba saying Mephibosheth stayed in Jerusalem expecting Israel to restore Saul's kingdom to him. The accounts assign incompatible intention and action to the same absence. Neither supplies an independent preparation, refusal, witness or other resolution carrier.

This closes new `S213-E001-2SA19`:

```text
ZIBA: HE STAYED FOR THE KINGDOM
MEPHIBOSHETH: I PREPARED TO GO; ZIBA DECEIVED AND SLANDERED ME
SAME ABSENCE / INCOMPATIBLE ACCOUNTS / TRUTH UNRESOLVED
```

No SKIP. Captain attends the mismatch only after both accounts exist; one separate YOINK changes nothing.

Mephibosheth calls David like an angel of God and yields judgment. David orders Ziba and Mephibosheth to divide the land. Mephibosheth says Ziba may take all because David returned peacefully. The property result is completed; account truth remains unresolved.

## Verses 31–40 — BARZILLAI / CHIMHAM / CROSSING

Eighty-year-old Barzillai, who supplied David at Mahanaim, escorts him over Jordan. David offers Jerusalem support. Barzillai declines, citing age, diminished discernment/taste/hearing and desire to die near his parents' grave; he proposes Chimham instead. David accepts Chimham and any further request. Everyone crosses; David kisses and blesses Barzillai, who returns home. Chimham continues with David to Gilgal. Offer, refusal, substitute and acceptance agree.

## Verses 41–43 — RETURN-CLAIM DISPUTE

Israel asks why Judah “stole” the king's crossing. Judah answers kinship and denies consuming royal cost or receiving gifts. Israel claims ten shares and a greater right, asking why its advice was not first. Judah's words are fiercer. These are competing political claims and questions; no completed allocation rule or independent entitlement result exists, so no contradiction is manufactured.

## God-line boundary

No direct LORD speech, divine form or narrator-described divine act occurs. Joab swears by LORD; Abishai calls David LORD's anointed; David invokes God in the Amasa oath; Mephibosheth compares David to an angel of God. All remain human speech carriers.

## Character and world-ledger changes

- NOT-DAVID moves from public grief to gate appearance, begins restoration, swears Shimei will live, divides disputed land, and crosses Jordan.
- NOT-JOAB gains the S154 private-feeling model and is named as the commander Amasa is promised to replace.
- NOT-SHIMEI confesses and receives a sworn life assurance.
- NOT-ZIBA and NOT-MEPHIBOSHETH now carry incompatible departure accounts; neither is adjudicated true.
- NOT-BARZILLAI refuses royal support; NOT-CHIMHAM crosses in his place.
- Judah and Israel retain an unresolved restoration-credit dispute.

## Bullshit pass

Issue `2SA-019 / ROYAL FEELINGS DETECTOR — NO SENSOR INCLUDED`. CrackFlix Property Court resolves two incompatible accounts by cutting the land slider in half. Jordan Ferry accepts payment in **TEN PARTS OF KING**. Foundation unchanged.

## FIR verification

- FILTER: all 43 markers retained; 2 Samuel 20 excluded.
- ISOLATE: grief/gate, restoration, Shimei oath, incompatible Ziba/Mephibosheth accounts, Barzillai substitution and tribal dispute.
- RECONSTRUCT: S154 closes only on unsupported private-State assertions; S213 retains both accounts and unresolved truth.
- VERIFY: one exact SKIP; two separate YOINKs; no later Shimei outcome imported; publication held.

## Required compound-eye facets

1. Joab told king weeps.
2. Victory becomes mourning.
3. People enter ashamed.
4. David covered-face cry.
5. Joab saved-household/shamed-servants speech.
6. Joab love-haters/hate-lovers assertion.
7. Joab nothing/all-dead preference assertion; `S154-E006` closes.
8. Inert `SKIP -> S154-E005-1SA17`.
9. First separate post-closure YOINK.
10. Joab gate order/LORD oath/desertion prediction.
11. David sits gate / people return.
12. Israel tribal restoration debate.
13. Absalom anointed/dead / bring David back question.
14. David priest-to-Judah message.
15. Bone/flesh appeal.
16. Amasa promised command instead of Joab.
17. Judah one-heart invitation.
18. David Jordan / Judah Gilgal.
19. Shimei/1000 Benjamin/Ziba household arrival.
20. Ferry and Shimei prostration.
21. Shimei asks non-imputation/remembrance.
22. Shimei confession/first Joseph-house claim.
23. Abishai death request.
24. David no-death-today refusal/king claim.
25. David sworn “you will not die.”
26. Mephibosheth neglected grooming/clothes.
27. David asks why absent.
28. Mephibosheth intended donkey/ride account.
29. Mephibosheth deception/slander claim.
30. Retained Ziba kingdom-wait account; `S213-E001` closes unresolved.
31. Second separate post-closure YOINK; no SKIP.
32. Angel comparison/dead-house/table appeal.
33. David divides land.
34. Mephibosheth yields all/peace return.
35. Barzillai escorts / age / prior support.
36. David Jerusalem support offer.
37. Barzillai age/taste/hearing/burden refusal.
38. Barzillai own-city/grave request / Chimham substitute.
39. David accepts Chimham/future requests.
40. Collective crossing / kiss / blessing / Barzillai return.
41. David/Chimham/Judah/half-Israel cross.
42. Israel accuses Judah / Judah kinship and no-gift response.
43. Israel ten-part claim / Judah fiercer; chapter 20 excluded.

All forty-three facets appear simultaneously.

## Production boundary

One high-resolution 43-facet compound-eye image. `NOT-` display; every living thing Joe-faced; no divine body. Exactly `S154-E006-2SA19` with inert `SKIP -> S154-E005-1SA17`; exactly new `S213-E001-2SA19` with no SKIP; exactly two separate causally-null post-closure YOINKs. Conflicting reports remain unresolved. Publication held; originator review required.

*shrug*

OK.
