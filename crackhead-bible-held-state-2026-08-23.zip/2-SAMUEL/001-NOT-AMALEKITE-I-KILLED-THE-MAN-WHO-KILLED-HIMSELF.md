# CRACKHEAD 2 SAMUEL 1

## Title field

**NOT-AMALEKITE: I KILLED NOT-SAUL. NOT-SAUL HAD ALREADY KILLED HIMSELF.**

Source parent: 2 Samuel chapter 1, verses 1–27, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-001/job.json` and `source.usfm`. Parent: 1 Samuel 31. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Death, execution and battlefield imagery remain restrained and non-graphic.

CrackFlix: new `S204-E001-2SA1`. No SKIP: this is the first retained occurrence in the series. Exactly one causally-null post-closure YOINK.

Production format: one high-resolution compound-eye field with all changed States simultaneous and addressed causal traversal.

## Causal foundation

```text
1 SAMUEL 31 RETAINED: SAUL FALLS ON OWN SWORD / DIES
-> DAVID RETURNS FROM AMALEKITE SLAUGHTER / STAYS TWO DAYS
-> THIRD DAY MAN ARRIVES FROM SAUL CAMP WITH TORN CLOTHES / EARTH
-> MAN SAYS HE ESCAPED ISRAEL CAMP
-> MAN REPORTS FLIGHT / DEATHS / SAUL + JONATHAN DEAD
-> DAVID ASKS HOW HE KNOWS
-> MAN REPORTS SAUL ALIVE AFTER FALL / REQUESTING DEATH
-> MAN SAYS HE KILLED SAUL
-> MAN PRESENTS CROWN + BRACELET
-> DAVID + MEN TEAR CLOTHES / MOURN / WEEP / FAST
-> MAN IDENTIFIES AS FOREIGNER'S SON / AMALEKITE
-> DAVID ASKS WHY HE WAS NOT AFRAID TO DESTROY LORD'S ANOINTED
-> DAVID ORDERS YOUNG MAN CUT DOWN
-> YOUNG MAN STRIKES / MAN DIES
-> DAVID: YOUR MOUTH TESTIFIED AGAINST YOU
-> DAVID LAMENTS SAUL + JONATHAN
-> COMMANDS JUDAH LEARN SONG OF BOW
-> LAMENT IS PERFORMED / BOOK OF JASHAR ATTRIBUTED
```

## Verses 1–4 — ARRIVAL / BATTLE REPORT

After Saul's death and David's return from striking Amalekites, David stays two days at Ziklag. On the third day a man arrives from Saul's camp with torn clothes and earth on his head, falls before David and shows respect.

The man says he escaped Israel's camp. Asked how it went, he reports flight, many fallen/dead, and Saul and Jonathan dead. The report overlaps retained chapter 31 outcomes but does not establish how the man learned them.

## Verses 5–10 — TWO INCOMPATIBLE DEATH ACCOUNTS

David asks how the man knows Saul and Jonathan are dead. The man says he happened on Gilboa, saw Saul leaning on his spear with chariots and horsemen close, answered Saul's call, identified himself as an Amalekite, heard Saul request death, stood beside him and killed him because he was sure Saul could not live after falling. He says he removed Saul's crown and bracelet and brought them to David.

Retained 1 Samuel 31 narration says Saul fell on his own sword and died, and the armor-bearer acted after seeing Saul dead. The arriving man's statement says Saul remained alive after the fall and that the man killed him. `S204-E001-2SA1` closes at the exact incompatible completed-act relation:

```text
RETAINED NARRATION: SAUL SELF-SWORD -> SAUL DEAD
ARRIVING CLAIM: SAUL ALIVE AFTER FALL -> I KILLED SAUL
```

The crown and bracelet support possession of those objects, not the asserted killing act. The source does not label the statement true, false, mistaken, staged or witnessed. No motive is invented. First occurrence: no SKIP. Captain's separate post-closure YOINK changes nothing.

## Verses 11–16 — MOURNING / TESTIMONY / EXECUTION

David tears his clothes and all men with him do likewise. They mourn, weep and fast until evening for Saul, Jonathan, the LORD's people and Israel's house because they fell by the sword.

The man identifies himself as the son of a foreigner, an Amalekite. David asks why he was not afraid to destroy the LORD's anointed, calls a young man and orders him cut down. The young man strikes him and he dies. David says the man's blood is on his own head because his own mouth testified, “I have slain the LORD's anointed.”

David's stated evidentiary basis is the man's own claim. The chapter does not supply an inquiry reconciling that claim with the retained self-sword narration. The execution is observed; guilt beyond the stated testimony route is not independently inferred.

## Verses 17–27 — LAMENT / TEACHING / RETAINED SPEECH

David laments Saul and Jonathan and commands Judah's children be taught the Song of the Bow, attributed as written in the Book of Jashar.

The lament addresses Israel, Gath, Ashkelon, Gilboa, daughters of Philistines and Israel, and Jonathan. It says the mighty fell, asks that the news not be told/published in Philistine cities, calls for no dew/rain/offerings on Gilboa, praises Saul's and Jonathan's weapons and qualities, says they were not divided in death, describes Saul's gifts to Israel's daughters, and states David's distress and Jonathan's wonderful love.

These are the words of a performed lament. The source does not observe weather obeying, news being suppressed, daughters reacting, teaching completion, or every poetic comparison as an external event. No extra contradiction or physical mechanism is manufactured.

## Character and world-ledger changes

- NOT-DAVID gains report receipt, mourning/fasting, testimony-based execution order, lament performance and teaching command.
- NOT-AMALEKITE-MESSENGER gains arrival, camp-escape claim, incompatible Saul-killing claim, crown/bracelet delivery, foreigner's-son identity and executed death.
- NOT-YOUNG-MAN gains completed execution act under David's order.
- NOT-SAUL and NOT-JONATHAN remain dead parent States; the messenger's account does not rewrite their retained death lineage.
- Judah's children gain an instruction to learn the song; completion remains unresolved.

## Bullshit pass

Issue `2SA-001 / CLAIM-BASED TERMINATION REVIEW`. NOT-AMALEKITE arrives with the executive accessories and files **I PERFORMED THE SHUTDOWN** against a retained log showing **LOCAL SELF-SHUTDOWN ALREADY COMPLETE**. NOT-DAVID accepts the confession as the ticket's own approval signature and terminates the reporter. CrackFlix stores both death ledgers. Foundation unchanged.

## FIR verification

- FILTER: all 27 markers retained; 2 Samuel 2 excluded.
- ISOLATE: return/timing, messenger arrival/report, incompatible death accounts, object delivery, mourning, identity, execution, lament and teaching command.
- RECONSTRUCT: object possession does not verify killing; execution basis is David's stated use of the man's own testimony; lament remains performed speech.
- VERIFY: one new episode, no SKIP, one YOINK; motive/truth/weather/teaching effects unresolved; publication held.

## Required compound-eye facets

1. Retained 1 Samuel 31: NOT-SAUL self-sword act and death, restrained.
2. NOT-DAVID returns from Amalekites / two days at Ziklag / third-day arrival.
3. Torn-clothes/earth messenger falls and shows respect.
4. Escape claim / flight and death report / Saul and Jonathan reported dead.
5. David asks how he knows.
6. Messenger's Gilboa account: Saul alive after fall / request / claimed killing.
7. Crown and bracelet delivered; possession does not verify killing.
8. `S204-E001`: retained self-death beside claimed messenger killing; exact mismatch.
9. No SKIP; one separate causally-null post-closure Captain YOINK.
10. David and men tear clothes / mourn / weep / fast until evening.
11. Messenger identifies as foreigner's son / Amalekite.
12. David asks why not afraid / orders young man cut him down.
13. Young man strikes / messenger dies, restrained.
14. David states mouth/testimony basis; no independent reconciliation shown.
15. Lament over Saul/Jonathan / Song of Bow teaching command / Book of Jashar attribution.
16. Lament speech field: mighty fallen, cities, Gilboa, weapons, daughters, Jonathan; effects unexecuted.
17. 2 Samuel 1 held; 2 Samuel 2 excluded.

All seventeen facets appear simultaneously in one zoomable compound-eye image.

## Production boundary

One high-resolution compound-eye image with 17 facets. `NOT-` display; every living thing Joe-faced; death/execution/battle restrained and non-graphic; no divine form. `S204-E001-2SA1`, no SKIP, exactly one separate causally-null post-closure YOINK. Preserve narrator account and messenger claim separately; crown/bracelet prove possession only; David's stated testimony route exact; lament as performed speech with effects unresolved. Originator review required; publication held.

*shrug*

OK.
