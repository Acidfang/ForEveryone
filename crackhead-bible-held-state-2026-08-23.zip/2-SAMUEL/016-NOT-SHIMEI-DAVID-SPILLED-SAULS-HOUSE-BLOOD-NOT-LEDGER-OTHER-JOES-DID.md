# CRACKHEAD 2 SAMUEL 16

## Title field

**NOT-SHIMEI: DAVID SPILLED SAUL'S HOUSE BLOOD. / NOT-LEDGER: OTHER JOES DID.**

Source parent: 2 Samuel chapter 16, verses 1–23, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-2SA-016/job.json` and `source.usfm`. Parent: 2 Samuel 15. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Cursing, stones, threatened beheading and sexual acts remain restrained and non-graphic.

CrackFlix: `S112-E002-2SA16`, with inert `SKIP -> S112-E001-NUM16`; one causally-null post-closure YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
ZIBA MEETS DAVID WITH DONKEYS/FOOD/WINE
-> ZIBA ASSIGNS SUPPLY USES
-> DAVID ASKS MEPHIBOSHETH LOCATION
-> ZIBA REPORTS JERUSALEM + KINGDOM-RESTORATION SPEECH
-> DAVID TRANSFERS MEPHIBOSHETH PROPERTY TO ZIBA
-> SHIMEI CURSES/THROWS STONES/DUST
-> SHIMEI ASSIGNS SAUL-HOUSE BLOOD + KINGDOM LOSS TO DAVID/LORD
-> ABISHAI REQUESTS BEHEADING
-> DAVID REFUSES / ATTRIBUTES CURSE INVITATION TO LORD / HOPES FOR GOOD
-> SHIMEI CONTINUES WHILE GROUP TRAVELS
-> DAVID/GROUP ARRIVE WEARY / REFRESH
-> ABSALOM/ISRAEL/AHITHOPHEL ENTER JERUSALEM
-> HUSHAI HAILS KING
-> ABSALOM QUESTIONS FRIEND-LOYALTY
-> HUSHAI DELIVERS SELECTED-SERVICE COVER
-> ABSALOM REQUESTS AHITHOPHEL COUNSEL
-> AHITHOPHEL ADVISES PUBLIC SEX WITH TEN CONCUBINES
-> ROOFTOP TENT / ABSALOM HAS SEX WITH CONCUBINES IN ISRAEL SIGHT
-> NARRATOR DESCRIBES AHITHOPHEL COUNSEL REPUTATION
```

## Verses 1–4 — ZIBA'S SUPPLIES / REPORT / PROPERTY TRANSFER

Ziba meets David just beyond the summit with two saddled donkeys, two hundred loaves, one hundred raisin clusters, one hundred summer fruits and wine. He assigns donkeys to the household, food to young men and wine to faint wilderness travelers.

Asked where his master's son is, Ziba says Mephibosheth remains in Jerusalem and reports Mephibosheth saying Israel will restore Saul's kingdom to him that day. David immediately gives Ziba everything belonging to Mephibosheth; Ziba bows and asks favor.

The location, quoted speech and disloyalty implication remain Ziba's report. Mephibosheth is absent and no independent verification occurs here. David's transfer is complete, but report truth and property legitimacy remain unresolved until later evidence; no contradiction is manufactured yet.

## Verses 5–8 — SHIMEI REASSIGNS THE BLOOD

At Bahurim, Shimei of Saul's family comes out cursing. He throws stones at David and the servants while people and mighty men surround David. Shimei calls David a bloody, wicked man and says LORD returned on David all the blood of Saul's house, delivered the kingdom to Absalom and caught David in his own evil.

This is `S112-E002-2SA16`:

```text
RETAINED SAUL-HOUSE DEATH CHAINS:
SAUL FALLS ON HIS OWN SWORD
ABNER IS KILLED BY JOAB
ISHBOSHETH IS KILLED BY BAANAH AND RECHAB
DAVID PUNISHES CLAIMED/PERFORMING KILLERS

SHIMEI: LORD RETURNED ALL SAUL-HOUSE BLOOD ON DAVID
CLAIM REASSIGNS COMPLETED CAUSAL CHAINS TO DAVID WITHOUT A TRANSFER CARRIER
```

It repeats `S112-E001-NUM16`, where narrated earth/LORD-fire deaths were reassigned to Moses and Aaron.

**SKIP -> S112-E001-NUM16: THE OBSERVED CAUSE DID IT. YOU DID IT.**

SKIP removes nothing. Shimei's wider moral category, unknown evidence and private belief remain unresolved; the crack is only the causal reassignment exceeding retained acts. One post-closure YOINK changes nothing.

## Verses 9–14 — BEHEADING REFUSED / CURSING CONTINUES

Abishai calls Shimei a dead dog and asks permission to remove his head. David rejects the sons of Zeruiah intervention. He says that because Shimei curses and because LORD said “Curse David,” nobody can ask why; he compares the threat from his own son and tells them to leave Shimei alone. David says LORD may see his wrong and repay good for that day's curse.

The narrator does not record LORD instructing Shimei. David's invitation and hoped repayment remain David's interpretations, not direct divine speech or outcome. Shimei continues along the opposite hillside cursing, throwing stones and dust. David and his people arrive weary and refresh themselves.

## Verses 15–19 — HUSHAI PERFORMS THE COVER

Absalom, Israel and Ahithophel enter Jerusalem. Hushai, still narrator-identified as David's friend, greets Absalom twice with “Long live the king.” Absalom asks whether this is kindness to his friend and why Hushai did not go with him.

Hushai says he will belong to and remain with the person LORD, the people and Israel chose, and asks whether he should serve the son as he served the father. This performs the cover speech David explicitly designed in 2 Samuel 15. The chapter does not say Absalom accepts, rejects or detects it. Hushai's actual retained David-friend/mission parent is not erased by the performed words.

## Verses 20–23 — AHITHOPHEL'S COUNSEL / PUBLIC ROOFTOP ACT

Absalom asks Ahithophel what to do. Ahithophel advises sex with the ten concubines David left to keep the house, predicting Israel will hear David abhors Absalom and supporters' hands will strengthen. A tent is spread on the roof; Absalom has sex with the concubines in the sight of all Israel. Consent is not supplied and is not invented; presentation remains restrained.

The observable public-house act matches the shape of Nathan's carried LORD speech in 2 Samuel 12 about David's house/wives being given to a neighbor before Israel and the sun. This chapter does not narrate LORD causing Ahithophel's counsel, Absalom's act or public visibility; correspondence is retained without invented mechanism.

Narrator says Ahithophel's counsel in those days was treated like inquiry at God's inner sanctuary by both David and Absalom. This is a counsel-reputation comparison, not proof of divine origin, infallibility or every counsel's correctness.

## Character and world-ledger changes

- NOT-ZIBA gains supply delivery, Mephibosheth location/kingdom speech report and receipt of David's total property transfer.
- NOT-MEPHIBOSHETH remains absent; his location/speech/loyalty are reported only and not adopted as fact.
- NOT-SHIMEI gains cursing, stone/dust throwing and S112 causal-reassignment speech.
- NOT-DAVID gains property-transfer judgment, refusal of Abishai's beheading request, human divine-attribution/hope speech and weary refresh State.
- NOT-HUSHAI begins the retained counter-counsel cover by performing service speech to Absalom; acceptance/effect remains unresolved.
- NOT-AHITHOPHEL gains public-concubine counsel; NOT-ABSALOM executes it.
- ten unnamed concubines remain living people and are not reduced to objects; consent/private State unresolved.

## Bullshit pass

Issue `2SA-016 / ONE-SIDED ASSET-TRANSFER HELP DESK`. NOT-ZIBA brings snacks and one allegation; NOT-DAVID presses **TRANSFER ALL** before the other account logs in. Across the road, NOT-SHIMEI opens Crackhead Causation Analytics and drags every Saul-house death onto DAVID. **SKIP -> S112-E001-NUM16.** Foundation unchanged.

## FIR verification

- FILTER: all 23 markers retained; 2 Samuel 17 excluded.
- ISOLATE: Ziba report/transfer, Shimei acts/causal model, David refusal/interpretation, Hushai cover and Ahithophel counsel/execution.
- RECONSTRUCT: S112 recurrence closes at causal reassignment; Ziba truth, divine invitation/repayment and counsel divinity remain unresolved claim types.
- VERIFY: one repeated episode, exact SKIP pointer, one YOINK; sensitive content restrained; publication held.

## Required compound-eye facets

1. Ziba meets David with saddled donkeys and exact supplies.
2. Ziba assigns ride/food/wine uses.
3. David asks Mephibosheth location.
4. Ziba reports Jerusalem and kingdom-restoration speech.
5. David transfers all Mephibosheth property / Ziba bows.
6. Shimei emerges cursing at Bahurim.
7. Stones thrown at David/servants amid surrounding force.
8. Shimei bloody/wicked/Saul-house blood speech.
9. `S112-E002`: retained other-actor death chains versus David reassignment.
10. `SKIP -> S112-E001-NUM16`, inert and noncausal.
11. One separate post-closure YOINK; Captain boilless and causally null.
12. Abishai requests beheading; visibly unperformed.
13. David refuses and attributes curse invitation to LORD as human speech.
14. David son comparison / possible good repayment model.
15. Shimei continues stones/dust/cursing while group travels.
16. Weary arrival and refresh.
17. Absalom/Israel/Ahithophel enter Jerusalem.
18. Hushai twice hails king / Absalom questions kindness.
19. Hushai LORD/people/Israel-choice and father-to-son service cover.
20. Absalom requests Ahithophel counsel.
21. Counsel: ten concubines/public abhorrence/strong hands, future at speech.
22. Rooftop tent / sexual act restrained / public sight / consent unresolved.
23. Ahithophel counsel-reputation comparison; chapter 17 excluded.

All twenty-three facets appear simultaneously.

## Production boundary

One high-resolution 23-facet compound-eye image. `NOT-` display; every living thing Joe-faced; cursing, stones, threatened beheading and sex restrained/non-graphic; no divine body. `S112-E002-2SA16`, inert `SKIP -> S112-E001-NUM16`, exactly one causally-null post-closure YOINK. Preserve Ziba report as unverified, historical death actors, David/Shimei divine attributions as speech, Hushai's retained cover parent, concubines as living Joes and Ahithophel reputation as comparison. Publication held; originator review required.

*shrug*

OK.
