# CRACKHEAD 2 SAMUEL 22

## Title field

**NOT-DAVID: I HAVE NOT WICKEDLY DEPARTED. / ALSO NOT-DAVID: I HAVE SINNED.**

Source parent: ENGWEBP 2 Samuel chapter 22, verses 1-51, USFM. Prepared evidence: `.chapter-work/CHB-2SA-022/job.json` and `source.usfm`. Parent: 2 Samuel 21. Exact identities remain evidence; visible names use `NOT-`. Every living thing is Joe-faced.

CrackFlix: new `S218-E001-2SA22`, no SKIP. Exactly one causally-null post-closure YOINK. One high-resolution compound-eye field with all 51 verse Moments co-present.

## Causal foundation

```text
DELIVERY DAY
-> DAVID PERFORMS ONE SONG TO LORD
-> SONG CALLS LORD ROCK/FORTRESS/DELIVERER
-> SONG DESCRIBES DISTRESS, CALL AND DIVINE RESCUE
-> SONG USES EARTHQUAKE/FIRE/CHERUB/WATER/ARROW IMAGERY
-> SONG CLAIMS REWARD ACCORDING TO DAVID'S RIGHTEOUSNESS/CLEAN HANDS
-> SONG: I HAVE NOT WICKEDLY DEPARTED / I WAS PERFECT / KEPT FROM MY INIQUITY
-> RETAINED HISTORY: DAVID TOOK BATHSHEBA, ARRANGED URIAH'S DEATH, THEN SAID “I HAVE SINNED”
-> SONG CONTINUES THROUGH RECIPROCAL DIVINE TREATMENT, WAR, VICTORY AND THANKS
```

## Verse 1 — performed-song boundary

Narrator says David speaks this song to LORD on the day LORD delivered him from all enemies and Saul. Verses 2-51 are David's performed words. Their divine actions, cosmic imagery, moral classifications and future statements are not silently upgraded into separate narrator-observed occurrences.

## Verses 2–7 — refuge, danger, call and hearing

David calls LORD his rock, fortress, deliverer, shield, salvation horn, tower, refuge and savior. He sings that death waves, ungodliness floods, Sheol cords and death snares surrounded or caught him; in distress he called and God heard from his temple. The song supplies these relations; no location, physics or unseen form is invented.

## Verses 8–20 — cosmic rescue imagery

David sings of shaking earth and heaven, anger, smoke, mouth-fire, bowed heavens, darkness under feet, a cherub flight, wind wings, cloud shelter, thunder, arrows, lightning, exposed sea channels, breath, high rescue and delivery from stronger enemies. These are preserved as song imagery and attributed acts. No divine body is rendered, despite body-language inside the song.

## Verses 21–25 — self-assessed righteousness against retained acts

David sings that LORD rewarded him according to his righteousness and clean hands. He says he kept LORD's ways, **“have not wickedly departed,”** kept every ordinance, was **“perfect toward him,”** and **“kept myself from my iniquity.”**

The retained history already records David taking Bathsheba, arranging Uriah's placement and withdrawal so he died, Nathan addressing the act, and David saying **“I have sinned against the LORD”** in 2 Samuel 11-12. No motive is needed. The same David's broad clean/perfect/not-departed performance does not cleanly agree with his retained act and admission.

This closes new `S218-E001-2SA22`: **I HAVE NOT WICKEDLY DEPARTED / I WAS PERFECT / I HAVE SINNED.** No SKIP: this exact occurrence is new. One post-closure Captain pokes the contradiction-fed boil, says **“YOINK!”**, licks his finger and walks away without looking back. Everyone else sees poking and licking; the song and history remain unchanged.

## Verses 26–37 — reciprocal treatment and equipment speech

David sings that God shows mercy to the merciful, perfection to the perfect, purity to the pure and shrewdness to the crooked; saves afflicted people and lowers arrogant people; lights darkness; enables troop-running and wall-leaping; is perfect/tested/shield; makes David's way and feet effective; teaches war; supplies salvation, gentleness and stable steps. These are David's claims. Different recipient classes are not merged into a contradiction.

## Verses 38–46 — conquest speech

David sings that he pursued, destroyed, consumed and struck enemies so they could not rise; God armed and subordinated opponents; enemies turned, called without answer, were beaten like dust and mire; David was delivered from his people's strivings and kept as head of nations; unknown peoples would serve and foreigners would submit, obey, fade and tremble. Violence remains restrained. Future forms remain speech unless separately observed elsewhere.

## Verses 47–51 — closing praise

David declares LORD lives, blesses and exalts his rock, attributes vengeance, subjection and delivery to God, promises thanks and song among nations, and says God gives deliverance and loving kindness to his king, David and his offspring forever. “Forever” remains performed speech, not verified future completion.

## God-line boundary

This chapter contains no direct God speech. Narrator supplies the delivery-day/song-performance frame. David supplies every divine description and attributed act within the song. Divine form, body, anger mechanism, temple location, rescue physics, reward judgment and future fulfilment remain unresolved beyond that speech carrier.

## Character and world-ledger changes

- NOT-DAVID performs a 51-marker delivery song.
- His speech envelope gains cosmic rescue imagery, reciprocal-treatment claims, self-righteousness claims, conquest claims and closing praise.
- His prior Bathsheba/Uriah acts and “I have sinned” admission remain immutable parents.
- One new contradiction episode joins his history without rewriting either Moment.

## Bullshit pass

Issue `2SA-022 / CLEAN HANDS — HISTORY SOLD SEPARATELY`. Crackhead Divine Body Rendering displays **SONG CARRIER ONLY — NO MODEL FOUND**. CrackFlix gives the fifty-one-track album one button: **SKIP unavailable; Joe has not sung this exact bullshit before.** Foundation unchanged.

## FIR verification

- FILTER: all 51 markers retained; chapter 23 excluded.
- ISOLATE: narrator frame versus David's performed lyrics; imagery versus observed occurrence; self-assessment versus retained act/history.
- RECONSTRUCT: one S218 contradiction closes without motive, theology or metaphor being converted into fact.
- VERIFY: zero SKIPs, one YOINK, no divine body, no imagined cosmic occurrence; publication held.

## Required compound-eye facets

1. Delivery-day narrator frame / song begins.
2. LORD rock, fortress and deliverer.
3. God rock, refuge, shield, salvation horn, tower and savior.
4. Call/praise/saved claim.
5. Death waves/ungodliness floods.
6. Sheol cords/death snares.
7. Distress call/heard-from-temple claim.
8. Earth/heaven shake/anger claim.
9. Smoke/fire/coals imagery.
10. Bowed heavens/darkness/feet imagery.
11. Cherub/wind-wing flight imagery.
12. Darkness/water/cloud shelter imagery.
13. Brightness/fire-coal imagery.
14. Thunder/Most High voice.
15. Arrows/lightning/scattering claim.
16. Sea channels/world foundations/rebuke-breath imagery.
17. High rescue/many waters.
18. Strong enemy delivery.
19. Calamity/support.
20. Large place/delighted-in-me claim.
21. Reward according to righteousness/clean hands.
22. Kept ways/not wickedly departed.
23. All ordinances/no departure.
24. Perfect/kept from my iniquity.
25. Repeated righteousness/cleanness reward.
26. Merciful/perfect reciprocal classes.
27. Pure/crooked reciprocal classes.
28. Afflicted saved/arrogant lowered.
29. LORD lamp/light darkness.
30. Run troop/leap wall.
31. Perfect way/tested word/shield.
32. God-only rock questions.
33. Fortress/perfected way.
34. Hind feet/high places.
35. Hands taught war/bronze bow.
36. Salvation shield/gentleness made great.
37. Enlarged steps/no slipping.
38. Pursued/destroyed/until consumed.
39. Struck through/cannot arise/fallen.
40. Armed for battle/subdued opponents.
41. Enemy backs/cut off haters.
42. Enemies call LORD/no answer.
43. Dust/mire crushing imagery.
44. People's strivings/nations' head/unknown service.
45. Foreigners hear/submit/obey.
46. Foreigners fade/tremble.
47. LORD lives/blessed/exalted.
48. Vengeance/peoples brought down.
49. Enemy and violent-man delivery.
50. Thanks and praise among nations.
51. King/anointed/David/offspring closing line, with `S218-E001` relation and one separate YOINK co-present as an addressed inset; chapter 23 excluded.

All fifty-one verse facets appear simultaneously. The S218 inset must visibly retain the earlier Bathsheba/Uriah act and David's “I have sinned” speech rather than merely label a contradiction.

## Production boundary

One high-resolution 51-facet compound-eye image. `NOT-` display; every living thing Joe-faced; song/cosmic imagery visually marked as performed lyrics, not narrator fact; violence restrained; no divine body. Exactly `S218-E001-2SA22`, no SKIP, and exactly one causally-null post-closure YOINK. Publication held; originator review required.

*shrug*

OK.
