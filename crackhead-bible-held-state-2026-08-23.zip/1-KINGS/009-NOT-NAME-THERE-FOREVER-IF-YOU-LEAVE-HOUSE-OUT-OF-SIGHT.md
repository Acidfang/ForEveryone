# CRACKHEAD 1 KINGS 9

## Title field

**NOT-LORD: MY NAME, EYES AND HEART ARE THERE FOREVER—HERE ARE THE IF/THEN TERMS. / NOT-HIRAM: WHAT ARE THESE GOOD-FOR-NOTHING CITIES, MY BROTHER?**

Source parent: ENGWEBP 1 Kings chapter 9, verses 1-28, USFM. Prepared evidence: `.chapter-work/CHB-1KI-009/job.json` and `source.usfm`. Parent: 1 Kings 8. Exact identities remain evidence; visible names use `NOT-`. Every living human, animal and plant is Joe-faced. Place-name wordplay is visibly Crackheadverse display and never replaces the exact source name in evidence.

CrackFlix: no completed contradiction, no episode, no SKIP, no Captain and no YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
SOLOMON FINISHES BOTH HOUSES AND HIS DESIRED WORK
-> LORD APPEARS A SECOND TIME / PRAYER HEARD / HOUSE SANCTIFIED
-> FOREVER NAME/EYES/HEART RELATION
-> EXPLICIT IF WALK -> THRONE ESTABLISHED
-> EXPLICIT IF TURN -> ISRAEL CUT OFF / HOUSE CAST OUT / PUBLIC EXPLANATION
-> TWENTY-YEAR TWO-HOUSE SUMMARY
-> HIRAM SUPPLIES MATERIAL/GOLD / SOLOMON GIVES TWENTY CITIES
-> HIRAM INSPECTS / DISLIKES / NAMES CABUL / SENDS 120 TALENTS GOLD
-> FORCED-LABOR BUILD PROGRAM AND GEZER HISTORY
-> NON-ISRAELITE DESCENDANTS MADE BONDED LEVY / ISRAELITES ASSIGNED OTHER ROLES
-> PHARAOH'S DAUGHTER MOVES / MILLO BUILT
-> THREE-YEARLY OFFERING PRACTICE / HOUSE FINISH SUMMARY
-> SOLOMON-HIRAM FLEET FETCHES 420 TALENTS GOLD FROM OPHIR
```

## Verses 1–9 — Second appearance and explicit branches

After Solomon finishes LORD's house, the king's house and everything he desired to do, LORD appears to him a second time, compared by narrator to Gibeon. LORD says Solomon's prayer was heard and the house made holy, with LORD's name there forever and eyes and heart there perpetually.

The speech then supplies its own branches. If Solomon walks as David did and keeps commands, statutes and ordinances, the throne is established forever under the reported David promise. If Solomon or his children turn away, fail to keep them and serve other gods, Israel is cut from the land, the sanctified house is cast out of sight, and Israel becomes proverb/byword. Future passers ask why; the supplied answer attributes the outcome to abandoning LORD after the Egypt relation and serving other gods.

The forever language and later removal are not routed as contradiction: the source itself supplies the exact conditional selector and consequence chain. No compliance, departure, removal, astonishment or public answer is performed in this chapter.

## Verses 10–14 — Twenty cities that do not please Hiram

At the end of twenty years used to build the two houses, narrator recalls Hiram king of Tyre supplying cedar, cypress and gold according to Solomon's desire. Solomon gives Hiram twenty Galilee cities. Hiram leaves Tyre, inspects them, and they do not please him. He asks what cities Solomon gave him and calls the land Cabul; the source footnote says the name sounds like Hebrew for “good-for-nothing.” Hiram nevertheless sends Solomon 120 talents of gold.

Inspection, displeasure, naming and gold transfer are retained in order. No private motive, contract valuation, refund, acceptance, rejection or relation between the city grant and 120-talents transfer is invented.

## Verses 15–23 — Forced labor, conquered Gezer and role classes

Narrator identifies the reason for Solomon's forced labor: LORD's house, Solomon's house, Millo, Jerusalem's wall, Hazor, Megiddo and Gezer. Pharaoh king of Egypt had taken and burned Gezer, killed its Canaanite residents and given it as wedding property to his daughter, Solomon's wife. Solomon builds Gezer, Lower Beth Horon, Baalath, Tamar, storage cities, chariot cities, horseman cities and desired works across Jerusalem, Lebanon and his dominion.

Remaining Amorite, Hittite, Perizzite, Hivite and Jebusite descendants—those Israel was reported unable to destroy completely—are made a bonded levy to the chapter's present. Israelites are said not to be made bondservants; they occupy war, servant, prince, captain, chariot and horseman roles. Five hundred fifty officers supervise the laboring people.

This does not contradict the earlier levy “out of all Israel.” The chapter distinguishes bonded status from Israelite war/servant/administrative roles, while the exact relation between the earlier rotating levy and these categories remains unresolved. Category boundaries are preserved rather than collapsed.

## Verses 24–28 — Move, offerings and fleet

Pharaoh's daughter moves from David's city to the house Solomon built for her; Solomon then builds Millo. Three times per year Solomon offers burnt and peace offerings and burns incense on the altar before LORD. Narrator says he finished the house. This is a summary following its ritual-use relation, not a narrated resumption of house construction after a finish, so it does not join `S227`.

Solomon makes a fleet at Ezion Geber by Eloth on the Red Sea shore in Edom. Hiram sends sea-skilled servants to work with Solomon's servants. They reach Ophir, fetch 420 talents of gold and bring it to Solomon. Route, expertise, joint crew, amount and recipient are retained; ship count, voyage duration, extraction mechanism, losses and ownership terms remain unresolved.

## God-line boundary

Direct God speech in verses 3–9 includes heard prayer, house sanctification, name/eyes/heart presence, the Solomon-walk/throne branch, the turn-away/other-gods branch, Israel and house consequences, future passer question and supplied public answer. Narrator states a second LORD appearance compared with Gibeon. No divine form is described, so production uses a typed voice/presence carrier only. Later LORD-house and offering language are property/ritual relations, not new divine acts.

## Character and world-ledger changes

- NOT-SOLOMON receives direct conditional speech, completes a twenty-year two-house summary, transfers twenty cities, runs the building/labor program, performs recurring offerings and establishes a fleet.
- NOT-HIRAM-KING supplies timber and gold, inspects twenty cities, rejects their quality in speech, names the land Cabul and supplies 120 talents; he later supplies sea-skilled servants.
- NOT-PHARAOH takes/burns Gezer, kills its Canaanite residents and gives it to NOT-PHARAOH'S-DAUGHTER as wedding property.
- NOT-PHARAOH'S-DAUGHTER moves into her constructed house.
- Retained population classes receive different labor/military/administrative assignments without invented consent or motive.
- The joint fleet completes the Ophir route and returns 420 talents of gold.

## Bullshit pass

Issue `1KI-009 / TERMS-AND-CONDITIONS + MUNICIPAL REFUND DEPARTMENT`. The eternal temple warranty has an actual if/then clause, so there is no crack. NOT-HIRAM receives twenty cities, conducts the inspection, labels the folder **GOOD-FOR-NOTHING**, then sends another 120 talents of gold anyway. Reason: not supplied. Accounting continues.

## FIR verification

- FILTER: all 28 markers retained; chapter 10 excluded.
- ISOLATE: second appearance/speech, conditional branches, twenty-year summary, Hiram city/gold exchange, labor/build program, population-role split, move/offerings/finish summary and fleet voyage.
- RECONSTRUCT: forever/removal has an explicit selector; bonded/non-bonded categories remain distinct; house-finish language resumes no construction.
- VERIFY: zero episode/SKIP/Captain/YOINK; direct speech typed; no divine body; no motive, valuation or causation invented; publication held.

## Required compound-eye facets

1. Solomon finishes LORD house/king house/all desired work.
2. LORD second appearance/as at Gibeon; no body.
3. Prayer heard/house holy/name forever/eyes-heart perpetually.
4. If Solomon walks as David/keeps all commands.
5. Then throne established forever/reported David promise.
6. If Solomon or children turn/serve and worship other gods.
7. Then Israel cut from land/house cast out/proverb and byword.
8. Future passers astonished/hiss/ask why.
9. Supplied abandonment/other-gods/public-answer branch.
10. Twenty-year/two-house build summary.
11. Hiram timber/cypress/gold supply; Solomon gives twenty Galilee cities.
12. Hiram inspects cities/not pleased.
13. Hiram question/Cabul good-for-nothing wordplay.
14. Hiram sends 120 talents gold.
15. Forced-labor reason/build inventory.
16. Pharaoh takes/burns Gezer/kills residents/gives wedding property.
17. Solomon builds Gezer/Lower Beth Horon.
18. Baalath/Tamar wilderness.
19. Storage/chariot/horseman/desire building across dominion.
20. Remaining non-Israelite people classes.
21. Descendants not utterly destroyed/made bonded levy.
22. Israelites not bondservants/war-servant-prince-captain-ruler roles.
23. 550 supervising officers/laboring people.
24. Pharaoh's daughter moves to her house/Millo built.
25. Three-times-year offerings/incense/house finish summary.
26. Fleet made at Ezion Geber/Eloth/Red Sea/Edom.
27. Hiram sea-skilled servants join Solomon servants.
28. Ophir voyage/420 talents gold returned to Solomon.

All twenty-eight facets appear simultaneously.

## Production boundary

One high-resolution 28-facet compound-eye image. `NOT-` display; every living thing Joe-faced; buildings, ships, altars and property objects remain nonliving. Typed divine voice/presence only and no body. Cabul may visibly carry `GOOD-FOR-NOTHING` as source-supplied wordplay while retaining exact `Cabul` evidence address. Zero episodes, zero SKIPs, zero Captain carriers and zero YOINKs. Non-graphic Gezer conquest/deaths. Review/publication/job/hash/path/instruction State stays exclusively in machine ledgers and must not appear anywhere in the visible comic. Publication remains held outside the image.

*shrug*

OK.
