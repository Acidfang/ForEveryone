# CRACKHEAD 1 KINGS 21

## Title field

**NOT-JEZEBEL: WRITE THE CRIME. / NOT-WITNESSES: SAY HE DID IT. / NOT-OFFICIALS: KILL HIM. / NOT-AHAB: TAKE THE VINEYARD.**

Source parent: ENGWEBP 1 Kings chapter 21, verses 1-29, USFM. Prepared evidence: `.chapter-work/CHB-1KI-021/job.json` and `source.usfm`. Parent: 1 Kings 20. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: new physical `S249-E001-1KI21`; recurring mental `S112-E003-1KI21` with inert `SKIP -> S112-E002-2SA16`; recurring physical `S127-E014-1KI21` with inert `SKIP -> S127-E013-1KI20`. Exactly three separate causally-null post-closure Captain YOINKs. Two SKIPs. One high-resolution 29-facet compound-eye field.

## Causal foundation

```text
NABOTH OWNS VINEYARD BESIDE AHAB'S PALACE
-> AHAB OFFERS BETTER VINEYARD OR MONEY
-> NABOTH REFUSES FATHERS' INHERITANCE TRANSFER
-> AHAB SULKS / REFUSES FOOD
-> JEZEBEL PROMISES THE VINEYARD
-> WRITES IN AHAB'S NAME / USES AHAB'S SEAL
-> ORDERS FAST + TWO FALSE WITNESSES + STONING
-> ELDERS / NOBLES EXECUTE THE LETTER
-> WITNESSES SPEAK THE ORDERED FALSE CLAIM
-> NABOTH IS STONED DEAD
-> JEZEBEL REPORTS DEATH / TELLS AHAB TAKE POSSESSION
-> AHAB GOES TO TAKE POSSESSION
-> S249 CLOSES / YOINK
-> LORD WORD SENDS ELIJAH TO THE VINEYARD
-> RETAINED KILLING CHAIN IS ASSIGNED TO AHAB
-> SKIP S112-E002 / S112-E003 / YOINK
-> HOUSE-DESTRUCTION PREDICTIONS
-> AHAB HUMILIATES HIMSELF
-> PUNISHMENT MOVED OUT OF AHAB'S DAYS INTO HIS SON'S DAYS
-> SKIP S127-E013 / S127-E014 / YOINK
```

## Verses 1–7 — A refused exchange and a royal sulk

Naboth has a vineyard beside Ahab's palace. Ahab offers a better vineyard or its monetary worth because he wants the nearby land for an herb garden. Naboth refuses to transfer his fathers' inheritance. Ahab returns sullen and angry, lies on his bed, turns his face away and refuses food.

Jezebel asks why. Ahab recounts his offer and Naboth's refusal, omitting Naboth's stated inheritance reason in his retelling. Jezebel asks whether he governs Israel, tells him to eat and be merry, and promises to give him the vineyard. No hidden plan, permission or Ahab knowledge is inserted before the source supplies it.

## Verses 8–16 — Manufacture evidence, execute the owner, take the property

Jezebel writes letters in Ahab's name, seals them with Ahab's seal and sends them to Naboth's elders and nobles. Her written procedure is exact: proclaim a fast, elevate Naboth, place two wicked fellows before him, have them testify that Naboth cursed God and king, carry him outside and stone him to death.

The city officials do as the letter instructs. The two men speak the ordered claim. The source supplies no Naboth curse occurrence. Naboth is carried out and stoned dead; the death is reported to Jezebel. Jezebel tells Ahab the man who refused the sale is dead and directs him to possess the vineyard. Ahab goes down to possess it.

This is not merely an allegation later found false. The retained instruction manufactures the testimony before the witnesses speak it, and the performed false claim supplies the route to death and the refused property. The complete chain closes new `S249-E001-1KI21`: **WRITE THE EVIDENCE / USE IT AS EVIDENCE / TAKE WHAT THE EVIDENCE WAS WRITTEN TO OBTAIN.** One Captain **YOINK!** changes no letter, testimony, death or possession.

## Verses 17–20 — The chain did it; Ahab killed

LORD's word directs Elijah to meet Ahab in Naboth's vineyard, where Ahab has gone to take possession. Elijah is to carry: **Have you killed and also taken possession?** followed by the dogs-and-blood prediction.

The possession act is directly observed in Ahab's route. The killing chain retained by the same chapter is Jezebel's written order, the elders' and nobles' compliance, the two men's false testimony and the group's stoning. No Ahab killing act, plan knowledge or transfer mechanism is narrated. The mediated accusation therefore repeats S112's exact causal reassignment relation. An inert **SKIP -> S112-E002-2SA16** points to it; `S112-E003-1KI21` closes at the addressed spoken causal model. One Captain **YOINK!** changes neither chain nor accusation.

Ahab calls Elijah his enemy. Elijah says he found him because Ahab sold himself to do evil. These are retained speeches, not invented psychology.

## Verses 21–26 — House judgments and narrator classifications

Elijah carries future destruction of Ahab and his house, comparisons with Jeroboam and Baasha, dogs eating Jezebel by Jezreel's rampart, and dogs or birds eating Ahab-house dead. These remain predictions; no future corpse, dog or bird act is rendered as already performed.

The narrator classifies Ahab as unmatched in selling himself to evil, says Jezebel stirred him, and recounts his idolatry like the Amorites. The narration supplies the attribution but no hidden influence mechanism; it remains typed as narrator State.

## Verses 27–29 — Humility moves the bill to the son

After hearing the words, Ahab tears his clothes, puts sackcloth on his body, fasts, lies in sackcloth and walks despondently. LORD's word then tells Elijah that because Ahab humbled himself, the announced evil will not arrive in Ahab's days; it will arrive on his house in his son's days.

The change from Ahab's days to his son's days has an explicit stated condition and is retained as a State transition, not a contradiction between unchanged claims. The resulting liability still moves from the addressed actor to a later son/house without those later people performing Ahab's retained acts. This repeats S127. An inert **SKIP -> S127-E013-1KI20** points to that contradiction; `S127-E014-1KI21` closes here. One Captain **YOINK!** changes no day, person or judgment.

## God-line boundary

- LORD words arrive through Elijah; no divine body is rendered.
- “Have you killed” remains a mediated divine accusation distinct from the narrator's explicit Jezebel/witness/official killing chain.
- The Naboth-blood dog occurrence is asserted inside the mediated prediction but was not narrated during the killing; its mechanism and observation remain unresolved.
- Ahab's future blood, Jezebel's death and Ahab-house deaths remain predictions.
- Ahab's humility acts are observed; LORD's later explanation of delay is direct-speech State carried through Elijah.

## Character and world-ledger changes

- NOT-NABOTH JOE moves from vineyard owner and inheritance refusal to target of manufactured testimony and stoning death.
- NOT-JEZEBEL JOE writes under Ahab's name, uses his seal, supplies the false-case procedure, receives the death report and routes Ahab to possession.
- NOT-AHAB JOE makes the exchange offer, sulks after refusal, goes to possess after the death report, receives Elijah's accusation and judgments, then performs humility acts.
- NOT-ELDER, NOT-NOBLE and NOT-WITNESS JOES execute distinct links in the written chain; they are not merged into Jezebel or Ahab.
- NOT-ELIJAH JOE carries LORD's accusation, predictions and later delay explanation.
- NOT-DOG and NOT-BIRD JOES appear only as living carriers inside future or asserted speech boundaries unless the source later performs those acts.

## Bullshit pass

Issue `1KI-021 / PROCUREMENT BY FABRICATED COMPLIANCE EVIDENCE`.

- Asset owner rejects acquisition request.
- Executive spouse authors complaint evidence under executive identity.
- Local compliance team hires two attestations to confirm the prewritten violation.
- Owner is removed.
- Executive takes asset.
- Audit asks executive: **DID YOU REMOVE THE OWNER AND TAKE THE ASSET?**
- Remediation is deferred from executive's service window to executive's child's service window because executive looked sad in sackcloth.

Captain licks the fabricated-evidence ticket, actor-attribution ticket and inherited-remediation ticket separately. **YOINK! YOINK! YOINK!** Nothing changes.

## FIR verification

- FILTER: all 29 markers retained; chapter 22 excluded.
- ISOLATE: offer/refusal, sulk, forged-name letter, ordered false testimony, performed stoning, possession, mediated causal reassignment, future house judgments, humility and son-day transfer.
- RECONSTRUCT: new S249 plus recurring S112 and S127.
- VERIFY: two exact inert SKIPs, three separate YOINKs, no Ahab plan knowledge, Naboth curse, divine body, future death performance, dog mechanism or graphic killing invented.

## Required compound-eye facets

1. Naboth vineyard beside Ahab palace.
2. Ahab offers better vineyard or money.
3. Naboth refuses fathers' inheritance transfer.
4. Ahab sullen/angry, bed/turned face/no food.
5. Jezebel asks why sad/no food.
6. Ahab recounts offer/refusal.
7. Jezebel says govern/eat/be merry/I give vineyard.
8. Jezebel writes in Ahab name/seals/sends.
9. Letter orders fast and Naboth elevated.
10. Letter orders two false witnesses and stoning.
11. Elders/nobles perform the written instructions.
12. Fast proclaimed/Naboth elevated.
13. Two men speak ordered claim/Naboth stoned dead, restrained.
14. Death reported to Jezebel.
15. Jezebel tells Ahab dead/take possession.
16. Ahab goes to possess; S249 YOINK.
17. LORD word comes to Elijah.
18. Elijah sent to Ahab in possessed vineyard.
19. Killed-and-possessed accusation/dog-blood prediction; S112 SKIP/YOINK.
20. Enemy/found/sold-to-evil exchange.
21. Future sweep/cut-off speech.
22. Jeroboam/Baasha house comparison.
23. Future Jezebel/dogs speech.
24. Future house dead/dogs/birds speech.
25. Narrator Ahab/Jezebel classification.
26. Narrator idol/Amorite classification.
27. Ahab tears clothes/sackcloth/fasts/walks despondently.
28. LORD word observes humility.
29. Evil delayed to son's days; S127 SKIP/YOINK.

All twenty-nine facets appear simultaneously.

## Production boundary

One high-resolution 29-facet compound-eye image. `NOT-` identities and Joe faces for every living thing. Letters, seal, stones, vineyard, palace and remains are nonliving/faceless. Exactly two inert SKIP pointers and three separate boilless Captain poke/lick/YOINK/walk-away carriers. Killing and corpse references restrained/non-graphic. Future judgments remain visibly unperformed. No divine body. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
