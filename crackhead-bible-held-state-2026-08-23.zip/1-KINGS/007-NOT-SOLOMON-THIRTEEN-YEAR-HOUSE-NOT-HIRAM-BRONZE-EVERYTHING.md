# CRACKHEAD 1 KINGS 7

## Title field

**NOT-SOLOMON: THIRTEEN YEARS FOR MY HOUSE. / NOT-HIRAM: TWO PILLARS, ONE SEA, TEN WHEELED BASINS, AND EVERYTHING ELSE IN BRONZE.**

Source parent: ENGWEBP 1 Kings chapter 7, verses 1-51, USFM. Prepared evidence: `.chapter-work/CHB-1KI-007/job.json` and `source.usfm`. Parent: 1 Kings 6. Exact identities remain evidence; visible names use `NOT-`. Every living human, animal and plant is Joe-faced. Hiram the bronze worker is distinct from Hiram king of Tyre. Cast oxen, lions, cherubim, palms, flowers and pomegranates are manufactured decoration, not living carriers.

CrackFlix: no completed contradiction, no episode, no SKIP, no Captain and no YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
SOLOMON'S OWN HOUSE COMPLETED IN 13 YEARS
-> FOREST HOUSE / HALLS / JUDGMENT PORCH / RESIDENCE / PHARAOH-DAUGHTER HOUSE DETAILED
-> SOLOMON SUMMONS HIRAM BRONZE WORKER
-> HIRAM LINEAGE + SKILL + ALL-WORK PERFORMANCE REPORTED
-> TWO BRONZE PILLARS/CAPITALS/NETWORKS/POMEGRANATES/LILIES BUILT + INSTALLED + NAMED
-> MOLTEN SEA + TWELVE CAST OXEN BUILT
-> TEN BRONZE WHEELED BASES + TEN BASINS BUILT + PLACED
-> POTS/SHOVELS/BASINS + COMPLETE HIRAM INVENTORY FINISHED
-> BRONZE CAST IN JORDAN CLAY / LEFT UNWEIGHED
-> SOLOMON GOLD VESSELS/LAMPSTANDS/TOOLS/HINGES MADE
-> ALL LORD-HOUSE WORK FINISHED
-> DAVID-DEDICATED SILVER/GOLD/VESSELS STORED IN TREASURIES
```

## Verses 1–12 — Solomon's palace complex

Solomon builds his own house for thirteen years and finishes all of it. The following verses explain that completed complex: the 100x50x30 House of the Forest of Lebanon, four cedar-pillar rows, forty-five beams in fifteen-per-row arrangement, three window ranks, square doors/posts, 50x30 pillar hall, throne/judgment porch, residence court, and a comparable house for Pharaoh's daughter. Costly measured/sawn stones, ten- and eight-cubit foundation stones, cedar and great-court construction are retained.

The detail following “finished all his house” is explanatory inventory, not a newly narrated resumption of construction. It does not join `S227`.

## Verses 13–22 — Hiram and the two pillars

Solomon summons Hiram from Tyre. This is the bronze worker: son of a Naphtali widow and a Tyrian bronze-worker father, described as filled with wisdom, understanding and skill. He comes and performs all assigned work.

He fashions two eighteen-cubit bronze pillars with twelve-cubit circumference, two five-cubit capitals, checker nets, chain wreaths, pomegranate rows, lily work and two-hundred-pomegranate rows. He installs the right pillar as Jachin and left as Boaz. Verse 22 closes the pillar-work scope only; later sea/base work is a different object scope, not resumed pillar work.

## Verses 23–39 — Molten sea, bases and basins

Hiram makes a round ten-cubit-wide, five-cubit-high, thirty-cubit-circumference molten sea with two bud rows, hand-width thickness, lily-cup brim and two-thousand-bath capacity. It stands on twelve manufactured oxen, three facing each compass direction.

Ten 4x4x3 bronze bases receive panels, ledges, manufactured lions/oxen/cherubim, wreaths, four wheels/axles/feet/supports, openings, engravings, cast wheel parts and integral corner supports. All ten share one casting, measure and form. Ten four-cubit basins hold forty baths each, one per base. Five bases go right, five left; the sea goes right/east/south.

## Verses 40–47 — Hiram's completed bronze inventory

Hiram makes pots, shovels and basins, and narrator says he finishes all work for Solomon in LORD's house. Verses 41–45 inventory that completed scope: two pillars, capital bowls, networks, four hundred pomegranates, ten bases/basins, one sea/twelve oxen and burnished-bronze small vessels. This is an inventory, not continued manufacture after finish.

The king casts them in Jordan clay ground between Succoth and Zarethan. Solomon leaves them unweighed because of their number; the bronze weight cannot be determined. “Could not be determined” is retained as outcome, not converted into motive or technological impossibility beyond this occurrence.

## Verses 48–51 — Gold work, total finish and stored dedications

Solomon makes the golden altar, showbread table, ten pure-gold lampstands, flowers, lamps, tongs, cups, snuffers, basins, spoons, fire pans and gold hinges for inner and temple doors. Verse 51 says all work Solomon did in LORD's house was finished. Solomon then brings David-dedicated silver, gold and vessels into the treasuries.

The storage transfer follows finished work but is not described as resumed house construction or manufacture. David's dedication act remains a retained parent; item origins, quantities and prior custody are unresolved.

## God-line boundary

No direct God speech, narrated divine act or human claim about a new divine action occurs. “LORD's house” identifies the addressed building/property relation. No divine body is rendered. Manufactured cherubim and animal/plant figures do not establish living spiritual, animal or plant presence.

## Character and world-ledger changes

- NOT-SOLOMON completes his thirteen-year house complex and all LORD-house vessel work, then stores David's dedicated property.
- NOT-PHARAOH'S-DAUGHTER receives a house relation; her speech, choice, residence act and use remain unresolved.
- NOT-HIRAM-THE-BRONZE-WORKER enters as a distinct Joe from NOT-HIRAM-KING, performs the full bronze inventory and remains living at chapter close.
- Palace buildings, bronze pillars/sea/bases/basins and gold vessels become completed material State.
- Jachin and Boaz are pillar names, not new living identities.

## Bullshit pass

Issue `1KI-007 / BRONZE UI COMPONENT LIBRARY`. NOT-HIRAM ships two named columns, a 42,200-liter metal swimming pool on twelve fake cows, and ten wheeled 840-liter wash buckets with decorative lion-ox-cherub dashboards. Bronze quantity: **TOO MUCH TO WEIGH, MOVING ON.** Foundation unchanged.

## FIR verification

- FILTER: all 51 markers retained; chapter 8 excluded.
- ISOLATE: palace completion/inventory, bronze-worker identity, pillar scope, sea/base/basin scope, complete bronze inventory, gold inventory, total work finish and treasury transfer.
- RECONSTRUCT: all finish statements have explicit object/inventory scope; zero valid contradiction occurrences.
- VERIFY: no episode/SKIP/Captain/YOINK; two Hirams distinct; manufactured figures nonliving; God-line empty; publication held.

## Required compound-eye facets

1. Solomon own house/thirteen years/all finished.
2. Forest House 100x50x30/four pillar rows/cedar beams.
3. Forty-five cedar-covered beams/fifteen per row.
4. Three beam/window ranks.
5. Square doors/posts/window ranks.
6. Pillar hall 50x30/porch/threshold.
7. Throne/judgment porch/cedar floor-to-floor.
8. Residence court/same construction/Pharaoh-daughter house.
9. Costly measured/sawn stones/foundation-to-coping/court.
10. Ten/eight-cubit costly foundation stones.
11. Costly measured cut stone and cedar above.
12. Great court three stone courses/cedar course/comparisons.
13. Solomon sends/brings Hiram worker from Tyre.
14. Widow-Naphtali/Tyrian-father/bronze skill/all work.
15. Two bronze pillars/18 high/12 circumference.
16. Two five-cubit molten capitals.
17. Seven-and-seven checker/chain networks.
18. Two pomegranate rows per capital.
19. Four-cubit lily capital work.
20. Capitals/bellies/networks/two-hundred rows.
21. Pillars installed/named Jachin and Boaz.
22. Lily tops/pillar work finished.
23. Molten sea 10 wide/5 high/30 circumference.
24. Two cast bud rows.
25. Twelve manufactured oxen/three per direction.
26. Hand-width/lily-cup brim/2,000 baths.
27. Ten bronze bases/4x4x3.
28. Base panels/ledges.
29. Manufactured lions/oxen/cherubim/pedestal/wreaths.
30. Four wheels/axles/feet/supports per base.
31. Round opening/engraving/square panels.
32. Wheel placement/1.5-cubit height.
33. Chariot-wheel cast axles/rims/spokes/hubs.
34. Four integral corner supports.
35. Half-cubit top band/supports/panels.
36. Engraved cherubim/lions/palms/wreaths.
37. Ten bases/one casting/measure/form.
38. Ten forty-bath/four-cubit basins/one per base.
39. Five-right/five-left bases/sea east-south.
40. Pots/shovels/basins/Hiram work finished.
41. Pillar/capital/network inventory.
42. Four hundred pomegranates/two rows each network.
43. Ten bases/ten basins.
44. One sea/twelve manufactured oxen.
45. Pots/shovels/basins/all burnished bronze.
46. Jordan clay casting/Succoth-Zarethan.
47. Unweighed abundance/weight undetermined.
48. Solomon gold altar/showbread table.
49. Ten lampstands/flowers/lamps/tongs.
50. Cups/snuffers/basins/spoons/fire pans/hinges.
51. All LORD-house work finished/David dedications stored; chapter 8 excluded.

All fifty-one facets appear simultaneously.

## Production boundary

One high-resolution 51-facet compound-eye image. `NOT-` display; every living thing Joe-faced; manufactured figures/oxen/plants remain visibly material and faceless; distinguish Hiram worker from Hiram king. Zero episodes, zero SKIPs, zero Captain carriers and zero YOINKs. Publication held; originator review required.

*shrug*

OK.
