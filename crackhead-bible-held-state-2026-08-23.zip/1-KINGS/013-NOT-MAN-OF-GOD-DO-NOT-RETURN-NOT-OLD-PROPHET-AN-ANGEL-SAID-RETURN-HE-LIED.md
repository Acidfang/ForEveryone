# CRACKHEAD 1 KINGS 13

## Title field

**NOT-MAN-OF-GOD: DO NOT RETURN. / NOT-OLD-PROPHET: AN ANGEL SAID RETURN. HE LIED. / YOU DISOBEYED.**

Source parent: ENGWEBP 1 Kings chapter 13, verses 1-34, USFM. Prepared evidence: `.chapter-work/CHB-1KI-013/job.json` and `source.usfm`. Parent: 1 Kings 12. Exact identities remain evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: new `S240-E001-1KI13`; recurring `S237-E002-1KI13` with inert `SKIP -> S237-E001-1KI12`. Exactly two separate causally-null post-closure Captain YOINKs. One high-resolution 34-facet compound-eye field.

## Causal foundation

```text
MAN OF GOD ARRIVES BY LORD WORD
-> ALTAR PROPHECY + SAME-DAY SIGN
-> KING ORDERS SEIZURE / HAND DRIES
-> ALTAR SPLITS / ASHES POUR
-> INTERCESSION / HAND RESTORED
-> KING INVITES / MAN REFUSES
-> RETAINED COMMAND: NO RETURN / NO BREAD / NO WATER
-> OLD PROPHET CLAIMS ANGEL REVERSAL
-> NARRATOR: HE LIED
-> MAN RETURNS / EATS / DRINKS
-> REAL LORD WORD COMES THROUGH SAME OLD PROPHET
-> RECEIVER CONDEMNED FOR DISOBEDIENCE
-> LION KILLS RECEIVER / LIAR RETRIEVES AND BURIES HIM
-> S240 / YOINK
-> JEROBOAM DOES NOT TURN
-> AGAIN MAKES PRIESTS FROM ALL PEOPLE
-> S237 RECURS / SKIP / YOINK
```

## Verses 1–10 — The altar sign and the route command

An unnamed man of God comes from Judah to Bethel by LORD's word while Jeroboam burns incense at the altar. He cries against the altar and carries a reported LORD saying: a son named Josiah will be born to David's house, high-place priests will be sacrificed on the altar, and human bones will be burned on it. He supplies a same-day sign: the altar will split and its ashes will pour out. The future Josiah acts remain speech; the sign belongs to the present chapter.

Jeroboam points and orders, **“Seize him!”** His extended hand dries so that he cannot draw it back. The altar splits and the ashes pour exactly as the man stated. Jeroboam asks the man to entreat LORD and pray for restoration. The man does; the king's hand is restored. No physical mechanism is invented.

The king invites the man home for refreshment and a reward. The man refuses even half the king's house. He reports the LORD-word command: eat no bread, drink no water and do not return by the route used to arrive. He leaves by another route.

## Verses 11–23 — A false update enters the same authority channel

An old prophet lives in Bethel. His sons report every act and word from the altar and show him the route taken by the man of God. The old prophet saddles a donkey, follows and finds the man sitting under an oak. He invites him home for bread.

The man repeats the retained command: he may not return, enter, eat bread or drink water there. The old prophet answers that he too is a prophet and claims an angel spoke to him by LORD's word: **bring him back so he may eat bread and drink water.** The narrator then closes the status of that claimed update exactly: **he lied to him.** No angel appearance or speech is rendered as an observed divine event.

The man returns, eats and drinks. While they sit at the table, LORD's word comes to the old prophet who brought him back. The old prophet now carries judgment to the man: because he rebelled against LORD's mouth and did not keep the command, but returned and ate and drank, his body will not come to his fathers' tomb. After the meal, the old prophet saddles the donkey for him.

The receiver retained a direct prohibition, received a reversal through a claimant presenting the same prophetic/LORD-word authority, and performed the reversal. The source explicitly marks the reversal as a lie. The same false-update carrier then becomes the carrier of the genuine sanction, while no verification bridge was available to the receiver inside the narrated exchange and no sanction is narrated for the liar. This entire addressed chain—not merely the meal—closes new `S240-E001-1KI13`. One Captain **YOINK!** changes no command, lie, act or allocation.

## Verses 24–32 — The lion, the body and the liar's grave

A lion meets and kills the man on the road. His body lies on the path while the donkey and lion stand beside it. Passersby observe and report it in the city. The old prophet hears, attributes the delivery to the lion to LORD and identifies the dead man as the one who rebelled against LORD's mouth. That explanation remains the old prophet's speech; the narrated death and prior carried judgment remain distinct evidence.

The old prophet finds the body. The lion has neither eaten the body nor mauled the donkey. He loads the body onto the donkey, returns, mourns and buries the man in his own grave, crying, **“Alas, my brother!”** The word *brother* is retained as his speech; no biological relation is inferred.

After burial he instructs his sons to bury him in the same grave later and place his bones beside the man's bones. That future burial is not performed here. He says the earlier altar/high-place saying will surely happen; future fulfilment remains unresolved.

## Verses 33–34 — The sign changes nothing in the priest factory

After these events Jeroboam does not turn from his evil way. He again makes priests for the high places from all the people; whoever desires it is consecrated. The retained Levite/Aaron priest-service lineage and the prior chapter's non-Levite appointments remain unchanged, with no new lineage exception or transition.

This is exact recurrence `S237-E002-1KI13`. `SKIP -> S237-E001-1KI12` points to the previous occurrence and removes no new appointment. A second Captain **YOINK!** changes nothing. The narrator says this thing became sin to Jeroboam's house, to cut it off and destroy it; the chapter does not instantiate the later house destruction.

## God-line boundary

- The man of God's arrival, altar speech and food/route command are mediated LORD-word carriers; the man is not God.
- The old prophet's angel/LORD-word reversal is explicitly classified by the narrator as a lie. No angel body, divine voice or divine authorization is invented for it.
- LORD's word later comes to the old prophet at the table; this later mediated judgment does not retroactively make his earlier lie true.
- The old prophet's lion explanation is human attributed speech. The narrated lion killing and the earlier mediated judgment remain distinct.
- No divine body, hand-drying mechanism, restoration mechanism or animal-control mechanism is invented.

## Character and world-ledger changes

- NOT-MAN-OF-GOD carries a sign and command, refuses the king, accepts a false reversal, eats and drinks, receives judgment and is killed by the lion.
- NOT-OLD-PROPHET searches for him, lies using a claimed divine update, brings him back, later carries judgment, retrieves and buries him, and requests future burial beside him.
- NOT-JEROBOAM burns incense, orders seizure, receives hand restoration and continues appointing high-place priests.
- NOT-OLD-PROPHET'S SONS report what they observed and later receive burial instructions; no motives are invented.
- NOT-LION and NOT-DONKEY remain living, Joe-faced and distinct. Their unusual standing relation is shown without invented thought or supernatural mechanism.

## Bullshit pass

Issue `1KI-013 / AUTHORITY UPDATE VALIDATION`.

- Original ticket: do not return; do not eat; do not drink.
- Revised ticket: an angel allegedly approved return, eating and drinking.
- Change-control evidence: **he lied.**
- Compliance outcome: the receiver is terminated.
- Incident owner: the liar carries the termination notice, retrieves the body and books the neighboring grave slot.
- Corrective action at Bethel: keep hiring absolutely anyone as priest.

Captain performs two independent audits by licking the closed evidence. **YOINK! YOINK!** Nothing changes.

## FIR verification

- FILTER: all 34 markers retained; chapter 14 excluded from story pixels.
- ISOLATE: altar sign, hand state change, route/food command, false reversal, performed return, mediated judgment, lion/body sequence, burial and repeated priest appointments.
- RECONSTRUCT: one new complete false-update/sanction-allocation contradiction and one exact priest-lineage recurrence.
- VERIFY: one inert SKIP, two separate YOINKs, no divine or angel body, no invented motive, mechanism, kinship or future fulfilment, story-only pixels.

## Required compound-eye facets

1. Man of God arrives from Judah by LORD word while Jeroboam burns incense.
2. Altar addressed/Josiah future saying carried.
3. Same-day altar-split/ash-pour sign stated.
4. Jeroboam orders seizure/extended hand dries.
5. Altar splits/ashes pour exactly as sign.
6. Jeroboam requests intercession.
7. Prayer performed/hand restored.
8. King offers home refreshment/reward.
9. Half-house refusal and no-food/no-water command reported.
10. No-return-same-route command/another route taken.
11. Old prophet receives sons' complete altar report.
12. Route identified/donkey saddled/pursuit begins.
13. Man found under oak/identity question.
14. Old prophet invites him home for bread.
15. Man repeats no-return/no-food/no-water command.
16. Old prophet claims prophet parity and angel/LORD-word reversal.
17. Narrator visibly classifies the reversal: HE LIED.
18. Man returns/eats/drinks.
19. Real LORD word comes to old prophet at table.
20. Old prophet carries rebellion/disobedience judgment.
21. Body-will-not-reach-fathers'-tomb judgment.
22. Meal ends/donkey saddled for man.
23. Lion kills man/body-donkey-lion stand on road; S240 YOINK.
24. Passers observe/report in city.
25. Old prophet hears and gives his lion-delivery attribution.
26. Old prophet travels and finds body/lion/donkey.
27. Lion has not eaten body or mauled donkey.
28. Body loaded/returned/mourned.
29. Burial in old prophet's grave/“Alas, my brother!”
30. Future same-grave/bones-beside-bones instruction.
31. Future altar/high-place fulfilment claim retained as speech.
32. Jeroboam does not turn after these things.
33. Again makes priests from all people; S237 SKIP/YOINK.
34. Sin-to-house/cut-off/destruction narrator outcome remains future at chapter close.

All thirty-four facets appear simultaneously.

## Production boundary

One high-resolution 34-facet compound-eye image. `NOT-` identities and Joe faces for every living thing. Altars, ashes, grave and other objects are nonliving and faceless. Exact one inert `SKIP -> S237-E001-1KI12` and two separate boilless Captain poke/lick/YOINK/walk-away carriers. No divine or angel body. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
