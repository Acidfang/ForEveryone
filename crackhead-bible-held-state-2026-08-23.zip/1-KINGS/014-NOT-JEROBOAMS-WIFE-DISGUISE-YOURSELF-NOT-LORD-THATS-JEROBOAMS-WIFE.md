# CRACKHEAD 1 KINGS 14

## Title field

**NOT-JEROBOAM'S-WIFE: DISGUISE YOURSELF. / NOT-LORD: THAT'S JEROBOAM'S WIFE. / NOT-DAVID: DID ONLY WHAT WAS RIGHT.**

Source parent: ENGWEBP 1 Kings chapter 14, verses 1-31, USFM. Prepared evidence: `.chapter-work/CHB-1KI-014/job.json` and `source.usfm`. Parent: 1 Kings 13. Exact identities remain evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: recurring `S127-E009-1KI14` with inert `SKIP -> S127-E008-1KI12`; recurring `S218-E002-1KI14` with inert `SKIP -> S218-E001-2SA22`. Exactly two separate causally-null post-closure Captain YOINKs. One high-resolution 31-facet compound-eye field.

## Causal foundation

```text
ABIJAH SICK
-> JEROBOAM ORDERS WIFE DISGUISED
-> BLIND AHIJAH CANNOT IDENTIFY BY SIGHT
-> LORD IDENTIFIES HER AND HER PURPOSE BEFORE ENTRY
-> AHIJAH ADDRESSES HER EXACTLY
-> HOUSE JUDGMENT FOR JEROBOAM'S ACTS
-> ONLY GOOD CHILD DIES AT HER THRESHOLD ARRIVAL
-> S127 RECURS / SKIP / YOINK
-> CHILD DIES / ISRAEL BURIES AND MOURNS
-> JEROBOAM DIES AFTER TWENTY-TWO YEARS / NADAB REIGNS
-> DIRECT SPEECH: DAVID KEPT COMMANDMENTS / DID ONLY RIGHT
-> RETAINED DAVID ACTS CONTRADICT ABSOLUTE CLASSIFICATION
-> S218 RECURS / SKIP / YOINK
-> JUDAH HIGH PLACES / PILLARS / ASHERAH / SOURCE-DEFINED LAND CLASS
-> SHISHAK TAKES GOLD SHIELDS
-> REHOBOAM MAKES BRONZE REPLACEMENTS
-> CONTINUAL WAR / REHOBOAM DIES / ABIJAM REIGNS
```

## Verses 1–6 — Disguise for the blind prophet; announce yourself to LORD

Jeroboam's son Abijah becomes sick. Jeroboam tells his wife to disguise herself so she will not be recognized as his wife, go to Ahijah at Shiloh and take ten loaves, cakes and a jar of honey. Ahijah is the prophet who previously said Jeroboam would be king; Jeroboam says Ahijah will tell what will become of the child.

Jeroboam's wife performs the disguise and journey. Ahijah cannot see because his eyes are fixed by age. Before she enters, LORD directly tells Ahijah that Jeroboam's wife is coming to ask about her sick son, supplies what he must tell her and says she will pretend to be another woman.

Ahijah hears her feet at the door and addresses her as Jeroboam's wife. The disguise was an attempted information-control act; the source explicitly supplies the separate disclosure carrier that defeats it. That is a completed causal chain, not a contradiction and not supernatural form evidence.

## Verses 7–18 — Jeroboam acts; the only good child pays first

Ahijah carries direct LORD speech through the wife to Jeroboam. LORD says he exalted Jeroboam, made him prince, tore the kingdom from David's house and gave it to him. The speech then contrasts Jeroboam with David, says Jeroboam made other gods and molten images, and announces the cutting-off and sweeping-away of Jeroboam's house. The source's wall-urination wording and male footnote remain source evidence without visual vulgarity being required.

The carried speech says city deaths will be eaten by dogs and field deaths by birds. It then gives the wife an exact trigger: when her feet enter the city, the child will die. All Israel will mourn and bury him; he alone of Jeroboam's house will reach a grave because some good thing toward LORD was found in him. A future king, Israel's uprooting/scattering and house destruction are announced but not all performed here.

Jeroboam's prohibited image and Israel-sin acts are the stated producing acts. The sick child is explicitly classified as the sole house member with some good, yet his death is the first performed house consequence when his mother reaches home. No act by the child produces that liability. This repeats `S127-E009-1KI14`. `SKIP -> S127-E008-1KI12` points to the prior actor/additional-person liability occurrence and removes nothing. One Captain **YOINK!** changes no act, allocation or death.

The wife returns to Tirzah. As she reaches the house threshold, the child dies. Israel buries and mourns him according to the LORD word spoken through Ahijah. The trigger, death, burial and mourning are complete; the remaining announced destruction is not imported as completed.

## Verses 7–16 joined to retained David State — “Did only what was right”

Within the same direct speech, LORD says David kept the commandments, followed with all his heart and did **only** what was right in LORD's eyes. Retained David history contains the Bathsheba/Uriah acts, David's engineered battle withdrawal and Uriah's death, Nathan's judgment, and David's own **“I have sinned against LORD.”**

The word **only** makes the classification universal inside its stated scope; no exception, repaired interval or excluded act is supplied here. This repeats the righteousness-versus-retained-act structure of `S218-E002-1KI14`. `SKIP -> S218-E001-2SA22` points to David's earlier clean-hands/not-wickedly-departed occurrence and deletes neither statement nor history. A second Captain **YOINK!** changes nothing.

## Verses 19–20 — Jeroboam closes

The rest of Jeroboam's fighting and reign is addressed to the kings-of-Israel chronicle rather than reconstructed here. He reigns twenty-two years, sleeps with his fathers and is succeeded by his son Nadab. Burial location and the mechanics/timing of the remaining house judgment are not supplied in this chapter.

## Verses 21–31 — Judah copies the objects; Egypt takes the gold

Rehoboam reigns in Judah from age forty-one for seventeen years in Jerusalem. His mother is named Naamah the Ammonitess. Judah does what the narrator classifies as evil, builds high places, sacred pillars and Asherah poles on high hills and under green trees, and contains the source-defined land class in verse 24. The exact source term/classification is retained without inventing individual identities, acts, motives or explicit sexual imagery.

In Rehoboam's fifth year, Shishak king of Egypt comes against Jerusalem and takes the LORD-house and king-house treasures, including Solomon's gold shields. Rehoboam makes bronze shields in their place, assigns them to guard captains, and the guard carries them whenever the king enters LORD's house before returning them to the guardroom. The bronze objects are not falsely called gold; replacement is therefore not itself a contradiction.

The rest of Rehoboam's acts is addressed to Judah's chronicle. Rehoboam and Jeroboam have continual war. Rehoboam dies, is buried with his fathers in David's city, and his son Abijam reigns in his place.

## God-line boundary

- Direct LORD speech to Ahijah identifies the disguised wife, her purpose and the message carrier before her entry; no divine body is rendered.
- Ahijah carries direct LORD speech concerning Jeroboam, David, the child, the house and future Israel outcomes; Ahijah is not merged with God.
- The wife's threshold arrival, child death, burial and mourning are narrator-completed acts according to the mediated word.
- Future king, house destruction, scattering and other announced outcomes remain future unless separately performed.
- Judah's evil/jealousy classification and LORD's prior driving-out act are narrator attributions; mechanism and divine form remain unresolved.

## Character and world-ledger changes

- NOT-JEROBOAM orders the disguise, remains king through twenty-two years, dies and is succeeded by NOT-NADAB.
- NOT-JEROBOAM'S-WIFE performs the disguise/journey, is recognized through disclosed information, receives the message and returns at the child's death trigger.
- NOT-AHIJAH is blind by age, hears her arrival and carries the supplied speech; no visual recognition is invented.
- NOT-ABIJAH-CHILD becomes sick, dies at the threshold trigger, is buried and mourned; no producing wrongdoing is assigned to him.
- NOT-REHOBOAM reigns seventeen years, replaces removed gold shields with bronze, has continual war, dies and is succeeded by NOT-ABIJAM.
- NOT-SHISHAK takes the treasures; no unstated battle, casualty, motive or recovery is invented.

## Bullshit pass

Issue `1KI-014 / DISGUISED CUSTOMER AND EXECUTIVE ASSET SUBSTITUTION`.

- Privacy plan: disguise the king's wife from the blind man.
- Information-security dependency: do not account for the system owner telling the blind man exactly who is arriving.
- House compliance result: the only member with a recorded good item is the first completed death.
- Historical performance appraisal: David performed **ONLY RIGHT**, excluding all retained evidence by not excluding it.
- Treasury remediation: replace every stolen gold shield with bronze and keep doing the ceremonial walk.

Captain performs two separate evidence-lick reviews. **YOINK! YOINK!** Nothing changes.

## FIR verification

- FILTER: all 31 markers retained; chapter 15 excluded from story pixels.
- ISOLATE: sickness/disguise/disclosure, mediated house judgment, threshold death/burial, David classification, both reign closures, Judah objects and Shishak treasure transfer.
- RECONSTRUCT: two exact structural recurrences; attempted disguise and bronze substitution remain complete non-contradictory chains.
- VERIFY: two inert SKIPs, two separate YOINKs, no divine body, no invented child guilt, disguise failure mechanism, battle, sexual act or future fulfilment, story-only pixels.

## Required compound-eye facets

1. Abijah child becomes sick.
2. Jeroboam orders wife disguise/Shiloh journey.
3. Ahijah former kingship saying and child inquiry purpose.
4. Ten loaves/cakes/honey carrier.
5. Wife disguises and reaches blind Ahijah's house.
6. Direct LORD disclosure of her identity/purpose/pretense.
7. Ahijah hears feet and names Jeroboam's wife.
8. Heavy-news opening and wife-as-message-carrier route.
9. LORD exalted Jeroboam/made prince speech.
10. Kingdom torn/given and David absolute-rightness claim; S218 SKIP/YOINK.
11. Jeroboam molten-image/other-gods acts stated.
12. House cut-off/sweep-away future speech.
13. Dog/city and bird/field future classes.
14. Threshold-entry child-death trigger.
15. Only-good-member/grave/mourning speech; S127 SKIP/YOINK.
16. Future king/house cut-off speech retained as future.
17. Future Israel reed/uproot/scatter/Asherah causal speech.
18. Wife returns/threshold reached/child dies.
19. Israel burial/mourning according mediated word.
20. Jeroboam chronicle pointer/reign 22/death/Nadab succession.
21. Rehoboam age 41/reign 17/Jerusalem/Naamah identity.
22. Judah evil/jealousy narrator classification.
23. High places/pillars/Asherah objects built.
24. Verse-24 source-defined land class without invented individual act.
25. Fifth-year Shishak comes against Jerusalem.
26. LORD-house/king-house treasures taken.
27. Solomon gold shields taken.
28. Rehoboam bronze replacement shields/guard assignment.
29. King-entry shield carry/guardroom return cycle.
30. Rehoboam chronicle pointer/continual Jeroboam war.
31. Rehoboam death/burial/Naamah repeat/Abijam succession.

All thirty-one facets appear simultaneously.

## Production boundary

One high-resolution 31-facet compound-eye image. `NOT-` identities and Joe faces for every living thing. Shields, pillars, poles, bread, honey and other objects are nonliving and faceless. Exact two inert SKIPs and two separate boilless Captain poke/lick/YOINK/walk-away carriers. No divine body. Verse 24 is restrained and non-explicit. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
