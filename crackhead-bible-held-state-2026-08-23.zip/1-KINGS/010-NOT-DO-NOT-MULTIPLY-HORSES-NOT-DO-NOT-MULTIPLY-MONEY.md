# CRACKHEAD 1 KINGS 10

## Title field

**NOT-SOLOMON: SKIP—DO NOT MULTIPLY HORSES. / 1,400 CHARIOTS, 12,000 HORSEMEN, IMPORTED FROM EGYPT. / DO NOT GREATLY MULTIPLY SILVER AND GOLD. / SILVER IS BASICALLY ROCKS NOW.**

Source parent: ENGWEBP 1 Kings chapter 10, verses 1-29, USFM. Prepared evidence: `.chapter-work/CHB-1KI-010/job.json` and `source.usfm`. Parent: 1 Kings 9 plus the retained royal limits in Deuteronomy 17 and later-found `S230-E001-1KI4`. Exact identities remain evidence; visible names use `NOT-`. Every living human, animal and plant is Joe-faced. Manufactured lions, throne, shields and vessels remain nonliving.

CrackFlix: recurring `S230-E002-1KI10` with exact inert `SKIP -> S230-E001-1KI4`, plus new `S231-E001-1KI10` with no SKIP. Exactly two separate causally-null post-closure Captain YOINKs. One high-resolution compound-eye field.

## Causal foundation

```text
QUEEN OF SHEBA HEARS / ARRIVES / TESTS SOLOMON
-> SOLOMON ANSWERS / QUEEN INSPECTS / CONFIRMS REPORT
-> QUEEN ATTRIBUTES KINGSHIP/JUSTICE TO LORD
-> MUTUAL ROYAL GIFTS / QUEEN RETURNS HOME
-> OPHIR MATERIALS BECOME PILLARS + INSTRUMENTS
-> ANNUAL GOLD = 666 TALENTS PLUS TRADE/TRIBUTE
-> GOLD SHIELDS + IVORY/GOLD THRONE + GOLD VESSELS
-> SILVER CONSIDERED LITTLE VALUE / MADE COMMON AS STONES
-> S231 CLOSES / YOINK CHANGES NOTHING
-> THREE-YEAR FLEET + WORLDWIDE RICHES/WISDOM/TRIBUTE CLAIMS
-> 1,400 CHARIOTS + 12,000 HORSEMEN
-> HORSES IMPORTED FROM EGYPT / HORSES + CHARIOTS EXPORTED
-> S230 RECURS / SKIP POINTS TO 1 KINGS 4 / YOINK CHANGES NOTHING
```

## Verses 1–10 — Queen of Sheba tests the report

The queen of Sheba hears Solomon's fame concerning LORD's name and arrives with hard questions, a great caravan, camels, spices, much gold and precious stones. She speaks all that is in her heart; Solomon answers every question, with nothing reported hidden from him.

She sees his wisdom, house, table food, servant seating, official attendance and clothing, cupbearers and ascent to LORD's house. The source says no spirit remains in her; no death, fainting, private emotion mechanism or disembodied entity is inferred. She calls the earlier report true, says she withheld belief until seeing, says less than half was reported, calls the attendants happy, and attributes Solomon's throne, justice and righteousness role to LORD's delight and lasting love of Israel.

She gives Solomon 120 talents of gold, exceptional spices and precious stones. Her attribution is human speech, not a newly narrated divine act.

## Verses 11–13 — Ophir materials and return gifts

Hiram's fleet also brings almug wood and precious stones from Ophir. Solomon turns the wood into pillars for both houses and harps/stringed instruments for singers. Narrator says no comparable almug supply had come or been seen to that day. Solomon gives the queen everything she desires and asks plus royal bounty; she and her servants return home. Gift contents beyond the source inventory and any trade balance remain unresolved.

## Verses 14–22 — The money pile

Solomon receives 666 talents of gold in one year, apart from traders, merchants, mixed-people kings and governors. He makes two hundred beaten-gold bucklers at six hundred shekels each and three hundred beaten-gold shields at three minas each, storing them in the Forest House.

He makes a great ivory throne overlaid with finest gold, six steps, rounded back, armrests, two manufactured lions beside the arms and twelve manufactured lions along the steps. All drinking vessels and Forest House vessels are gold; none are silver because silver is considered of little value. A joint Tarshish fleet returns every three years with gold, silver, ivory, apes and peacocks.

The retained king rule at Deuteronomy 17:17 says the king shall not greatly multiply silver and gold for himself. This closes `S231-E001-1KI10`: the same addressed royal office receives vast annual gold plus other revenue, manufactures gold prestige objects and makes silver as common as stones in verse 27. No limit, exception or repeal is supplied. One separate Captain poke/lick/**YOINK!**/walk-away changes nothing.

## Verses 23–29 — All-earth claims and horse recurrence

Narrator says Solomon exceeds all earth's kings in riches and wisdom, all earth seeks his presence to hear God-attributed wisdom, and each visitor brings annual tribute: silver/gold vessels, clothing, armor, spices, horses and mules. These are narrator scope claims; exact census and comparison method remain unresolved rather than silently universalized.

Solomon gathers 1,400 chariots and 12,000 horsemen in chariot cities and Jerusalem. He makes silver common as stones and cedars common as lowland sycamores. His horses are brought from Egypt in merchant droves at a price. Chariots cost six hundred silver shekels and horses one hundred fifty; merchants export them to Hittite and Syrian kings.

This closes recurring `S230-E002-1KI10` against Deuteronomy 17:16. The retained rule says a king shall not multiply horses and shall not return people through Egypt to multiply them. The chapter records large capacity and an Egypt import/export route. `SKIP -> S230-E001-1KI4` points to the earlier forty-thousand-stall/twelve-thousand-horsemen occurrence, omits only its explanation and removes nothing. A separate Captain poke/lick/**YOINK!**/walk-away follows this closure and changes nothing.

## God-line boundary

No direct God speech or new narrator-performed divine act occurs. The queen attributes LORD's delight, Solomon's enthronement, Israel's lasting love relation and Solomon's justice purpose to LORD. Narrator attributes Solomon's heart-wisdom to God. These remain human attribution and narrator attribution respectively. No divine body or mechanism is supplied.

## Character and world-ledger changes

- NOT-QUEEN-OF-SHEBA enters, tests Solomon, inspects visible State, revises her report assessment, gives material and returns home.
- NOT-SOLOMON answers, receives/gives gifts, manufactures prestige objects, accumulates annual wealth, hosts visitors and expands horse/chariot trade.
- NOT-HIRAM-KING's fleet continues Ophir/Tarshish material transport.
- NOT-SERVANTS, NOT-SINGERS, NOT-MERCHANTS, NOT-SAILORS and visiting NOT-JOES retain only observed roles.
- Living camels, horses, mules, apes and peacocks are Joe-faced; ivory/material origin does not create a living carrier.
- Manufactured throne lions are visibly objects and never Joe-faced.

## Bullshit pass

Issue `1KI-010 / ROYAL COMPLIANCE DASHBOARD`. Horse limit: **SKIP**. Money limit: annual intake **666 TALENTS PLUS THE OTHER MONEY**, gold shields, gold cups, gold chair, silver downgraded to landscaping aggregate. Compliance report generated by Captain: **YOINK! YOINK!** Nothing filed.

## FIR verification

- FILTER: all 29 markers retained; chapter 11 excluded from story content and held only in machine State.
- ISOLATE: queen test/inspection/speech/gifts, Ophir materials, annual wealth, gold objects/throne/vessels, fleets/tribute, horse inventory and Egypt trade.
- RECONSTRUCT: S230 horse-limit recurrence points exactly to found E001; S231 wealth-limit mismatch is a distinct contradiction type.
- VERIFY: two episodes, one exact noncausal SKIP, two separate YOINKs, no divine body, manufactured figures nonliving, no motive/comparison method invented. Workflow metadata is excluded from comic pixels.

## Required compound-eye facets

1. Queen hears fame concerning LORD name/comes with hard questions.
2. Great caravan/camels/spices/gold/stones/all-heart speech.
3. Solomon answers all/nothing hidden.
4. Queen sees wisdom and built house.
5. Food/seating/attendance/clothing/cupbearers/ascent/no-spirit-left wording.
6. Queen calls report true.
7. Prior disbelief/eyes see/less than half told/wisdom prosperity exceed fame.
8. Happy men/servants/hear wisdom.
9. Queen's LORD-delight/throne/love/justice attribution.
10. Queen gives 120 talents gold/spices/stones.
11. Hiram fleet brings Ophir gold/almug/stones.
12. Almug pillars/instruments/no-such-wood-to-date.
13. Solomon gives all desire/asks/bounty; queen returns.
14. Annual 666 talents gold.
15. Additional traders/merchants/kings/governors revenue.
16. Two hundred gold bucklers/600 shekels each.
17. Three hundred gold shields/three minas/Forest House.
18. Ivory throne/finest-gold overlay.
19. Six steps/rounded back/armrests/two manufactured lions.
20. Twelve manufactured step lions/nothing-like kingdom claim.
21. Gold vessels/no silver/little-value claim; S231 closure/YOINK relation continues to F27.
22. Three-year Tarshish fleet/gold-silver-ivory-apes-peacocks.
23. Solomon exceeds all kings in riches/wisdom claim.
24. All-earth seekers/God-attributed heart wisdom.
25. Annual tribute inventory.
26. 1,400 chariots/12,000 horsemen; `S230-E002`, inert `SKIP -> S230-E001`, horse YOINK.
27. Silver common as stones/cedar as sycamores; visible S231 wealth closure/YOINK.
28. Egypt horse imports/merchant droves/prices.
29. 600-shekel chariot/150-shekel horse/Hittite-Syria exports.

All twenty-nine facets appear simultaneously.

## Production boundary

One high-resolution 29-facet compound-eye image. `NOT-` display; every living thing Joe-faced; manufactured throne lions and all objects remain nonliving/faceless. Exact `S230-E002-1KI10` with visible inert `SKIP -> S230-E001-1KI4`; exact `S231-E001-1KI10` with no SKIP; exactly two separate post-closure Captain poke/lick/YOINK/walk-away carriers. No divine body. The image is the finished comic: no review/publication/job/hash/path/validation/instruction/next-source metadata may appear in its pixels.

*shrug*

OK.
