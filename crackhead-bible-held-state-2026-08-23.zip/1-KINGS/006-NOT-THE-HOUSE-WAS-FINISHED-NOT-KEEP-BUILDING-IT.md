# CRACKHEAD 1 KINGS 6

## Title field

**NOT-SOLOMON: THE HOUSE WAS FINISHED. / ALSO NOT-SOLOMON: KEEP BUILDING THE HOUSE. / SKIP: IT IS FINISHED AGAIN.**

Source parent: ENGWEBP 1 Kings chapter 6, verses 1-38, USFM. Prepared evidence: `.chapter-work/CHB-1KI-006/job.json` and `source.usfm`. Parent: 1 Kings 5. Exact identities remain evidence; visible names use `NOT-`. Every living human, animal and plant is Joe-faced. Wooden cherubim, carved palms/flowers and construction materials are nonliving carriers and do not receive faces merely from their forms.

CrackFlix: new series `S227`, episodes `S227-E001-1KI6` and `S227-E002-1KI6`. The second recurrence uses one exact inert `SKIP -> S227-E001-1KI6`. Exactly two separate causally-null post-closure YOINKs. One high-resolution compound-eye field.

## Causal foundation

```text
YEAR 480 AFTER EGYPT EXIT / SOLOMON YEAR 4 / ZIV
-> HOUSE BUILD BEGINS
-> EXTERIOR DIMENSIONS / PORCH / WINDOWS / SIDE FLOORS
-> QUARRY-PREPARED STONE / NO IRON TOOL HEARD IN HOUSE
-> ACCESS + STAIRS
-> HOUSE FINISHED
-> MORE FLOORS BUILT
-> LORD WORD: CONDITIONAL ESTABLISHMENT / DWELL / NOT FORSAKE
-> HOUSE FINISHED AGAIN
-> MORE WALLS / SANCTUARY / GOLD / CHERUBIM / CARVINGS / DOORS / COURT BUILT
-> FOUNDATION DATE RESTATED
-> YEAR 11 / BUL / ALL PARTS + SPECIFICATIONS FINISHED
-> SEVEN-YEAR BUILD CLOSE
```

## Verses 1–8 — Date, dimensions and shell

The build begins in year 480 after Israel left Egypt, Solomon's fourth regnal year, month Ziv/second month. The house is sixty by twenty by thirty cubits; the porch is twenty by ten. Fixed-lattice windows, surrounding floors/side rooms, five-six-seven-cubit floor widths, exterior offsets, quarry-prepared stone, silent-on-site iron tools, a right-side door and winding stairs are retained exactly.

No tool being heard **in the house** does not mean no tools were used at the quarry. The supplied preparation location closes that relation without contradiction.

## Verses 9–10 — First finish, immediate continuation

Verse 9 says Solomon **built the house and finished it**, then describes cedar covering. Verse 10 says he **built the floors all along the house**, each five cubits high, resting on cedar timbers.

This closes `S227-E001-1KI6`: **THE HOUSE WAS FINISHED / MORE OF THE HOUSE WAS BUILT.** No completion scope limiting “finished it” to the shell is stated there. One separate Captain poke/lick/**YOINK!**/walk-away changes nothing.

## Verses 11–13 — Direct conditional God speech

LORD's word comes to Solomon. Direct speech concerns the house but makes the result conditional on Solomon walking in statutes, executing ordinances and keeping all commandments. Then God will establish the word spoken to David, dwell among Israel and not forsake Israel. The chapter does not verify Solomon's entire future compliance or the forever outcome.

## Verses 14–22 — Second finish, interior continues

Verse 14 again says Solomon **built the house and finished it**. Verse 15 immediately resumes building/covering interior walls and floor. Verses 16–22 create the twenty-cubit inner sanctuary, forty-cubit front sanctuary, cedar bud/flower surface, ark location, twenty-cubit cube, cedar-covered altar, gold interior/chains and whole-house/altar gold overlay.

This closes `S227-E002-1KI6`, the same **FINISHED / MORE BUILDING** contradiction. `SKIP -> S227-E001-1KI6` points to the exact retained explanation and deletes nothing. A second separate YOINK changes nothing.

## Verses 23–36 — Cherubim, carvings, doors and court

Two ten-cubit-high olive-wood cherubim with five-cubit wings are equal in measure/form, placed wall-to-wall with inner wings touching, and overlaid with gold. They are manufactured objects, not living angels. Walls receive carved cherubim, palm trees and flowers; floors receive gold. Olive-wood and cypress doors, fifth/fourth wall portions, folding leaves, carved/gold surfaces and the inner court's three stone courses plus cedar course are retained.

Plant and angelic imagery does not establish living plant or angel presence. No ark placement occurs yet; verse 19 states preparation **to set** it there.

## Verses 37–38 — Dated all-parts completion

The foundation date is restated as year four, Ziv. In year eleven, Bul/eighth month, the house is finished throughout **all its parts and according to all its specifications**. The stated build duration is seven years. This is the chapter's expressly scoped total completion and is not another contradiction occurrence.

## God-line boundary

Direct God speech appears only in verses 12–13: conditional word-establishment, dwelling among Israel and not forsaking Israel. Narrator supplies only that LORD's word came. The transmission mechanism and divine form are absent. No divine body is rendered. Cherub sculptures do not depict LORD and do not prove living cherub presence.

## Character and world-ledger changes

- NOT-SOLOMON begins and completes the LORD-name house across fourth-to-eleventh-year dates.
- Unnamed builders/workers remain collective living Joe-faced participants; individual task allocation is unresolved.
- Temple shell, floors, sanctuary, gold, cherubim, carvings, doors and court become completed material State.
- The covenant ark remains outside this chapter's performed placement State.
- Two completed/continued contradiction occurrences join one recurring CrackFlix series.

## Bullshit pass

Issue `1KI-006 / FINAL_FINAL_TEMPLE_v3_REAL`. The project is marked **FINISHED**, receives another floor, is marked **FINISHED** again, receives the entire interior, then finally ships **FINISHED THROUGHOUT ALL PARTS AND SPECIFICATIONS** seven years later. On-site noise policy passes because all the hammering happened somewhere else. Foundation unchanged.

## FIR verification

- FILTER: all 38 markers retained; chapter 7 excluded.
- ISOLATE: dated start, dimensions/shell, first finish/continued floor work, conditional divine speech, second finish/continued interior work, furnishings/surfaces and dated total completion.
- RECONSTRUCT: `S227-E001` and recurrent `S227-E002`, with one exact SKIP from E002 to E001.
- VERIFY: two YOINKs; final all-parts finish not duplicated as contradiction; future conditional divine outcome unresolved; no living sculpture inference; publication held.

## Required compound-eye facets

1. 480th year/fourth reign year/Ziv-second month/build begins.
2. House 60x20x30 cubits.
3. Porch 20x10.
4. Fixed-lattice windows.
5. Surrounding floors/side rooms/temple-inner sanctuary.
6. Five-six-seven widths/exterior offsets/no wall beam insertion.
7. Quarry-prepared stone/no iron tool heard in house.
8. Right-side door/winding stairs/middle-to-third.
9. House built/finished/cedar cover; `S227-E001` and first YOINK.
10. More five-cubit floors/cedar support.
11. LORD word comes.
12. Conditional statutes/ordinances/commands/establish-David-word speech.
13. Dwell-among/not-forsake speech.
14. House built/finished again; `S227-E002`, `SKIP -> S227-E001`, second YOINK.
15. More interior cedar walls/cypress floor.
16. Twenty-cubit rear cedar inner sanctuary/most holy.
17. Forty-cubit front sanctuary.
18. Cedar buds/flowers/no visible stone.
19. Inner sanctuary prepared for future ark placement.
20. 20x20x20 sanctuary/pure gold/cedar altar.
21. Interior pure gold/gold chains/sanctuary overlay.
22. Whole house and altar gold/final surface finish.
23. Two olive-wood cherubim/ten cubits high.
24. Five-plus-five wing/ten-cubit span.
25. Equal cherub measure/form.
26. Both cherub heights ten.
27. Wall-to-wall/middle-touching wings.
28. Cherub gold overlay.
29. Wall carvings: cherubim/palms/flowers inside/outside.
30. Gold floor inside/outside.
31. Inner-sanctuary olive doors/fifth wall.
32. Two carved/gold olive doors.
33. Temple olive posts/fourth wall.
34. Two folding cypress doors.
35. Door carvings/gold fitted work.
36. Inner court three cut-stone courses/one cedar course.
37. Foundation laid year four/Ziv.
38. Year eleven/Bul/all parts/specifications finished/seven years; chapter 7 excluded.

All thirty-eight facets appear simultaneously.

## Production boundary

One high-resolution 38-facet compound-eye image. `NOT-` display; every living thing Joe-faced; carved/wooden figures remain visibly manufactured and faceless unless a separate living carrier is present; no divine body. Exactly two episodes, one inert SKIP on E002 pointing to E001, and exactly two separate causally-null post-closure YOINKs. Publication held; originator review required.

*shrug*

OK.
