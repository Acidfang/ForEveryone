# CRACKHEAD 1 KINGS 19

## Title field

**NOT-JEZEBEL: YOU DIE BY TOMORROW. / NOT-ELIJAH: FORTY DAYS LATER, I ONLY AM LEFT. / NOT-LORD: I RESERVED SEVEN THOUSAND.**

Source parent: ENGWEBP 1 Kings chapter 19, verses 1-21, USFM. Prepared evidence: `.chapter-work/CHB-1KI-019/job.json` and `source.usfm`. Parent: 1 Kings 18. Exact identities remain evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: new `S247-E001-1KI19`; recurring `S246-E002-1KI19` with inert `SKIP -> S246-E001-1KI18`; recurring `S246-E003-1KI19` with inert `SKIP -> S246-E002-1KI19`. Exactly three separate causally-null post-closure Captain YOINKs. Two SKIPs. One high-resolution 21-facet compound-eye field.

## Causal foundation

```text
AHAB REPORTS CARMEL/KILLING TO JEZEBEL
-> JEZEBEL: ELIJAH WILL DIE BY TOMORROW
-> ELIJAH FLEES / REQUESTS DEATH / SLEEPS
-> ANGEL TOUCH / FOOD + WATER / SECOND TOUCH
-> ELIJAH EATS / TRAVELS FORTY DAYS AND NIGHTS / REMAINS ALIVE
-> S247 DEADLINE CRACK / YOINK
-> LORD WORD ASKS WHAT HE IS DOING
-> ELIJAH: I ONLY AM LEFT
-> SKIP S246-E001-1KI18 / S246-E002 / YOINK
-> WIND / EARTHQUAKE / FIRE / STILL SMALL VOICE
-> QUESTION REPEATED
-> ELIJAH REPEATS I ONLY AM LEFT
-> SKIP S246-E002-1KI19 / S246-E003 / YOINK
-> LORD ORDERS HAZAEL, JEHU, ELISHA ANOINTINGS
-> FUTURE ESCAPE/KILL CHAIN STATED, NOT PERFORMED
-> LORD: I RESERVED SEVEN THOUSAND WHO DID NOT BOW/KISS BAAL
-> ELIJAH FINDS ELISHA / MANTLE PLACED
-> ELISHA KILLS OXEN / FEEDS PEOPLE / FOLLOWS AND SERVES
```

## Verses 1–4 — “By tomorrow” begins a deadline

Ahab reports to Jezebel all Elijah did and how he killed all the prophets with the sword. This is Ahab's report of the retained Carmel killing.

Jezebel sends a messenger swearing by gods that she will make Elijah's life like one of those prophets by the same time tomorrow. Elijah sees the threat, runs for his life to Beersheba, leaves his servant there, travels another day into the wilderness, sits under a juniper tree and asks LORD to take his life because he is no better than his fathers.

The messenger threat, Elijah's flight and Elijah's death request are distinct speech/act Moments. No death occurs here.

## Verses 5–8 — Eat twice, travel forty days

Elijah sleeps. An angel touches him and says to arise and eat. A cake baked on coals and a jar of water are at his head. He eats, drinks and sleeps again. LORD's angel returns, touches him and tells him to eat because the journey is too great.

Elijah eats and drinks, then travels in the strength of that food forty days and nights to Horeb. The angel has explicit touch/speech agency and is rendered only to the source-supported carrier boundary; no invented divine body. Food provenance and forty-day sustenance mechanism remain unresolved.

Elijah is alive after Jezebel's exact “tomorrow” deadline and remains alive through the forty-day journey. No performance, extension, revocation or failed attempt repairs the deadline. This closes new `S247-E001-1KI19`: **DIE BY TOMORROW / ALIVE FORTY DAYS LATER.** One Captain **YOINK!** changes neither threat nor survival.

## Verses 9–10 — “I only am left,” occurrence two

Elijah camps in a Horeb cave. LORD's word asks what he is doing there. Elijah says he has been jealous for LORD, Israel has forsaken the covenant, thrown down altars and killed prophets, and **“I, even I only, am left.”** He also says they seek his life.

The one hundred hidden LORD prophets from chapter 18 remain retained. No chapter-19 death or declassification removes them before this claim. An inert **SKIP -> S246-E001-1KI18** points to the already explained inventory contradiction without deleting the new utterance. This closes `S246-E002-1KI19`. One Captain **YOINK!** changes nothing.

## Verses 11–14 — Wind, earthquake, fire, voice, same answer

LORD directs Elijah to stand on the mountain. The narrator says LORD passes by; a great wind tears mountains and breaks rocks, but LORD is not in the wind. An earthquake follows, but LORD is not in it. Fire follows, but LORD is not in it. Then comes a still small voice.

Elijah hears, wraps his face in his mantle and stands at the cave entrance. A voice repeats the question. Elijah repeats the same jealousy/covenant/altar/prophet account and again says he alone remains and people seek his life.

Wind, earthquake, fire and voice are separately typed source events. “Not in” is retained exactly; no visual body or spatial theology is invented. The repeated answer is a new speech occurrence, not the prior words replayed. An inert **SKIP -> S246-E002-1KI19** points backward; `S246-E003-1KI19` closes at the still-retained prophet inventory. One separate Captain **YOINK!** changes nothing.

## Verses 15–18 — Three appointments, future sword chain, seven thousand retained

LORD tells Elijah to return toward Damascus and anoint Hazael king over Syria, Jehu king over Israel and Elisha prophet in Elijah's place. LORD states a future chain: Jehu will kill one escaping Hazael's sword, and Elisha will kill one escaping Jehu's sword. No appointment, sword escape or killing in that chain is performed in verses 15–18.

LORD then says: **“Yet I reserved seven thousand in Israel,”** whose knees did not bow and mouths did not kiss Baal. This directly supplies a retained population incompatible with Elijah's repeated unqualified one-left count. It strengthens the evidence for S246 but is not a fourth Elijah utterance or a separate Captain occurrence.

The exact identities and relation between the seven thousand and Obadiah's one hundred remain unresolved; neither population is silently merged.

## Verses 19–21 — Mantle, oxen, meal, service

Elijah departs and finds Elisha plowing with twelve yoke of oxen, Elisha at the twelfth. Elijah puts his mantle on him. Elisha leaves the oxen, runs after Elijah and asks to kiss his parents before following. Elijah tells him to return and asks what he has done to him.

Elisha returns, takes the yoke of oxen, kills them, boils their meat using the equipment, gives it to the people, and they eat. He then follows and serves Elijah. The oxen are living Joe-faced participants before death; the meal and equipment are nonliving afterward. The mantle act and later service are observed, but the source does not explicitly call this anointing, so the exact command-performance relation remains unresolved rather than silently closed.

## God-line boundary

- LORD's angel has explicit touch/speech carrier acts; render only that source-supported carrier, not an invented God body.
- LORD word/question, mountain instruction and Hazael/Jehu/Elisha commands are direct speech.
- LORD passing, wind/earthquake/fire distinctions, still small voice and seven-thousand statement retain exact source attribution without invented form or mechanism.
- Jezebel's death deadline and Elijah's claims are participant speech, not divine facts.
- The future sword chain remains future speech; no execution is depicted.

## Character and world-ledger changes

- NOT-ELIJAH JOE flees, requests death, receives two food/touch events, travels forty days, twice repeats his only-left claim, receives commands, finds Elisha and gains a serving follower.
- NOT-JEZEBEL JOE issues a one-day death deadline that does not perform within the retained State.
- NOT-AHAB JOE reports Carmel events; no further act is supplied.
- NOT-ANGEL JOE has two explicit touch/speech visits; exact appearance and food production remain unresolved.
- NOT-ELISHA JOE moves from plowing to mantle recipient, household farewell request, ox-meal provider and Elijah servant.
- NOT-HAZAEL and NOT-JEHU remain future appointment/kill-chain identities; no anointing or killing is imported.
- Seven thousand retained Israel Joes remain a source-defined group with individual identities unresolved.

## Bullshit pass

Issue `1KI-019 / TERMINATION DEADLINE AND HEADCOUNT RECONCILIATION`.

- Management promise: employee dead by tomorrow.
- Employee response: run away, request own termination, sleep through onboarding.
- Support ticket: **ARISE AND EAT**—twice.
- Deadline audit: employee still alive forty days later.
- Staffing report, attempt one: **ONLY ME LEFT.** Existing cache: 100.
- Staffing report, attempt two: **ONLY ME LEFT.** System response: **7,000 RESERVED.**
- Succession process: throw coat on farmer; farmer burns farming equipment to cook the workforce and joins support.

Captain services the missed deadline and both repeated headcount claims separately. **YOINK! YOINK! YOINK!** Nothing changes.

## FIR verification

- FILTER: all 21 markers retained; chapter 20 excluded from story pixels.
- ISOLATE: report/threat/flight, death request, two angel-food visits, forty-day route, two question-answer cycles, wind/earthquake/fire/voice sequence, appointments/future chain, seven thousand and Elisha transition.
- RECONSTRUCT: new S247 deadline failure plus two recurring S246 one-left utterances against retained 100/7000.
- VERIFY: two inert SKIPs, three distinct YOINKs, no divine body, invented angel form, food/sustenance mechanism, completed future killing, merged populations or graphic animal killing.

## Required compound-eye facets

1. Ahab reports Elijah/Carmel killings to Jezebel.
2. Jezebel messenger: death by tomorrow deadline.
3. Elijah sees/runs to Beersheba/leaves servant.
4. Wilderness/juniper/death request.
5. Sleep/first angel touch/arise-and-eat.
6. Cake/water/eat/drink/sleep again.
7. Second angel touch/eat for journey.
8. Food strength/forty-day Horeb route; S247 YOINK.
9. Cave/LORD word asks why here.
10. First only-left account; S246 E002 SKIP/YOINK.
11. Stand before LORD/wind breaks rocks/LORD not in wind/earthquake distinction.
12. Fire distinction/still small voice.
13. Mantle over face/cave entrance/repeated question.
14. Repeated only-left account; S246 E003 SKIP/YOINK.
15. Return/Damascus/Hazael anointing command.
16. Jehu/Elisha anointing commands.
17. Future Hazael-to-Jehu-to-Elisha sword chain.
18. LORD states seven thousand reserved.
19. Elijah finds plowing Elisha/places mantle.
20. Elisha follows/parent-kiss request/Elijah response.
21. Elisha kills oxen/cooks/feeds people/follows/serves, restrained.

All twenty-one facets appear simultaneously.

## Production boundary

One high-resolution 21-facet compound-eye image. `NOT-` identities and Joe faces for every living thing, including angel and oxen at living Moments. Objects and animal remains are nonliving/faceless. Two exact inert S246 SKIPs and exactly three separate boilless Captain poke/lick/YOINK/walk-away carriers. Restrained death request and oxen killing. Future sword killings are text-only/unperformed. No divine body. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
