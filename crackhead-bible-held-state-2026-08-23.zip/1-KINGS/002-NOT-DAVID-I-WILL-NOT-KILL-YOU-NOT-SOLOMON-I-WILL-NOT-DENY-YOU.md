# CRACKHEAD 1 KINGS 2

## Title field

**NOT-DAVID: I WILL NOT PUT YOU TO DEATH. / ALSO NOT-DAVID: BRING HIM DOWN WITH BLOOD. / NOT-SOLOMON: I WILL NOT DENY YOU.**

Source parent: ENGWEBP 1 Kings chapter 2, verses 1-46, USFM. Prepared evidence: `.chapter-work/CHB-1KI-002/job.json` and `source.usfm`. Parent: 1 Kings 1. Exact identities remain evidence; visible names use `NOT-`. Every living thing, including Shimei's donkey, is Joe-faced. Death and burial remain restrained/non-graphic.

CrackFlix: new `S222-E001-1KI2`, `S223-E001-1KI2`, and `S224-E001-1KI2`; no SKIPs. Exactly three separate causally-null post-closure YOINKs. One high-resolution compound-eye field.

## Causal foundation

```text
DAVID NEARS DEATH
-> INSTRUCTS SOLOMON: LAW / JOAB / BARZILLAI SONS / SHIMEI
-> RECOUNTS I-WILL-NOT-KILL-SHIMEI OATH
-> ORDERS SHIMEI BROUGHT DOWN WITH BLOOD
-> DAVID DIES / 40-YEAR REIGN CLOSE
-> ADONIJAH REQUESTS ABISHAG THROUGH BATHSHEBA
-> SOLOMON: I WILL NOT DENY YOU
-> REQUEST SPOKEN
-> SOLOMON DENIES / ORDERS ADONIJAH KILLED
-> ABIATHAR EXILED
-> JOAB HOLDS ALTAR / SOLOMON ORDERS DEATH / BENAIAH KILLS
-> BENAIAH + ZADOK REPLACE JOAB + ABIATHAR
-> SOLOMON CONFINES SHIMEI WITH DEATH CONDITION
-> SHIMEI: I WILL DO IT
-> THREE YEARS / SHIMEI LEAVES FOR GATH AND RETURNS
-> SOLOMON RECITES CONDITION / ORDERS DEATH
-> KINGDOM ESTABLISHED
```

## Verses 1–4 — David's law instruction

Near death, David tells Solomon to be strong, keep LORD's instruction and Moses' law so he may prosper, and recounts a conditional throne promise for careful, whole-hearted descendants. The divine speech is David's report, not independently narrated direct speech in this chapter.

## Verses 5–9 — Joab, Barzillai's sons and Shimei

David recounts Joab killing Abner and Amasa and tells Solomon not to let Joab die in peace. He orders kindness/table access for Barzillai's sons.

David then recounts Shimei's curse and his own LORD-oath: **“I will not put you to death with the sword.”** He immediately tells Solomon not to hold Shimei guiltless and to bring his gray head to Sheol **with blood**.

This closes `S222-E001-1KI2`: **I WILL NOT PUT YOU TO DEATH / MY SUCCESSOR WILL BRING YOU DOWN WITH BLOOD.** The different executor does not erase David's observable succession instruction toward the promised outcome. No SKIP. One separate YOINK changes nothing.

## Verses 10–12 — David dies / Solomon established

David dies and is buried. His reign is recorded as forty years: seven Hebron and thirty-three Jerusalem. Solomon sits on David's throne and the kingdom is firmly established. Bathsheba's prior “live forever” speech remains contradicted by this observed death, but it is the already-addressed `S221-E001-1KI1` occurrence; no new episode is created merely for its later outcome.

## Verses 13–25 — Adonijah's petition and death

Adonijah tells Bathsheba he comes peaceably, says the kingdom was his but became Solomon's from LORD, and asks her to request Abishag as wife. His private motive and the truth of “all Israel” are unresolved.

Bathsheba agrees to carry the request. Solomon rises, bows, seats her at his right hand. She asks one small petition and says do not deny her. Solomon replies: **“I will not deny you.”** She states the Abishag request. Solomon interprets it as asking for the kingdom, swears Adonijah spoke against his life, declares death that day and sends Benaiah; Adonijah dies.

This closes `S223-E001-1KI2`: **I WILL NOT DENY YOU / PETITION SPOKEN / DENIED WITH EXECUTION.** Solomon's interpretation is retained as his speech, not converted into Adonijah's hidden motive. No SKIP. One separate YOINK changes nothing.

The chapter-one worthy/wicked conditional is not contradicted: Solomon explicitly uses this later word as his wickedness/death selector.

## Verses 26–35 — Abiathar and Joab

Solomon calls Abiathar worthy of death but spares him at that time because of ark-bearing/shared affliction, removes him from priesthood and sends him to Anathoth. Narrator links this to an earlier LORD word concerning Eli; the mechanism is narrator attribution.

Joab hears, flees to LORD's Tent and holds altar horns. Solomon orders Benaiah to kill him. Joab refuses to leave and says he will die there. Benaiah reports the response; Solomon tells him to comply, kill and bury Joab, attributing the judgment to Abner/Amasa blood. Benaiah kills and buries Joab. Solomon appoints Benaiah over the army and Zadok as priest. Sanctuary protection is not asserted by this chapter, so its absence is not manufactured as contradiction.

## Verses 36–46 — Shimei's accepted boundary and breach

Solomon confines Shimei to Jerusalem and states that leaving/crossing Kidron means certain death. Shimei says: **“What you say is good… so will your servant do.”** He remains many days.

After three years, two slaves run to Gath. Shimei saddles his Joe-faced donkey, leaves, retrieves them and returns. Solomon recites the oath and warning, asks why it was not kept, joins David's earlier grievance, attributes returned wickedness to LORD, and orders Benaiah to kill him. Benaiah does; the kingdom is established.

This closes `S224-E001-1KI2`: **I WILL STAY / I LEFT AND RETURNED.** The slave flight explains the trip's addressed object but does not make the accepted condition disappear. No SKIP. One separate YOINK changes nothing.

## God-line boundary

No direct God speech occurs. David reports prior divine law/promise; Solomon and others swear or attribute establishment, judgment, blessing and throne endurance to LORD; narrator attributes Abiathar's removal to fulfilment of an earlier word. These carriers remain typed. No divine body or causal confirmation is invented.

## Character and world-ledger changes

- NOT-DAVID gives final instructions, dies and is buried.
- NOT-SOLOMON orders Adonijah and Joab killed, removes Abiathar, installs Benaiah/Zadok, confines and later executes Shimei.
- NOT-BATHSHEBA carries Adonijah's petition without private motive supplied.
- NOT-ADONIJAH, NOT-JOAB and NOT-SHIMEI die; NOT-ABIATHAR lives in removed/exiled state.
- NOT-BENAIAH becomes army commander; NOT-ZADOK becomes priest in Abiathar's place.

## Bullshit pass

Issue `1KI-002 / I WON'T KILL YOU — SUCCESSION SERVICES AVAILABLE`. Crackhead Royal Customer Service promises **WE WILL NOT DENY YOUR PETITION** before opening it. Jerusalem's three-year geofence uses one donkey and no GPS. Altar Horn Premium does not include murder protection. Foundation unchanged.

## FIR verification

- FILTER: all 46 markers retained; chapter 3 excluded.
- ISOLATE: David instructions/death, Adonijah petition, Abiathar removal, Joab death, Shimei condition/breach/death.
- RECONSTRUCT: S222 proxy-death promise mismatch; S223 promise/petition mismatch; S224 accepted-condition/action mismatch.
- VERIFY: zero SKIPs, three YOINKs, motives and divine mechanisms unresolved; publication held.

## Required compound-eye facets

1. David near death/commands Solomon.
2. Way of all earth/be strong.
3. Keep law/prosper condition.
4. Reported careful-descendant throne promise.
5. Joab Abner/Amasa blood history.
6. Do not let Joab die in peace.
7. Barzillai sons kindness/table.
8. David recounts Shimei curse and I-will-not-kill oath.
9. David orders Shimei brought down with blood; `S222-E001` and first YOINK.
10. David death/burial.
11. Forty years = seven + thirty-three.
12. Solomon throne/kingdom established.
13. Adonijah peaceably approaches Bathsheba.
14. Something-to-say exchange.
15. Kingdom-was-mine/turned/LORD attribution.
16. One petition/do-not-deny.
17. Abishag-wife request through Bathsheba.
18. Bathsheba agrees.
19. Solomon bows/two thrones.
20. Small petition / Solomon “I will not deny you.”
21. Abishag request spoken.
22. Solomon kingdom interpretation.
23. Solomon oath/word-against-life.
24. Adonijah death declaration; `S223-E001` relation.
25. Benaiah kills Adonijah; second YOINK.
26. Abiathar worthy-death but spared/exiled reasoning.
27. Abiathar removed/Eli-word attribution.
28. Joab Adonijah history/altar horns.
29. Solomon sends Benaiah kill order.
30. Come-out refusal/die-here/report.
31. Solomon comply/kill/bury/remove blood speech.
32. Abner/Amasa attribution/David unaware claim.
33. Joab-offspring blood/David-house peace speech.
34. Benaiah kills/buries Joab.
35. Benaiah/Zadok appointments.
36. Shimei Jerusalem confinement.
37. Leaving/Kidron/death condition.
38. Shimei accepts and promises compliance.
39. Three years/two slaves at Gath.
40. Shimei donkey/Gath/retrieval/return.
41. Solomon receives report.
42. Solomon recites warning and Shimei agreement.
43. Why-not-kept question.
44. Solomon joins prior wickedness attribution.
45. Solomon blessing/forever-throne speech.
46. Benaiah kills Shimei/kingdom established; `S224-E001` and third separate YOINK; chapter 3 excluded.

All forty-six facets appear simultaneously.

## Production boundary

One high-resolution 46-facet compound-eye image. `NOT-` display; every living thing Joe-faced; death/burial restrained; no divine body. Exactly three new episodes, zero SKIPs and exactly three separate causally-null post-closure YOINKs. Publication held; originator review required.

*shrug*

OK.
