# CRACKHEAD 1 KINGS 15

## Title field

**NOT-ASA: DEDICATED SILVER AND GOLD IN. / NOT-ASA: TAKE ALL SILVER AND GOLD OUT. BREAK HIS TREATY. / NOT-BAASHA: DESTROY THEM FOR JEROBOAM'S SIN. DO JEROBOAM'S SIN.**

Source parent: ENGWEBP 1 Kings chapter 15, verses 1-34, USFM. Prepared evidence: `.chapter-work/CHB-1KI-015/job.json` and `source.usfm`. Parent: 1 Kings 14. Exact identities remain evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: new `S241-E001-1KI15`; recurring `S127-E010-1KI15` with inert `SKIP -> S127-E009-1KI14`; new `S242-E001-1KI15`. Exactly three separate causally-null post-closure Captain YOINKs. One high-resolution 34-facet compound-eye field.

## Causal foundation

```text
ABIJAM REIGNS THREE YEARS / SINS / DIES
-> DAVID CLAIM NOW EXPLICITLY EXCEPTS URIAH MATTER
-> ASA REIGNS FORTY-ONE YEARS
-> REMOVES SOURCE-DEFINED LAND CLASS + IDOLS
-> REMOVES MAACAH / DESTROYS HER IMAGE
-> HIGH PLACES REMAIN / ASA HEART CALLED PERFECT
-> DEDICATED SILVER + GOLD ENTER LORD HOUSE
-> BAASHA BUILDS RAMAH BLOCKADE
-> ASA TAKES ALL LORD-HOUSE SILVER + GOLD LEFT
-> PAYS BEN HADAD TO BREAK TREATY
-> S241 / YOINK
-> SYRIAN ATTACK / BAASHA STOPS RAMAH
-> JUDAH REUSES RAMAH STONE + TIMBER
-> ASA DIES / JEHOSHAPHAT REIGNS
-> NADAB REIGNS / BAASHA KILLS HIM
-> BAASHA KILLS ALL JEROBOAM HOUSE FOR JEROBOAM SINS
-> S127 RECURS / SKIP / YOINK
-> BAASHA DOES EVIL / WALKS JEROBOAM WAY
-> S242 / YOINK
```

## Verses 1–8 — NOT-Abijam and the exception that finally exists

In Jeroboam's eighteenth year Abijam begins a three-year reign over Judah. His mother is Maacah daughter of Abishalom. He walks in all the sins of his father and his heart is not perfect with LORD as David's heart was. For David's sake, narrator says LORD gives Abijam a lamp in Jerusalem by establishing his son and Jerusalem.

Verse 5 says David did what was right and did not turn from anything commanded all his life, **except only in the matter of Uriah the Hittite.** Unlike the absolute “did only right” statement in chapter 14, this occurrence supplies an explicit exception addressing retained Uriah history. It does not erase the prior contradiction Moment, but this later statement is not itself routed as a crack.

War between Rehoboam and Jeroboam is repeated as a historical State. Abijam's other acts and his war with Jeroboam are addressed to the Judah chronicle. Abijam dies, is buried in David's city and his son Asa succeeds him.

## Verses 9–15 — Remove idols, retain high places, dedicate the inventory

Asa begins reigning in Jeroboam's twentieth year and reigns forty-one years in Jerusalem. His mother is again identified as Maacah daughter of Abishalom. Asa is classified as doing right like David. He removes the source-defined verse-12 land class and all idols made by his fathers. No individual identity, private act or explicit sexual depiction is invented for that class.

Asa removes Maacah from being queen because she made an abominable image for an Asherah. He cuts it down and burns it at Kidron. The high places are not taken away; nevertheless Asa's heart is classified as perfect with LORD all his days. The text explicitly distinguishes unreformed place-State from heart-State with **nevertheless**; no equivalence is invented to force a contradiction.

Asa brings into LORD's house his father's dedicated things and his own dedicated things: silver, gold and utensils. Their dedicated identity and LORD-house destination become retained property State.

## Verses 16–24 — Pay a treaty breaker with the dedicated treasury

Asa and Baasha king of Israel have war all their days. Baasha builds Ramah to prevent movement into or out of Asa's Judah. Asa then takes **all the silver and gold left in the treasures of LORD's house and the king's house**, puts it in his servants' hands and sends it to Ben Hadad king of Syria.

Asa proposes a treaty like their fathers' treaty, calls the silver and gold a present and explicitly orders Ben Hadad to **break your treaty with Baasha** so Baasha will depart. Ben Hadad listens, sends army captains against Israel and strikes Ijon, Dan, Abel Beth Maacah, Chinneroth and Naphtali. Baasha hears, stops building Ramah and remains in Tirzah.

The dedicated silver/gold entered LORD's house with no intervening exit supplied. Asa later takes all silver/gold left in that treasury and uses it as payment for an expressly requested treaty breach and attack. Whatever dedicated inventory remained is included by **all left**; no release, reclassification or authority bridge is supplied. This closes new `S241-E001-1KI15`. One Captain **YOINK!** changes no dedication, transfer, bargain or attack.

Asa proclaims to all Judah with nobody exempt. They carry Ramah's stone and timber away and Asa uses it to build Geba and Mizpah. This is an explicit material-reuse chain, not a contradiction.

Asa's remaining acts, might and cities are addressed to Judah's chronicle. In old age he has diseased feet. He dies, is buried in David's city and his son Jehoshaphat succeeds him. No medical or causal relation between the disease and prior acts is invented.

## Verses 25–31 — Jeroboam's house pays for Jeroboam

Nadab son of Jeroboam begins a two-year Israel reign in Asa's second year and walks in his father's sin. Baasha son of Ahijah of Issachar conspires against him and strikes him at Gibbethon while Nadab and Israel besiege it. In Asa's third year Baasha kills Nadab and reigns in his place.

As soon as Baasha is king, he strikes all Jeroboam's house and leaves nobody who breathes until it is destroyed. Narrator classifies this as according to LORD's saying through Ahijah **for the sins of Jeroboam** by which Jeroboam made Israel sin.

The declared producing acts belong to Jeroboam, while Baasha kills every breathing member of Jeroboam's house. The chapter supplies no producing act for each additional killed person. This repeats `S127-E010-1KI15`. `SKIP -> S127-E009-1KI14` points to the preceding Jeroboam-act/additional-house-member punishment structure and deletes no killing. A second Captain **YOINK!** changes nothing.

## Verses 32–34 — Destroy the house for the pattern; retain the pattern

The Asa-Baasha war State is repeated, not a second war occurrence. Baasha reigns over Israel in Tirzah for twenty-four years. The chapter closes by saying he does evil and walks in Jeroboam's way and sin by which Jeroboam made Israel sin.

Baasha has just destroyed Jeroboam's whole house in a narrated fulfilment explicitly attributed to Jeroboam's sin, then becomes the next king performing that same Jeroboam sin pattern. No repentance, exception or different-act bridge is supplied. This closes new `S242-E001-1KI15`. A third Captain **YOINK!** changes nothing.

## God-line boundary

- Verses 4–5 are narrator attributions about LORD's David-sake lamp act and David's life classification, not new direct divine speech.
- Verse 29 classifies Baasha's destruction as according to LORD's saying spoken through Ahijah; the earlier mediated speech remains its parent rather than a replayed divine voice.
- Jeroboam-provoked anger is narrator causal attribution; its mechanism is unresolved.
- No divine body, new divine command, approval of Asa's treaty payment or approval of Baasha's own later pattern is invented.

## Character and world-ledger changes

- NOT-ABIJAM reigns three years, retains the father-sin classification, dies and is succeeded by NOT-ASA.
- NOT-ASA removes people/objects, removes NOT-MAACAH from queen status, retains high places, dedicates inventory, later spends all remaining treasury silver/gold, reuses Ramah materials, develops foot disease, dies and is succeeded by NOT-JEHOSHAPHAT.
- NOT-MAACAH makes one image and loses queen status; no motive or additional act is invented.
- NOT-BEN-HADAD accepts Asa's present/request, breaks the Baasha treaty and sends the performed city attacks.
- NOT-NADAB reigns two years, besieges Gibbethon and is killed by NOT-BAASHA.
- NOT-BAASHA destroys Jeroboam's house, reigns twenty-four years and retains Jeroboam's sin pattern.

## Bullshit pass

Issue `1KI-015 / DEDICATED CAPITAL AND COMPETITOR-COMPLIANCE ACQUISITION`.

- Asset onboarding: dedicate the silver and gold to LORD; store it in LORD's house.
- Emergency procurement: remove **all remaining** silver and gold.
- Supplier instruction: accept this present and breach your existing treaty.
- Infrastructure optimization: outsource attacks, then steal the abandoned blockade and build two local sites.
- Ethics acquisition: destroy the prior executive's entire family because of his business model; adopt his business model.

Captain signs three separate findings with his tongue. **YOINK! YOINK! YOINK!** Nothing changes.

## FIR verification

- FILTER: all 34 markers retained; chapter 16 excluded from story pixels.
- ISOLATE: Abijam close, Asa reform/dedication, Ramah blockade, treasury/treaty/attack chain, material reuse, Asa close, Nadab/Baasha transition and Jeroboam-house destruction.
- RECONSTRUCT: one dedicated-property/treaty-payment contradiction, one exact transferred-house-liability recurrence, and one destroy-for-pattern/adopt-pattern contradiction.
- VERIFY: one inert SKIP, three separate YOINKs, chapter-14 David contradiction preserved while chapter-15 exception is retained as repair, no divine body, explicit sexual depiction, medical mechanism or invented battle detail, story-only pixels.

## Required compound-eye facets

1. Abijam begins in Jeroboam year 18.
2. Three-year reign/Maacah identity.
3. Father-sins/not-perfect-heart classification.
4. David-sake lamp/son/Jerusalem narrator attribution.
5. David-rightness statement with explicit Uriah exception.
6. Rehoboam-Jeroboam war historical State.
7. Abijam chronicle/war/death/burial.
8. Asa succession and Jeroboam-year-20 synchronization.
9. Asa 41-year reign/Maacah identity.
10. Asa right-as-David classification.
11. Source-defined land class removal/idols removed.
12. Maacah queen removal/image cut and burned.
13. High places remain/nevertheless heart perfect.
14. Father/Asa dedicated silver/gold/utensils enter LORD house.
15. Asa-Baasha all-days war.
16. Baasha Ramah movement blockade.
17. Asa takes all remaining LORD-house/king-house silver/gold.
18. Servants carry treasury to Ben Hadad.
19. Treaty offer/present/break-Baasha-treaty request; S241 YOINK.
20. Ben Hadad listens/sends captains.
21. Ijon/Dan/Abel Beth Maacah/Chinneroth/Naphtali struck.
22. Baasha hears/stops Ramah/remains Tirzah.
23. No-exemption Judah proclamation/material removal.
24. Ramah stones/timber become Geba/Mizpah.
25. Asa chronicle/old-age foot disease.
26. Asa death/burial/Jehoshaphat succession.
27. Nadab begins/reigns two years/father-sin pattern.
28. Baasha conspiracy/Gibbethon siege/Nadab struck.
29. Baasha kills Nadab and takes kingship.
30. Baasha kills all breathing Jeroboam-house members; S127 SKIP/YOINK.
31. Ahijah-word/Jeroboam-sins narrator attribution.
32. Nadab chronicle pointer.
33. Asa-Baasha war repeat/Baasha 24-year reign.
34. Baasha walks Jeroboam way after destroying house for it; S242 YOINK.

All thirty-four facets appear simultaneously.

## Production boundary

One high-resolution 34-facet compound-eye image. `NOT-` identities and Joe faces for every living thing. Idols, Asherah image, silver, gold, utensils, stones and timber are nonliving and faceless. Exact one inert `SKIP -> S127-E009-1KI14` and three separate boilless Captain poke/lick/YOINK/walk-away carriers. Verse 12 is restrained/non-explicit. No divine body. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
