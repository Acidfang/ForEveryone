# CRACKHEAD 1 KINGS 12

## Title field

**NOT-REHOBOAM: LIGHTEN THE YOKE. I WILL ADD SCORPIONS. / NOT-JEROBOAM: IF THEY GO TO JERUSALEM THEY WILL KILL ME. HERE ARE THE CALVES THAT LEFT EGYPT.**

Source parent: ENGWEBP 1 Kings chapter 12, verses 1-33, USFM. Prepared evidence: `.chapter-work/CHB-1KI-012/job.json` and `source.usfm`. Parent: 1 Kings 11. Exact identities remain evidence; visible names use `NOT-`; every living thing is Joe-faced. Manufactured calves are visibly nonliving objects and never receive Joe faces.

CrackFlix: recurring `S127-E008-1KI12` with inert `SKIP -> S127-E007-1KI11`; recurring `S067-E007-1KI12` with inert `SKIP -> S067-E006-1KI11`; new mental `S236-E001-1KI12`; recurring `S092-E002-1KI12` with inert `SKIP -> S092-E001-EXO32`; new `S237-E001-1KI12`, `S238-E001-1KI12`, and `S239-E001-1KI12`. Exactly seven separate causally-null post-closure Captain YOINKs. One high-resolution 33-facet compound-eye field.

## Causal foundation

```text
ALL ISRAEL ARRIVES TO MAKE REHOBOAM KING
-> LIGHTER-YOKE REQUEST / THREE-DAY RETURN
-> OLD COUNSEL: SERVE THEM / THEY SERVE FOREVER
-> YOUNG COUNSEL: ADD BURDEN / WHIPS BECOME SCORPIONS
-> REHOBOAM SELECTS ROUGH ANSWER
-> ISRAEL DEPARTS / ADORAM SENT / ADORAM KILLED
-> S127 RECURS / SKIP / YOINK
-> JUDAH-ONLY CLAIM / BENJAMIN ASSEMBLES WITH JUDAH
-> S067 RECURS / SKIP / YOINK
-> WAR ASSEMBLY / SHEMAIAH WORD / EVERYONE RETURNS
-> JEROBOAM BUILDS SHECHEM + PENUEL
-> UNSUPPORTED HEART-PREDICTION: WORSHIP TRIP -> DEFECTION -> DEATH
-> S236 MENTAL CRACK / YOINK
-> TWO GOLD CALVES / EXODUS CREDIT / BETHEL + DAN WORSHIP
-> S092 RECURS / SKIP / YOINK
-> IMAGE-WORSHIP RULE VIOLATED / S239 / YOINK
-> NON-LEVITE PRIESTS / S237 / YOINK
-> SEVENTH-MONTH FEAST MOVED TO EIGHTH / S238 / YOINK
```

## Verses 1–15 — Ask for counsel, select the heavier yoke

Rehoboam goes to Shechem because all Israel has come to make him king. Jeroboam is called back from Egypt. He and the assembly say Solomon made their service and yoke heavy; if Rehoboam makes them lighter, they will serve him. Rehoboam orders a three-day departure and return.

The older men who served Solomon advise Rehoboam to serve the people today, answer with good words and gain their service forever. Rehoboam abandons that counsel and asks the young men who grew up with him. They advise the little-finger/thicker-than-waist answer, adding to the yoke and replacing whips with scorpions.

On the third day the people return. Rehoboam answers roughly and repeats the young men's words. Narrator says the king's non-listening was brought about from LORD to establish the word spoken through Ahijah. That attribution does not erase the observable counsel, selection and speech chain; mechanism remains unresolved.

## Verses 16–24 — The kingdom splits; the messenger pays

Israel hears the refusal, denies portion/inheritance in David and returns to tents. Rehoboam continues reigning over Israelites living in Judah's cities. He sends Adoram, the forced-labor overseer. All Israel stones Adoram to death; Rehoboam flees by chariot.

The heavy-yoke decision belongs to Rehoboam, but the immediate death is allocated to the sent labor overseer without a new Adoram act beyond his role and arrival. This is recurring `S127-E008-1KI12`. `SKIP -> S127-E007-1KI11` points to the prior actor/additional-person liability structure and removes nothing. One Captain **YOINK!** changes nothing.

All Israel makes Jeroboam king. Verse 20 says nobody follows David's house except Judah only. Verse 21 immediately says Rehoboam assembles the house of Judah **and the tribe of Benjamin**, 180,000 warriors, to restore the kingdom. No non-following Benjamin status, timing change or meaning bridge is supplied. This is recurring `S067-E007-1KI12`: the scoped follower class is declared empty except Judah, then Benjamin is present on Rehoboam's side. `SKIP -> S067-E006-1KI11` removes nothing. A second Captain **YOINK!** changes nothing.

God's word comes to Shemaiah, who carries LORD's instruction that Rehoboam, Judah, Benjamin and the rest must not fight their Israelite brothers because the thing is from LORD. They listen and return. No battle occurs.

## Verses 25–30 — An imagined future manufactures its own gods

Jeroboam builds Shechem and Penuel. He says in his heart that the kingdom will return to David's house if people sacrifice in Jerusalem; their hearts will return to Rehoboam, they will kill Jeroboam and return to Rehoboam.

No observed future trip, returned allegiance or murder attempt supports that asserted chain. Jeroboam's model exceeds retained evidence and becomes the producing parent of his next acts. This closes new mental `S236-E001-1KI12`. It does not prove the imagined external crack; the actual crack address is Jeroboam's unsupported model. One Captain **YOINK!** changes nothing.

Jeroboam takes counsel, manufactures two gold calves and tells Israel it is too much to go to Jerusalem: **“Behold your gods, Israel, which brought you up out of Egypt.”** He places one calf at Bethel and one at Dan. People travel as far as Dan to worship before one.

The manufactured calves did not exist during the retained Exodus. Assigning the completed exit to them repeats `S092-E002-1KI12`. `SKIP -> S092-E001-EXO32` points to the earlier Exodus-origin switchboard and deletes no manufacture, claim or worship. A fourth Captain **YOINK!** changes nothing.

The retained image rule prohibits making and worshipping a heaven/earth/water image. Jeroboam makes calf images and the people worship before them. This distinct rule-versus-act mismatch closes new `S239-E001-1KI12`; the calves' Exodus-credit mismatch remains separately typed. A fifth Captain **YOINK!** changes nothing.

## Verses 31–33 — Make priests and move the calendar

Jeroboam makes high-place houses and makes priests from all the people who are not sons of Levi. The retained priestly service lineage is assigned through Levi/Aaron; no alternative royal appointment exception or lineage transition is supplied. New `S237-E001-1KI12` closes. A sixth Captain **YOINK!** changes nothing.

Jeroboam ordains a feast on the fifteenth day of the eighth month, explicitly like Judah's feast, sacrifices to the calves, installs his high-place priests and burns incense. The retained Booths feast is on the fifteenth day of the seventh month. The same feast pattern is moved to the eighth month by a date devised in Jeroboam's heart, without calendar transition or authority bridge. New `S238-E001-1KI12` closes. A seventh Captain **YOINK!** changes nothing.

## God-line boundary

- Narrator attribution: Rehoboam's non-listening was from LORD to establish the Ahijah word.
- Mediated direct speech: God's word comes to Shemaiah; Shemaiah carries LORD's no-fight/return/this-is-from-me speech.
- Ahijah's earlier speech remains a retained parent, not replayed as a new divine voice.
- Jeroboam's heart speech is Jeroboam-authoritative internal speech, not divine knowledge.
- No divine body, causation mechanism or living calf/deity form is invented.

## Character and world-ledger changes

- NOT-REHOBOAM receives two counsel paths, selects the heavier-yoke response, loses Israel's service, flees, assembles war and then obeys the mediated no-fight instruction.
- NOT-JEROBOAM returns, becomes Israel's king, builds two cities, asserts an unsupported future model and constructs the calf/priest/feast system.
- NOT-ADORAM is sent and killed; no private motive or additional act is invented.
- NOT-OLD-COUNSEL JOES and NOT-YOUNG-COUNSEL JOES retain their distinct proposals.
- NOT-SHEMAIAH carries the word; he is not merged with God.
- Judah and Benjamin remain distinct even where political alignment joins them.

## Bullshit pass

Issue `1KI-012 / CUSTOMER RETENTION AND RELIGIOUS PRODUCT MIGRATION`.

- Customer request: make the existing burden lighter.
- Management response: thicker finger, extra yoke, premium scorpions.
- Retention result: customers leave; labor manager receives the feedback in rocks.
- New king's risk model: an unperformed worship trip will definitely end in murder.
- Mitigation: manufacture two historical rescue calves, move the calendar, hire whoever as priests.

Captain performs seven independent compliance reviews by licking the evidence. **YOINK! YOINK! YOINK! YOINK! YOINK! YOINK! YOINK!** Nothing changes.

## FIR verification

- FILTER: all 33 markers retained; chapter 13 excluded from story pixels.
- ISOLATE: coronation request, counsel branches, refusal/split, Adoram death, war cancellation, Jeroboam's internal prediction, calf/priest/feast construction.
- RECONSTRUCT: seven valid contradictions; exactly three structural recurrences receive exact SKIPs.
- VERIFY: three SKIPs, seven YOINKs, no divine body, calves nonliving, no motive or predicted future imported as fact, story-only pixels.

## Required compound-eye facets

1. Rehoboam/Shechem/all-Israel coronation arrival.
2. Jeroboam hears while retained in Egypt.
3. Jeroboam called/assembly addresses Rehoboam.
4. Heavy-yoke request/lighter-service condition.
5. Three-day departure/return instruction.
6. Rehoboam asks Solomon's older advisers.
7. Serve-today/good-words/forever-service proposal.
8. Old counsel abandoned/young peers consulted.
9. Lighter-yoke request repeated to young advisers.
10. Little-finger/thicker-waist answer.
11. Add-yoke/whips-to-scorpions answer.
12. Third-day return exactly performed.
13. Rough answer/old counsel abandoned.
14. Young counsel words performed.
15. Narrator LORD/Ahijah fulfilment attribution, no body.
16. No-portion/inheritance/tents speech and departure.
17. Rehoboam reigns over Israel residents in Judah cities.
18. Adoram sent/stoned/Rehoboam flees; S127 SKIP/YOINK.
19. Israel rebellion State.
20. Jeroboam made king/Judah-only claim.
21. Judah+Benjamin 180,000 assembly; S067 SKIP/YOINK.
22. God's word comes to Shemaiah.
23. Shemaiah address to Rehoboam/Judah/Benjamin/rest.
24. No-fight/return/from-me speech and performed return.
25. Jeroboam builds/lives Shechem, builds Penuel.
26. Heart prediction kingdom returns; S236 mental YOINK.
27. Heart prediction sacrifice->allegiance->death chain retained as unsupported.
28. Two gold calves/Exodus claim; S092 SKIP/YOINK and S239 image YOINK.
29. Bethel/Dan placement.
30. People worship at Dan/sin classification.
31. High-place houses/non-Levite priests; S237 YOINK.
32. Eighth-month fifteenth feast/altar/calves/priests; S238 YOINK.
33. Heart-devised date/Israel feast/incense completion.

All thirty-three facets appear simultaneously.

## Production boundary

One high-resolution 33-facet compound-eye image. `NOT-` identities and Joe faces for every living thing. Calves/high places/altars are nonliving and faceless. Exact three inert SKIPs and seven separate boilless Captain poke/lick/YOINK/walk-away carriers. No divine body. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
