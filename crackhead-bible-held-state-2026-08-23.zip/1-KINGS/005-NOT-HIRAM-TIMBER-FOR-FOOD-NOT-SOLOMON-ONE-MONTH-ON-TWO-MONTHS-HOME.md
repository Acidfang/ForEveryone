# CRACKHEAD 1 KINGS 5

## Title field

**NOT-HIRAM: TIMBER BY SEA. / NOT-SOLOMON: FOOD YEAR BY YEAR. / THIRTY THOUSAND JOES: ONE MONTH ON, TWO MONTHS HOME.**

Source parent: ENGWEBP 1 Kings chapter 5, verses 1-18, USFM. Prepared evidence: `.chapter-work/CHB-1KI-005/job.json` and `source.usfm`. Parent: 1 Kings 4. Exact identities remain evidence; visible names use `NOT-`. Every living human, animal and plant is Joe-faced. Timber, stones and food retain material identity without becoming living carriers.

CrackFlix: no completed contradiction, no episode, no SKIP, no Captain and no YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
HIRAM HEARS SOLOMON ANOINTED / SENDS SERVANTS
-> SOLOMON REPORTS DAVID WAR BARRIER + CURRENT REST
-> SOLOMON STATES HOUSE INTENT / REPORTED DIVINE SUCCESSION SPEECH
-> REQUESTS CEDAR CUTTING + JOINT SERVANTS + WAGES
-> HIRAM REJOICES / ATTRIBUTES WISE SON TO LORD
-> HIRAM ACCEPTS CEDAR + CYPRESS DESIRE
-> HIRAM DEFINES LEBANON-SEA-RAFT-BREAKUP-RECEIPT ROUTE
-> SOLOMON OWES HOUSEHOLD FOOD
-> TIMBER GIVEN
-> WHEAT + OIL GIVEN YEAR BY YEAR
-> LORD-WISDOM ATTRIBUTION / PEACE / TREATY
-> 30,000 LEVY / 10,000 MONTHLY ROTATION
-> 70,000 BURDEN BEARERS + 80,000 CUTTERS + 3,300 OFFICERS
-> LARGE COSTLY WORKED FOUNDATION STONES CUT
-> SOLOMON + HIRAM + GEBALITE BUILDERS PREPARE TIMBER/STONES
-> HOUSE CONSTRUCTION REMAINS NEXT
```

## Verses 1–6 — Diplomatic contact and request

Hiram king of Tyre sends servants after hearing Solomon was anointed in David's place; narrator says Hiram had always loved David. Solomon sends a message saying David could not build a LORD-name house because of surrounding wars until LORD put enemies under his feet. Solomon says LORD has now given rest, with no enemy and no evil occurrence, and states his intent to build under reported divine succession speech.

He asks Hiram to command cedar cutting in Lebanon, proposes joint servants and wages set according to Hiram's statement, and says nobody among Israel knows how to cut timber **like the Sidonians**. This is a comparative skill claim, not a claim that Israel has zero timber cutters.

## Verses 7–12 — Accepted exchange and treaty

Hiram rejoices and attributes a wise son for David to LORD. He accepts Solomon's timber desire, adds cedar and cypress, and defines the carrier route: servants bring timber from Lebanon to sea, form rafts, transport them to Solomon's specified place, break them up, and Solomon receives them. In return Solomon is to supply food for Hiram's household.

Narrator reports Hiram gave all desired cedar and cypress. Solomon gives twenty thousand cors of wheat and twenty cors of pure oil year by year. LORD gives Solomon wisdom as promised; Hiram and Solomon have peace and make a treaty. The exchange is performed without an observable mismatch.

## Verses 13–18 — Labor, stone and preparation

Solomon raises thirty thousand men from all Israel. Ten thousand rotate to Lebanon for one month and remain home two months; Adoniram oversees the forced labor. Solomon also has seventy thousand burden bearers, eighty thousand mountain stone cutters and three thousand three hundred chief officers over the work.

At royal command, large costly worked stones are cut for the house foundation. Solomon's builders, Hiram's builders and the Gebalites cut and prepare timber and stones. This does not contradict the earlier **like the Sidonians** comparison. The house itself is not narrated as built in this chapter.

## God-line boundary

No direct God speech occurs in the chapter's current Moment. Solomon reports earlier LORD speech that David's enthroned son would build the house, reports divine enemy-rest action and attributes current rest to LORD. Hiram attributes Solomon's wisdom and kingship to LORD. Narrator says LORD gave Solomon wisdom as promised. These human, reported and narrator carriers remain separate; no divine body or mechanism is invented.

## Character and world-ledger changes

- NOT-HIRAM sends/receives messages, accepts the exchange, supplies cedar/cypress and enters peace/treaty with Solomon.
- NOT-SOLOMON requests timber, supplies wheat/oil, raises labor groups and commands foundation-stone work.
- NOT-HIRAM'S-SERVANTS, NOT-SOLOMON'S-SERVANTS and NOT-GEBALITE-BUILDERS receive distinct work relations.
- NOT-ADONIRAM continues as forced-labor overseer.
- 30,000 levy workers, 70,000 burden bearers, 80,000 cutters and 3,300 officers enter retained collective State without invented individual identities, consent, injuries or outcomes.

## Bullshit pass

Issue `1KI-005 / TEMPLE PROCUREMENT: SEND TREE, RECEIVE 3,270 TONNES OF BREAD`. Lebanon runs **WOOD-AS-A-SERVICE** over sea rafts. The workforce enjoys a royal three-month subscription: one month abroad, two months wondering whether that counts as flexible work. Foundation unchanged.

## FIR verification

- FILTER: all 18 markers retained; chapter 6 excluded.
- ISOLATE: Hiram contact, Solomon request, accepted timber-food exchange, treaty, rotating levy, labor counts and prepared foundation materials.
- RECONSTRUCT: complete exchange/preparation chain; zero valid contradiction occurrences.
- VERIFY: no episode, SKIP, Captain or YOINK; comparative cutter claim preserved; construction future; divine carriers typed; publication held.

## Required compound-eye facets

1. Hiram hears anointing/sends servants/always-loved-David narration.
2. Solomon sends to Hiram.
3. Solomon reports David war barrier/LORD enemy action.
4. Solomon reports LORD-given rest/no enemy/no evil occurrence.
5. House intent/reported enthroned-son divine speech.
6. Cedar request/joint servants/wages/Sidonian comparison.
7. Hiram rejoices/LORD-wise-son attribution.
8. Hiram accepts cedar/cypress desire.
9. Lebanon-to-sea rafts/breakup/receipt/household-food condition.
10. Hiram gives cedar/cypress according to desire.
11. Solomon gives 20,000 cors wheat/20 cors oil/year by year.
12. LORD-wisdom narration/Hiram-Solomon peace/treaty.
13. Thirty-thousand Israel levy.
14. Ten-thousand monthly Lebanon rotation/two months home/Adoniram.
15. Seventy-thousand burden bearers/eighty-thousand mountain cutters.
16. Three-thousand-three-hundred work officers.
17. Command/large costly worked foundation stones.
18. Solomon-Hiram-Gebalite builders prepare timber/stones; chapter 6 excluded.

All eighteen facets appear simultaneously.

## Production boundary

One high-resolution 18-facet compound-eye image. `NOT-` display; every living thing Joe-faced; forced labor and bulk material movement shown without invented conditions or injury; no divine body. Zero episodes, zero SKIPs, zero Captain carriers and zero YOINKs. Publication held; originator review required.

*shrug*

OK.
