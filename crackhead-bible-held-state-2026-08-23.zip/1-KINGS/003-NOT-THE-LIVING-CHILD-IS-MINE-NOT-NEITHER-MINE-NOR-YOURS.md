# CRACKHEAD 1 KINGS 3

## Title field

**NOT-WOMAN: THE LIVING CHILD IS MINE. / ALSO NOT-WOMAN: HE SHALL BE NEITHER MINE NOR YOURS.**

Source parent: ENGWEBP 1 Kings chapter 3, verses 1-28, USFM. Prepared evidence: `.chapter-work/CHB-1KI-003/job.json` and `source.usfm`. Parent: 1 Kings 2. Exact identities remain evidence; visible names use `NOT-`. Every living human, animal and plant is Joe-faced. The dead infant and proposed division remain restrained and non-graphic.

CrackFlix: new `S225-E001-1KI3`; no SKIP. Exactly one separate causally-null post-closure YOINK. One high-resolution compound-eye field.

## Causal foundation

```text
SOLOMON MARRIES PHARAOH'S DAUGHTER
-> PEOPLE + SOLOMON SACRIFICE AT HIGH PLACES
-> SOLOMON OFFERS 1,000 AT GIBEON
-> LORD APPEARS IN NIGHT DREAM / OFFERS GIFT
-> SOLOMON ASKS FOR UNDERSTANDING TO JUDGE
-> REQUEST PLEASES LORD
-> DREAM SPEECH GRANTS WISDOM + RICHES + HONOR / CONDITIONAL LONG LIFE
-> SOLOMON WAKES / RETURNS TO JERUSALEM / OFFERS / FEASTS
-> TWO WOMEN PRESENT OPPOSING CHILD CLAIMS
-> SECOND CLAIMANT: LIVING CHILD IS MINE
-> SOLOMON REQUESTS SWORD / ORDERS PROPOSED DIVISION
-> FIRST CLAIMANT: GIVE CHILD AWAY / DO NOT KILL
-> SECOND CLAIMANT: NEITHER MINE NOR YOURS / DIVIDE
-> SOLOMON AWARDS LIVING CHILD TO FIRST CLAIMANT
-> ISRAEL HEARS / FEARS / ATTRIBUTES GOD'S WISDOM
```

## Verses 1–4 — Marriage, construction and high places

Solomon makes a marriage alliance with Pharaoh, takes Pharaoh's daughter and brings her into David's city pending three building projects. People sacrifice in high places because no LORD-name house has yet been built. Narrator says Solomon loved LORD and walked in David's statutes, except he sacrificed and burned incense at high places. He goes to Gibeon, the great high place, and offers one thousand burnt offerings. “Except” marks the supplied qualification; it is not converted into a contradiction.

## Verses 5–15 — The dream request and changed State

At Gibeon LORD appears to Solomon in a night dream. God says: **“Ask for what I should give you.”** Solomon attributes David's throne line and his own kingship to God, calls himself a little child who does not know how to go out or come in, and requests an understanding heart to judge and discern good from evil.

The request pleases the Lord. God directly says that because Solomon did not request long life, riches or enemy life, God has done according to his word and given him a wise and understanding heart. God also grants unrequested riches and honor, and conditionally promises lengthened days if Solomon walks in the stated ways.

Solomon wakes and identifies the occurrence as a dream, travels to Jerusalem, stands before the covenant ark, offers burnt and peace offerings and makes a feast. His earlier inability and later judgment are separated by the expressly narrated grant; no contradiction is manufactured. “None after you” remains future dream speech, not a completed comparison.

## Verses 16–23 — Two incompatible accounts

Two women identified by the source as prostitutes stand before Solomon. The first says both lived alone in one house, gave birth three days apart, the other woman's child died when she lay on it, and the other swapped the children at midnight. These are her statements; the swap, sleep act and maternity are not silently upgraded before judgment.

The other woman says: **“The living one is my son, and the dead one is your son.”** The first says the reverse. Solomon accurately restates the opposing claims. Their disagreement establishes incompatible testimony, not by itself which account is true.

## Verses 24–27 — Sword test, changed claim and judgment

Solomon requests a sword; it is brought. He orders the living child divided and half given to each. No division occurs.

The source narrator identifies one woman as the woman whose child was living and says her heart yearned over her son. She asks Solomon to give the living child to the other woman and not kill him. The other claimant—who had just said **“the living one is my son”**—says: **“He shall be neither mine nor yours. Divide him.”**

This closes `S225-E001-1KI3`: **THE LIVING CHILD IS MINE / HE SHALL BE NEITHER MINE NOR YOURS.** It uses the same claimant's explicit statements and needs no invented maternal psychology. Solomon orders the living child given to the first woman and not killed, declaring her the mother. The child remains alive. One separate Captain poke/lick/**YOINK!**/walk-away changes nothing.

## Verse 28 — Public response

All Israel hears the judgment, fears Solomon and observes that God's wisdom is in him to do justice. That is the narrator's report of Israel's observation and attribution. The mechanism by which the test proves biological maternity beyond the narrated relation remains unresolved.

## God-line boundary

Direct dream speech belongs only to God: the gift invitation, the reasoned grant of wisdom/riches/honor and the conditional length-of-days promise. Narrator separately supplies LORD's appearance, the request pleasing the Lord and Israel's later wisdom attribution. Solomon's claims about David, selection and kingship remain Solomon's speech. No divine body is rendered; the dream uses a typed voice/presence carrier.

## Character and world-ledger changes

- NOT-SOLOMON marries Pharaoh's daughter, offers at Gibeon, dreams, requests understanding, wakes, offers at Jerusalem and decides the child case.
- NOT-PHARAOH'S-DAUGHTER is brought into David's city; her name, speech, consent and later acts remain unresolved.
- NOT-FIRST-WOMAN presents one account, asks that the living child be spared and receives the child by Solomon's ruling.
- NOT-SECOND-WOMAN presents the opposite claim, then says the child shall belong to neither claimant and should be divided.
- NOT-LIVING-CHILD remains alive and is transferred by judgment; NOT-DEAD-CHILD remains dead.
- Israel hears, fears and attributes divine wisdom.

## Bullshit pass

Issue `1KI-003 / SOLOMON BETA TESTS CUSTOMER SUPPORT WITH A SWORD`. Gibeon processes one thousand offerings before Dream Support enables **UNDERSTANDING HEART**. Royal Child Allocation briefly displays **50% / 50%**, then cancels before execution. Foundation unchanged.

## FIR verification

- FILTER: all 28 markers retained; chapter 4 excluded.
- ISOLATE: marriage/building wait, high-place offerings, dream request/grant, Jerusalem offerings, opposing testimony, unexecuted sword test, judgment and public response.
- RECONSTRUCT: one same-speaker claim reversal, `S225-E001-1KI3`.
- VERIFY: no SKIP, one YOINK, alleged swap retained as testimony, no child division, no inferred motive, dream/direct-speech boundaries typed, publication held.

## Required compound-eye facets

1. Solomon marriage alliance/Pharaoh's daughter/three unfinished builds.
2. People sacrifice at high places/no house yet.
3. Solomon loves LORD/walks statutes/except high-place sacrifice and incense.
4. Gibeon great high place/one thousand offerings.
5. Night dream appearance/God asks what to give.
6. Solomon reports David loving-kindness/truth/righteousness/uprightness/throne son.
7. Solomon says God made him king/little child/cannot go out or come in.
8. Great unnumbered chosen people.
9. Understanding-heart request/good-evil judgment.
10. Request pleases the Lord.
11. God distinguishes unrequested life/riches/enemy life from justice understanding.
12. God grants wise/understanding heart/none-like claim.
13. God grants unrequested riches/honor/king comparison.
14. Conditional walk/keep/lengthened-days speech.
15. Solomon wakes/dream/Jerusalem ark/offerings/feast.
16. Two women stand before king.
17. First woman: shared house/her childbirth.
18. Third day/other childbirth/no stranger/two alone.
19. First woman's account: other child died from being lain on.
20. First woman's account: midnight child swap.
21. Morning dead child/inspection/not her born son claim.
22. Opposing living/dead child claims.
23. Solomon restates both claims.
24. Sword requested and brought.
25. Proposed division/half to each; no execution.
26. Narrator yearning attribution/first woman says give away and do not kill; second says neither mine nor yours/divide; `S225-E001`.
27. Solomon gives living child to first woman/declares mother; separate YOINK.
28. Israel hears/fears/sees God-wisdom attribution; chapter 4 excluded.

All twenty-eight facets appear simultaneously.

## Production boundary

One high-resolution 28-facet compound-eye image. `NOT-` display; every living thing Joe-faced; infant death and sword proposal restrained/non-graphic; no divine body. Exactly one new episode, zero SKIPs and exactly one separate causally-null post-closure YOINK. Publication held; originator review required.

*shrug*

OK.
