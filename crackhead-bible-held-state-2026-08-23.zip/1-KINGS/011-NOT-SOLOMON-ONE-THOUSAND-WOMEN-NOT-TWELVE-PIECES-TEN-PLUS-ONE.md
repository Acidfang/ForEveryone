# CRACKHEAD 1 KINGS 11

## Title field

**NOT-SOLOMON: DO NOT MULTIPLY WIVES. ONE THOUSAND WOMEN. / DO NOT GO AFTER OTHER GODS. BUILDS ALL OF THEM A PLACE. / EVERY MALE CUT OFF. CHILD NOT-HADAD ESCAPED. / PEACE ON ALL SIDES. ADVERSARY ALL HIS DAYS. / TWELVE PIECES: TEN PLUS ONE.**

Source parent: ENGWEBP 1 Kings chapter 11, verses 1-43, USFM. Prepared evidence: `.chapter-work/CHB-1KI-011/job.json` and `source.usfm`. Parents: 1 Kings 10; Deuteronomy 17:17; retained 1 Kings 4-5 peace/no-adversary State; `S067-E005-2SA18`; `S127-E006-JDG21`. Exact identities remain evidence; visible names use `NOT-`. Every living human, animal and plant is Joe-faced. Named gods remain source claims and receive no invented living bodies.

CrackFlix: new `S232-E001-1KI11`, `S233-E001-1KI11`, `S234-E001-1KI11`, and `S235-E001-1KI11`; recurring `S127-E007-1KI11` with exact inert `SKIP -> S127-E006-JDG21`; recurring `S067-E006-1KI11` with exact inert `SKIP -> S067-E005-2SA18`. Exactly six separate causally-null post-closure Captain YOINKs. One high-resolution 43-facet compound-eye field.

## Causal foundation

```text
KING-WIFE RULE + FOREIGN-NATION WARNING
-> SOLOMON JOINS MANY WOMEN / 700 WIVES + 300 CONCUBINES
-> HEART TURNS EXACTLY AS WARNED
-> S232 CLOSES / YOINK CHANGES NOTHING
-> DIRECT OTHER-GODS COMMAND RETAINED
-> SOLOMON GOES AFTER OTHER GODS / BUILDS HIGH PLACES
-> S233 CLOSES / YOINK CHANGES NOTHING
-> LORD SPEAKS KINGDOM-TEARING CONSEQUENCE
-> SOLOMON KEEPS KINGDOM DURING HIS LIFE / SON LOSES TEN TRIBES
-> S127 RECURS / SKIP POINTS TO JUDGES 21 / YOINK CHANGES NOTHING
-> HADAD HISTORY: EVERY MALE CUT OFF / MALE CHILD ESCAPES
-> S067 RECURS / SKIP POINTS TO 2 SAMUEL 18 / YOINK CHANGES NOTHING
-> REZON ADVERSARY ALL SOLOMON'S DAYS
-> EARLIER PEACE-ALL-SIDES + NO-ADVERSARY STATE FAILS
-> S234 CLOSES / YOINK CHANGES NOTHING
-> AHIJAH TEARS GARMENT INTO 12 / GIVES 10 / REPORTS ONE TRIBE LEFT
-> S235 CLOSES / YOINK CHANGES NOTHING
-> SOLOMON SEEKS JEROBOAM'S DEATH / JEROBOAM ESCAPES
-> SOLOMON DIES AFTER 40 YEARS / REHOBOAM REIGNS
```

## Verses 1–8 — The warning performs itself

Solomon loves many foreign women, including Pharaoh's daughter and women identified with Moabites, Ammonites, Edomites, Sidonians and Hittites. The retained LORD speech to Israel says the groups must not enter one another because they will surely turn Israelite hearts after their gods. Solomon joins himself to them in love.

The source counts seven hundred wives who are princesses and three hundred concubines. His wives turn his heart. In old age his heart goes after other gods and is not fully with LORD as David's was. Solomon follows Ashtoreth and Milcom, does what narrator calls evil, builds high places for Chemosh and Molech, and does likewise for all foreign wives who burn incense and sacrifice.

Deuteronomy 17:17 already says the king shall not multiply wives so his heart will not turn away. The king multiplies wives and his heart turns away. This closes new `S232-E001-1KI11`; no quantity threshold, exception or repeal is supplied. One Captain poke/lick/**YOINK!**/walk-away changes nothing.

The chapter separately says LORD had commanded Solomon not to go after other gods, and says Solomon did not keep it. That direct command and performed opposite close new `S233-E001-1KI11`. It is not merged into the wife-count crack: one concerns multiplication producing the warned result; the other concerns a directly prohibited act actually performed. A second separate Captain **YOINK!** changes nothing.

## Verses 9–13 — The actor keeps it; the son loses it

Narrator says LORD is angry because Solomon's heart turned away from the God who appeared to him twice and commanded him about this thing. LORD directly tells Solomon that, because Solomon did this and did not keep covenant/statutes, the kingdom will surely be torn from him and given to his servant.

The speech then explicitly delays the act: it will not happen in Solomon's days for David's sake, but will be torn from Solomon's son's hand. One tribe remains to the son for David and Jerusalem. The delay is an explicit timing bridge, so “from you / from your son's hand” is not independently classified as crack.

The punishment allocation is a recurrence: Solomon is the addressed actor, while his son loses the kingdom during the son's reign without a supplied act by that son producing this judgment. This is `S127-E007-1KI11`. `SKIP -> S127-E006-JDG21` points to the prior additional-person liability structure, omits only its explanation and deletes no speech or future act. A third separate Captain **YOINK!** changes nothing.

## Verses 14–22 — Every male, including the child who escaped

Narrator says LORD raises Hadad the Edomite as Solomon's adversary. Hadad is royal offspring in Edom. The retained backstory says David was in Edom, Joab went to bury the slain, and Joab struck every male. Joab and all Israel remain six months until every male in Edom is cut off.

Hadad nevertheless flees with Edomite servants while he is a little male child. The group travels through Midian and Paran into Egypt. Pharaoh gives Hadad a house, food and land, then gives him the sister of Tahpenes as wife. She bears Genubath; Tahpenes weans him inside Pharaoh's house.

“Every male cut off” followed by the included male child escaping closes recurring `S067-E006-1KI11`. No age exclusion, hidden survival category, replacement population or chronology bridge is supplied. `SKIP -> S067-E005-2SA18` points to the latest same empty-class/still-member structure and removes nothing. A fourth separate Captain **YOINK!** changes nothing.

Hadad hears that David and Joab are dead and asks Pharaoh to let him return to his country. Pharaoh asks what Hadad lacked. Hadad answers “Nothing,” while still asking to leave. No hidden motive is inferred; the request and answer coexist as observed speech.

## Verses 23–28 — No adversary; adversary all the days

Narrator attributes another raised adversary to God: Rezon son of Eliada, who fled Hadadezer. Rezon gathers men after David kills people of Zobah, becomes troop captain, moves to Damascus and reigns there. Verse 25 states that Rezon is an adversary to Israel **all the days of Solomon**, in addition to Hadad's mischief, and reigns over Syria.

The retained earlier State says Solomon had peace on all sides in 1 Kings 4 and says there was neither adversary nor evil occurrence in 1 Kings 5. “Adversary all the days of Solomon” occupies the same reign scope without a supplied peaceful-period, later-start, inactive-adversary or word-scope bridge. This closes new `S234-E001-1KI11`. One fifth separate Captain **YOINK!** changes nothing.

Jeroboam son of Nebat, whose mother is the widow Zeruah, is Solomon's servant and lifts his hand against the king. The narrator's supplied reason references Solomon building Millo and repairing David city's breach. Solomon sees Jeroboam's industrious work and appoints him over the labor of Joseph's house. The supplied reason is retained without adding private motive or treating promotion as rebellion's cause.

## Verses 29–39 — Twelve pieces become ten plus one

Jeroboam meets Ahijah the Shilonite prophet outside Jerusalem while Ahijah wears a new garment. They are alone. Ahijah takes the new garment and tears it into twelve pieces. He tells Jeroboam to take ten.

Ahijah then carries reported LORD speech: the kingdom will be torn from Solomon and ten tribes given to Jeroboam; one tribe remains for David and Jerusalem. The speech attributes forsaking, worship and noncompliance to “they”; that pronoun scope remains unresolved rather than silently assigned. Solomon remains prince during his lifetime for David's sake; the kingdom is taken from his son. One tribe remains as David's lamp. Jeroboam is promised rule, with a conditional sure-house branch if he listens, walks, does right and keeps statutes/commandments. David's offspring will be afflicted, but not forever.

The physical sign starts with twelve pieces. Ten pieces are addressed to ten tribes, while the reported allocation retains one tribe for Solomon's son. `12 -> 10 + 1` leaves one symbolic piece/tribe without a supplied allocation, merged-tribe rule or non-tribal piece. This closes new `S235-E001-1KI11`. No SKIP applies. A sixth separate Captain **YOINK!** changes nothing.

## Verses 40–43 — Escape, forty years, succession

Solomon seeks to kill Jeroboam. The source does not state that Solomon heard Ahijah's speech, so no knowledge path or motive is invented. Jeroboam flees to Shishak king of Egypt and remains there until Solomon's death.

The rest of Solomon's acts and wisdom are addressed to the book of his acts. Solomon's Jerusalem reign over all Israel is forty years. He dies, is buried in David's city, and Rehoboam his son reigns in his place. Burial location detail beyond the source and the kingdom division's execution remain for later State.

## God-line boundary

- Narrator acts: LORD is angry, had appeared twice, had commanded Solomon, raises Hadad; God raises Rezon.
- Direct LORD speech: verses 11–13 to Solomon.
- Reported prophetic LORD speech: Ahijah's verses 31–39 carrier; it is not converted into a newly observed divine voice.
- Human attributions and narrator labels remain typed to their carriers.
- No divine body, appearance form, adversary-raising mechanism, heart-turning mechanism or prophecy-transfer mechanism is invented.
- Ashtoreth, Milcom, Chemosh and Molech remain named source identities/claims; no living deity form is rendered.

## Character and world-ledger changes

- NOT-SOLOMON violates both retained royal wife limit and direct other-gods command, receives direct judgment speech, promotes Jeroboam, seeks Jeroboam's death, completes forty-year reign, dies and is buried.
- NOT-PHARAOH'S-DAUGHTER and the many foreign NOT-WIFE/CONCUBINE JOES retain the source's group acts and counts; individual identities and acts remain unresolved except where stated.
- NOT-HADAD survives the every-male report as a child, receives Egyptian provision/family State, and requests return.
- NOT-REZON becomes troop captain and Damascus ruler/adversary.
- NOT-JEROBOAM is promoted, receives the torn-garment prophetic carrier, escapes to Egypt and remains alive.
- NOT-AHIJAH tears one new garment into twelve and delivers speech; he is not merged with God.
- NOT-REHOBOAM succeeds Solomon; no kingdom division is yet executed in this chapter.

## Bullshit pass

Issue `1KI-011 / ROYAL LIMITS AND KINGDOM ACCOUNTING`.

- Wife limit: **1,000 relationships and the exact warned heart result**.
- Other-gods command: **received twice-adjacent divine history; ignored anyway**.
- Male-removal audit: **EVERY MALE REMOVED / CHILD EXIT RECORDED**.
- Peace status: **NO ADVERSARY / ADVERSARY ALL DAYS**.
- Twelve-piece allocation: **10 + 1 = DON'T ASK ABOUT THE OTHER ONE**.

Captain files six reports by licking them. **YOINK! YOINK! YOINK! YOINK! YOINK! YOINK!** Nothing changes.

## FIR verification

- FILTER: all 43 markers retained; chapter 12 excluded from story content and held only in machine State.
- ISOLATE: wife/heart chain, other-gods acts, direct consequence speech, Hadad and Rezon histories, Jeroboam appointment, Ahijah sign/speech, escape, death and succession.
- RECONSTRUCT: six distinct contradiction occurrences; only S067 and S127 repeat retained structures and receive exact noncausal SKIPs.
- VERIFY: two SKIPs, six separate YOINKs, no divine body, no god-body rendering, no motive/knowledge/collective-pronoun bridge invented, all workflow metadata excluded from comic pixels.

## Required compound-eye facets

1. Solomon loves many foreign women/named source groups.
2. Retained LORD no-intermingling/heart-turn warning; Solomon joins them.
3. 700 wives + 300 concubines; heart turns; S232 closure/YOINK.
4. Old Solomon/heart after other gods/not fully LORD.
5. Ashtoreth/Milcom following as source identity claims.
6. Narrator evil/not-full comparison with David.
7. Chemosh/Molech high places; no deity bodies.
8. All foreign wives' incense/sacrifice acts.
9. LORD anger/two appearances/heart-turn attribution.
10. Direct no-other-gods command not kept; S233 closure/YOINK.
11. Direct kingdom-tear/servant speech.
12. Not in Solomon days/son hand; S127 recurrence, inert SKIP and YOINK.
13. One-tribe David/Jerusalem retention speech.
14. LORD raises royal-offspring Hadad adversary.
15. David/Joab every-male strike in Edom.
16. Six months/every male cut off.
17. Child Hadad/Edomite servants flee; S067 recurrence, inert SKIP and YOINK.
18. Midian/Paran/Egypt route and Pharaoh house/food/land.
19. Pharaoh gives Tahpenes's sister as wife.
20. Genubath birth/weaning/Pharaoh-house State.
21. Hadad hears David/Joab deaths and requests departure.
22. Pharaoh lack question/Hadad nothing-but-depart answer.
23. God raises Rezon/fled Hadadezer.
24. Rezon troop/Damascus residence/reign.
25. Adversary all Solomon days; S234 closure/YOINK against earlier peace/no-adversary.
26. Jeroboam identity/mother/servant/lifted hand.
27. Narrator-supplied Millo/breach reason.
28. Industrious Jeroboam promoted over Joseph labor.
29. Ahijah meets Jeroboam alone/new garment.
30. Garment torn into twelve pieces.
31. Take ten/reported ten-tribe speech.
32. One-tribe retention; S235 twelve-versus-ten-plus-one closure/YOINK.
33. Reported forsaking/worship/non-walk speech with pronoun scope unresolved.
34. Solomon lifetime retained for David.
35. Ten tribes taken from son.
36. One tribe/David lamp/Jerusalem name relation.
37. Jeroboam taken to reign according to desire.
38. Conditional obedience/walk/right/statute branch.
39. Conditional sure house/Israel gift.
40. David-offspring affliction/not-forever limit.
41. Solomon seeks kill/Jeroboam flees to Shishak Egypt.
42. Acts-book address/forty-year reign.
43. Solomon death/burial/Rehoboam succession.

All forty-three facets appear simultaneously.

## Production boundary

One high-resolution 43-facet compound-eye image. `NOT-` display; every living thing Joe-faced. Exact `S127-E007-1KI11` with inert `SKIP -> S127-E006-JDG21`; exact `S067-E006-1KI11` with inert `SKIP -> S067-E005-2SA18`; four new non-SKIP episodes; exactly six separate post-closure Captain poke/lick/YOINK/walk-away carriers. Named other gods remain text/object references without living bodies. No divine body. The image is the finished comic: no review/publication/job/hash/path/validation/instruction/next-source metadata may appear in its pixels.

*shrug*

OK.
