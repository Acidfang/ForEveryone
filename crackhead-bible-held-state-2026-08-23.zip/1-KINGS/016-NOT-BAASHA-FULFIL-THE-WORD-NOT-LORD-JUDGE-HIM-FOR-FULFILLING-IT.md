# CRACKHEAD 1 KINGS 16

## Title field

**NOT-BAASHA: DESTROY JEROBOAM'S HOUSE ACCORDING TO THE WORD. / NOT-LORD-WORD: JUDGE BAASHA BECAUSE HE DESTROYED IT. / NOT-ZIMRI: DESTROY BAASHA FOR BEING JEROBOAM. BECOME JEROBOAM.**

Source parent: ENGWEBP 1 Kings chapter 16, verses 1-34, USFM. Prepared evidence: `.chapter-work/CHB-1KI-016/job.json` and `source.usfm`. Parent: 1 Kings 15. Exact identities remain evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: new `S243-E001-1KI16`; recurring `S127-E011-1KI16` with inert `SKIP -> S127-E010-1KI15`; recurring `S242-E002-1KI16` with inert `SKIP -> S242-E001-1KI15`; new `S244-E001-1KI16`; recurring `S127-E012-1KI16` with inert `SKIP -> S127-E011-1KI16`. Exactly five separate causally-null post-closure Captain YOINKs. One high-resolution 34-facet compound-eye field.

## Causal foundation

```text
LORD WORD THROUGH JEHU AGAINST BAASHA
-> BAASHA CONDEMNED FOR JEROBOAM WAY + STRIKING HIS HOUSE
-> PRIOR STATE: BAASHA STRUCK HOUSE ACCORDING TO LORD SAYING
-> S243 / YOINK
-> BAASHA DIES / ELAH REIGNS
-> ZIMRI KILLS DRUNK ELAH / TAKES THRONE
-> ZIMRI KILLS BAASHA HOUSE + RELATIVES + FRIENDS
-> BAASHA/ELAH SINS SUPPLY HOUSE-DESTRUCTION CAUSE
-> S127 RECURS / SKIP / YOINK
-> ZIMRI DESTROYS HOUSE FOR JEROBOAM PATTERN
-> ZIMRI WALKS JEROBOAM PATTERN / DIES
-> S242 RECURS / SKIP / YOINK
-> ALL ISRAEL MAKES OMRI KING
-> ISRAEL SPLITS HALF OMRI / HALF TIBNI
-> S244 / YOINK
-> OMRI PREVAILS / BUILDS SAMARIA / DIES / AHAB REIGNS
-> AHAB ESCALATES JEROBOAM PATTERN / BAAL + ASHERAH
-> HIEL BUILDS JERICHO
-> HIEL'S FIRSTBORN + YOUNGEST PAY FOR HIS BUILD
-> S127 RECURS / SKIP / YOINK
```

## Verses 1–7 — The fulfilment act becomes the offence

LORD's word comes to Jehu son of Hanani against Baasha. The mediated speech says LORD exalted Baasha from dust and made him prince, but Baasha walked in Jeroboam's way and made Israel sin. It announces Baasha's house will be swept away like Jeroboam's, with city deaths eaten by dogs and field deaths by birds.

Baasha's remaining acts and might are addressed to Israel's chronicle. He dies, is buried in Tirzah and his son Elah succeeds him.

Verse 7 restates the word through Jehu against Baasha and his house for Baasha's evil, being like Jeroboam's house, **and because he struck him.** The retained chapter-15 State says Baasha struck all Jeroboam's house **according to LORD's saying through Ahijah**. The same completed house-destruction act is therefore classified first as fulfilment of the LORD saying and then as a producing reason for the LORD word against Baasha. No distinction between commanded fulfilment and prohibited excess, or between different strike objects, is supplied.

This closes new `S243-E001-1KI16`. One Captain **YOINK!** changes neither attribution.

## Verses 8–14 — Seven-day succession factory, part one

Elah begins a two-year reign in Tirzah during Asa's twenty-sixth year. His servant Zimri, captain of half his chariots, conspires while Elah drinks himself drunk in household-overseer Arza's house. Zimri enters, kills Elah in Asa's twenty-seventh year and reigns in his place.

As soon as Zimri sits on the throne he attacks all Baasha's house and leaves no male among Baasha's relatives or friends. The source's wall-urination wording and male footnote remain evidence without requiring vulgar depiction. Zimri destroys Baasha's house according to LORD's word through Jehu, for Baasha and Elah's sins by which they made Israel sin.

The declared producing sins belong to Baasha and Elah, while relatives and friends are killed without individual producing acts supplied. This repeats `S127-E011-1KI16`. `SKIP -> S127-E010-1KI15` points to the previous king-act/whole-house liability occurrence and removes no death. A second Captain **YOINK!** changes nothing.

## Verses 15–20 — Seven-day succession factory, part two

Zimri reigns seven days while the people are encamped against Philistine Gibbethon. The camp hears he conspired and killed the king. All Israel makes army captain Omri king that day. Omri and all Israel leave Gibbethon and besiege Tirzah.

When Zimri sees the city is taken, he enters the fortified royal house, burns it over himself and dies. Narrator assigns his death to his sins, doing evil and walking in Jeroboam's way and sin.

Zimri destroyed Baasha's house in a narrated fulfilment caused by Baasha/Elah following Jeroboam's pattern, then the narrator classifies Zimri himself as following that pattern. This exactly repeats `S242-E002-1KI16`. `SKIP -> S242-E001-1KI15` points to Baasha's earlier destroy-for-pattern/adopt-pattern occurrence and changes no siege, fire or death. A third Captain **YOINK!** changes nothing.

Zimri's remaining acts and treason are addressed to the Israel chronicle.

## Verses 21–28 — All Israel chooses; half Israel chooses someone else

After the camp's **all Israel made Omri king** statement, Israel's people divide into two parts: half follows Tibni son of Ginath to make him king and half follows Omri. No intervening revocation, newly arrived population, narrower camp-only identity or transition from unanimous to divided selection is supplied.

This closes new `S244-E001-1KI16`: the addressed whole is declared to have selected Omri, then half that whole selects Tibni. One Captain **YOINK!** changes neither selection.

Omri's followers prevail, Tibni dies and Omri reigns. Omri begins a twelve-year reign in Asa's thirty-first year, including six years at Tirzah. He buys Samaria hill from Shemer for two talents of silver, builds on it and names the city after Shemer. The purchase/build/name chain is complete and non-contradictory.

Omri is classified as doing more evil than predecessors and walking in Jeroboam's way. His remaining acts/might are addressed to the chronicle. He dies, is buried in Samaria and his son Ahab succeeds him.

## Verses 29–33 — Escalate the inherited operating system

Ahab begins a twenty-two-year Israel reign in Samaria in Asa's thirty-eighth year. He is classified as doing more evil than all before him. As though Jeroboam's sins were light, he marries Jezebel daughter of Sidonian king Ethbaal, serves and worships Baal, builds Baal's house and altar in Samaria, and makes the Asherah. The source describes escalation, not a contradiction between Ahab's claim and act. Baal and Asherah artifacts are nonliving/faceless; no deity body is invented.

## Verse 34 — Rebuild the city; spend the sons

In Ahab's days Hiel the Bethelite builds Jericho. He lays its foundation with the loss of his firstborn Abiram and sets its gates with the loss of his youngest Segub, according to LORD's word spoken through Joshua son of Nun.

The producing build acts belong to Hiel; the two sons receive the stated losses without any producing act by them. This repeats `S127-E012-1KI16`. `SKIP -> S127-E011-1KI16` points to the immediately prior actor-act/additional-person liability structure and deletes no foundation, gate or loss. A fifth Captain **YOINK!** changes nothing.

## God-line boundary

- LORD's word comes to Jehu and is carried against Baasha; Jehu is not God and no divine body is rendered.
- Verse 7's causal explanation is narrator State concerning the mediated word.
- Baasha-house destruction is narrated according to LORD's word through Jehu; the prior message remains its parent.
- Zimri's death, Omri/Ahab evil classifications and provoked anger are narrator attributions, not direct speech.
- Hiel's losses are narrated according to LORD's word through Joshua; Joshua's retained carrier is not replayed as a new divine voice.

## Character and world-ledger changes

- NOT-JEHU carries the Baasha judgment and remains distinct from God.
- NOT-BAASHA dies and is succeeded by NOT-ELAH; the prior Jeroboam-house strike remains both fulfilment parent and later judgment reason.
- NOT-ELAH reigns two years, becomes drunk at NOT-ARZA's house and is killed by NOT-ZIMRI.
- NOT-ZIMRI reigns seven days, destroys Baasha's relations, is besieged and dies in the burned royal house.
- NOT-OMRI is selected, defeats the Tibni faction, buys/builds/names Samaria, reigns twelve years, dies and is succeeded by NOT-AHAB.
- NOT-TIBNI is selected by half the people and later dies; battle or death mechanism is not invented.
- NOT-AHAB marries NOT-JEZEBEL and performs the Baal/Asherah construction and worship acts.
- NOT-HIEL builds Jericho; NOT-ABIRAM and NOT-SEGUB receive the stated losses.

## Bullshit pass

Issue `1KI-016 / SUCCESSION-AS-A-SERVICE`.

- Baasha audit: destroy the old house according to the divine finding; receive a new divine finding because you destroyed it.
- Zimri onboarding: kill the drunk king, delete his relatives and friends, obtain a seven-day executive trial.
- Zimri compliance: punish the Jeroboam operating system; install the Jeroboam operating system; burn office with self inside.
- Democratic consensus: all Israel selects Omri; half Israel selects NOT-Omri.
- Urban development: Hiel pays the foundation milestone with one son and the gate milestone with another.

Captain performs five completely independent tongue-based certifications. **YOINK! YOINK! YOINK! YOINK! YOINK!** Nothing changes.

## FIR verification

- FILTER: all 34 markers retained; chapter 17 excluded from story pixels.
- ISOLATE: Jehu word, Baasha close, Elah/Zimri transition, Baasha-house destruction, Zimri siege/death, Omri/Tibni split, Samaria build, Omri/Ahab transitions and Hiel/Jericho losses.
- RECONSTRUCT: one fulfilment-as-offence contradiction, two distinct actor/additional-person liability recurrences, one destroy-pattern/adopt-pattern recurrence and one unanimous/divided selection contradiction.
- VERIFY: three inert SKIPs, five separate YOINKs, no divine/deity body, vulgar depiction, invented battle, motive, son guilt or death mechanism, story-only pixels.

## Required compound-eye facets

1. LORD word comes to Jehu against Baasha.
2. Dust-to-prince/Jeroboam-way accusation.
3. Baasha-house sweep/Jeroboam-house comparison.
4. Dog/city and bird/field future classes.
5. Baasha chronicle/death/burial/Elah succession.
6. Jehu word restated: evil/like Jeroboam/because struck him; S243 YOINK.
7. Elah begins two-year reign.
8. Zimri half-chariot command/conspiracy.
9. Elah drunk in Arza house.
10. Zimri kills Elah/takes throne.
11. Zimri attacks Baasha house/relations/friends.
12. Complete house destruction according Jehu word; S127 SKIP/YOINK.
13. Baasha/Elah sins and Israel-sin causal attribution.
14. Elah chronicle pointer.
15. Zimri seven-day reign/Gibbethon camp.
16. Camp hears conspiracy/regicide/all Israel makes Omri king.
17. Omri/all Israel leave Gibbethon/besiege Tirzah.
18. Zimri sees capture/burns royal house/dies.
19. Zimri Jeroboam-way classification; S242 SKIP/YOINK.
20. Zimri chronicle/treason pointer.
21. Israel divides half Tibni/half Omri; S244 YOINK.
22. Omri faction prevails/Tibni dies/Omri reigns.
23. Omri twelve-year/six-year timing.
24. Samaria hill purchase/two talents.
25. Samaria city build/name after Shemer.
26. Omri worse-than-prior/Jeroboam-way classification.
27. Omri chronicle/death/burial/Ahab succession.
28. Ahab synchronization/22-year reign.
29. Ahab above-all-prior evil classification.
30. Jezebel marriage/Baal service/worship.
31. Baal house/altar build in Samaria.
32. Asherah made/more-than-prior anger attribution.
33. Hiel Jericho foundation/Abiram loss.
34. Hiel gates/Segub loss/Joshua-word parent; S127 SKIP/YOINK.

All thirty-four facets appear simultaneously.

## Production boundary

One high-resolution 34-facet compound-eye image. `NOT-` identities and Joe faces for every living thing. Altars, houses, Asherah, hill, silver, city materials and fire are nonliving/faceless. Exact three inert SKIPs and five separate boilless Captain poke/lick/YOINK/walk-away carriers. Deaths and fire are restrained/non-graphic. No divine or deity body. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
