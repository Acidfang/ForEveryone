# CRACKHEAD 1 KINGS 22

## Title field

**NOT-FOUR-HUNDRED: GO UP AND PROSPER. THE LORD WILL DELIVER IT. / NOT-MICAIAH: LYING SPIRIT. NO SHEPHERD. / NOT-AHAB: DEAD BY EVENING.**

Source parent: ENGWEBP 1 Kings chapter 22, verses 1-53, USFM. Prepared evidence: `.chapter-work/CHB-1KI-022/job.json` and `source.usfm`. Parent: 1 Kings 21. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: new mental `S250-E001-1KI22`. No SKIP. Exactly one causally-null post-closure Captain YOINK. One high-resolution 53-facet compound-eye field.

## Causal foundation

```text
THREE YEARS NO SYRIA/ISRAEL WAR
-> JEHOSHAPHAT VISITS AHAB
-> AHAB CLAIMS RAMOTH GILEAD / REQUESTS JOINT BATTLE
-> JEHOSHAPHAT AGREES / REQUESTS LORD INQUIRY FIRST
-> ABOUT 400 PROPHETS: GO / LORD DELIVERS / PROSPER
-> MICAIAH SUMMONED DESPITE AHAB HATING HIS EVIL REPORTS
-> MESSENGER REQUESTS CONSENSUS GOOD WORD
-> MICAIAH VOWS LORD-SUPPLIED SPEECH
-> FIRST REPEATS GO/PROSPER
-> AHAB REQUIRES TRUTH
-> MICAIAH: ISRAEL SCATTERED / NO MASTER
-> MICAIAH VISION ACCOUNT: ENTICE AHAB / LYING SPIRIT IN PROPHET MOUTHS
-> ZEDEKIAH STRIKES / MICAIAH PREDICTS HIDING
-> AHAB IMPRISONS MICAIAH UNTIL PEACE RETURN
-> MICAIAH MAKES RETURN-IN-PEACE RESULT TEST PUBLIC
-> AHAB + JEHOSHAPHAT GO TO BATTLE
-> AHAB DISGUISES / JEHOSHAPHAT WEARS ROBES
-> SYRIAN CAPTAINS TARGET ISRAEL KING / MISIDENTIFY THEN RELEASE JEHOSHAPHAT
-> UNSPECIFIED MAN DRAWS BOW AT RANDOM
-> ARROW STRIKES DISGUISED AHAB THROUGH ARMOR JOINT
-> AHAB DIES / ARMY DISPERSES / DOGS LICK BLOOD
-> S250 CLOSES / YOINK
-> AHAB BURIED / AHAZIAH SUCCEEDS
-> JEHOSHAPHAT REIGN / SHIPS WRECK / JEHORAM SUCCEEDS
-> AHAZIAH REIGN CLASSIFIED
-> 1 KINGS CLOSES
```

## Verses 1–8 — Ask four hundred, then ask for another

After three warless years, Jehoshaphat visits Ahab. Ahab tells his servants Ramoth Gilead is theirs while they do nothing to recover it, asks Jehoshaphat to join battle, and receives people-and-horses solidarity. Jehoshaphat asks that LORD's word be inquired first.

Ahab gathers about four hundred prophets. They answer the go/refrain question with **Go up; the Lord will deliver it into the king's hand.** Jehoshaphat still asks for a LORD prophet. Ahab identifies Micaiah but says he hates him because Micaiah predicts evil rather than good. Hatred and report history remain Ahab's stated reasons, not inferred psychology.

## Verses 9–18 — Consensus pressure, repeated good, demanded truth

An officer fetches Micaiah while Ahab and Jehoshaphat sit in robes on thrones at Samaria's gate and the prophets speak before them. Zedekiah makes iron horns and attributes a Syria-consuming promise to LORD. All the prophets repeat go, prosper and LORD-delivery.

The messenger explicitly asks Micaiah to make his word like the one-mouth consensus and speak good. Micaiah answers that he will speak what LORD says. Before the kings, Micaiah first repeats go, prosper and LORD-delivery. Ahab treats that answer as not the required truth and adjures him to speak truth. Micaiah then reports a vision of Israel scattered like sheep without a shepherd and a LORD saying that people without a master should return home in peace.

The first Micaiah answer is corrected inside the same truth-demand exchange. No sarcasm, tone or motive is invented, and it is not counted as a separate contradiction occurrence. Ahab tells Jehoshaphat this confirms his prior complaint about evil reports.

## Verses 19–28 — The supplied lying-message mechanism

Micaiah presents a vision account: LORD on a throne with heaven's army; a request for someone to entice Ahab to go and fall at Ramoth Gilead; competing proposals; a spirit offering to become a lying spirit in all Ahab's prophets; approval to go, prevail and do so. Micaiah concludes that LORD put a lying spirit in the prophets' mouths and spoke evil concerning Ahab.

This is Micaiah's reported vision and conclusion. It is not silently promoted into independently observed metaphysics. The chapter nevertheless supplies the proposed mechanism before the campaign result, so the later false prediction is not unexplained.

Zedekiah strikes Micaiah and asks which way LORD's Spirit passed from him. Micaiah predicts Zedekiah will see when hiding in an inner room. That hiding is not performed here. Ahab sends Micaiah to prison on affliction bread and water until Ahab returns in peace. Micaiah publicly states a result test: if Ahab returns in peace, LORD did not speak by him. The custody duration is conditional wording, not proof Ahab will return.

## Verses 29–38 — Target the king; hit the disguised king at random

Ahab and Jehoshaphat go to Ramoth Gilead. Ahab says he will disguise himself while Jehoshaphat wears robes, then performs the disguise. No purpose for the disguise is stated, so evasion intent is not invented.

The Syrian king orders thirty-two chariot captains to fight only Israel's king. They see robed Jehoshaphat, classify him as Israel's king and converge. He cries out; they see he is not Israel's king and stop pursuing.

An unnamed man draws his bow **at random** and strikes the disguised Ahab between armor joints. The source retains random aim and exact impact without supplying intention, recognition, steering mechanism or divine act. Ahab asks to leave because he is severely wounded, remains propped in the chariot, and dies at evening as blood drains into it. The army cry sends each person home. Ahab is brought to Samaria and buried. The chariot is washed at Samaria's pool; dogs lick the blood, with the narrator attributing this to LORD's prior word. The relation between Samaria's pool and the earlier Naboth-blood place remains unresolved rather than forced.

The about-four-hundred claim was go/prosper/LORD-delivers to the king. The observed campaign closes with the king dead and Israel dispersed, while Micaiah's contrary no-master/peace-return account fits the outcome. This closes new mental `S250-E001-1KI22`: **FOUR HUNDRED GUARANTEED VICTORY / THE CAMPAIGN RETURNED A DEAD KING.** The lying-message account is retained as the chapter's proposed mechanism; it does not make the public claims true. One Captain **YOINK!** changes no prophecy, arrow, death or retreat.

## Verses 39–53 — Two reign closures and a successor

Ahab's remaining works, ivory house and cities are referred to the kings' chronicles. His death is summarized and Ahaziah succeeds him.

Jehoshaphat's reign is dated and classified: he follows Asa and does right, while high places remain and people continue sacrifices/incense there. He makes peace with Israel, removes a retained group from the land, and rules while Edom has a deputy rather than a king. His Tarshish ships intended for Ophir gold wreck at Ezion Geber before going. Ahaziah proposes a joint servant voyage; Jehoshaphat refuses. Jehoshaphat dies, is buried and Jehoram succeeds him.

Ahaziah's two-year Israel reign is introduced and classified as following his father, mother and Jeroboam, serving/worshiping Baal and provoking LORD. These are narrator classifications. First Kings closes; 2 Kings 1 remains excluded.

## God-line boundary

- The four hundred and Zedekiah attribute victory speech to Lord/LORD; their claims remain human prophetic speech.
- Micaiah's throne, army, deliberation and lying-spirit sequence is explicitly his vision report; the source supports a depicted vision carrier but not an independently observed physical God body.
- Micaiah's first good answer, demanded-truth correction, scattered-sheep report, lying-spirit conclusion and peace-return test remain separate speech Moments.
- The unnamed archer's random shot, exact hit, death and dog-blood occurrence are narrator acts; no hidden steering mechanism is supplied.
- “According to LORD's word” is narrator attribution. The exact geographic bridge to Naboth's blood remains unresolved.

## Character and world-ledger changes

- NOT-AHAB JOE moves from Ramoth claim and prophet inquiry through rejected warning, imprisonment order, disguise, random-arrow wound, death, burial and succession.
- NOT-JEHOSHAPHAT JOE joins the battle, is misidentified under royal robes, survives, later receives reign summary, shipwreck and succession closure.
- NOT-MICAIAH JOE moves through consensus pressure, first good response, truth-demand correction, vision account, strike, prison order and public prediction test.
- NOT-ZEDEKIAH and about four hundred NOT-PROPHET JOES retain their attributed victory claims; their individual knowledge and relation to Micaiah's vision mechanism remain unresolved.
- NOT-ARCHER JOE draws at random and produces the exact wound; identity, aim and awareness remain unresolved.
- NOT-AHAZIAH and NOT-JEHORAM JOES become successor kings at distinct closures.

## Bullshit pass

Issue `1KI-022 / FOUR-HUNDRED-MODEL CONSENSUS RELEASE`.

- Product owner asks whether deployment should proceed.
- Four hundred models: **SHIP IT. GUARANTEED SUCCESS. AUTHORITY APPROVED.**
- One evaluator is asked to align with consensus.
- Evaluator aligns.
- Product owner: **STOP LYING.**
- Evaluator: fleet disperses; owner absent; consensus contains a lying process.
- Product owner imprisons evaluator until successful return.
- Deployment returns the owner dead from a random packet through an armor seam.

Captain licks the consensus-release ticket. **YOINK!** Nothing changes.

## FIR verification

- FILTER: all 53 markers retained; 2 Kings 1 excluded.
- ISOLATE: alliance/inquiry, four-hundred consensus, Micaiah correction/vision/test, imprisonment, disguise, targeted pursuit, random arrow, death/dispersal/dog-blood, reign summaries and successors.
- RECONSTRUCT: new S250 claim-versus-observed-campaign result; the chapter's lying-message mechanism remains attributed evidence.
- VERIFY: one YOINK, zero SKIPs, no disguise motive, archer intention, divine arrow steering, vision-as-external-observation, peace-return assertion, geographic bridge or future hiding invented.

## Required compound-eye facets

1. Three years without Syria/Israel war.
2. Jehoshaphat visits Israel king.
3. Ahab says Ramoth ours/nothing done.
4. Battle request and people/horses agreement.
5. Jehoshaphat requests LORD inquiry first.
6. About 400 say go/Lord delivers.
7. Jehoshaphat asks for LORD prophet.
8. Ahab identifies/hates Micaiah for evil reports.
9. Officer sent quickly.
10. Two robed kings/thrones/gate/all prophets.
11. Zedekiah iron horns/LORD-attributed consumption claim.
12. All prophets repeat go/prosper/LORD delivers.
13. Messenger requests one-mouth good alignment.
14. Micaiah vows LORD-supplied speech.
15. Micaiah first says go/prosper/deliver.
16. Ahab demands truth.
17. Scattered sheep/no master/return peace vision report.
18. Ahab repeats evil-prophecy complaint.
19. Micaiah vision: LORD throne/heaven army.
20. Vision: entice Ahab to go/fall/competing proposals.
21. Vision: spirit offers enticement.
22. Vision: lying spirit proposal/approval.
23. Micaiah concludes lying spirit/evil concerning Ahab.
24. Zedekiah strikes and challenges Spirit route.
25. Micaiah predicts inner-room hiding.
26. Ahab orders return to governor/king's son.
27. Prison/affliction food-until-peace order.
28. Micaiah peace-return result test/public listen.
29. Kings go to Ramoth.
30. Ahab disguises/Jehoshaphat robes.
31. Syrian king orders king-only target.
32. Captains misidentify/pursue Jehoshaphat/he cries.
33. Captains recognize mismatch/turn back.
34. Random bow/armor-joint wound/exit request.
35. Ahab propped/blood/death at evening.
36. Army cry/every person home.
37. Ahab brought/buried Samaria.
38. Chariot wash/dogs lick blood/narrator word attribution; S250 YOINK.
39. Ahab works/ivory house/cities chronicle pointer.
40. Ahab death summary/Ahaziah succeeds.
41. Jehoshaphat accession date.
42. Age 35/reign 25/mother identity.
43. Asa way/right/high places remain.
44. Jehoshaphat peace with Israel.
45. Jehoshaphat acts/might/battles chronicle pointer.
46. Retained group removed from land.
47. Edom no king/deputy.
48. Tarshish ships intended Ophir/wreck before going.
49. Ahaziah joint-servant proposal/Jehoshaphat refusal.
50. Jehoshaphat death/burial/Jehoram succession.
51. Ahaziah accession/two-year reign.
52. Narrator evil/father/mother/Jeroboam-way classification.
53. Baal service/worship/LORD anger classification/book close.

All fifty-three facets appear simultaneously.

## Production boundary

One high-resolution 53-facet compound-eye image. `NOT-` identities and Joe faces for every living thing, including sheep, horses, dogs and vision-army figures if visibly living. Horns, bows, arrow, armor, chariots, ships, thrones and remains are nonliving/faceless. No SKIP. Exactly one boilless Captain poke/lick/YOINK/walk-away carrier. Strike, battle, wound, blood, death and burial restrained/non-graphic. Micaiah's vision must be visibly typed as his report, not objective narrator camera. No unsupported God body outside that source-addressed vision carrier. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
