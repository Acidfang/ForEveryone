# CRACKHEAD 1 KINGS 1

## Title field

**NOT-ADONIJAH: I WILL BE KING. / NOT-DAVID: SOLOMON WILL BE KING TODAY.**

Source parent: ENGWEBP 1 Kings chapter 1, verses 1-53, USFM. Prepared evidence: `.chapter-work/CHB-1KI-001/job.json` and `source.usfm`. Parent: 2 Samuel 24. Exact identities remain evidence; visible names use `NOT-`. Every living thing, including mule and sacrificed animals, is Joe-faced. Intimacy, slaughter and threatened death remain restrained/non-graphic.

CrackFlix: new `S221-E001-1KI1`, no SKIP. Exactly one causally-null post-closure YOINK. One high-resolution compound-eye field with all 53 verse Moments co-present.

## Causal foundation

```text
OLD DAVID CANNOT KEEP WARM
-> SERVANTS SEARCH / ABISHAG SERVES / NO INTIMACY
-> ADONIJAH: I WILL BE KING
-> CHARIOTS / FIFTY RUNNERS / JOAB + ABIATHAR SUPPORT
-> EXCLUDED DAVID GROUP + SOLOMON
-> ADONIJAH FEAST / KING ACCLAMATION
-> NATHAN COUNSELS BATHSHEBA
-> BATHSHEBA REPORTS SOLOMON OATH + ADONIJAH STATE
-> NATHAN ENTERS AND CONFIRMS OBSERVATIONS
-> DAVID REAFFIRMS OATH / ORDERS SOLOMON INSTALLED TODAY
-> MULE / GIHON / OIL / TRUMPET / THRONE
-> CITY REJOICES
-> ADONIJAH FEAST HEARS / JONATHAN REPORTS SOLOMON KING
-> GUESTS DISPERSE / ADONIJAH HOLDS ALTAR HORNS
-> SOLOMON ISSUES CONDITIONAL SAFETY
-> ADONIJAH BROUGHT DOWN / SENT HOME
```

## Verses 1–4 — David, servants and Abishag

David is old and cannot keep warm under clothes. Servants propose finding a young virgin to stand before, cherish, lie beside and warm him. They search Israel, find Abishag and bring her. She serves and cherishes David; narrator explicitly says David does not know her intimately. Her consent, selection authority and private feeling are not supplied.

## Verses 5–10 — Adonijah constructs kingship

Adonijah exalts himself and says **“I will be king,”** preparing chariots, horsemen and fifty runners. Narrator says David had never challenged his acts; Adonijah is handsome and born after Absalom. Joab and Abiathar help him. Zadok, Benaiah, Nathan, Shimei, Rei and David's mighty men do not join.

Adonijah kills animals at Zoheleth and calls royal brothers and Judah servants, excluding Nathan, Benaiah, mighty men and Solomon. This is observable selection; no motive is invented.

## Verses 11–27 — coordinated report to David

Nathan tells Bathsheba Adonijah reigns without David knowing, warns that her and Solomon's lives require action, supplies exact oath-question wording, and says he will enter afterward to confirm her words.

Bathsheba enters, reports David's oath that Solomon would reign, states Adonijah now reigns without David's knowledge, lists Adonijah's invited supporters and Solomon's exclusion, says Israel awaits David's succession declaration, and predicts that after David sleeps with his fathers she and Solomon will be considered criminals.

Nathan enters as planned, reports the feast/acclamation and excluded group, and asks whether David authorized it without telling servants. This coordination is stated openly before execution; it is not silently relabeled independent confirmation.

## Verses 28–31 — oath reaffirmed and the forever line

David calls Bathsheba back, vows by living LORD, confirms his prior Solomon oath and says he will perform it today.

Bathsheba—having just described David's future sleep with his fathers—then says **“Let my lord King David live forever!”** This closes new `S221-E001-1KI1`: **WHEN YOU DIE / LIVE FOREVER.** No idiom limitation is supplied inside the selected encounter. No SKIP. One post-closure Captain pokes the contradiction-fed boil, says **“YOINK!”**, licks his finger and walks away without looking back. The succession continues unchanged.

## Verses 32–40 — Solomon installed

David calls Zadok, Nathan and Benaiah; orders Solomon placed on David's mule, taken to Gihon, anointed, proclaimed by trumpet, returned to sit on the throne and appointed over Israel/Judah. Benaiah says amen and wishes divine confirmation and a greater Solomon throne.

The order is executed. Zadok uses oil from the Tent; Solomon is anointed; trumpet and people proclaim him; public piping and joy shake the earth. The described sound effect remains narrator language, not a geological measurement.

## Verses 41–48 — the other feast receives the result

Adonijah's party hears the city after finishing food. Joab asks about the uproar. Adonijah calls arriving Jonathan worthy and predicts good news. Jonathan instead reports David made Solomon king, lists the procession/anointing/throne, and reports servants blessing David with wishes that Solomon exceed him. David bows and blesses LORD for seeing a successor on his throne.

Adonijah's prediction and later unwanted information are changed knowledge, not contradiction.

## Verses 49–53 — dispersal, altar and conditional release

Adonijah's guests fear and disperse. Adonijah fears Solomon and holds altar horns, requesting an oath against sword death. Solomon says worthy conduct means safety and found wickedness means death. Solomon has him brought down; Adonijah bows; Solomon sends him home. Worthiness/wickedness remains a future conditional selector, not a present verdict.

## God-line boundary

No direct God speech occurs. David swears by LORD and attributes past redemption; Bathsheba reports a LORD-oath; Benaiah and servants express wishes about God; David blesses LORD and attributes the observed succession. No divine body, confirmation or causal intervention is invented.

## Character and world-ledger changes

- NOT-DAVID remains alive, reaffirms his oath and installs Solomon.
- NOT-ABISHAG enters as a serving/cherishing participant with agency beyond acts unresolved.
- NOT-ADONIJAH self-proclaims, assembles support, loses the public succession contest, takes altar refuge and receives conditional release.
- NOT-NATHAN and NOT-BATHSHEBA execute their stated report sequence.
- NOT-SOLOMON becomes publicly anointed king, sits on the throne and issues his first retained conditional judgment.
- NOT-JOAB and NOT-ABIATHAR join Adonijah's party; NOT-ZADOK, NOT-BENAIAH and David's retained group install Solomon.

## Bullshit pass

Issue `1KI-001 / TWO KINGS — ONE CHAIR`. Crackhead Royal Streaming launches simultaneous unauthorized previews: **ADONIJAH NOW PLAYING** and **SOLOMON — OFFICIAL RELEASE**. Bethlehem Forever Plans terminate when the subscriber sleeps with his fathers. Altar horns provide no written warranty. Foundation unchanged.

## FIR verification

- FILTER: all 53 markers retained; chapter 2 excluded.
- ISOLATE: warming process, competing succession acts, coordinated report, David order, public installation, feast collapse and conditional release.
- RECONSTRUCT: S221 closes only on Bathsheba's adjacent death expectation/forever speech.
- VERIFY: zero SKIPs, one YOINK, no motive/consent/divine action invented; publication held.

## Required compound-eye facets

1. Old David/clothes/no warmth.
2. Servants propose young-woman warming role.
3. Search/found Abishag/brought to king.
4. Abishag serves/cherishes/no intimacy.
5. Adonijah I-will-be-king/chariots/fifty runners.
6. David never challenged/handsome/after Absalom.
7. Joab/Abiathar help.
8. Zadok/Benaiah/Nathan/Shimei/Rei/mighty men not with him.
9. Zoheleth slaughter/invited brothers/Judah servants.
10. Nathan/Benaiah/mighty men/Solomon excluded.
11. Nathan tells Bathsheba Adonijah reigns/David unaware.
12. Nathan life-saving counsel.
13. Supplied Solomon-oath question.
14. Nathan planned confirmation.
15. Bathsheba enters/Abishag serves.
16. Bow/respect/what-would-you-like.
17. Bathsheba reports LORD-oath/Solomon throne.
18. Adonijah reigns/David unaware.
19. Feast supporters/Solomon excluded.
20. Israel eyes await successor declaration.
21. David sleeps/Bathsheba-Solomon criminals prediction.
22. Nathan enters as planned.
23. Nathan announced/bows.
24. Nathan asks whether David appointed Adonijah.
25. Nathan reports feast/acclamation.
26. Nathan reports excluded group.
27. Nathan authorization/non-disclosure question.
28. David calls Bathsheba back.
29. David living-LORD/redemption vow.
30. David oath reaffirmed/do today.
31. Bathsheba death expectation versus live-forever; `S221-E001` and one separate YOINK.
32. David calls Zadok/Nathan/Benaiah.
33. Mule/Gihon order.
34. Anoint/trumpet/Long-live-Solomon order.
35. Throne/king/prince appointment.
36. Benaiah amen/divine confirmation wish.
37. Greater Solomon throne wish.
38. Procession on David's mule.
39. Tent oil/anoint/trumpet/acclamation.
40. People pipes/joy/earth-shaking sound.
41. Adonijah feast hears/Joab asks uproar.
42. Jonathan arrives/Adonijah predicts good news.
43. Jonathan: David made Solomon king.
44. Jonathan procession report.
45. Jonathan anointing/city-noise report.
46. Solomon sits throne.
47. Servants' greater-name/throne wish/David bows.
48. David blessing/seeing successor.
49. Adonijah guests fear/disperse.
50. Adonijah fears/altar horns.
51. Reported request for Solomon no-kill oath.
52. Solomon worthy-safe/wicked-die condition.
53. Adonijah brought down/bows/go-home release; chapter 2 excluded.

All fifty-three facets appear simultaneously.

## Production boundary

One high-resolution 53-facet compound-eye image. `NOT-` display; every living thing Joe-faced; intimacy/slaughter/death restrained; no divine body. Exactly `S221-E001-1KI1`, no SKIP, exactly one causally-null post-closure YOINK. Publication held; originator review required.

*shrug*

OK.
