# CRACKHEAD 1 KINGS 4

## Title field

**NOT-ABIATHAR: REMOVED FROM PRIESTHOOD. / THE NEXT ROSTER: ABIATHAR WAS PRIEST.**

Source parent: ENGWEBP 1 Kings chapter 4, verses 1-34, USFM. Prepared evidence: `.chapter-work/CHB-1KI-004/job.json` and `source.usfm`. Parent: 1 Kings 3, with the 1 Kings 2 Abiathar-removal Moment retained. Exact identities remain evidence; visible names use `NOT-`. Every living human, animal and plant is Joe-faced.

CrackFlix: `S226-E001-1KI4` plus later-found `S230-E001-1KI4`; neither has a prior same-type episode, so no SKIP. Exactly two separate causally-null post-closure YOINKs. One high-resolution compound-eye field.

## Causal foundation

```text
SOLOMON KING OVER ALL ISRAEL
-> CENTRAL PRINCES/OFFICES LISTED
-> ABIATHAR LISTED AS PRIEST AFTER RETAINED REMOVAL
-> TWELVE REGIONAL OFFICERS EACH SUPPLY ONE MONTH
-> REGIONS/OFFICERS ENUMERATED
-> JUDAH + ISRAEL NUMEROUS / EAT / DRINK / MERRY
-> KINGDOMS BRING TRIBUTE / SERVE
-> DAILY FOOD + ANIMAL PROVISION ENUMERATED
-> DOMINION / PEACE / SAFETY REPORTED
-> HORSE STALLS + HORSEMEN REPORTED
-> RETAINED KING RULE SAYS DO NOT MULTIPLY HORSES
-> S230-E001 CLOSES / SECOND YOINK CHANGES NOTHING
-> OFFICERS SUPPLY TABLE + HORSE FEED WITHOUT LACK
-> GOD-GIVEN WISDOM REPORTED
-> COMPARISONS / PROVERBS / SONGS / NATURAL SUBJECTS ENUMERATED
-> ALL-NATION HEARERS ARRIVE THROUGH KINGS
```

## Verses 1–6 — Central administration

Solomon is king over all Israel. The roster identifies Azariah son of Zadok as priest; Elihoreph and Ahijah as scribes; Jehoshaphat as recorder; Benaiah over the army; Zadok and Abiathar as priests; Azariah son of Nathan over officers; Zabud as chief minister and king's friend; Ahishar over the household; and Adoniram over forced labor.

The prior retained State in 1 Kings 2:26-27 says Solomon removed Abiathar from being priest. This roster then says **“Zadok and Abiathar were priests.”** No reinstatement, retrospective date, honorary category or copying explanation is supplied.

This closes `S226-E001-1KI4`: **REMOVED FROM BEING PRIEST / LISTED AS PRIEST.** Both source Moments remain. No SKIP. One separate Captain poke/lick/**YOINK!**/walk-away changes nothing.

## Verses 7–19 — Twelve monthly provision officers

Twelve officers over Israel provide food for king and household, each for one month. The source lists Ben Hur, Ben Deker, Ben Hesed, Ben Abinadab, Baana son of Ahilud, Ben Geber, Ahinadab, Ahimaaz, Baana son of Hushai, Jehoshaphat son of Paruah, Shimei son of Ela and Geber son of Uri with their regions. Taphath and Basemath are identified as Solomon's daughters and wives of two officers. Similar names are not silently merged; “Ben” forms and two Baanas remain source-distinct unless lineage proves identity.

## Verses 20–28 — Population, dominion and provisioning

Judah and Israel are described as numerous as seaside sand, eating, drinking and making merry. Solomon rules kingdoms from the River to Philistine land and Egypt's border; they bring tribute and serve him all his days. The daily provision is thirty cors fine flour, sixty measures meal, ten fat cattle, twenty pasture cattle, one hundred sheep plus wild animals and fowl.

Narrator reports dominion, peace on all sides, and individual safety under vines and fig trees from Dan to Beersheba. Solomon has forty thousand horse stalls and twelve thousand horsemen. The retained king rule at Deuteronomy 17:16 says the king shall not multiply horses. This closes later-found `S230-E001-1KI4`: **KING MUST NOT MULTIPLY HORSES / KING HAS FORTY THOUSAND STALLS AND TWELVE THOUSAND HORSEMEN.** No quantity threshold, exception or repeal is supplied. It is the first retained occurrence of this contradiction type, so there is no SKIP. A second separate Captain poke/lick/**YOINK!**/walk-away changes nothing.

Monthly officers supply the king's table without lack and bring barley and straw for horses and swift steeds. Counts, conversion footnote, supply allocation and peace scope remain exact source claims; no harmonization with later texts is performed here.

## Verses 29–34 — Wisdom and hearers

Narrator says God gives Solomon abundant wisdom, understanding and breadth of mind like seaside sand. His wisdom exceeds eastern and Egyptian wisdom and named men; his fame spreads. He speaks three thousand proverbs, one thousand five songs, and speaks about trees, animals, birds, creeping things and fish. People of all nations, sent by kings who heard of his wisdom, come to hear him.

These are narrated outcomes and comparisons. Exact works, surviving corpus, comparison method, hearer identities and travel counts are unresolved; absence of those mechanisms is not a contradiction.

## God-line boundary

No direct God speech occurs. Narrator attributes Solomon's wisdom, understanding and breadth of mind to God. No divine act mechanism or body is supplied or rendered. The earlier dream promise remains a parent; this chapter's observed wisdom report may join it without proving every future comparison, riches, honor or lifespan statement.

## Character and world-ledger changes

- NOT-SOLOMON remains king and is assigned a central and regional administration, provisioning system, dominion, peace, horses and wisdom output.
- NOT-ABIATHAR is listed as priest despite the retained removal State.
- NOT-BENAIAH remains over the army; NOT-ZADOK is listed as priest.
- Twelve named regional officers and central office holders enter the ledger with exact lineages and regions.
- NOT-TAPHATH and NOT-BASEMATH enter as Solomon's daughters and officer wives; speech and agency remain unresolved.
- Numerous provisioned animals are living Joe-faced carriers; inventory does not merge individuals.

## Bullshit pass

Issue `1KI-004 / OFFBOARDING COMPLETE — USER STILL IN ACTIVE DIRECTORY`. Royal Catering rotates one province per month and promises **NOTHING LACKING**, including forty thousand horse parking bays. Solomon releases 3,000 proverbs and 1,005 tracks before anyone invents streaming. Foundation unchanged.

## FIR verification

- FILTER: all 34 markers retained; chapter 5 excluded.
- ISOLATE: central roster, twelve-region provisioning, population/dominion, daily supply, peace/horses and wisdom corpus.
- RECONSTRUCT: office mismatch `S226-E001-1KI4`; retained king-rule/horse multiplication mismatch `S230-E001-1KI4`.
- VERIFY: no SKIP, two separate YOINKs, names not merged, quantities retained, divine attribution typed, no explanation invented, publication held.

## Required compound-eye facets

1. Solomon king over all Israel.
2. Azariah son of Zadok/priest.
3. Elihoreph/Ahijah scribes; Jehoshaphat recorder.
4. Benaiah army; Zadok and Abiathar priests; `S226-E001` relation and YOINK.
5. Azariah son Nathan over officers; Zabud minister/friend.
6. Ahishar household; Adoniram forced labor.
7. Twelve officers/one provision month each.
8. Ben Hur/Ephraim hill country.
9. Ben Deker/Makaz-Shaalbim-Beth Shemesh-Elon Beth Hanan.
10. Ben Hesed/Arubboth-Socoh-Hepher.
11. Ben Abinadab/Dor/Taphath wife.
12. Baana son Ahilud/Taanach-Megiddo-Beth Shean route.
13. Ben Geber/Ramoth Gilead/Jair towns/Argob/sixty fortified cities.
14. Ahinadab son Iddo/Mahanaim.
15. Ahimaaz/Naphtali/Basemath wife.
16. Baana son Hushai/Asher-Bealoth.
17. Jehoshaphat son Paruah/Issachar.
18. Shimei son Ela/Benjamin.
19. Geber son Uri/Gilead/Sihon-Og land/only officer.
20. Judah-Israel seaside-sand multitude/eating/drinking/merry.
21. River-to-Philistine-to-Egypt-border rule/tribute/service.
22. Daily thirty cors flour/sixty meal.
23. Daily cattle/sheep/deer/gazelles/roebucks/fowl.
24. River/Tiphsah/Gaza dominion/kings/peace all sides.
25. Safe under vine/fig tree/Dan-Beersheba/all Solomon days.
26. Forty thousand horse stalls/twelve thousand horsemen; `S230-E001` and separate YOINK.
27. Officers monthly table supply/nothing lacking.
28. Barley/straw/horse and swift-steed delivery by duty.
29. God gives abundant wisdom/understanding/breadth like sand.
30. Wisdom exceeds east and Egypt.
31. Wiser-than-all/named comparisons/fame.
32. Three thousand proverbs/one thousand five songs.
33. Trees/hyssop/animals/birds/creeping things/fish speech.
34. All-nation hearers sent by kings; chapter 5 excluded.

All thirty-four facets appear simultaneously.

## Production boundary

One high-resolution 34-facet compound-eye image. `NOT-` display; every living thing Joe-faced; forced-labor State shown without invented conditions; no divine body. Exactly `S226-E001-1KI4` and later-found `S230-E001-1KI4`, zero SKIPs and exactly two separate causally-null post-closure YOINKs. The comic is the finished artifact: review/publication/job/hash/path/instruction State stays exclusively in machine ledgers and is not visible in the image.

*shrug*

OK.
