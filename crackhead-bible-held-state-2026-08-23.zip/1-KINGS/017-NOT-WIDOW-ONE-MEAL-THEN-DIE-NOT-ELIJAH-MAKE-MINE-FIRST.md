# CRACKHEAD 1 KINGS 17

## Title field

**NOT-WIDOW: ONE MEAL, THEN WE DIE. / NOT-ELIJAH: MAKE MINE FIRST. / EVERYONE EATS FOR MANY DAYS. / SON DIES: SHE BLAMES ELIJAH. ELIJAH BLAMES LORD.**

Source parent: ENGWEBP 1 Kings chapter 17, verses 1-24, USFM. Prepared evidence: `.chapter-work/CHB-1KI-017/job.json` and `source.usfm`. Parent: 1 Kings 16. Exact identities remain evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: new mental `S245-E001-1KI17`. Exactly one causally-null post-closure Captain YOINK. No SKIP. One high-resolution 24-facet compound-eye field.

## Causal foundation

```text
ELIJAH ANNOUNCES NO DEW/RAIN EXCEPT BY HIS WORD
-> LORD WORD: HIDE AT CHERITH / RAVENS FEED
-> ELIJAH GOES / RAVENS BRING FOOD / BROOK DRIES
-> LORD WORD: ZAREPHATH WIDOW WILL SUSTAIN
-> WIDOW HAS ONE LAST MEAL MODEL
-> ELIJAH: MAKE MINE FIRST / MEAL + OIL WILL NOT FAIL
-> WIDOW PERFORMS / HOUSEHOLD EATS MANY DAYS
-> SON SICK / NO BREATH
-> WIDOW ASSERTS ELIJAH CAME TO KILL HIM
-> ELIJAH ASSERTS LORD BROUGHT EVIL/KILLED HIM
-> NARRATOR SUPPLIES DEATH STATE BUT NEITHER PRODUCING CAUSE
-> S245 MENTAL CRACK / YOINK
-> ELIJAH PRAYS THREE TIMES
-> LORD LISTENS / SOUL RETURNS / CHILD REVIVES
-> CHILD RETURNED / WIDOW STATES WORD-TRUTH KNOWLEDGE
```

## Verses 1–7 — Weather announcement and raven delivery route

Elijah the Tishbite, a Gilead settler, tells Ahab that as LORD lives, before whom Elijah stands, there will be neither dew nor rain for years except according to Elijah's word. The duration and later ending are not performed in this chapter.

LORD's word comes to Elijah directing him east to hide at brook Cherith, drink from it, and stating that ravens have been commanded to feed him there. Elijah performs the route and residence. Ravens bring bread and meat morning and evening; he drinks from the brook. The ravens are living Joe-faced carriers. Their command reception and food provenance remain unresolved.

After a while the brook dries because there is no rain in the land. That is the performed consequence of the retained no-rain State, not a contradiction in the water supply.

## Verses 8–16 — “Feed him” meets “one meal, then die”

LORD's word directs Elijah to Zarephath in Sidon and says a widow there has been commanded to sustain him. Elijah reaches the city gate and sees a widow gathering sticks. He requests a little water; while she goes, he adds a request for a morsel of bread.

The widow swears by Elijah's God that she has nothing baked, only a handful of meal and a little oil. She is gathering two sticks to bake it for herself and her son so they may eat and die. This is her present inventory and future model; the anticipated death is not yet external fact.

Elijah tells her not to fear, to do as she said but make him a little cake first, then make food for herself and her son. He carries a LORD saying: the meal jar will not run out and the oil jar will not fail until LORD sends rain.

She performs the instruction. She, Elijah and her household eat for many days. The meal does not run out and oil does not fail according to LORD's word through Elijah. The initial finite inventory and later continuing supply are joined by an explicit changed-State carrier. The physical replenishment mechanism remains unresolved; it is not routed as a contradiction merely because it is unexplained.

## Verses 17–22 — Two causal accusations, zero supplied cause

After these things the widow's son becomes severely sick until no breath remains. The narrator supplies sickness and no-breath State but no producing cause.

The widow tells Elijah that he came to bring her sin to memory and kill her son. Elijah takes the child to his upstairs room and bed, then cries to LORD: **“Have you also brought evil on the widow with whom I am staying, by killing her son?”**

The widow assigns the death to Elijah's purpose and her remembered sin. Elijah assigns it to LORD. Neither supplies observed intervention, and the narrator confirms neither causal claim. The claims are mutually different and each exceeds the retained evidence boundary. This closes new mental `S245-E001-1KI17` at the two human models, not at an imagined divine or physical cause. One Captain **YOINK!** changes no death State or causal evidence.

Elijah stretches himself on the child three times and asks LORD to let the child's soul return. LORD listens to Elijah's voice; the child's soul returns and he revives. The prayer, three physical acts, narrator-attributed listening, returned soul and revived State are retained in order. No biological or spiritual mechanism is invented.

## Verses 23–24 — Return the living result

Elijah carries the child downstairs, gives him to his mother and says her son lives. The woman says she now knows Elijah is a man of God and LORD's word in his mouth is truth. This is her knowledge claim at the final Moment; it does not retroactively prove every earlier causal accusation.

## God-line boundary

- Elijah's no-rain announcement invokes LORD but is Elijah-carried speech; its exact authority relation remains as stated.
- Direct LORD words to Elijah supply Cherith and Zarephath routes, raven/widow sustainment statements and the meal/oil saying later carried through Elijah.
- Raven delivery and jar persistence are narrator-performed outcomes according to the carried word; no divine body or mechanism is rendered.
- The widow's “you killed” and Elijah's “you killed” prayer are human causal attributions, not narrator-confirmed divine acts.
- LORD listening, soul return and revival are narrator acts; no form, body or mechanism is invented.

## Character and world-ledger changes

- NOT-ELIJAH announces drought, follows two location commands, receives raven/widow support, requests first food, carries the jar saying, receives the dead child, prays and returns him alive.
- NOT-AHAB receives Elijah's weather statement; no response is supplied here.
- NOT-RAVEN JOES deliver morning/evening food; source and command mechanism remain unresolved.
- NOT-WIDOW JOE moves from last-meal inventory/model to many-day household food, loses her son's breath, makes a causal accusation and receives him alive.
- NOT-WIDOW'S-SON JOE moves from living to no-breath to revived through explicitly retained Moments.

## Bullshit pass

Issue `1KI-017 / LAST-MEAL PRIORITY SERVICE`.

- Customer inventory: one handful, little oil, two sticks, one final family meal.
- Contractor request: provide his cake first.
- Service-level guarantee: jar does not finish until weather service resumes.
- Result: household eats many days; implementation documentation is blank.
- Incident attribution: customer blames contractor; contractor escalates and blames system owner; evidence ledger contains only **SON: NO BREATH**.
- Resolution: lie on customer three times, shout at system owner, return living customer.

Captain licks the competing causal tickets once. **YOINK!** Nothing changes.

## FIR verification

- FILTER: all 24 markers retained; chapter 18 excluded from story pixels.
- ISOLATE: drought speech, Cherith route/support/drying, Zarephath inventory/request/supply, son sickness/death accusations, prayer/revival and returned child.
- RECONSTRUCT: one mental contradiction containing two unsupported competing causal claims; unexplained raven, jar and revival mechanisms remain unresolved rather than called cracks.
- VERIFY: zero SKIPs, one YOINK, no divine body, invented food provenance, widow prior knowledge, sin identity, death cause or revival mechanism, story-only pixels.

## Required compound-eye facets

1. Elijah/Ahab no-dew/no-rain announcement.
2. LORD word sends Elijah east/hide at Cherith.
3. Brook drink/raven-command sustainment speech.
4. Elijah performs route/residence.
5. Ravens bring bread/meat morning/evening; brook drinking.
6. Brook dries/no-rain cause.
7. LORD word sends Elijah to Zarephath/widow sustainment statement.
8. Elijah arrives/widow gathers sticks/water request.
9. Widow begins water act/Elijah adds bread request.
10. Widow handful meal/little oil inventory.
11. Two sticks/last meal/then-die model.
12. Elijah no-fear/make-mine-first instruction.
13. Afterward-self-and-son instruction/LORD jar saying.
14. Widow performs/three-party household eats many days.
15. Meal/oil do not fail according mediated word.
16. Son severe sickness/no breath.
17. Widow blames Elijah/sin-memory causal model.
18. Elijah takes child/upstairs/bed.
19. Elijah blames LORD in prayer; S245 mental YOINK with widow claim.
20. Elijah stretches three times/requests soul return.
21. LORD listens/soul returns/child revives.
22. Elijah carries child downstairs.
23. Child delivered/“your son lives.”
24. Woman's final man-of-God/word-is-truth knowledge claim.

All twenty-four facets appear simultaneously.

## Production boundary

One high-resolution 24-facet compound-eye image. `NOT-` identities and Joe faces for every living thing, including ravens. Food, jars, sticks, brook, bed and other objects are nonliving/faceless. Zero SKIPs and exactly one separate boilless Captain poke/lick/YOINK/walk-away carrier at the competing unsupported causal claims. Child sickness/death/revival is restrained/non-graphic. No divine body. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
