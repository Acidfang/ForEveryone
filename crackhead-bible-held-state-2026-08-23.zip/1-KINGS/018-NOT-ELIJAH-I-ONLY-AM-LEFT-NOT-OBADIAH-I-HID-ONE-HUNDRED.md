# CRACKHEAD 1 KINGS 18

## Title field

**NOT-OBADIAH: I HID ONE HUNDRED LORD PROPHETS. / NOT-ELIJAH: I, EVEN I ONLY, AM LEFT. / NOT-CAPTAIN: YOINK!**

Source parent: ENGWEBP 1 Kings chapter 18, verses 1-46, USFM. Prepared evidence: `.chapter-work/CHB-1KI-018/job.json` and `source.usfm`. Parent: 1 Kings 17. Exact identities remain evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: recurring mental `S245-E002-1KI18` with inert `SKIP -> S245-E001-1KI17`; new physical `S246-E001-1KI18`. Exactly two separate causally-null post-closure Captain YOINKs. One SKIP. One high-resolution 46-facet compound-eye field.

## Causal foundation

```text
LORD WORD: SHOW YOURSELF TO AHAB / I WILL SEND RAIN
-> ELIJAH GOES / FAMINE SEVERE
-> OBADIAH'S HIDDEN ONE HUNDRED PROPHETS RETAINED
-> AHAB AND OBADIAH SEARCH FOR GRASS
-> OBADIAH MEETS ELIJAH / PREDICTS DISAPPEARANCE AND DEATH
-> ELIJAH SWEARS TO APPEAR / OBADIAH REPORTS / AHAB MEETS
-> AHAB: YOU TROUBLED ISRAEL
-> ELIJAH: AHAB AND HIS HOUSE TROUBLED ISRAEL
-> NO NARRATED TROUBLE-CAUSE BRIDGE
-> SKIP S245-E001-1KI17 / S245-E002 MENTAL CRACK / YOINK
-> ISRAEL AND PROPHETS GATHER AT CARMEL
-> ELIJAH: I ONLY AM LEFT AS LORD PROPHET
-> RETAINED ONE HUNDRED LORD PROPHETS STILL HIDDEN
-> S246 PHYSICAL CRACK / YOINK
-> TWO-BULL / NO-FIRE TEST AGREED
-> BAAL CALLS RECEIVE NO VOICE, ANSWER OR ATTENTION
-> LORD ALTAR REPAIRED / WATER POURED THREE TIMES
-> ELIJAH PRAYS / LORD FIRE CONSUMES OFFERING, WOOD, STONES, DUST, WATER
-> PEOPLE DECLARE LORD GOD
-> BAAL PROPHETS SEIZED AND KILLED
-> ELIJAH ANNOUNCES RAIN SOUND / SEVENTH LOOK FINDS SMALL CLOUD
-> SKY BLACKENS / GREAT RAIN / AHAB RIDES / ELIJAH RUNS
```

## Verses 1–6 — Rain instruction inside severe famine

In the third year LORD's word tells Elijah to show himself to Ahab and says rain will be sent on the earth. Elijah goes. The famine is severe in Samaria.

Ahab calls household overseer Obadiah. The narrator says Obadiah greatly fears LORD and, when Jezebel cut off LORD's prophets, hid one hundred of them in two caves and supplied bread and water. The exact number killed, food/water provenance and continuing hidden condition remain unresolved; the one hundred living prophets are retained.

Ahab orders a search of springs and brooks for grass to preserve horses and mules. Ahab and Obadiah divide the land and travel separately. The animals are living Joe-faced participants; the survival outcome is not yet supplied.

## Verses 7–16 — Obadiah's future model meets an oath

Obadiah recognizes Elijah, falls and asks whether it is him. Elijah confirms and directs him to tell Ahab that Elijah is here.

Obadiah asks how he sinned that Elijah would deliver him to be killed. He reports that Ahab searched nations and kingdoms and demanded oaths when Elijah was not found. He predicts that LORD's Spirit will carry Elijah somewhere unknown after Obadiah leaves, causing Ahab to kill him. This is Obadiah's conditional future model, not an observed future act. Its universal search scope and Spirit mechanism remain unresolved.

Obadiah recounts hiding one hundred LORD prophets. Elijah swears by living LORD that he will show himself to Ahab that day. The oath supplies a new assurance relation. Obadiah reports to Ahab, and Ahab meets Elijah. The predicted disappearance and killing do not occur in this chapter.

## Verses 17–20 — “You troubled Israel” / “No, you did”

Ahab calls Elijah the troubler of Israel. Elijah denies it and attributes the trouble to Ahab and his father's house forsaking LORD's commandments and following Baals. Severe famine is observed, but neither speaker supplies a complete narrated causal chain for the broader “trouble” attribution.

This repeats the competing unsupported causal-model relation from `S245-E001-1KI17`. An inert **SKIP -> S245-E001-1KI17** points to that retained contradiction and deletes no Moment. `S245-E002-1KI18` remains mental crack in the competing claims. One Captain **YOINK!** changes no famine, action or causal evidence.

Elijah directs Ahab to gather all Israel, 450 Baal prophets and 400 Asherah prophets who eat at Jezebel's table at Mount Carmel. Ahab sends and gathers Israel and the prophets. Whether all 400 Asherah prophets attend is not separately confirmed.

## Verses 21–24 — One hundred hidden / “I only am left”

Elijah asks the people how long they will waver between two sides and directs them to follow LORD if LORD is God or Baal if Baal is. They initially say nothing.

Elijah then says: **“I, even I only, am left as a prophet of the LORD.”** The same chapter already retains Obadiah's one hundred hidden LORD prophets. No death, declassification, narrower “public-at-Carmel” scope or other bridge removes them before Elijah's statement.

This closes new physical `S246-E001-1KI18`: **ONE HUNDRED LORD PROPHETS HIDDEN / I ONLY AM LEFT.** One Captain **YOINK!** changes neither group. Captain does not decide theology or repair arithmetic.

Elijah proposes two bulls, wood and no supplied fire. Baal's prophets call their god; Elijah calls LORD. The God answering by fire will be treated as God. The people explicitly agree.

## Verses 25–29 — No voice, answer or attention

Baal's prophets choose and prepare a bull without fire. From morning to noon they call and leap, but no voice or answer is observed. Elijah mocks them with possible thought, absence, journey or sleep explanations. These are mock proposals, not evidence-backed Baal States.

They cry, cut themselves with knives and lances and prophesy until evening. The scene remains restrained and non-graphic. The narrator again supplies no voice, no answer and no attention. Absence of an observed response closes only this selected test boundary; no deity body is invented or rendered.

## Verses 30–39 — Twelve stones, twelve jars, one fire occurrence

The people approach. Elijah repairs the thrown-down LORD altar, takes twelve stones for Jacob's twelve tribes and builds an altar. The retained word naming Jacob “Israel” is historical attribution, not a new direct voice. Elijah makes a trench with a stated two-seah seed capacity, arranges wood, prepares the bull and orders four water jars poured over offering and wood three times. Water runs around the altar and fills the trench. Water provenance during famine remains unresolved, not contradictory.

At evening Elijah prays to LORD, God of Abraham, Isaac and Israel, asking that LORD, Elijah's servant relation and acts at LORD's word be known, and that the people know LORD is God and has turned their heart back. These are Elijah's prayer claims and requests.

LORD's fire falls and consumes offering, wood, stones and dust, and licks up trench water. The narrator supplies the fire occurrence and effects but no physical mechanism or divine body. The people see, fall and twice declare LORD is God. Their earlier silence and later declaration are separated by the observed test result and therefore are a changed State, not a contradiction.

## Verses 40–46 — Killing, seven looks and rain

Elijah orders the Baal prophets seized with none escaping. The people seize them; Elijah takes them to brook Kishon and kills them there. The event is retained without graphic depiction, invented individual acts or motive.

Elijah tells Ahab to eat and drink because there is a sound of abundant rain. Ahab does. Elijah bows on Carmel and sends his servant to look toward the sea. The servant first reports nothing; Elijah orders repeated looks seven times. On the seventh the servant reports a small cloud like a man's hand rising from the sea.

Elijah tells Ahab to prepare and descend before rain stops him. The sky becomes black with clouds and wind, and great rain occurs. Ahab rides to Jezreel. LORD's hand is narrator-attributed on Elijah; Elijah secures his cloak and runs before Ahab to Jezreel's entrance. The rain fulfils the chapter-opening announced State through an explicit observation chain. Cloud growth, rain and running mechanisms remain unresolved.

## God-line boundary

- Direct LORD word tells Elijah to show himself to Ahab and states rain will be sent.
- Obadiah's predicted Spirit transport and death, Ahab's trouble claim, Elijah's counterclaim, Elijah's only-prophet claim and Elijah's Carmel prayer remain participant speech at their exact boundaries.
- LORD fire, LORD hand and resulting rain sequence are narrator-attributed acts/effects; no divine body or hidden mechanism is rendered.
- Elijah's mock Baal explanations remain mock proposals; no Baal form, voice or internal State is invented.
- The historical Jacob-to-Israel naming word is retained as a parent attribution rather than replayed as a new voice.

## Character and world-ledger changes

- NOT-ELIJAH JOE appears to Ahab, stages the Carmel test, makes the only-prophet claim, repairs the altar, prays, orders seizure, announces rain and runs to Jezreel.
- NOT-AHAB JOE searches for grass, meets Elijah, gathers Israel/prophets, makes the trouble claim, eats, rides and reaches Jezreel.
- NOT-OBADIAH JOE retains household authority, one-hundred-prophet concealment/support, a conditional death model and completed messenger act.
- NOT-JEZEBEL JOE remains alive and linked to prophet cutting-off and table support; she is not observed at Carmel.
- NOT-PROPHET JOES remain distinct: one hundred hidden LORD prophets, 450 Baal prophets, and 400 Asherah prophets named in the gathering command. Attendance and outcome classes are not merged.
- NOT-ISRAEL JOES move from silence to explicit agreement and later declaration after the observed fire occurrence.
- NOT-HORSE, NOT-MULE and other living animal Joes remain Joe-faced if shown. Bulls are living until the source preparation/death Moments; thereafter their remains are nonliving.

## Bullshit pass

Issue `1KI-018 / ONLY EMPLOYEE LEFT — EXCEPT THE HUNDRED IN THE CAVES`.

- Disaster recovery cache: 100 prophets, two caves, bread and water.
- Executive inventory statement: **I ONLY AM LEFT.**
- Audit result: 1 does not absorb 100 without a scope bridge.
- Vendor response test: shout all day; no voice, answer or attention.
- Internal response test: soak the entire ticket twelve jars deep, then burn the ticket, desk, rocks, dust and remaining water.
- Weather deployment: check status seven times; first six return `NOTHING`; seventh returns `HAND-SIZED CLOUD`; production rain follows.

Captain services the competing-blame ticket and the 1-versus-100 ticket separately. **YOINK! YOINK!** Nothing changes.

## FIR verification

- FILTER: all 46 markers retained; chapter 19 excluded from story pixels.
- ISOLATE: rain instruction, hidden prophets, search, Obadiah encounter/model/oath, competing trouble claims, Carmel assembly/test, only-prophet claim, calls, altar/water/fire, seizure/killing and rain sequence.
- RECONSTRUCT: recurring S245 competing unsupported attribution plus new S246 exact one-versus-one-hundred contradiction.
- VERIFY: one inert SKIP, two distinct YOINKs, no divine/deity body, invented motive, water/fire/rain mechanism, Asherah attendance, universal search proof or graphic injury/death.

## Required compound-eye facets

1. LORD word: show yourself/I send rain.
2. Elijah goes; severe Samaria famine.
3. Ahab calls Obadiah/household role/fears LORD.
4. Jezebel cut-off history; Obadiah hides 100 in two caves and feeds them.
5. Ahab orders spring/brook/grass search to preserve animals.
6. Ahab/Obadiah divide land and travel separately.
7. Obadiah meets/recognizes/bows to Elijah.
8. Elijah confirms and orders report to Ahab.
9. Obadiah asks how he sinned/delivered to death.
10. Ahab nation/kingdom search-and-oath report.
11. Elijah-is-here instruction restated.
12. Obadiah predicts Spirit removal/Ahab killing.
13. Obadiah recounts lifelong fear and hidden 100.
14. Elijah swears to appear that day.
15. Obadiah reports; Ahab meets Elijah.
16. Ahab calls Elijah troubler.
17. Elijah counterattributes trouble; S245 SKIP/YOINK.
18. Elijah orders Israel/450 Baal/400 Asherah gathering.
19. Ahab sends and gathers at Carmel.
20. Elijah two-side question; people silent.
21. Elijah says only LORD prophet left; S246 YOINK against hidden 100.
22. Two bulls/no-fire preparation proposal.
23. Answer-by-fire test/people agree.
24. Baal prophets choose/prepare/call without fire.
25. Morning-to-noon calls; no voice/answer; leaping.
26. Elijah's explicit mock possibilities.
27. Restrained self-cutting/crying.
28. Until evening: no voice/answer/attention.
29. People approach; Elijah repairs thrown-down altar.
30. Twelve stones/Jacob-Israel history.
31. Altar/trench two-seah capacity.
32. Wood/bull/four-water-jar order.
33. Second and third four-jar pours.
34. Water around altar/trench filled.
35. Elijah evening prayer: identity/servant/word claims.
36. Elijah hear-me/people-know/heart-turn prayer.
37. LORD fire consumes offering/wood/stones/dust/water.
38. People see/fall/declare LORD God twice.
39. Elijah orders Baal prophets seized/none escape.
40. Seizure/Kishon/killing, restrained.
41. Elijah announces rain sound; Ahab eats/drinks.
42. Elijah bows at Carmel.
43. Servant first sees nothing; seven-look order.
44. Seventh look hand-sized cloud; Ahab warning.
45. Black sky/wind/great rain/Ahab rides.
46. LORD hand attribution/Elijah runs to Jezreel entrance.

All forty-six facets appear simultaneously.

## Production boundary

One high-resolution 46-facet compound-eye image. `NOT-` identities and Joe faces for every living thing. Manufactured altars, images, tools and other objects are nonliving/faceless. One exact inert `SKIP -> S245-E001-1KI17`, two separate boilless Captain poke/lick/YOINK/walk-away carriers. Restrained self-injury and killing. No divine or deity body. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
