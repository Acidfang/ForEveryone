# CRACKHEAD 1 KINGS 20

## Title field

**NOT-SYRIA: THEIR GOD IS OF THE HILLS, NOT THE VALLEYS. / FIGHT THEM IN THE PLAIN. / LOSE IN THE PLAIN. / NOT-AHAB: LET THEIR KING GO. / YOUR PEOPLE PAY.**

Source parent: ENGWEBP 1 Kings chapter 20, verses 1-43, USFM. Prepared evidence: `.chapter-work/CHB-1KI-020/job.json` and `source.usfm`. Parent: 1 Kings 19. Exact identities remain evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: new mental `S248-E001-1KI20`; recurring physical `S127-E013-1KI20` with inert `SKIP -> S127-E012-1KI16`. Exactly two separate causally-null post-closure Captain YOINKs. One SKIP. One high-resolution 43-facet compound-eye field.

## Causal foundation

```text
BEN HADAD + 32 KINGS BESIEGE SAMARIA
-> FIRST DEMAND / AHAB ACCEPTS
-> EXPANDED SEARCH-AND-TAKE DEMAND / ELDERS REJECT / AHAB REFUSES EXPANSION
-> THREATS / ATTACK PREPARED
-> PROPHET CARRIES TODAY-DELIVERY WORD
-> 232 YOUNG MEN + 7000 ISRAEL GO OUT
-> FIRST SYRIAN DEFEAT / BEN HADAD ESCAPES
-> PROPHET WARNS YEAR-RETURN
-> SYRIAN ADVISERS: LORD IS HILL GOD, NOT VALLEY GOD
-> MOVE REMATCH TO PLAIN / REBUILD ARMY
-> MAN OF GOD CARRIES PLAIN-DELIVERY WORD
-> ISRAEL DEFEATS SYRIA IN PLAIN
-> S248 MENTAL CRACK / YOINK
-> BEN HADAD ASKS LIFE / COVENANT / AHAB RELEASES HIM
-> PROPHET REQUESTS WOUND / FIRST FELLOW REFUSES / LION KILLS
-> SECOND MAN WOUNDS PROPHET / DISGUISED CASE PRESENTED
-> AHAB PRONOUNCES CASE JUDGMENT
-> PROPHET REVEALS / APPLIES RELEASE JUDGMENT
-> AHAB LIFE FOR BEN HADAD LIFE + AHAB PEOPLE FOR BEN HADAD PEOPLE
-> SKIP S127-E012-1KI16 / S127-E013 / YOINK
-> AHAB RETURNS SULLEN AND ANGRY
```

## Verses 1–12 — Accept the first demand, reject the search expansion

Ben Hadad gathers his army, thirty-two kings, horses and chariots, besieges Samaria and sends messengers. He claims Ahab's silver, gold, wives and best children. Ahab answers that he and all he has are Ben Hadad's according to the saying.

The messengers return with an expanded operational demand: servants will enter the next day, search Ahab's and his servants' houses, and remove whatever is pleasant in Ahab's eyes. Ahab consults the elders, who tell him not to consent. Ahab replies that he will perform the first demand but cannot perform this expanded search-and-take demand. The two scopes remain distinct; this is not an acceptance contradiction.

Ben Hadad swears that Samaria's dust will not provide enough handfuls for all his followers. Ahab answers with the armor-on/armor-off warning. These are competing boasts before outcome, not completed facts. Ben Hadad hears while drinking with the kings and orders attack preparation; the servants prepare.

## Verses 13–22 — Two hundred thirty-two lead seven thousand

An unnamed prophet carries LORD's saying that the great multitude will be delivered to Ahab that day so Ahab knows LORD. Asked by whom and who begins, the prophet carries: the 232 young men of provincial princes, with Ahab beginning.

Ahab musters those 232 and seven thousand Israel participants. They go out at noon while Ben Hadad and the thirty-two kings are drinking drunk. Scouts report men coming from Samaria. Ben Hadad gives the same capture-alive instruction whether they come for peace or war; this is an explicit action common to two branches, not a contradiction.

The young men and following army emerge. Each kills his opponent; Syrians flee; Israel pursues; Ben Hadad escapes on a horse. Ahab strikes horses/chariots and Syrians in a great slaughter. Battle remains restrained.

The prophet tells Ahab to strengthen, plan and know Syria will return at the year's turn. That later return is explicitly performed in verse 26.

## Verses 23–30 — “Hill God” enters a plain and loses

Syrian servants explain their defeat by asserting Israel's God is a hill god, not a plain/valley god. They propose replacing kings with captains, rebuilding horse for horse and chariot for chariot, and fighting in the plain where they say Syria will surely be stronger. Ben Hadad adopts the plan.

At the year's turn Syria goes to Aphek. Israel, provisioned and mustered, appears like two little goat flocks while Syria fills the country. A man of God carries LORD's saying that because Syrians said LORD is hill god and not valley god, the multitude will be delivered to Israel.

After seven days the plain battle begins. Israel kills one hundred thousand Syrian footmen in one day; the remaining twenty-seven thousand flee to Aphek where a wall falls on them. Ben Hadad reaches an inner room.

The advisers' selected hill-only model directly chose the plain rematch; the observed plain result contradicts the claim that Israel's God lacks that boundary. This closes new mental `S248-E001-1KI20`. The crack is in the advisers' causal model; the battle deaths are not boils. One Captain **YOINK!** changes nothing.

## Verses 31–34 — Sackcloth, “brother,” covenant, release

Ben Hadad's servants report hearing Israel's kings are merciful. They put on sackcloth and ropes, ask Ahab to let Ben Hadad live, and rapidly retain Ahab's phrase that Ben Hadad is his brother. Ahab brings Ben Hadad into the chariot.

Ben Hadad promises to restore cities his father took and allow Ahab streets in Damascus. Ahab makes a covenant and releases him. City restoration and street installation remain promised, not performed here.

## Verses 35–38 — A requested wound and a lion outcome

A son of the prophets asks a fellow by LORD's word to strike him. The fellow refuses. The prophet says a lion will kill him for not obeying; after departure a lion finds and kills him. The instruction, refusal, carried consequence and outcome are retained in order. No lion motive, divine body or attack mechanism is invented.

Another man complies and wounds the prophet. The prophet covers his eyes with a headband and waits for Ahab. Injury and death remain restrained; the lion and living people are Joe-faced.

## Verses 39–43 — A staged case becomes Ahab's judgment mirror

The disguised prophet presents a staged first-person case: a battle prisoner was entrusted to him under life-for-life or one-talent liability, and disappeared while he was busy. Ahab answers that the speaker has decided his own judgment.

The prophet removes the headband; Ahab recognizes him. The prophet then carries LORD's saying: because Ahab released a man devoted to destruction, Ahab's life will replace Ben Hadad's life and Ahab's people will replace Ben Hadad's people.

The staged case was intentionally constructed as an analogy and is revealed before its judgment application. It is not promoted into external battle fact and is not a mental crack.

The personal Ahab-for-Ben-Hadad exchange remains the stated judgment. The additional people-for-people transfer assigns consequence to Ahab's people without supplying each person's producing release act. This repeats S127. An inert **SKIP -> S127-E012-1KI16** points to the existing actor-to-others liability contradiction; `S127-E013-1KI20` closes here. One Captain **YOINK!** changes no judgment or person.

Ahab returns to Samaria sullen and angry. No death judgment is performed in this chapter.

## God-line boundary

- The unnamed prophet and man of God carry LORD battle-delivery sayings; no divine body is rendered.
- Syrian hill/valley theology remains adviser speech; its selected test and plain defeat are observed.
- The son-of-prophets strike request is attributed to LORD word by that speaker; lion consequence and outcome are separately retained.
- Final release judgment is prophet-mediated LORD speech; Ahab's staged-case ruling is human judgment.
- No hidden command to destroy Ben Hadad is invented before the release; “devoted to destruction” enters only in the final carried saying.

## Character and world-ledger changes

- NOT-AHAB JOE moves through siege demands, consultation, two battles, Ben Hadad covenant/release, staged judgment and sullen return.
- NOT-BEN-HADAD JOE moves from besieger/boaster to first escape, plain rematch loser, hidden-room survivor, mercy petitioner, covenant partner and released king.
- NOT-SYRIAN-ADVISER JOES create the hill-only causal model and plain-rematch plan; the selected plain result disproves it.
- NOT-PROPHET JOES remain distinct carriers: first-battle prophet, second-battle man of God, wounded son of prophets, refusing fellow and complying man.
- NOT-ISRAEL JOES retain 232 vanguard plus 7000 mustered participants; no identity merge with chapter-19 reserved seven thousand is inferred.
- NOT-LION JOE performs the narrated killing; motive and control mechanism remain unresolved.

## Bullshit pass

Issue `1KI-020 / REGIONAL GOD OUTAGE AND MERCY PENALTY`.

- Vendor demand v1: all your family and treasury.
- Customer: fine.
- Vendor demand v2: root access to every employee's house and take anything pleasant.
- Customer: that scope was not in v1.
- First deployment: 232 interns lead 7,000 users; vendor flees.
- Root-cause analysis: **THEIR GOD ONLY WORKS ON HILLS.**
- Remediation: rebuild entire army and deploy in plain.
- Result: plain environment also supported; 127,000 loss report.
- Customer releases vendor under covenant.
- Compliance response: customer life for vendor life; customer users for vendor users.

Captain licks the regional-theology ticket and collective-liability ticket separately. **YOINK! YOINK!** Nothing changes.

## FIR verification

- FILTER: all 43 markers retained; chapter 21 excluded from story pixels.
- ISOLATE: siege/demand scopes, first battle, year-return forecast, hill/plain model, second battle, mercy/covenant, requested wound/lion, staged case and final judgment.
- RECONSTRUCT: new S248 model-versus-plain-result contradiction and recurring S127 actor-to-people liability.
- VERIFY: one inert SKIP, two distinct YOINKs, no divine body, merged seven-thousand populations, invented destroy command, staged-story external fact, battle motive or graphic killing.

## Required compound-eye facets

1. Ben Hadad/32 kings/horses/chariots besiege Samaria.
2. Messengers enter/Ahab addressed.
3. Silver/gold/wives/children first demand.
4. Ahab accepts first demand.
5. Messengers return/restate delivery demand.
6. Tomorrow house-search/take-pleasant expansion.
7. Ahab consults elders and distinguishes accepted first scope.
8. Elders/people reject consent.
9. Ahab reports first-will-do/expanded-cannot-do.
10. Ben Hadad dust-handful boast.
11. Ahab armor-on/off response.
12. Drinking Ben Hadad orders attack; preparation occurs.
13. Prophet carries same-day delivery word.
14. 232 vanguard/Ahab begins answer.
15. 232 plus 7000 mustered.
16. Noon exit/Ben Hadad and 32 kings drunk.
17. Vanguard exits/scout report.
18. Peace-or-war/capture-alive common instruction.
19. Vanguard/following army exits.
20. Individual strikes/Syrian flight/Ben Hadad horse escape.
21. Ahab strikes horses/chariots/Syrian slaughter.
22. Prophet warns year-return/strengthen/plan.
23. Syrian hill-only model/plain proposal.
24. Replace kings with captains.
25. Rebuild horse/chariot army/adoption.
26. Year-return/Aphek rematch.
27. Israel two-goat-flock scale/Syria fills country.
28. Man of God carries hill/valley delivery word.
29. Seven-day wait/100000 plain-battle deaths.
30. 27000 wall fall/Ben Hadad inner room; S248 YOINK.
31. Mercy report/sackcloth-rope proposal.
32. Servants perform/ask Ben Hadad life/Ahab says brother.
33. Phrase captured/Ben Hadad brought to chariot.
34. City/street promises/Ahab covenant/release.
35. Prophet requests strike by LORD word/fellow refuses.
36. Lion warning and performed killing, restrained.
37. Second man strikes/wounds prophet, restrained.
38. Prophet disguises/waits.
39. Staged guard-prisoner/liability case.
40. Staged busy/gone account/Ahab self-decided judgment.
41. Headband removed/prophet recognized.
42. Release judgment/Ahab-for-Ben-Hadad and people-for-people; S127 SKIP/YOINK.
43. Ahab returns sullen/angry.

All forty-three facets appear simultaneously.

## Production boundary

One high-resolution 43-facet compound-eye image. `NOT-` identities and Joe faces for every living thing, including horses, goats, oxen and lion if visible. Objects, walls, chariots and remains are nonliving/faceless. One exact inert S127 SKIP and exactly two separate boilless Captain poke/lick/YOINK/walk-away carriers. Battles, lion killing and wound restrained/non-graphic. Future/promised acts remain visibly unperformed. No divine body. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
