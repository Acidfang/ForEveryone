# CRACKHEAD 1 SAMUEL 10

## Title page

**NOT-SAMUEL: “THE KING WAS CHOSEN.” NOT-ISRAEL: “WHERE IS HE?” NOT-THE-LORD: “IN THE BAGGAGE.”**

Source parent: 1 Samuel chapter 10, verses 1–27, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-010/job.json` and `source.usfm`. Parent: 1 Samuel 9.

Display-origin layer: exact identities remain in evidence; comic display uses `NOT-` identities and places. Every living human, donkey, goat, plant and other animal is Joe-faced. Oil vials, bread, instruments, baggage, lots, books and other face-like objects may receive Joe faces without life. NOT-THE-LORD / NOT-GOD / NOT-SPIRIT remains unrendered.

CrackFlix routing: new selected-authority-absence series `S178`; `S178-E001-1SA10` has no SKIP. Exactly one causally-null post-closure YOINK.

## Causal foundation

```text
SAMUEL POURS OIL / KISSES SAUL / STATES LORD ANOINTED PRINCE
-> SAMUEL PREDICTS THREE SIGN GROUPS + GILGAL WAIT
-> SAUL TURNS AWAY / GOD GIVES ANOTHER HEART
-> ALL SAME-DAY SIGNS HAPPEN
-> SPIRIT COMES MIGHTILY / SAUL PROPHESIES
-> OBSERVERS QUESTION / PROVERB FORMS
-> UNCLE ASKS / SAUL REPORTS DONKEYS FOUND BUT WITHHOLDS KINGDOM MATTER
-> SAMUEL CALLS ISRAEL TO MIZPAH
-> CARRIES LORD EGYPT/DELIVERANCE + REJECTION SPEECH
-> TRIBE -> BENJAMIN / FAMILY -> MATRITES / PERSON -> SAUL CHOSEN
-> SAUL CANNOT BE FOUND
-> LORD ANSWERS: HE HID AMONG BAGGAGE
-> PEOPLE RUN + RETRIEVE HIM
-> PUBLIC HEIGHT DISPLAY / LONG LIVE KING
-> KINGDOM REGULATIONS SPOKEN/WRITTEN/LAID BEFORE LORD
-> PEOPLE DISMISSED
-> SAUL TO GIBEAH WITH GOD-TOUCHED ARMY
-> WORTHLESS FELLOWS QUESTION/DESPISE/NO TRIBUTE
-> SAUL HOLDS PEACE
```

## 1 Samuel 10:1–8 — PRIVATE ANOINTING / PREDICTED SIGNS

Samuel pours a vial of oil on Saul's head, kisses him and says LORD has anointed him prince over his inheritance. The private anointing is now executed; public kingship has not yet occurred.

Samuel predicts:

1. two men at Rachel's tomb will report the donkeys found and Kish anxious for Saul;
2. three Bethel-bound men carrying three goats, three loaves and wine will greet Saul and give him two loaves;
3. at God's hill near a Philistine garrison, an instrument-led prophet band will meet him; LORD's Spirit will come mightily, Saul will prophesy and be turned into another man.

Samuel tells Saul to act appropriately when the signs come because God is with him. Samuel also tells him to go ahead to Gilgal and wait seven days for Samuel to offer sacrifices and show what to do.

The Gilgal instruction remains future. Do not import its later execution.

## 1 Samuel 10:9–13 — ALL SIGNS HAPPEN

When Saul turns away from Samuel, narration says God gives him another heart and all the signs happen that day.

At the hill, a band of prophets meets him. God's Spirit comes mightily and Saul prophesies among them. People who knew him before see this and ask what happened to Kish's son and whether Saul is also among the prophets. A local person asks who their father is; **“IS SAUL ALSO AMONG THE PROPHETS?”** becomes a proverb.

After prophesying, Saul goes to the high place. The source asserts all signs happened but narrates only the prophet-band encounter in full. Do not invent dialogue, faces, timing or transfers for omitted sign details beyond Samuel's prior speech and the summary.

## 1 Samuel 10:14–16 — DONKEYS YES / KINGDOM NO

Saul's uncle asks where Saul and the servant went. Saul says they sought donkeys and went to Samuel when they could not find them.

Asked what Samuel said, Saul reports that the donkeys were found. He does not tell his uncle the kingdom matter Samuel spoke.

The withheld disclosure is explicitly observable. No lie is added: Saul states a true retained part and omits another. His motive, obligation to disclose and uncle's later knowledge remain unresolved, so no mental crack is manufactured.

## 1 Samuel 10:17–24 — THE PUBLICLY CHOSEN KING IS MISSING

Samuel gathers Israel to LORD at Mizpah. He carries LORD's speech: LORD brought Israel from Egypt and delivered them from Egyptians and oppressing kingdoms; Israel has now rejected the God who saves from calamities and demanded a king. Samuel orders presentation by tribes and thousands.

The selection narrows:

**ISRAEL -> BENJAMIN -> MATRITE FAMILY -> SAUL SON OF KISH.**

Saul is chosen, but when they look for him he cannot be found. They inquire of LORD further. LORD answers that Saul has hidden among the baggage.

The completed contradiction is:

**PUBLIC AUTHORITY SELECTED FOR THE PEOPLE → SELECTED PERSON HIDES SO THE PEOPLE CANNOT PRESENT HIM.**

New CrackFlix series:

**S178: WE CHOSE A KING. WHERE IS HE? IN THE BAGGAGE.**

When the selected king is found absent because he hid, `S178-E001-1SA10` completes. Captain pokes the authority boil, licks his finger, says **“YOINK!”**, and walks away without looking back.

People run and retrieve Saul. Standing among them, he is taller from the shoulders upward. Samuel asks whether they see LORD's chosen, with none like him among the people. The people shout **“LONG LIVE THE KING!”** Retrieval changes the later State; it does not erase the completed hiding occurrence.

Saul's motive for hiding, exact baggage arrangement, inquiry mechanism and retrieval details remain unresolved.

## 1 Samuel 10:25–27 — REGULATIONS / SUPPORT / CONTEMPT

Samuel tells the people the kingdom regulations, writes them in a book and lays it before LORD. The text of that book and its exact relation to chapter 8's warning are not supplied here; do not duplicate or invent it.

Samuel dismisses everyone. Saul goes to his Gibeah house with an army whose hearts God had touched. Certain men called worthless ask how Saul could save them, despise him and bring no tribute. Saul holds his peace.

Support and contempt are both retained. The skeptics' question is not contradiction proof, their worthlessness is narrator/source labeling, and Saul's silence supplies no hidden emotion.

## Character and world-ledger changes

- NOT-SAUL JOE gains private anointing, another-heart State, fulfilled signs, prophesying, selective uncle disclosure, public selection, baggage hiding/retrieval, king acclamation and silent response to contempt.
- NOT-SAMUEL JOE gains anointing act, sign/Gilgal instructions, public divine-history carrier, selection administration and kingdom-book custody.
- NOT-PROPHET JOES and instrument carriers meet Saul; local observers create the proverb.
- NOT-SAUL-UNCLE JOE receives donkey-search/found report but not kingdom matter.
- NOT-ISRAEL JOES participate in public narrowing, search, inquiry, retrieval and acclamation.
- God-touched NOT-ARMY JOES accompany Saul; NOT-WORTHLESS-FELLOWS withhold tribute.
- `S178-E001-1SA10` retains one completed selected-authority-absence contradiction.

## Bullshit pass

Issue `1SA-010 / KING DEPLOYMENT: FILE NOT FOUND`. The national selector returns NOT-SAUL with 100% confidence. The presentation layer returns **404: CHECK BAGGAGE**. After manual retrieval, everybody shouts the deployment healthy and writes the regulations to a book nobody opens on-panel. Foundation unchanged.

## FIR verification

- FILTER: 1 Samuel 10 only; all 27 markers retained in order; 1 Samuel 11 excluded.
- ISOLATE: private anointing, predicted/fulfilled signs, prophecy/proverb, uncle disclosure boundary, public selection, hiding/retrieval, regulations, support/contempt.
- RECONSTRUCT: one contradiction completes at selected public authority plus deliberate absence; retrieval is subsequent resolution.
- VERIFY: one new series/episode, zero SKIPs and one YOINK; future Gilgal held; omitted signs not fabricated; divine form absent; publication held.

## Required comic states

1. Samuel privately oils/kisses Saul and states prince anointing.
2. First sign prediction: two men/donkeys found/father anxious.
3. Second sign: three travelers/goats/bread/wine/two loaves.
4. Third sign: prophet band/instruments/Spirit/another man.
5. Gilgal seven-day instruction held future.
6. Saul turns; narrator another heart/all signs same day.
7. Prophet band meets; Spirit attribution/prophesying, no divine body.
8. Familiar observers question; proverb forms.
9. Uncle asks; Saul reports donkeys found, withholds kingdom matter.
10. Samuel gathers Mizpah and carries LORD history/rejection speech.
11. Public narrowing Israel -> Benjamin -> Matrites -> Saul.
12. Saul chosen but cannot be found; inquiry.
13. LORD unrendered answer: hidden among baggage; S178 and one causally-null YOINK.
14. People retrieve Saul; height display and king acclamation.
15. Samuel states/writes/lays kingdom regulations; text unshown.
16. Dismissal; Saul/army to Gibeah.
17. Worthless fellows question/despise/no tribute; Saul silent.
18. Held lineage page: 1 Samuel 11 excluded.

## Production boundary

- All displayed biblical identities/places use `NOT-`; exact names remain in evidence.
- All living humans, donkeys, goats, plants and animals are Joe-faced. Object faces do not establish life. LORD/God/Spirit remains unrendered.
- Keep anointing private and public selection later; do not merge them.
- Render predicted signs as Samuel speech, then only source-supplied fulfillment detail; summary may state all occurred without invented scenes.
- Saul's uncle disclosure is truthful partial disclosure; do not invent lie, motive or duty.
- Exactly one contradiction when chosen Saul cannot be found because he hid among baggage. No SKIP. Exactly one boilless, causally-null Captain: poke, lick, **“YOINK!”**, walk away, no look back.
- Do not invent Gilgal fulfillment, kingdom-book text, inquiry mechanics, touched-heart visuals as literal anatomy, skeptic motives or Saul emotion.
- Publication held. `CHB-1SA-011` excluded.

*shrug*

OK.
