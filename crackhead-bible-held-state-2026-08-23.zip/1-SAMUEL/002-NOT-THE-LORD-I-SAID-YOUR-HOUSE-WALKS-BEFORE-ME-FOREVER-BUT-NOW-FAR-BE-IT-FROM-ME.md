# CRACKHEAD 1 SAMUEL 2

## Title page

**NOT-THE-LORD: “I SAID YOUR HOUSE SHOULD WALK BEFORE ME FOREVER.” ALSO NOT-THE-LORD: “BUT NOW—FAR BE IT FROM ME.”**

Source parent: 1 Samuel chapter 2, verses 1–36, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-002/job.json` and `source.usfm`. Parent: 1 Samuel 1.

Display-origin layer: exact source identities remain in evidence. Comic display uses `NOT-` identities and places. Every living human and animal is Joe-faced. NOT-THE-LORD / NOT-GOD remains unrendered. The unnamed **NOT-MAN-OF-GOD JOE** is a visible Joe-faced messenger carrying attributed speech; he is not rendered as God.

CrackFlix routing: new promise-revocation series `S173-E001-1SA2` has no SKIP. Exactly one causally-null post-closure YOINK.

## Causal foundation

```text
HANNAH PRAYS REVERSAL/JUDGMENT SONG
-> ELKANAH RETURNS RAMAH
-> SAMUEL SERVES BEFORE ELI
-> ELI SONS CLASSIFIED WICKED / DO NOT KNOW LORD
-> PRIEST SERVANT FORKS BOILING OFFERING MEAT
-> ALSO DEMANDS RAW MEAT BEFORE FAT BURNING
-> THREATENS FORCE
-> NARRATOR CLASSIFIES GREAT SIN / OFFERING DESPISED
-> SAMUEL MINISTERS IN LINEN EPHOD
-> HANNAH BRINGS YEARLY LITTLE ROBE
-> ELI BLESSES PARENTS / ASKS OFFSPRING
-> NARRATOR: LORD VISITS HANNAH
-> HANNAH BEARS THREE SONS + TWO DAUGHTERS
-> SAMUEL GROWS
-> OLD ELI HEARS SONS' ACTS + REPORTS
-> ELI QUESTIONS/REBUKES
-> SONS DO NOT LISTEN
-> NARRATOR: LORD INTENDED TO KILL THEM
-> SAMUEL GROWS IN FAVOR
-> MAN OF GOD COMES / CARRIES LORD SPEECH
-> SPEECH RETELLS REVELATION/PRIEST CHOICE/OFFERINGS
-> SPEECH ACCUSES ELI OF HONORING SONS ABOVE LORD
-> SPEECH: I SAID HOUSE WOULD WALK BEFORE ME FOREVER
-> SPEECH: BUT NOW FAR BE IT FROM ME
-> SPEECH ANNOUNCES HOUSE JUDGMENT + TWO-SON SAME-DAY SIGN
-> SPEECH ANNOUNCES FUTURE FAITHFUL PRIEST/HOUSE
```

## 1 Samuel 2:1–10 — HANNAH'S PRAYER

Hannah prays. She says her heart and horn are exalted in LORD, her mouth is enlarged over enemies, and she rejoices in salvation. She declares LORD uniquely holy, incomparable as rock and God of knowledge who weighs actions.

Her prayer describes reversals: mighty bows broken and stumbling people strengthened; full people hiring for bread and hungry people satisfied; the barren bearing seven and the many-child woman languishing; LORD killing/making alive, lowering/raising, impoverishing/enriching, lifting poor/needy to princes and glory.

She attributes earth pillars and world placement to LORD, predicts holy feet kept, wicked silenced, opponents broken by thunder, earth ends judged, strength given to a king and the anointed horn exalted.

These are Hannah's prayer claims, general classes and future statements. No named enemy, seven-child identity, king, anointed person, earth-pillar mechanism, death/resurrection occurrence or future judgment is supplied here. “The barren has borne seven” is not automatically merged into Hannah's later household count.

## 1 Samuel 2:11–17 — PRIEST FORK / RAW FIRST / FORCE

Elkanah returns to Ramah. Samuel serves LORD before Eli.

Eli's sons are called wicked men who do not know LORD. The source then describes priest custom: while sacrificial meat boils, a servant uses a three-toothed fork in pan, kettle, cauldron or pot, and the priest keeps whatever rises. This is done to all Israelites arriving at Shiloh.

Before the fat is burned, the servant also demands raw meat to roast because the priest will not accept boiled meat. If the sacrificer says burn the fat first and then take what is desired, the servant demands it immediately and threatens force.

The narrator calls the young men's sin very great and says they despised LORD's offering. The actors behind each fork/demand are not individually assigned between Hophni and Phinehas; retain the collective sons/servant/priest relation.

## 1 Samuel 2:18–21 — LITTLE ROBE / FIVE MORE CHILDREN

Child Samuel ministers before LORD in a linen ephod. Each year Hannah makes and brings him a little robe when she and Elkanah come for sacrifice.

Eli blesses Elkanah and his wife and says **may** LORD give offspring for the petition asked. They return home. The narrator says LORD visits Hannah; she conceives and bears three sons and two daughters. Samuel grows before LORD.

The blessing remains Eli's wish; visit is narrator attribution; conception and births are Hannah's acts. Samuel plus the later five children yields six retained children born to Hannah across chapters. Hannah's earlier prayer line about “the barren” bearing seven does not explicitly identify herself, a literal count boundary or completed household total, so no contradiction is manufactured.

## 1 Samuel 2:22–26 — ELI HEARS / SONS DO NOT LISTEN

Very old Eli hears all his sons did to Israel and hears they slept with women serving at the Tent entrance. He asks why they do such things, says the report from all the people is not good, and says they make LORD's people disobey.

Eli distinguishes sin against another person, which God will judge, from sin against LORD, asking who will intercede. His sons do not listen to his voice. The narrator says this is because LORD intended to kill them.

The reports are retained as reports and narrator assertion. The women's individual identities, consent, exact acts, witnesses, timing and Eli's prior knowledge are not supplied. The intended-killing statement is narrator attribution; no death occurs in this chapter.

Samuel continues growing and increasing in favor with LORD and people. Favor carriers and measurements are not supplied.

## 1 Samuel 2:27–30 — FOREVER / FAR BE IT

An unnamed man of God comes to Eli and says **“THE LORD SAYS.”** He carries first-person LORD speech. God is not visually rendered; the Joe-faced messenger speaks the quotation.

The carried speech asks whether LORD revealed himself to Eli's ancestral house in Egypt, chose him as priest from all tribes, assigned altar/incense/ephod work and gave the father's house Israel's fire offerings. It then asks why Eli kicks at commanded sacrifice/offering and honors sons above LORD, making themselves fat with the best offerings.

The speech continues:

**“I SAID INDEED THAT YOUR HOUSE AND YOUR FATHER'S HOUSE SHOULD WALK BEFORE ME FOREVER.”**

Then:

**“BUT NOW THE LORD SAYS, ‘FAR BE IT FROM ME.’”**

No duration qualifier, conditional wording from the earlier statement, expiry, separate house identity or semantic bridge is supplied in this speech. The claimed forever State is expressly rejected by the same attributed speaker. New CrackFlix series:

**S173: I SAID FOREVER. NOW I SAY ABSOLUTELY NOT.**

After “far be it” completes the contradiction, Captain pokes the promise-revocation boil, licks his finger, says **“YOINK!”**, and walks away. The messenger continues carrying the speech. Captain does not judge God, Eli or the sons; he only sees crack.

The speech then states a new honor/despise relation: those honoring LORD will be honored and despisers cursed. This is retained as the replacement rule, not an explanation that retroactively changes the word “forever.”

## 1 Samuel 2:31–36 — ANNOUNCED HOUSE OUTCOME

The carried LORD speech announces future days: Eli's arm and ancestral-house arm cut off; no old man in the house; habitation affliction amid Israel's wealth; an altar survivor consuming Eli's eyes and grieving his heart; household increase dying in prime.

Hophni and Phinehas dying on one day is announced as the sign. No death occurs yet.

The speech promises a future faithful priest who acts according to LORD's heart/mind, receives a sure house and walks before LORD's anointed forever. Remaining people of Eli's house will bow to him for silver and bread and ask for priest office to eat.

The faithful priest's identity, timing, house, anointed identity, implementation and later fulfillment are unresolved. The second “forever” is future speech and cannot be tested within this chapter. 1 Samuel 3 is excluded.

## Character and world-ledger changes

- NOT-HANNAH gains a ten-verse prayer carrier, yearly robe-making visits and three-son/two-daughter births.
- NOT-SAMUEL gains child ministry, linen ephod, yearly robe, continuing growth and favor statements.
- NOT-HOPHNI / NOT-PHINEHAS gain collective wicked/non-knowing classification, offering-abuse chain, reported sexual acts, failed-response State and same-day-death prediction.
- NOT-ELI gains very-old State, reports received, rebuke, messenger encounter and addressed house judgment.
- NOT-MAN-OF-GOD JOE gains one messenger-carried LORD-speech occurrence only; personal identity and future remain unresolved.
- `S173-E001-1SA2` retains the completed forever/revocation contradiction.

## Bullshit pass

Issue `1SA-002 / PRIEST FORK PRIORITY ACCESS`. The offering terminal says **BURN FAT FIRST**; the sons select **RAW NOW / FORCE ENABLED**. The eternal-service contract then updates from **FOREVER** to **FAR BE IT** without changing its filename. Foundation unchanged.

## FIR verification

- FILTER: 1 Samuel 2 only; all 36 markers retained in order; 1 Samuel 3 excluded.
- ISOLATE: Hannah prayer, Samuel ministry/growth, sons' offering practices, family births, Eli reports/rebuke, narrator intent attribution and messenger-carried LORD judgment.
- RECONSTRUCT: one new `S173`; explicit same-speaker forever claim/revocation.
- VERIFY: exactly one crack, zero SKIPs and one YOINK; prayer imagery/classes, child count, servant identity, sexual details, divine form/mechanism, death fulfillment, faithful priest identity and future outcome remain unmanufactured; publication held.

## Required comic states

1. Hannah prayer opening and reversal declarations, visibly framed as her speech.
2. Prayer future judgment/king/anointed close; no outcomes rendered as completed.
3. Elkanah leaves/Samuel serves; Eli sons classified wicked/non-knowing.
4. Boiling-meat three-tooth fork custom.
5. Raw-meat-before-fat demand, sacrificer objection, force threat and narrator evaluation.
6. Samuel linen ephod; Hannah's annual little robe.
7. Eli offspring wish, narrator visit attribution, Hannah's five later children, Samuel growth.
8. Eli hears reports, questions/rebukes; sons do not listen; narrator kill-intent attribution.
9. Man of God arrives and begins LORD quotation with ancestral priest history and offering accusation.
10. “I said forever” followed by “far be it”; S173 and one YOINK.
11. Future house judgment and Hophni/Phinehas same-day sign retained as speech only.
12. Future faithful priest/sure house/bread-office close and held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; exact source identities remain in evidence.
- Every living human and animal is Joe-faced. NOT-THE-LORD / NOT-GOD remains unrendered. The man of God is a Joe-faced messenger, never God's visual form.
- Preserve Hannah's prayer as her speech. Do not render its generic classes and future claims as verified completed events.
- Offering abuse may be shown clearly but non-graphically. Do not assign every servant act to a named son unless source does.
- Keep reported sexual acts non-graphic and do not invent consent, identities, witnesses or detail.
- One crack only: same carried LORD speaker says prior house relation was forever, then rejects it. No SKIP. Exactly one boilless, causally-null Captain occurrence after “far be it”: poke, lick, **“YOINK!”**, walk away, no look back.
- Retain all verses 31–36 as future messenger-carried speech. Do not execute deaths or identify the faithful priest/anointed.
- Publication held. `CHB-1SA-003` excluded.

*shrug*

OK.

