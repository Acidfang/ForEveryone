# CRACKHEAD 1 SAMUEL 16

## Title page

**NOT-SAMUEL: SURELY THIS IS THE ONE. NOT-THE-LORD: NO.**

Source parent: 1 Samuel chapter 16, verses 1–23, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-016/job.json` and `source.usfm`. Parent: 1 Samuel 15.

Exact identities remain in evidence; comic display uses `NOT-` identities and places. Every living human, animal and plant is Joe-faced. Face-like objects may receive Joe faces without life. Divine and spirit forms remain unrendered because no form is supplied.

CrackFlix routing: mental-model series `S138`, episode `S138-E003-1SA16`, with `SKIP -> S138-E002-JDG5`. SKIP points to the same unsupported-model/contrary-State relation and changes nothing. Exactly one causally-null post-closure YOINK.

## Causal foundation

```text
LORD TELLS SAMUEL STOP MOURNING / FILL HORN / GO TO JESSE / KING PROVIDED
-> SAMUEL SAYS SAUL MAY KILL HIM IF HE HEARS
-> LORD SUPPLIES HEIFER/SACRIFICE SPEECH + JESSE CALL + FUTURE IDENTIFICATION
-> SAMUEL GOES; BETHLEHEM ELDERS TREMBLE; PEACEABLE SACRIFICE STATED
-> JESSE + SONS SANCTIFIED/CALLED
-> SAMUEL SEES ELIAB: SURELY LORD'S ANOINTED
-> LORD: ELIAB REJECTED / DO NOT SELECT BY FACE OR HEIGHT / LORD LOOKS HEART
-> ABINADAB, SHAMMAH, SEVEN SONS PASS; NONE CHOSEN
-> YOUNGEST REMAINS WITH SHEEP
-> DAVID BROUGHT; APPEARANCE DESCRIBED
-> LORD: ARISE, ANOINT HIM
-> SAMUEL ANOINTS DAVID; LORD'S SPIRIT COMES MIGHTILY; SAMUEL RETURNS RAMAH
-> LORD'S SPIRIT DEPARTS SAUL; EVIL SPIRIT FROM LORD TROUBLES HIM
-> SERVANTS PROPOSE SKILLFUL HARP PLAYER / PREDICT WELLNESS
-> SAUL ORDERS SEARCH; SERVANT DESCRIBES JESSE'S SON
-> SAUL SENDS FOR DAVID; JESSE SENDS DONKEY/BREAD/WINE/GOAT WITH DAVID
-> DAVID STANDS BEFORE SAUL; GREATLY LOVED; ARMOR BEARER; FAVOR REQUEST
-> WHEN SPIRIT TROUBLES SAUL, DAVID PLAYS
-> SAUL REFRESHED/WELL; EVIL SPIRIT DEPARTS
```

## Verses 1–3 — NEW ANOINTING MISSION / STATED DANGER / SUPPLIED CARRIER

LORD asks how long Samuel will mourn Saul after rejection, tells him to fill his horn with oil, go to Jesse the Bethlehemite, and says a king is provided among Jesse's sons.

Samuel asks how he can go and says Saul will kill him if Saul hears. Preserve this as Samuel's prospective prediction; Saul does not hear or kill Samuel in this chapter.

LORD tells Samuel to take a heifer and say he came to sacrifice, call Jesse, and await instruction identifying whom to anoint. The sacrifice is actually conducted/called in the subsequent State; the anointing mission is additionally retained. Do not invent a lie classification, motive, concealment mechanism or Saul knowledge.

## Verses 4–5 — BETHLEHEM / PEACEABLE SACRIFICE

Samuel does what LORD spoke and reaches Bethlehem. Elders meet him trembling and ask if he comes peaceably. Samuel says peaceably, states the sacrifice, instructs sanctification, sanctifies Jesse and sons, and calls them. No cause for the elders' trembling is supplied.

## Verses 6–7 — ELIAB MODEL / DIRECT REJECTION

Samuel sees Eliab and says: **“SURELY THE LORD'S ANOINTED IS BEFORE HIM.”** The source supplies only Samuel's looking and assertion before the reply.

LORD tells Samuel not to look at Eliab's face or stature height because Eliab is rejected; man looks at outward appearance, while LORD looks at the heart.

**SAMUEL SEES ELIAB -> ASSERTS ELIAB IS THE ANOINTED -> DIRECT REPLY: ELIAB IS REJECTED / APPEARANCE IS NOT THE LORD'S SELECTION BOUNDARY.**

This is mental crack at Samuel's asserted model. It joins `S138`, where an unsupported model is closed by a contrary observed/supplied State.

`S138-E003-1SA16` displays **SKIP -> S138-E002-JDG5**. SKIP omits explaining the already-retained model-overreach relation and does nothing. The LORD's correction and selection process continue. Once the contrary rejection completes, Captain's eyes bulge at **“MENTAL CRACK?!”**; he pokes the physical boil, licks his finger, says **“YOINK!”**, and walks away without looking back. He does not select or reject anyone.

Do not infer Samuel's private motive, a general biometric rule, Eliab's heart State, or that facial attractiveness itself is disqualifying.

## Verses 8–13 — SEVEN PASS / REMAINING YOUNGEST / DAVID ANOINTED

Abinadab and Shammah pass; Samuel says neither is chosen. Jesse makes seven sons pass; Samuel says LORD chose none. Samuel asks whether all children are present. Jesse says the youngest remains keeping sheep. Samuel orders him fetched and says they will not sit until he comes.

David is brought and described as ruddy, handsome-faced and good-looking. LORD says arise and anoint him. Preserve the appearance description while retaining the explicit heart-versus-outward selection boundary: the source does not state appearance caused selection or reveal David's heart contents.

Samuel anoints David among his brothers. LORD's Spirit comes mightily on David from that day forward. Samuel returns to Ramah. Divine/spirit form and anointing mechanism remain unrendered.

The text calls the provided target a king and completes anointing, while Saul continues exercising royal authority later in the chapter. Exact accession/transfer timing is not supplied; do not assert simultaneous completed kingship or silently force a handoff.

## Verses 14–18 — SAUL TROUBLED / HARP PLAN / DAVID RECOMMENDED

LORD's Spirit departs Saul; an evil spirit from LORD troubles him. Saul's servants observe/state that an evil spirit from God troubles Saul. They propose finding a skillful harp player and predict playing will make Saul well when the spirit is on him. Saul orders them to provide such a man.

A young man reports seeing a son of Jesse who is skillful in playing, mighty/valiant, a man of war, prudent in speech, handsome, and says LORD is with him. These are the young man's report carriers; prior battle history and mechanism are not supplied here.

## Verses 19–23 — DAVID BROUGHT / SERVICE / OBSERVED RELIEF

Saul sends to Jesse for David, identified as with the sheep. Jesse loads a donkey with bread, wine and a young goat and sends them with David. David stands before Saul; Saul loves him greatly; David becomes armor bearer. Saul asks Jesse to let David remain because he found favor.

When the spirit from God is on Saul, David plays the harp. Saul is refreshed and well; the evil spirit departs. The servants' predicted intervention/result is observed, so it is not a contradiction. Preserve exact recurrence language and do not invent medical diagnosis, acoustic physics, possession mechanics or permanent cure.

## Character and world-ledger changes

- NOT-SAMUEL gains stopped-mourning instruction, stated Saul-danger prediction, Bethlehem mission, peaceable sacrifice, Eliab mental model/correction, seven-son review, David anointing and Ramah return.
- NOT-DAVID JOE gains first retained identity, youngest/sheep-keeper relation, appearance report, selection/anointing, Spirit State, skill/valor/war/prudence/LORD-with report, palace delivery, favor/love, armor-bearer role and harp-relief acts.
- NOT-SAUL gains continuing royal command, Spirit-departure/troubled State, musician search, David request, love/favor and observed refreshment/wellness.
- NOT-JESSE and sons gain Bethlehem/sacrifice, seven-pass, absent-youngest disclosure, David delivery and gift carriers.
- NOT-BETHLEHEM ELDERS gain trembling peace inquiry and sacrifice participation boundary.

## Bullshit pass

Issue `1SA-016 / FACE RECOGNITION FAILED, HEART API PRIVATE`. NOT-SAMUEL runs visual candidate scoring and instantly selects the tall one. NOT-THE-LORD rejects the model, then selects the later handsome candidate without publishing the heart payload. NOT-SAUL's palace opens a **HARP-BASED INCIDENT RESPONSE** vacancy; the observed service actually clears the incident. Foundation unchanged.

## FIR verification

- FILTER: all 23 markers retained in order; 1 Samuel 17 excluded.
- ISOLATE: mission/sacrifice, Eliab model/rejection, seven-son search/David anointing, Saul spirit State, musician search and observed relief.
- RECONSTRUCT: one mental contradiction joins `S138`; other apparent tensions remain bounded/unresolved.
- VERIFY: one exact SKIP pointer, one YOINK, no invented divine/spirit form, no asserted accession timing, publication held.

## Required comic states

1. Stop-mourning/fill-horn/Jesse/provided-king instruction.
2. Samuel Saul-kill prediction; heifer/sacrifice/identification reply.
3. Bethlehem elders trembling/peace inquiry.
4. Peaceable sacrifice and sanctification/call.
5. Samuel sees Eliab and asserts surely anointed.
6. SKIP pointer; LORD rejects Eliab/corrects appearance boundary; mental crack/YOINK.
7. Abinadab/Shammah and seven-son rejection sequence.
8. All-children question; youngest remains with sheep; fetch/no-sit.
9. David brought with source appearance description.
10. Arise/anoint instruction.
11. Anointing, Spirit-on-David, Samuel to Ramah.
12. Spirit departs Saul; evil spirit from LORD troubles him, no rendered form.
13. Servants' harp-player proposal/predicted wellness.
14. Saul search order and young man's David report.
15. Saul message to Jesse; David/sheep address.
16. Donkey/bread/wine/goat sent with David.
17. David stands before Saul; love/armor-bearer/favor request.
18. Recurring troubled State; David plays; Saul refreshed/well; spirit departs.
19. Held lineage page; 1 Samuel 17 excluded.

## Production boundary

- Use `NOT-` display identities/places; exact identities remain in evidence. All living humans, sheep, heifer, donkey, goat and plants are Joe-faced. Object faces do not establish life.
- No divine or spirit form. Exact speech/attribution only.
- Exactly one mental episode: `S138-E003-1SA16`; one `SKIP -> S138-E002-JDG5`; exactly one causally-null post-closure Captain appearance and YOINK.
- Do not infer Samuel's motive, Eliab's heart, appearance causation, Saul's actual hearing/killing, kingship transfer timing, David's prior war events or harp mechanism.
- Publication held. `CHB-1SA-017` excluded.

*shrug*

OK.
