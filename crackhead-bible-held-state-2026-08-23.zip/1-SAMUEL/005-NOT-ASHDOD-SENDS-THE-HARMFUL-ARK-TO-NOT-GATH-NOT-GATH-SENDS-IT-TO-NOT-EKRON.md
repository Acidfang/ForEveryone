# CRACKHEAD 1 SAMUEL 5

## Title page

**THE ARK IS HURTING OUR CITY. SEND IT TO OUR OTHER CITY.**

Source parent: 1 Samuel chapter 5, verses 1–12, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-005/job.json` and `source.usfm`. Parent: 1 Samuel 4.

Display-origin layer: source names remain exact in evidence. Comic display uses `NOT-ASHDOD`, `NOT-GATH`, `NOT-EKRON`, `NOT-DAGON` and other `NOT-` identities. Every living human is Joe-faced. The ark and Dagon statue may receive Joe faces as face-like objects without becoming alive. NOT-THE-LORD / NOT-GOD remains unrendered.

CrackFlix routing: new harm-routing series `S176`. `S176-E001-1SA5` has no SKIP. `S176-E002-1SA5` points exactly to E001 and SKIPs explaining the repeated relation; SKIP changes nothing. Exactly two causally-null post-closure YOINKs.

## Causal foundation

```text
PHILISTINES TAKE ARK EBENEZER -> ASHDOD
-> SET ARK BESIDE DAGON
-> MORNING: DAGON FACE-DOWN / PEOPLE PUT DAGON BACK
-> NEXT MORNING: DAGON FACE-DOWN / HEAD + PALMS ON THRESHOLD
-> THRESHOLD AVOIDANCE CONTINUES
-> NARRATOR ATTRIBUTES ASHDOD DESTRUCTION/TUMORS TO LORD'S HEAVY HAND
-> ASHDOD MEN SAY ARK CANNOT STAY / HAND SEVERE ON THEM + DAGON
-> LORDS DECIDE SEND ARK TO GATH
-> AFTER ARRIVAL: GREAT CONFUSION + TUMORS
-> ARK SENT TO EKRON
-> EKRON CRIES: YOU BROUGHT IT TO KILL US
-> LORDS GATHER / EKRON REQUESTS RETURN TO ARK'S OWN PLACE
-> DEADLY PANIC + TUMORS / CITY CRY GOES TO HEAVEN
```

## 1 Samuel 5:1–5 — NOT-DAGON NEEDS PUTTING BACK

The Philistines take God's ark from Ebenezer to Ashdod and set it in Dagon's house beside Dagon.

The next morning, the Ashdodites find Dagon fallen face-down before LORD's ark. They take Dagon and put him back in his place.

The following morning, Dagon is face-down again. His head and both palms lie cut off on the threshold; only his torso remains. From that retained event, Dagon's priests and other entrants do not tread on that threshold, continuing to the narrator's day.

Keep both falls, the human restoration, the changed statue and the continuing threshold practice. No actor states what Dagon should be able to do, so no contradiction is manufactured. No statue life, fight, ark action, overnight witness, cutting agent or mechanism is invented.

## 1 Samuel 5:6–9 — HURTING US / SEND IT TO NOT-GATH

The narrator says LORD's hand is heavy on the people of Ashdod, destroys them and strikes Ashdod and its borders with tumors. No visible hand or divine body is shown; the mechanism and medical identity remain unresolved.

The Ashdod men see the State and say God's ark must not remain with them because God's hand is severe on them and Dagon. The Philistine lords gather. Asked what to do with the ark, they answer that it should be carried to Gath. They carry it there.

After it arrives, the narrator again attributes great confusion and tumors among small and great to LORD's hand.

The completed observable relation is:

**THIS OBJECT'S PRESENCE IS IDENTIFIED WITH HARM TO OUR CITY → SEND THE OBJECT TO ANOTHER CITY OF OUR OWN → THE SAME CLASS OF HARM APPEARS THERE.**

New CrackFlix series:

**S176: THE DANGER MUST LEAVE OUR CITY. SEND IT TO OUR OTHER CITY.**

After Gath receives the routed harm and the repeated harmful State completes `S176-E001-1SA5`, Captain pokes the contradiction boil, licks his finger, says **“YOINK!”**, and walks away without looking back. Nothing changes.

## 1 Samuel 5:9–12 — NOT-GATH SENDS IT TO NOT-EKRON

After the Gath State, they send God's ark to Ekron. As it arrives, the Ekronites cry that the ark has been brought around to kill them and their people.

CrackFlix points to the already retained routing relation:

**SKIP -> S176-E001-1SA5: HARMFUL HERE / SEND TO ANOTHER ONE OF OUR CITIES / HARMFUL THERE.**

SKIP does not move the ark, prevent arrival or change the world. `S176-E002-1SA5` completes when the same routed object reaches Ekron and Ekron immediately identifies the transferred danger. Captain's eyes clear after the unchanged arrival. He pokes the new contradiction boil, licks his finger, says **“YOINK!”**, and walks away without looking back.

The Ekronites gather the Philistine lords and request that God's ark be sent back to its own place so it does not kill them and their people. The narrator records deadly panic throughout the city, God's very heavy hand, tumors on those not dead and a city cry reaching heaven.

“The ark was brought to kill us” is Ekronite speech. The narrator separately attributes the heavy hand and affliction to God. Do not collapse ark, divine agency and human routing into one invented mechanism.

## Character and world-ledger changes

- NOT-PHILISTINE JOES retain custody and move the ark through Ashdod, Gath and Ekron.
- NOT-ASHDOD JOES restore Dagon once, retain the changed threshold practice, identify severe harm and route the ark to Gath.
- NOT-GATH JOES receive the ark, confusion and tumors, then route it to Ekron.
- NOT-EKRON JOES receive it, cry out, gather the lords and request return to its own place.
- NOT-DAGON remains a statue/object, twice found face-down and later changed; it is not made living.
- `S176-E001-1SA5` and `S176-E002-1SA5` retain two completed same-series harm-routing occurrences.

## Bullshit pass

Issue `1SA-005 / INTERNAL DANGER LOGISTICS`. NOT-PHILISTINE REGIONAL SUPPORT closes each city ticket by changing the destination field. Dagon's threshold becomes **DO NOT STEP ON THE INCIDENT REPORT**. Foundation unchanged.

## FIR verification

- FILTER: 1 Samuel 5 only; all 12 markers retained in order; 1 Samuel 6 excluded.
- ISOLATE: ark transport, two Dagon morning States, threshold practice, three city States, lords' routing decisions and final return request.
- RECONSTRUCT: one new harm-routing series with two completed occurrences.
- VERIFY: exactly two cracks, one correctly addressed SKIP and two YOINKs; Dagon gets no invented crack; divine form and mechanisms remain absent; tumors are not silently merged with genetically normal status boils; publication held.

## Required comic states

1. Ark taken from Ebenezer to Ashdod and placed beside Dagon.
2. First morning: Dagon face-down; Ashdod Joes put statue back.
3. Second morning: Dagon face-down, head/palms at threshold, torso retained.
4. Continuing threshold avoidance, without invented explanation beyond source event.
5. Ashdod tumors/destruction under narrator's LORD-hand attribution; no visible divine hand.
6. Ashdod says ark cannot stay; lords decide Gath; ark carried.
7. Gath confusion/tumors complete S176-E001; first causally-null YOINK.
8. Gath sends ark to Ekron; `SKIP -> S176-E001-1SA5` visibly points to repeated contradiction and does nothing.
9. Ekron receives ark and cries it was brought to kill them; S176-E002 completes; second causally-null YOINK.
10. Lords gather; Ekron requests return to ark's own place.
11. Citywide panic, deaths/tumors and cry-to-heaven close, restrained/non-graphic.
12. Held lineage page: ark future in 1 Samuel 6 excluded.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; exact names stay in machine evidence.
- Every living human is Joe-faced. The ark and Dagon may have face-like Joe faces without life or agency. NOT-THE-LORD / NOT-GOD stays unrendered.
- Keep broken statue, deaths and tumors non-graphic. Source tumors remain distinct from ordinary Crackheadverse boils.
- Dagon's repeated fall/restoration is observable absurdity, not a crack without an unsupported capability premise.
- Exactly two cracks: Ashdod-to-Gath harm routing and its Gath-to-Ekron recurrence. The second visibly uses `SKIP -> S176-E001-1SA5`; SKIP changes nothing.
- Exactly two boilless, causally-null Captain occurrences after each contradiction completes: poke, lick, **“YOINK!”**, walk away, no look back.
- Do not animate the ark/statue, show divine form, infer disease physics, cutting agent, private motives or ark-as-killer mechanism.
- Publication held. `CHB-1SA-006` excluded.

*shrug*

OK.
