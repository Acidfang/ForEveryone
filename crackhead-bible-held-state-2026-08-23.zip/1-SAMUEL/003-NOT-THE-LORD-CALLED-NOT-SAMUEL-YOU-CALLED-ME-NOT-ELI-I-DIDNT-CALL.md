# CRACKHEAD 1 SAMUEL 3

## Title page

**NOT-THE-LORD CALLED. NOT-SAMUEL: “YOU CALLED ME.” NOT-ELI: “I DIDN'T CALL.”**

Source parent: 1 Samuel chapter 3, verses 1–21, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-003/job.json` and `source.usfm`. Parent: 1 Samuel 2.

Display-origin layer: exact source identities remain in evidence. Comic display uses `NOT-` identities and places. Every living person is Joe-faced. NOT-THE-LORD / NOT-GOD remains unrendered: the source supplies calling, coming, standing, speech and appearance-by-word, but no visual body description.

CrackFlix routing: new caller-misattribution series `S174` has three occurrences. `S174-E001-1SA3` has no SKIP; `S174-E002-1SA3` SKIPs to E001; `S174-E003-1SA3` SKIPs to E002. SKIP changes nothing. Exactly three causally-null post-closure YOINKs.

## Causal foundation

```text
SAMUEL MINISTERS BEFORE ELI
-> LORD WORD RARE / VISIONS NOT MANY
-> ELI DIM-EYED / LYING DOWN
-> LAMP NOT OUT / SAMUEL LIES BY ARK
-> NARRATOR: LORD CALLS SAMUEL
-> SAMUEL RUNS TO ELI / SAYS YOU CALLED
-> ELI SAYS I DIDN'T CALL / SENDS BACK
-> NARRATOR: LORD CALLS AGAIN
-> SAMUEL GOES TO ELI / SAYS YOU CALLED
-> ELI SAYS I DIDN'T CALL / SENDS BACK
-> NARRATOR: SAMUEL DOESN'T YET KNOW LORD / WORD NOT REVEALED
-> NARRATOR: LORD CALLS THIRD TIME
-> SAMUEL GOES TO ELI / SAYS YOU CALLED
-> ELI PERCEIVES LORD CALLED
-> ELI INSTRUCTS RESPONSE
-> LORD COMES/STANDS/CALLS SAMUEL TWICE
-> SAMUEL ANSWERS
-> LORD SPEAKS ELI-HOUSE JUDGMENT
-> SAMUEL LIES UNTIL MORNING / OPENS DOORS / FEARS TELLING
-> ELI CALLS / DEMANDS COMPLETE MESSAGE
-> SAMUEL TELLS EVERY BIT / HIDES NOTHING
-> ELI ACCEPTS LORD AS SPEAKER / OUTCOME
-> SAMUEL GROWS / WORDS DON'T FALL
-> ALL ISRAEL KNOWS SAMUEL ESTABLISHED PROPHET
-> LORD APPEARS AGAIN BY WORD
```

## 1 Samuel 3:1–3 — RARE WORD / DIM EYES / LAMP STILL ON

Child Samuel ministers to LORD before Eli. LORD's word is rare and visions are not many. Eli lies in his place; his eyes have grown dim so he cannot see. God's lamp has not gone out. Samuel lies in LORD's temple where God's ark is.

Samuel's ministry and verse 7's “didn't yet know LORD” are retained together as friction, not declared contradiction. Service under Eli can be performed before personal recognition/revelation; the source supplies no rule that ministry requires prior caller recognition.

The lamp is a physical temple carrier. It is not rendered as God or as a supernatural signal unless the source says so.

## 1 Samuel 3:4–5 — FIRST WRONG CALLER

Narration says LORD calls Samuel. Samuel answers “Here I am,” runs to Eli and says:

**“HERE I AM, FOR YOU CALLED ME.”**

Eli answers:

**“I DIDN'T CALL. LIE DOWN AGAIN.”**

The actual caller is narrator-attributed to LORD. Samuel assigns the call to Eli, who directly denies it. New CrackFlix series:

**S174: SOMEONE CALLED. YOU SAY IT WAS ME. IT WASN'T ME.**

After Eli's denial completes `S174-E001-1SA3`, Captain pokes the caller-attribution boil, licks his finger, says **“YOINK!”**, and walks away. Samuel returns and lies down.

## 1 Samuel 3:6–7 — SAME CALL, SAME WRONG JOE

LORD calls again: “Samuel!” Samuel arises, goes to Eli and again says:

**“HERE I AM, FOR YOU CALLED ME.”**

Eli answers:

**“I DIDN'T CALL, MY SON. LIE DOWN AGAIN.”**

This is the same exact root contradiction as the first occurrence. CrackFlix points backward:

**SKIP → S174-E001-1SA3: LORD CALLED / SAMUEL SAID ELI CALLED / ELI DIDN'T.**

SKIP does nothing. Eli finishes the denial and instruction; Samuel returns. After `S174-E002-1SA3` completes, Captain performs the same causally useless poke, lick, **“YOINK!”**, and walk-away.

Narration then states Samuel did not yet know LORD and LORD's word had not yet been revealed to him. This supplies the recognition boundary; it does not retroactively make Eli the caller.

## 1 Samuel 3:8–9 — THIRD TIME / ELI FINALLY ROUTES IT

LORD calls Samuel a third time. Samuel again goes to Eli and says:

**“HERE I AM, FOR YOU CALLED ME.”**

This third wrong attribution closes against the retained narrator caller. Eli does not repeat “I didn't call”; instead he perceives LORD called the child. The exact same series repeats:

**SKIP → S174-E002-1SA3: SAME CALLER MISROUTED AGAIN.**

SKIP does nothing. After `S174-E003-1SA3` completes, Captain pokes, licks, says **“YOINK!”**, and walks away.

Eli tells Samuel to lie down and, if called, answer, “Speak, LORD, for your servant hears.” Samuel obeys. Eli's perception is narrator-stated; its mechanism and certainty carrier are not supplied.

## 1 Samuel 3:10–14 — THE MESSAGE

LORD comes, stands and calls “Samuel! Samuel!” as before. Samuel says, “Speak, for your servant hears.” The source gives location/actions and voice but no body, face, clothing, scale or visual form. NOT-THE-LORD remains unrendered.

LORD tells Samuel he will do a thing in Israel that makes hearers' ears tingle. He says he will perform against Eli all previously spoken concerning the house, beginning to end.

The speech says Eli was told the house would be judged forever for known iniquity: his sons brought a curse on themselves and he did not restrain them. LORD says Eli-house iniquity will not be removed by sacrifice or offering forever.

This joins the prior messenger-carried judgment without executing it. Eli's earlier verbal rebuke remains real; rebuking is not silently equated with successful restraint. The curse act, restraint action that would have sufficed, judgment mechanism and outcomes remain unresolved.

## 1 Samuel 3:15–18 — TELL ME EVERYTHING

Samuel lies until morning, opens LORD-house doors and is afraid to show Eli the vision. Eli calls him; Samuel answers.

Eli asks what was spoken and demands Samuel hide nothing, invoking God against him if anything is hidden. Samuel tells every bit and hides nothing.

Eli says:

**“IT IS THE LORD. LET HIM DO WHAT SEEMS GOOD TO HIM.”**

This is Eli's acceptance statement after receiving the full report. It does not execute or approve each future result, and no immediate judgment occurs here.

## 1 Samuel 3:19–21 — ESTABLISHED BY RETAINED OUTCOME

Samuel grows. Narration says LORD is with him and lets none of his words fall to the ground. All Israel from Dan to Beersheba knows Samuel is established as LORD's prophet.

The source does not enumerate every word, audience, prediction or verification event behind the national conclusion. The result is retained as narration, not expanded into invented episodes.

LORD appears again in Shiloh because LORD reveals himself to Samuel there by LORD's word. The supplied appearance carrier is the word. No visual form is invented. 1 Samuel 4 is excluded.

## Character and world-ledger changes

- NOT-SAMUEL gains three caller-misattribution trips, recognition instruction, first direct retained LORD-message reception, fear, complete disclosure, continued growth and established-prophet State.
- NOT-ELI gains dim sight, three night encounters, two explicit denials, third-call perception, response instruction, complete-message demand and acceptance statement.
- NOT-THE-LORD gains source-attributed call sequence, word-carried appearance and direct speech only; no visual identity is supplied.
- `S174-E001-1SA3`, `S174-E002-1SA3` and `S174-E003-1SA3` retain the three completed caller-misattribution occurrences.

## Bullshit pass

Issue `1SA-003 / DIVINE CALL ROUTER`. Three incoming calls arrive from **CALLER ID: NOT RENDERED**. NOT-SAMUEL forwards each to NOT-ELI. NOT-ELI rejects tickets one and two, then configures **SPEAK, YOUR SERVANT HEARS**. Foundation unchanged.

## FIR verification

- FILTER: 1 Samuel 3 only; all 21 markers retained in order; 1 Samuel 4 excluded.
- ISOLATE: rare-word setting, three calls/misattributions, Eli recognition/routing, direct judgment message, Samuel disclosure and established-prophet close.
- RECONSTRUCT: new `S174` with three occurrences; E002 SKIPs to E001 and E003 SKIPs to E002.
- VERIFY: exactly three cracks, two SKIPs and three YOINKs; ministry/knowledge friction not promoted; no divine body, lamp signal, Eli perception mechanism, judgment fulfillment, national evidence events or future history invented; publication held.

## Required comic states

1. Samuel ministry, rare word/visions, dim-eyed Eli, lamp not out, Samuel by ark.
2. First LORD call, Samuel runs to Eli, first “you called” / “I didn't”; E001 and YOINK.
3. Second LORD call, same trip/claim/denial; SKIP to E001, E002 and YOINK.
4. Narrator knowledge/revelation boundary.
5. Third LORD call, same claim; Eli perceives LORD; SKIP to E002, E003 and YOINK.
6. Eli response instruction and Samuel returns to place.
7. Unrendered LORD comes/stands/calls twice; Samuel answers.
8. Direct Eli-house judgment message retained as future speech.
9. Morning doors/fear; Eli calls and demands everything.
10. Samuel complete disclosure; Eli acceptance statement.
11. Samuel growth/words-national prophet establishment.
12. Shiloh appearance-by-word and held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; exact source identities remain in evidence.
- Every living human is Joe-faced. NOT-THE-LORD / NOT-GOD remains unrendered even when source says came/stood; show voice/presence/location without inventing body. The final appearance is explicitly by word.
- Preserve all three call loops. E001 no SKIP; E002 points to E001; E003 points to E002. SKIP does nothing and does not cause Eli's perception.
- Exactly three boilless, causally-null Captain occurrences after each wrong-attribution occurrence completes: poke, lick, **“YOINK!”**, walk away, no look back.
- Do not turn Samuel's ministry/not-yet-knowing relation into a crack.
- Keep Eli-house judgment as speech only. Do not execute deaths or later outcomes.
- Preserve Samuel's fear and complete report without inventing omitted wording.
- Publication held. `CHB-1SA-004` excluded.

*shrug*

OK.

