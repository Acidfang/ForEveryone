# CRACKHEAD 1 SAMUEL 24

## Title field

**NOT-DAVID: I CUT YOUR ROBE. I DID NOT KILL YOU.**

Source parent: 1 Samuel chapter 24, verses 1–22, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-024/job.json` and `source.usfm`. Parent: 1 Samuel 23. Exact identities remain in evidence; comic display uses `NOT-` identities. Every living thing is Joe-faced. LORD is present only through exact character attributions; no divine form or direct divine speech is supplied. Cave privacy, pursuit and weapons remain restrained and non-graphic.

CrackFlix: no completed contradiction, no episode, no SKIP, no YOINK.

Production format: one compound-eye field. Every required changed State is a separately addressed facet or facet cluster; all Moments appear at one time while their causal order remains retained below.

## Causal foundation

```text
SAUL RETURNS FROM PHILISTINES
-> HEARS DAVID IS IN EN GEDI
-> TAKES 3,000 CHOSEN MEN TO SEEK DAVID
-> ENTERS CAVE TO RELIEVE HIMSELF
-> DAVID AND MEN ALREADY IN INNER CAVE
-> MEN ATTRIBUTE ENEMY-DELIVERY SPEECH TO LORD
-> DAVID SECRETLY CUTS SAUL'S ROBE SKIRT
-> DAVID'S HEART STRIKES HIM BECAUSE OF THE CUT
-> DAVID SAYS LORD FORBID HAND AGAINST LORD'S ANOINTED
-> RESTRAINS HIS MEN / SAUL LEAVES UNHARMED
-> DAVID EXITS / BOWS / ADDRESSES SAUL
-> DISPLAYS CUT SKIRT AS EVIDENCE HE SPARED SAUL
-> DENIES EVIL/DISOBEDIENCE/SIN AGAINST SAUL
-> CALLS FOR LORD'S JUDGMENT / REFUSES HAND AGAINST SAUL
-> SAUL WEEPS / SAYS DAVID MORE RIGHTEOUS / CONFESSES OWN EVIL
-> SAUL ACKNOWLEDGES DAVID WILL BE KING
-> REQUESTS OATH FOR OFFSPRING/NAME
-> DAVID SWEARS
-> SAUL GOES HOME / DAVID GOES TO STRONGHOLD
```

## Verses 1–3 — THREE THOUSAND / ONE CAVE

After returning from following the Philistines, Saul hears David is in En Gedi. He takes three thousand chosen men from Israel and seeks David and his men at the wild-goat rocks.

Saul enters a roadside cave to relieve himself while David and his men are already in its innermost parts. Production shows privacy through exterior silhouette, robe and cave framing only; it does not make the bodily act explicit.

## Verses 4–7 — DELIVERY SPEECH / ROBE CUT / RESTRAINT

David's men call this the day on which LORD said an enemy would be delivered into David's hand for him to treat as seemed good. This is the men's attributed quotation. No prior direct LORD occurrence or source address is supplied here, so it is not promoted into God-only speech.

David secretly cuts the skirt of Saul's robe. Afterward David's heart strikes him **because he cut the skirt**. He tells his men LORD forbid that he act against his lord, LORD's anointed, or stretch out his hand against him. David checks his men with the words and prevents them rising against Saul. Saul leaves the cave unharmed.

The heart-struck State and later denial of evil may have different scopes: robe cutting versus killing/rebellion. Without an exact shared typed boundary, this friction remains unresolved and does not produce crack.

## Verses 8–11 — EVIDENCE IN HAND

David follows Saul out, calls **“MY LORD THE KING,”** bows face-down and asks why Saul listens to speech that David seeks harm.

David says Saul's own eyes can see LORD delivered Saul into David's hand, that some urged killing, and that David spared him. He says the cut robe skirt proves he could act but did not kill. The source directly observes the men's “do as seems good” speech, the skirt cut and Saul's survival; it does not separately observe the exact words “kill him” from the men. David's account remains his speech without backfilled dialogue.

David says there is neither evil nor disobedience in his hand and he has not sinned against Saul, while Saul hunts his life. The robe cutting and David's heart response remain retained rather than explained away.

## Verses 12–15 — JUDGMENT SPEECH / HAND REFUSAL

David invokes LORD to judge, avenge, see, plead and deliver, while twice stating his own hand will not be on Saul. He quotes an ancient proverb, **“OUT OF THE WICKED COMES WICKEDNESS,”** and asks whether Israel's king pursues a dead dog or flea.

These are David's appeals, future requests and comparisons. No divine judgment, vengeance, sentence or delivery act occurs within this chapter.

## Verses 16–20 — SAUL WEEPS / CONFESSES

After David finishes, Saul recognizes his voice, calls him son and weeps. Saul says David is more righteous because David did good while Saul did evil. He accepts the cave account: LORD delivered Saul to David and David did not kill him. He asks who finds an enemy and lets him leave unharmed, then asks LORD to reward David.

Saul's confession aligns his speech with the retained pursuit and David's spared-enemy evidence. It is not a retrospective denial and therefore is not crack. Saul says he knows David will surely be king and Israel's kingdom established in David's hand. The installation remains future speech.

## Verses 21–22 — OATH / SEPARATE DEPARTURES

Saul asks David to swear by LORD not to cut off Saul's offspring or destroy Saul's name from his father's house. David swears. The requested future preservation remains untested here.

Saul goes home. David and his men go up to the stronghold. Their different destinations remain; the dialogue does not establish reconciliation, safety or the end of future pursuit.

## Character and world-ledger changes

- NOT-DAVID gains cave opportunity, secret robe cut, heart-struck State, restraint of his men, public evidence display, hand-refusal speech and oath to Saul.
- NOT-SAUL gains three-thousand-person En Gedi pursuit, cave vulnerability, survival, confession/weeping, David-kingship acknowledgment, offspring/name request and homeward departure.
- NOT-DAVID'S MEN gain attributed LORD-delivery quotation and restrained opportunity without invented kill wording.
- No new God-only line is created; all LORD content is human attribution, appeal, oath or requested future act.

## Bullshit pass

Issue `1SA-024 / CRACKHEAD COMPLIANCE SAMPLE`. NOT-DAVID performs a secret **ROYAL ROBE EDGE DESTRUCTIVE TEST**, immediately fails his own internal quality check, then presents the removed sample as proof that the king remains substantially un-killed. NOT-SAUL signs the finding **YOU ARE MORE RIGHTEOUS / I HAVE DONE EVIL** and requests a future-name retention warranty. No crack issued. Foundation unchanged.

## FIR verification

- FILTER: all 22 markers retained; 1 Samuel 25 excluded.
- ISOLATE: pursuit, cave coincidence, men's attributed speech, robe cut, heart response, restraint, evidence address, appeals, Saul confession, future kingship, oath and departures.
- RECONSTRUCT: complete causal interaction; zero closed contradiction episodes.
- VERIFY: heart/no-evil scope unresolved; men's kill wording not backfilled; future oath and kingship unexecuted; no SKIP/YOINK; publication held.

## Required compound-eye facets

1. Saul returns / En Gedi report / three thousand selected.
2. Saul enters cave / David and men hidden inside.
3. Men's attributed LORD-delivery speech.
4. David secretly cuts robe skirt.
5. David's heart strikes him because of the cut.
6. David refuses hand against anointed / restrains men.
7. Saul exits unharmed.
8. David emerges, calls king, bows.
9. Cut skirt displayed / spared-life account.
10. No-evil/no-sin speech against retained robe-cut and heart State, visibly marked **SCOPE UNRESOLVED — NO CRACK**.
11. LORD judgment/avenge/deliver appeals / dead dog/flea comparison.
12. Saul recognizes voice, weeps and confesses David good/Saul evil.
13. David future-kingship acknowledgment.
14. Offspring/name oath request / David swears.
15. Saul home / David stronghold / held lineage; chapter 25 excluded.

All fifteen addressed facets appear simultaneously in one zoomable compound-eye image. Facet numbering preserves traversal without turning the presentation back into fifteen linear pages.

## Production boundary

One actual high-resolution compound-eye image, fifteen addressed Moment facets, every living thing Joe-faced, `NOT-` display, no divine form. No episode, SKIP, boil, Captain interaction or YOINK. Keep the cave bodily act private and all threat imagery non-graphic. Do not invent direct LORD speech, men's kill dialogue, Saul motive, reconciliation, oath fulfillment, future kingship or a shared scope for heart-struck/no-evil friction. Originator visual review required; publication held.

*shrug*

OK.
