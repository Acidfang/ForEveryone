# CRACKHEAD 1 SAMUEL 31

## Title field

**NOT-SAUL AND THREE NAMED SONS DIED ON GILBOA. NOT-JABESH TOOK THE BODIES BACK.**

Source parent: 1 Samuel chapter 31, verses 1–13, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-031/job.json` and `source.usfm`. Parent: 1 Samuel 30, with chapter 28 prediction retained as a separate parent. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced. Battle, death, body treatment and burning remain restrained and non-graphic.

CrackFlix: none. Battle delivery and named deaths are observed, but the source supplies no calendar bridge proving chapter 28's “tomorrow,” and does not close the full scope of “your sons.” Zero SKIP and zero YOINK.

Production format: one high-resolution compound-eye field with all changed States simultaneous and addressed causal traversal.

## Causal foundation

```text
PHILISTINES FIGHT ISRAEL
-> ISRAELITES FLEE / MEN FALL SLAIN ON GILBOA
-> PHILISTINES OVERTAKE SAUL + SONS
-> JONATHAN / ABINADAB / MALCHISHUA KILLED
-> ARCHERS OVERTAKE SAUL / BATTLE HARD
-> SAUL REQUESTS ARMOR-BEARER KILL HIM
-> ARMOR-BEARER REFUSES FROM TERROR
-> SAUL FALLS ON OWN SWORD / DIES
-> ARMOR-BEARER SEES / DOES LIKEWISE / DIES
-> SAUL + THREE SONS + ARMOR-BEARER + ALL HIS MEN DIE SAME DAY
-> OTHER ISRAELITES SEE / ABANDON CITIES / FLEE
-> PHILISTINES OCCUPY CITIES
-> NEXT DAY PHILISTINES FIND BODIES
-> SAUL HEAD/ARMOR REMOVED / NEWS SENT
-> ARMOR IN ASHTAROTH HOUSE / BODY FASTENED AT BETH SHAN
-> JABESH-GILEAD HEARS
-> VALIANT MEN TRAVEL ALL NIGHT / RECOVER SAUL + SONS' BODIES
-> BODIES BURNED / BONES BURIED UNDER TAMARISK / SEVEN-DAY FAST
```

## Verses 1–6 — BATTLE / THREE SONS / SAUL AND ARMOR-BEARER DIE

Philistines fight Israel. Israelite men flee and fall slain on Mount Gilboa. Philistines overtake Saul and his sons and kill Jonathan, Abinadab and Malchishua.

Battle goes hard against Saul; archers overtake him and he is greatly distressed. Saul asks his armor-bearer to kill him to prevent Philistine thrust/abuse. The armor-bearer refuses because he is terrified. Saul falls on his own sword. Seeing Saul dead, the armor-bearer likewise falls on his sword and dies.

Narration says Saul, his three sons, armor-bearer and all his men die together that same day. “All his men” retains this narrated group boundary and is not expanded to every Israelite in the region.

This observes Philistine battle success and the deaths of Saul plus three named sons, matching parts of the chapter 28 speaker's prediction. It does not prove the exact “tomorrow” relation without a calendar bridge, nor prove every possible son was included. No crack is manufactured.

## Verse 7 — CITY ABANDONMENT / PHILISTINE OCCUPATION

Israelites across the valley and Jordan see Israel's flight and Saul/sons' deaths, abandon cities and flee. Philistines come and live in the cities. These living fleeing Israelites are not merged with “all his men” from verse 6.

## Verses 8–10 — NEXT-DAY DISCOVERY / NEWS / DISPLAY

On the next day Philistines strip the slain and find Saul and three sons on Gilboa. They remove Saul's head and armor, send news around Philistine land to idol houses and people, place armor in the Ashtaroth house, and fasten Saul's body to Beth Shan's wall. Presentation remains non-graphic; no idol face, speech or divine effect is invented.

## Verses 11–13 — JABESH RECOVERY / BURNING / BURIAL / FAST

Jabesh-Gilead hears what Philistines did. All valiant men travel all night, remove Saul's and his sons' bodies from the wall, bring them to Jabesh and burn them. They bury the bones under the tamarisk/salt-cedar tree and fast seven days.

The source does not explain the relation between burning and bone burial beyond the ordered acts. No resurrection, afterlife mechanism or later report is imported.

## Character and world-ledger changes

- NOT-SAUL closes living State through battle distress, refused assisted-death request, self-sword act and narrated death.
- NOT-JONATHAN, NOT-ABINADAB and NOT-MALCHISHUA close living State through named Philistine killings.
- NOT-ARMOR-BEARER gains terrified refusal, observed Saul death and own death.
- NOT-PHILISTINES gain battle victory, city occupation, body/armor handling and news distribution.
- NOT-JABESH-VALIANT-MEN gain overnight recovery, burning, burial and seven-day-fast acts.

## Bullshit pass

Issue `1SA-031 / KING SERVICE TERMINATION AND ASSET RECOVERY`. NOT-SAUL's armor-bearer rejects the requested shutdown operation; NOT-SAUL performs local shutdown; the armor-bearer mirrors it. NOT-PHILISTINES redistribute the hardware and publish the incident. NOT-JABESH runs an unauthorized overnight recovery, archival burn, bone backup and seven-day maintenance window. The chapter 28 forecast remains marked **PARTIAL MATCH / CALENDAR BRIDGE MISSING**. Foundation unchanged.

## FIR verification

- FILTER: all 13 markers retained; 2 Samuel 1 excluded.
- ISOLATE: battle, named deaths, Saul/armor-bearer acts, city abandonment/occupation, body treatment, Jabesh recovery/burial/fast.
- RECONSTRUCT: chapter 28 delivery/death prediction has partial observed fit; tomorrow and full sons scope unresolved.
- VERIFY: zero contradiction/SKIP/YOINK; non-graphic production; publication held.

## Required compound-eye facets

1. Philistine-Israel battle / Israel flight / Gilboa deaths.
2. Philistines overtake Saul/sons / three named sons killed.
3. Archers overtake Saul / battle hard / distress.
4. Saul asks armor-bearer / armor-bearer terrified refusal.
5. Saul self-sword act / death, non-graphic.
6. Armor-bearer observes / likewise dies; verse-6 group closure.
7. Chapter-28 prediction joined as **PARTIAL MATCH — TOMORROW/FULL SONS SCOPE UNRESOLVED — NO CRACK**.
8. Other Israelites flee / abandon cities / Philistines occupy.
9. Next-day body discovery on Gilboa.
10. head/armor/news/Ashtaroth/Beth-Shan actions, restrained.
11. Jabesh hears / valiant men travel all night.
12. bodies recovered and brought to Jabesh / burned, restrained.
13. bones buried under tamarisk/salt cedar / seven-day fast.
14. 1 Samuel held-complete 31/31; 2 Samuel 1 excluded.

All fourteen facets appear simultaneously in one zoomable compound-eye image.

## Production boundary

One high-resolution compound-eye image with 14 facets. `NOT-` display; living things Joe-faced; all battle/death/body acts restrained and non-graphic; no divine/idol form or effect. Zero contradiction/SKIP/YOINK. Preserve prediction as partial match only, exact three named sons, verse-6 group boundary, other fleeing Israelites, and ordered Jabesh acts. Originator review required; publication held.

*shrug*

OK.
