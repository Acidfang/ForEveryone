# CRACKHEAD 1 SAMUEL 30

## Title field

**NOT-DAVID RECOVERED ALL AND MADE THE BATTLE/BAGGAGE SHARES ALIKE.**

Source parent: 1 Samuel chapter 30, verses 1–31, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-030/job.json` and `source.usfm`. Parent: 1 Samuel 29. Exact identities remain evidence; display uses `NOT-`. Every living thing is Joe-faced, including animals. Raids, threatened stoning, battle and calf/livestock States remain non-graphic.

CrackFlix: none. The four-hundred escape is an explicit exception in the source sentence. The proposed no-share rule is rejected before allocation. Zero SKIP and zero YOINK.

Production format: one high-resolution compound-eye field with all changed States simultaneous and addressed causal traversal.

## Causal foundation

```text
DAVID + MEN RETURN THIRD DAY
-> ZIKLAG BURNED / PEOPLE CAPTURED / NOBODY KILLED
-> GROUP WEEPS / MEN SPEAK OF STONING DAVID
-> DAVID STRENGTHENS HIMSELF IN LORD
-> ABIATHAR BRINGS EPHOD / DAVID INQUIRES
-> LORD ANSWERS PURSUE / OVERTAKE / RECOVER ALL
-> 600 REACH BESOR / 200 TOO FAINT / 400 CONTINUE
-> ABANDONED SICK EGYPTIAN FOUND / FED / REVIVED
-> EGYPTIAN REPORTS AMALEKITE MASTER + RAIDS + ZIKLAG FIRE
-> SAFETY OATH REQUEST / EGYPTIAN GUIDES DAVID
-> TROOP FOUND EATING/DRINKING/DANCING WITH PLUNDER
-> DAVID STRIKES THROUGH NEXT EVENING
-> 400 CAMEL RIDERS EXPLICITLY ESCAPE
-> DAVID RECOVERS ALL / NOTHING LACKING
-> FLOCKS/HERDS CALLED DAVID'S PLUNDER
-> RETURN TO 200 / DAVID GREETS
-> SOME FIGHTERS PROPOSE FAMILY-ONLY RETURN / NO PLUNDER SHARE
-> DAVID REJECTS / ATTRIBUTES PRESERVATION + DELIVERY TO LORD
-> BATTLE AND BAGGAGE SHARES ALIKE
-> RULE BECOMES ISRAEL STATUTE
-> DAVID SENDS PLUNDER PRESENTS TO JUDAH ELDERS/FRIENDS/PLACES
```

## Verses 1–6 — BURNED CITY / CAPTIVES ALIVE / WEEPING / STONING SPEECH

On the third day David and his men reach Ziklag after Amalekites raided the South and city, burned it, and captured everyone small and great without killing anyone. Wives, sons and daughters are absent as captives. David and the people weep until no strength remains; Ahinoam and Abigail are named among the captured.

The men speak of stoning David because they grieve their children. No stoning occurs. David is distressed and strengthens himself in LORD his God; the mechanism is not supplied.

## Verses 7–10 — EPHOD / ANSWER / 600 BECOMES 400 + 200

Abiathar brings the ephod at David's request. David asks LORD whether pursuit will overtake the troop. The answer is: pursue, surely overtake, and recover all. No divine form or ephod mechanics are rendered.

Six hundred reach Besor. Two hundred are too faint to cross and stay; David continues with four hundred. The split is observed incapacity, not refusal or punishment.

## Verses 11–16 — ABANDONED EGYPTIAN / FOOD / REPORT / GUIDE

They find an Egyptian in a field, bring him to David, give bread, water, fig cake and raisins. After three days/nights without food or water, his spirit returns. He says his Amalekite master abandoned him when he became sick and reports raids on Cherethite/Judah/Caleb south and burning Ziklag.

David asks for guidance to the troop. The Egyptian requests an oath against killing or return to his master, then guides David. The source does not separately narrate David's oath words; the completed guidance shows the requested route proceeds without supplying the missing oath carrier.

## Verses 16–20 — ATTACK / EXPLICIT 400 EXCEPTION / ALL RECOVERED

The troop is spread over the ground eating, drinking and dancing because of plunder from Philistine and Judah land. David strikes from twilight to the next evening. The source says no man escaped **except four hundred young camel riders who fled**. Because the exception is explicit inside the same statement, it is not a contradiction.

David recovers everything Amalekites took, rescues both wives, and narration says nothing small/great, son/daughter, plunder or other item is lacking. He brings all back. Additional flocks/herds are driven ahead and called David's plunder. All visible surviving animals are Joe-faced.

## Verses 21–25 — PROPOSED EXCLUSION / EQUAL SHARES / STATUTE

David returns to the two hundred, who meet him; he greets them. Narrator-labelled wicked/worthless fighters propose giving the two hundred only their wives and children because they did not go, withholding recovered plunder.

David rejects the proposal before allocation. He calls the men brothers, attributes gift, preservation and troop delivery to LORD, and sets equal shares for battle-goers and baggage-stayers. The source says this becomes an Israel statute and ordinance from that day to its “this day.” Proposal and adopted rule differ through an explicit decision process; no contradiction is manufactured.

## Verses 26–31 — PRESENTS FROM PLUNDER

At Ziklag David sends plunder to Judah elders/friends as a present from LORD's enemies. Recipients are Bethel, South Ramoth, Jattir, Aroer, Siphmoth, Eshtemoa, Racal, Jerahmeelite cities, Kenite cities, Hormah, Borashan, Athach, Hebron and all places David and men stayed. Delivery mechanics and individual quantities are unresolved; the send act and addressed list are retained.

## Character and world-ledger changes

- NOT-DAVID gains burned-city return, distress/strengthening, inquiry, pursuit, rescue/recovery, equal-share rule and present distribution.
- NOT-MEN split into 400 pursuers and 200 faint baggage-stayers; proposed exclusion belongs only to narrator-labelled subset.
- NOT-ABIATHAR gains ephod delivery; NOT-EGYPTIAN gains abandonment, revival, raid report, safety request and guidance.
- NOT-AMALekites gain raid/capture, celebration, battle and explicit 400-rider escape; captured households return complete.

## Bullshit pass

Issue `1SA-030 / DISASTER RECOVERY WITH ABANDONED VENDOR DOCUMENTATION`. The only surviving route documentation is a sick contractor left in a field by the attacking organization. Feeding him restores the navigation service. Recovery returns **ALL**, while four hundred explicitly excepted camel accounts remain outside the deletion query. The combat team proposes deleting the support team's bonus; NOT-DAVID writes **BATTLE SHARE = BAGGAGE SHARE** into national policy. Foundation unchanged.

## FIR verification

- FILTER: all 31 markers retained; 1 Samuel 31 excluded.
- ISOLATE: raid/captivity, return/grief, inquiry, 600 split, Egyptian recovery/guidance, attack/exception, total recovery, share dispute/rule and presents.
- RECONSTRUCT: explicit exception is not universal contradiction; proposed rule is changed before execution.
- VERIFY: zero episodes/SKIP/YOINK; direct answer retained without form/mechanics; publication held.

## Required compound-eye facets

1. Ziklag raid/fire/captivity with nobody killed.
2. Return / family absence / weeping / named wives captured.
3. stoning speech / David distress and LORD-strengthening.
4. Abiathar ephod / inquiry / pursue-overtake-recover-all answer.
5. 600 at Besor / 200 faint stay / 400 pursue.
6. Egyptian found/fed/revived after three days/nights.
7. Egyptian identity/abandonment/raid report.
8. Guidance request / safety condition / completed guidance.
9. Amalekite celebration and retained plunder.
10. non-graphic attack through next evening / explicit 400 camel-rider exception; **NO CRACK**.
11. all recovered / wives rescued / nothing lacking.
12. flocks/herds and “David's plunder”; Joe-faced animals.
13. return/greeting to 200 / subset proposes family-only return.
14. David rejects; LORD gift/preservation/delivery attribution.
15. equal battle/baggage shares / statute.
16. Ziklag present and complete addressed recipient/place list; chapter 31 excluded.

All sixteen facets appear simultaneously in one zoomable compound-eye image.

## Production boundary

One high-resolution compound-eye image with 16 facets. `NOT-` display; living things Joe-faced; all violence non-graphic; no divine form. Zero contradiction/SKIP/YOINK. Keep the four hundred as explicit exception, proposed share exclusion unexecuted, equal-share rule adopted, and recipient list complete. Originator review required; publication held.

*shrug*

OK.
