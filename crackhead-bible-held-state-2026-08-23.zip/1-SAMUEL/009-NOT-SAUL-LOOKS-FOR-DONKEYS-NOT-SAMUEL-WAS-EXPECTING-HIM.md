# CRACKHEAD 1 SAMUEL 9

## Title page

**NOT-SAUL GOES LOOKING FOR DONKEYS. NOT-SAMUEL HAS ALREADY RESERVED HIS DINNER.**

Source parent: 1 Samuel chapter 9, verses 1–27, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-009/job.json` and `source.usfm`. Parent: 1 Samuel 8.

Display-origin layer: exact identities remain in evidence; comic display uses `NOT-` identities and places. Every living human, donkey and plant is Joe-faced. Silver, sacks, water vessels, sacrifice portions, buildings and other face-like objects may receive Joe faces without life. NOT-THE-LORD remains unrendered.

CrackFlix routing: no completed contradiction, no SKIP, no Captain and no YOINK.

## Causal foundation

```text
KISH LINEAGE + SAUL DESCRIPTION
-> KISH DONKEYS LOST
-> KISH SENDS SAUL + SERVANT TO SEARCH
-> MULTIPLE LANDS SEARCHED / NOTHING FOUND
-> SAUL PROPOSES RETURN FOR FATHER'S ANXIETY
-> SERVANT PROPOSES HONORED MAN OF GOD
-> SAUL NOTES NO PRESENT / SERVANT HAS QUARTER SHEKEL
-> THEY GO / MAIDENS DIRECT THEM TO SAMUEL + SACRIFICE TIMING
-> SAMUEL MEETS THEM
-> PRIOR DAY: LORD REVEALED BENJAMITE MAN + FUTURE ANOINTING/DELIVERANCE
-> PRESENT: LORD IDENTIFIES SAUL TO SAMUEL
-> SAUL ASKS SAMUEL WHERE SEER IS
-> SAMUEL IDENTIFIES HIMSELF / INVITES SAUL / SAYS DONKEYS FOUND
-> SAMUEL STATES ISRAEL DESIRE / SAUL QUESTIONS SMALL TRIBE/FAMILY
-> SAUL + SERVANT GET BEST SEATS / RESERVED PORTION
-> SAUL EATS / SAMUEL TALKS ON ROOFTOP
-> DAYBREAK DEPARTURE
-> SERVANT SENT AHEAD
-> SAUL TOLD TO STAND FOR GOD'S MESSAGE
```

## 1 Samuel 9:1–5 — NOT-SAUL'S DONKEY SEARCH

Kish is introduced as a Benjaminite mighty man of valor through Abiel, Zeror, Becorath and Aphiah. Kish's son Saul is impressive, described as more handsome than any Israelite and taller from the shoulders upward.

Kish's donkeys become lost. He sends Saul with one servant to look for them. They search Ephraim's hill country, Shalishah, Shaalim and Benjaminite land without finding them.

At Zuph, Saul proposes returning because his father may stop caring about the donkeys and become anxious for them. The father-anxiety statement is Saul's forecast; Kish's changed concern is not observed here.

## 1 Samuel 9:6–10 — THE SERVANT HAS A QUARTER SHEKEL

The servant says an honored man of God is in the city and that all he says surely happens. He proposes asking which way to go. This is the servant's reputation statement, not a universal verification performed by the chapter.

Saul says their bread is spent and asks what present they have. The servant has a quarter shekel of silver and offers it for direction. The narrator explains that the person now called prophet was formerly called seer.

Saul accepts the proposal and they go to the city. The silver is available; the source does not record it being transferred.

## 1 Samuel 9:11–14 — WATER-DRAWERS GIVE THE TIMING

On the city ascent, Saul and the servant meet young women going to draw water and ask whether the seer is there.

The women say he has arrived that day for a high-place sacrifice. They tell the travelers to hurry: the people wait for him to bless the sacrifice before invited guests eat. They say Saul and the servant will find him at that time.

The pair enters the city as Samuel comes out toward them on his way to the high place. The women's directions resolve observably; their knowledge source and exact timing mechanism remain unprovided.

## 1 Samuel 9:15–17 — SAMUEL ALREADY HAS THE ADDRESS

The narrator moves back one day. LORD had revealed to Samuel that about the same time tomorrow he would send a Benjaminite man. Samuel is told to anoint him prince over Israel; the man will save the people from the Philistines because their cry has reached LORD.

When Samuel sees Saul, LORD directly identifies him as the man previously mentioned and says he will have authority over the people.

This prior revelation and present identification belong to Samuel's knowledge boundary. Saul has not yet heard them. Anointing, authority execution and Philistine deliverance remain future.

## 1 Samuel 9:18–21 — ASKING THE SEER WHERE THE SEER IS

Saul approaches Samuel at the gateway and asks where the seer's house is. Samuel says, **“I AM THE SEER.”** He sends Saul ahead to the high place, invites him to eat, promises morning release and says he will tell Saul everything in his heart.

Samuel says the donkeys lost three days earlier have been found and tells Saul not to set his mind on them. The finder, location, recovery act and return to Kish are not supplied.

Samuel asks whether all Israel's desire is for Saul and his father's house. Saul responds that he is from Benjamin, the smallest tribe, and from its least family, and asks why Samuel speaks that way. These are Samuel's statement and Saul's self-location; do not convert them into a verified population ranking beyond their speech.

## 1 Samuel 9:22–27 — RESERVED BEFORE ARRIVAL

Samuel brings Saul and the servant into the guest room and gives them the best place among about thirty invitees. Samuel asks the cook for a portion he previously ordered set aside. The cook places the thigh and what is on it before Saul. Samuel says it was reserved for Saul for the appointed time. Saul eats with Samuel.

The pre-reserved portion joins the prior-day revelation and planned invitation. It does not reveal an unrecorded conversation or make the cook divine.

After descending to the city, Samuel talks with Saul on the housetop. The content is not supplied. At daybreak Samuel calls Saul, they go outside together and walk toward the city edge.

Samuel tells Saul to send the servant ahead. The servant goes. Samuel tells Saul to stand still so he may cause Saul to hear God's message.

The message itself and anointing are excluded with 1 Samuel 10. No contradiction completes merely because Saul's donkey search intersects Samuel's prepared selection path.

## Character and world-ledger changes

- NOT-KISH JOE gains lineage, valor description, lost donkeys and search instruction.
- NOT-SAUL JOE gains physical description, multi-land search, father-concern speech, seer inquiry, Samuel encounter, best-seat meal and private-message threshold.
- NOT-SERVANT JOE proposes the seer route, supplies quarter-shekel capability, accompanies Saul and later goes ahead.
- NOT-WATER-DRAWER JOES provide Samuel/sacrifice timing directions.
- NOT-SAMUEL JOE gains prior-day direct revelation, present Saul identification, planned invitation/portion and private disclosure boundary.
- NOT-COOK JOE retains the reserved portion and serves it.
- No CrackFlix occurrence is admitted.

## Bullshit pass

Issue `1SA-009 / DONKEY-LOSS EXECUTIVE RECRUITMENT`. NOT-SAUL submits a missing-donkey ticket. NOT-SERVANT escalates it to the seer. NOT-SAMUEL has already booked the candidate lunch under **APPOINTED TIME**, while the donkeys silently close their own ticket off-panel. Foundation unchanged.

## FIR verification

- FILTER: 1 Samuel 9 only; all 27 markers retained in order; 1 Samuel 10 excluded.
- ISOLATE: Saul lineage/description, donkey search, servant proposal/payment capacity, women directions, prior revelation, encounter, donkey-found statement, meal preparation and private-message threshold.
- RECONSTRUCT: search path and independently prepared Samuel path meet; differing knowledge boundaries remain distinct.
- VERIFY: zero contradictions, SKIPs, Captain or YOINK; no payment/anointing/king installation imported; divine form absent; publication held.

## Required comic states

1. Kish lineage/valor and Saul appearance/height.
2. Lost Joe-faced donkeys; Kish sends Saul and servant.
3. Ephraim/Shalishah/Shaalim/Benjamin search montage, no find.
4. Zuph: Saul proposes return due possible father anxiety.
5. Servant proposes honored man of God whose words happen.
6. Saul's empty provisions question; servant shows quarter shekel.
7. Seer/prophet language note and decision to go.
8. Water-drawing women provide high-place timing/directions.
9. Saul/servant enter as Samuel comes toward them.
10. Prior-day direct LORD revelation to Samuel, LORD unrendered.
11. Present LORD identification of Saul to Samuel, LORD unrendered.
12. Saul asks Samuel where seer is; Samuel identifies himself.
13. Samuel invitation, donkey-found statement and Israel-desire speech; Saul questions it.
14. Guest room/best place/about thirty; cook produces reserved portion.
15. Saul eats with Samuel; housetop conversation content held unknown.
16. Daybreak departure; servant sent ahead.
17. Saul stands for God's message; 1 Samuel 10 excluded.
18. Held lineage page with zero contradiction machinery.

## Production boundary

- Every displayed biblical identity/place uses `NOT-`; exact names remain in evidence.
- Every living human, donkey and plant is Joe-faced. Silver/sacks/water vessels/food/building faces do not establish life. LORD remains unrendered.
- Preserve prior-day revelation as a temporal inset before present Saul identification; do not make Saul hear either.
- Preserve servant claim, women directions, Samuel statements and narrator facts as separate carriers.
- Do not show quarter-shekel payment, donkey recovery mechanics, king installation, anointing, future deliverance, private housetop dialogue or next message.
- No contradiction, CrackFlix, SKIP, Captain or YOINK.
- Publication held. `CHB-1SA-010` excluded.

*shrug*

OK.
