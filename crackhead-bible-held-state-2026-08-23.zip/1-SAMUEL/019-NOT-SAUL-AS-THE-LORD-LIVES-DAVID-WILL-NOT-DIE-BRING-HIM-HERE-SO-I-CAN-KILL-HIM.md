# CRACKHEAD 1 SAMUEL 19

## Title page

**NOT-SAUL: AS THE LORD LIVES, DAVID WILL NOT DIE. BRING HIM HERE SO I CAN KILL HIM.**

Source parent: 1 Samuel chapter 19, verses 1–24, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-019/job.json` and `source.usfm`. Parent: 1 Samuel 18. Exact identities remain in evidence; comic display uses `NOT-` identities. Every living thing is Joe-faced. Divine/spirit forms remain unrendered. Violence and nakedness remain restrained and non-graphic.

CrackFlix: premiere `S195`, repeated `S191-E002-1SA19`, premieres `S196` and `S197`. Nine closed episodes total. Six exact SKIPs. Exactly nine causally-null post-closure YOINKs.

## Causal foundation

```text
SAUL ORDERS JONATHAN/SERVANTS TO KILL DAVID
-> JONATHAN WARNS DAVID / HIDING + FIELD ADVOCACY PLAN
-> JONATHAN: DAVID DID GOOD / VICTORY / INNOCENT BLOOD / NO CAUSE
-> SAUL SWEARS: AS LORD LIVES, DAVID SHALL NOT BE PUT TO DEATH
-> DAVID RETURNS TO SAUL
-> WAR AGAIN / DAVID WINS / PHILISTINES FLEE
-> SAUL AGAIN TRIES TO PIN DAVID / SPEAR STICKS WALL / DAVID ESCAPES
-> SAUL SENDS HOUSE WATCHERS TO KILL DAVID IN MORNING
-> MICHAL LOWERS DAVID THROUGH WINDOW / HE ESCAPES
-> IDOL + GOAT-HAIR PILLOW + CLOTHES IN BED
-> MICHAL: HE IS SICK
-> MESSENGERS SEE IDOL IN BED
-> SAUL: BRING DAVID IN BED SO I MAY KILL HIM
-> IDOL STILL IN BED
-> MICHAL REPORTS DAVID THREAT; EVENT NOT OBSERVED HERE
-> DAVID/SAMUEL AT NAIOTH
-> SEIZE PARTY 1 SEES PROPHETS / PROPHESIES
-> SEIZE PARTY 2 PROPHESIES
-> SEIZE PARTY 3 PROPHESIES
-> SAUL GOES HIMSELF / PROPHESIES / STRIPS / LIES ALL DAY AND NIGHT
```

## Verses 1–7 — KILL ORDER / ADVOCACY / DEATH OATH / RETURN

Saul tells Jonathan and all servants to kill David. Jonathan delights greatly in David, warns him, tells him to hide, and promises to speak with Saul and report what he sees. Jonathan cites David's good works, life-risk, Philistine victory, Saul's observed rejoicing, innocent blood and absence of cause.

Saul listens and swears: **“AS THE LORD LIVES, HE SHALL NOT BE PUT TO DEATH.”** Jonathan reports the interaction and returns David to Saul's presence as before. The oath is completed speech; it does not erase the earlier kill order.

## Verses 8–10 — OATH / ANOTHER SPEAR

War recurs. David fights, produces a great slaughter, and Philistines flee. Narration says an evil spirit from LORD is on Saul while Saul holds a spear and David plays music. Saul seeks to pin David; David slips away, the spear sticks in the wall, and David escapes that night.

New `S195: AS THE LORD LIVES, DAVID WILL NOT DIE. I AM TRYING TO KILL DAVID.` `S195-E001-1SA19` closes at Saul's first observed post-oath kill attempt. No SKIP. One causally-null **“YOINK!”**.

The spear result repeats `S191`. `S191-E002-1SA19` displays **SKIP -> S191-E001-1SA18**. SKIP omits the already-addressed pin/escape contradiction and changes nothing. One separate causally-null **“YOINK!”**.

## Verses 11–12 — OATH / MORNING KILL ORDER / WINDOW ESCAPE

Saul sends messengers to watch David's house and kill him in the morning. Michal warns David that he will be killed tomorrow unless he saves his life tonight, lowers him through the window, and David goes, flees and escapes.

`S195-E002-1SA19` displays **SKIP -> S195-E001-1SA19** because the same death oath now meets a distinct kill order. The messengers' intended morning act is not invented as completed; the contradiction closes at Saul's order. One causally-null **“YOINK!”**.

## Verses 13–16 — HE IS SICK / THAT IS AN IDOL

Michal places a teraphim in the bed, a goats'-hair pillow at its head, and clothes over it. The footnote describes possible household-property association but does not establish this object's purpose. When messengers come to take David, Michal says **“HE IS SICK.”**

Saul orders them to see David and bring him in the bed **“THAT I MAY KILL HIM.”** This is the third distinct post-oath kill instruction. `S195-E003-1SA19` displays **SKIP -> S195-E002-1SA19**. One causally-null **“YOINK!”**.

The messengers enter and observe the teraphim and goats'-hair pillow in the bed, not David. New `S196: HE IS SICK IN BED. THAT IS AN IDOL IN BED.` closes at that observation. No SKIP. One causally-null **“YOINK!”**. The object may receive a Joe face as face-like garbage, but it is not established as alive or as David.

## Verses 17–19 — ACCUSATION / REPORTED THREAT / NAIOTH

Saul asks Michal why she deceived him and let his enemy escape. Michal answers that David told her to let him go and asked why he should kill her. This chapter supplies her report but no observed David threat event. It remains an unresolved asserted occurrence, not crack.

David reaches Samuel at Ramah, reports what Saul did, and they live at Naioth. Saul receives David's location.

## Verses 20–24 — GO SEIZE HIM / EVERYBODY PROPHESIES

Saul sends messengers to seize David. They see a company of prophets prophesying with Samuel standing as head; narration says God's Spirit comes on the messengers and they also prophesy.

New `S197: GO SEIZE DAVID. YOU ARE PROPHESYING.` `S197-E001-1SA19` closes when the first seizure party performs the different observed act. No SKIP. One causally-null **“YOINK!”**.

Saul sends a second party; they also prophesy. `S197-E002-1SA19` displays **SKIP -> S197-E001-1SA19**. One causally-null **“YOINK!”**. He sends a third party; they also prophesy. `S197-E003-1SA19` displays **SKIP -> S197-E002-1SA19**. One causally-null **“YOINK!”**.

Saul goes himself, asks where Samuel and David are, receives Naioth, continues there, and narration says God's Spirit comes on him. He prophesies while traveling, strips his clothes, prophesies before Samuel, and lies naked all day and night. This is Saul's own fourth attempted route into the same non-seizure State. `S197-E004-1SA19` displays **SKIP -> S197-E003-1SA19**. One causally-null **“YOINK!”**. The concluding saying **“IS SAUL ALSO AMONG THE PROPHETS?”** is retained as speech; no membership ontology or spirit mechanism is invented.

## Character and world-ledger changes

- NOT-SAUL gains kill order, death oath, restored David presence, spear attempt, house-watch/bed-kill orders, Michal confrontation, three messenger dispatches and personal Naioth/prophesying/naked State.
- NOT-DAVID gains Jonathan warning, hiding, restored court presence, renewed war success, spear escape, window escape and Samuel/Naioth refuge.
- NOT-JONATHAN gains warning, field advocacy, oath witness and David restoration.
- NOT-MICHAL gains warning, window lowering, bed decoy, sick report and later threat report; no unobserved threat is adopted.
- NOT-SAMUEL/pro, messengers and location informant retain their exact observed roles.

## Bullshit pass

Issue `1SA-019 / FOUR FAILED ARREST WORKFLOWS`. Palace policy says **DAVID SHALL NOT DIE**, then emits spear, dawn-kill and hospital-bed-kill tickets. The surveillance dummy is a Joe-faced household idol with premium goat-hair support. Every arrest team reaches **CRACKHEAD PROPHET MODE** instead. Foundation unchanged.

## FIR verification

- FILTER: all 24 markers retained; 1 Samuel 20 excluded.
- ISOLATE: kill order/advocacy/oath, three post-oath death acts, repeated pin failure, bed report/decoy, unresolved threat report, four seizure routes/prophesying outcomes.
- RECONSTRUCT: nine closed episodes; three new series and one repeated existing series.
- VERIFY: six exact SKIPs, nine YOINKs, reported threat and divine/spirit mechanisms unresolved; publication held.

## Required comic states

1. Kill order / Jonathan warning and hiding plan.
2. Jonathan's evidence-based advocacy.
3. Saul death oath and David return.
4. War win / renewed spear / escape; S195-E001 and S191-E002 SKIP/YOINKs.
5. House watch/morning kill / Michal warning/window escape; S195-E002 SKIP/YOINK.
6. Idol/goat hair/clothes bed and “he is sick.”
7. Bed-kill instruction; S195-E003 SKIP/YOINK.
8. Idol revealed; S196/YOINK.
9. Saul/Michal exchange; threat report visibly marked reported/unverified without narration explaining it.
10. David/Samuel at Naioth; location reported.
11. First seizure party prophesies; S197-E001/YOINK.
12. Second party prophesies; S197-E002 SKIP/YOINK.
13. Third party prophesies; S197-E003 SKIP/YOINK.
14. Saul goes/prophesies/strips/lies all day-night; S197-E004 SKIP/YOINK.
15. Held lineage page; chapter 20 excluded.

## Production boundary

`NOT-` display; every living thing Joe-faced; teraphim may be face-like but is not established alive. No divine/spirit form. Restrained/non-graphic spear and kill imagery; strategic object/blanket framing for nakedness. Nine episodes, six exact SKIPs, nine separate boilless causally-null Captain poke/lick/**“YOINK!”**/walk-away appearances. Do not convert Michal's reported threat into observed history. Publication held.

*shrug*

OK.
