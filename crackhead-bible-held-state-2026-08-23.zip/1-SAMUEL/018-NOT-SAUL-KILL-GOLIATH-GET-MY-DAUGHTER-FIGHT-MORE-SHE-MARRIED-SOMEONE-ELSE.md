# CRACKHEAD 1 SAMUEL 18

## Title page

**NOT-SAUL: KILL GOLIATH, GET MY DAUGHTER. FIGHT MORE. SHE MARRIED SOMEONE ELSE.**

Source parent: 1 Samuel chapter 18, verses 1–30, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-018/job.json` and `source.usfm`. Parent: 1 Samuel 17. Exact identities remain in evidence; comic display uses `NOT-` identities. Every living thing is Joe-faced. Divine/spirit forms remain unrendered. Violence and the foreskin delivery remain restrained and non-graphic.

CrackFlix premieres: `S190-E001-1SA18` through `S194-E001-1SA18`. Zero SKIPs. Exactly five causally-null post-closure YOINKs.

## Causal foundation

```text
JONATHAN LOVES DAVID / COVENANT / GIFTS
-> DAVID SUCCEEDS UNDER SAUL
-> WOMEN: SAUL THOUSANDS / DAVID TEN THOUSANDS
-> SAUL ANGRY / WATCHES
-> SAUL: I WILL PIN DAVID TO WALL / THROWS SPEAR TWICE
-> DAVID ESCAPES TWICE
-> SAUL REMOVES THEN PROMOTES DAVID / PEOPLE LOVE DAVID
-> RETAINED REWARD: KING'S DAUGHTER FOR GOLIATH KILL
-> MERAB OFFERED WITH MORE FIGHTING
-> MERAB SHOULD HAVE BEEN GIVEN TO DAVID / GIVEN TO ADRIEL
-> SAUL: DON'T LET MY HAND BE ON HIM / RETAINED TWO PERSONAL SPEAR THROWS
-> MICHAL LOVES DAVID / SAUL PLANS SNARE AND PHILISTINE DEATH
-> SECRET MESSAGE: KING DELIGHTS IN YOU
-> REQUIRE 100 PHILISTINES
-> DAVID RETURNS BEFORE DEADLINE WITH 200
-> MARRIES MICHAL / SAUL FEARS MORE / DAVID HIGHLY ESTEEMED
```

## Verses 1–9 — COVENANT / SUCCESS / PRAISE / WATCH

Jonathan's soul is knit with David's; he loves David as himself, makes a covenant, and gives robe, clothing, sword, bow and sash. Saul keeps David from returning to his father's house. David succeeds wherever sent, is set over the men of war and is accepted by people and servants. Returning women sing: **“SAUL HAS SLAIN HIS THOUSANDS, DAVID HIS TEN THOUSANDS.”** Saul becomes angry, states the credited-number difference, asks what remains except the kingdom, and watches David onward. No private State is added beyond source speech/narration.

## Verses 10–16 — PIN HIM / TWO ESCAPES

The narrator says an evil spirit from God comes mightily on Saul. David plays as usual. Saul holds and throws a spear, saying **“I WILL PIN DAVID TO THE WALL.”** David escapes twice.

`S191: I WILL PIN HIM TO THE WALL. HE ESCAPED TWICE.` closes after both failed results. No SKIP. Captain pokes, licks his finger, says **“YOINK!”**, walks away and changes nothing.

Saul fears David, removes him from his presence, makes him captain over a thousand, and David succeeds before the people. Israel and Judah love him. Divine/spirit mechanisms remain unresolved.

## Verses 17–19 — DAUGHTER REWARD / MORE CONDITION / OTHER HUSBAND

The chapter-17 report says the king's daughter goes to the Goliath killer. David killed Goliath. Saul offers Merab while adding **“ONLY BE VALIANT FOR ME, AND FIGHT THE LORD'S BATTLES.”** When Merab **should have been given to David**, she is instead given to Adriel as wife. The earlier reward remains reported speech; verse 19 supplies the obligation State.

`S190: KILL GOLIATH, GET THE DAUGHTER. KILLED HIM. FIGHT MORE. SHE MARRIED SOMEONE ELSE.` closes at the Adriel marriage. No SKIP. One causally-null **“YOINK!”**.

The narrator also supplies Saul's plan: **“DON'T LET MY HAND BE ON HIM, BUT LET THE HAND OF THE PHILISTINES BE ON HIM.”** The retained prior acts show Saul's hand throwing the spear twice.

`S192: DON'T LET MY HAND BE ON HIM. I THREW THE SPEAR TWICE.` closes there. No timing repair or added motive. No SKIP. One causally-null **“YOINK!”**.

## Verses 20–25 — SECRET DELIGHT / SECRET DEATH PLAN

Michal loves David. Saul is told and is pleased. The narrator supplies Saul's plan to use her as a snare so the Philistine hand may be against David. Saul orders servants secretly to say: **“THE KING DELIGHTS IN YOU ... BE THE KING'S SON-IN-LAW.”** They deliver it. David says he is poor and little known. Saul requires no money, but one hundred Philistine foreskins; narration again supplies Saul's thought that David fall by Philistine hands.

`S193: TELL HIM THE KING DELIGHTS IN HIM. THE KING IS TRYING TO GET HIM KILLED.` closes when the delivered message and retained plan occupy the same process. David's knowledge is not inferred. No SKIP. One causally-null **“YOINK!”**.

## Verses 26–30 — REQUIRE 100 / RETURN 200

David accepts the condition. Before the deadline David and his men kill two hundred Philistines and bring the full count. Depict only a sealed **CRACKHEAD DOWRY: 200 / REQUIRED: 100** carrier. Saul gives Michal to David. Saul sees/knows LORD is with David, becomes more afraid and remains his enemy; David continues exceeding Saul's servants and becomes highly esteemed.

`S194: SEND HIM TO DIE FOR 100. HE RETURNS WITH 200 AND MARRIES THE DAUGHTER.` closes at the doubled return and marriage. It records plan versus outcome without asserting exclusive cause. No SKIP. One causally-null **“YOINK!”**.

## Character and world-ledger changes

- NOT-DAVID: covenant/gifts, success, two escapes, captaincy, Merab obligation, 200 return, Michal marriage, increased esteem.
- NOT-SAUL: praise response/watch, two spear throws, removal/promotion, Merab offer/non-delivery, source-supplied hand/snare/death plans, secret delight instruction, condition, increased fear/enemy State.
- NOT-JONATHAN: covenant/love/gifts. NOT-MERAB: should-have-been-given and Adriel-wife States. NOT-MICHAL: stated love and David-wife State. NOT-ADRIEL/servants/women/forces: supplied acts only.

## Bullshit pass

Issue `1SA-018 / EXECUTIVE TALENT RETENTION`. The reward portal adds requirements after delivery, routes the daughter to another vendor, tells the candidate management delights in him, and sends him to the **CRACKHEAD DOWRY DEPARTMENT** to die. He returns with 200% KPI completion. Foundation unchanged.

## FIR verification

- FILTER: all 30 markers retained; 1 Samuel 19 excluded.
- ISOLATE: covenant, praise, spear/escapes, promotion, daughter non-delivery, hand statement, secret delight/death plan, doubled return.
- RECONSTRUCT: five premiere episodes.
- VERIFY: zero SKIPs; five YOINKs; reported speech, narrator private States, consent/mechanism gaps preserved; publication held.

## Required comic states

1. Jonathan covenant/gifts.
2. David service/success.
3. Women's song; Saul anger/watch.
4. Spear/two escapes; S191/YOINK.
5. Removal/promotion/public love.
6. Reward/Goliath kill; Merab added condition.
7. Merab should-have-been-given/Adriel marriage; S190/YOINK.
8. Not-my-hand/two spear throws; S192/YOINK.
9. Michal love/snare plan.
10. Secret delight message beside death plan/100 condition; S193/YOINK.
11. Sealed 200/100 carrier and return.
12. Marriage/increased fear/enemy/esteem; S194/YOINK.
13. Held lineage page; chapter 19 excluded.

## Production boundary

`NOT-` display; living things Joe-faced; no divine/spirit form. Non-graphic spear/battle treatment; never visualize foreskins. Five premiere episodes, zero SKIPs, five separate boilless causally-null Captain poke/lick/**“YOINK!”**/walk-away appearances. No motive, consent, diagnosis, divine mechanism or exclusive causation invented. Publication held.

*shrug*

OK.
