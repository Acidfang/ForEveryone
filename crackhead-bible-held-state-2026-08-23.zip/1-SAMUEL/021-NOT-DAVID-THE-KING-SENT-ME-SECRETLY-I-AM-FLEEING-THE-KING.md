# CRACKHEAD 1 SAMUEL 21

## Title page

**NOT-DAVID: THE KING SENT ME SECRETLY. I AM FLEEING THE KING.**

Source parent: 1 Samuel chapter 21, verses 1–15, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-021/job.json` and `source.usfm`. Parent: 1 Samuel 20. Exact identities remain in evidence; comic display uses `NOT-` identities. Every living thing is Joe-faced. Divine form remains unrendered. All fear, weapons, food and acted-insanity imagery stays non-graphic.

CrackFlix: premiere `S199-E001-1SA21`, mental `S138-E006-1SA21`, premiere `S200-E001-1SA21`. One exact SKIP. Exactly three causally-null post-closure YOINKs.

## Causal foundation

```text
DAVID DEPARTS JONATHAN / FUGITIVE FROM SAUL
-> ARRIVES ALONE AT NOB / AHIMELECH TREMBLES
-> DAVID: KING COMMANDED SECRET BUSINESS / YOUNG MEN SENT ELSEWHERE
-> REQUESTS FIVE LOAVES OR AVAILABLE FOOD
-> PRIEST: ONLY HOLY BREAD / CONDITION ABOUT YOUNG MEN
-> DAVID ASSERTS THREE-DAY ABSTENTION/HOLINESS
-> PRIEST GIVES REPLACED SHOWBREAD
-> DOEG PRESENT / DETAINED BEFORE LORD
-> DAVID: NO WEAPON BECAUSE KING'S BUSINESS REQUIRED HASTE
-> RECEIVES GOLIATH'S WRAPPED SWORD
-> DAVID FLEES THAT DAY FOR FEAR OF SAUL
-> GOES TO ACHISH OF GATH
-> SERVANTS IDENTIFY DAVID / CALL HIM KING / REPEAT PRAISE SONG
-> DAVID VERY AFRAID
-> DELIBERATELY PRETENDS INSANITY / SCRIBBLES / DROOLS
-> ACHISH: YOU SEE THE MAN IS INSANE
-> ACHISH: WHY BRING THIS FELLOW TO PLAY THE MADMAN?
```

## Verses 1–3 — ALONE / SECRET KING BUSINESS

David arrives at Nob to Ahimelech. The priest meets him trembling and asks why he is alone. David says the king commanded him to do something, ordered secrecy about the business and commands, and that David sent young men to a certain place. He asks for five loaves or whatever is available.

The retained parent has David depart after Saul's explicit surely-die declaration and Jonathan's beyond-arrow danger signal. Verse 10 of this chapter says David flees for fear of Saul. No king-sent mission is supplied.

New `S199: THE KING SENT ME SECRETLY. I AM FLEEING THE KING.` `S199-E001-1SA21` closes when the stated urgent royal mission is held against the retained flight-from-Saul route. The absent young men remain a claim without a contrary observation beyond David arriving alone; they are not separately converted into crack. No SKIP. One causally-null **“YOINK!”**.

## Verses 4–7 — HOLY BREAD / ASSERTED QUALIFICATION / DOEG PRESENT

Ahimelech has no common bread, only holy bread, conditional on the young men having kept from women. David asserts three days of usual abstention, holy vessels at departure, a common journey and greater present holiness. The source does not independently observe those young men, vessels or abstention, but absence of verification is not proof of falsity.

The priest gives David holy showbread removed from before LORD and replaced with hot bread that day. Doeg the Edomite, Saul's servant and best herdsman, is present, detained before LORD. The detention reason and what Doeg observes are unresolved here.

## Verses 8–10 — KING'S HASTE / GOLIATH'S SWORD / FEAR OF SAUL

David asks for spear or sword and says he brought no weapons because the king's business required haste. This continues the same S199 cover interaction rather than spawning a duplicate episode.

Ahimelech identifies Goliath's sword, says David killed Goliath in Elah, and offers the cloth-wrapped sword from behind the ephod. David says none is like it and takes it. The statement does not replay or repair chapter 17's two-kill grammar.

David arises and flees that day **for fear of Saul**, going to Achish king of Gath. This supplies the chapter's explicit observed route boundary for S199.

## Verses 11–12 — IDENTIFIED AT GATH

Achish's servants ask whether this is David, call him **“THE KING OF THE LAND,”** and repeat the women’s Saul-thousands/David-ten-thousands song. Saul remains the retained reigning king while David is anointed and fugitive, but the servants' rhetorical title is not upgraded into an installed office claim.

David lays the words in his heart and becomes very afraid of Achish. These internal States are narrator-supplied and require no invented motive beyond the heard identification.

## Verses 13–15 — PRETENDS INSANE / IS INSANE / PLAYS MADMAN

David changes his behavior and **pretends to be insane** in their hands, scribbles on gate doors and lets spittle fall on his beard.

Achish says to servants: **“LOOK, YOU SEE THE MAN IS INSANE.”** The narrator has already supplied that the observed behavior is deliberate pretending. This joins mental-model series `S138`. `S138-E006-1SA21` displays **SKIP -> S138-E005-1SA20**. Captain's eyes bulge at **“MENTAL CRACK?!”**, then poke, lick, **“YOINK!”**, walk-away. He changes nothing.

Achish immediately asks why they brought the man, whether he lacks madmen, and why they brought **“THIS FELLOW TO PLAY THE MADMAN”** in his presence. The same speaker's supplied descriptions shift from the man **is insane** to the fellow **plays** the madman, with no transition between actual and performed State.

New `S200: THE MAN IS INSANE. THIS FELLOW IS PLAYING THE MADMAN.` `S200-E001-1SA21` closes at “play the madman.” No SKIP. One causally-null **“YOINK!”**. Whether Achish recognized the performance, changed his conclusion, or used equivalent idiom remains unresolved.

## Character and world-ledger changes

- NOT-DAVID gains Nob arrival, royal-business cover account, bread/weapon requests, holy-bread receipt, Goliath-sword possession, Saul-fear flight, Gath identification/fear and deliberate acted-insanity performance.
- NOT-AHIMELECH gains trembling meeting, bread condition, showbread transfer and sword transfer without knowledge beyond David's supplied account.
- NOT-DOEG gains observed presence/detention and Saul-herdsman role; later use remains future.
- NOT-ACHISH gains servant identification report, insane-model assertion and play-madman description.
- NOT-SERVANTS gain David/title/song identification speech only.

## Bullshit pass

Issue `1SA-021 / SECRET ROYAL MISSION WITH NO ROYAL MISSION`. NOT-DAVID submits a **KING'S BUSINESS—DO NOT ASK** meal-and-weapons expense claim while fleeing the king. The only sword in stock is the boss weapon from his previous episode. At Gath he enables **CRACKHEAD COMPATIBILITY MODE: SCRIBBLE + DROOL**. NOT-ACHISH's classifier returns **INSANE / PLAYING INSANE** in adjacent fields. Foundation unchanged.

## FIR verification

- FILTER: all 15 markers retained; 1 Samuel 22 excluded.
- ISOLATE: royal-mission cover, bread condition/transfer, weapon account/sword, fear-flight, identification, deliberate performance and Achish's two descriptions.
- RECONSTRUCT: three closed episodes; one mental repeated and two premieres.
- VERIFY: one exact SKIP, three YOINKs; young men, holiness, title, Doeg detention and Achish interpretation remain bounded; publication held.

## Required comic states

1. David alone at Nob / Ahimelech trembling.
2. Secret royal mission account / young men elsewhere / bread request.
3. Retained chapter-20 flight plus verse-10 fear-of-Saul route; S199/YOINK.
4. Holy-bread condition / David qualification / bread transfer.
5. Doeg present/detained.
6. No weapon because royal haste / Goliath sword transfer.
7. David flees to Gath for fear of Saul.
8. Achish servants identify David/call king/repeat song.
9. David fear / deliberate scribble-drool performance.
10. Achish “man is insane”; S138-E006 SKIP/mental YOINK.
11. Achish “play the madman”; S200/YOINK.
12. Held lineage page; chapter 22 excluded.

## Production boundary

`NOT-` display; every living thing Joe-faced; no divine form. Restrained weapon/fear imagery; drool remains comic but non-degrading beyond source act. Three episodes, one exact SKIP, three separate boilless causally-null Captain poke/lick/**“YOINK!”**/walk-away appearances. Preserve assertions as assertions and do not invent young men, abstention evidence, installed kingship, Doeg motive or Achish mental transition. Publication held.

*shrug*

OK.
