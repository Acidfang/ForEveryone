# CRACKHEAD 1 SAMUEL 20

## Title page

**NOT-JONATHAN: IT IS NOT SO. NOT-SAUL: HE SHALL SURELY DIE.**

Source parent: 1 Samuel chapter 20, verses 1–42, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-020/job.json` and `source.usfm`. Parent: 1 Samuel 19. Exact identities remain in evidence; comic display uses `NOT-` identities. Every living thing is Joe-faced. Divine form remains unrendered. Violence remains restrained and non-graphic.

CrackFlix: mental `S138-E004-1SA20` and `S138-E005-1SA20`; premiere `S198-E001-1SA20`; repeated death-oath `S195-E004-1SA20`. Three exact SKIPs. Exactly four causally-null post-closure YOINKs.

## Causal foundation

```text
DAVID: SAUL SEEKS MY LIFE
-> JONATHAN: YOU WILL NOT DIE / FATHER DISCLOSES EVERYTHING / IT IS NOT SO
-> DAVID: FATHER HIDES THIS FROM YOU / ONE STEP FROM DEATH
-> NEW-MOON ABSENCE TEST PLANNED
-> COVER STORY: DAVID WENT TO BETHLEHEM FAMILY SACRIFICE
-> RESPONSE SELECTOR: WELL = PEACE / ANGER = EVIL DETERMINED
-> COVENANT + DISCLOSURE + ARROW SIGNAL PLAN
-> DAVID HIDES IN FIELD
-> FIRST EMPTY SEAT / SAUL: SURELY DAVID IS UNCLEAN
-> SECOND EMPTY SEAT / JONATHAN DELIVERS BETHLEHEM COVER STORY
-> SAUL ANGRY / SAYS DAVID SHALL SURELY DIE
-> JONATHAN ASKS WHAT DAVID DID
-> SAUL THROWS SPEAR AT JONATHAN
-> JONATHAN KNOWS DEATH DETERMINED / LEAVES ANGRY / DOES NOT EAT
-> BEYOND-ARROW SIGNAL EXECUTED
-> BOY REMAINS UNAWARE / WEAPONS SENT CITY
-> DAVID EMERGES / BOWS / KISS / WEEP / COVENANT FAREWELL
```

## Verses 1–4 — IT IS NOT SO / LATER DIRECT DEATH STATE

David flees Naioth and asks Jonathan what he has done and why Saul seeks his life. Jonathan replies: **“FAR FROM IT; YOU WILL NOT DIE.”** He states Saul does nothing great or small without disclosing it to him, asks why Saul would hide this, and concludes **“IT IS NOT SO.”**

David swears that Saul knows David has Jonathan's favor, supplies a model in which Saul hides the plan to avoid Jonathan's grief, and says only one step separates him from death. Jonathan agrees to do what David requests. David's model remains his speech until the later test supplies observable State.

At verses 30–33 Saul directly says David shall surely die and throws a spear at Jonathan when challenged. Jonathan then knows Saul is determined to put David to death.

This closes Jonathan's unsupported no-death/not-so model as mental crack. `S138-E004-1SA20` displays **SKIP -> S138-E003-1SA16**: an asserted model is closed by contrary supplied State. Captain's eyes bulge at **“MENTAL CRACK?!”**, then poke, lick, **“YOINK!”**, walk-away. He changes nothing.

## Verses 5–17 — ABSENCE TEST / COVER STORY / COVENANT

David notes the new-moon meal obligation and asks to hide in the field through the third evening. He instructs Jonathan to say David earnestly requested leave to run to Bethlehem for a yearly family sacrifice. The response selector is explicit: Saul saying **“IT IS WELL”** means peace; anger means evil is determined.

David invokes their LORD covenant and says Jonathan should kill him himself if iniquity exists rather than bring him to Saul. Jonathan rejects that route and promises disclosure if he learns evil is determined.

In the field Jonathan invokes LORD/God, promises to sound out Saul and disclose good or evil, send David away in peace if necessary, and asks continuing kindness for himself and his house. He makes covenant with David's house and causes David to swear again. All future house/enemy/cut-off relations remain prospective.

## Verses 18–23 — THREE-ARROW CODE

Jonathan specifies the empty seat, three-day hiding place by Ezel, three-arrow mark performance and boy-mediated code:

- arrows on this side / take them -> come, peace/no danger;
- arrows beyond -> go, LORD has sent you away.

LORD-between-us-forever remains covenant speech. The later execution visibly uses the beyond signal. Source grammar says Jonathan shoots **an arrow** beyond the boy and later the boy gathers **arrows**; it does not prove only one total shot or a failed three-arrow plan, so no crack is invented.

## Verses 24–29 — HIDING IN FIELD / SURELY UNCLEAN / BETHLEHEM REPORT

David hides in the field. At the new-moon meal his seat is empty. Saul says nothing the first day because he thinks something happened and repeats: **“HE IS NOT CLEAN. SURELY HE IS NOT CLEAN.”** The retained observed cause of absence is David's field hiding; no impurity event is supplied.

This mental model joins `S138`. `S138-E005-1SA20` displays **SKIP -> S138-E004-1SA20**. SKIP changes nothing. One mental-crack **“YOINK!”** changes nothing.

On the second day Saul asks why David has not eaten yesterday or today. Jonathan delivers the planned Bethlehem account, including family sacrifice and a brother's command. David did ask Jonathan to **say** this, but the observed execution has David hidden in the field rather than traveling to Bethlehem.

New `S198: HE WENT TO BETHLEHEM. HE IS HIDING IN THE FIELD.` `S198-E001-1SA20` closes when Jonathan delivers the cover story against the retained hiding State. No motive beyond the explicit test plan is inferred. No SKIP. One causally-null **“YOINK!”**.

## Verses 30–34 — DAVID SHALL SURELY DIE / PRIOR DEATH OATH

Saul's anger burns. He insults Jonathan and his mother, states Jonathan chose David to shame, predicts Jonathan's kingdom cannot be established while David lives, and orders David brought because **“HE SHALL SURELY DIE.”** Jonathan asks what David did. Saul throws his spear at Jonathan to strike him. Jonathan thereby knows the death determination, leaves in fierce anger, eats no food and grieves because Saul treated David shamefully.

The retained chapter-19 parent has Saul swear **“AS THE LORD LIVES, HE SHALL NOT BE PUT TO DEATH.”** The new explicit surely-die statement repeats series `S195`. `S195-E004-1SA20` displays **SKIP -> S195-E003-1SA19**. SKIP does not alter Saul's speech or Jonathan's response. One causally-null **“YOINK!”**.

Saul's shame/kingdom predictions and Jonathan's inner knowledge/grief are retained only where narration supplies them. The spear response does not answer Jonathan's question, but absence of an answer is not itself contradiction.

## Verses 35–42 — BEYOND SIGNAL / FAREWELL

Jonathan arrives with a boy at the appointed time, tells him to find the arrows, shoots beyond him, calls **“ISN'T THE ARROW BEYOND YOU?”**, urges speed, receives the gathered arrows, then sends the boy and weapons to the city. The boy does not know the matter; only Jonathan and David know.

David emerges from the south, bows three times, and they kiss and weep, David most. Jonathan tells him to go in peace because of their mutual LORD-name oath and the continuing offspring covenant. David departs; Jonathan returns to the city. “Go in peace” remains covenant farewell rather than a claim that no danger exists.

## Character and world-ledger changes

- NOT-DAVID gains Naioth departure, accusation/questions, near-death claim, absence-test design, field hiding, signal reception, covenant renewal and departure.
- NOT-JONATHAN gains not-so/no-death model, test execution, Bethlehem cover report, Saul confrontation/spear target State, determined-death knowledge, grief, arrow signal and farewell.
- NOT-SAUL gains first-day impurity model, second-day inquiry, anger/insults, explicit surely-die order, Jonathan spear throw and retained contrast with the chapter-19 oath.
- NOT-BOY gains arrow retrieval and weapons transport while remaining unaware of the encoded matter.

## Bullshit pass

Issue `1SA-020 / CRACKHEAD ABSENCE API`. The royal dinner monitoring system classifies **EMPTY SEAT -> UNCLEAN**. The human diagnostic sends a fake **BETHLEHEM FAMILY SACRIFICE** ticket. Saul answers the yes/no health check by throwing a spear at the technician. Production uses the **THREE-ARROW ENCRYPTION STANDARD**, apparently documented with singular/plural ammunition support. Foundation unchanged.

## FIR verification

- FILTER: all 42 markers retained; 1 Samuel 21 excluded.
- ISOLATE: competing death models, absence test/cover story, covenant/arrow code, impurity model, direct death declaration and farewell.
- RECONSTRUCT: four closed episodes; two mental repeated, one premiere, one repeated death-oath episode.
- VERIFY: three exact SKIPs, four YOINKs; future covenant, private claims, arrow count and divine relations remain bounded; publication held.

## Required comic states

1. David accusation / Jonathan not-so model.
2. David hidden-plan/one-step claim and test request.
3. Bethlehem cover story and response selector.
4. Field covenant/disclosure promises.
5. Arrow-code instructions.
6. David hides / first empty seat / Saul surely-unclean model; S138-E005 SKIP/YOINK.
7. Second empty seat / Jonathan Bethlehem report / field-hiding parent; S198/YOINK.
8. Saul anger/insults/surely-die statement.
9. Prior chapter-19 no-death oath; S195-E004 SKIP/YOINK.
10. Jonathan asks what David did / Saul spear / Jonathan knows; S138-E004 SKIP/YOINK positioned at contrary-State closure.
11. Beyond-arrow execution; boy unaware/weapons sent.
12. David emerges/bows; kiss/weeping/covenant farewell.
13. Held lineage page; chapter 21 excluded.

## Production boundary

`NOT-` display; every living thing Joe-faced; no divine form. Restrained/non-graphic spear imagery. Four episodes, three exact SKIPs, four separate boilless causally-null Captain poke/lick/**“YOINK!”**/walk-away appearances. Do not convert covenant predictions, Saul's shame claims, David's model, arrow ambiguity or “go in peace” into extra facts. Publication held.

*shrug*

OK.
