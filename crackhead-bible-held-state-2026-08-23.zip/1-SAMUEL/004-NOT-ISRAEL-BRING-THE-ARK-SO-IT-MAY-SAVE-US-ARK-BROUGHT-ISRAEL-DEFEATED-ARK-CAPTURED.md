# CRACKHEAD 1 SAMUEL 4

## Title page

**NOT-ISRAEL: “BRING THE ARK SO IT MAY SAVE US.” ARK BROUGHT. NOT-ISRAEL DEFEATED. ARK CAPTURED.**

Source parent: 1 Samuel chapter 4, verses 1–22, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-004/job.json` and `source.usfm`. Parent: 1 Samuel 3.

Display-origin layer: exact source identities remain in evidence. Comic display uses `NOT-` identities and places. Every living human is Joe-faced. The ark and cherubim may carry Joe faces as face-like objects without becoming living agents. NOT-THE-LORD / NOT-GOD remains unrendered.

CrackFlix routing: new failed-protective-object prediction `S175-E001-1SA4` has no SKIP. Exactly one causally-null post-closure YOINK.

## Causal foundation

```text
SAMUEL WORD REACHES ALL ISRAEL
-> ISRAEL/PHILISTINES ENCAMP + FIGHT
-> ISRAEL DEFEATED / ABOUT 4000 KILLED
-> ELDERS ASK WHY LORD DEFEATED THEM
-> ELDERS PROPOSE BRING ARK SO IT MAY SAVE THEM
-> PEOPLE FETCH ARK / HOPHNI + PHINEHAS WITH IT
-> ARK ENTERS CAMP / ISRAEL SHOUTS / EARTH RESOUNDS
-> PHILISTINES HEAR / IDENTIFY ARK / FEAR / DIVINE MODEL
-> PHILISTINES EXHORT STRENGTH / FIGHT
-> ISRAEL DEFEATED / 30000 FALL / MEN FLEE
-> ARK CAPTURED / HOPHNI + PHINEHAS SLAIN
-> BENJAMIN MESSENGER RUNS TO SHILOH
-> CITY HEARS / CRIES
-> BLIND 98-YEAR-OLD ELI RECEIVES REPORT
-> ARK MENTION / ELI FALLS / NECK BREAKS / DIES
-> PHINEHAS WIFE HEARS ARK + HUSBAND + FATHER-IN-LAW NEWS
-> BIRTH PAINS / SON BORN / SHE DIES
-> SHE NAMES ICHABOD / SAYS GLORY DEPARTED BECAUSE ARK TAKEN
```

## 1 Samuel 4:1–2 — FIRST DEFEAT

Samuel's word comes to all Israel. Israel goes to battle against the Philistines, camping by Ebenezer while the Philistines camp at Aphek.

The Philistines array themselves and defeat Israel. About four thousand Israelite army men are killed in the field. Keep battle and death non-graphic; the exact total, identities and body dispositions remain unresolved.

## 1 Samuel 4:3–5 — MAKE THE ARK SAVE US

Back at camp, Israel's elders ask:

**“WHY HAS THE LORD DEFEATED US TODAY BEFORE THE PHILISTINES?”**

That is their attribution. No LORD speech or narrated divine battle act occurs here.

They propose fetching LORD's covenant ark from Shiloh:

**“BRING IT TO US, THAT IT MAY COME AMONG US AND SAVE US OUT OF THE HAND OF OUR ENEMIES.”**

The people send for the ark. It is described as the ark of LORD of Armies who sits above the cherubim. Hophni and Phinehas accompany it. This description does not supply a visible divine body.

When the ark enters camp, all Israel shouts so greatly the earth resounds. The ark's arrival, crowd reaction and prediction are observable; salvation is still future.

## 1 Samuel 4:6–9 — PHILISTINE MODEL / FIGHT ANYWAY

The Philistines hear the shout, ask its meaning and understand LORD's ark has entered the Hebrew camp. They fear and say **“GOD HAS COME INTO THE CAMP.”** They say this has not happened before and ask who will deliver them from these mighty gods, whom they describe as striking Egypt with wilderness plagues.

These are Philistine statements and their plural-gods historical model. No divine arrival, multiplicity, visual form or new plague is narrated.

They exhort one another to be strong and fight so they do not serve the Hebrews as the Hebrews served them. The earlier service history, duration and exact actors are not supplied in this chapter.

## 1 Samuel 4:10–11 — THE ARK DOES NOT SAVE THE ARK

The Philistines fight. Israel is defeated again; each man flees to his tent. Thirty thousand Israelite footmen fall. God's ark is taken. Hophni and Phinehas are slain.

The elders' stated dependency was:

**ARK COMES AMONG US → ARK SAVES US FROM ENEMY HAND.**

The observed completed State is:

**ARK COMES → ISRAEL LOSES 30,000 → ARK ITSELF ENTERS ENEMY HAND.**

New CrackFlix series:

**S175: BRING THE PROTECTIVE OBJECT. NOW PROTECT THE OBJECT.**

The ark remains an object carrier; no motive or failed will is assigned to it. The contradiction belongs to the elders' prediction against the resulting battle State. After the ark's capture completes `S175-E001-1SA4`, Captain pokes the failed-protection boil, licks his finger, says **“YOINK!”**, and walks away. The battle outcome remains unchanged.

Hophni and Phinehas dying on the same day closes the sign announced in 1 Samuel 2. It is fulfillment lineage, not a new contradiction. The mechanism joining prediction to deaths remains source-attributed, not independently derived.

## 1 Samuel 4:12–18 — THE REPORT KILLS ELI AFTER THE ARK LINE

A Benjamin man runs from the army to Shiloh the same day with torn clothes and dirt on his head. Eli sits by the road watching, his heart trembling for God's ark. The messenger tells the city; the city cries out.

Eli hears the tumult and asks its meaning. The messenger identifies himself as the same-day army fugitive. Eli, ninety-eight, blind and unable to see, asks what happened.

The messenger reports in order: Israel fled, great slaughter occurred, Hophni and Phinehas are dead, and God's ark was captured.

When the messenger mentions the ark, Eli falls backward from his seat by the gate. His neck breaks and he dies. Narration identifies him as old and heavy and says he judged Israel forty years.

The ark mention immediately precedes the fall, but no private thought, shock physiology or divine push is supplied. Retain sequence without inventing mechanism. Eli's death plus his sons' deaths advances the earlier house-judgment lineage; it does not finish every future house claim.

## 1 Samuel 4:19–22 — BIRTH / DEATH / ICHABOD

Phinehas's pregnant wife is near birth. She hears the ark was taken and her husband and father-in-law died. She bows and gives birth when pains come upon her.

Near her death, attending women tell her not to fear because she has borne a son. She does not answer or regard it.

She names the child Ichabod, meaning no glory, and says:

**“THE GLORY HAS DEPARTED FROM ISRAEL.”**

The source explains her statement by the ark's capture and deaths; she repeats that glory departed because the ark was taken. This is her named interpretation. “Glory” is not separately observed, measured or opposed by another retained State here, so no mental crack is manufactured.

The son is alive at the naming Moment unless later source changes that State. The mother's personal name, attendants' identities, exact death mechanism, custody and future remain unresolved. 1 Samuel 5 is excluded.

## Character and world-ledger changes

- NOT-ISRAEL JOES gain two defeats, 4,000/30,000 reported losses, ark-salvation plan, great shout and final flight.
- NOT-PHILISTINE JOES gain ark/noise interpretation, fear speech, strength exhortation, victory and ark capture.
- NOT-HOPHNI and NOT-PHINEHAS change from predicted-alive to slain same-day, closing the prior sign.
- NOT-ELI gains ninety-eight/forty-year State, ark-focused waiting, full report reception, fall, broken neck and death.
- NOT-BENJAMIN-MESSENGER JOE gains battle flight, Shiloh report and Eli report sequence.
- NOT-PHINEHAS-WIFE JOE gains report-triggered birth sequence, Ichabod naming/glory statement and death.
- NOT-ICHABOD JOE gains birth and name only.
- `S175-E001-1SA4` retains the completed failed-protection prediction.

## Bullshit pass

Issue `1SA-004 / PORTABLE SALVATION DEVICE`. NOT-ISRAEL installs the ark in the battle slot and receives **DEVICE CAPTURED BY OPPONENT**. The incident report reaches NOT-ELI only after reading every prior failure line aloud. Foundation unchanged.

## FIR verification

- FILTER: 1 Samuel 4 only; all 22 markers retained in order; 1 Samuel 5 excluded.
- ISOLATE: first defeat, elders' ark prediction, ark transport/reactions, second defeat/capture, same-day son deaths, messenger/Eli death and Ichabod birth/naming.
- RECONSTRUCT: one new `S175`; predicted ark salvation completes as defeat and ark capture.
- VERIFY: exactly one crack, zero SKIPs and one YOINK; elders/Philistines/dying mother models remain attributed, divine form/action is not invented, prior sign fulfillment is joined, deaths remain non-graphic, publication held.

## Required comic states

1. Samuel word/all Israel; battle camps and first defeat/about 4,000.
2. Elders ask why LORD defeated them and propose ark salvation.
3. Ark fetched with Hophni/Phinehas; great Israel shout/earth resounds.
4. Philistines hear, identify ark, fear and state gods/Egypt model.
5. Philistine strength/fight exhortation.
6. Second battle: Israel defeat/flight/30,000, ark captured, sons slain; S175 and YOINK.
7. Benjamin messenger torn/dirt run; Eli roadside ark-focused wait; city cry.
8. Blind ninety-eight-year Eli requests report; messenger delivers ordered losses/sons/ark.
9. Ark mention, Eli fall/neck break/death; forty-year close, non-graphic.
10. Phinehas wife receives ark/husband/father-in-law news and gives birth, non-graphic.
11. Attendants announce son; mother unresponsive, names Ichabod and repeats glory departure.
12. Held lineage page: prior same-day-death sign fulfilled; ark future in 1 Samuel 5 excluded.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; exact source identities remain in evidence.
- Every living human is Joe-faced. The ark/cherubim may carry Joe faces only as face-like objects, never as living agents. NOT-THE-LORD / NOT-GOD remains unrendered.
- Keep battle, deaths, broken neck and childbirth non-graphic.
- The only crack is elders' ark-salvation prediction versus second defeat and ark capture. No SKIP. Exactly one boilless, causally-null Captain occurrence after capture completes: poke, lick, **“YOINK!”**, walk away, no look back.
- Do not convert elders' defeat attribution, Philistine God/gods model or Ichabod glory statement into verified divine facts or extra cracks.
- Preserve messenger report order and ark-mention/fall sequence without invented psychology/mechanism.
- Retain Hophni/Phinehas death as prior sign fulfillment, not a new prediction.
- Publication held. `CHB-1SA-005` excluded.

*shrug*

OK.

