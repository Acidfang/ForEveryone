# CRACKHEAD 1 SAMUEL 8

## Title page

**NOT-ELDERS: “YOUR JUDGES TAKE BRIBES.” ALSO NOT-ELDERS: “GIVE US THE KING YOU JUST SAID WILL TAKE EVERYTHING.”**

Source parent: 1 Samuel chapter 8, verses 1–22, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-008/job.json` and `source.usfm`. Parent: 1 Samuel 7.

Display-origin layer: exact names remain in evidence; comic display uses `NOT-` identities and places. Every living human, donkey, flock animal and plant is Joe-faced. Chariots, fields, instruments and other face-like objects may carry Joe faces without life. NOT-THE-LORD remains unrendered.

CrackFlix routing: new decision-contradiction series `S177`; `S177-E001-1SA8` has no SKIP. Exactly one causally-null post-closure YOINK.

## Causal foundation

```text
OLD SAMUEL APPOINTS JOEL + ABIJAH AS BEERSHEBA JUDGES
-> SONS PURSUE DISHONEST GAIN / TAKE BRIBES / PERVERT JUSTICE
-> ELDERS CITE SAMUEL AGE + SONS' WAYS
-> REQUEST KING TO JUDGE LIKE OTHER NATIONS
-> REQUEST DISPLEASES SAMUEL / SAMUEL PRAYS
-> LORD: LISTEN; THEY REJECT ME AS KING; WARN THEM OF KING'S WAY
-> SAMUEL DELIVERS LORD'S WORDS
-> FUTURE WARNING: KING WILL TAKE SONS/DAUGHTERS/FIELDS/PRODUCE/SERVANTS/DONKEYS/FLOCKS
-> FUTURE WARNING: PEOPLE BECOME HIS SERVANTS + CRY / LORD NOT ANSWER THAT DAY
-> PEOPLE REFUSE TO LISTEN
-> REPEAT DEMAND: KING TO JUDGE / LEAD / FIGHT LIKE NATIONS
-> SAMUEL REHEARSES WORDS TO LORD
-> LORD: LISTEN + MAKE KING
-> SAMUEL SENDS PEOPLE TO OWN CITIES
```

## 1 Samuel 8:1–5 — THE JUDGES ARE THE PROBLEM

When Samuel is old, he makes his sons judges over Israel. The firstborn is Joel, the second Abijah; they judge in Beersheba.

They do not walk in Samuel's ways. They turn after dishonest gain, take bribes and pervert justice.

Israel's elders gather at Ramah. They tell Samuel he is old and his sons do not walk in his ways. Their proposed replacement is:

**“MAKE US A KING TO JUDGE US LIKE ALL THE NATIONS.”**

The sons' recorded corruption and the elders' stated basis are observed. Individual bribe cases, victims, amounts, rulings and Samuel's knowledge before the meeting remain unresolved.

## 1 Samuel 8:6–10 — LISTEN / PROTEST / SHOW THEM

The request for a king to judge them displeases Samuel. This feeling is narrator-supplied, not inferred. Samuel prays.

LORD directly tells Samuel to listen to everything the people say. LORD says they have rejected him—not Samuel—as king over them, joining it to their works since Egypt, forsaking him and serving other gods. LORD again orders Samuel to listen, while solemnly protesting and showing them the way of the king who will reign.

Samuel tells all LORD's words to the people. NOT-THE-LORD remains unrendered; Samuel is the visible human carrier of the warning.

## 1 Samuel 8:11–18 — THE KING WILL TAKE

Samuel's delivered future list says the king will:

- take sons for chariots, horsemen and runners;
- appoint captains of thousands and fifties;
- assign plowing, harvesting and weapons/chariot-instrument making;
- take daughters as perfumers, cooks and bakers;
- take the best fields, vineyards and olive groves for servants;
- take a tenth of seed and vineyards for officers and servants;
- take male/female servants, best young men and donkeys for his work;
- take a tenth of flocks;
- make the people his servants.

Samuel says they will later cry because of the king they chose and LORD will not answer that day.

Every item remains warning speech. No king has been selected, no taking has occurred, nobody has entered those roles and no future cry has happened in this chapter.

## 1 Samuel 8:19–22 — WE HEARD THE TAKE LIST. KING PLEASE.

The people refuse to listen to Samuel. They say no: they will have a king so they may be like all nations, be judged by the king, have him go before them and fight their battles.

Their starting complaint was an appointed judging process corrupted by dishonest gain, bribes and perverted justice. The explicitly disclosed replacement process centers on one ruler taking their children, labor, best property, produce, servants, animals and making them his servants. After the disclosure, they knowingly retain the replacement demand.

The completed decision contradiction is:

**OUR JUDGES MISUSE OFFICE FOR GAIN → REPLACE THEM WITH THE WARNED OFFICE THAT WILL TAKE ACROSS THE WHOLE COMMUNITY → WE STILL WANT IT.**

New CrackFlix series:

**S177: OUR JUDGES TAKE BRIBES. GIVE US A KING WHO WILL TAKE EVERYTHING.**

When the people refuse the warning and repeat the demand, `S177-E001-1SA8` completes. Captain pokes the decision boil, licks his finger, says **“YOINK!”**, and walks away without looking back. Their decision remains unchanged.

Samuel hears all their words and rehearses them to LORD. LORD says to listen and make them a king. Samuel tells Israel's men to return to their own cities. The actual king identity, selection, appointment and warned future acts remain outside this chapter.

## Character and world-ledger changes

- NOT-SAMUEL JOE becomes old, appoints sons, receives elders, prays, carries two LORD replies and dismisses the assembly.
- NOT-JOEL and NOT-ABIJAH JOES become Beersheba judges who pursue gain, take bribes and pervert justice.
- NOT-ISRAEL-ELDER JOES cite the judging failure, request a king, hear the taking warning, refuse it and repeat the king demand.
- NOT-THE-LORD directly supplies rejection history, listen/protest instructions and final make-a-king instruction without visible form.
- `S177-E001-1SA8` retains one completed decision contradiction; all warned king acts stay future.

## Bullshit pass

Issue `1SA-008 / CENTRALIZED BRIBE SOLUTION`. The elders reject distributed corruption and request **ENTERPRISE TAKE™**, a single platform that integrates children, land, crops, animals and labor into one convenient extraction dashboard. Foundation unchanged.

## FIR verification

- FILTER: 1 Samuel 8 only; all 22 markers retained in order; 1 Samuel 9 excluded.
- ISOLATE: Samuel's appointment, sons' corruption, elders' complaint/request, direct LORD replies, complete warning list, refusal/repeated demand and dismissal.
- RECONSTRUCT: one decision contradiction completes when the people hear the relevant replacement process and still select it; warned acts remain unexecuted.
- VERIFY: one new series/episode, zero SKIPs and one YOINK; divine form absent; no future king or acts imported; publication held.

## Required comic states

1. Old Samuel appoints Joel/Abijah as Beersheba judges.
2. Sons pursue gain, accept bribes and pervert justice, without invented cases.
3. Elders gather at Ramah and cite Samuel's age/sons' ways.
4. Elders request king to judge like nations.
5. Samuel displeased/prays; LORD first direct reply unrendered.
6. Samuel carries listen/protest/show-king's-way instruction.
7. Warning: sons/chariots/horsemen/runners/captains/agricultural and war work.
8. Warning: daughters/perfumers/cooks/bakers.
9. Warning: best fields/vineyards/olive groves and tenths.
10. Warning: servants/young men/donkeys/flocks; people become servants.
11. Future cry/no-answer warning clearly shown as speech, not event.
12. People refuse and repeat king/judge/lead/fight demand; S177 and one causally-null YOINK.
13. Samuel rehearses words; LORD says listen/make king, unrendered.
14. Samuel sends everyone home; actual king remains excluded.
15. Held lineage page: 1 Samuel 9 excluded.

## Production boundary

- All displayed biblical identities/places use `NOT-`; exact source names stay in evidence.
- All living humans, donkeys, flock animals and plants are Joe-faced. Object faces do not establish life. LORD remains unrendered.
- Do not instantiate any warning item as a completed act; render it as Samuel's disclosed future process/visualized speech only.
- Preserve Samuel's narrator-supplied displeasure without inventing motive. Preserve LORD rejection/history claims as direct speech.
- Exactly one contradiction after people hear the warning and repeat the demand. No SKIP. Exactly one boilless, causally-null Captain: poke, lick, **“YOINK!”**, walk away, no look back.
- Do not invent bribery cases, elder motives, king identity, appointment, battles, future cry or divine body.
- Publication held. `CHB-1SA-009` excluded.

*shrug*

OK.
