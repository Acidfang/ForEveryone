# CRACKHEAD 1 SAMUEL 28

## Title field

**NOT-SAUL: I SENT THEM OUT. FIND ME ONE. I WILL NOT EAT. HE ATE.**

Source parent: 1 Samuel chapter 28, verses 1–25, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-028/job.json` and `source.usfm`. Parent: 1 Samuel 27. Exact identities remain in evidence; comic display uses `NOT-` identities. Every living thing is Joe-faced. The woman-observed figure is limited to the exact old-man/robe description; its mechanism remains unresolved. Food preparation and future death remain non-graphic.

CrackFlix: new `S203-E001-1SA28`; repeated `S186-E002-1SA28` with exact `SKIP -> S186-E001-1SA15`. Exactly two distinct causally-null post-closure YOINKs.

Production format: one high-resolution compound-eye field with all changed States simultaneous and causal traversal retained by facet addresses.

## Causal foundation

```text
PHILISTINES PREPARE WAR / ACHISH REQUIRES DAVID + MEN
-> DAVID: YOU WILL KNOW WHAT I CAN DO
-> ACHISH: BODYGUARD FOREVER
-> SAMUEL DEAD/BURIED / SAUL HAD EXPELLED SPIRIT-PRACTITIONERS
-> ARMIES CAMP / SAUL AFRAID
-> SAUL INQUIRES OF LORD / NO ANSWER BY DREAMS, URIM OR PROPHETS
-> SAUL ORDERS SERVANTS: FIND WOMAN WITH FAMILIAR SPIRIT
-> SERVANTS IDENTIFY WOMAN AT ENDOR
-> DISGUISED SAUL REQUESTS HER PROHIBITED SERVICE
-> WOMAN CITES SAUL'S EXPULSION/DEATH RISK
-> SAUL SWEARS NO PUNISHMENT / REQUESTS SAMUEL
-> WOMAN SEES SAMUEL / IDENTIFIES SAUL'S DECEPTION
-> WOMAN REPORTS GOD/OLD MAN/ROBE / SAUL PERCEIVES SAMUEL
-> SAMUEL-FIGURE QUESTIONS DISTURBANCE
-> SAUL REPORTS WAR / GOD NONANSWER / ASKS WHAT TO DO
-> SAMUEL-FIGURE ATTRIBUTES KINGDOM LOSS/AMALEK CAUSE
-> PREDICTS TOMORROW DEATH + PHILISTINE DELIVERY
-> SAUL FALLS / TERRIFIED / NO FOOD DAY OR NIGHT
-> WOMAN REQUESTS HE EAT
-> SAUL: I WILL NOT EAT
-> WOMAN + SERVANTS CONSTRAIN / SAUL LISTENS
-> WOMAN PREPARES CALF + BREAD / SAUL AND SERVANTS EAT
-> THEY LEAVE THAT NIGHT
```

## Verses 1–3 — WAR REQUIREMENT / BODYGUARD / PRIOR EXPULSION

Philistine armies gather to fight Israel. Achish tells David he and his men will enter the army. David says Achish will know what his servant can do. Achish says he will make David bodyguard forever. No battle or permanent appointment executes here.

Samuel is dead, mourned and buried at Ramah. Saul had sent familiar-spirit practitioners and wizards out of the land. This retained prior act supplies the boundary for the later request.

## Verses 4–7 — FEAR / NO ANSWER / FIND THE EXPELLED SERVICE

Philistines camp at Shunem; Saul gathers Israel at Gilboa. Saul sees the army, is afraid and his heart trembles greatly. He inquires of LORD; LORD does not answer through dreams, Urim or prophets.

Saul then orders servants to find a woman with a familiar spirit so he can inquire through her. They identify one at Endor. New `S203-E001-1SA28` closes when the authority who expelled the service requires and locates that service inside the land. The exact survival/return mechanism is absent. No SKIP. One separate post-closure YOINK changes nothing.

## Verses 8–14 — DISGUISE / RISK / OATH / WOMAN-OBSERVED FIGURE

Saul disguises himself, changes clothing and reaches the woman by night with two men. He asks her to consult and bring up whomever he names. She cites Saul's removal of practitioners and asks why he lays a death-snare for her. Saul swears by LORD that no punishment will happen to her for this act.

At Saul's request for Samuel, the woman sees Samuel, cries out and identifies the disguised requester as Saul. She reports seeing “a god” coming from earth, then an old man covered with a robe. Saul perceives it is Samuel and bows. The source gives the woman's visual report and Saul's perception; it does not give Saul independent sight, explain identity recognition, or define the apparition mechanism. If shown, the described old-man/robe form carries Joe identity as a source-observed face, not a new biological claim.

## Verses 15–19 — QUESTION / DISTRESS / ATTRIBUTED HISTORY / TOMORROW PREDICTION

The Samuel-identified speaker asks why Saul disturbed and brought him up. Saul reports severe distress, Philistine war, God's departure/nonanswer, and asks what to do.

The speaker says LORD departed and became adversary, performed the earlier kingdom-transfer word, and did this because Saul did not obey regarding Amalek. He predicts LORD will deliver Israel and its army to Philistines and that tomorrow Saul and his sons will be with him. These are speaker-attributed past relations and future outcomes; chapter 28 does not execute or verify tomorrow.

## Verses 20–25 — I WILL NOT EAT / HE EATS

Saul immediately falls full length, terrified by the words, with no strength after eating no bread all day and night. The woman says she risked her life and obeyed him, asks him to listen in return, and offers food for strength.

Saul refuses: **“I WILL NOT EAT.”** His servants and the woman constrain him; he listens, rises and sits on the bed. The woman kills a fattened calf, kneads flour and bakes unleavened bread. She brings the food; Saul and his servants eat.

This closes repeated `S186-E002-1SA28`: explicit refusal, repeated request/pressure, then the refused act. Exact **SKIP -> S186-E001-1SA15**. SKIP removes nothing. A second distinct post-closure YOINK changes nothing. They rise and leave that night.

## Character and world-ledger changes

- NOT-SAUL gains fear/nonanswer, prohibited-service search, disguise, no-punishment oath, reported consultation, terror/collapse, refused-then-performed eating and night departure.
- NOT-WOMAN-AT-ENDOR gains retained practitioner State, death-risk objection, consultation act, Saul recognition, visual report, food request/preparation and departure witness.
- NOT-SAMUEL remains dead while a source-identified speaking figure gains exact old-man/robe report, questions, attributions and tomorrow prediction; mechanism unresolved.
- NOT-ACHISH/NOT-DAVID gain unexecuted army/bodyguard speech; Saul's two servants gain search, attendance, constraint, meal and departure States.

## Bullshit pass

Issue `1SA-028 / DECOMMISSIONED VENDOR EMERGENCY PROCUREMENT`. NOT-SAUL removes the entire supplier category, receives no response from approved channels, then opens a priority ticket: **FIND ME ONE OF THE SUPPLIERS I REMOVED.** After the consultation predicts tomorrow's outage, he rejects catering and is escalated into eating the catering. **SKIP -> S186-E001-1SA15.** Nothing skips. Foundation unchanged.

## FIR verification

- FILTER: all 25 markers retained; 1 Samuel 29 excluded.
- ISOLATE: war speech, prior expulsion, inquiry/nonanswer, prohibited-service search/use, woman-observed figure, attributed speech/prediction, collapse, refusal and meal.
- RECONSTRUCT: one new expelled-but-required-service episode and one repeated explicit-refusal/performed-act episode.
- VERIFY: two episodes, one exact SKIP, two distinct YOINKs; apparition and future battle/death mechanisms unresolved; publication held.

## Required compound-eye facets

1. Philistine war gathering / Achish army requirement / David capability speech / bodyguard future.
2. Samuel dead/buried / Saul's prior practitioner expulsion.
3. Army camps / Saul fear and trembling.
4. LORD inquiry / no answer by dreams, Urim or prophets; no divine form.
5. Saul orders familiar-spirit woman search / servants identify Endor.
6. `S203-E001`: expelled service beside required located service; no SKIP; first separate YOINK.
7. Disguise/night request / woman's expulsion and death-risk objection.
8. Saul no-punishment oath / Samuel request.
9. Woman sees/cries/recognizes Saul; exact god/old-man/robe report; Saul perception/bow.
10. Samuel-figure question / Saul distress, war and nonanswer report.
11. Kingdom/Amalek attributions and tomorrow Philistine/death prediction; future visibly unresolved.
12. Saul falls terrified / no food day and night.
13. Woman reciprocity/eat request / Saul says I WILL NOT EAT.
14. Woman and servants constrain / Saul listens, rises and sits.
15. Calf/bread prepared non-graphically / food delivered / Saul and servants eat.
16. `S186-E002`, exact SKIP and second separate YOINK / night departure; chapter 29 excluded.

All sixteen facets appear simultaneously in one zoomable compound-eye image; addresses retain causal traversal.

## Production boundary

One actual high-resolution compound-eye image with 16 facets. `NOT-` display; living things Joe-faced; old-man/robe figure bounded to woman's report; no invented apparition or divine mechanism; food killing non-graphic. `S203-E001` no SKIP; `S186-E002` exact `SKIP -> S186-E001-1SA15`; exactly two separate causally-null YOINKs. Future battle/death/bodyguard outcomes remain unexecuted. Originator review required; publication held.

*shrug*

OK.
