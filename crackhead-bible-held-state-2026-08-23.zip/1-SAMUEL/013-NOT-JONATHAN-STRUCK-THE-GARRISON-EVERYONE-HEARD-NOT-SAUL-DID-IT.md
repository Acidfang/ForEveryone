# CRACKHEAD 1 SAMUEL 13

## Title page

**NOT-JONATHAN STRUCK THE GARRISON. ALL NOT-ISRAEL HEARD NOT-SAUL STRUCK IT.**

Source parent: 1 Samuel chapter 13, verses 1–23, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-013/job.json` and `source.usfm`. Parent: 1 Samuel 12.

Display-origin layer: exact identities remain in evidence; comic display uses `NOT-` identities and places. Every living human, horse, plant and other animal is Joe-faced. Trumpets, chariots, offerings, tools, weapons and other face-like objects may receive Joe faces without life. NOT-THE-LORD / NOT-GOD remains unrendered.

CrackFlix routing: new action-attribution series `S181` and new expired-deadline/punished-compliance series `S182`. `S181-E001-1SA13` and `S182-E001-1SA13` have no SKIP. Exactly two distinct causally-null post-closure YOINKs.

## Causal foundation

```text
SOURCE PRESENTS SAUL AGE 30 / REIGN 42 WITH MANUSCRIPT FOOTNOTE
-> SAUL SELECTS 3000: 2000 WITH SAUL / 1000 WITH JONATHAN / REST HOME
-> JONATHAN STRIKES PHILISTINE GARRISON
-> SAUL BLOWS TRUMPET
-> ALL ISRAEL HEARS SAUL STRUCK GARRISON
-> PHILISTINES MASS / ISRAEL HIDES, CROSSES JORDAN, TREMBLES, SCATTERS
-> SAUL WAITS SEVEN DAYS ACCORDING TO SAMUEL'S SET TIME
-> SAMUEL DOES NOT COME WITHIN APPOINTED DAYS
-> SAUL ORDERS AND OFFERS BURNT OFFERING
-> AS SOON AS OFFERING FINISHES, SAMUEL COMES
-> SAMUEL ASKS / SAUL REPORTS SCATTERING, ABSENCE, THREAT, UNENTREATED LORD
-> SAMUEL SAYS FOOLISH / COMMAND NOT KEPT / KINGDOM WILL NOT CONTINUE
-> SAMUEL LEAVES / SAUL COUNTS ABOUT 600
-> PHILISTINE RAIDERS TAKE THREE ROUTES
-> NO ISRAELITE BLACKSMITH / PHILISTINE TOOL-SHARPENING DEPENDENCY + PRICE
-> BATTLE DAY: ONLY SAUL AND JONATHAN HAVE SWORD/SPEAR
-> PHILISTINE GARRISON MOVES TO MICHMASH PASS
```

## 1 Samuel 13:1 — RETAIN THE SOURCE'S NUMBER CARRIER

The selected source reads Saul was thirty when he became king and reigned forty-two years. Its own footnote says the traditional Hebrew text omits “thirty” and “forty-” and that the blanks were filled from a few Septuagint manuscripts.

Retain both the presented reading and its provenance warning. Do not pretend the numbers are unqualified, choose another chronology, or manufacture a resolved age/reign relation.

## 1 Samuel 13:2–4 — JONATHAN DID / SAUL RECEIVED THE REPORT

Saul chooses 3,000 Israelite men: 2,000 stay with Saul at Michmash and Mount Bethel; 1,000 stay with Jonathan at Gibeah of Benjamin. The rest are sent home.

Jonathan strikes the Philistine garrison at Geba. The Philistines hear. Saul blows a trumpet throughout the land saying, **“LET THE HEBREWS HEAR!”**

Then all Israel hears **that Saul struck the Philistine garrison** and that Israel became an abomination to the Philistines. The people gather after Saul at Gilgal.

The completed friction is exactly:

**SOURCE ACTOR: JONATHAN STRUCK THE GARRISON -> NATIONAL REPORT: SAUL STRUCK THE GARRISON.**

New CrackFlix series:

**S181: HE DID IT. HIS DAD GOT THE CREDIT.**

`S181-E001-1SA13` closes when the Saul-attributed report is observed. Captain pokes the attribution boil, licks his finger, says **“YOINK!”**, and walks away without looking back. He does not reassign credit or affect mobilization.

The mechanism of the attribution change is absent. Saul's trumpet does not itself say Saul performed the strike, and no motive or deliberate theft is inferred.

## 1 Samuel 13:5–7 — MASSING / HIDING / TREMBLING

The Philistines assemble to fight Israel: 30,000 chariots, 6,000 horsemen and people like seashore sand. They camp at Michmash east of Beth Aven. Preserve the source number without harmonization.

Israel sees trouble and distress. People hide in caves, thickets, rocks, tombs and pits. Some Hebrews cross the Jordan into Gad and Gilead. Saul remains at Gilgal while those following him tremble.

No cowardice motive, casualty or battle outcome is added.

## 1 Samuel 13:8–14 — SEVEN DAYS / ABSENCE / OFFERING / PUNISHMENT

Saul stays seven days **according to the time set by Samuel**. Samuel does not come to Gilgal within the appointed days, and people scatter from Saul.

Saul orders the burnt offering and peace offerings brought and personally offers the burnt offering. As soon as he finishes, Samuel arrives. Saul goes to greet him.

Samuel asks what Saul has done. Saul states four observable/model carriers:

1. he saw the people scattering;
2. Samuel did not come within the appointed days;
3. Philistines assembled at Michmash;
4. he said they would descend before he entreated LORD's favor, so he forced himself and offered.

Samuel says Saul acted foolishly and did not keep LORD's command; he states LORD would have established Saul's kingdom forever, but now it will not continue, and says LORD sought and appointed a man after his heart because Saul did not keep the command.

The retained rule/process friction is:

**SEVEN-DAY TIME SET -> SAUL STAYS SEVEN DAYS -> SAMUEL ABSENT WITHIN APPOINTED DAYS -> SAUL ACTS AFTER THE SET TIME -> SAMUEL CLASSIFIES THE ACT AS FAILURE TO KEEP THE COMMAND.**

New CrackFlix series:

**S182: WAIT SEVEN DAYS. I WON'T ARRIVE WITHIN SEVEN DAYS. YOU FAILED TO WAIT.**

`S182-E001-1SA13` closes at Samuel's failure/punishment statement against the observed wait and absence. Captain pokes the deadline boil, licks his finger, says **“YOINK!”**, and walks away without looking back.

The command in 1 Samuel 10:8 also says “until I come”; whether arrival was a second independent condition, whether any partial-day convention applies, the exact offering authority, and the divine command's direct carrier remain unresolved. Preserve those frontiers; do not collapse ambiguity into innocence or guilt beyond Samuel's recorded judgment.

Samuel's forever-kingdom counterfactual and replacement-prince claims remain speech. Do not identify the replacement or execute later dynastic outcomes.

## 1 Samuel 13:15–18 — SIX HUNDRED / THREE RAIDER ROUTES

Samuel rises and travels from Gilgal to Gibeah of Benjamin. Saul counts about 600 people still present. Saul, Jonathan and their group stay at Geba; Philistines camp at Michmash.

Philistine raiders leave in three companies: toward Ophrah/Shual, toward Beth Horon, and toward the Zeboim valley border/wilderness. Routes are observed; raids' individual acts and outcomes are not supplied here.

## 1 Samuel 13:19–23 — OUTSOURCED SHARPENING / WEAPON SCARCITY

No blacksmith is found throughout Israel because the Philistines said Hebrews must not make swords or spears. Israelites go down to Philistines to sharpen plowshares, mattocks, axes and sickles.

The price is one payim for sharpening listed tools; the source footnote defines a payim/pim as two-thirds shekel, 0.26 ounces or 7.6 grams. Preserve the source's measurement carrier.

On battle day, no sword or spear is found in the hands of Saul and Jonathan's people except Saul and Jonathan have them. The Philistine garrison moves to the pass of Michmash.

This is an explicit dependency/control structure, not by itself a contradiction: the force that prevents weapon manufacture also provides paid agricultural-tool sharpening. Motives beyond the quoted weapon-control purpose are not invented.

## Character and world-ledger changes

- NOT-SAUL JOE gains qualified age/reign record, force selection, trumpet mobilization, national strike attribution, Gilgal wait, offering act, explanation, Samuel judgment, about-600 count and weapon possession.
- NOT-JONATHAN JOE gains first named son relation, 1,000-person command, executed Geba garrison strike and weapon possession.
- NOT-SAMUEL JOE gains late-at-appointed-window arrival, inquiry, foolish/command-failure judgment, counterfactual forever-kingdom speech, replacement-prince speech and departure.
- NOT-ISRAEL / NOT-HEBREW JOES gain mobilization report, distress/hiding/crossing/scattering, reduced about-600 presence, blacksmith absence, Philistine sharpening dependency and general weapon scarcity.
- NOT-PHILISTINE JOES gain mass assembly, three raider routes, blacksmith-control statement, paid sharpening role, arms advantage and Michmash-pass movement.
- `S181-E001-1SA13` and `S182-E001-1SA13` retain two distinct completed contradictions.

## Bullshit pass

Issue `1SA-013 / CREDIT TRANSFER + SLA ENFORCEMENT`. NOT-JONATHAN completes the garrison ticket. The nationwide dashboard automatically displays **NOT-SAUL COMPLETED THIS**. At Gilgal, the support agreement says **WAIT 7 DAYS**; NOT-SAMUEL arrives after the seven-day service window and immediately issues a breach notice for not continuing to wait after the stated window. Israel discovers its entire sharpening department was outsourced to the enemy under the **NO INTERNAL WEAPONS** enterprise plan. Foundation unchanged.

## FIR verification

- FILTER: 1 Samuel 13 only; all 23 markers retained in order; 1 Samuel 14 excluded.
- ISOLATE: qualified age/reign data, force allocation, garrison strike/report attribution, military buildup/dispersal, seven-day wait/absence/offering/judgment, reduced force, raider routes and blacksmith/weapon dependency.
- RECONSTRUCT: two separate contradictions—actor/report attribution and set-deadline/punished post-deadline action.
- VERIFY: two new series/episodes, zero SKIPs and two distinct YOINKs; number footnotes retained; future kingdom/replacement outcomes remain speech; divine form absent; publication held.

## Required comic states

1. Qualified age 30/reign 42 carrier plus visible manuscript-footnote boundary.
2. Saul's 3,000 split: 2,000 Saul / 1,000 Jonathan / rest home.
3. Jonathan strikes Geba garrison; Philistines hear.
4. Saul trumpet: let Hebrews hear.
5. All Israel hears Saul struck it; S181 closes; one causally-null YOINK.
6. Philistine force/count/camp, with source numbers exact.
7. Israel distress/hiding/cross-Jordan/trembling/scattering.
8. Saul stays seven days; Samuel does not arrive within appointed days.
9. Saul orders and completes burnt offering; Samuel immediately arrives.
10. Samuel inquiry; Saul's four-part explanation.
11. Samuel foolish/command-not-kept/kingdom-not-continue speech; S182 closes; second causally-null YOINK.
12. Samuel replacement-prince claim remains speech/unidentified.
13. Samuel departure; Saul counts about 600; opposing camps.
14. Three Philistine raider routes.
15. No Israelite blacksmith; Philistine weapon-control statement.
16. Agricultural tools sent to Philistines for payim sharpening.
17. Battle-day sword/spear scarcity; only Saul/Jonathan armed.
18. Philistine garrison moves to Michmash pass.
19. Held lineage page: 1 Samuel 14 excluded.

## Production boundary

- All displayed biblical identities/places use `NOT-`; exact source names remain in evidence.
- All living humans, horses, plants and animals are Joe-faced. Object faces do not establish life. LORD/God remains unrendered.
- Display 13:1 numbers with the source footnote qualification; do not resolve manuscript history.
- Exactly two distinct contradictions. No SKIP. Exactly two separate boilless, causally-null Captain appearances after their respective closures: poke physical boil, lick finger, **“YOINK!”**, walk away, no look back.
- Do not infer Saul deliberately stole Jonathan's credit; preserve act/report distinction only.
- Preserve exact seven-day wait, Samuel's nonarrival within appointed days, offering completion, immediate arrival and Samuel's judgment. Do not invent time-of-day, offering authority, command wording beyond retained parents, motive or guilt resolution.
- Keep battle restrained and avoid graphic violence. Preserve exact source counts and approximate 600.
- Keep future kingdom/replacement claims unexecuted and replacement identity unresolved.
- Publication held. `CHB-1SA-014` excluded.

*shrug*

OK.
