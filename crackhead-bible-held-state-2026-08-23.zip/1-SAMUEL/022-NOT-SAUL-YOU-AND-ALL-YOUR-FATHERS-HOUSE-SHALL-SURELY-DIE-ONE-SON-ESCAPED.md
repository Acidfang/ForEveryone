# CRACKHEAD 1 SAMUEL 22

## Title page

**NOT-SAUL: YOU AND ALL YOUR FATHER'S HOUSE SHALL SURELY DIE. ONE SON ESCAPED.**

Source parent: 1 Samuel chapter 22, verses 1–23, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-022/job.json` and `source.usfm`. Parent: 1 Samuel 21. Exact identities remain in evidence; comic display uses `NOT-` identities. Every living thing is Joe-faced. Divine form remains unrendered. All killing and threatened violence is non-graphic.

CrackFlix: premiere `S201-E001-1SA22`. No SKIP. Exactly one causally-null post-closure YOINK.

## Causal foundation

```text
DAVID ESCAPES TO CAVE / FAMILY AND ABOUT 400 GATHER
-> PARENTS PLACED WITH KING OF MOAB
-> GAD ORDERS DAVID TO JUDAH / DAVID GOES
-> SAUL ACCUSES SERVANTS OF CONSPIRACY/NONDISCLOSURE
-> DOEG REPORTS DAVID'S NOB VISIT AND AHIMELECH'S ACTS
-> SAUL SUMMONS AHIMELECH AND ALL PRIESTS OF HIS FATHER'S HOUSE
-> SAUL ACCUSES AHIMELECH OF CONSPIRACY
-> AHIMELECH IDENTIFIES DAVID AS FAITHFUL/HONORED AND DENIES KNOWLEDGE
-> SAUL: YOU AND ALL YOUR FATHER'S HOUSE SHALL SURELY DIE
-> SAUL'S GUARDS REFUSE TO KILL LORD'S PRIESTS
-> DOEG OBEYS / KILLS 85 PRIESTS / STRIKES NOB
-> ONE NAMED SON ABIATHAR ESCAPES
-> ABIATHAR TELLS DAVID
-> DAVID SAYS HE KNEW DOEG WOULD TELL / ACCEPTS RESPONSIBILITY
-> DAVID OFFERS ABIATHAR SAFETY WITH HIM
```

## Verses 1–5 — CAVE, FOUR HUNDRED, PARENTS, JUDAH

David escapes to Adullam's cave. His brothers and father's house hear and go to him. Distressed, indebted and discontented people gather; David becomes captain over about four hundred men.

David asks the king of Moab to let his father and mother remain until David knows what God will do for him. They live there while David is in the stronghold. The prophet Gad tells David not to remain but to enter Judah; David goes to Hereth forest. God supplies no rendered form or direct speech in this chapter.

## Verses 6–10 — SAUL'S ACCUSATION / DOEG'S REPORT

Saul hears David and his men are discovered. With spear in hand and servants around him, Saul asks whether Jesse's son will give the Benjamites fields, vineyards and offices. He says all have conspired, nobody disclosed Jonathan's treaty, nobody is sorry, and Jonathan stirred David to ambush him.

Those are Saul's claims. The text does not establish what every servant knew, their motives, an ambush, or a collective conspiracy. Doeg then reports only what he says he saw at Nob: David came to Ahimelech, who inquired of LORD, supplied food and supplied Goliath's sword. The later disclosure is a changed observable State, not proof that Saul's preceding universal accusation was true or false.

## Verses 11–15 — SUMMONS / ACCUSATION / DENIAL

Saul summons Ahimelech and all priests of his father's house at Nob. Saul treats the bread, sword and inquiry as conspiracy intended to raise David against him.

Ahimelech answers that David was Saul's faithful servant, son-in-law, bodyguard captain and honored in Saul's house. He asks whether that day began his inquiries for David, rejects the accusation, and says he knew nothing of the matter, less or more.

Saul's knowing-conspiracy account and Ahimelech's no-knowledge account conflict, but the fly cannot inspect either mind. No crack is invented from the unresolved testimony.

## Verses 16–20 — ALL SHALL DIE / ONE ESCAPES

Saul declares: **“YOU SHALL SURELY DIE, AHIMELECH, YOU AND ALL YOUR FATHER'S HOUSE.”** He orders his guard to kill LORD's priests, asserting they knew David fled and withheld it. The guards refuse.

Saul gives the order to Doeg. Doeg attacks and kills eighty-five linen-ephod wearers that day, then strikes Nob's people and animals. Production depicts only aftermath, absence, abandoned objects and restrained silhouettes—no gore.

One named son of Ahimelech, Abiathar, **escapes** and flees after David. The declared all-house death outcome has completed far enough to produce killings, yet the source explicitly retains one member alive.

New `S201: YOU AND ALL YOUR FATHER'S HOUSE SHALL SURELY DIE. ONE SON ESCAPED.` `S201-E001-1SA22` closes at Abiathar's escape. No SKIP. Captain appears only after the survivor is observed, pokes and licks the boil, says **“YOINK!”**, walks away eating the crack crystal he thinks he took, and changes nothing.

## Verses 21–23 — REPORT / RESPONSIBILITY / SAFETY

Abiathar tells David Saul killed LORD's priests. David says he knew when Doeg was present that Doeg would surely tell Saul, and says he is responsible for the deaths of Abiathar's father's house. This is David's explicit retrospective knowledge and responsibility statement. It does not erase Saul's orders, Doeg's acts, the guards' refusal, David's earlier cover account, or any other retained causal Root.

David tells Abiathar to stay, not fear, and says the seeker of David's life seeks Abiathar's life and Abiathar will be safe with him. Future safety remains speech at chapter close.

## Character and world-ledger changes

- NOT-DAVID gains cave captaincy, Moab parent placement, Judah return, retrospective Doeg-knowledge statement, responsibility acceptance and Abiathar safety promise.
- NOT-SAUL gains servant conspiracy speech, Ahimelech accusation, all-house death declaration and two sequential kill orders.
- NOT-DOEG gains Nob report and completed priest/Nob attack acts without invented motive.
- NOT-AHIMELECH gains faithful-David defense, explicit no-knowledge statement and death.
- NOT-ABIATHAR gains named survivor State, escape, David report and unresolved future safety.
- NOT-GUARDS gain collective refusal to kill the priests.
- NOT-GAD gains one spoken movement instruction; no divine form is supplied.

## Bullshit pass

Issue `1SA-022 / ALL MEANS MOSTLY ALL`. NOT-SAUL runs **CRACKHEAD HUMAN RESOURCES: CONSPIRACY BY BENEFITS PACKAGE**, then issues an **ALL-HOUSE TERMINATION NOTICE** with one surviving account still logged in. NOT-DAVID accepts the blame ticket without deleting the king-order or Doeg-execution tickets. Foundation unchanged.

## FIR verification

- FILTER: all 23 markers retained; 1 Samuel 23 excluded.
- ISOLATE: cave/company, parents, Gad route, Saul speech, Doeg report, summons, accusation/denial, guard refusal, Doeg attacks, Abiathar escape, report/responsibility/safety.
- RECONSTRUCT: one closed survivor contradiction; conspiracy knowledge remains unresolved testimony.
- VERIFY: no SKIP, one YOINK; violence restrained; future safety unclosed; publication held.

## Required comic states

1. Cave gathering / about four hundred / David captain.
2. Parents with NOT-KING OF MOAB / Gad instruction / David enters Judah.
3. Saul under tree with spear / servants / accusation speech.
4. Doeg's bounded Nob report.
5. Ahimelech and priests summoned.
6. Saul conspiracy accusation / Ahimelech faithful-David and no-knowledge answer.
7. Saul all-house surely-die declaration.
8. Guards refuse the priest-killing order.
9. Doeg accepts second order / non-graphic priest and Nob aftermath.
10. Abiathar visibly escapes alive; S201/YOINK.
11. Abiathar reports / David accepts responsibility without causal erasure.
12. Stay-with-me safety speech / held lineage; chapter 23 excluded.

## Production boundary

`NOT-` display; every living thing Joe-faced; no divine form. Violence and death remain source-faithful but non-graphic. One episode, no SKIP, one separate boilless causally-null Captain poke/lick/**“YOINK!”**/walk-away appearance after Abiathar's observed survival. Do not infer conspiracy, priest knowledge, servant motives, Doeg motive, divine instruction behind Gad, or fulfilled future safety. Publication held.

*shrug*

OK.
