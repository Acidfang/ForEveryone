# CRACKHEAD 1 SAMUEL 17

## Title page

**NOT-SAUL: WHOSE SON IS THE GUY I REQUESTED FROM HIS FATHER?**

Source parent: 1 Samuel chapter 17, verses 1–58, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-017/job.json` and `source.usfm`. Parent: 1 Samuel 16.

Exact identities remain in evidence; comic display uses `NOT-` identities and places. Every living human, animal and plant is Joe-faced. Face-like equipment may receive Joe faces without life. Divine form remains unrendered.

CrackFlix: repeated mental-private-State `S154-E005-1SA17`, capability-dismissal `S179-E002-1SA17`, failed-death-prediction `S153-E002-1SA17`; premieres `S187-E001-1SA17`, `S188-E001-1SA17`, `S189-E001-1SA17`. Three exact SKIPs do nothing. Exactly six causally-null post-closure YOINKs.

## Causal foundation

```text
PHILISTINES/ISRAEL ARRAY ACROSS VALLEY
-> GOLIATH EQUIPMENT/MEASUREMENTS + SINGLE-COMBAT TERMS
-> IF ISRAEL MAN KILLS GOLIATH, PHILISTINES WILL SERVE ISRAEL
-> FORTY DAYS OF CHALLENGE; SAUL/ISRAEL AFRAID
-> DAVID MOVES BETWEEN SAUL AND JESSE'S SHEEP
-> JESSE SENDS FOOD/CHEESES + BROTHER-STATUS MISSION
-> DAVID ARRIVES, HEARS CHALLENGE/REWARD
-> ELIAB ASSERTS PRIDE/EVIL HEART/COME-TO-WATCH MOTIVE
-> RETAINED JESSE COMMAND + COMPLETED DELIVERY ROUTE
-> DAVID'S FIGHT OFFER REACHES SAUL
-> SAUL: YOU ARE NOT ABLE
-> DAVID REPORTS LION/BEAR ACTS; SAUL PERMITS
-> SAUL ARMOR TRIED/REMOVED; STAFF/FIVE STONES/SLING
-> GOLIATH DISDAINS DAVID AND PREDICTS DAVID'S FLESH TO BIRDS/ANIMALS
-> DAVID PREDICTS GOLIATH DEFEAT AND STATES LORD-BATTLE ATTRIBUTION
-> STONE STRIKES; GOLIATH FALLS
-> NARRATOR: DAVID KILLED GOLIATH WITH SLING/STONE
-> DAVID TAKES GOLIATH'S SWORD AND KILLS HIM
-> PHILISTINES SEE CHAMPION DEAD AND FLEE INSTEAD OF SERVING
-> ISRAEL/JUDAH PURSUE; CAMP PLUNDERED
-> SAUL ASKS WHOSE SON DAVID IS
-> RETAINED PRIOR: SAUL SENT TO JESSE FOR DAVID HIS SON, THEN ASKED JESSE TO KEEP HIM
-> DAVID AGAIN IDENTIFIES JESSE AS FATHER
```

## Verses 1–11 — ARMIES / CHAMPION / TERMS / FEAR

Retain Socoh/Azekah/Ephesdammim, Elah and the opposing mountains. Goliath of Gath emerges: six cubits and span, with source footnote about 9 feet 9 inches/2.97 m; bronze helmet, 5,000-shekel coat with 50 kg/110 lb footnote; shin armor/javelin; beam-like spear with 600-shekel head and 6 kg/13 lb footnote; shield bearer.

Goliath proposes one fighter. If that fighter kills him, Philistines will be Israel's servants; if he kills the fighter, Israel serves Philistines. Saul and Israel hear, are dismayed and greatly afraid. Terms are speech; no acceptance carrier is separately supplied, but Goliath continues presenting them.

## Verses 12–23 — JESSE HOUSE / FORTY DAYS / DELIVERY

Jesse is elderly, has eight sons; Eliab, Abinadab and Shammah follow Saul. David is youngest and goes back and forth from Saul to feed Jesse's sheep. Goliath presents morning/evening for forty days.

Jesse sends David with an ephah of grain, ten loaves and ten cheeses, ordering delivery, brother-status observation and news return. David leaves sheep with a keeper, carries provisions, reaches the wagon place, leaves baggage with its keeper, runs to greet brothers, and hears Goliath repeat the challenge.

## Verses 24–30 — FLIGHT / REWARD / ELIAB'S MENTAL MODEL

Israel's men flee terrified. They report proposed reward: riches, king's daughter and tax-free father's house. David asks and hears it repeated.

Eliab's anger burns. He asks why David came and where he left the few sheep, then asserts knowledge of David's pride, evil heart and purpose: **“YOU HAVE COME DOWN THAT YOU MIGHT SEE THE BATTLE.”**

The source retains Jesse's explicit delivery/status/news command and David's completed provision route. It supplies no David statement establishing pride or evil heart.

This joins mental-private-State series `S154`. `S154-E005-1SA17` displays **SKIP -> S154-E004-JDG20**. SKIP changes nothing; Eliab's speech and David's response continue. The mental crack closes at the retained command/executed mission boundary. Captain's eyes bulge at **“MENTAL CRACK?!”**, then standard poke, lick, **“YOINK!”**, walk-away. He changes nothing.

## Verses 31–40 — NOT ABLE / PAST ACTS / EQUIPMENT CHANGE

David's words reach Saul; David offers to fight. Saul says David is **not able** because David is a youth and Goliath a warrior from youth. David reports rescuing sheep and killing lion/bear, predicts Goliath will be like them, and attributes past/future delivery to LORD. Saul permits him and states LORD will be with him.

Saul clothes David in armor. David tries moving, says he cannot go in untested gear, removes it, and takes staff, five smooth stones, shepherd bag and sling.

David then fights and kills Goliath. This closes the capability dismissal against executed capability and joins `S179`. `S179-E002-1SA17` displays **SKIP -> S179-E001-1SA11**; SKIP does nothing. After the kill closure, Captain performs one causally-null **“YOINK!”**.

David's lion/bear account and divine attribution remain his speech; no prior event replay or mechanism is invented.

## Verses 41–47 — MUTUAL SPEECH / FAILED THREAT

Goliath approaches with shield bearer, sees/disdains David based on youth/ruddy/good-looking face, asks whether he is a dog approached with sticks, curses by his gods, and says he will give David's flesh to birds and field animals.

David states sword/spear/javelin versus LORD-of-Armies name, predicts Goliath's delivery, strike and head removal, predicts army bodies to animals, and states the battle belongs to LORD. Preserve these as David's speech until observed acts close individual predictions.

David survives and Goliath dies. Goliath's David-death/flesh prediction therefore joins `S153`. `S153-E002-1SA17` displays **SKIP -> S153-E001-JDG13**; SKIP does nothing. One post-closure Captain **“YOINK!”** changes nothing.

## Verses 48–51 — STONE KILL / SWORD KILL

David runs, slings one stone into Goliath's forehead; Goliath falls face down. Verse 50 states David prevailed with sling/stone, struck and **killed him**, with no sword in David's hand.

David then takes Goliath's sword, draws it, **kills him**, and cuts off his head. Preserve the two explicit sequential kill statements without converting the first to merely stunned.

**NARRATOR: KILLED WITH STONE -> THEN TOOK SWORD AND KILLED HIM.**

New `S188: KILLED HIM. THEN KILLED HIM.` `S188-E001-1SA17` closes at the second kill statement. No SKIP. Captain performs one causally-null **“YOINK!”**. Depict all violence restrained and non-graphic.

## Verses 51–54 — PROMISED SERVICE / OBSERVED FLIGHT

Philistines see their champion dead and flee. Israel/Judah pursue toward Gai/Ekron, with wounded falling along the Shaaraim/Gath/Ekron route, then return and plunder camp. David takes the head to Jerusalem and stores armor in his tent; chronology/location mechanics beyond the source order remain unresolved.

Goliath's terms said Philistines would serve Israel if an Israelite killed him. David kills him; Philistines flee instead.

New `S187: KILL ME AND WE WILL SERVE YOU. YOU KILLED ME; WE RAN AWAY.` `S187-E001-1SA17` closes at the flight. No SKIP. Captain performs one causally-null **“YOINK!”**. Do not infer whether Philistine forces accepted Goliath's terms.

## Verses 55–58 — WHOSE SON / PRIOR REQUEST TO FATHER

As David goes to fight, Saul asks Abner whose son the youth is. Abner cannot tell; Saul orders inquiry. After David returns, Saul asks David whose son he is. David identifies Jesse the Bethlehemite.

The retained chapter-16 parent records:

1. a young man identifies the candidate as a son of Jesse the Bethlehemite;
2. Saul sends messengers to Jesse saying **“SEND ME DAVID YOUR SON”**;
3. David serves Saul;
4. Saul sends to Jesse again asking David to remain.

No identity reset, different David/Jesse, memory-loss event or limited-question scope is supplied.

New `S189: SEND ME DAVID YOUR SON, JESSE. WHOSE SON IS DAVID?` `S189-E001-1SA17` closes at Saul's renewed question against the retained addressed correspondence. No SKIP. Captain performs one causally-null **“YOINK!”** and does not answer for anyone.

## Character and world-ledger changes

- NOT-DAVID gains back-and-forth shepherd/service State, provision mission, Goliath inquiry, Eliab accusation/response, fight offer, lion/bear report, equipment test/removal, sling/stone victory, Goliath-sword action, pursuit aftermath carriers and repeated father identification.
- NOT-SAUL gains battlefield fear, reward report attributed by Israel, capability dismissal/permission, armor provision and father-identity inquiry despite prior Jesse correspondence.
- NOT-GOLIATH gains measurements/equipment, forty-day challenge, duel terms, curses/threat, death and retained double-kill grammar.
- NOT-ELIAB gains anger, private-heart/purpose assertions and mental crack address.
- NOT-ISRAEL/PHILISTINES gain fear/flight/pursuit/plunder and unexecuted servitude terms.

## Bullshit pass

Issue `1SA-017 / PROD IDENTITY CACHE MISS`. NOT-SAUL rejects the already-recommended **MIGHTY MAN OF WAR** as unable to fight, then asks whose son the palace employee is after twice messaging his father. The duel contract says **LOSER'S COMPANY BECOMES SUBSIDIARY**; the losing company runs away. Goliath receives duplicate death notifications. Foundation unchanged.

## FIR verification

- FILTER: all 58 markers retained in order; 1 Samuel 18 excluded.
- ISOLATE: camps/champion/terms, Jesse delivery, Eliab mental assertion, capability dismissal, mutual predictions, double kill, flight and cross-chapter identity query.
- RECONSTRUCT: six valid episodes; three exact repeated types and three premieres.
- VERIFY: three SKIPs point to exact episodes and do nothing; six YOINKs; identity, acceptance and mechanism gaps preserved; publication held.

## Required comic states

1. Opposing camps/valley.
2. Goliath measurements/equipment/footnotes.
3. Duel terms including promised servitude.
4. Saul/Israel fear; forty-day repetition.
5. Jesse/eight sons/three at battle/David back-and-forth.
6. Food/cheese/status mission and completed delivery route.
7. Goliath repeat; Israel flight/reward report.
8. David inquiry/repeated reward.
9. Eliab private-heart/purpose claim; S154 SKIP/mental YOINK.
10. David fight offer reaches Saul.
11. Saul not-able dismissal.
12. Lion/bear report and permission.
13. Armor tried/removed; staff/stones/sling.
14. Goliath disdain/curse/David-flesh threat.
15. David LORD/delivery/battle speech.
16. Run/sling/stone/fall.
17. Capability closure; S179 SKIP/YOINK.
18. David survives/Goliath dies; S153 SKIP/YOINK.
19. Narrated stone kill then sword kill; S188/YOINK.
20. Champion dead; Philistines flee; S187/YOINK.
21. Restrained pursuit/plunder/head/armor State.
22. Saul asks Abner whose son.
23. Retained chapter-16 Jesse correspondence beside renewed question; S189/YOINK.
24. David identifies Jesse.
25. Held lineage page; 1 Samuel 18 excluded.

## Production boundary

- `NOT-` display; exact identities in evidence. Every living person, lion, bear, sheep, donkey, birds and animals Joe-faced. No divine form.
- Restrained/non-graphic combat, death, head and pursuit imagery.
- Six episodes; three exact SKIPs; six separate boilless causally-null Captain poke/lick/**“YOINK!”**/walk-away appearances.
- Preserve source measurements/footnotes, actor speech versus narrator outcome, double kill grammar and cross-chapter correspondence. No motive, memory diagnosis, contract acceptance, divine mechanism or textual repair invented.
- Publication held. `CHB-1SA-018` excluded.

*shrug*

OK.
