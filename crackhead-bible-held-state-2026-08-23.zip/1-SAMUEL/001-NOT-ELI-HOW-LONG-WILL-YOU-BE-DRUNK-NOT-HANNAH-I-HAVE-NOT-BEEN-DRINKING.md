# CRACKHEAD 1 SAMUEL 1

## Title page

**NOT-ELI: “HOW LONG WILL YOU BE DRUNK?” NOT-HANNAH: “I HAVE NOT BEEN DRINKING.”**

Source parent: 1 Samuel chapter 1, verses 1–28, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-001/job.json` and `source.usfm`. Parent: Ruth 4.

Display-origin layer: exact source identities remain in evidence. Comic display uses `NOT-` identities and places, including **NOT-ELKANAH JOE**, **NOT-HANNAH JOE**, **NOT-PENINNAH JOE**, **NOT-ELI JOE**, **NOT-HOPHNI JOE**, **NOT-PHINEHAS JOE**, and child **NOT-SAMUEL JOE**. Every living person and sacrificial bull is Joe-faced. NOT-THE-LORD / NOT-GOD remains unrendered.

CrackFlix routing: new mental-model series `S172-E001-1SA1` has no SKIP. Exactly one causally-null post-closure YOINK.

## Causal foundation

```text
ELKANAH HAS HANNAH + PENINNAH AS WIVES
-> PENINNAH HAS CHILDREN / HANNAH HAS NONE
-> YEARLY SHILOH WORSHIP + SACRIFICE
-> ELKANAH DISTRIBUTES PORTIONS / DOUBLE TO HANNAH
-> NARRATOR ATTRIBUTES HANNAH CLOSED WOMB TO LORD
-> PENINNAH PROVOKES HANNAH YEAR BY YEAR
-> HANNAH WEEPS / DOES NOT EAT
-> ELKANAH ASKS WHY + CLAIMS BETTER THAN TEN SONS
-> HANNAH RISES / PRAYS WEEPING / VOWS BOY TO LORD FOR LIFE
-> ELI OBSERVES MOVING LIPS + UNHEARD VOICE
-> ELI THINKS DRUNK / ASSERTS DRUNK / ORDERS WINE REMOVAL
-> HANNAH SAYS NO WINE OR STRONG DRINK / SORROWFUL PRAYER
-> ELI SAYS GO IN PEACE / MAY GOD GRANT PETITION
-> HANNAH LEAVES / EATS / FACE NO LONGER SAD
-> FAMILY WORSHIPS / RETURNS / ELKANAH KNOWS HANNAH
-> NARRATOR: LORD REMEMBERS HER
-> HANNAH CONCEIVES / BEARS / NAMES SAMUEL
-> NEXT YEAR HANNAH STAYS TO NURSE UNTIL WEANED
-> AFTER WEANING TAKES CHILD + OFFERING TO SHILOH
-> BULL KILLED / CHILD BROUGHT TO ELI
-> HANNAH IDENTIFIES PRIOR PRAYER + ATTRIBUTES GRANT TO LORD
-> HANNAH SAYS CHILD GIVEN TO LORD FOR LIFE
-> HE WORSHIPS THERE
```

## 1 Samuel 1:1–8 — YEAR BY YEAR

Elkanah's ancestry and Ephraimite identity are supplied. He has two wives: Hannah and Peninnah. Peninnah has sons and daughters; Hannah has no children.

Each year Elkanah goes from his city to worship and sacrifice to LORD of Armies at Shiloh, where Eli's sons Hophni and Phinehas are priests. At sacrifice he gives portions to Peninnah and her children, and a double portion to Hannah because he loves her. The narrator twice says LORD shut Hannah's womb.

Peninnah, called Hannah's rival, severely provokes and irritates her because of that State. This repeats year by year at LORD's house. Hannah weeps and does not eat.

Elkanah asks why she weeps, does not eat and has a grieved heart, then asks:

**“AM I NOT BETTER TO YOU THAN TEN SONS?”**

This is Elkanah's comparison, not an observed measurement and not a contradiction. Hannah's answer is not supplied. Peninnah's exact words and private motive are not supplied beyond the narrator's provoke/irritate relation.

## 1 Samuel 1:9–11 — THE VOW

After eating and drinking finish in Shiloh, Hannah rises. Eli sits by the temple doorpost. Hannah, bitter in soul, prays to LORD and weeps bitterly.

She vows that if LORD looks at her affliction, remembers rather than forgets her, and gives her a boy, she will give him to LORD for all his life and no razor will come on his head.

This is a conditional human vow and request. It is not yet a divine promise, answer, conception or birth.

## 1 Samuel 1:12–16 — MOVING LIPS BECOME WINE

Hannah continues praying. Eli sees her mouth. The narrator says Hannah speaks in her heart: only her lips move and her voice is not heard.

From that observation Eli thinks she is drunk and says:

**“HOW LONG WILL YOU BE DRUNK? GET RID OF YOUR WINE!”**

Hannah answers:

**“NO, MY LORD. I AM A WOMAN OF A SORROWFUL SPIRIT. I HAVE NOT BEEN DRINKING WINE OR STRONG DRINK.”**

She says she poured out her soul before LORD and asks not to be considered wicked, explaining her speech as abundant complaint and provocation.

The only retained evidence behind Eli's model is moving lips with no audible voice. No wine, drinking act, odor, container, impaired movement or other intoxication carrier is supplied. Hannah directly denies drinking. New mental CrackFlix series:

**S172: I SAW ONE SIGN. I SUPPLIED THE WHOLE CONDITION.**

The mental crack is addressed to Eli's asserted intoxication model, not to an imagined external act by Hannah. After the denial completes, Captain pokes the mental-model boil, licks his finger, says **“YOINK!”**, and walks away. Eli continues normally.

## 1 Samuel 1:17–20 — REQUEST, REMEMBRANCE, BIRTH

Eli tells Hannah to go in peace and says **may** the God of Israel grant her petition. Hannah asks to find favor. She leaves, eats, and her facial expression is no longer sad.

Eli's sentence is a wish, not an assertion that he granted the petition or that God already did.

The family rises, worships and returns to its Ramah house. Elkanah knows Hannah his wife. The narrator says LORD remembers her. In due time Hannah conceives, bears a son and names him Samuel, saying she asked him of LORD.

The sequence is retained without inventing a divine form, speech, biological mechanism, exact duration, Eli causation or independent proof of Hannah's later attribution.

## 1 Samuel 1:21–23 — WAIT UNTIL WEANED

Elkanah and all his house go for the yearly sacrifice and his vow. Hannah does not go. She tells Elkanah she will wait until the child is weaned, then bring him to appear before LORD and stay there forever.

Elkanah tells her to do what seems good, wait until weaning, and says only may LORD establish his word. The addressed “word,” its carrier and whether it refers to Eli's wish, Hannah's vow or another statement remain unresolved.

Hannah waits, nurses her son and weans him. No conflict with the yearly trip is manufactured; the source explicitly supplies her temporary exception and Elkanah's agreement.

## 1 Samuel 1:24–28 — GIVEN

After weaning, Hannah takes young Samuel to LORD's house in Shiloh with three bulls, one ephah of meal and a container of wine. They kill **the bull** and bring the child to Eli. The relation between the three transported bulls and singular killed bull remains a scoped count distinction, not automatically a contradiction; the remaining bulls' immediate disposition is unresolved.

Hannah identifies herself as the woman who stood by Eli praying. She says she prayed for this child and LORD gave her the petition she asked. Therefore she has given Samuel to LORD; as long as he lives he is given to LORD.

This is Hannah's attribution and performed delivery/vow statement. It does not erase Elkanah's reproductive act, Hannah's conception/birth/nursing acts or Eli's earlier wish. Custody duties, priest acceptance words, Samuel's understanding and future service remain unresolved.

The chapter says **he worshiped LORD there**. The pronoun referent is not resolved beyond the source wording. Do not choose Samuel, Elkanah or Eli without evidence. 1 Samuel 2 is excluded.

## Character and world-ledger changes

- NOT-ELKANAH gains ancestry, two-wife household, yearly Shiloh sacrifice, portion distribution, Hannah comparison, reproductive act, later vow journey and weaning agreement.
- NOT-HANNAH gains childless/provoked/weeping State, prayer/vow, silent-lip prayer, drinking denial, restored facial expression, conception/birth/naming, nursing/weaning, offering transport and lifetime-gift statement.
- NOT-PENINNAH gains children and year-by-year provocation State; words and private motive remain unresolved.
- NOT-ELI gains temple-seat observation, unsupported drunk model, accusation, corrected evidence State, peace/grant wish and later child-delivery encounter.
- NOT-SAMUEL gains birth, name, nursing/weaning, Shiloh delivery and given-for-life statement; later service is excluded.
- `S172-E001-1SA1` retains the completed mental contradiction.

## Bullshit pass

Issue `1SA-001 / PRAYER AUDIO DRIVER NOT FOUND`. NOT-ELI's lip scanner returns **WINE DETECTED: SOURCE NONE**. NOT-HANNAH uploads the correction, then the child-transfer screen displays **THREE BULLS IN / THE BULL OUT / REMAINDER PENDING**. Foundation unchanged.

## FIR verification

- FILTER: 1 Samuel 1 only; all 28 markers retained in order; 1 Samuel 2 excluded.
- ISOLATE: household/reproduction State, yearly provocation, prayer/vow, Eli intoxication model and denial, later conception/birth, weaning and Shiloh delivery.
- RECONSTRUCT: one new mental `S172`; Eli's evidence-to-condition jump closes at Hannah's direct denial.
- VERIFY: exactly one crack, zero SKIPs and one YOINK; no Peninnah words/motive, divine speech/form/mechanism, Eli causation, vow referent, bull disposal, custody detail, worshiper pronoun or future service invented; publication held.

## Required comic states

1. Elkanah family identities, Peninnah children/Hannah none, yearly Shiloh route and priests.
2. Sacrifice portions/double Hannah portion and narrated closed-womb attribution.
3. Yearly provocation, weeping/no eating, Elkanah's questions and ten-sons comparison.
4. Hannah bitter prayer and conditional lifelong/no-razor vow; Eli seated nearby.
5. Moving lips/unheard voice observation; Eli's drunk model and accusation.
6. Hannah's no-wine/strong-drink denial; S172 mental crack and one YOINK.
7. Eli's peace/may-God-grant wish; Hannah leaves/eats/face changes.
8. Worship/return, Elkanah knows Hannah, narrated LORD remembrance, conception/birth/name.
9. Next yearly trip; Hannah's weaning delay and Elkanah agreement.
10. Weaned child, three bulls/meal/wine transport, singular bull killed, child brought to Eli.
11. Hannah prior-prayer identification, grant attribution and lifetime-gift statement.
12. Unresolved “he worshiped” carrier and held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; exact source identities remain in evidence.
- Every living human and animal is Joe-faced, including young NOT-SAMUEL and the bulls. NOT-THE-LORD / NOT-GOD remains unrendered.
- Eli's mental crack must show exactly the observed lips/unheard voice, his intoxication assertion, and Hannah's denial. Do not add drinking imagery or make Captain reveal external alcohol.
- No SKIP. Exactly one boilless, causally-null Captain occurrence after the denial completes: poke, lick, **“YOINK!”**, walk away, no look back.
- Preserve wishes, prayers, vows, narrator attributions and human testimony as distinct carriers. Do not turn Eli's wish into divine speech or causal power.
- Keep reproduction non-graphic. Do not invent divine or biological mechanism.
- Retain three bulls transported and singular bull killed without silently changing either count or inventing disposition.
- Do not resolve the final worshiper pronoun.
- Publication held. `CHB-1SA-002` excluded.

*shrug*

OK.

