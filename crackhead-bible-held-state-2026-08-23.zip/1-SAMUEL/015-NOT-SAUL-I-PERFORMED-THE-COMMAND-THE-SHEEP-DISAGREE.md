# CRACKHEAD 1 SAMUEL 15

## Title page

**NOT-SAUL: I PERFORMED THE COMMAND. THE NOT-SHEEP DISAGREE.**

Source parent: 1 Samuel chapter 15, verses 1–35, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-015/job.json` and `source.usfm`. Parent: 1 Samuel 14.

Exact identities remain in evidence; comic display uses `NOT-` identities and places. Every living human, animal and plant is Joe-faced. Face-like objects may receive Joe faces without life. NOT-THE-LORD / NOT-GOD remains unrendered except exact speech carriers.

CrackFlix routing: existing actor/report series `S181`; new retained-remainder/completion series `S185`; new refusal/reversal series `S186`. Episodes: `S185-E001-1SA15`, `S181-E002-1SA15`, `S185-E002-1SA15`, `S181-E003-1SA15`, `S186-E001-1SA15`. Three SKIPs point backward and do nothing. Exactly five causally-null post-closure YOINKs.

## Causal foundation

```text
SAMUEL CARRIES LORD COMMAND: DESTROY ALL / SPARE NONE
-> SAUL COUNTS 200000 + 10000, WARNS KENITES, STRIKES AMALEK
-> AGAG TAKEN ALIVE; SAUL + PEOPLE SPARE KING/BEST LIVESTOCK/GOOD THINGS
-> LORD WORD: SAUL DID NOT PERFORM COMMANDS
-> SAUL BUILDS OWN MONUMENT
-> SAUL: I PERFORMED THE COMMAND
-> SHEEP BLEAT / CATTLE LOW / AGAG REMAINS ALIVE
-> SAUL: THE PEOPLE SPARED THEM FOR SACRIFICE; WE DESTROYED REST
-> SAMUEL RETAINS COMMAND / ASKS WHY PLUNDER TAKEN
-> SAUL: I OBEYED / BROUGHT AGAG / DESTROYED AMALEKITES
-> SAUL: THE PEOPLE TOOK BEST DEVOTED THINGS FOR SACRIFICE
-> SAMUEL: OBEDIENCE BETTER THAN SACRIFICE / REJECTION FROM KINGSHIP
-> SAUL CONFESSES / SAYS HE FEARED PEOPLE / ASKS PARDON AND RETURN
-> SAMUEL: I WILL NOT RETURN WITH YOU
-> ROBE TEARS / KINGDOM-TRANSFER SPEECH / NOT-LIE-NOR-REPENT SPEECH
-> SAUL ASKS PUBLIC HONOR AND RETURN
-> SAMUEL RETURNS WITH SAUL; SAUL WORSHIPS
-> AGAG SAYS DEATH BITTERNESS PAST
-> SAMUEL EXECUTES AGAG NON-GRAPHICALLY
-> SAMUEL/RAMAH; SAUL/GIBEAH; NO MORE MEETING BEFORE SAUL DEATH
-> SAMUEL MOURNS; LORD GRIEVES MAKING SAUL KING
```

## Verses 1–3 — CARRIED COMMAND

Samuel says LORD sent him to anoint Saul and tells Saul to listen. He carries LORD-of-Armies speech remembering Amalek's action against Israel and commanding Saul to strike Amalek, destroy all, spare none, listing men, women, infants, nursing babies, oxen, sheep, camels and donkeys.

Retain this as direct quoted speech through Samuel and depict the subject matter non-graphically. Do not infer an unrecorded execution detail or moral explanation.

## Verses 4–9 — FORCE / KENITE EXIT / SPARING

Saul summons and counts 200,000 footmen plus 10,000 Judah men at Telaim, ambushes by the valley, and warns Kenites to leave because of retained kindness to Israel. They depart. Saul strikes Amalek from Havilah toward Shur.

Agag is taken alive. The source says all the people are utterly destroyed, while Saul and the people spare Agag and the best sheep, cattle, fat calves, lambs and everything good; they destroy what is vile/refuse. Preserve the source's scoped “all people” statement and the named surviving king without silently harmonizing them.

## Verses 10–15 — COMPLETE CLAIM / AUDIBLE REMAINDER / ACTOR SHIFT

LORD's word tells Samuel it grieves him that he set Saul up as king because Saul turned back and did not perform commandments. Samuel is angry and cries all night. In the morning he is told Saul erected a monument for himself at Carmel and went to Gilgal.

Saul greets Samuel: **“I HAVE PERFORMED THE COMMANDMENT OF THE LORD.”** Samuel asks what the audible sheep bleating and cattle lowing mean.

**COMMAND: DESTROY ALL / SPARE NONE -> SAUL + PEOPLE SPARE AGAG AND BEST LIVESTOCK -> SAUL CLAIMS COMPLETE PERFORMANCE -> RETAINED LIVESTOCK ARE AUDIBLE AND AGAG REMAINS.**

**S185: I COMPLETED ALL OF IT. HERE IS THE PART I KEPT.**

`S185-E001-1SA15` closes when the completion claim meets the audible retained livestock and living Agag. No SKIP. Captain pokes the completion boil, licks his finger, says **“YOINK!”**, and walks away without looking back.

Saul answers that **the people** spared the best for sacrifice and **we** destroyed the rest. The retained source says **Saul and the people** spared them.

**SOURCE ACTORS: SAUL + PEOPLE SPARED -> SAUL REPORT: PEOPLE SPARED.**

This joins `S181`, the actor/report identity series. `S181-E002-1SA15` points with SKIP to `S181-E001-1SA13`; SKIP does nothing. Captain zones out, then after the actor mismatch completes, pokes its boil, licks his finger, says **“YOINK!”**, and leaves. No motive or deliberate blame-shifting is invented.

## Verses 16–23 — COMMAND RESTATED / CLAIM REPEATED

Samuel tells Saul to stay and hear last night's LORD speech. Samuel recalls Saul's small-in-own-sight State, headship/anointing, and command to destroy Amalek until consumed. He asks why Saul did not obey, took plunder and did evil.

Saul repeats that he obeyed, went the sent way, brought Agag and utterly destroyed the Amalekites. His own statement retains the living excluded king while claiming complete obedience/destruction.

`S185-E002-1SA15` points with SKIP to `S185-E001-1SA15`; explanation is omitted, the claim continues, and SKIP changes nothing. After the repeated contradiction closes, Captain says **“YOINK!”** through the standard causally-null poke/lick/walk-away action.

Saul again says **the people** took the plunder/best devoted things for sacrifice. This repeats the source-actor/report mismatch. `S181-E003-1SA15` points with SKIP to `S181-E002-1SA15`; the report continues. After closure, Captain performs another causally-null **“YOINK!”**.

Samuel says obedience/listening is better than sacrifice/fat of rams, compares rebellion/stubbornness to witchcraft/idolatry/teraphim, and says Saul is rejected from being king because he rejected LORD's word. Retain the teraphim footnote as household idols possibly associated with inheritance rights.

## Verses 24–31 — CONFESSION / REFUSAL / RETURN

Saul says he sinned and transgressed because he feared the people and obeyed their voice. This remains Saul's stated explanation; fear mechanism and responsibility allocation are not inferred. He asks pardon and asks Samuel to turn back so he may worship.

Samuel says: **“I WILL NOT RETURN WITH YOU.”** He attributes Saul's rejection from kingship to LORD. As Samuel turns away, Saul grabs his robe skirt and it tears. Samuel uses the tear to say LORD tore the kingdom from Saul that day and gave it to a better neighbor. He says the Strength of Israel will not lie nor repent because he is not a man who should repent.

Saul again says he sinned, asks honor before elders/Israel and asks Samuel to return so he may worship. **Samuel goes back with Saul**, and Saul worships.

**SAMUEL: I WILL NOT RETURN WITH YOU -> SAUL REPEATS REQUEST -> SAMUEL RETURNS WITH SAUL.**

**S186: I WILL NOT RETURN WITH YOU. I RETURNED WITH YOU.**

`S186-E001-1SA15` closes at Samuel's observed return. No SKIP. Captain performs one causally-null **“YOINK!”** and changes neither return nor worship.

The intervening request is retained; no secret motive, permission change or redefinition of “return” is supplied. The robe-to-kingdom analogy is Samuel's speech. Kingdom transfer timing and neighbor identity remain unresolved/unexecuted here.

## Verses 32–35 — AGAG / SEPARATION / GRIEF

Samuel orders Agag brought. Agag comes cheerfully and says surely death's bitterness is past. Samuel cites Agag's sword making women childless and says Agag's mother will be childless. Samuel executes Agag before LORD at Gilgal. Depict the execution restrained and non-graphically.

Samuel goes to Ramah; Saul goes to his Gibeah house. Samuel does not see Saul again before Saul's death, but mourns him. The source again says LORD grieved making Saul king.

Do not equate the source's “grieved” wording with Samuel's different “will not repent” wording without a supplied semantic bridge. Preserve both carriers and the unresolved relation. Do not render divine form.

## Character and world-ledger changes

- NOT-SAUL gains force count, Kenite warning, Amalek action, shared sparing, self-monument, two completion/obedience claims, two people-only attributions, confession/fear explanation, pardon/public-honor requests, worship and final separation.
- NOT-SAMUEL gains carried command, all-night cry, confrontation, obedience-over-sacrifice speech, refusal then return, robe-tear kingdom speech, Agag execution, Ramah separation and mourning.
- NOT-AGAG gains captured-alive State, retained survival through Saul's claims, death-past statement and restrained execution.
- NOT-PEOPLE gain force participation, shared sparing and Saul-attributed plunder/sacrifice purpose.
- NOT-KENITES gain warning/kindness attribution and completed departure.

## Bullshit pass

Issue `1SA-015 / COMPLETION CERTIFICATE WITH LIVE AUDIO`. NOT-SAUL closes **DELETE EVERYTHING** while the excluded livestock provide real-time audio QA. The incident owner changes from **SAUL + PEOPLE** to **PEOPLE**, twice. NOT-SAMUEL issues **RETURN REQUEST DENIED**, then returns on the same ticket. Foundation unchanged.

## FIR verification

- FILTER: all 35 markers retained in order; 1 Samuel 16 excluded.
- ISOLATE: carried command, force/exit/strike/sparing, completion claims/audible remainder, actor-report shifts, judgment/confession/refusal-return, Agag execution and final separation.
- RECONSTRUCT: five valid occurrences across `S181`, `S185`, `S186`.
- VERIFY: three SKIPs point to exact prior episodes and do nothing; five post-closure YOINKs; grief/non-repent and kingdom transfer remain unresolved; publication held.

## Required comic states

1. Samuel carries anointing/listen and destroy-all/spare-none speech.
2. 200,000 + 10,000 count and valley ambush.
3. Kenite warning and departure.
4. Restrained Amalek strike; Agag alive; best livestock spared by Saul + people.
5. LORD grief/nonperformance speech to Samuel; all-night cry.
6. Saul's self-monument route.
7. Saul completion greeting.
8. Audible sheep/cattle and living Agag; S185 E001; YOINK.
9. People-only sparing report versus Saul+people source; S181 E002 SKIP; YOINK.
10. Samuel restates journey/command and asks about plunder.
11. Saul repeats obeyed/Agag brought/Amalekites destroyed; S185 E002 SKIP; YOINK.
12. Saul repeats people-only attribution; S181 E003 SKIP; YOINK.
13. Obedience-over-sacrifice and rejection speech.
14. Saul confession/fear explanation/pardon-return request.
15. Samuel refuses return and states rejection.
16. Robe grab/tear; kingdom/neighbor/not-lie-nor-repent speech.
17. Saul public-honor/return request.
18. Samuel returns; Saul worships; S186; YOINK.
19. Agag death-past speech and restrained execution.
20. Ramah/Gibeah separation; no later meeting; mourning/grief.
21. Held lineage page; 1 Samuel 16 excluded.

## Production boundary

- Use `NOT-` display identities/places; exact names remain in evidence. Every living thing Joe-faced; divine form unrendered.
- Keep all mass violence, children, livestock killing and Agag execution non-graphic and restrained.
- Exactly five contradiction episodes, three SKIPs with exact pointers, five separate boilless/causally-null post-closure Captain poke/lick/**“YOINK!”**/walk-away appearances.
- Preserve source actor sets, audible animal evidence, exact claims, requests and return order. Do not invent motives or semantic repairs.
- Publication held. `CHB-1SA-016` excluded.

*shrug*

OK.
