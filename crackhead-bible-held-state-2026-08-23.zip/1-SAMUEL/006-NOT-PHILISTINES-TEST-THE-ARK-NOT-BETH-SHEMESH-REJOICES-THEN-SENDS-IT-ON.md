# CRACKHEAD 1 SAMUEL 6

## Title page

**NOT-BETH-SHEMESH: “THE ARK IS BACK!” ALSO NOT-BETH-SHEMESH: “WHO CAN TAKE IT FROM US?”**

Source parent: 1 Samuel chapter 6, verses 1–21, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-006/job.json` and `source.usfm`. Parent: 1 Samuel 5.

Display-origin layer: source names remain exact in evidence; comic identities and places use `NOT-`. Every living human, cow, calf, mouse and wheat plant is Joe-faced. The ark, cart, gold images, box and great stone may receive Joe faces as face-like objects without life. NOT-THE-LORD / NOT-GOD remains unrendered.

CrackFlix routing: `S176-E003-1SA6` points exactly to `S176-E002-1SA5`. Its SKIP omits explanation of the already retained danger-transfer relation and changes nothing. Exactly one causally-null post-closure YOINK.

## Causal foundation

```text
ARK IN PHILISTINE COUNTRY SEVEN MONTHS
-> PRIESTS/DIVINERS CALLED FOR RETURN PROCEDURE
-> GOLD TUMORS + GOLD MICE / FIVE-LORD OFFERING
-> NEW CART + TWO UNYOKED MILK COWS / CALVES SHUT HOME
-> DECLARED TEST: COWS TO BETH SHEMESH = HE DID EVIL; OTHERWISE CHANCE
-> MEN EXECUTE TEST
-> COWS GO STRAIGHT TO BETH SHEMESH / LORDS FOLLOW TO BORDER
-> BETH SHEMESH REAPERS SEE ARK / REJOICE
-> CART STOPS AT JOSHUA FIELD / CART WOOD + COWS OFFERED
-> LEVITES SET ARK/BOX ON GREAT STONE / OFFERINGS MADE
-> FIVE LORDS OBSERVE / RETURN TO EKRON
-> GOLD OFFERING/CITY LEDGER + STONE-REMAINS CLOSE
-> NARRATOR: GOD STRIKES MEN WHO LOOKED INTO ARK / 50,070
-> PEOPLE MOURN
-> MEN ASK WHO CAN STAND / TO WHOM HE SHALL GO FROM US
-> MESSENGERS ASK KIRIATH JEARIM TO TAKE ARK
```

## 1 Samuel 6:1–6 — SEVEN MONTHS / RETURN INSTRUCTIONS

The ark remains in Philistine country seven months. The Philistines call priests and diviners and ask what to do and how to send it to its place.

The advisers say not to send it empty: return a trespass offering, then healing and knowledge about the unremoved hand will follow. Asked what offering, they prescribe five golden tumors and five golden mice, one tumor per lord and mice representing those marring the land. They say one plague was on people and lords, advise giving glory to Israel's God, and say **perhaps** his hand will release them, their gods and land.

They invoke Egyptians and Pharaoh hardening their hearts and later letting the people depart. This is adviser speech and historical argument. Healing, release and causal knowledge are predictions, not yet observed outcomes in this chapter.

## 1 Samuel 6:7–12 — THE COW TEST

The advisers specify a new cart and two milk cows never yoked. The cows are tied to the cart while their calves are brought home and shut in. The ark goes on the cart; the gold objects go in a box beside it.

Their declared selector is explicit:

- cows go straight toward Beth Shemesh: **he has done this great evil**;
- otherwise: **his hand did not strike us; chance happened to us**.

The men perform the procedure. The cows take the straight Beth Shemesh road, lowing, turning neither right nor left. The five Philistine lords follow to the border.

By the participants' own declared test, the observed route selects their first branch. That is a test result, not a contradiction. Cow choice, divine control, maternal behavior and physical guidance mechanisms remain unresolved. No private cow reasoning is invented.

## 1 Samuel 6:13–18 — ARRIVAL / OFFERING / OBSERVERS RETURN

Beth Shemesh people reap wheat in the valley. They see the ark and rejoice.

The cart enters the field of Joshua of Beth Shemesh and stops by a great stone. The people split the cart wood and offer the cows as a burnt offering to LORD. Levites lower the ark and gold-object box onto the stone. Beth Shemesh people make burnt offerings and sacrifices that day. Keep animal death non-graphic.

The five Philistine lords see this and return to Ekron the same day.

The source then identifies one golden tumor for each of Ashdod, Gaza, Ashkelon, Gath and Ekron. Golden mice correspond to all fortified cities and country villages under the five lords. Do not collapse the mice count to five: verse 18 defines the wider city/village relation. The great stone remains in Joshua's field to the narrator's day.

## 1 Samuel 6:19–21 — REJOICE / SLAUGHTER / PLEASE TAKE IT

The narrator says God strikes Beth Shemesh men because they looked into LORD's ark: fifty thousand seventy men. The people mourn the great slaughter.

They ask:

**“WHO IS ABLE TO STAND BEFORE THE LORD, THIS HOLY GOD?”**

**“TO WHOM SHALL HE GO UP FROM US?”**

They send messengers to Kiriath Jearim saying the Philistines brought the ark back and asking its inhabitants to come take it up to themselves.

The observable recurrence is:

**COMMUNITY RECEIVES ARK → COMMUNITY IDENTIFIES INTOLERABLE HARM → COMMUNITY ASKS ANOTHER COMMUNITY TO TAKE ARK.**

CrackFlix displays:

**SKIP -> S176-E002-1SA5: HARMFUL HERE / SEND IT TO ANOTHER COMMUNITY.**

SKIP does not prevent the slaughter, send the messengers or move the ark. When the request to Kiriath Jearim completes `S176-E003-1SA6`, Captain pokes the contradiction boil, licks his finger, says **“YOINK!”**, and walks away without looking back. The request and ark State remain unchanged.

The exact 50,070 source count is retained without silently correcting, harmonizing or explaining it. Identities, population basis, looking act details, divine mechanism and body disposition remain unresolved.

## Character and world-ledger changes

- NOT-PHILISTINE JOES retain seven-month custody, adviser consultation, gold offering, cow test and observed return route.
- NOT-PRIEST and NOT-DIVINER JOES gain conditional return instructions and attributed historical reasoning.
- Two NOT-COW JOES pull the new cart straight to Beth Shemesh while lowing; their NOT-CALVES remain shut home.
- Five NOT-PHILISTINE-LORD JOES follow, observe and return to Ekron.
- NOT-BETH-SHEMESH JOES rejoice, unload, sacrifice, suffer narrated slaughter, mourn and request transfer to Kiriath Jearim.
- NOT-LEVITE JOES lower ark and box to the great stone.
- `S176-E003-1SA6` retains the third same-series danger-routing occurrence.

## Bullshit pass

Issue `1SA-006 / COW-POWERED CAUSALITY DETECTOR`. The diagnostic has two outputs: **GOD DID IT** or **RANDOM SHIT**. It passes acceptance testing, is immediately dismantled for firewood, and both biological processors are offered. Foundation unchanged.

## FIR verification

- FILTER: 1 Samuel 6 only; all 21 markers retained in order; 1 Samuel 7 excluded.
- ISOLATE: seven-month State, adviser procedure, conditional test, execution/route, Beth Shemesh reception/offering, source offering ledger, slaughter and onward request.
- RECONSTRUCT: no crack from the successful stated test; one same-series S176 recurrence only after Beth Shemesh asks another community to take the harmful ark.
- VERIFY: one correctly addressed SKIP, one crack and one YOINK; source counts retained; divine/animal mechanisms absent; publication held.

## Required comic states

1. Seven-month ark custody; Philistines call priests/diviners.
2. Advisers prescribe nonempty return, healing/knowledge prediction.
3. Five gold tumors and wider gold-mice/city relation; perhaps-hand-release speech.
4. Egypt/Pharaoh comparison remains adviser speech.
5. New cart, two unyoked milk cows, calves shut home, ark/box loaded.
6. Two-branch Beth Shemesh-versus-chance test displayed before execution.
7. Cows go straight, lowing, no turns; five lords follow.
8. Beth Shemesh harvest Joes see ark and rejoice.
9. Cart stops at great stone; cart split/cows offered, restrained.
10. Levites lower ark/box; same-day offerings.
11. Lords observe/return; five-tumor and all-city/village mice ledger; stone remains.
12. Men look into ark; narrated 50,070 slaughter; mourning, restrained.
13. Who-can-stand/to-whom-go questions.
14. `SKIP -> S176-E002-1SA5`; Kiriath Jearim collection request; one causally-null YOINK.
15. Held lineage page: 1 Samuel 7 excluded.

## Production boundary

- All displayed biblical names/places use `NOT-`; exact identities remain in evidence.
- All living humans, cattle, calves, mice and plants are Joe-faced. Ark/cart/gold objects/stone faces do not establish life. God remains unrendered.
- Keep sacrifice and slaughter restrained/non-graphic. Do not render looking-inside detail beyond the source act.
- Preserve adviser predictions, narrator divine attribution and human conclusions as distinct carriers.
- The cow test succeeds by its stated observable branch; no crack, Captain or SKIP occurs there.
- Exactly one crack after Beth Shemesh identifies the harmful presence and requests another community take it. `SKIP -> S176-E002-1SA5`; exactly one boilless, causally-null Captain: poke, lick, **“YOINK!”**, walk away, no look back.
- Do not infer cow motives, divine steering, disease physics, exact gold-mice total, healing occurrence, population correction or slaughter mechanism.
- Publication held. `CHB-1SA-007` excluded.

*shrug*

OK.
