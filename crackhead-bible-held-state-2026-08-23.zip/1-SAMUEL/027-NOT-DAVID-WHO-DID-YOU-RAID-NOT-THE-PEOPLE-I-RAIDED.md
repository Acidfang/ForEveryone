# CRACKHEAD 1 SAMUEL 27

## Title field

**NOT-ACHISH: WHO DID YOU RAID? NOT-DAVID: NOT THE PEOPLE I RAIDED.**

Source parent: 1 Samuel chapter 27, verses 1–12, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-027/job.json` and `source.usfm`. Parent: 1 Samuel 26. Exact identities remain in evidence; comic display uses `NOT-` identities. Every living thing is Joe-faced, including livestock. Raids and deaths remain non-graphic.

CrackFlix: new `S202-E001-1SA27`. No SKIP because this is the first retained occurrence. Exactly one causally-null post-closure YOINK.

Production format: one high-resolution compound-eye field. All required changed States appear simultaneously in addressed facets while the ledger below preserves causal order.

## Causal foundation

```text
DAVID'S HEART: SAUL WILL ONE DAY KILL ME
-> DAVID SELECTS PHILISTINE ESCAPE / PREDICTS SAUL WILL STOP SEEKING
-> DAVID + 600 MEN + HOUSEHOLDS + TWO WIVES CROSS TO ACHISH AT GATH
-> SAUL IS TOLD / STOPS SEEKING DAVID
-> DAVID REQUESTS COUNTRY CITY
-> ACHISH GIVES ZIKLAG
-> DAVID LIVES IN PHILISTINE COUNTRY 1 YEAR + 4 MONTHS
-> DAVID + MEN RAID GESHURITES / GIRZITES / AMALEKITES
-> NO MAN OR WOMAN LEFT ALIVE / LIVESTOCK + CLOTHING TAKEN
-> DAVID RETURNS TO ACHISH
-> ACHISH ASKS WHO WAS RAIDED
-> DAVID NAMES SOUTH JUDAH / JERAHMEELITES / KENITES
-> ACTUAL TARGET SET != REPORTED TARGET SET
-> DAVID RETAINS NO WITNESSES TO REPORT HIS ACTS
-> ACHISH BELIEVES DAVID
-> ACHISH DERIVES ISRAEL ABHORS DAVID / DAVID WILL SERVE FOREVER
```

## Verses 1–4 — HEART MODEL / CROSSING / SAUL STOPS

David says in his heart that Saul will one day kill him, that nothing is better than escape to Philistine land, and that Saul will stop seeking him throughout Israel so he will escape Saul's hand. This is directly supplied private speech; it is not an externally verified inevitable death.

David, six hundred men, their households, Ahinoam and Abigail cross to Achish king of Gath and live there. Saul is told David fled to Gath and stops looking for him. The selected escape route produces David's predicted stop-seeking State. No contradiction closes in this chain.

## Verses 5–7 — ZIKLAG / ONE YEAR FOUR MONTHS

David asks Achish for a country-city residence rather than the royal city. Achish gives him Ziklag that day. Narration says Ziklag therefore belongs to Judah's kings to the source's “this day.” David's Philistine-country residence lasts one full year and four months. The property mechanism beyond Achish's gift and the narrator's later possession statement remains unstated.

## Verses 8–9 — ACTUAL RAIDS / NO LIVING WITNESSES

David and his men raid the Geshurites, Girzites and Amalekites, described as old inhabitants toward Shur and Egypt. David strikes the land, leaves no man or woman alive, takes sheep, cattle, Joe-faced donkeys, Joe-faced camels and clothing, then returns to Achish.

The source states the raid and survivor outcomes but supplies no individual battle sequence, victim speech, divine command or moral explanation. Production remains non-graphic.

## Verses 10–12 — DIFFERENT REPORT / BELIEF / PERMANENT-SERVICE CONCLUSION

Achish asks whom David raided that day. David answers: the South of Judah, the South of the Jerahmeelites, and the South of the Kenites. Those are not the three populations named as the actual raid targets.

Narration repeats that David leaves no man or woman alive to bring to Gath and gives David's expressed purpose: they might otherwise report what he did. This retained purpose explains witness removal without changing the actual-target/reported-target mismatch.

The completed mismatch closes new `S202-E001-1SA27`: **ACTUAL RAIDS—GESHURITES / GIRZITES / AMALEKITES. REPORT TO ACHISH—SOUTH JUDAH / JERAHMEELITES / KENITES.** No SKIP. Captain's separate post-closure compound-eye facet shows the boilless first-person poke, empty finger, **“YOINK!”**, lick and walk-away. Nothing in the raid, report, belief or residence changes.

Achish believes David and says David made Israel utterly abhor him, therefore David will be Achish's servant forever. Israel's hatred and permanent service are Achish's derived current/future model; neither is independently observed here.

## Character and world-ledger changes

- NOT-DAVID gains private Saul-death/escape model, completed Gath crossing, Ziklag residence, repeated raids, zero-survivor policy, different-target reporting and witness-report prevention purpose.
- NOT-SAUL gains report-received and stopped-seeking States, closing the immediate prediction without proving permanent future non-pursuit.
- NOT-ACHISH gains household admission, Ziklag gift, raid-question, belief and permanent-servant conclusion.
- NOT-AHINOAM, NOT-ABIGAIL, six hundred NOT-MEN and households gain Gath/Ziklag residence.
- Geshurite, Girzite and Amalekite populations gain non-graphic raid/no-survivor States; livestock and transport animals remain Joe-faced.

## Bullshit pass

Issue `1SA-027 / CUSTOMER LOCATION ANALYTICS`. NOT-DAVID relocates the entire account to NOT-ACHISH hosting. The Saul crawler stops indexing him. NOT-DAVID then submits three daily **RAID TARGET** values that do not match the production logs and deletes every human audit carrier before sync. NOT-ACHISH marks the dashboard **TRUSTED / SERVANT FOREVER**. CrackFlix saves the actual query results. Foundation unchanged.

## FIR verification

- FILTER: all 12 verse markers retained; 1 Samuel 28 excluded.
- ISOLATE: private model, crossing, Saul stop, city request/gift, residence duration, actual raids, survivor removal, reported targets, belief and future service conclusion.
- RECONSTRUCT: one new actual-act/reported-act target mismatch; witness removal is retained purpose, not correction.
- VERIFY: `S202-E001-1SA27`, zero SKIP, one post-closure YOINK; Israel hatred/permanent service remain Achish's model; publication held.

## Required compound-eye facets

1. David's heart speech: Saul-death prediction / Philistine escape selection / stop-seeking prediction.
2. David, 600 men, households and two wives cross to Achish at Gath.
3. Saul receives flight report and stops seeking David.
4. David requests country city / Achish gives Ziklag.
5. One-year-four-month residence and retained Ziklag/Judah-kings statement.
6. Actual raid targets: Geshurites / Girzites / Amalekites.
7. Non-graphic no-survivor State and livestock/clothing removal; all living animals Joe-faced.
8. David returns / Achish asks whom he raided.
9. David reports South Judah / Jerahmeelites / Kenites.
10. `S202-E001`: actual-target set beside different reported-target set; no SKIP; separate post-closure YOINK.
11. No-witness/report-prevention purpose / Achish belief / Israel-abhor and servant-forever model; chapter 28 excluded.

All eleven addressed facets appear simultaneously in one zoomable compound-eye image. Facet numbers preserve causal traversal; no facet is a separate linear page.

## Production boundary

One actual high-resolution compound-eye image with 11 addressed facets. `NOT-` display; every living thing Joe-faced; raids/deaths non-graphic. One new episode `S202-E001-1SA27`, no SKIP and one separate boilless first-person causally-null YOINK facet. Preserve David's heart words as source-supplied private speech, Saul's stopping as observed, actual and reported target sets exactly, witness removal purpose, and Achish's hatred/permanent-service conclusion as his model. No invented battle, divine form/command, moral judgment or later outcome. Originator visual review required; publication held.

*shrug*

OK.
