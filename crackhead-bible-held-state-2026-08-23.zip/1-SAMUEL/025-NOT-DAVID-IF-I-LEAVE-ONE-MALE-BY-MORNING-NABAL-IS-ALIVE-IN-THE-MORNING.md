# CRACKHEAD 1 SAMUEL 25

## Title field

**NOT-DAVID: IF I LEAVE ONE MALE BY MORNING—NOT-NABAL IS ALIVE IN THE MORNING.**

Source parent: 1 Samuel chapter 25, verses 1–44, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-025/job.json` and `source.usfm`. Parent: 1 Samuel 24. Exact identities remain in evidence; comic display uses `NOT-` identities. Every living thing is Joe-faced, including animals. LORD acts only where source narration directly supplies it; divine form remains unrendered. Threats, death and bloodguilt remain non-graphic.

CrackFlix: repeated `S201-E002-1SA25`, with exact `SKIP -> S201-E001-1SA22`. Exactly one causally-null post-closure YOINK.

Production format: one high-resolution compound-eye field. All required changed States appear simultaneously in addressed facets while the ledger below preserves their causal order.

## Causal foundation

```text
SAMUEL DIES / ISRAEL MOURNS / BURIAL AT RAMAH
-> DAVID MOVES TO PARAN
-> NABAL HAS 3,000 SHEEP / 1,000 GOATS / SHEARING FEAST
-> DAVID SENDS TEN MEN WITH PEACE/GIFT REQUEST
-> MEN REPORT NO HARM/NO LOSS AND ASK WHATEVER COMES TO HAND
-> NABAL IDENTIFIES DAVID/SON OF JESSE RHETORICALLY
-> REFUSES HIS BREAD/WATER/MEAT TO UNKNOWN-ORIGIN MEN
-> DAVID ORDERS SWORDS / 400 FOLLOW / 200 GUARD BAGGAGE
-> SERVANT REPORTS TO ABIGAIL: INSULT + DAVID'S MEN WERE A WALL
-> ABIGAIL LOADS LARGE FOOD GIFT / DOES NOT TELL NABAL
-> DAVID: PROTECTION WAS VAIN / EVIL RETURNED FOR GOOD
-> DAVID OATH: IF ONE MALE IS LEFT BY MORNING, CURSE
-> ABIGAIL MEETS DAVID / TAKES BLAME / PRESENTS FOOD
-> ABIGAIL ATTRIBUTES LORD WITHHOLDING BLOODGUILT
-> ABIGAIL SPEAKS FUTURE HOUSE/LIFE/KINGSHIP/NO-EVIL STATES
-> DAVID BLESSES LORD/ABIGAIL / ACCEPTS SHE STOPPED BLOODGUILT
-> DAVID RECEIVES GIFT / GRANTS REQUEST / ABIGAIL RETURNS
-> NABAL FEASTING/VERY DRUNK / ABIGAIL WAITS UNTIL MORNING
-> NABAL ALIVE IN MORNING / HEARS EVENTS / HEART DIES/STONE STATE
-> ABOUT TEN DAYS LATER LORD STRIKES NABAL / HE DIES
-> DAVID ATTRIBUTES JUDGMENT/RESTRAINT TO LORD
-> DAVID PROPOSES THROUGH SERVANTS / ABIGAIL ACCEPTS
-> ABIGAIL BECOMES DAVID'S WIFE
-> AHINOAM ALSO DAVID'S WIFE
-> SAUL HAS GIVEN MICHAL, CALLED DAVID'S WIFE, TO PALTI
```

## Verses 1–3 — SAMUEL / PARAN / NABAL AND ABIGAIL

Samuel dies. All Israel gathers, mourns and buries him at his house in Ramah. David moves to Paran.

Nabal is a very great Maon man with Carmel possessions, three thousand sheep and one thousand goats, currently shearing. Narration calls Abigail intelligent and beautiful-faced, and Nabal surly and evil in his doings. Both retain the same Joe facial identity; the supplied descriptors belong to their roles and acts, not different human faces.

## Verses 4–12 — PEACE REQUEST / REFUSAL

David hears of shearing and sends ten young men. His exact message offers long life and threefold peace, says Nabal's shepherds were unharmed and lost nothing while with David's group, invites Nabal to ask his own men, and requests whatever comes to hand for David's servants and “son David.” The messengers deliver all the words and wait.

Nabal asks **“WHO IS DAVID? WHO IS THE SON OF JESSE?”**, refers to servants breaking from masters, and refuses to take his bread, water and shearer meat for men whose origin he says he does not know. The questions can be rhetorical because he identifies Jesse; they are not converted into an ignorance contradiction.

The messengers return and repeat all the words.

## Verses 13–17 — SWORDS / SERVANT REPORT

David orders every man to put on his sword. David and the men comply. About four hundred follow; two hundred remain with baggage. No attack has happened yet.

One young man tells Abigail that David's messengers greeted Nabal and Nabal insulted them. He says David's men were very good, harmed nobody, allowed no loss, and were a wall night and day around the shepherds. He says evil is determined against Nabal and the house and describes Nabal as impossible to speak to. These are the servant's observed/reporting boundaries; his motive and knowledge source beyond supplied interaction remain unresolved.

## Verses 18–20 — ABIGAIL'S GIFT / HIDDEN DEPARTURE

Abigail rapidly loads two hundred loaves, two wine containers, five dressed sheep, five seahs of parched grain, one hundred raisin clusters and two hundred fig cakes onto Joe-faced donkeys. She sends young men ahead, follows, and does not tell Nabal.

She descends hidden by the mountain and meets David and his men coming toward her. No divine dispatch is narrated at this point.

## Verses 21–22 — DAVID'S UNIVERSAL MORNING OATH

David says guarding Nabal's property was vain because Nabal returned evil for good. He invokes God against David's enemies and more if, by morning light, he leaves alive **even one male** belonging to Nabal.

This is a universal death outcome for an exact household class with a morning deadline. The threat remains non-graphic. The crack cannot close until the deadline's survivor State exists.

## Verses 23–31 — ABIGAIL INTERVENES

Abigail dismounts, bows, takes blame onto herself, asks to speak, calls Nabal worthless/foolish by name, and says she did not see David's messengers.

She swears by LORD and David's life that LORD has withheld David from bloodguilt and self-avenging. Her arrival and speech are already occurring, but David has not yet accepted her request. The withholding attribution is not treated as an independently observed divine mechanism.

She offers the food to David's followers, asks forgiveness, and speaks of a sure house, LORD's battles, evil never found in David, David's life bound with LORD, enemies slung out, future appointment over Israel, and future freedom from grief caused by causeless bloodshed/self-vengeance. These remain Abigail's future and theological speech. No kingship, permanent moral status or divine sling act is imported here.

## Verses 32–35 — ACCEPTED RESTRAINT / REQUEST GRANTED

David blesses LORD, whom he says sent Abigail, then blesses her discretion and her. He says she kept him from bloodguilt and self-vengeance. He adds that LORD withheld him from harming her and that without her hurried arrival no male would have remained to Nabal by morning.

David receives the gift, says he listened, grants her request, and sends her home in peace. The selected killing act is changed before execution. That change does not erase the exact oath uttered earlier.

## Verses 36–38 — MORNING SURVIVOR / TEN DAYS / DEATH

Abigail finds Nabal holding a king-like feast, merry and very drunk, so she tells him nothing until morning.

In the morning, after the wine leaves him, **Nabal is alive** and Abigail tells him the events. His heart dies within him and he becomes like stone. The mechanism/medical classification is not supplied.

The morning survivor closes repeated `S201-E002-1SA25`: David swore a universal no-male-left outcome by morning, but the head of the addressed house is observed alive at that deadline. Exact **SKIP -> S201-E001-1SA22**. SKIP changes nothing. Captain's post-closure facet shows one boilless first-person poke, empty finger, **“YOINK!”**, lick and walk-away; Nabal's State continues unchanged by Captain.

About ten days later, narration says LORD strikes Nabal and he dies. No divine form or physical mechanism is rendered. Later death does not erase the earlier morning survivor Moment or repair David's deadline.

## Verses 39–44 — ATTRIBUTION / MARRIAGES / MICHAL TRANSFER

David hears Nabal died and blesses LORD, attributing pleading of his reproach, restraint from evil and return of Nabal's evildoing to LORD. The narrator directly supplies only LORD striking Nabal; David's broader causal interpretation remains his speech.

David sends servants to propose taking Abigail as wife. They deliver the proposal. Abigail bows, offers service, rises quickly with five maids, follows, and becomes David's wife. David also takes Ahinoam; both are his wives.

Saul has given Michal—still identified by the narrator as David's wife—to Palti son of Laish. The source does not state the transfer's legal mechanism or explicitly label Palti's role here; do not infer a second marriage, consent, divorce or resolved David–Michal status beyond the exact words.

## Character and world-ledger changes

- NOT-SAMUEL gains completed death, national mourning and Ramah burial.
- NOT-DAVID gains food request, armed retaliation order/oath, Abigail encounter, changed act, gift acceptance, bloodguilt-restraint attribution, Nabal-death interpretation and two wife acquisitions.
- NOT-NABAL gains refusal, feast/drunken State, morning survival/stone-like State and narrator-attributed LORD strike/death.
- NOT-ABIGAIL gains servant report, undisclosed gift transport, blame-taking intervention, extensive future speech, accepted request, morning disclosure and marriage acceptance.
- NOT-SERVANT gains protection/insult report; NOT-MEN gain message, sword, march, baggage and gift-recipient States.
- NOT-MICHAL gains transfer-by-Saul State while exact narrator identity remains David's wife; NOT-PALTI gains recipient State only.

## Bullshit pass

Issue `1SA-025 / MORNING SLAUGHTER SERVICE CANCELLED AFTER CATERING ARRIVES`. NOT-DAVID converts an unpaid **WILDERNESS LOSS-PREVENTION INVOICE** into a universal household deletion oath. NOT-ABIGAIL submits **200 LOAVES + 2 WINE + 5 SHEEP + 5 SEAHS + 100 RAISINS + 200 FIGS**, changing the selected act. CrackFlix checks the next morning: customer NOT-NABAL remains irritatingly alive. **SKIP -> S201-E001-1SA22.** Nothing skips. Foundation unchanged.

## FIR verification

- FILTER: all 44 markers retained; 1 Samuel 26 excluded.
- ISOLATE: Samuel closure, Nabal property/shearing, request/refusal, armed route, servant report, Abigail gift/intervention, David oath/change, morning survivor, later LORD strike/death and marriage/transfer closures.
- RECONSTRUCT: one repeated universal-death/survivor episode; later death does not repair the missed morning deadline.
- VERIFY: one exact SKIP, one YOINK; future Abigail claims unexecuted; divine form absent; marital mechanisms unresolved; publication held.

## Required compound-eye facets

1. Samuel death / mourning / Ramah burial / David to Paran.
2. Nabal wealth/shearing and narrator role descriptions for Nabal/Abigail.
3. David composes peace/protection/gift request and sends ten men.
4. Messengers deliver and wait.
5. Nabal Who-is-David/servant/refusal speech.
6. Return report / David orders swords / 400 move and 200 remain.
7. Young servant reports insult, no harm/no loss and wall protection to Abigail.
8. Abigail assembles exact gift on Joe-faced donkeys without telling Nabal.
9. Mountain-hidden approach / parties meet.
10. David protection-was-vain/evil-for-good speech.
11. David universal no-male-left-by-morning oath.
12. Abigail bows/takes blame/Nabal-name and unseen-messengers speech.
13. Abigail LORD-withheld/gift/forgiveness/future-house-life-kingship speech.
14. David blesses LORD/Abigail and accepts she prevented bloodguilt.
15. Gift accepted / request granted / Abigail returns.
16. Nabal king-like feast/very drunk / Abigail waits.
17. Morning: Nabal alive, receives report, heart/stone State; `S201-E002`, exact SKIP and separate post-closure YOINK.
18. About ten days later: unrendered LORD strike / Nabal dies.
19. David hears and supplies LORD judgment/restraint interpretation.
20. Proposal delivered / Abigail accepts and becomes David's wife.
21. Ahinoam also wife / Michal called David's wife and given by Saul to Palti; mechanism unresolved.
22. Held lineage facet; chapter 26 excluded.

All twenty-two addressed facets appear simultaneously in one zoomable compound-eye image. Facet numbers preserve causal traversal; no facet is a separate linear page.

## Production boundary

One actual high-resolution compound-eye image with 22 addressed facets. `NOT-` display; every living thing Joe-faced; no divine form; non-graphic threat/death/bloodguilt; restrained feast/drunkenness. One repeated episode, exact `SKIP -> S201-E001-1SA22`, one separate boilless first-person causally-null YOINK facet. Do not invent Nabal ignorance, protection contract, Abigail motive, divine dispatch/withholding mechanics, future kingship, moral permanence, heart medical mechanism, marital consent/divorce/Palti role or later chapter outcomes. Originator visual review required; publication held.

*shrug*

OK.
