# CRACKHEAD 1 SAMUEL 14

## Title page

**NOT-SAUL: NOBODY EATS UNTIL I AM AVENGED. THE FIGHTERS FAINT AND EAT WITH BLOOD.**

Source parent: 1 Samuel chapter 14, verses 1–52, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-1SA-014/job.json` and `source.usfm`. Parent: 1 Samuel 13.

Exact source identities remain in evidence; comic display uses `NOT-` identities and places. Every living human, animal and plant is Joe-faced. Face-like objects may receive Joe faces without life. NOT-THE-LORD / NOT-GOD remains unrendered.

CrackFlix routing: new series `S183` and `S184`; no SKIP; exactly two distinct causally-null post-closure YOINKs.

## Causal foundation

```text
JONATHAN PRIVATELY LEAVES WITH ARMOR BEARER
-> DECLARES WAIT / COME-UP RESPONSE TEST
-> PHILISTINES SAY COME UP
-> JONATHAN INTERPRETS DELIVERY; PAIR STRIKES ABOUT 20
-> TREMBLING / EARTHQUAKE / SCATTERING / INTERNAL PHILISTINE SWORDS
-> HEBREWS AND HIDDEN ISRAEL JOIN PURSUIT
-> NARRATOR: LORD SAVED ISRAEL THAT DAY
-> SAUL CURSES EATING BEFORE EVENING / VENGEANCE
-> PEOPLE DO NOT EAT HONEY; THEY FAINT
-> UNAWARE JONATHAN EATS HONEY; EYES BRIGHTEN
-> PEOPLE BECOME VERY FAINT AND EAT LIVESTOCK WITH BLOOD
-> SAUL CALLS IT SIN AND INSTALLS STONE/SLAUGHTER ROUTE
-> SAUL ASKS COUNSEL; NO ANSWER
-> DECLARES GUILTY PERSON DIES, EVEN JONATHAN
-> LOT SELECTS JONATHAN; HE CONFESSES HONEY
-> SAUL SAYS JONATHAN SURELY DIES
-> PEOPLE RESCUE JONATHAN; HE DOES NOT DIE
-> PURSUIT STOPS; FINAL KINGDOM/WAR/FAMILY/RECRUITMENT STATE
```

## Verses 1–5 — PRIVATE DEPARTURE / POSITIONS

Jonathan privately crosses toward the Philistine garrison with his armor bearer and does not tell Saul. Saul remains near Gibeah under the pomegranate tree with about 600. Retain Ahijah's genealogy, priest/ephod role, the people's lack of knowledge, Bozez/Seneh and the Michmash/Geba positions. No motives added.

## Verses 6–14 — DECLARED TEST / FIRST ACTION

Jonathan says LORD may work for them and is not restrained to save by many or few. The armor bearer supports him. Jonathan declares: if the Philistines say wait, remain; if they say come up, go and interpret delivery. They reveal themselves; the Philistines call them up. Jonathan interprets the response, climbs on hands and feet, and the armor bearer follows. About twenty fall in the first restrained, non-graphic action.

This is Jonathan's declared selector. Its matching outcome does not independently prove divine causation or a general test mechanism.

## Verses 15–23 — TREMBLING / COUNT / CONFUSION / PURSUIT

Trembling occurs through camp, field, people, garrison and raiders; the earth quakes. Watchmen see melting/scattering. A count reveals Jonathan and armor bearer missing. Saul requests God's ark; as tumult grows while he speaks to the priest, Saul says withdraw the hand. Saul's group sees every Philistine sword against his fellow amid great confusion. Hebrews formerly with Philistines and hidden hill-country Israelites join pursuit. Narration says LORD saved Israel that day; battle passes Beth Aven.

The quake mechanism, ark/priest inquiry operation, interruption effect and divine form remain unresolved.

## Verses 24–35 — NO FOOD / FAINT / EAT WITH BLOOD

Israel is distressed because Saul curses anyone eating before evening, until he is avenged. Nobody tastes food. Forest honey is visible, but the people do not eat because they fear the oath. Jonathan did not hear it; he dips his rod in honey, eats, and his eyes brighten. A man reports the oath and the people's faintness. Jonathan says his father troubled the land and says more eating would have enabled a greater strike.

After striking from Michmash to Aijalon, the people are very faint. They rush sheep, cattle and calves, kill them on the ground and eat with blood. Saul receives the sin report, calls them treacherous, installs a large-stone slaughter route, and the people thereafter kill and eat without blood. Saul builds his first altar.

**RULE WITHHOLDS FOOD FOR VENGEANCE -> FIGHTERS FAINT -> FAINT FIGHTERS PRODUCE THE EATING-WITH-BLOOD STATE THE RULE-MAKER CALLS SIN.**

**S183: STARVE THE FIGHTERS FOR VICTORY. FIX THE EATING DISASTER.**

`S183-E001-1SA14` closes when the people eat with blood after observed no-food compliance and faintness. Captain pokes the physical boil, licks his finger, says **“YOINK!”**, and walks away without looking back. He changes nothing.

Do not infer Saul intended the result or that hunger is its only possible cause. Retain the observed order and Saul's correction.

## Verses 36–46 — DEATH DECLARED / SELECTED / RESCUED

Saul proposes night pursuit; the people assent and the priest says draw near God. Saul asks whether to pursue and whether Philistines will be delivered. No answer comes that day.

Saul calls chiefs to identify sin and declares that even if it is Jonathan, the guilty person shall die. Nobody answers. Israel is separated from Saul/Jonathan; Saul/Jonathan are selected, then Jonathan is selected by lot. Jonathan confesses tasting a little honey and says he must die. Saul says Jonathan shall surely die. The people say Jonathan, who worked the great salvation, shall not die; they rescue him and he does not die.

**GUILTY PERSON DIES, EVEN JONATHAN -> LOT SELECTS JONATHAN -> CONFESSION -> SURELY-DIES DECLARATION -> PEOPLE RESCUE JONATHAN -> HE DOES NOT DIE.**

**S184: EVEN JONATHAN MUST DIE. JONATHAN DOES NOT DIE.**

`S184-E001-1SA14` closes at the rescue/nondeath. Captain pokes the physical boil, licks his finger, says **“YOINK!”**, and walks away without looking back. He changes nothing.

No divine endorsement of Saul's sin theory, the lot, execution or rescue is inferred. The no-answer relation, lot mechanism and people's “worked with God” claim remain distinct. Saul stops pursuing; Philistines return.

## Verses 47–52 — KINGDOM / WARS / FAMILY / RECRUITMENT

Saul takes the kingdom and fights Moab, Ammon, Edom, Zobah's kings and Philistines; wherever he turns he defeats. He strikes Amalek and delivers Israel from plunderers. Retain sons Jonathan/Ishvi/Malchishua; daughters Merab/Michal; wife Ahinoam daughter of Ahimaaz; captain Abner son of Ner, Saul's uncle; Kish father of Saul; Ner father of Abner and son of Abiel. Philistine war remains severe throughout Saul's days, and Saul recruits every mighty/valiant man he sees. Do not replay unspecified battles or merge later identities.

## Character and world-ledger changes

- NOT-JONATHAN: private sortie, response test, first action, honey ignorance/eating, brightened eyes, assessment, lot selection, confession, rescue.
- NOT-ARMOR-BEARER: support, climb/follow, first-action participation.
- NOT-SAUL: inquiry interruption, pursuit, oath, correction route/first altar, no-answer inquiry, death declarations, stopped pursuit, kingdom-war-family/recruitment.
- NOT-ISRAEL: pursuit joins, oath observance, faintness, blood-eating, corrected slaughter, lot participation, Jonathan rescue.
- NOT-PHILISTINES: response, trembling/scattering/internal swords, retreat and later war State.

## Bullshit pass

Issue `1SA-014 / FASTING-ENABLED COMBAT + EXECUTIVE DEATH EXCEPTION`. **NO CALORIES UNTIL REVENGE™** puts the army in low-power mode and produces a blood-compliance incident. The **EVEN MY SON** policy selects the boss's son and closes as **SON RETAINED**. Foundation unchanged.

## FIR verification

- FILTER: all 52 markers in order; 1 Samuel 15 excluded.
- ISOLATE: sortie/test/battle; oath/no-food/faintness/blood-eating/correction; no-answer/lot/death/rescue; final ledger.
- RECONSTRUCT: two distinct contradictions.
- VERIFY: two new episodes, zero SKIPs, two YOINKs; unresolved mechanisms retained; publication held.

## Required comic states

1. Private departure; Saul/about-600/Ahijah/people-unaware.
2. Crags and positions.
3. Many/few speech and armor-bearer support.
4. Wait/come-up selector.
5. Come-up response, interpretation and climb.
6. Restrained about-twenty action.
7. Trembling/earthquake/scattering.
8. Watch/count; missing pair.
9. Ark request, tumult, withdraw hand.
10. Internal swords/confusion and pursuit joins.
11. Narrator LORD-saved attribution, no form.
12. Cursed no-food oath.
13. Honey untouched; people faint.
14. Jonathan eats unaware; eyes brighten; oath reported.
15. Jonathan assessment.
16. Extended strike; very faint.
17. Eat with blood; S183 closes; first YOINK.
18. Saul's correction route and first altar.
19. Night-pursuit proposal and priest statement.
20. Counsel request; no answer.
21. Even-Jonathan death declaration and separation.
22. Lot selects Jonathan; confession.
23. Saul's surely-dies declaration.
24. Rescue/nondeath; S184 closes; second YOINK.
25. Pursuit stop/return.
26. Kingdom/enemy/family/captain/recruitment ledger.
27. Held lineage page; 1 Samuel 15 excluded.

## Production boundary

- Display `NOT-` names; retain exact names in evidence. All living things Joe-faced; object faces do not establish life; LORD/God unrendered.
- Exactly two contradictions, no SKIP, exactly two boilless causally-null Captain appearances after closure: poke, lick finger, **“YOINK!”**, walk away, no look back.
- Restrained, non-graphic combat/slaughter/blood depiction.
- Preserve test, oath chain and lot/rescue order without invented mechanisms, motives or divine approval.
- Publication held. `CHB-1SA-015` excluded.

*shrug*

OK.
