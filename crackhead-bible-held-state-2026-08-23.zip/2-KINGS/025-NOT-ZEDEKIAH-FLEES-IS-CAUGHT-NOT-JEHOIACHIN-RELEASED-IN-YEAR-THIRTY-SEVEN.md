# CRACKHEAD 2 KINGS 25

## Title field

**NOT-ZEDEKIAH: FLEES, IS CAUGHT, JUDGED, BLINDED AND TAKEN. / NOT-JEHOIACHIN: RELEASED IN CAPTIVITY YEAR THIRTY-SEVEN.**

Source chapter 25 parent: ENGWEBP 2 Kings 25:1-30, retained at `.chapter-work/CHB-2KI-025/source.usfm` with SHA-256 `b13d8f8f825005f9010dafc10830c2516dd599312c3279e662daa0b43aaad5d5`; canonical book source SHA-256 `e4ade265a98ed78b4f0fe9f24889a9aac013ff1b20e7948ec6d314fee9f45704`. Parent manuscript: 2 Kings 24. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: zero closed contradiction occurrences, no SKIP and no Captain/YOINK. One high-resolution 30-facet compound-eye image; violence remains restrained and non-graphic.

## Causal foundation

```text
NEBUCHADNEZZAR + ARMY ENCAMP / BUILD FORTS
-> JERUSALEM BESIEGED TO ZEDEKIAH YEAR 11
-> SEVERE FAMINE / NO BREAD
-> CITY BREACHED
-> WAR MEN + KING FLEE AT NIGHT
-> CHALDEAN ARMY PURSUES / OVERTAKES ZEDEKIAH
-> ARMY SCATTERS
-> ZEDEKIAH CAPTURED / TAKEN TO RIBLAH / JUDGED
-> SONS KILLED BEFORE HIM
-> ZEDEKIAH BLINDED / BOUND / TAKEN TO BABYLON
-> NEBUZARADAN BURNS HOUSES
-> CHALDEAN ARMY BREAKS WALLS
-> CITY REMNANT/DESERTERS/MULTITUDE DEPORTED
-> SOME POOREST PEOPLE LEFT FOR VINEYARDS/FIELDS
-> TEMPLE BRONZE/GOLD/SILVER OBJECTS BROKEN OR TAKEN
-> NAMED RELIGIOUS/MILITARY/CIVIC GROUP TAKEN TO RIBLAH
-> BABYLON KING PUTS THEM TO DEATH
-> GEDALIAH MADE GOVERNOR OVER REMNANT
-> FORCE CAPTAINS/MEN COME TO GEDALIAH
-> GEDALIAH SWEARS: LIVE/SERVE/WELL
-> ISHMAEL + TEN KILL GEDALIAH/JUDEANS/CHALDEANS AT MIZPAH
-> PEOPLE + CAPTAINS FLEE TO EGYPT FROM FEAR
-> YEAR 37 OF JEHOIACHIN CAPTIVITY
-> EVILMERODACH RELEASES HIM
-> KIND SPEECH / THRONE ABOVE OTHER KINGS
-> PRISON CLOTHES CHANGED / CONTINUAL TABLE BREAD + DAILY ALLOWANCE
```

## Verses 1-7 — Siege, breach, flight and Zedekiah's capture

On Zedekiah's ninth-year, tenth-month, tenth-day date, Nebuchadnezzar and all his army encamp against Jerusalem and build surrounding forts. The siege continues to Zedekiah's eleventh year. On the ninth day of the fourth month famine is severe and the land people have no bread.

A city breach occurs. All war men flee by night through the gate between two walls near the king's garden while Chaldeans surround the city; the king goes toward the Arabah. The Chaldean army pursues and overtakes Zedekiah on Jericho's plains while his army scatters. They capture him, take him to Babylon's king at Riblah and pass judgment.

Zedekiah's sons are killed before his eyes; his eyes are then put out, he is bound in fetters and carried to Babylon. Depiction is non-graphic. The source does not supply the individual judge speakers, judgment words, sons' identities/count, breach maker, flight plan or causal mechanism from famine to breach.

## Verses 8-17 — Burning, walls, deportation and temple inventory

In Nebuchadnezzar's nineteenth year, fifth month, seventh day, guard captain and royal servant Nebuzaradan comes to Jerusalem. He burns LORD's house, the king's house and every great Jerusalem house. The accompanying Chaldean army breaks the surrounding walls.

Nebuzaradan deports the city remnant, those who deserted to Babylon's king and the remaining multitude, while leaving some poorest land people to work vineyards and fields. This is a new later remnant selection and does not erase the poorest-person remainder recorded in chapter 24.

Chaldeans break the two bronze pillars, bases and bronze sea and carry the pieces to Babylon. Pots, shovels, snuffers, spoons, bronze service vessels, fire pans, basins and their gold/silver material classes are taken. The two pillars, one sea and bases have unweighed bronze. One pillar is eighteen cubits high with a three-cubit bronze capital, network and pomegranates; the second is like it. Manufactured objects remain faceless.

## Verses 18-21 — Selected people taken and killed

Nebuzaradan takes chief priest Seraiah, second priest Zephaniah, three threshold keepers, one war-men officer, five king-face men, the mustering army scribe and sixty land people found in the city. He brings them to Babylon's king at Riblah. That king attacks and puts them to death there; Judah is carried captive from the land.

The selected list remains exact. It is not expanded to every priest, officer, scribe or remaining person, and “Judah was carried captive” does not erase the explicit land remnant introduced next.

## Verses 22-26 — Gedaliah government, killing and flight

Nebuchadnezzar makes Gedaliah son of Ahikam son of Shaphan governor over the Judah people left in the land. Named force captains and their men hear and come to him at Mizpah: Ishmael son of Nethaniah, Johanan son of Kareah, Seraiah son of Tanhumeth the Netophathite, Jaazaniah son of the Maacathite, and their men.

Gedaliah swears that they should not fear Chaldean servants, should dwell in the land and serve Babylon's king, and that it will be well with them. In the seventh month Ishmael—Nethaniah's son, Elishama's grandson and royal offspring—comes with ten men and kills Gedaliah plus the Judeans and Chaldeans with him at Mizpah. The source does not say the killed group equals every person addressed by Gedaliah or that each had performed the proposed service; therefore the later killing does not close a contradiction against “it will be well.”

All people, small and great, and the force captains rise and go to Egypt because they fear the Chaldeans. Their exact membership and route remain unresolved.

## Verses 27-30 — Jehoiachin's release and continuing allowance

In Jehoiachin's thirty-seventh captivity year, twelfth month, twenty-seventh day, and Evilmerodach's accession year, Babylon's new king releases Jehoiachin from prison. He speaks kindly, sets Jehoiachin's throne above the thrones of the kings with him in Babylon, changes his prison garments and provides continual table bread plus a daily allowance for all the days of his life.

Release, relative throne placement, garment change, table access and allowance are distinct observed acts. The source does not restore Jerusalem rule, end captivity for others, explain Evilmerodach's reason, state Jehoiachin's remaining lifespan or continue beyond this book.

## CrackFlix frontier

No valid contradiction closes. “Judah carried captive” retains both the earlier and newly stated poorest-person remnants. Gedaliah's prospective well-being statement cannot be tested against every addressed person because the later killed and fleeing groups are not fully identity-mapped to those who accepted and performed its conditions.

## Bullshit pass

No bullshit closes. The brutal structure is already in the retained acts: a king rebels, a city is besieged and breached, elites and populations are removed, a remnant government is installed and destroyed, and a previously captive king receives a later release. No extra insult, motive or causal bridge is required.

## God-line boundary

- No new direct God speech occurs in this chapter.
- LORD's house is a source-addressed object in the destruction and inventory chain; that does not make the destroying acts divine acts.
- Siege, famine, breach, judgment, killings, burning, deportation, government, assassination, flight and release remain human/narrator events.
- Chapter 24's divine attribution remains a retained parent but is not repeated as new direct speech here.
- No God body is rendered.

## Character and world-ledger changes

- NOT-ZEDEKIAH JOE adds flight, pursuit, capture, judgment, sons' deaths, blinding, binding and Babylon removal.
- NOT-NEBUCHADNEZZAR JOE adds siege presence, Riblah judgment relation and Gedaliah appointment. Nebuzaradan is identified as his servant, but no royal destruction/deportation command is supplied.
- NOT-NEBUZARADAN JOE adds burning, deportation, temple-object taking and selected-person transfer.
- NOT-GEDALIAH JOE adds governorship, oath/advice and death.
- NOT-ISHMAEL JOE and ten separate men add the Mizpah killing occurrence.
- NOT-JEHOIACHIN JOE adds thirty-seven-year captivity boundary, release, changed status/clothes, table bread and allowance.
- NOT-EVILMERODACH JOE adds accession-year release, kind speech, throne placement and continuing provision.

## Reconstruction boundary

All 30 source verse markers are retained. Exact verse-range sections preserve causal order while the hashed USFM remains the reversible source carrier. The compound-eye image must keep siege/breach/flight/capture distinct; keep Zedekiah and Jehoiachin histories separate; retain remnant-after-deportation; preserve every inventory/count qualifier; and avoid inventing God action, motives, graphic violence or post-book outcomes. Exact names remain in sidecars; visible story names use `NOT-`; workflow metadata stays outside story pixels.

2 Kings is held complete at 25/25 chapters. Publication remains held. The next source boundary is 1 Chronicles 1.
