# CRACKHEAD 2 KINGS 20

## Title field

**NOT-ISAIAH: YOU WILL DIE AND NOT LIVE. / NOT-HEZEKIAH: [PRAYS AND WEEPS.] / NOT-LORD: I HAVE HEARD. I WILL HEAL YOU. FIFTEEN YEARS ADDED.**

Source parent: ENGWEBP 2 Kings chapter 20, verses 1-21, USFM. Prepared evidence: `.chapter-work/CHB-2KI-020/job.json` and `source.usfm`. Parent: 2 Kings 19. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: zero closed contradiction occurrences, zero SKIPs, zero Captain/YOINKs. The death forecast and later healing are connected by an explicit prayer/new-word revision chain and both Moments remain. One high-resolution 21-facet compound-eye image.

## Causal foundation

```text
HEZEKIAH SICK/DYING
-> ISAIAH MEDIATES LORD: ORDER HOUSE / DIE AND NOT LIVE
-> HEZEKIAH TURNS TO WALL / PRAYS / WEEPS
-> BEFORE ISAIAH LEAVES CITY MIDDLE, LORD WORD COMES
-> TURN BACK / PRAYER HEARD / TEARS SEEN
-> HEALING + THIRD-DAY LORD-HOUSE + FIFTEEN YEARS + CITY DEFENSE
-> FIG CAKE PLACED ON BOIL
-> HEZEKIAH RECOVERS
-> HEZEKIAH ASKS SIGN
-> CHOOSES SHADOW BACK TEN STEPS
-> ISAIAH CRIES TO LORD
-> SHADOW RETURNS TEN STEPS ON AHAZ SUNDIAL
-> BABYLON KING SENDS LETTERS/PRESENT AFTER HEARING OF SICKNESS
-> HEZEKIAH SHOWS ALL TREASURES/ARMOR/DOMINION
-> ISAIAH QUESTIONS / HEZEKIAH CONFIRMS ALL SHOWN
-> ISAIAH MEDIATES LORD: ALL CARRIED TO BABYLON / SONS BECOME EUNUCHS
-> HEZEKIAH CALLS WORD GOOD / CITES PEACE AND TRUTH IN HIS DAYS
-> POOL/CONDUIT/WATER WORK RETAINED BY CHRONICLE POINTER
-> HEZEKIAH DIES / MANASSEH SUCCEEDS
```

## Verses 1-7 — Forecast, prayer, revised State and recovery

Hezekiah is sick and dying. Isaiah mediates a LORD instruction to put his house in order because he will die and not live. Hezekiah turns to the wall, asks LORD to remember his truthful, whole-hearted walk and good acts, and weeps bitterly.

Before Isaiah reaches the middle of the city, LORD's word tells him to return. The new mediated message says the prayer was heard and tears seen; LORD will heal Hezekiah, he will enter LORD's house on the third day, receive fifteen added years, and he and the city will be delivered from Assyria.

Isaiah orders a fig cake. It is placed on the boil and Hezekiah recovers. The source retains prayer, new word, physical treatment and recovery but does not isolate their physiological or divine mechanism. The first forecast is not deleted; the later message is a new causal Moment explicitly following the prayer.

## Verses 8-11 — Selected sign and backward shadow

Hezekiah asks for a sign of healing and third-day ascent. Isaiah offers forward or backward movement of the shadow by ten steps. Hezekiah selects backward as the non-light option. Isaiah cries to LORD, and the narrator attributes the shadow's ten-step backward return on Ahaz's sundial to LORD.

The observation, selected direction and attribution are retained. The physical mechanism, geometry, duration and external measurement are not supplied and remain unresolved rather than being filled with an invented astronomical explanation.

## Verses 12-19 — Babylon visitors, total disclosure and forecast

Berodach Baladan sends letters and a present after hearing Hezekiah was sick. Hezekiah listens and shows the visitors every precious store, silver, gold, spices, oil, armor and all treasures across his dominion. Nothing is withheld from their view.

Isaiah asks what they said, where they came from and what they saw. Hezekiah identifies Babylon and confirms everything was shown. Isaiah then mediates LORD's future statement: all stored property will be carried to Babylon with nothing left, and some future sons will be taken as eunuchs in the Babylonian king's palace.

Hezekiah calls the word good and says there will be peace and truth in his own days. That evaluation and stated reason are his speech. No unspoken motive, knowledge of timing, visitor intent or completed deportation is inferred.

## Verses 20-21 — Works, death and succession

The chapter points to the Judah kings' chronicles for Hezekiah's other acts, might, pool, conduit and water delivery into the city. Those source-addressed works are retained without reconstructing unquoted engineering details.

Hezekiah later dies and Manasseh succeeds him. This supplies the eventual death State without erasing the fifteen-year addition or specifying its start date beyond the mediated statement.

## Bullshit pass

No verified bullshit closes. “Die and not live” and “I will heal/add fifteen years” are different retained messages separated by Hezekiah's prayer, tears and a new LORD word; flattening them into simultaneous incompatible claims would delete the explicit transition. The backward shadow is strange but source-attributed and mechanism-unresolved, which is not itself contradiction. Hezekiah's “good” evaluation may be brutal in context, but it conflicts with no retained claim of his own impartial concern.

## God-line boundary

- Isaiah mediates LORD speech in verses 1, 4-6 and 16-18.
- Hezekiah's prayer, sign request, Babylon answers and “good” evaluation remain his speech.
- Narrator attributes LORD's word arrival and backward shadow act; no God body is rendered.
- Fig-cake placement and recovery are observed physical acts; causal shares remain unresolved.
- Future Babylon removal and sons' status remain forecasts in this chapter, not completed occurrences.

## Character and world-ledger changes

- NOT-HEZEKIAH JOE adds illness, prayer, tears, recovery, sign selection, complete treasure disclosure, evaluation, water works, death and succession.
- NOT-ISAIAH JOE carries the first forecast, revised mediated message, fig-cake instruction, sign offer/prayer, questions and Babylon forecast.
- NOT-BERODACH-BALADAN JOE adds letters/present dispatch after hearing of illness; visitor purpose beyond that is unresolved.
- NOT-MANASSEH JOE becomes reigning successor at chapter close.
- No Captain appears because no contradiction closes.

## Reconstruction boundary

All 21 source verse markers are retained. Earlier forecast, intervening prayer, new mediated word, treatment, observed recovery and eventual death remain distinct Moments. The compound-eye image must not turn forecast into completed exile, shadow observation into an invented mechanism, or Hezekiah's evaluation into an inferred diagnosis. Exact names remain in sidecars; visible story names use `NOT-`; workflow metadata remains outside story pixels.

Publication remains held. The compound-eye carrier presents all 21 facets simultaneously with story-only pixels.
