# CRACKHEAD 2 KINGS 18

## Title field

**NOT-HEZEKIAH: [CUTS GOLD OFF TEMPLE DOORS.] / NOT-RABSHAKEH: THE LORD TOLD ME TO DESTROY THIS LAND. / NOT-PEOPLE: [SAY NOTHING.]**

Source parent: ENGWEBP 2 Kings chapter 18, verses 1-37, USFM. Prepared evidence: `.chapter-work/CHB-2KI-018/job.json` and `source.usfm`. Parent: 2 Kings 17. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: zero closed contradiction occurrences, zero SKIPs, zero Captain/YOINKs. Rabshakeh's authorization, deception, incapacity and relocation statements remain candidate speech awaiting later State. One high-resolution 37-facet compound-eye image.

## Causal foundation

```text
HEZEKIAH REIGNS 29 YEARS / RIGHT LIKE DAVID
-> HIGH PLACES/PILLARS/ASHERAH REMOVED
-> MOSES BRONZE SERPENT BROKEN BECAUSE INCENSE BURNED TO IT
-> TRUST/COMMAND KEEPING / LORD-WITH-HIM ATTRIBUTION
-> ASSYRIA REBELLION + PHILISTINE VICTORIES
-> SAMARIA SIEGE/CAPTURE/DEPORTATION RETOLD
-> SENNACHERIB TAKES JUDAH FORTIFIED CITIES
-> HEZEKIAH ADMITS OFFENCE / ACCEPTS LEVY
-> 300 TALENTS SILVER + 30 GOLD
-> TEMPLE/PALACE SILVER + TEMPLE-DOOR/PILLAR GOLD SENT
-> ASSYRIAN ENVOYS + GREAT ARMY AT JERUSALEM
-> JUDAH OFFICIALS MEET
-> RABSHAKEH ARGUMENT: CONFIDENCE/EGYPT/HIGH-PLACE REMOVAL/HORSES
-> RABSHAKEH CLAIMS LORD AUTHORIZED DESTRUCTION
-> OFFICIALS REQUEST SYRIAN LANGUAGE
-> RABSHAKEH REFUSES AUDIENCE BOUNDARY / SPEAKS LOUDLY IN JEWS' LANGUAGE
-> PUBLIC CLAIMS: HEZEKIAH DECEIVES / LORD WILL NOT DELIVER
-> OFFER: PEACE, CURRENT FOOD/WATER, LATER RELOCATION
-> ANALOGY TO OTHER CAPTURED LANDS/GODS
-> PEOPLE SILENT UNDER KING'S COMMAND
-> OFFICIALS TEAR CLOTHES / REPORT WORDS
```

## Verses 1-8 — Hezekiah's reign and reform

Hezekiah begins at twenty-five and reigns twenty-nine years. Narrator evaluates him right like David, trusting LORD without an equal among Judah kings before or after, adhering to commands and prospering with LORD attributed as present.

He removes high places, breaks pillars, cuts Asherah and destroys Moses' bronze serpent because Israel burns incense to it, naming it Nehushtan. The retained source artifact becomes a later worship object and is then destroyed; this is changed use and State, not erased provenance. He rejects Assyrian service and defeats Philistines through the stated territory.

## Verses 9-12 — Samaria closure retold

The prior three-year Samaria siege, capture and deportation are synchronized against Hezekiah's reign. Narrator again attributes the outcome to Israel's non-obedience. This is a historical join to 2 Kings 17, not a duplicated new occurrence.

## Verses 13-17 — Judah losses and paid levy

Sennacherib takes Judah's fortified cities. Hezekiah admits offence, requests withdrawal and accepts the imposed three hundred talents silver and thirty talents gold. He gives all available temple/palace silver and removes gold he had overlaid on LORD-house doors and pillars.

The payment does not close the conflict: Assyria then sends three titled envoys with a great army to Jerusalem. The chapter does not provide agreement wording that would make this a broken promise; withdrawal-for-payment remains Hezekiah's requested term, not an accepted Assyrian covenant.

## Verses 18-25 — Rabshakeh's first argument

Eliakim, Shebnah and Joah meet the envoys. Rabshakeh questions Hezekiah's confidence, labels counsel words vain, calls Egypt a bruised reed, interprets Hezekiah's altar removals as damage to LORD worship, challenges Judah to staff two thousand horses, and claims LORD directly ordered him to destroy the land.

These are Rabshakeh's attributed arguments. Hezekiah's actual confidence, Egypt plan, rider capacity, deception, and Rabshakeh's claimed LORD speech are not independently established here. No mental crack closes merely because a hostile envoy asserts them; later evidence may test each claim.

## Verses 26-37 — Public-language refusal and surrender pitch

Judah's officials ask for Syrian-language speech so wall listeners do not hear. Rabshakeh explicitly rejects that audience boundary, invokes siege suffering, and speaks loudly in the Jews' language.

He says Hezekiah deceives, cannot deliver, and should not induce LORD trust. He offers peace, immediate private food/water and later relocation to a land described as equivalent and life-preserving. He analogizes prior captured nations and gods to Jerusalem's prospects.

These are prospective claims and rhetoric; the relocation, survival and Jerusalem outcome have not occurred in this chapter. The people obey Hezekiah's command not to answer. The officials tear clothes and report the speech.

## God-line boundary

- Narrator attributes Hezekiah's evaluation, trust relation, adherence, LORD presence and prosperity.
- Samaria's fall is narrator-attributed to covenant non-obedience.
- Rabshakeh claims LORD directly ordered the invasion; this remains Rabshakeh speech, not promoted to verified direct God speech.
- Rabshakeh also quotes a supposed Hezekiah deliverance statement; it remains nested speech.
- No God body, divine authorization, deliverance outcome or invisible military act is invented.

## Character and world-ledger changes

- NOT-HEZEKIAH JOE adds reform, Nehushtan destruction, Assyria rebellion, tribute and silent-response command.
- NOT-SENNACHERIB JOE adds fortified-city capture, levy and Jerusalem envoy/army deployment.
- NOT-RABSHAKEH JOE adds public-language strategy, military/religious argument, claimed LORD authorization and surrender/relocation offer; truth State remains unresolved.
- NOT-ELIAKIM, NOT-SHEBNAH and NOT-JOAH JOES carry receipt, language request, silence and report.
- Zero contradiction machinery is admitted until later State actually closes a mismatch.

## Bullshit pass

- Hezekiah pays three hundred silver talents and thirty gold talents.
- Strips temple doors to do it.
- Assyria sends a great army anyway.
- Envoy: **YOUR GOD TOLD ME TO DESTROY YOU. ALSO YOUR KING IS DECEIVING YOU. ALSO SURRENDER AND WE'LL MOVE YOU SOMEWHERE JUST AS NICE.**
- Officials: **CAN YOU SAY THIS IN THE LANGUAGE THE PUBLIC DOESN'T UNDERSTAND?**
- Envoy switches to loud public broadcast.
- Public says nothing because their king already told them not to.
- Captain is excluded because none of the envoy's future claims has closed yet.

## FIR verification

- FILTER: all 37 markers retained; 2 Kings 19 excluded.
- ISOLATE: Hezekiah reform, Samaria retelling, Sennacherib levy, envoy argument, language boundary, surrender offer and silence.
- RECONSTRUCT: prior Samaria occurrence deduplicated; envoy claims retained as speech candidates; payment request is not invented as accepted treaty.
- VERIFY: zero closed contradictions/SKIPs/YOINKs; no motive, divine authorization, future outcome or God form invented.

## Required compound-eye facets

Exactly F001-F037, one per verse marker, simultaneously present. Siege-language bodily consequences remain symbolic/restrained, not graphic. Bronze serpent, idols, gold, doors, pillars, horses, chariots, conduit and wall are nonliving/faceless; living horses are Joe-faced. Finished-story pixels only; workflow metadata sidecar-only.

*shrug*

OK.
