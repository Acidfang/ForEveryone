# CRACKHEAD 2 KINGS 12

## Title field

**NOT-JOASH: WHY AREN'T YOU REPAIRING THE HOUSE? / NOT-JEHOIADA: [DRILLS HOLE IN CHEST.] / NOT-WORKERS: NO ACCOUNTING REQUIRED. THEY DEALT FAITHFULLY.**

Source parent: ENGWEBP 2 Kings chapter 12, verses 1-21, USFM. Prepared evidence: `.chapter-work/CHB-2KI-012/job.json` and `source.usfm`. Parent: 2 Kings 11. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: zero contradiction occurrences, zero SKIPs, zero Captain/YOINKs. One high-resolution 21-facet compound-eye image.

## Causal foundation

```text
JEHOASH BEGINS 40-YEAR REIGN / RIGHT-WHILE-JEHOIADA-INSTRUCTS
-> HIGH PLACES REMAIN / PEOPLE CONTINUE SACRIFICE + INCENSE
-> KING ORDERS PRIESTS TO COLLECT THREE MONEY CLASSES + REPAIR DAMAGE
-> YEAR 23: DAMAGE NOT REPAIRED
-> KING QUESTIONS PRIESTS / ENDS THEIR COLLECTION + REPAIR ROLE
-> PRIESTS CONSENT
-> JEHOIADA DRILLS CHEST LID / THRESHOLD PRIESTS DEPOSIT INCOMING MONEY
-> MUCH MONEY OBSERVED
-> KING SCRIBE + HIGH PRIEST BAG/COUNT
-> WEIGHED MONEY GIVEN TO OVERSEERS
-> CARPENTERS/BUILDERS/MASONS/CUTTERS PAID
-> TIMBER/CUT STONE PURCHASED / HOUSE REPAIRED
-> NO CULT VESSELS MADE FROM THIS MONEY
-> NO WORKER ACCOUNTING DEMANDED / FAITHFUL DEALING
-> TRESPASS/SIN MONEY REMAINS PRIESTS'
-> HAZAEL TAKES GATH / TURNS TOWARD JERUSALEM
-> JEHOASH SENDS DEDICATED THINGS + TREASURY GOLD
-> HAZAEL DEPARTS
-> TWO SERVANTS CONSPIRE / STRIKE JEHOASH / HE DIES
-> BURIAL / AMAZIAH SUCCEEDS
```

## Verses 1-3 — Reign evaluation and retained high places

Jehoash begins in Jehu's seventh year, reigns forty years in Jerusalem, and is identified through his mother Zibiah of Beersheba. Narrator says he does right in LORD's eyes throughout the days Jehoiada instructs him.

The high places are not removed; people continue sacrificing and burning incense there. The evaluation is scoped by Jehoiada's instruction period and does not assert that every practice or every actor is compliant. No contradiction is manufactured between a qualified royal evaluation and the separately retained public high-place practice.

## Verses 4-8 — First repair mechanism does not produce repair

Jehoash assigns three money classes brought to LORD's house: current holy-things money, evaluated-person money, and voluntary heart-moved money. Priests are to collect from their donors and repair every discovered house defect.

By the king's twenty-third year, the priests have not repaired the damage. The source supplies nonperformance but no completed-repair claim, no amount collected under the first route, and no reason for failure. Theft, laziness, corruption and mismanagement remain unasserted candidates.

Jehoash asks Jehoiada and the priests why repair is absent, stops them collecting from treasurers, and requires the money delivered for repair. The priests consent to stop taking money and stop owning the repair task. This is an explicit process transition, not silent erasure of the failed parent mechanism.

## Verses 9-16 — Chest, counted money, direct workers and faithful dealing

Jehoiada drills a hole in a chest lid and places it beside the altar at the right side of the LORD-house entrance. Threshold priests put all incoming money into it. When much money is visible, the king's scribe and high priest bag and count it.

Weighed money goes to house-work overseers, who pay carpenters, builders, masons and stone cutters and purchase timber, cut stone and every required repair input. The workers repair the house.

This repair money is not used to manufacture silver cups, snuffers, basins, trumpets, or gold/silver vessels; it goes to workers. No accounting is demanded from the entrusted men because narrator says they deal faithfully. “No accounting” does not mean no counting: the preceding king-scribe/high-priest count is retained, while the later statement concerns downstream worker disbursement accountability.

Trespass- and sin-offering money is excluded from the house chest route and remains the priests'. The distinct money classes are not merged.

## Verses 17-21 — Hazael payment, conspiracy and succession

Hazael fights Gath, takes it, and turns toward Jerusalem. Jehoash takes all holy things dedicated by Jehoshaphat, Jehoram, Ahaziah and himself, plus all gold found in LORD-house and king-house treasuries, and sends it to Hazael. Hazael leaves Jerusalem.

The transfer and departure are observed; the chapter does not state a negotiated price, exact threat message, recipient promise, or whether every treasure category becomes empty. Dedicated status remains parent history; no retained rule in this selected chapter says these carriers can never be transferred, so no crack is invented.

Jehoash's remaining acts point to Judah's chronicles. His servants conspire and strike him at Millo on the road to Silla. Jozacar son of Shimeath and Jehozabad son of Shomer are named as the two strikers. Jehoash dies, is buried with his fathers in David's city, and Amaziah succeeds. The conspiracy motive is unresolved.

## God-line boundary

- Narrator evaluates Jehoash as right in LORD's eyes during Jehoiada's instruction.
- All temple-money, chest, repair and offering routes are human acts involving LORD's house; no direct LORD speech occurs.
- High-place sacrifices/incense are observed human practices.
- Hazael's campaign, treasury transfer, departure and Joash's death remain human causal chains.
- No God body, financial blessing, repair miracle, treasury-protection rule or assassination judgment is invented.

## Character and world-ledger changes

- NOT-JOASH/JEHOASH JOE extends from seven-year-old accession through forty-year reign, repair redesign, Hazael payment and assassination.
- NOT-JEHOIADA JOE extends as instructor and chest-system implementer; his later State is not imported.
- NOT-PRIEST JOES retain failed first-route repair, consent, threshold deposit work and excluded offering-money ownership without an invented motive.
- NOT-SCRIBE, NOT-HIGH-PRIEST, NOT-OVERSEER and NOT-WORKER JOES form the verified counting-to-repair chain.
- NOT-JOZACAR and NOT-JEHOZABAD JOES are exact producing actors in Joash's death; no collective servant guilt is assigned.
- NOT-AMAZIAH JOE enters as successor only.

## Bullshit pass

Issue `2KI-012 / TEMPLE REPAIR PROCUREMENT REFORM`.

- King: **COLLECT MONEY FROM YOUR DONORS AND REPAIR EVERYTHING.**
- Sixteen-plus years later: building still damaged.
- King: **WHY AREN'T YOU REPAIRING IT?**
- Priests agree to stop collecting and stop repairing.
- High priest's replacement fintech platform: wooden chest with hole drilled in lid.
- Money becomes visible.
- Scribe and high priest count it.
- Workers receive it.
- Building gets repaired.
- Auditor: **WHERE ARE THE DOWNSTREAM ACCOUNTS?**
- Narrator: **THEY DEALT FAITHFULLY.**
- Foreign king approaches.
- Every available sacred and royal gold carrier becomes an outbound retention payment.

Captain hears no validated contradiction and does absolutely nothing.

## FIR verification

- FILTER: all 21 markers retained; 2 Kings 13 excluded.
- ISOLATE: reign evaluation, high places, failed priest repair route, chest/count/worker repair route, offering-money exclusion, Hazael payment and assassination/succession.
- RECONSTRUCT: process failure becomes explicit role redesign; upstream count and downstream no-accounting statement remain distinct.
- VERIFY: zero contradictions/SKIPs/YOINKs; no priest motive, missing-money claim, dedication prohibition, treaty terms, divine form or assassination motive invented.

## Required compound-eye facets

1. Jehoash accession synchronism/40-year reign/Zibiah.
2. Right-during-Jehoiada-instruction evaluation.
3. High places remain/people sacrifice and burn incense.
4. Three temple-money classes identified.
5. Priests take donor money/repair every found defect command.
6. Year 23/damage not repaired.
7. King asks why/stops collection/requires repair delivery.
8. Priests consent to stop collection and repair role.
9. Jehoiada chest/hole/altar-right entrance placement/deposits.
10. Much money observed/scribe and high priest bag/count.
11. Weighed money handed to work overseers.
12. Carpenters/builders paid.
13. Masons/cutters/timber/cut-stone repair inputs.
14. No cups/snuffers/basins/trumpets/gold-silver vessels from fund.
15. Money goes to workers/house repaired.
16. No downstream accounting demanded/faithful dealing.
17. Trespass/sin money excluded and remains priests'.
18. Hazael takes Gath/turns toward Jerusalem.
19. Dedicated things + temple/royal gold sent/Hazael departs.
20. Judah-chronicles pointer/servant conspiracy/Millo strike.
21. Two named strikers/Jehoash death/burial/Amaziah succession.

All twenty-one facets appear simultaneously.

## Production boundary

One high-resolution 21-facet compound-eye image. `NOT-` identities and Joe faces for all living humans and animals. Money, chest, altar, temple, high places, tools, timber, stone, vessels, treasuries, dedicated things, Gath, Jerusalem, Millo and weapons are nonliving/faceless. Zero SKIPs and zero Captain/YOINKs. Assassination restrained/non-graphic. No God body. Finished-story pixels only; workflow metadata sidecar-only.

*shrug*

OK.
