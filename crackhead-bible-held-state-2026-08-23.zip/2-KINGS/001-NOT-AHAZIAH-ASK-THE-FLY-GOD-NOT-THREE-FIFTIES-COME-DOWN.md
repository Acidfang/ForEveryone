# CRACKHEAD 2 KINGS 1

## Title field

**NOT-AHAZIAH: ASK THE FLY GOD IF I RECOVER. / NOT-ELIJAH: YOU WILL DIE. / NOT-CAPTAINS: COME DOWN. / FIRE COMES DOWN.**

Source parent: ENGWEBP 2 Kings chapter 1, verses 1-18, USFM. Prepared evidence: `.chapter-work/CHB-2KI-001/job.json` and `source.usfm`. Parent: 1 Kings 22. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: no closed contradiction. Zero SKIPs, Captain appearances or YOINKs. One high-resolution 18-facet compound-eye field.

## Causal foundation

```text
AHAB DIES -> MOAB REBELS
-> AHAZIAH FALLS THROUGH UPPER-ROOM LATTICE / BECOMES SICK
-> SENDS MESSENGERS TO INQUIRE OF BAAL ZEBUB ABOUT RECOVERY
-> LORD ANGEL TELLS ELIJAH TO INTERCEPT
-> ELIJAH CARRIES NO-GOD-IN-ISRAEL QUESTION + SURE-DEATH WORD
-> MESSENGERS RETURN / REPORT / IDENTIFY HAIRY MAN WITH LEATHER BELT
-> AHAZIAH IDENTIFIES ELIJAH
-> FIRST CAPTAIN + FIFTY ORDER ELIJAH DOWN
-> ELIJAH IF-MAN-OF-GOD FIRE REQUEST
-> FIRE COMES DOWN / CONSUMES 51
-> SECOND CAPTAIN + FIFTY ORDER QUICKLY DOWN
-> SAME REQUEST / GOD'S FIRE CONSUMES 51
-> THIRD CAPTAIN + FIFTY KNEEL / ASK LIVES PRECIOUS
-> LORD ANGEL TELLS ELIJAH GO DOWN / DO NOT FEAR
-> ELIJAH GOES TO KING / REPEATS SURE-DEATH WORD
-> AHAZIAH DIES / JEHORAM SUCCEEDS
```

## Verses 1–8 — The recovery inquiry is intercepted

After Ahab's death, Moab rebels. Ahaziah falls through the lattice of his Samaria upper room and becomes sick. He sends messengers to ask Baal Zebub of Ekron whether he will recover.

LORD's angel tells Elijah to meet them and carry a question: whether the Ekron inquiry is because there is no God in Israel. The carried result says Ahaziah will not leave his bed and will surely die. Elijah departs.

The messengers return early. Ahaziah asks why; they accurately report the encountered man's message. Asked what kind of man, they describe a hairy man with a leather belt. Ahaziah identifies Elijah. The description-to-identity inference is Ahaziah's conclusion; it is not independently upgraded by appearance alone.

## Verses 9–12 — Twice: “come down”; fire comes down

Ahaziah sends a captain with fifty people. Elijah sits on a hilltop. The captain addresses him as man of God and carries the king's command to come down. Elijah answers conditionally: if he is a man of God, let fire come down from the sky and consume the captain and fifty. Fire comes down and consumes them.

A second captain and fifty repeat the route, now commanding Elijah to come down quickly. Elijah repeats the conditional fire request. God's fire comes down and consumes the second group.

The repeated words create brutal literal wordplay—captains demand that Elijah **come down**, and fire **comes down**—but no claim/act mismatch exists. The two performed occurrences remain distinct and produce no SKIP, crack or Captain.

## Verses 13–16 — The third captain changes the relation

A third captain and fifty are sent. This captain goes up, kneels before Elijah and asks that his own life and the fifty servants' lives be precious, explicitly citing the prior two fire outcomes. This is not the earlier command repeated: the speech, posture and requested outcome change.

LORD's angel tells Elijah to go down with him and not fear. Elijah does so, reaches Ahaziah and repeats the Ekron-inquiry question and sure-death result. The angel instruction supplies the transition from hilltop refusal/fire encounters to going down; no contradiction is created.

## Verses 17–18 — Prediction outcome and succession

Ahaziah dies according to the LORD word Elijah spoke. Jehoram succeeds because Ahaziah has no son. The reign date is retained against Jehoram son of Jehoshaphat in Judah. Ahaziah's remaining acts are referred to Israel's royal chronicles.

## God-line boundary

- LORD's angel supplies the interception, death-message and later go-down/no-fear instruction; no angel or divine form beyond speech-carrier identity is invented.
- Elijah's two conditional fire requests are human prophetic speech; the first fire is narrator fire-from-sky, the second is narrator “God's fire.”
- Ahaziah's death is observed and narrator-linked to LORD's word spoken by Elijah.
- Baal Zebub is only the destination of Ahaziah's proposed inquiry; no reply, deity body or successful consultation occurs.

## Character and world-ledger changes

- NOT-AHAZIAH JOE moves from post-Ahab king through lattice fall, foreign-deity recovery inquiry, intercepted warning, three deployments, death and no-son succession.
- NOT-ELIJAH JOE is recognized through messenger description, remains on the hill through two fire outcomes, then goes down under the later angel instruction and speaks to the king.
- Three NOT-CAPTAIN JOES and their three fifties remain distinct: two command and die; the third kneels, cites those deaths, asks for life and survives.
- NOT-JEHORAM JOE succeeds Ahaziah; he is not merged with the contemporaneous Judah Jehoram.

## Bullshit pass

Issue `2KI-001 / ESCALATION PATH HAS A VERY LITERAL DOWNSTREAM RESPONSE`.

- Executive asks external Fly Support whether production will recover.
- Internal incident responder intercepts: **YOU HAVE INTERNAL SUPPORT. YOU WILL NOT RECOVER.**
- Team one: **COME DOWN.**
- Fire: **COMES DOWN.**
- Team two: **COME DOWN QUICKLY.**
- God's fire: **COMES DOWN QUICKLY ENOUGH.**
- Team three: kneels, cites both incident reports, asks not to be included.
- Internal authority: **GO DOWN WITH THIS ONE.**

No contradiction. Captain Crackhead hears “fire” but not “crack” and does not attend.

## FIR verification

- FILTER: all 18 markers retained; 2 Kings 2 excluded.
- ISOLATE: Moab rebellion, fall/sickness, recovery inquiry, interception, messenger report/identity inference, three captain encounters, repeated fire results, final message, death and succession.
- RECONSTRUCT: two repeated command/fire occurrences plus a materially changed third encounter; no valid contradiction.
- VERIFY: zero SKIPs/YOINKs/Captain; no Baal reply, angel/God body, fire mechanism, Elijah fear State, captain motive, identity-by-appearance proof or graphic death invented.

## Required compound-eye facets

1. Moab rebels after Ahab death.
2. Ahaziah falls/lies sick/sends Baal Zebub recovery inquiry.
3. LORD angel tells Elijah intercept/no-God question.
4. Sure-death word/Elijah departs.
5. Messengers return/Ahaziah asks why.
6. Messengers repeat encountered-man message.
7. Ahaziah asks what kind of man.
8. Hair/leather-belt description/Ahaziah identifies Elijah.
9. First captain/fifty/hilltop/come-down order.
10. First conditional request/fire consumes 51, restrained.
11. Second captain/fifty/come-down-quickly order.
12. Second conditional request/God's fire consumes 51, restrained.
13. Third captain/fifty/kneels/asks lives precious.
14. Third captain cites prior fire/deaths/repeats life request.
15. LORD angel says go down/do not fear; Elijah goes.
16. Elijah repeats Ekron/no-God/sure-death word to king.
17. Ahaziah dies/Jehoram succeeds/no son/date distinction.
18. Ahaziah chronicle pointer.

All eighteen facets appear simultaneously.

## Production boundary

One high-resolution 18-facet compound-eye image. `NOT-` identities and Joe faces for every living thing. Lattice, bed, belt, hill, fire and remains are nonliving/faceless. Zero Captain Crackhead carriers, SKIPs or YOINKs. Fire deaths restrained/non-graphic. The three captains/fifties must remain visually distinct; the third survives. No deity body or Baal reply. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
