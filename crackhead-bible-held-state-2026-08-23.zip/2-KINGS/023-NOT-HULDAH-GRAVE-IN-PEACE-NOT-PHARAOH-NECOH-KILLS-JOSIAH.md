# CRACKHEAD 2 KINGS 23

## Title field

**NOT-HULDAH: YOU WILL BE GATHERED TO YOUR GRAVE IN PEACE. / NOT-PHARAOH-NECOH: [KILLS NOT-JOSIAH AT MEGIDDO.]**

Source parent: ENGWEBP 2 Kings chapter 23, verses 1-37, USFM. Prepared evidence: `.chapter-work/CHB-2KI-023/job.json` and `source.usfm`. Cross-chapter comparison parent: 2 Kings 22:20, retained by `.chapter-work/CHB-2KI-022/source.usfm` (SHA-256 `3e458984e5da8f15a05fd985006cb03cff1364165fd79cafb160fbcf5a207a1d`) and `2-KINGS/022-NOT-HILKIAH-I-FOUND-THE-BOOK-NOT-JOSIAH-TEARS-CLOTHES.md`. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: zero closed contradiction occurrences, no SKIP and no Captain/YOINK. The relation between the prior “grave in peace” wording and Josiah's violent death is an unresolved semantic frontier: the source does not define whether “in peace” describes manner of death, burial, or death before the later place-wide disaster. One high-resolution 37-facet compound-eye image.

## Causal foundation

```text
JOSIAH GATHERS ELDERS/PEOPLE/PRIESTS/PROPHETS
-> READS FOUND COVENANT BOOK TO ALL
-> KING MAKES COVENANT / PEOPLE AGREE
-> TEMPLE VESSELS REMOVED/BURNED/ASHES TO BETHEL
-> PRIESTS/ALTARS/ASHERAH/HOUSES/HIGH PLACES REMOVED OR DEFILED
-> TOPHETH DISABLED / SUN HORSES REMOVED / CHARIOTS BURNED
-> AHAZ/MANASSEH/SOLOMON INSTALLATIONS DESTROYED
-> BETHEL ALTAR/HIGH PLACE DESTROYED
-> TOMB BONES BURNED ON ALTAR
-> MAN-OF-GOD + SAMARIA-PROPHET BONES LEFT UNDISTURBED
-> SAMARIA HIGH PLACES REMOVED / PRIESTS KILLED
-> PASSOVER COMMANDED AND KEPT IN YEAR 18
-> MEDIUMS/WIZARDS/TERAPHIM/IDOLS REMOVED
-> JOSIAH UNIQUE TURNING EVALUATION
-> LORD WRATH NOT TURNED / JUDAH-JERUSALEM REMOVAL FORECAST
-> JOSIAH GOES AGAINST PHARAOH NECOH
-> PHARAOH NECOH KILLS JOSIAH AT MEGIDDO
-> SERVANTS CARRY HIM DEAD / BURY IN OWN TOMB
-> JEHOAHAZ ANOINTED / 3-MONTH REIGN
-> PHARAOH BINDS JEHOAHAZ / IMPOSES 100 SILVER + 1 GOLD TALENT
-> ELIakim MADE KING / RENAMED JEHOIAKIM
-> JEHOAHAZ TAKEN TO EGYPT / DIES THERE
-> JEHOIAKIM TAXES PEOPLE / PAYS PHARAOH
-> JEHOIAKIM 11-YEAR EVIL-EVALUATED REIGN
```

## Verses 1-3 — Public reading and covenant

Josiah gathers Judah and Jerusalem elders, then goes to LORD's house with priests, prophets and the whole small-to-great population. He reads all words of the found covenant book. He makes a whole-heart/whole-soul covenant to follow LORD and keep the written commands, testimonies and statutes; all people agree.

The agreement is an observed collective response. Individual comprehension, future compliance and consent mechanics are not invented.

## Verses 4-14 — Jerusalem and Judah removal chain

Josiah orders Hilkiah, second-order priests and threshold keepers to remove Baal, Asherah and sky-army vessels. The source then uses singular “he” for burning them outside Jerusalem and carrying their ashes to Bethel; the exact singular referent is not silently replaced with the commanded plural group. Idolatrous priests are removed; Asherah is burned, pulverized and spread on common graves; shrine-prostitute houses and woven-hanging site are broken down.

Priests are brought from Judah's cities and high places defiled from Geba to Beersheba. High-place priests do not ascend to Jerusalem's altar but eat unleavened bread among brothers. Topheth is disabled to prevent child-through-fire use. Sun horses are removed, sun chariots burned, Ahaz-roof and Manasseh-court altars broken and their dust cast into Kidron.

Solomon-associated high places are defiled; pillars and Asherah poles are destroyed and their places filled with human bones. Manufactured objects remain faceless. Living people remain Joe-faced; child, corpse and killing material is restrained.

## Verses 15-20 — Bethel/Samaria acts and retained tomb boundary

Josiah breaks and burns Jeroboam's Bethel altar/high place and Asherah. He removes bones from nearby tombs and burns them on the altar, matching the earlier LORD word proclaimed by the man of God. This is a fulfillment join to the retained 1 Kings 13 occurrence, not a newly invented prophecy.

On seeing a monument, Josiah asks its identity. City men identify the Judah man-of-God tomb and its relation to Josiah's present altar acts. Josiah orders those bones left alone, and the bones of the Samaria prophet are also preserved.

He removes Samaria-city high-place houses, kills the high-place priests on their altars, burns human bones there and returns to Jerusalem. No individual priest histories or additional judicial process are supplied.

## Verses 21-27 — Passover, further removals and unresolved wrath

Josiah commands the written-book Passover. The narrator says no such Passover had been kept from the judges through the Israel and Judah kings; this one is kept in Josiah's eighteenth year.

He removes mediums, wizards, teraphim, idols and visible abominations to confirm the found-book law. The narrator says no king before or after turned to LORD like him with all heart, soul and might according to Moses' law.

Nevertheless, LORD's wrath is said not to turn because of Manasseh's provocation. Direct LORD speech forecasts Judah's removal like Israel's and rejection of Jerusalem and the addressed house while retaining the historical name-there statement. Josiah's reforms and the forecast have different retained causal parents; no promise in this chapter says the reforms cancel the consequence.

## Verses 28-30 — Josiah's violent death

Pharaoh Necoh travels toward the Euphrates and Josiah goes against him. Pharaoh Necoh kills Josiah at Megiddo when he sees him. Josiah's servants carry him dead by chariot to Jerusalem and bury him in his own tomb. The people anoint Jehoahaz king.

This supplies the later State needed to test 2 Kings 22:20. Burial and not seeing the later Jerusalem disaster may fit the prior message, while violent death creates a real semantic tension if “in peace” is read as manner of death. The source supplies no definition that selects that reading, so the relation remains unresolved and cannot enter CrackFlix as a validated contradiction.

## Verses 31-37 — Jehoahaz and Jehoiakim under Pharaoh

Jehoahaz begins at twenty-three, reigns three months and is evaluated evil. Pharaoh Necoh binds him at Riblah to stop his Jerusalem reign and imposes one hundred talents silver plus one talent gold.

Pharaoh installs Josiah's son Eliakim, renames him Jehoiakim, and takes Jehoahaz to Egypt where he dies. Jehoiakim raises Pharaoh's payment by assessing and taxing the land people. He begins at twenty-five, reigns eleven years and receives an evil evaluation.

## CrackFlix frontier

**GRAVE IN PEACE / KILLED AT MEGIDDO — SCOPE UNRESOLVED, NO CRACK.**

Huldah's mediated LORD message says Josiah will be gathered to his grave in peace. The later observed chain says Josiah goes against Pharaoh Necoh, is killed by him at Megiddo, is carried dead by servants and buried. Those facts are retained together, but the text does not define the scope of “in peace.” No contradiction, SKIP, boil, Captain or YOINK is admitted.

## Bullshit pass

No bullshit is closed here. **GRAVE IN PEACE / KILLED IN BATTLE** remains a candidate semantic tension, not a source-forced contradiction. Other apparent tensions are likewise retained without inflation: Josiah's reform does not carry an explicit promise to cancel Manasseh-linked wrath, and the Bethel act fulfills an earlier addressed forecast rather than creating one retroactively.

## God-line boundary

- The found-book covenant and historical man-of-God proclamation remain retained carriers.
- Verse 27 records direct LORD speech forecasting Judah/Jerusalem/house rejection.
- Narrator attributes Josiah's unique evaluation and LORD's continuing wrath relation.
- Huldah's prior mediated peace forecast joins as a tested parent; its relation to the death State remains scope-unresolved.
- No God body, battle motive, Pharaoh route purpose beyond source wording or reform efficacy mechanism is invented.

## Character and world-ledger changes

- NOT-JOSIAH JOE adds public book reading, covenant, extensive removal/destruction chain, Passover, unique evaluation, Megiddo confrontation, death and burial.
- NOT-HILKIAH and priest/keeper JOES carry temple-removal execution.
- NOT-PHARAOH-NECOH JOE carries Josiah killing, Jehoahaz restraint/tribute and Eliakim installation/rename.
- NOT-JEHOAHAZ JOE adds three-month reign, restraint, Egypt removal and death.
- NOT-ELIAKIM/JEHOIAKIM JOE adds imposed kingship, rename, taxation/payment and eleven-year reign.
- The protected man-of-God and Samaria-prophet bones remain distinct from burned tomb bones.
- Zero contradiction episodes, SKIPs, boils, Captain acts or YOINKs are admitted.

## Reconstruction boundary

All 37 source verse markers are retained. Covenant, reform acts, prior-prophecy fulfillment, Passover, evaluation, direct forecast, battle death, burial and foreign royal control remain separate. The compound-eye image must not merge tomb populations, render manufactured objects living, show Jerusalem's later fall as complete, or render the unresolved peace relation as a contradiction. Exact names remain in sidecars; visible story names use `NOT-`; workflow metadata remains outside story pixels.

Publication remains held. The compound-eye carrier presents all 37 facets simultaneously with story-only pixels.
