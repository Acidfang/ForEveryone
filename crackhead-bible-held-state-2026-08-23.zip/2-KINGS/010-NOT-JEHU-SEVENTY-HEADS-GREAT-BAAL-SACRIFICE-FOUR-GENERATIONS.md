# CRACKHEAD 2 KINGS 10

## Title field

**NOT-JEHU: PICK A KING AND FIGHT ME. / SEVENTY HEADS. / I WILL SERVE BAAL MUCH. GREAT SACRIFICE. EVERYONE INSIDE. / [KILL THEM.] / FOUR GENERATIONS.**

Source parent: ENGWEBP 2 Kings chapter 10, verses 1-36, USFM. Prepared evidence: `.chapter-work/CHB-2KI-010/job.json` and `source.usfm`. Parent: 2 Kings 9. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: four contradiction occurrences. `S127-E015-2KI10`, `S127-E016-2KI10`, and `S127-E017-2KI10` each carry an exact inert SKIP to the immediately prior S127 occurrence. New `S258-E001-2KI10` has no SKIP. Exactly four separate Captain/YOINKs occur only after their addressed closures. One high-resolution 36-facet compound-eye image.

## Causal foundation

```text
JEHU LETTER: SELECT BEST AHAB SON / CROWN HIM / FIGHT
-> SAMARIA AUTHORITIES FEAR / SUBMIT
-> SECOND LETTER DEMANDS SEVENTY HEADS
-> CARETAKERS KILL SEVENTY SONS / SEND HEADS
-> JEHU ORDERS TWO GATE HEAPS / ADDRESSES CROWD
-> JEHU KILLS REMAINING AHAB HOUSE/ASSOCIATES/PRIESTS
-> JEHU MEETS FORTY-TWO AHAZIAH BROTHERS / TAKES ALIVE / KILLS AT PIT
-> JEHU + JEHONADAB JOIN / RIDE TO SAMARIA
-> REMAINING AHAB PEOPLE DESTROYED
-> JEHU ANNOUNCES MUCH BAAL SERVICE + GREAT SACRIFICE
-> NARRATOR IDENTIFIES DECEPTIVE DESTRUCTION INTENT
-> ALL BAAL WORSHIPERS ASSEMBLE / RECEIVE ROBES / LORD SERVANTS EXCLUDED
-> OFFERING FINISHES
-> EIGHTY GUARDS + CAPTAINS KILL ASSEMBLED WORSHIPERS
-> PILLARS/HOUSE DESTROYED / SITE MADE LATRINE
-> BAAL DESTROYED OUT OF ISRAEL
-> JEHU RETAINS GOLDEN-CALF SIN ROUTE
-> LORD COMMENDS AHAB-HOUSE EXECUTION / PROMISES FOUR DESCENDANT REIGNS
-> JEHU DOES NOT WALK WHOLEHEARTEDLY
-> LORD-ATTRIBUTED ISRAEL REDUCTION / HAZAEL STRIKES EASTERN LAND
-> JEHU DIES / JEHOAHAZ SUCCEEDS / TWENTY-EIGHT-YEAR REIGN CLOSES
```

## Verses 1-11 — Seventy sons and the transferred-liability recurrence

Ahab has seventy sons in Samaria. Jehu writes their rulers, elders and caregivers: since they possess the sons, chariots, horses, fortified city and armor, they should select the best son, enthrone him and fight for their master's house. They fear because two kings did not stand before Jehu and submit without choosing a king.

Jehu's second letter conditions being on his side on bringing the sons' heads by the next day. The caregivers kill all seventy, send their heads in baskets, and Jehu orders two heaps at the gate until morning. Depiction is restrained; no severed-head spectacle is required.

Jehu acknowledges his own conspiracy and killing of his master, then asks who killed all these. The rhetorical question does not erase his exact second-letter command or the caregivers' performed killings. He attributes the whole outcome to LORD's word concerning Ahab's house. He then strikes all remaining Ahab-house people, great men, familiar friends and priests in Jezreel.

`S127-E015-2KI10` closes the recurring transferred-liability relation: judgment framed through Ahab/Jezebel acts reaches seventy sons and a wider house population whose individual producing acts are not supplied. SKIP points to `S127-E014-1KI21`; it removes no letter, killing, body State or attribution. One separate post-closure YOINK changes nothing.

## Verses 12-17 — Forty-two visitors, Jehonadab and Samaria completion

On the road Jehu meets Ahaziah's brothers. They identify themselves and state that they are going to greet the king's and queen's children. Jehu orders them taken alive; they are taken alive and then all forty-two are killed at the shearing-house pit. No hostile act or knowledge by the forty-two is supplied.

`S127-E016-2KI10` closes another recurrence: the visitors receive lethal dynastic liability without an addressed producing act. SKIP points to `S127-E015-2KI10` and changes nothing. One separate YOINK follows closure.

Jehu meets Jehonadab, asks whether his heart is right, receives the answer, takes his hand and lifts him into the chariot. Jehu invites him to witness his zeal for LORD. At Samaria Jehu destroys those remaining to Ahab, which narrator aligns with LORD's word carried to Elijah.

## Verses 18-28 — The announced sacrifice is the trap

Jehu gathers the people and says Ahab served Baal little but Jehu will serve much. He summons every Baal prophet, worshiper and priest for a great sacrifice and threatens absence with death. The narrator explicitly states Jehu acts deceptively, intending to destroy Baal's worshipers.

The solemn assembly is proclaimed; the house fills completely. Robes are issued. Jehu and Jehonadab enter and require a search ensuring only Baal worshipers are present and no LORD servants. Eighty men wait outside under a life-for-life escape rule.

After the burnt offering finishes, Jehu orders the guard and captains to kill everyone and allow no escape. They perform the killing, clear the bodies, burn the pillars, break down pillar and house, and turn the site into a latrine. Narrator closes that Jehu destroyed Baal out of Israel.

New `S258-E001-2KI10` isolates the deliberate bait relation: Jehu publicly announces much Baal service and a great sacrifice to make the selected audience assemble; narrator preserves the opposite destruction intent and the execution performs it. This is not a mental mistake by Jehu. It is a physical contradiction between the asserted event offered to recipients and the retained event used to trap them. No SKIP: this is the series root. One post-closure YOINK changes no deception, deaths or demolition.

## Verses 29-36 — Calves retained, four-generation benefit and territorial loss

Jehu does not depart from Jeroboam's golden calves at Bethel and Dan. LORD directly tells Jehu that he did well executing what was right concerning Ahab's house and promises his descendants Israel's throne to the fourth generation. The source then says Jehu did not heed LORD's law with all his heart and did not depart from Jeroboam's sins. These are scoped distinctions, not a forced contradiction: commendation is explicitly for the Ahab-house execution; noncompliance concerns his broader walk and calves.

`S127-E017-2KI10` addresses the separate four-generation allocation: Jehu's retained act produces a throne benefit for descendants who did not perform that act. SKIP points to `S127-E016-2KI10`; it erases neither commendation nor promise. One separate YOINK changes nothing.

Narrator says LORD began cutting away parts of Israel and Hazael struck the eastern territories from Jordan through Gilead and Bashan. LORD attribution and Hazael's observed military act remain distinct carriers; no hidden mechanism is invented. Jehu's other acts remain in the chronicles pointer. He dies, is buried in Samaria, Jehoahaz succeeds, and the reign closes at twenty-eight years.

## God-line boundary

- Jehu attributes the Ahab-house outcome to LORD's Elijah-carried word.
- Narrator aligns Samaria's destruction with LORD's word spoken to Elijah.
- Jehu calls his campaign zeal for LORD; this is Jehu's statement, not an independently measured inner State.
- LORD directly addresses Jehu in verse 30, commending the exact Ahab-house execution and promising four descendant reigns.
- Narrator separately says Jehu did not walk in LORD's law wholeheartedly and attributes Israel's territorial reduction to LORD while naming Hazael's strikes.
- No God body, revelation mechanism, inner-heart visualization or invisible territorial-cause mechanism is invented.

## Character and world-ledger changes

- NOT-JEHU JOE extends through dynastic purge, Jehonadab alliance, Baal trap, retained calf practice, direct commendation, territorial loss, death and succession.
- NOT-SEVENTY-SON JOES close as seventy distinct killed people; they are not reduced to baskets or a generic house symbol.
- NOT-FORTY-TWO-BROTHER JOES remain distinct captured-and-killed visitors with no invented hostility.
- NOT-JEHONADAB JOE knowingly joins Jehu's chariot and temple inspection; no unstated role in the killings is assigned.
- NOT-BAAL-WORSHIPER JOES assemble under a deceptive invitation and are killed; the exact population is unresolved.
- NOT-JEHOAHAZ JOE succeeds Jehu; later reign acts remain outside this chapter.

## Bullshit pass

Issue `2KI-010 / HOSTILE TAKEOVER EMAIL CAMPAIGN AND MANDATORY COMPANY RETREAT`.

- CEO: **PICK YOUR BEST HEIR, GIVE HIM THE COMPANY, AND FIGHT ME.**
- Entire board: **THE LAST TWO CEOS DID NOT SURVIVE THE INTERVIEW. WE ARE YOUR SERVANTS.**
- CEO, second email: **SEND SEVENTY HEADS BY TOMORROW.**
- Seventy heads arrive in baskets.
- CEO: **I KILLED MY MASTER. BUT WHO KILLED ALL THESE?**
- Later company-wide invite: **I LOVE BAAL MORE THAN THE LAST CEO. MANDATORY GREAT SACRIFICE. ABSENCE MEANS DEATH.**
- Wardrobe issues everyone matching robes.
- Security checks the room contains only the invited demographic.
- Sacrifice finishes.
- CEO: **KILL EVERYONE.**
- Building converted into toilet.
- Performance review: **GOOD JOB ON THAT EXACT ASSIGNMENT. ALSO YOU IGNORED THE REST OF THE MANUAL.**

Captain receives four separately closed boils, YOINKs each exactly once, and changes absolutely nothing.

## FIR verification

- FILTER: all 36 markers retained; 2 Kings 11 excluded.
- ISOLATE: letter purge, seventy sons, forty-two visitors, Jehonadab join, Baal deception/trap, calf retention, commendation/descendant promise, territorial losses and succession.
- RECONSTRUCT: three S127 recurrences plus one new S258 bait occurrence; scoped commendation and broader noncompliance remain compatible.
- VERIFY: exactly three inert SKIPs and four YOINKs; no victim guilt, Jehonadab killing act, inner zeal, divine form or hidden territorial mechanism invented.

## Required compound-eye facets

1. Seventy Ahab sons/caregivers in Samaria.
2. First letter reaches rulers/elders/caregivers.
3. Chariots/horses/fortified city/armor inventory.
4. Select best son/throne/fight challenge.
5. Authorities fear/two-kings reasoning.
6. Authorities submit/no king/do what is good to Jehu.
7. Second letter demands heads by tomorrow.
8. Seventy sons with great men/caregivers.
9. Seventy killed/heads basketed and sent, restrained.
10. Messenger report/two gate heaps until morning, restrained.
11. Jehu morning speech: own conspiracy/who killed these.
12. S127-E015 closure with inert SKIP to S127-E014 and one YOINK.
13. Remaining Ahab household/associates/priests struck, restrained.
14. Jehu travels/shearing house.
15. Forty-two identify as Ahaziah brothers/greeting route.
16. Taken alive then killed at pit, restrained.
17. S127-E016 closure with inert SKIP to S127-E015 and one YOINK.
18. Jehu meets Jehonadab/heart exchange/hand/chariot.
19. Come see my zeal for LORD statement.
20. Samaria Ahab remnant destruction/Elijah-word attribution.
21. Jehu announces much Baal service.
22. All prophets/worshipers/priests + great-sacrifice invitation.
23. Narrator exposes deceptive destruction intent.
24. Solemn assembly proclaimed/all worshipers fill house.
25. Wardrobe keeper issues robes.
26. Jehu/Jehonadab search/exclude LORD servants.
27. Sacrifice/offering begins/eighty outside/life-for-life rule.
28. Offering finishes/kill-no-escape order and execution, restrained.
29. S258-E001 closure with no SKIP and one YOINK.
30. Pillars burned/pillar-house broken/site made latrine.
31. Baal destroyed out of Israel/golden calves retained.
32. Direct LORD commendation/four-generation throne promise.
33. S127-E017 closure with inert SKIP to S127-E016 and one YOINK.
34. Jehu not wholehearted/Jeroboam sins retained.
35. LORD-attributed reduction/Hazael eastern strikes/map.
36. Chronicles/Jehu death-burial/Jehoahaz succession/28-year close.

All thirty-six facets appear simultaneously.

## Production boundary

One high-resolution 36-facet compound-eye image. `NOT-` identities and Joe faces for all living humans and animals. Letters, baskets, heads/remains, robes, offerings, pillars, calves, temple, latrine, weapons, cities and maps are nonliving/faceless. Three exact inert SKIPs and exactly four separate post-closure Captain/YOINKs. Mass killings, body heaps and remains restrained/non-graphic. No God body. Finished-story pixels only; workflow metadata sidecar-only.

*shrug*

OK.
