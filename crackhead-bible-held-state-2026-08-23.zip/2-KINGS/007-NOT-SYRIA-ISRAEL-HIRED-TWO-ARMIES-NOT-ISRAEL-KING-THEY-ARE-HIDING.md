# CRACKHEAD 2 KINGS 7

## Title field

**NOT-SYRIA: ISRAEL HIRED THE HITTITE AND EGYPTIAN KINGS! / NOT-ISRAEL-KING: THEY LEFT EVERYTHING SO THEY CAN HIDE AND CAPTURE US! / THE TRAIL: DISCARDED EQUIPMENT ALL THE WAY TO JORDAN.**

Source parent: ENGWEBP 2 Kings chapter 7, verses 1-20, USFM. Prepared evidence: `.chapter-work/CHB-2KI-007/job.json` and `source.usfm`. Parent: 2 Kings 6. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: recurring mental `S252-E002-2KI7` and `S252-E003-2KI7`. Exactly two inert SKIPs: E002 -> `S252-E001-2KI3`; E003 -> E002. Exactly two separate causally null Captain YOINKs. One high-resolution 20-facet compound-eye image.

## Causal foundation

```text
ELISHA CARRIES TOMORROW PRICE WORD
-> CAPTAIN ASKS IF EVEN HEAVEN WINDOWS COULD MAKE IT
-> ELISHA: YOU WILL SEE / NOT EAT
-> FOUR LEPROUS MEN CHOOSE SYRIAN CAMP OVER CERTAIN FAMINE DEATH
-> LORD MAKES SYRIANS HEAR GREAT ARMY SOUND
-> SYRIANS INVENT HITTITE + EGYPTIAN HIRES
-> SKIP -> S252-E001 / SYRIANS FLEE AND ABANDON CAMP
-> S252-E002 CLOSES / YOINK
-> FOUR MEN EAT/DRINK/HIDE GOODS / THEN REPORT GOOD NEWS
-> EMPTY CAMP REPORT REACHES KING
-> KING INVENTS HIDDEN AMBUSH PLAN
-> SCOUTS FOLLOW TRAIL TO JORDAN
-> GARMENTS/EQUIPMENT DISCARDED IN HASTY FLIGHT / NO AMBUSH OBSERVED
-> SKIP -> S252-E002 / S252-E003 CLOSES / YOINK
-> PEOPLE PLUNDER CAMP
-> EXACT FLOUR/BARLEY PRICES OCCUR
-> CAPTAIN SEES BUT IS TRAMPLED AND DIES WITHOUT EATING
```

## Verses 1–2 — Tomorrow's prices and the captain's outcome

Elisha carries LORD's word that by the same time tomorrow, one seah of fine flour and two seahs of barley will each sell for one shekel at Samaria's gate. The captain on whose hand the king leans asks whether such a thing could happen even if LORD made heaven windows. Because this is grammatically a question, it is not converted into a categorical impossibility claim. Elisha says the captain will see it but not eat it.

## Verses 3–9 — Certain death, empty camp and invented hired armies

Four leprous men at the gate compare staying, entering famine and surrendering. They go at twilight to the Syrian camp and find nobody. Narrator says Lord made Syria hear chariots, horses and a great army. The Syrians assert Israel hired Hittite and Egyptian kings to attack. No hired king or army exists in retained State. They flee for their lives, leaving tents, horses, donkeys and camp intact.

This repeats S252's surface-signal-to-invented-completed-history mechanism. An inert **SKIP -> S252-E001-2KI3** points to the red-water/dead-kings explanation; `S252-E002-2KI7` closes when the allegedly hired armies remain absent and the Syrians' own flight produces the empty camp. One YOINK changes nothing.

The four men eat and drink, remove and hide silver, gold and clothing from two tents, then say keeping silent on a good-news day is wrong and risks punishment. They decide to report.

## Verses 10–15 — Empty-camp report and invented ambush

The men tell gatekeepers the camp has no human or voice, while tied animals and tents remain. The report reaches the king. He asserts Syria knows Israel is hungry, has hidden in the field, plans to capture those who leave and then enter the city. This turns an empty camp into an unobserved completed ambush plan.

A servant proposes sending remaining horses to observe. Two chariots follow the Syrian route to Jordan. The entire path contains garments and equipment Syria discarded in haste. The messengers return with the flight evidence; no hidden force, capture or city-entry attempt is observed. An inert **SKIP -> S252-E002-2KI7** preserves the same inference failure; `S252-E003-2KI7` closes and receives its own YOINK.

## Verses 16–20 — Plunder, exact prices and the captain trampled

The people plunder the Syrian camp. Fine flour and barley sell at the exact quantities and price Elisha carried as LORD's word. The king appoints the skeptical captain over the gate. The crowd tramples him and he dies, so he sees the market State but does not eat it, matching Elisha's personal outcome statement.

Verses 18–20 restate the price statement, the captain's question, Elisha's answer and the performed outcome; they are retained as a source recap, not duplicated occurrences.

The prior 2 Kings 6 same-day threat against Elisha remains unresolved: this chapter identifies the king coming down and Elisha speaking, but does not supply a reliable clock boundary or explicit later Elisha State proving the entire named day expired without the threatened act.

## God-line boundary

- Elisha explicitly carries LORD's price word.
- Narrator says Lord causes Syria to hear chariot/horse/great-army sound.
- Syria invents hired Hittite/Egyptian forces; this is their inference, not narrator fact.
- Exact market prices are narrator outcome according to LORD's word.
- No God body, sound-production mechanism, market mechanism or trampling mechanism is invented.

## Character and world-ledger changes

- FOUR NOT-LEPROUS JOES move from gate exclusion and death calculus through discovery, self-enrichment, self-correction and public report.
- NOT-SYRIAN-ARMY JOES flee an attributed sound after manufacturing a hired-army history.
- NOT-ISRAEL-KING JOE receives the empty-camp report, manufactures an ambush history, authorizes scouts and receives contrary trail evidence.
- NOT-CAPTAIN JOE moves from rhetorical disbelief through direct observation to death without eating.
- NOT-ELISHA JOE carries both price and captain outcome statements; no new action concerning the prior beheading threat is supplied.

## Bullshit pass

Issue `2KI-007 / BOTH SIDES INVENT THE MISSING ARMY`.

- Besieging organization hears a huge army.
- **THE CLIENT HIRED TWO INTERNATIONAL ARMIES. EVACUATE EVERYTHING.**
- Four excluded contractors find the entire environment abandoned.
- Besieged executive receives exact report.
- **OBVIOUSLY THEY ARE HIDING TO CAPTURE US.**
- Audit team follows a trail of clothes and equipment dropped during evacuation.
- Market prices normalize exactly on schedule.
- The disbelief officer sees the dashboard and gets trampled before lunch.

Captain presses SKIP twice. Two invented armies remain zero armies. **YOINK! YOINK!**

## FIR verification

- FILTER: all 20 markers retained; 2 Kings 8 excluded.
- ISOLATE: price word, captain response, four-man decision, Syrian sound/inference/flight, report, royal ambush inference, scout evidence, plunder/prices and captain death.
- RECONSTRUCT: recurring S252 E002 and E003 only; source recap deduplicated.
- VERIFY: two SKIPs/two YOINKs; rhetorical question not forced into assertion; beheading deadline remains unresolved; no hired army, ambush, sound or market mechanism invented.

## Required compound-eye facets

1. Elisha carries exact tomorrow prices.
2. Captain heaven-window question/see-not-eat response.
3. Four leprous men at gate/death question.
4. City/stay/surrender decision tree.
5. Twilight arrival/empty camp.
6. Lord-attributed great-army sound/Syrian hired-army inference; S252-E002 SKIP/YOINK.
7. Syrian twilight flight/intact camp.
8. Four men eat/drink/hide goods twice.
9. Self-correction/good-news report decision.
10. Gatekeeper report: no people/voice, animals tied/tents intact.
11. Gatekeepers route report inward.
12. King hidden-ambush model; S252-E003 candidate.
13. Servant proposes five remaining horses/observation.
14. Two chariots sent.
15. Jordan trail of discarded equipment; S252-E003 SKIP/YOINK.
16. People plunder/exact prices.
17. Captain gate appointment/trampling/death.
18. Price prophecy recap.
19. Captain question and see-not-eat recap.
20. Trampling/death outcome recap without duplicate occurrence.

All twenty facets appear simultaneously.

## Production boundary

One high-resolution 20-facet compound-eye image. `NOT-` identities and Joe faces for all living humans and animals, including horses and donkeys. Tents, equipment, clothing, money, food and chariots are nonliving/faceless. Exactly two inert SKIPs and two separate boilless Captain sequences. Leprosy and trampling restrained/non-graphic. No God body. Finished-story pixels only; workflow metadata sidecar-only.

*shrug*

OK.
