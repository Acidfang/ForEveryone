# CRACKHEAD 2 KINGS 19

## Title field

**NOT-SENNACHERIB: YOUR GOD DECEIVES YOU. JERUSALEM WILL BE GIVEN TO ME. / NOT-LORD: I WILL DEFEND THIS CITY. / NOT-SENNACHERIB: [GOES HOME.]**

Source parent: ENGWEBP 2 Kings chapter 19, verses 1-37, USFM. Prepared evidence: `.chapter-work/CHB-2KI-019/job.json` and `source.usfm`. Parent: 2 Kings 18. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: one new physical contradiction occurrence `S260-E001-2KI19`, no SKIP, exactly one causally-null Captain/YOINK. One high-resolution 37-facet compound-eye image.

## Causal foundation

```text
RABSHAKEH WORDS HEARD
-> HEZEKIAH TEARS CLOTHES / ENTERS LORD HOUSE
-> SACKCLOTH DELEGATION TO ISAIAH
-> ISAIAH MEDIATES LORD: DO NOT FEAR / RETURN / SWORD IN OWN LAND
-> RABSHAKEH RETURNS / TIRHAKAH NEWS
-> SENNACHERIB LETTER: GOD DECEIVES / JERUSALEM WILL BE GIVEN
-> HEZEKIAH READS / SPREADS LETTER / PRAYS
-> ISAIAH MEDIATES LORD RESPONSE
-> ASSYRIAN BOASTS QUOTED / PRIOR CONQUESTS ATTRIBUTED TO LORD'S LONG PLAN
-> HOOK/BRIDLE/RETURN FORECAST
-> TWO-YEAR FOOD + THIRD-YEAR SOW/REAP SIGN
-> REMNANT ROOT/FRUIT FORECAST
-> LORD: NO CITY ENTRY/ARROW/SHIELD/MOUND; I WILL DEFEND AND SAVE
-> LORD ANGEL STRIKES 185,000 IN ASSYRIAN CAMP
-> SENNACHERIB DEPARTS / LIVES AT NINEVEH
-> LATER SONS KILL HIM BY SWORD / ESCAPE
-> ESAR HADDON SUCCEEDS
```

## Verses 1-7 — Report, prayer request and mediated answer

Hezekiah hears the report, tears his clothes, covers himself with sackcloth and enters LORD's house. He sends Eliakim, Shebna and priest elders in sackcloth to Isaiah. Their message calls the day trouble, rebuke and rejection, uses a birth-without-strength comparison, asks whether LORD will hear Rabshakeh's defiance, and requests prayer for the remnant.

Isaiah tells them to relay a direct LORD message: do not fear the blasphemous words; LORD will put a spirit in the Assyrian king, he will hear news, return to his land and fall by the sword there. This is mediated divine speech, not Isaiah's independent forecast and not a rendered God body.

## Verses 8-19 — New letter and Hezekiah's prayer

Rabshakeh returns and finds Sennacherib fighting Libnah after leaving Lachish. News says Tirhakah is coming to fight. Sennacherib sends another message: Hezekiah's God must not deceive him with the claim Jerusalem will not be given to Assyria; prior destroyed lands and their gods supposedly prove he will not be delivered.

Hezekiah receives and reads the letter, spreads it before LORD and prays. He distinguishes LORD from the burned manufactured wood-and-stone gods, acknowledges Assyria's prior devastation and asks for rescue so kingdoms may know LORD alone. The prayer is Hezekiah's speech; the manufactured figures remain nonliving and faceless.

## Verses 20-34 — Mediated LORD answer

Isaiah sends a LORD response that the prayer was heard. The response identifies Sennacherib's speech as defiance and blasphemy, quotes his chariot, mountain, tree, water and river boasts, and says his fortified-city victories occurred inside a long-formed LORD plan rather than by independent unlimited power.

Because of Sennacherib's raging and arrogance, LORD says he will be turned back by the way he came. A sign retains first-year volunteer growth, second-year regrowth, then third-year sowing, reaping, vineyard planting and fruit. Judah's remnant is forecast to root downward and fruit upward.

The exact city boundary is explicit: the Assyrian king will not enter Jerusalem, shoot an arrow there, approach with shield or build a mound. LORD says he will defend and save the city for his own and David's sake.

## Verses 35-37 — Camp strike, departure and later death

That night the LORD's angel strikes 185,000 in the Assyrian camp; the morning observation is dead bodies. The carrier is explicitly LORD's angel and may use the current Joe Root artifact; no God body or unstated mechanism is rendered. Violence remains restrained.

Sennacherib departs, returns home and lives at Nineveh. Later, while worshipping in Nisroch's house, his sons Adrammelech and Sharezer kill him by sword and escape to Ararat. Esar Haddon succeeds him. This closes the earlier return-and-sword forecast while retaining the interval and exact human actors.

## CrackFlix closure

`S260-E001-2KI19` — **YOUR GOD DECEIVES YOU / JERUSALEM WILL BE GIVEN / I WILL DEFEND THIS CITY / ASSYRIA GOES HOME**.

Sennacherib's addressed letter says Jerusalem's non-delivery promise is divine deception and asks whether Hezekiah can be delivered. Rabshakeh's parent speech also denied LORD deliverance and claimed LORD-authorized destruction. The mediated LORD reply says the king will not enter, shoot, shield or mound against the city and that LORD will defend and save it; the observed next State has the Assyrian camp struck and Sennacherib departing home. The later State directly closes the delivery/destruction claim. This first occurrence has no SKIP. Captain appears only after closure, pokes and licks one boil, says YOINK and changes nothing.

## Bullshit pass

The bullshit is exactly the Assyrian certainty that Jerusalem will be handed over and its God cannot deliver it, tested against the later addressed divine statement and observed departure. Repeated rhetoric is one confrontation, not several invented cracks. The chapter does not infer the private belief or motive of any speaker.

## God-line boundary

- Isaiah mediates direct LORD speech in verses 6-7 and 20-34.
- Sennacherib's letter and the quoted Assyrian boasts remain human speech even when the LORD response quotes them.
- LORD's response attributes prior conquest capacity, the reversal, sign, remnant future and Jerusalem defense.
- Verse 35 attributes the camp strike to LORD's angel; the mechanism beyond that carrier is unresolved.
- Hezekiah's prayer and causal interpretations remain his speech unless the narrator or mediated LORD independently supplies them.
- No God body, private motive, battle detail or temporal interval before Sennacherib's death is invented.

## Character and world-ledger changes

- NOT-HEZEKIAH JOE adds sackcloth, delegation, letter receipt/display and prayer.
- NOT-ISAIAH JOE carries two addressed mediated LORD messages.
- NOT-SENNACHERIB JOE adds the letter, divine-deception/delivery claim, retreat to Nineveh and later death.
- NOT-RABSHAKEH JOE returns to the Assyrian king; his chapter-18 claims join the tested confrontation.
- NOT-ANGEL JOE carries the explicitly attributed camp strike; NOT-ADRAMMELECH and NOT-SHAREZER JOES carry the later sword act.
- The 185,000 camp deaths are observed and source-attributed; individual identities and strike mechanism remain unresolved.

## Reconstruction boundary

All 37 source verse markers are retained. Speech carrier, forecast, observed act and later outcome remain separate. The compound-eye image must show every facet without converting quoted claims into facts, forecasts into completed acts, the angel into God, or Captain into a cause. Exact names remain in sidecars; visible story names use `NOT-`. Workflow metadata stays outside story pixels.

Publication remains held. The compound-eye carrier presents all 37 facets simultaneously with story-only pixels.
