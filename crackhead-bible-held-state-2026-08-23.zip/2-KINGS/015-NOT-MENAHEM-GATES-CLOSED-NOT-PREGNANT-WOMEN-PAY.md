# CRACKHEAD 2 KINGS 15

## Title field

**NOT-MENAHEM: THEY DIDN'T OPEN THE GATES. / NOT-PREGNANT-WOMEN: [RECEIVE THE CONSEQUENCE.] / FIVE KINGS: [CONSPIRE, KILL, REPLACE.]**

Source parent: ENGWEBP 2 Kings chapter 15, verses 1-38, USFM. Prepared evidence: `.chapter-work/CHB-2KI-015/job.json` and `source.usfm`. Parent: 2 Kings 14. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: one physical recurrence, `S127-E018-2KI15`, with inert `SKIP -> S127-E017-2KI10` and one causally-null Captain YOINK. One high-resolution 38-facet compound-eye image.

## Causal foundation

```text
AZARIAH/UZZIAH REIGNS 52 YEARS / HIGH PLACES REMAIN
-> LORD-ATTRIBUTED STRIKE / LEPROSY / SEPARATE HOUSE
-> JOTHAM RUNS HOUSEHOLD + JUDGES LAND
-> AZARIAH DIES / JOTHAM SUCCEEDS
-> ZECHARIAH REIGNS SIX MONTHS
-> SHALLUM CONSPIRES / KILLS / REPLACES
-> FOURTH JEHU GENERATION WORD CLOSED
-> SHALLUM REIGNS ONE MONTH
-> MENAHEM KILLS SHALLUM / REPLACES
-> TIPHSAH DOES NOT OPEN GATES
-> MENAHEM ATTACKS CITY/BORDERS + PREGNANT WOMEN
-> S127-E018 / SKIP POINTS TO S127-E017 / ONE YOINK
-> MENAHEM REIGNS TEN YEARS
-> PUL ARRIVES / 1000 TALENTS SILVER
-> WEALTHY MEN EACH PAY 50 SHEKELS / PUL LEAVES
-> MENAHEM DIES / PEKAHIAH SUCCEEDS
-> PEKAH + FIFTY GILEADITES KILL PEKAHIAH / PEKAH SUCCEEDS
-> TIGLATH PILESER TAKES NAMED TERRITORIES / CAPTIVITY
-> HOSHEA KILLS PEKAH / SUCCEEDS
-> JOTHAM REIGN FRAME / HIGH PLACES REMAIN / UPPER GATE BUILT
-> LORD-ATTRIBUTED SENDING OF REZIN + PEKAH
-> JOTHAM DIES / AHAZ SUCCEEDS
```

## Verses 1-7 — Azariah/Uzziah and delegated judgment

Azariah begins at sixteen and reigns fifty-two years. Narrator evaluates him as right in LORD's eyes on Amaziah's route, while high places remain. The chapter later uses Uzziah for the same Judah king; the same reign synchronisms and Jotham parentage retain one addressed person, without inventing a second king.

Narrator says LORD strikes the king; he has leprosy until death and lives separately. Jotham controls the household and judges the land's people. The strike mechanism and reason are not supplied here. Azariah dies, is buried and Jotham succeeds.

## Verses 8-15 — Zechariah, Shallum and the fourth generation

Zechariah reigns six months, retains the Jeroboam route, and is killed publicly by Shallum, who replaces him. Narrator says this closes LORD's prior word to Jehu that four generations of sons would sit on Israel's throne. The exact four-generation succession is retained as fulfilment, not a new contradiction.

Shallum reigns one month. Menahem comes from Tirzah, kills him and replaces him. Both conspiracies remain direct actor-target sequences; their motives and wider support are unresolved.

## Verse 16 — Gate refusal and expanded liability

Menahem attacks Tiphsah, its inhabitants and border areas because “they” did not open their gates. He then violently attacks every pregnant woman. The chapter supplies no individual gate-control act by each affected woman or bridge assigning the collective refusal to them.

This recurs as `S127-E018-2KI15`. `SKIP -> S127-E017-2KI10` points to the retained consequence-allocation contradiction without deleting the Tiphsah occurrence. One post-closure Captain YOINK changes nothing. The image must communicate the closed gate and expanded affected class without graphic anatomy.

## Verses 17-26 — Menahem, Assyrian payment and Pekahiah

Menahem reigns ten years and retains the Jeroboam route. Pul of Assyria comes against the land. Menahem gives him one thousand talents of silver to support his hold on the kingdom, extracting fifty shekels from each wealthy mighty man. Pul leaves. The exact agreement and coercion beyond the stated extraction remain unresolved.

Menahem dies and Pekahiah succeeds for two years, retaining the same evaluated route. His captain Pekah, Argob, Arieh and fifty Gileadites attack him in the palace fortress; Pekah kills and replaces him.

## Verses 27-38 — Pekah, deportation, Hoshea and Jotham

Pekah reigns twenty years. Tiglath Pileser takes the named northern territories and carries their people to Assyria. Hoshea conspires, kills Pekah and replaces him. Campaign and conspiracy mechanisms remain unresolved.

The narrative returns to Jotham's Judah reign: twenty-five at accession, sixteen years, right in LORD's eyes on Uzziah's route, high places retained, upper LORD-house gate built. Narrator says LORD begins sending Rezin and Pekah against Judah. No God body or invisible transport is shown. Jotham dies, is buried and Ahaz succeeds.

## God-line boundary

- Narrator attributes Azariah's strike/leprosy to LORD without supplying reason or mechanism.
- Narrator identifies Zechariah's fourth-generation succession as fulfilment of LORD's prior direct word to Jehu.
- Narrator attributes the beginning of Rezin/Pekah pressure against Judah to LORD.
- Royal moral evaluations remain narrator State.
- No God body, disease mechanism, assassination authorization or military control mechanism is invented.

## Character and world-ledger changes

- NOT-AZARIAH/UZZIAH JOE closes through reign, separate-house illness, death and burial; NOT-JOTHAM JOE progresses from delegated judge to king, death and succession by NOT-AHAZ JOE.
- NOT-ZECHARIAH, NOT-SHALLUM, NOT-MENAHEM, NOT-PEKAHIAH and NOT-PEKAH JOES form an exact reign/conspiracy/succession chain; NOT-HOSHEA JOE ends as king.
- NOT-PREGNANT-WOMEN JOES retain affected-person identity without being assigned an unobserved gate act.
- `S127-E018-2KI15` retains one physical recurrence, one inert SKIP and one causally-null Captain YOINK.

## Bullshit pass

- City gate remains shut.
- Menahem: **THEY DIDN'T OPEN IT.**
- Consequence expands to all inhabitants, borders and every pregnant woman.
- No per-person gate decision is supplied.
- `SKIP -> S127-E017-2KI10` points at the already-retained actor-to-other-person consequence structure.
- Captain arrives after closure, licks one boil and improves no dynasty whatsoever.

## FIR verification

- FILTER: all 38 markers retained; 2 Kings 16 excluded.
- ISOLATE: Azariah/Jotham, Israel's five reign transitions, Tiphsah, Pul payment, Assyrian capture and Judah pressure.
- RECONSTRUCT: same Azariah/Uzziah identity retained; assassinations separated from contradiction; Tiphsah refusal separated from affected-person liability.
- VERIFY: one physical recurrence, one SKIP, one YOINK; no motive, divine form, disease mechanism or graphic violence invented.

## Required compound-eye facets

Exactly F001-F038, one per verse marker, simultaneously present. F016 carries `S127-E018-2KI15`, exact inert SKIP and separate post-closure Captain carrier. All killings, pregnancy-related violence, illness, war and captivity remain restrained/non-graphic. Finished-story pixels only; workflow metadata sidecar-only.

*shrug*

OK.
