# CRACKHEAD 2 KINGS 22

## Title field

**NOT-HILKIAH: I FOUND THE BOOK OF THE LAW IN THE LORD'S HOUSE. / NOT-SHAPHAN: [READS IT.] / NOT-JOSIAH: [TEARS HIS CLOTHES.]**

Source parent: ENGWEBP 2 Kings chapter 22, verses 1-20, USFM. Prepared evidence: `.chapter-work/CHB-2KI-022/job.json` and `source.usfm`. Parent: 2 Kings 21. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: zero closed contradiction occurrences, zero SKIPs, zero Captain/YOINKs. Huldah's peace/grave statement remains a forecast pending Josiah's later death State. One high-resolution 20-facet compound-eye image.

## Causal foundation

```text
JOSIAH BEGINS AGE 8 / REIGNS 31 YEARS / RIGHT-WAY EVALUATION
-> YEAR 18 SENDS SHAPHAN TO LORD HOUSE
-> COUNT PEOPLE-GATHERED MONEY
-> DELIVER TO OVERSEERS/WORKERS
-> CARPENTERS/BUILDERS/MASONS BUY TIMBER/CUT STONE / REPAIR DAMAGE
-> NO ACCOUNTING REQUIRED BECAUSE FAITHFUL DEALING
-> HILKIAH FINDS LAW BOOK
-> GIVES BOOK TO SHAPHAN
-> SHAPHAN READS / REPORTS MONEY DELIVERY
-> SHAPHAN READS BOOK BEFORE KING
-> JOSIAH HEARS / TEARS CLOTHES
-> COMMANDS FIVE-PERSON LORD INQUIRY
-> DELEGATION GOES TO HULDAH
-> HULDAH MEDIATES PLACE/INHABITANT CONSEQUENCE
-> REASON: FORSAKEN LORD / INCENSE / HANDWORK
-> JOSIAH-SPECIFIC RESPONSE: TENDER HEART/HUMILITY/TEARS HEARD
-> FORECAST: GRAVE IN PEACE / NOT SEE PLACE DISASTER
-> MESSAGE RETURNED TO KING
```

## Verses 1-7 — Repair funding and bounded accounting

Josiah begins reigning at eight, rules thirty-one years and receives a right-way narrator evaluation. In his eighteenth year he sends Shaphan to Hilkiah to count money gathered from the people at LORD's house.

The money moves to overseers and then house workers for damage repair. Carpenters, builders and masons receive it, including for timber and cut stone. The instruction explicitly removes a transaction-accounting demand because the workers deal faithfully. That is a selected trust boundary, not evidence that quantities, identities or completion may be invented.

## Verses 8-13 — Found book, reading and inquiry command

Hilkiah reports finding the book of the law in LORD's house, gives it to Shaphan, and Shaphan reads it. Shaphan separately reports that servants emptied the found money and delivered it to work overseers.

He then tells Josiah about the book and reads it before him. Josiah hears, tears his clothes and orders Hilkiah, Ahikam, Achbor, Shaphan and Asaiah to inquire of LORD for himself, the people and Judah.

Josiah states his causal interpretation: great wrath is kindled because the fathers did not listen to and perform what the book says concerning them. This remains Josiah's speech until the mediated response independently addresses it.

## Verses 14-20 — Huldah's mediated response

The five-person delegation goes to Huldah the prophetess in Jerusalem's second quarter. Her retained household relation identifies Shallum as her husband and wardrobe keeper; lineage through Tikvah and Harhas is preserved.

Huldah mediates LORD speech that the book's words will come upon the place and inhabitants because they forsook LORD, burned incense to other gods and provoked with the work of their hands. The wrath is said not to be quenched. This is future at this chapter boundary.

For Josiah specifically, the mediated message says his tender heart, humility, torn clothes and tears were heard. It forecasts that he will be gathered to his grave in peace and will not see the place's coming disaster. The delegation returns the message. No death, burial or place disaster occurs here, so later State must test the exact wording and scope.

## Bullshit pass

No verified bullshit closes. Finding a book inside the house does not establish when, why or by whom it was placed there. Removing the accounting requirement is an explicit authority decision grounded in stated faithful dealing, not a contradiction. “Gathered to your grave in peace” remains prospective and cannot be classified against an outcome that has not yet occurred in this chapter.

## God-line boundary

- Josiah's wrath explanation is human speech.
- Huldah mediates LORD speech in verses 15-20; it separates place-wide consequence from Josiah-specific response.
- Narrator supplies Josiah's evaluation, the repair/book/message events and the delegation return.
- No God body, book provenance, private worker motive or future fulfillment is invented.

## Character and world-ledger changes

- NOT-JOSIAH JOE adds year-18 repair authorization, trust boundary, book hearing, torn clothes and inquiry command.
- NOT-SHAPHAN JOE carries the repair message, book receipt/readings and king report.
- NOT-HILKIAH JOE carries money counting, book discovery/transfer and inquiry delegation.
- NOT-AHIKAM, NOT-ACHBOR and NOT-ASAIAH JOES join the inquiry delegation.
- NOT-HULDAH JOE carries the mediated place-wide and Josiah-specific responses.
- House workers retain trade roles and faithful-dealing attribution; no Captain appears.

## Reconstruction boundary

All 20 source verse markers are retained. Money transport, repair authority, book discovery, reading, Josiah's reaction, inquiry and mediated forecast remain separate. The compound-eye image must not fabricate the book's origin, show unrecorded repair completion, make the forecast already fulfilled, or render God bodily. Exact names remain in sidecars; visible story names use `NOT-`; workflow metadata remains outside story pixels.

Publication remains held. The compound-eye carrier presents all 20 facets simultaneously with story-only pixels.
