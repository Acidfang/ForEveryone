# CRACKHEAD 2 KINGS 24

## Title field

**NOT-JEHOIAKIM: SERVES THREE YEARS, THEN REBELS. / NOT-NEBUCHADNEZZAR: BESIEGES AND DEPORTS.**

Source chapter 24 parent: ENGWEBP 2 Kings 24:1-20, retained at `.chapter-work/CHB-2KI-024/source.usfm` with SHA-256 `3d5ef45c2a92e0dd3cbde03d2b3e26b6ae91f93d1e41fed4cb86efa5d2434cfe`; canonical book source SHA-256 `e4ade265a98ed78b4f0fe9f24889a9aac013ff1b20e7948ec6d314fee9f45704`. Parent manuscript: 2 Kings 23. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: zero closed contradiction occurrences, no SKIP and no Captain/YOINK. One high-resolution 20-facet compound-eye image with all verse Moments co-present.

## Causal foundation

```text
JEHOIAKIM SERVES BABYLON THREE YEARS
-> JEHOIAKIM REBELS
-> LORD-ATTRIBUTED CHALDEAN/SYRIAN/MOABITE/AMMONITE BANDS SENT
-> JUDAH DESTRUCTION/REMOVAL LINKED TO PROPHET WORD + MANASSEH ACTS/BLOOD
-> JEHOIAKIM DIES / JEHOIACHIN REIGNS
-> BABYLON HOLDS FORMER EGYPTIAN TERRITORY
-> BABYLON SERVANTS BESIEGE JERUSALEM
-> NEBUCHADNEZZAR ARRIVES
-> JEHOIACHIN/HOUSEHOLD/OFFICIALS GO OUT
-> JEHOIACHIN CAPTURED IN BABYLON KING YEAR EIGHT
-> TEMPLE/PALACE TREASURES REMOVED / GOLD VESSELS CUT
-> ROYAL/MILITARY/CRAFT POPULATION DEPORTED
-> POOREST LAND PEOPLE REMAIN
-> MATTANIAH INSTALLED / RENAMED ZEDEKIAH
-> ZEDEKIAH REIGNS ELEVEN YEARS
-> ZEDEKIAH REBELS AGAINST BABYLON
```

## Verses 1-7 — Jehoiakim's service, rebellion and death

Nebuchadnezzar comes up; Jehoiakim serves him for three years, then turns and rebels. The narrator attributes the sending of Chaldean, Syrian, Moabite and Ammonite bands against Judah to LORD and to prior prophet speech. Judah's removal is further attributed to Manasseh's acts, innocent blood and the statement that LORD would not pardon.

Jehoiakim's remaining acts are addressed to the Judah-kings chronicle. He dies and Jehoiachin succeeds him. Egypt's king no longer comes out because Babylon has taken the territory from Egypt's brook to Euphrates. No campaign details, band member motives, pardon mechanism or exact relation between the bands and Jehoiakim's death is invented.

## Verses 8-12 — Three-month reign, siege and capture

Jehoiachin begins at eighteen, reigns three months in Jerusalem and receives the same evil-evaluation relation as his father. Nebuchadnezzar's servants besiege Jerusalem; Nebuchadnezzar arrives while that siege continues.

Jehoiachin goes out with his mother, servants, princes and officers. Babylon's king captures him in the eighth year of the Babylonian reign. “Went out” is retained as the observed act; motive, negotiation, surrender terms and coercion mechanics are unresolved.

## Verses 13-17 — Treasure removal, deportation and replacement

Temple and palace treasures are carried out, and Solomon-made gold temple vessels are cut according to prior LORD speech. The population statement says all Jerusalem, princes, mighty men, ten thousand captives, craftsmen and smiths are carried away, with only the poorest land people remaining. The next verses specify Jehoiachin, royal household and chief people, plus seven thousand men of might and one thousand craftsmen/smiths fit for war.

Those totals and classes are retained without forcing an arithmetic identity not stated by the source. “All Jerusalem” is read through its explicit exception and following class details, not promoted into a contradiction. Babylon's king installs Jehoiachin's father's brother Mattaniah and changes his name to Zedekiah.

## Verses 18-20 — Zedekiah and the next rebellion

Zedekiah begins at twenty-one and reigns eleven years in Jerusalem. He receives an evil evaluation according to Jehoiakim's acts. The narrator attributes the Jerusalem/Judah State to LORD's anger until they are cast from his presence. Zedekiah then rebels against Babylon's king.

The rebellion is complete as an act; its consequence belongs to the next retained source State. No motive, plan, allies, timing within the reign or outcome is imported from 2 Kings 25.

## CrackFlix frontier

No valid contradiction closes. Jehoiakim's service followed by rebellion and Zedekiah's later rebellion are changed political acts, not contradictions. The “all Jerusalem” phrase carries an immediate poorest-person exception and class breakdown; no false total-versus-survivor crack is manufactured.

## Bullshit pass

No bullshit closes. The apparent total “all Jerusalem” is source-qualified by the poorest-person exception and the following deportee classes. Service followed by rebellion records changed acts; it does not make either act false.

## God-line boundary

- Verses 2-4 attribute band sending, Judah destruction/removal and non-pardon to LORD and prior prophet speech.
- Verse 13 attributes the treasure/vessel outcome to prior LORD speech.
- Verse 20 attributes Jerusalem/Judah's State and casting-out route to LORD's anger.
- These are narrator attributions, not a visible God body or newly quoted direct speech.
- Human service, rebellion, siege, capture, deportation, installation and renaming remain separately typed acts.

## Character and world-ledger changes

- NOT-JEHOIAKIM JOE adds three-year Babylon service, rebellion, death and succession.
- NOT-JEHOIACHIN JOE adds three-month reign, siege exit, capture and Babylon deportation.
- NOT-NEBUCHADNEZZAR JOE adds territorial control, Jerusalem siege arrival, capture, treasure removal, deportation and replacement-king installation.
- NOT-MATTANIAH/ZEDEKIAH JOE adds installation, rename, eleven-year reign and rebellion.
- Royal household, officials, military people, craftspeople, smiths, captives and poorest remaining people retain distinct source classes; manufactured treasure and vessels remain faceless.

## Reconstruction boundary

All 20 source verse markers are retained. Each prose block addresses explicit verse ranges, while the exact USFM remains the reversible source carrier. The compound-eye image must keep the two rebellions distinct, separate siege from capture, retain the poorest-person exception, avoid inventing deportee arithmetic, and leave 2 Kings 25 outcomes future. Exact names remain in sidecars; visible story names use `NOT-`; workflow metadata stays outside story pixels.

Publication remains held.
