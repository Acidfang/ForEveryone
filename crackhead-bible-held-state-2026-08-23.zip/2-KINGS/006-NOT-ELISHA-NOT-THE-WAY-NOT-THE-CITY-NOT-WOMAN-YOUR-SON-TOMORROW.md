# CRACKHEAD 2 KINGS 6

## Title field

**NOT-ELISHA: THIS IS NOT THE WAY. THIS IS NOT THE CITY. I WILL TAKE YOU TO THE MAN YOU SEEK. / NOT-WOMAN: YOUR SON TOMORROW. [HIDES SON.]**

Source parent: ENGWEBP 2 Kings chapter 6, verses 1-33, USFM. Prepared evidence: `.chapter-work/CHB-2KI-006/job.json` and `source.usfm`. Parent: 2 Kings 5. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: recurring mental `S255-E003-2KI6`; new physical `S256-E001-2KI6`; new mental `S257-E001-2KI6`. Exactly one inert SKIP, from S255-E003 to S255-E002-2KI5. Exactly three separate causally null Captain YOINKs. One high-resolution 33-facet compound-eye image.

## Causal foundation

```text
PROPHET SONS NEED LARGER PLACE / CUT JORDAN WOOD
-> BORROWED AX HEAD FALLS IN WATER
-> ELISHA THROWS STICK / IRON FLOATS / OWNER TAKES IT
-> SYRIAN KING PLANS CAMPS / ELISHA WARNS ISRAEL KING REPEATEDLY
-> SYRIAN KING SUSPECTS INSIDER / SERVANT IDENTIFIES ELISHA
-> ARMY SURROUNDS DOTHAN
-> ELISHA: THOSE WITH US ARE MORE
-> LORD OPENS SERVANT EYES / FIRE HORSES AND CHARIOTS VISIBLE
-> ELISHA PRAYS / SYRIANS STRUCK BLIND
-> ELISHA SAYS NOT THE WAY/NOT THE CITY/WILL TAKE YOU TO MAN SOUGHT
-> RETAINED STATE: DOTHAN + ELISHA IS THE SOUGHT MAN
-> SKIP -> S255-E002 / S255-E003 CLOSES / YOINK
-> ELISHA LEADS THEM TO SAMARIA / EYES OPEN
-> ISRAEL KING ASKS TWICE TO STRIKE / ELISHA REFUSES
-> FEAST / RELEASE / RAIDING BANDS STOP
-> BENHADAD'S FULL ARMY BESIEGES SAMARIA / FAMINE
-> WOMAN REPORTS RECIPROCAL SON-EATING AGREEMENT
-> HER SON IS EATEN / OTHER WOMAN HIDES HER SON
-> S256 CLOSES / YOINK
-> KING TEARS CLOTHES / SACKCLOTH / VOWS ELISHA BEHEADING TODAY
-> MESSENGER SENT / ELISHA ANTICIPATES AND ORDERS DOOR HELD
-> SPEAKER: THIS EVIL IS FROM LORD
-> NO ADDRESSED CAUSAL EVIDENCE SUPPLIED
-> S257 CLOSES / YOINK
-> BEHEADING DEADLINE REMAINS OPEN AT CHAPTER EDGE
```

## Verses 1–7 — Larger quarters and floating borrowed iron

The prophet sons say their meeting place is too small, propose each taking a Jordan beam, receive permission and ask Elisha to accompany them. At the Jordan they cut wood. A borrowed ax head falls into the water. Elisha asks the location, cuts and throws a stick there, and the iron floats. The borrower reaches out and takes it. The source supplies exact acts and result but no buoyancy mechanism.

## Verses 8–17 — Repeated warning and opened sight

During Syrian war, the Syrian king privately selects camp locations. Elisha repeatedly warns Israel's king, who checks and avoids them. The Syrian king asks which servant is for Israel. A servant rejects the insider model and says Elisha tells Israel's king even bedroom words. The perception channel remains unresolved.

The Syrian king locates Elisha at Dothan and sends horses, chariots and a great army by night. Elisha's servant sees the city surrounded. Elisha says those with them are more than those with Syria. He prays that LORD open the servant's eyes; narrator says LORD does, and the servant sees a mountain full of fire horses and chariots around Elisha. No divine body or visibility mechanism is supplied.

## Verses 18–23 — Blind army, false route and feast

As Syrians descend, Elisha prays for blindness; narrator says they are struck according to his word. Elisha tells them: **This is not the way, neither is this the city. Follow me, and I will bring you to the man whom you seek.** They are at Dothan, and the sought man is the speaker Elisha. This repeats S255's asserted-occurrence-versus-retained-State structure. An inert **SKIP -> S255-E002-2KI5** points to the prior explanation; `S255-E003-2KI6` closes, and one YOINK changes no route or army.

Elisha leads them to Samaria. After his prayer, LORD opens their eyes and they see their location. Israel's king twice asks permission to strike them. Elisha refuses, asks whether captives taken by sword and bow would be struck, and orders bread and water. The king makes a great feast, sends them to their master, and Syrian bands stop raiding Israel. The later full-army siege is a different military class and does not erase the stopped-band occurrence.

## Verses 24–30 — Siege famine and withheld reciprocal son

After this, Benhadad gathers all his army and besieges Samaria. Famine prices rise to eighty silver pieces for a donkey head and five for a quarter-kab of dove dung. A woman asks the passing Israel king for help. He says without LORD's help he has no threshing-floor or winepress help, then asks her problem.

She reports another woman proposed: **Give your son so we may eat him today, and we will eat my son tomorrow.** They boil and eat the first speaker's son. On the next day the other woman hides her son instead of supplying him. The first supplied irreversible consideration; the named reciprocal act is withheld without revision or exception. This closes physical `S256-E001-2KI6`. One YOINK changes no death, famine or hidden child. Depiction remains restrained and non-graphic.

The king tears his clothes; observers see sackcloth beneath them.

## Verses 31–33 — Open beheading vow and unsupported causal attribution

The king swears that Elisha's head will not remain on him that day. Elisha sits with elders, anticipates the sent man, calls the sender a murderer's son, and orders the door held because the master's footsteps follow. The messenger arrives while Elisha is still speaking.

A speaker says: **This evil is from LORD. Why should I wait for LORD any longer?** The siege and famine are observed, but this line supplies no addressed LORD act, speech or causal bridge producing them. The asserted causal State exceeds the retained evidence and closes mental `S257-E001-2KI6`; one YOINK changes nothing. The beheading oath has not expired or been performed by chapter end, so it remains an open deadline rather than a prematurely closed contradiction.

## God-line boundary

- Elisha is repeatedly called man of God; his intelligence channel remains unresolved.
- Elisha prays for the servant's eyes to open; narrator attributes opening to LORD and the servant sees fire horses/chariots.
- Elisha prays for blindness and later restored sight; narrator attributes both outcomes to LORD.
- The king conditions help on LORD's help.
- The final speaker attributes the evil to LORD without a supplied causal carrier; this is speaker attribution, not narrator fact.
- No God body, sensory mechanism, iron mechanism or siege-causation mechanism is rendered.

## Character and world-ledger changes

- NOT-ELISHA JOE moves through iron recovery, repeated military warning, servant sight prayer, Syrian blindness, deceptive route, Samaria delivery, non-killing instruction and anticipated messenger.
- NOT-SERVANT JOE moves from visible encirclement fear to fire-army observation.
- NOT-SYRIAN-KING JOE moves from leaked camp plans through Dothan capture attempt and later whole-army siege.
- NOT-ISRAEL-KING JOE accepts warnings, feeds captured soldiers, later encounters famine testimony and opens a same-day Elisha-death deadline.
- TWO NOT-WOMAN JOES and TWO NOT-SON JOES retain the reciprocal agreement, performed first death and withheld second delivery without invented motives.

## Bullshit pass

Issue `2KI-006 / SECURITY TEAM FOLLOWS THE TARGET TO SECURITY HQ`.

- Intelligence lead leaks every ambush location to defense.
- Attacker sends an entire capture team to his city.
- Target: **THIS IS NOT THE CITY. I AM NOT THE TARGET. FOLLOW ME TO THE TARGET.**
- Capture team follows target into the capital.
- Capital feeds them and sends them home.
- Later, procurement contract: **WE CONSUME YOUR ASSET TODAY; OUR ASSET TOMORROW.**
- Day two: supplier hides the asset.
- Executive blames the whole famine on an unobserved authority and sends a beheading messenger.

Captain presses SKIP on the false route and YOINKs all three closed dashboards separately. Nothing changes.

## FIR verification

- FILTER: all 33 markers retained; 2 Kings 7 excluded.
- ISOLATE: building/iron, warning network, Dothan surround, opened sight, blindness/route/Samaria, feast/release, siege/famine, reciprocal child agreement, death vow and causal attribution.
- RECONSTRUCT: recurring S255 false route/target, new S256 withheld reciprocal delivery, new S257 unsupported LORD-cause assertion.
- VERIFY: exactly one SKIP and three YOINKs; beheading deadline open; no floating, intelligence, sight, blindness, famine or causal mechanism invented.

## Required compound-eye facets

1. Too-small meeting place.
2. Jordan beam/build proposal and permission.
3. Elisha invited/agrees.
4. Jordan wood cutting.
5. Borrowed ax head falls.
6. Location shown/stick thrown/iron floats.
7. Borrower takes iron.
8. Syrian private camp plan.
9. Elisha sends warning.
10. Israel king repeatedly checks/avoids.
11. Syrian king suspects insider.
12. Servant identifies Elisha bedroom-word channel.
13. Dothan location/capture order.
14. Night army surrounds city.
15. Servant sees encirclement/asks what to do.
16. More-with-us assurance.
17. Eyes opened/fire horses and chariots.
18. Blindness prayer/outcome.
19. Not-way/not-city/take-to-man claim; SKIP/S255-E003/YOINK.
20. Samaria arrival/eyes opened.
21. King asks twice to strike.
22. Elisha refuses/orders food and release.
23. Feast/release/bands stop.
24. Benhadad whole-army siege.
25. Famine/prices.
26. Woman asks king help.
27. King LORD-help/floor/press response.
28. Reciprocal son agreement report.
29. First son eaten/second hidden/S256 YOINK.
30. Torn clothes/sackcloth.
31. Same-day Elisha-head vow; deadline open.
32. Elisha anticipates messenger/door instruction/master footsteps.
33. Messenger arrives/evil-from-LORD claim/S257 YOINK.

All thirty-three facets appear simultaneously.

## Production boundary

One high-resolution 33-facet compound-eye image. `NOT-` identities and Joe faces for all living humans and animals, including horses. Iron, ax, stick, buildings, fire chariots, food, money and siege materials are nonliving/faceless. Exactly one inert SKIP and three separate boilless Captain sequences. Blindness, famine and child death restrained/non-graphic. No God body. Finished-story pixels only; workflow metadata sidecar-only.

*shrug*

OK.
