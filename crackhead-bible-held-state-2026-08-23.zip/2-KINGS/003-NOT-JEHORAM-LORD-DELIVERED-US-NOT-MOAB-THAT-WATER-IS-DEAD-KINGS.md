# CRACKHEAD 2 KINGS 3

## Title field

**NOT-JEHORAM: THE LORD BROUGHT US HERE TO GIVE US TO MOAB. / NOT-MOAB: THAT WATER IS BLOOD. THE KINGS KILLED EACH OTHER. TO THE PLUNDER! / NOT-ISRAEL: HELLO.**

Source parent: ENGWEBP 2 Kings chapter 3, verses 1-27, USFM. Prepared evidence: `.chapter-work/CHB-2KI-003/job.json` and `source.usfm`. Parent: 2 Kings 2. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: new mental `S251-E001-2KI3` and new mental `S252-E001-2KI3`. Zero SKIPs. Exactly two separate causally-null post-closure Captain YOINKs. One high-resolution 27-facet compound-eye field.

## Causal foundation

```text
JEHORAM REIGNS / MESHA TRIBUTE HISTORY / MOAB REBELS
-> JEHORAM MUSTERS ISRAEL / JEHOSHAPHAT AND EDOM JOIN
-> WILDERNESS-EDOM ROUTE / SEVEN DAYS / NO WATER
-> JEHORAM: LORD ASSEMBLED THREE KINGS TO DELIVER THEM TO MOAB
-> JEHOSHAPHAT SEEKS LORD PROPHET / THREE KINGS GO TO ELISHA
-> ELISHA REJECTS JEHORAM PROPHET ROUTE / RESPECTS JEHOSHAPHAT PRESENCE
-> MUSICIAN PLAYS / LORD HAND ON ELISHA
-> TRENCHES / NO VISIBLE WIND OR RAIN / WATER PROMISE
-> MOAB DELIVERY + LAND-DESTRUCTION SPEECH
-> MORNING WATER ARRIVES FROM EDOM / COUNTRY FILLS
-> MOAB SEES SUNLIT WATER RED
-> CLAIMS BLOOD / KINGS DESTROYED EACH OTHER / ADVANCES FOR PLUNDER
-> ISRAEL CAMP RISES / STRIKES MOAB / MOAB FLEES
-> S251 + S252 CLOSE / TWO YOINKS
-> ALLIED FORCE DAMAGES CITIES/LAND/SPRINGS/TREES / ATTACKS KIR HARESETH
-> MESHA + 700 FAIL BREAKTHROUGH TO EDOM KING
-> MESHA OFFERS SUCCESSOR SON ON WALL
-> GREAT WRATH AGAINST ISRAEL / ALLIES DEPART HOME
```

## Verses 1–8 — Reign, tribute, rebellion and the Edom route

Jehoram son of Ahab begins a twelve-year Israel reign. The narrator calls his conduct evil but distinguishes him from his parents because he removes Ahab's Baal pillar while retaining Jeroboam's sins.

Mesha of Moab is a sheep breeder whose tribute was one hundred thousand lambs and wool from one hundred thousand rams. After Ahab's death he rebels. Jehoram musters Israel and asks Jehoshaphat to join battle. Jehoshaphat repeats people-and-horses solidarity and asks the route; Jehoram selects the wilderness of Edom.

## Verses 9–14 — Seven days, no water, opposite causal claims

Israel, Judah and Edom kings march a circuitous route for seven days and run out of water for army and animals. Jehoram says LORD called the three kings together to deliver them to Moab. No prior LORD call or delivery act has been supplied.

Jehoshaphat instead asks for a LORD prophet. A servant identifies Elisha through his prior water-pouring service to Elijah; Jehoshaphat says LORD's word is with him. All three kings go down to Elisha.

Elisha tells Jehoram to use his parents' prophets. Jehoram repeats his LORD-delivered-us-to-Moab claim. Elisha says he would neither look at nor see Jehoram but for respecting Jehoshaphat's presence. This is an explicit recipient boundary, not universal refusal.

## Verses 15–20 — Musician, trenches and water without visible weather

Elisha requests a musician. When the musician plays, the narrator says LORD's hand comes on Elisha. Instrumental causation, mental mechanism and the identity of the musician remain unresolved.

Elisha carries instructions to fill the valley with trenches and says no wind or rain will be seen, yet the valley will fill so people and animals drink. He calls that easy in LORD's sight, adds Moab's delivery, and describes striking cities, felling trees, stopping springs and stoning land.

At morning sacrifice time, water comes by Edom's route and fills the country. The source gives the route and timing but no hydrological mechanism. The no-visible-wind/no-visible-rain statement is consistent with the narrated water and does not claim water has no physical source.

## Verses 21–24 — Sun on water becomes dead kings in Moab's model

Moab gathers everyone able to wear armor. At sunrise, the water opposite looks red as blood. Moab's speakers convert appearance into a completed causal history: **This is blood. The kings are surely destroyed and struck one another. Now to the plunder.** No body, battle, witness or blood carrier supports that account.

They reach Israel's camp. The Israelites rise and strike them; Moab flees and the allies advance.

The live allied attack falsifies both mental models. Jehoram's repeated claim that LORD assembled the kings for delivery to Moab closes `S251-E001-2KI3`: the alleged delivered kings instead strike and pursue Moab. Moab's red-water-to-dead-kings inference closes `S252-E001-2KI3`: the claimed mutual destruction is answered by the living camp. Two separate Captain **YOINK!** visits change no water, belief, army or battle.

## Verses 25–27 — Destroyed land, failed breakout, wall offering, withdrawal

The allies beat down cities, stone good land, stop springs and cut trees until Kir Hareseth's stones remain while slingers surround and attack it. The Moab king takes seven hundred swordsmen to break through to Edom's king; they cannot.

Mesha takes his oldest son, the successor, and offers him as a burnt offering on the wall. Great wrath occurs against Israel; the allies depart from Mesha and return home.

The source does not identify the wrath's owner, target mechanism, observer, relationship to the offering, or military process causing withdrawal. Sequence alone is not upgraded to mechanism. The son dies in the explicit offering; depiction remains restrained. Whether the earlier “deliver Moab” speech includes complete occupation, and how the final withdrawal relates to it, remains unresolved rather than forced into a third crack.

## God-line boundary

- Jehoram twice attributes the kings' assembly and expected defeat to LORD; these are human causal claims.
- Elisha attributes trenches, unseen-weather water, Moab delivery and destruction instructions to LORD after the musician/LORD-hand narrator sequence.
- Water arrival is narrator event; no divine body or hidden water creation mechanism is rendered.
- Moab's blood/dead-kings account is speaker inference from red appearance, not narrator fact.
- “Great wrath” has no named owner or mechanism and remains source-language only.

## Character and world-ledger changes

- NOT-JEHORAM JOE moves from accession through Moab campaign, repeated defeat attribution, Elisha rejection, water survival and victorious attack.
- NOT-JEHOSHAPHAT JOE supplies alliance and prophet inquiry; his presence is Elisha's explicit condition for engagement.
- NOT-EDOM-KING JOE joins the route and becomes Mesha's failed-breakthrough target.
- NOT-ELISHA JOE receives musician/LORD-hand sequence, routes trenches/water and carries campaign speech.
- NOT-MESHA JOE moves from tribute/rebellion through defense, failed breakout and sacrifice of his successor son.
- NOT-MOAB JOES manufacture a dead-kings account from sunlit water and enter the live camp for plunder.

## Bullshit pass

Issue `2KI-003 / RED DASHBOARD MEANS ALL COMPETITORS KILLED EACH OTHER`.

- Three organizations select a seven-day migration with no water.
- Lead organization: **AUTHORITY BROUGHT US HERE TO HAND US TO THE COMPETITOR.**
- Consultant requests live music, then says dig trenches.
- Dashboard fills with water despite no visible weather event.
- Competitor sees red reflection: **THAT IS BLOOD. ALL THREE ORGANIZATIONS DESTROYED EACH OTHER. FREE ASSETS!**
- Competitor enters environment.
- Three live organizations: **WELCOME TO THE INCIDENT REVIEW.**

Captain licks the defeat forecast and blood dashboard separately. **YOINK! YOINK!** Nothing changes.

## FIR verification

- FILTER: all 27 markers retained; 2 Kings 4 excluded.
- ISOLATE: reign/tribute/rebellion, alliance/route, no-water crisis, Jehoram model, Elisha boundary, musician/water prophecy, water arrival, Moab inference, battle, destruction, sacrifice and withdrawal.
- RECONSTRUCT: new S251 defeat model versus allied victory and S252 red-water/dead-kings model versus live camp.
- VERIFY: zero SKIPs, two YOINKs, no musician mechanism, divine body, water mechanism, Moab evidence, wrath owner, sacrifice-to-withdrawal cause or total-delivery scope invented.

## Required compound-eye facets

1. Jehoram accession/twelve-year reign.
2. Evil-but-not-parents/Baal pillar removal.
3. Jeroboam-sin retention.
4. Mesha 100000 lambs/100000 rams' wool tribute.
5. Ahab death/Moab rebellion.
6. Jehoram musters Israel.
7. Jehoshaphat alliance/people/horses.
8. Wilderness-Edom route selection.
9. Three kings/seven-day circuit/no army-animal water.
10. Jehoram LORD-delivered-us-to-Moab claim.
11. Prophet inquiry/Elisha water-pouring identity.
12. LORD-word-with-Elisha/three kings descend.
13. Elisha rejects Jehoram route/Jehoram repeats defeat claim.
14. Elisha Jehoshaphat-only respect boundary.
15. Musician plays/LORD hand narrator event.
16. Valley trenches instruction.
17. No visible wind/rain/water fill/drinking promise.
18. Easy/Moab-delivery speech.
19. City/tree/spring/land destruction speech.
20. Morning water from Edom/country filled.
21. Moab all armor-capable gather/border.
22. Sunrise makes water look red as blood.
23. Moab declares blood/kings mutually destroyed/to plunder.
24. Israel rises/strikes/Moab flees; S251 and S252 two YOINKs.
25. Cities/land/springs/trees/Kir Hareseth attack.
26. Mesha/700 failed Edom-king breakout.
27. Oldest successor son wall offering/great wrath/withdrawal, restrained.

All twenty-seven facets appear simultaneously.

## Production boundary

One high-resolution 27-facet compound-eye image. `NOT-` identities and Joe faces for every living thing, including sheep, rams, horses and other animals. Water, trenches, instruments, armor, cities, trees, springs, stones and remains are nonliving/faceless. Zero SKIPs. Exactly two separate boilless Captain poke/lick/YOINK/walk-away carriers. Battle, land destruction and wall offering restrained/non-graphic. Great wrath remains an unowned text carrier, not a deity/body/effect invention. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
