# CRACKHEAD 2 KINGS 8

## Title field

**NOT-SHUNAMMITE: SEVEN YEARS AWAY. GIVE BACK MY HOUSE, LAND AND EVERY HARVEST. / NOT-ELISHA: RECOVER FROM THE SICKNESS. SURELY DIE. / NOT-HAZAEL: [WET CLOTH.]**

Source parent: ENGWEBP 2 Kings chapter 8, verses 1-29, USFM. Prepared evidence: `.chapter-work/CHB-2KI-008/job.json` and `source.usfm`. Parent: 2 Kings 7. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: zero contradiction occurrences, zero SKIPs, zero Captain/YOINKs. One high-resolution 29-facet compound-eye image.

## Causal foundation

```text
ELISHA WARNS RESTORED-SON WOMAN OF SEVEN-YEAR FAMINE
-> HOUSEHOLD LIVES IN PHILISTINE LAND SEVEN YEARS
-> WOMAN RETURNS / PETITIONS FOR HOUSE AND LAND
-> GEHAZI TELLS KING RESTORED-SON HISTORY AS WOMAN ARRIVES
-> KING VERIFIES WITH WOMAN
-> OFFICER ORDERED TO RESTORE PROPERTY + ALL SEVEN-YEAR FIELD FRUIT
-> ELISHA ARRIVES DAMASCUS / BENHADAD SICK
-> HAZAEL BRINGS FORTY-CAMEL GIFT / ASKS RECOVERY
-> ELISHA: RECOVER FROM SICKNESS / LORD SHOWED SURE DEATH
-> ELISHA WEEPS / FORETELLS HAZAEL VIOLENCE + KINGSHIP
-> HAZAEL REPORTS RECOVERY ONLY
-> NEXT DAY HAZAEL APPLIES WET THICK CLOTH / BENHADAD DIES
-> HAZAEL REIGNS
-> JEHORAM OF JUDAH REIGNS / EVIL CLASSIFICATION
-> EDOM + LIBNAH REVOLT / JORAM NIGHT BREAKOUT / REBELLION PERSISTS
-> JORAM DIES / AHAZIAH SUCCEEDS
-> AHAZIAH JOINS ISRAEL JORAM AGAINST HAZAEL
-> JORAM WOUNDED / RETURNS JEZREEL / AHAZIAH VISITS
```

## Verses 1–6 — Seven-year absence and complete restoration order

The woman whose son Elisha restored had earlier received his instruction to leave with her household because LORD called a seven-year famine. She performs the instruction and lives in Philistine land seven years. At the end she returns and petitions the king for house and land.

At that Moment the king is asking Gehazi for Elisha's great acts. While Gehazi recounts restoring the dead child, the woman and son arrive. Gehazi identifies them; the king asks her, and she tells him. He appoints an officer to restore everything that was hers and all field fruits from departure until now. The actual officer execution and recovered quantities remain unresolved; the royal order itself is complete.

The chronology of Gehazi's audience relative to his 2 Kings 5 leprous exit is not stated. Narrative placement is not silently converted into continuous elapsed order or a healing event.

## Verses 7–15 — Recover from sickness, die by Hazael

Elisha comes to Damascus while Benhadad is sick. The king sends Hazael with forty camel-loads of every good Damascus thing to ask through Elisha whether he will recover from this sickness.

Elisha instructs Hazael to say Benhadad will surely recover, then adds that LORD showed him Benhadad will surely die. These propositions are not forced into contradiction: recovery is scoped to the sickness; the observed death comes from Hazael's separate next-day act. The source does not observe whether sickness recovery completed before death.

Elisha stares, then weeps. He says he knows future evil Hazael will do to Israel: burn strongholds and kill young men, little ones and pregnant women. Hazael asks how a servant who is a dog could do such a great thing. Elisha says LORD showed him Hazael as Syrian king. The violent list remains forecast here and is not rendered as already performed.

Hazael reports only the recovery statement to Benhadad. The next day he wets a thick cloth, spreads it on the king's face so he dies, and succeeds him. The mechanism is explicit enough to retain Hazael's killing act, while depiction remains restrained.

## Verses 16–24 — Jehoram of Judah, revolts and succession

Jehoram son of Jehoshaphat begins Judah's reign at thirty-two and reigns eight years. Narrator links his Israel-king way and evil classification to marriage with Ahab's daughter. LORD nevertheless does not destroy Judah for David's sake, preserving the promised lamp lineage.

Edom revolts and appoints a king. Joram crosses to Zair, breaks through surrounding Edomites by night, and his people flee to tents. Edom's revolt persists to the narrator's day; Libnah also revolts. These territorial losses are not equated to Judah's complete destruction.

Joram's other acts are addressed to the Judah chronicles. He dies, is buried in David's city, and Ahaziah succeeds.

## Verses 25–29 — Ahaziah, Hazael war and wounded Joram

Ahaziah begins a one-year Judah reign at twenty-two. His mother is Athaliah, identified as Omri's daughter. Narrator places him in Ahab-house conduct and evil classification through the family relation.

Ahaziah joins Joram of Israel at Ramoth Gilead against Hazael. Syrians wound Joram. Joram returns to Jezreel for healing; Ahaziah visits because he is sick. No recovery, death or later political outcome is imported from chapter 9.

## God-line boundary

- Elisha attributes the seven-year famine call to LORD; the woman performs departure and return.
- Benhadad asks inquiry of LORD through Elisha.
- Elisha says LORD showed Benhadad's death and Hazael's kingship.
- Narrator says LORD preserves Judah for David and the promised lamp.
- Narrator classifications of evil remain narrator reports, not God-body scenes.
- No divine body, revelation mechanism, famine mechanism or recovery State is invented.

## Character and world-ledger changes

- NOT-SHUNAMMITE JOE and NOT-SON JOE extend from 2 Kings 4 through seven-year migration, return, identity verification and property-restoration order.
- NOT-GEHAZI JOE appears as history witness; timing relative to his leprous exit remains unresolved.
- NOT-HAZAEL JOE moves from envoy through recovery report, Benhadad killing and Syrian accession; forecast Israel violence remains future.
- NOT-BENHADAD JOE moves from sickness/inquiry through Hazael's wet-cloth killing.
- NOT-JEORAM-OF-JUDAH JOE and NOT-AHAZIAH JOE enter distinct Judah reign paths; they are not merged with NOT-JORAM-OF-ISRAEL JOE.

## Bullshit pass

Issue `2KI-008 / SUCCESSION PLANNING WITH FORTY CAMELS`.

- Returning tenant asks for seven years of property output.
- King's live storyteller: **THAT IS THE EXACT PERSON IN MY STORY.**
- King: **RETURN EVERYTHING INCLUDING EVERY HARVEST.**
- Sick executive sends successor candidate with forty camel-loads to ask prognosis.
- Consultant: **HE RECOVERS FROM THE ILLNESS. HE DEFINITELY DIES. YOU BECOME CEO.**
- Candidate reports only recovery.
- Next day candidate applies wet-cloth succession protocol.
- Candidate becomes CEO.

Captain hears no validated crack and does absolutely nothing.

## FIR verification

- FILTER: all 29 markers retained; 2 Kings 9 excluded.
- ISOLATE: famine migration/restoration, Damascus inquiry, scoped recovery/death, Hazael forecast/killing/accession, Judah reign/revolts/succession and Ramoth wounds.
- RECONSTRUCT: zero contradictions; separate sickness prognosis from killing outcome and prophecy from performed acts.
- VERIFY: zero SKIPs/YOINKs; no Gehazi healing, Benhadad sickness recovery, future atrocity, divine form or hidden mechanism invented.

## Required compound-eye facets

1. Elisha prior seven-year famine warning.
2. Woman/household seven years in Philistine land.
3. Return/petition for house and land.
4. King asks Gehazi for Elisha acts.
5. Restored-child story and woman/son arrival/identity.
6. King verifies and orders all property/fruits restored.
7. Elisha Damascus/Benhadad sick.
8. Hazael gift/inquire-of-LORD instruction.
9. Forty camel-load arrival/recovery question.
10. Recover-from-sickness/surely-die statement.
11. Steady gaze/Elisha weeps.
12. Forecast stronghold and human violence, restrained as speech.
13. Hazael dog question/LORD-shown-kingship response.
14. Hazael reports recovery.
15. Wet cloth/Benhadad death/Hazael accession, restrained.
16. Jehoram Judah accession synchronism.
17. Age thirty-two/eight years.
18. Ahab-house marriage/evil classification.
19. David-lamp/Judah non-destruction statement.
20. Edom revolt/own king.
21. Joram Zair night breakout/people flee.
22. Edom and Libnah revolts persist.
23. Judah chronicles pointer.
24. Joram death/burial/Ahaziah succession.
25. Ahaziah synchronism.
26. Age twenty-two/one year/Athaliah-Omri relation.
27. Ahab-house way/evil/son-in-law relation.
28. Ahaziah/Joram war against Hazael/Joram wounded.
29. Joram heals at Jezreel/Ahaziah visits; later outcome excluded.

All twenty-nine facets appear simultaneously.

## Production boundary

One high-resolution 29-facet compound-eye image. `NOT-` identities and Joe faces for all living humans and animals, including camels and horses. Property, gifts, cloth, water, crowns, weapons and cities are nonliving/faceless. Zero SKIPs and zero Captain/YOINKs. Forecast violence remains text/vision carrier; Benhadad death and battle wounds restrained/non-graphic. No God body. Finished-story pixels only; workflow metadata sidecar-only.

*shrug*

OK.
