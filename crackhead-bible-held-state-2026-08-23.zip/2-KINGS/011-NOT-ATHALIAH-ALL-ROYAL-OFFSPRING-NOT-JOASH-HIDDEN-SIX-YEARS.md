# CRACKHEAD 2 KINGS 11

## Title field

**NOT-ATHALIAH: DESTROYED ALL ROYAL OFFSPRING. / NOT-JOASH: [HIDDEN SIX YEARS.] LONG LIVE THE KING. / TREASON! TREASON!**

Source parent: ENGWEBP 2 Kings chapter 11, verses 1-21, USFM. Prepared evidence: `.chapter-work/CHB-2KI-011/job.json` and `source.usfm`. Parent: 2 Kings 10. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: one recurring contradiction occurrence, `S130-E005-2KI11`, with exact inert SKIP to `S130-E004-JDG1`, followed by exactly one causally-null Captain/YOINK. One high-resolution 21-facet compound-eye image.

## Causal foundation

```text
ATHALIAH SEES AHAZIAH DEAD
-> DESTROYS ALL ROYAL OFFSPRING
-> JEHOSHEBA REMOVES JOASH + NURSE FROM AMONG SLAIN
-> JOASH SURVIVES / HID SIX YEARS IN LORD HOUSE
-> ATHALIAH REIGNS SIX YEARS
-> YEAR SEVEN JEHOIADA COVENANTS WITH CAPTAINS / SHOWS KING'S SON
-> SABBATH WATCH PLAN + WEAPONS DISTRIBUTED
-> GUARD SURROUNDS JOASH
-> JOASH CROWNED / GIVEN COVENANT / ANOINTED / ACCLAIMED
-> ATHALIAH HEARS / ENTERS / SEES KING / CRIES TREASON
-> JEHOIADA ORDERS HER REMOVED / NO KILLING IN LORD HOUSE
-> ATHALIAH SEIZED / KILLED AT HORSE ENTRY
-> LORD-KING-PEOPLE + KING-PEOPLE COVENANTS
-> BAAL HOUSE/ALTARS/IMAGES BROKEN / MATTAN KILLED
-> LORD HOUSE OFFICERS APPOINTED
-> JOASH ESCORTED TO KING HOUSE / SITS ON THRONE
-> LAND REJOICES / CITY QUIET / JOASH AGE SEVEN
```

## Verses 1-3 — All royal offspring, except the child removed alive

Athaliah sees her son Ahaziah is dead, rises, and destroys all royal offspring. Jehosheba—Joram's daughter and Ahaziah's sister—takes Ahaziah's son Joash and his nurse away from among the slain king's sons, places them in a bedroom, and hides him from Athaliah so he is not killed.

Joash remains hidden with Jehosheba in LORD's house for six years while Athaliah reigns. No mechanism, assistant population or exact room transition beyond the supplied bedroom/house carriers is invented.

`S130-E005-2KI11` closes the retained total-removal mismatch: the source states Athaliah destroyed all royal offspring while explicitly retaining one royal offspring alive within that selected population. SKIP points to `S130-E004-JDG1`; it removes no killing, rescue, concealment or reign. One separate post-closure YOINK changes nothing.

## Verses 4-11 — Seventh-year covenant and guard geometry

In year seven Jehoiada summons the hundred-captains of Carites and guards into LORD's house, makes covenant with them, and shows them the king's son. His Sabbath plan assigns three incoming thirds to the king's house, Sur gate and rear guard gate; the two outgoing companies remain around the king in LORD's house.

Every guard is armed. Anyone entering the ranks is to be killed, and the formation accompanies the king in and out. The captains perform the plan, bringing both incoming and outgoing Sabbath groups. Jehoiada distributes David's spears and shields retained in LORD's house. Guards span right to left beside altar and house, surrounding the child.

The lethal perimeter rule is prospective here; no unauthorized entrant or perimeter killing occurs in the chapter.

## Verses 12-16 — Coronation, treason cry and Athaliah's death

Jehoiada brings out the king's son, crowns him, gives him the covenant, makes and anoints him king. People clap and say, “Long live the king!” The covenant carrier's exact physical form is unresolved and is not invented as a modern book or tablet.

Athaliah hears guard-and-people noise, enters LORD's house, and sees the crowned king at the traditional pillar, captains and trumpets beside him, and the people rejoicing. She tears her clothes and cries “Treason! Treason!” This is her accusation during the observed replacement of her reign; it is not treated as a false occurrence or a claim of her own innocence.

Jehoiada orders captains to bring her outside the ranks and kill by sword anyone who follows her, explicitly refusing her death inside LORD's house. They seize her, take her through the horses' entry to the king's house, and kill her there. The death remains restrained.

## Verses 17-21 — Covenants, Baal-house destruction and seven-year-old king

Jehoiada makes one covenant between LORD, king and people that they should be LORD's people, and another between king and people. This chapter records Jehoiada's covenant act; it does not narrate direct LORD speech or a divine body.

All land people break down Baal's house, altars and images and kill Mattan the priest before the altars. Jehoiada appoints officers over LORD's house. The escort brings Joash through the guard gate to the king's house, where he sits on the kings' throne.

All land people rejoice and the city is quiet after Athaliah's death. Joash is seven when his reign begins. “All people” remains scoped to the land people named in this public transition; no universal-population inference is made.

## God-line boundary

- Joash is hidden in LORD's house; the location does not imply an unspoken divine act.
- Jehoiada makes covenants involving LORD, king and people; no direct LORD reply is recorded.
- David's spears and shields are stored in LORD's house and used by guards.
- Jehoiada excludes Athaliah's killing from LORD's house and later appoints officers over it.
- No God body, protection miracle, coronation approval voice or covenant mechanism is invented.

## Character and world-ledger changes

- NOT-ATHALIAH JOE moves from Ahaziah's death through royal-offspring destruction, six-year reign, coronation confrontation, removal and death.
- NOT-JOASH JOE moves from rescued infant through six hidden years to crowned, anointed seven-year-old king.
- NOT-JEHOSHEBA JOE and NOT-NURSE JOE retain the rescue and concealment path; neither is erased once Joash appears publicly.
- NOT-JEHOIADA JOE carries covenant, security plan, coronation, removal order, public covenants and temple-officer appointment.
- NOT-CAPTAIN and NOT-GUARD JOES perform the bounded watch and escort plan; no unperformed perimeter killing is attributed.

## Bullshit pass

Issue `2KI-011 / SIX-YEAR SUCCESSION AUDIT`.

- Queen mother: **I DESTROYED ALL ROYAL OFFSPRING.**
- Royal offspring, from a temple bedroom for six years: **HELLO.**
- Priest runs a five-company Sabbath security deployment using museum weapons.
- Seven-year-old receives crown, covenant and throne.
- Entire crowd: **LONG LIVE THE KING.**
- Former queen enters the ceremony she was not invited to.
- Former queen: **TREASON! TREASON!**
- Priest: **YES, BUT TAKE IT OUTSIDE.**
- City becomes quiet.

Captain YOINKs the one closed total-removal boil and cannot remove six years of causal history.

## FIR verification

- FILTER: all 21 markers retained; 2 Kings 12 excluded.
- ISOLATE: royal-offspring destruction/rescue, six-year concealment, seventh-year guard plan, coronation, Athaliah removal/death, covenants, Baal-house destruction and throne installation.
- RECONSTRUCT: one S130 total-removal recurrence; Athaliah's treason cry stays an accusation within an observed overthrow.
- VERIFY: exactly one inert SKIP and one YOINK; no miracle, survivor motive, covenant object, hidden guilt or direct God speech invented.

## Required compound-eye facets

1. Athaliah sees Ahaziah dead/destroys all royal offspring.
2. Jehosheba takes Joash/nurse from among slain into bedroom.
3. Joash hidden six years in LORD house while Athaliah reigns.
4. S130-E005 closure with SKIP to S130-E004 and one YOINK.
5. Seventh-year captain summons/covenant/king's son revealed.
6. First Sabbath third guards king's house.
7. Second/third groups at Sur and rear-guard gates/barrier.
8. Two outgoing companies guard LORD house around king.
9. Armed surround/entrant-death rule/accompany king.
10. Captains gather incoming and outgoing companies.
11. David spears/shields distributed/guard line around king.
12. Joash brought out/crowned/given covenant/anointed/acclaimed.
13. Athaliah hears noise and enters LORD house.
14. King at pillar/captains/trumpets/rejoicing people.
15. Athaliah tears clothes/treason cry.
16. Jehoiada orders outside removal/follower rule/no temple killing.
17. Athaliah seized/horse-entry route/killed outside, restrained.
18. LORD-king-people and king-people covenants.
19. Baal house/altars/images broken/Mattan killed, restrained.
20. LORD-house officers/escort/guard gate/Joash enthroned.
21. Land rejoices/city quiet/Joash age seven.

All twenty-one facets appear simultaneously.

## Production boundary

One high-resolution 21-facet compound-eye image. `NOT-` identities and Joe faces for all living humans and horses. Bedroom, temple, gates, crown, covenant carrier, spears, shields, pillar, trumpets, throne, altars and images are nonliving/faceless. One exact inert SKIP and exactly one separate post-closure Captain/YOINK. Royal deaths, Athaliah's death and Mattan's death restrained/non-graphic. No God body. Finished-story pixels only; workflow metadata sidecar-only.

*shrug*

OK.
