# CRACKHEAD 2 KINGS 14

## Title field

**NOT-AMAZIAH: COME, LOOK ME IN THE FACE. / NOT-JEHOASH: YOUR HEART HAS LIFTED YOU UP. / NOT-NARRATOR: JUDAH LOST.**

Source parent: ENGWEBP 2 Kings chapter 14, verses 1-29, USFM. Prepared evidence: `.chapter-work/CHB-2KI-014/job.json` and `source.usfm`. Parent: 2 Kings 13. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: one mental recurrence, `S254-E002-2KI14`, with inert `SKIP -> S254-E001-2KI5` and one causally-null Captain YOINK. One high-resolution 29-facet compound-eye image.

## Causal foundation

```text
AMAZIAH REIGNS / JOASH-PATH EVALUATION / HIGH PLACES REMAIN
-> KILLS FATHER'S KILLERS / SPARES THEIR CHILDREN UNDER WRITTEN LAW
-> DEFEATS EDOM / TAKES SELA / RENAMES IT
-> CHALLENGES JEHOASH TO FACE-TO-FACE MEETING
-> JEHOASH ANSWERS WITH THISTLE FABLE
-> OBSERVED EDOM VICTORY + CHALLENGE
-> JEHOASH ASSERTS AMAZIAH'S INTERNAL HEART/GLORY STATE
-> MENTAL CRACK S254-E002 / SKIP POINTS TO S254-E001 / ONE YOINK
-> AMAZIAH DOES NOT LISTEN / KINGS MEET
-> JUDAH DEFEATED / AMAZIAH CAPTURED / WALL BREACHED
-> TREASURES + HOSTAGES TAKEN / JEHOASH RETURNS
-> JEHOASH DIES / JEROBOAM SUCCEEDS
-> AMAZIAH LIVES FIFTEEN MORE YEARS
-> CONSPIRACY / FLIGHT / KILLING / BURIAL
-> AZARIAH SUCCEEDS / REBUILDS ELATH
-> JEROBOAM II REIGNS / EVIL CLASSIFICATION
-> BORDER RESTORED ACCORDING TO LORD WORD THROUGH JONAH
-> NARRATOR: LORD SAW BITTER AFFLICTION / NO HELPER / SAVED BY JEROBOAM
-> JEROBOAM DIES / ZECHARIAH SUCCEEDS
```

## Verses 1-7 — Reign, individual liability and Edom victory

Amaziah begins at twenty-five and reigns twenty-nine years. Narrator evaluates him as right in LORD's eyes, but on his father Joash's route rather than David's; high places and their worship remain.

Once established, he kills the servants who killed his father but does not kill their children. The narrator explicitly joins this to the written Moses-law command that each person dies for their own sin. He then kills ten thousand Edomites, takes Sela by war and names it Joktheel. The battle is restrained and no divine participation is invented.

## Verses 8-14 — Challenge, unsupported internal State and defeat

Amaziah sends Jehoash a challenge to look one another in the face. Jehoash replies with a thistle, cedar and trampling-animal fable, then states: Amaziah struck Edom, his heart lifted him up, he should enjoy the glory and remain home. The fable is Jehoash's speech, not a literal historical event.

The Edom victory and challenge are observed. Amaziah's internal heart/glory motive is not observed or stated by Amaziah. Jehoash asserts it as present fact without an evidentiary bridge. That is mental recurrence `S254-E002-2KI14`; `SKIP -> S254-E001-2KI5` omits the already-retained explanation without changing causality. Captain receives one post-closure YOINK and contributes nothing.

Amaziah does not listen. The kings meet; Judah loses and flees. Jehoash captures Amaziah, breaks four hundred cubits of Jerusalem wall, takes temple and palace treasure plus hostages, and returns to Samaria. This later loss supports Jehoash's warning about possible harm, but it does not verify the earlier internal-motive assertion.

## Verses 15-22 — Two deaths and Azariah succession

Jehoash's remaining acts point to chronicles. He dies, is buried in Samaria and Jeroboam succeeds. Amaziah lives fifteen years beyond Jehoash, then a conspiracy forms; he flees to Lachish, is pursued and killed, transported by horses and buried in David's city. Conspiracy motive is unresolved.

Judah makes sixteen-year-old Azariah king. He builds Elath and restores it to Judah after Amaziah's death. Construction details and prior Elath State are not supplied.

## Verses 23-29 — Jeroboam II, restored border and attributed relief

Jeroboam son of Joash begins a forty-one-year Israel reign. Narrator classifies his path as evil and continuous with Jeroboam son of Nebat.

He restores Israel's border from Hamath's entrance to the Arabah sea according to LORD's word spoken through Jonah son of Amittai. Narrator says LORD saw Israel's very bitter affliction and absence of a helper, had not said Israel's name would be blotted out, and saved them through Jeroboam's hand. These are typed narrator/mediated attributions; no God body or invisible mechanism is rendered.

Jeroboam's other acts, might, warfare and recovery of Damascus and Hamath point to chronicles. He dies and Zechariah succeeds.

## God-line boundary

- Written law is attributed to LORD through Moses.
- LORD's border word is mediated through Jonah.
- Narrator attributes seeing affliction, non-erasure and saving through Jeroboam to LORD.
- Jehoash's heart/motive assertion remains human speech and a mental crack.
- No God body, battle intervention, motive, prophetic mechanism or invisible saving act is invented.

## Character and world-ledger changes

- NOT-AMAZIAH JOE closes through reign, individual-liability enforcement, Edom victory, challenge, defeat, conspiracy flight, killing and burial.
- NOT-JEHOASH JOE closes through fable/warning, unsupported internal-State assertion, victory, capture, wall breach, seizure, death and burial.
- NOT-AZARIAH JOE succeeds Amaziah and restores Elath; NOT-JEROBOAM JOE restores the border and later dies; NOT-ZECHARIAH JOE succeeds him.
- `S254-E002-2KI14` retains one mental recurrence, one inert SKIP and one causally-null Captain YOINK.

## Bullshit pass

- King wins against Edom.
- King sends: **COME LOOK ME IN THE FACE.**
- Other king: **YOUR HEART HAS LIFTED YOU UP. ENJOY YOUR GLORY. STAY HOME.**
- He observed the win and message, not the other man's heart.
- `SKIP -> S254-E001-2KI5` points to the existing unsupported-motive contradiction.
- Later defeat proves defeat. It does not retroactively turn mind-reading into observation.
- Captain licks one boil and changes absolutely nothing.

## Required compound-eye facets

Exactly F001-F029, one per verse marker, simultaneously present. F010 carries `S254-E002-2KI14`, the exact inert SKIP pointer and the separate post-closure Captain sequence. All battles, killings and bodies remain restrained. Finished-story pixels only; workflow metadata sidecar-only.

## FIR verification

- FILTER: all 29 markers retained; 2 Kings 15 excluded.
- ISOLATE: Amaziah reign/liability/Edom/challenge/defeat/death, Azariah transition, Jeroboam reign/restoration and LORD/Jonah attribution.
- RECONSTRUCT: observed victory/message separated from asserted internal motive and later defeat.
- VERIFY: one mental recurrence, one SKIP, one YOINK; no motive, divine form, battle mechanism or conspiracy explanation invented.

*shrug*

OK.
