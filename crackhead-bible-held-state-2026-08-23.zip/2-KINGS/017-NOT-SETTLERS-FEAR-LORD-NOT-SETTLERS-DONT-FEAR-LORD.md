# CRACKHEAD 2 KINGS 17

## Title field

**NOT-SETTLERS: WE FEAR THE LORD AND SERVE OUR GODS. / NOT-NARRATOR: THEY DON'T FEAR THE LORD. / NOT-NARRATOR: THEY FEAR THE LORD AND SERVE THEIR IMAGES.**

Source parent: ENGWEBP 2 Kings chapter 17, verses 1-41, USFM. Prepared evidence: `.chapter-work/CHB-2KI-017/job.json` and `source.usfm`. Parent: 2 Kings 16. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: new physical series `S259`, two occurrences: `S259-E001-2KI17` has no SKIP; `S259-E002-2KI17` uses inert `SKIP -> S259-E001-2KI17`. Exactly two causally-null Captain YOINKs. One high-resolution 41-facet compound-eye image.

## Causal foundation

```text
HOSHEA REIGNS 9 YEARS / ASSYRIAN TRIBUTE
-> EGYPT MESSENGERS + TRIBUTE STOPS
-> HOSHEA IMPRISONED / SAMARIA BESIEGED 3 YEARS
-> SAMARIA TAKEN / ISRAEL DEPORTED
-> NARRATOR EXPLAINS ISRAEL ACTS + REPEATED PROPHET WARNINGS
-> ISRAEL REMOVED / JUDAH REMAINS BUT ALSO DOES NOT KEEP
-> ASSYRIA SETTLES FIVE SOURCE PEOPLES IN SAMARIA
-> NARRATOR: LORD SENDS LIONS / SOME SETTLERS KILLED
-> SETTLERS REPORT LAND-GOD LAW MODEL
-> ASSYRIAN KING RETURNS ONE EXILED PRIEST
-> PRIEST TEACHES HOW TO FEAR LORD
-> EACH SETTLER NATION ALSO INSTALLS OWN GODS/PRIESTS
-> THEY FEARED LORD + SERVED OWN GODS
-> THEY DON'T FEAR LORD
-> S259-E001 / ONE YOINK
-> RETAINED COVENANT COMMANDS REHEARSED
-> THEY DO NOT LISTEN / CONTINUE PRIOR PRACTICE
-> THEY FEARED LORD + SERVED ENGRAVED IMAGES
-> S259-E002 / SKIP->E001 / ONE YOINK
-> CHILDREN REPEAT PRACTICE
```

## Verses 1-6 — Hoshea, conspiracy, siege and deportation

Hoshea reigns nine years and is evaluated evil, though unlike earlier Israel kings. Shalmaneser imposes service/tribute. Hoshea sends to Egypt and stops annual tribute; Assyria identifies conspiracy, imprisons him, besieges Samaria three years, captures it and relocates Israel to named Assyrian territories.

The messenger, tribute and imprisonment chain is explicit. Motive beyond the observable alliance/tribute break and deportation logistics remain unresolved.

## Verses 7-23 — Narrator's causal explanation of Israel's removal

Narrator attributes removal to Israel's retained acts: other-god fear, adopted statutes, secret wrongs, high places, pillars, Asherah, incense, idols, ignored warnings, covenant rejection, calves, sky army, Baal, children through fire, divination and enchantments. LORD's warning through prophets/seers is quoted: turn and keep the commanded law.

The chapter says Israel does not listen and retains those paths until removal according to prophetic speech. Judah is separately said not to keep the commandments. These are narrator and mediated explanation layers, not independently observed motives for every person. Fire/children remain restrained.

## Verses 24-28 — Replacement settlers, lions and returned priest

Assyria installs people from Babylon, Cuthah, Avva, Hamath and Sepharvaim in Samaria. Narrator says they do not fear LORD and LORD sends lions that kill some.

The settlers report a model to Assyria: they do not know “the law of the god of the land,” therefore he sent lions. Their report is kept distinct from the narrator's preceding attribution. The king returns one deported priest, who lives at Bethel and teaches how to fear LORD. The exact teaching and any change in lion events are not supplied.

## Verses 29-34 — Mixed worship and first fear contradiction

Each nation installs its own gods in existing high-place houses; the named manufactured gods remain nonliving and faceless. Sepharvites burn children; depiction is non-graphic. Settlers appoint their own high-place priests.

Verse 33 states they feared LORD and also served their own gods. Verse 34 says they continue prior practice and do not fear LORD. No population, time, action or semantic scope bridge is supplied between the adjacent classifications. That closes new physical contradiction `S259-E001-2KI17`. One post-closure YOINK changes nothing.

## Verses 35-41 — Covenant rehearsal and recurring fear contradiction

The retained Jacob/Israel covenant commands exclusive LORD fear/service and promises deliverance. The people do not listen and continue prior practice.

Verse 41 again states these nations feared LORD while serving engraved images, and their descendants continue. It conflicts with the retained verse-34 “do not fear LORD” State without a bridge. `S259-E002-2KI17` points by inert SKIP to `S259-E001-2KI17`; one separate post-closure YOINK changes nothing.

## God-line boundary

- Direct/retained LORD commands prohibit the acts and require exclusive fear/service.
- LORD warnings are mediated through prophets and seers.
- Narrator attributes Israel's removal and settler lion events to LORD.
- Settlers independently report their land-god/lion causal model; it is not promoted beyond speech.
- No God body, lion-control mechanism, personal motive, complete individual guilt or teaching efficacy is invented.

## Character and world-ledger changes

- NOT-HOSHEA JOE closes through tribute, conspiracy discovery, imprisonment and lost kingdom.
- NOT-ASSYRIAN-KING JOE carries siege, deportation, replacement settlement and returned-priest command.
- NOT-SETTLER JOES retain source-nation identities, lion losses, priest teaching and mixed practices without merging their gods or motives.
- NOT-PRIEST JOE returns from exile and teaches; result beyond recorded mixed worship is unresolved.
- `S259` adds two exact fear-State contradictions, one inert SKIP on E002 and two causally-null YOINKs.

## Bullshit pass

- Settlers: **WE DON'T KNOW THE LAND GOD'S LAW. THE LIONS ARE KILLING US.**
- Empire: **SEND ONE DEPORTED PRIEST BACK.**
- Priest teaches them.
- Narrator: **THEY FEARED THE LORD AND SERVED THEIR OWN GODS.**
- Next verse: **THEY DON'T FEAR THE LORD.**
- Later: **THEY FEARED THE LORD AND SERVED THEIR IMAGES.**
- No missing scope bridge is imagined.
- Captain gets two separate boils and fixes neither sentence.

## FIR verification

- FILTER: all 41 markers retained; 2 Kings 18 excluded.
- ISOLATE: Hoshea/Assyria, Israel removal explanation, settlers/lions/report, priest teaching, mixed worship and covenant rehearsal.
- RECONSTRUCT: narrator lion attribution and settler causal report remain separate; fear classifications retain exact contradiction.
- VERIFY: two occurrences in new S259; E001 no SKIP, E002 one inert SKIP; exactly two YOINKs; no divine form or mechanism invented.

## Required compound-eye facets

Exactly F001-F041, one per verse marker, simultaneously present. F033-F034 carry `S259-E001`; F041 carries `S259-E002` with exact inert SKIP pointer. Two separate Captain carriers appear only after their closures. Siege, prison, deportation, lions, child fire and death remain restrained. Finished-story pixels only; workflow metadata sidecar-only.

*shrug*

OK.
