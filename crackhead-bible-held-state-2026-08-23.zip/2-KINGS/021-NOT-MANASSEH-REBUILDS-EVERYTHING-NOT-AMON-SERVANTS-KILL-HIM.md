# CRACKHEAD 2 KINGS 21

## Title field

**NOT-MANASSEH: [REBUILDS WHAT HIS FATHER DESTROYED.] / NOT-PROPHETS: JERUSALEM WILL BE WIPED LIKE A DISH. / NOT-AMON-SERVANTS: [KILL AMON IN HIS HOUSE.]**

Source parent: ENGWEBP 2 Kings chapter 21, verses 1-26, USFM. Prepared evidence: `.chapter-work/CHB-2KI-021/job.json` and `source.usfm`. Parent: 2 Kings 20. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: zero closed contradiction occurrences, zero SKIPs, zero Captain/YOINKs. One high-resolution 26-facet compound-eye image. Violence and child/fire material remain restrained and non-graphic.

## Causal foundation

```text
MANASSEH BEGINS AGE 12 / REIGNS 55 YEARS
-> REBUILDS HEZEKIAH-DESTROYED HIGH PLACES
-> BAAL ALTARS / ASHERAH / SKY-ARMY WORSHIP
-> ALTARS IN LORD HOUSE + TWO COURTS
-> SON THROUGH FIRE / SORCERY / ENCHANTMENTS / MEDIUMS
-> ASHERAH IMAGE SET IN CHOSEN HOUSE
-> RETAINED CONDITION: LAND STABILITY IF COMMANDS OBSERVED
-> PEOPLE DO NOT LISTEN / MANASSEH LEADS GREATER EVIL
-> LORD SPEAKS THROUGH PROPHETS
-> MANASSEH/JUDAH ACTS ADDRESSED
-> FUTURE JERUSALEM DISASTER / SAMARIA LINE / AHAB PLUMB / WIPED DISH
-> REMNANT ENEMY PREY FORECAST
-> MANASSEH SHEDS MUCH INNOCENT BLOOD
-> CHRONICLE POINTER
-> MANASSEH DIES/BURIED / AMON SUCCEEDS
-> AMON TWO-YEAR REIGN / FATHER'S IDOL ROUTE / LORD ABANDONMENT
-> SERVANTS CONSPIRE / KILL AMON IN HIS HOUSE
-> LAND PEOPLE KILL ALL CONSPIRATORS
-> JOSIAH MADE KING
-> AMON CHRONICLE POINTER/BURIAL
```

## Verses 1-9 — Manasseh reverses the prior reform

Manasseh begins reigning at twelve and rules fifty-five years. The narrator evaluates his acts as evil. He rebuilds high places his father destroyed, constructs Baal altars, makes Asherah, worships and serves the sky army, and places altars in LORD's house and both courts.

He makes his son pass through fire, practices sorcery and enchantments, and deals with mediums and wizards. The outcome for the son and mechanisms of the practices are not supplied. The child/fire facet remains non-graphic.

Manasseh places his Asherah image in the house associated with retained LORD speech to David and Solomon: LORD's name would be placed there and Israel would not be made to wander if the people observed all commands and Moses' law. The condition remains attached. The people do not listen, and the narrator says Manasseh seduces them into acts worse than the prior nations.

## Verses 10-16 — Mediated warning and bloodshed

LORD speaks through servant prophets. Their mediated message addresses Manasseh's acts, his leading Judah into idol-related sin, and the population's retained evil from Egypt to the current day. It forecasts disaster on Jerusalem and Judah, applies Samaria's measuring line and Ahab-house plumb line, and compares the future wiping of Jerusalem to a wiped and overturned dish.

The remnant is forecast to be cast off and delivered to enemies as prey and plunder. This remains future speech here. The chapter supplies collective and Manasseh-specific reasons but not individual allocations, fulfillment timing or enemy identities.

The narrator separately records that Manasseh sheds very much innocent blood until Jerusalem is filled end to end, in addition to his idol-related leadership. Victim identities, counts and killing mechanics are unresolved; depiction is restrained.

## Verses 17-18 — Manasseh death and succession

Unquoted acts and sins are addressed to the Judah kings' chronicles. Manasseh dies, is buried in his own house's garden of Uzza, and Amon succeeds him. No later repentance account from another source is imported into this chapter.

## Verses 19-26 — Amon, conspiracy and Josiah

Amon begins at twenty-two and reigns two years. The narrator evaluates him as evil, following Manasseh's ways, serving and worshipping the same idols, abandoning LORD and not walking in LORD's way.

Amon's servants conspire and kill him in his own house. The people of the land then kill all named-by-class conspirators and make Josiah king. The conspiracy motive, individual servant identities, legal process and precise relation between the two killings are not supplied.

Amon's remaining acts are addressed to the chronicles. He is buried in the garden of Uzza and Josiah succeeds him.

## Bullshit pass

No verified bullshit closes. Manasseh rebuilding what Hezekiah destroyed is a later actor changing prior physical State, not simultaneous contradiction. The future punishment message cites both Manasseh's addressed acts and Judah's retained non-listening/evil; it does not provide enough individual allocation to manufacture a liability crack. Amon's servants and the land people perform separate killings against separately addressed targets.

## God-line boundary

- Prior LORD speech about the house, Jerusalem and conditional land stability is retained as quoted historical speech.
- LORD speaks through servant prophets in verses 10-15; this is mediated speech and future warning.
- Narrator evaluates Manasseh and Amon, attributes prior national displacement to LORD, and records acts/outcomes.
- Son/fire outcome, occult mechanisms, anger mechanism and forecast fulfillment remain unresolved.
- No God body or invented prophet identity is rendered.

## Character and world-ledger changes

- NOT-MANASSEH JOE adds fifty-five-year reign, reversal of Hezekiah's removals, house/court installations, son/fire act, practices, Judah leadership, innocent bloodshed, death and burial.
- NOT-PROPHET JOES carry the addressed mediated warning without invented names.
- NOT-AMON JOE adds two-year reign, continued worship route, abandonment evaluation, assassination and burial.
- NOT-SERVANT JOES carry the conspiracy and Amon killing; NOT-LAND-PEOPLE JOES carry conspirator killings and Josiah's installation.
- NOT-JOSIAH JOE becomes reigning successor.
- No Captain appears because no contradiction closes.

## Reconstruction boundary

All 26 source verse markers are retained. Historical divine statements, current acts, narrator evaluations, mediated future warning, observed deaths and chronicle pointers remain distinct. The compound-eye image must not render future Jerusalem destruction as completed, infer occult mechanisms, import another-source repentance, or invent conspiracy motives. Exact names remain in sidecars; visible story names use `NOT-`; workflow metadata remains outside story pixels.

Publication remains held. The compound-eye carrier presents all 26 facets simultaneously with story-only pixels.
