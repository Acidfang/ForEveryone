# CRACKHEAD 2 KINGS 16

## Title field

**NOT-AHAZ: I AM YOUR SERVANT AND SON. SAVE ME. / [SENDS TEMPLE GOLD.] / NOT-AHAZ: COPY THAT ALTAR. / NOT-URIJAH: BUILT IT BEFORE HE GOT HOME.**

Source parent: ENGWEBP 2 Kings chapter 16, verses 1-20, USFM. Prepared evidence: `.chapter-work/CHB-2KI-016/job.json` and `source.usfm`. Parent: 2 Kings 15. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: zero contradiction occurrences, zero SKIPs, zero Captain/YOINKs. One high-resolution 20-facet compound-eye image.

## Causal foundation

```text
AHAZ REIGNS 16 YEARS / NOT-RIGHT EVALUATION
-> ISRAEL-KING ROUTE / SON THROUGH FIRE / HIGH-PLACE WORSHIP
-> REZIN + PEKAH BESIEGE JERUSALEM / DO NOT OVERCOME AHAZ
-> REZIN RECOVERS ELATH / JEWS DRIVEN OUT / SYRIANS SETTLE
-> AHAZ CALLS TIGLATH PILESER SERVANT/SON + REQUESTS RESCUE
-> LORD-HOUSE + PALACE GOLD/SILVER SENT
-> ASSYRIA TAKES DAMASCUS / DEPORTS PEOPLE / KILLS REZIN
-> AHAZ SEES DAMASCUS ALTAR
-> DRAWING + BUILD PLANS SENT TO URIJAH
-> URIJAH BUILDS BEFORE AHAZ RETURNS
-> AHAZ OFFERS ON NEW ALTAR
-> BRONZE ALTAR MOVED NORTH
-> ALL ROUTINE OFFERINGS/BLOOD ROUTED TO GREAT ALTAR
-> BRONZE ALTAR RESERVED FOR AHAZ TO INQUIRE BY
-> URIJAH EXECUTES COMMAND
-> BASE PANELS/BASIN/SEA/OXEN RECONFIGURED
-> SABBATH WAY + ROYAL ENTRANCE REMOVED BECAUSE OF ASSYRIAN KING
-> AHAZ DIES / HEZEKIAH SUCCEEDS
```

## Verses 1-4 — Ahaz's reign and worship route

Ahaz begins at twenty, reigns sixteen years and is evaluated as not right in LORD's eyes. Narrator places him on Israel's royal route, says he makes his son pass through fire, and records sacrifice/incense at high places, hills and green trees. The son's outcome and ritual mechanism are not supplied; depiction remains restrained and non-graphic.

## Verses 5-9 — Siege, tribute and Assyrian intervention

Rezin and Pekah besiege Jerusalem but cannot overcome Ahaz. Rezin recovers Elath for Syria, removes its Jews and Syrians settle there.

Ahaz calls Tiglath Pileser his master/father-equivalent through “servant and son” speech and asks rescue. He sends silver and gold from LORD's house and royal treasuries. Assyria listens, captures Damascus, deports its people to Kir and kills Rezin. These observed political, material and military acts require no invented divine or private-motive bridge.

## Verses 10-16 — Remote altar reproduction and ritual rerouting

Ahaz visits Damascus, sees its altar and sends Urijah a drawing and complete build plans. Urijah constructs the altar before Ahaz returns. This is an exact source-to-plan-to-build chain: a retained example of remote visual specification and physical reproduction, not a claim of invention by Urijah.

Ahaz offers burnt, meal, drink and peace offerings on it. He moves the pre-existing bronze altar north, commands all regular royal/public offerings and blood routed to the large new altar, and reserves the bronze altar for his inquiry. Urijah does everything commanded. The inquiry's method and later use remain unresolved.

## Verses 17-20 — Temple fittings altered and succession

Ahaz cuts base panels, removes basins, takes the sea from the bronze oxen and places it on stone pavement. He removes the Sabbath covered way and royal outer entrance because of the Assyrian king. The precise pressure, request or design reason is not supplied.

Ahaz's other acts point to chronicles. He dies, is buried in David's city and Hezekiah succeeds.

## God-line boundary

- Narrator evaluates Ahaz against LORD and attributes prior nation displacement to LORD.
- No direct LORD speech occurs in this chapter.
- Siege, tribute, Assyrian response, altar reproduction, offerings and architectural changes remain human acts.
- No God body, fire-ritual mechanism, rescue mechanism, inquiry result or divine approval is invented.

## Character and world-ledger changes

- NOT-AHAZ JOE closes through reign, siege, Assyrian appeal/tribute, Damascus visit, altar specification, ritual rerouting, temple alteration, death and burial.
- NOT-URIJAH JOE adds exact drawing-to-build and command-execution State.
- NOT-REZIN JOE closes through Elath recovery and death; NOT-TIGLATH-PILESER JOE adds Damascus capture/deportation and Ahaz relation.
- NOT-HEZEKIAH JOE succeeds Ahaz. Zero contradiction machinery is admitted.

## Bullshit pass

- Besieged king empties temple and palace treasury into a foreign-rescue present.
- Then visits the resulting conqueror's city.
- Sees an altar.
- Sends the priest a drawing and full build plans.
- Priest has the copy finished before the king returns.
- King reroutes the whole offering stack and parks the old altar to one side for inquiries.
- Captain finds no broken relation, so he is not in the image.

## FIR verification

- FILTER: all 20 markers retained; 2 Kings 17 excluded.
- ISOLATE: Ahaz worship route, siege/Elath, Assyrian request/payment/outcome, altar reproduction, ritual reroute, temple changes and succession.
- RECONSTRUCT: drawing/plans are parents of the new altar; political request/payment remains distinct from later response.
- VERIFY: zero contradictions/SKIPs/YOINKs; no motive, God form, ritual mechanism or approval invented.

## Required compound-eye facets

Exactly F001-F020, one per verse marker, simultaneously present. Son/fire, war, killing and deportation are restrained/non-graphic. Altars, plans, treasures, bases, basins, sea, oxen sculptures and buildings are nonliving/faceless. Finished-story pixels only; workflow metadata sidecar-only.

*shrug*

OK.
