# CRACKHEAD 2 KINGS 9

## Title field

**NOT-JEHU: OIL. KING. DRIVE FURIOUSLY. / NOT-JORAM: IS IT PEACE? [ARROW.] NABOTH'S PLOT. / NOT-JEZEBEL: ZIMRI? [WINDOW.]**

Source parent: ENGWEBP 2 Kings chapter 9, verses 1-37, USFM. Prepared evidence: `.chapter-work/CHB-2KI-009/job.json` and `source.usfm`. Parent: 2 Kings 8. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: zero contradiction occurrences, zero SKIPs, zero Captain/YOINKs. One high-resolution 37-facet compound-eye image.

## Causal foundation

```text
ELISHA SENDS YOUNG PROPHET WITH OIL + PRIVATE ANOINT/FLEE INSTRUCTION
-> PROPHET FINDS JEHU / POURS OIL / CARRIES LORD KINGSHIP + AHAB-HOUSE JUDGMENT SPEECH
-> PROPHET FLEES
-> JEHU PARTLY DEFLECTS / THEN REPORTS ANOINTING
-> CAPTAINS PLACE CLOAKS / BLOW TRUMPET / DECLARE JEHU KING
-> JEHU CONSPIRES / RIDES TO JEZREEL
-> TWO HORSEMEN ASK PEACE / EACH FALLS IN BEHIND
-> WATCHMAN IDENTIFIES JEHU'S FURIOUS DRIVING
-> JORAM + AHAZIAH MEET JEHU ON NABOTH LAND
-> JEHU REJECTS PEACE / JORAM FLEES
-> JEHU SHOOTS JORAM / ORDERS BODY CAST ON NABOTH PLOT
-> JEHU ATTRIBUTES PLOT REPAYMENT WORD TO LORD
-> AHAZIAH IS STRUCK / DIES / IS BURIED
-> JEZEBEL PREPARES / ADDRESSES JEHU FROM WINDOW
-> JEHU CALLS FOR SUPPORT / EUNUCHS THROW HER DOWN / HORSES TRAMPLE
-> JEHU EATS / LATER ORDERS BURIAL
-> ONLY SKULL + FEET + PALMS FOUND
-> JEHU IDENTIFIES RESULT WITH PRIOR ELIJAH-CARRIED LORD WORD
```

## Verses 1-10 — Private anointing and carried judgment

Elisha sends one young prophet to Ramoth Gilead with a vial of oil. The exact ordered sequence is retained: identify Jehu, separate him into an inner room, pour oil on his head, carry the quoted LORD anointing, open the door, flee, and do not wait.

The young prophet performs the route. His longer delivered speech identifies Jehu as king over Israel and commands him to strike Ahab's house as vengeance for blood attributed to Jezebel's hand. It forecasts the whole house's removal and dogs eating Jezebel on the Jezreel plot with no burial. These are mediated speech at this Moment, not already completed events. The messenger then opens the door and flees.

## Verses 11-16 — Disclosure, declaration and conspiracy

Jehu returns to the other captains. They call the visitor a madman and ask why he came. Jehu initially answers that they know the man and his talk; when they reject that answer as a lie and ask for the message, he reports the anointing statement. The first answer is retained as an evasive/partial response, not upgraded into a false factual occurrence without an exact contradicted proposition.

The captains immediately place their cloaks beneath Jehu, blow the trumpet, and declare him king. Jehu conspires against Joram while Joram is at Jezreel healing from Syrian wounds. Jehu orders that no one leave Ramoth Gilead to report, then rides to Jezreel where Ahaziah is visiting Joram.

## Verses 17-26 — Three peace questions, Joram's death and Naboth's plot

The Jezreel watchman sees Jehu's company. Joram sends one horseman asking whether it is peace. Jehu rejects the question and orders him behind; the messenger does not return. The same happens to a second horseman. The watchman identifies the driving as Jehu's because it is furious. This is an observation-based identity claim; its mechanism remains ordinary visual recognition, not omniscience.

Joram and Ahaziah ride out and meet Jehu on Naboth's land. Joram asks peace a third time. Jehu answers that peace cannot exist while Jezebel's prostitution and witchcraft abound. Joram calls treason and flees. Jehu shoots him between the arms; the arrow exits at his heart and he collapses in the chariot.

Jehu tells Bidkar to cast Joram on Naboth's plot. He recalls that both rode behind Ahab when LORD laid a burden on him, then quotes a LORD statement about seeing Naboth's and his sons' blood and repayment in that plot. This is Jehu's retained recollection and attribution. The chapter does not independently replay the earlier revelation or establish the otherwise unstated deaths of Naboth's sons, so those details remain attributed speech rather than silently backfilled history.

## Verses 27-29 — Ahaziah struck, dead and buried

Ahaziah flees by the garden house. Jehu orders him struck in the chariot. He is struck near Ibleam, reaches Megiddo, and dies there. His servants carry him to Jerusalem and bury him with his fathers in David's city. The reign synchronism follows. No motive for striking Ahaziah and no cross-book chronology repair is invented.

## Verses 30-37 — Window, trampling, remains and fulfillment interpretation

Jezebel hears Jehu has arrived, paints her eyes, adorns her head, and looks from the window. She addresses him as Zimri and murderer of his master. `Zimri` is retained as her spoken comparison/address, not a literal identity merge.

Jehu asks who is on his side. Two or three eunuchs look out. At his command they throw Jezebel down; blood reaches wall and horses, and she is trampled. Jehu enters, eats and drinks, then orders burial because she is a king's daughter. The delayed burial order does not erase the preceding acts.

The burial party finds only skull, feet and hand-palms. They report back. Jehu identifies this result as the LORD word spoken through Elijah: dogs eat Jezebel on the Jezreel plot and her body becomes unidentifiable field dung. The source supplies the remains and Jehu's interpretation, but not the eating interval, dog acts as separately witnessed Moments, or decomposition mechanism. Depiction remains restrained and non-graphic.

## God-line boundary

- Elisha instructs a young prophet; the prophet carries direct quotations attributed to LORD.
- The anointing, judgment command and future Jezebel outcome are mediated speech until their respective observed acts occur.
- Jehu later recalls a LORD burden concerning Naboth, his sons and the plot; this remains Jehu's attributed recollection.
- Jehu interprets Jezebel's remains through a prior LORD word carried by Elijah.
- No God body, revelation mechanism, vengeance ontology, dog-eating scene, or hidden causal bridge is invented.

## Character and world-ledger changes

- NOT-JEHU JOE moves from captain through private anointing, public declaration, conspiracy and royal execution.
- NOT-JORAM-OF-ISRAEL JOE moves from wound recovery to death and placement on Naboth's plot.
- NOT-AHAZIAH JOE moves from visit through flight, mortal strike, death and Jerusalem burial.
- NOT-JEZEBEL JOE moves from window confrontation through death, attempted burial and partial remains.
- NOT-YOUNG-PROPHET JOE performs the exact message carrier route and exits; no later State is inferred.
- Two or three eunuchs remain an unresolved count, not silently normalized to two or three exact individuals.

## Bullshit pass

Issue `2KI-009 / PEACE CHECKS DURING HOSTILE TAKEOVER`.

- Secret consultant oils military commander and sprints out the door.
- Coworkers: **WHAT DID THE MADMAN WANT?**
- Newly oiled commander: **YOU KNOW HOW HE TALKS.**
- Coworkers: **THAT IS A LIE. TELL US.**
- Commander: **APPARENTLY I AM KING.**
- Everyone immediately supplies a cloak staircase and trumpet.
- First peace auditor joins the convoy.
- Second peace auditor joins the convoy.
- Watchman: **THAT DRIVING IS JEHU. IT IS ABSOLUTELY FURIOUS.**
- King asks whether it is peace while standing on the murdered neighbor's land.
- It is not peace.

Captain hears no validated crack and does absolutely nothing.

## FIR verification

- FILTER: all 37 markers retained; 2 Kings 10 excluded.
- ISOLATE: prophet dispatch/anointing, captain declaration, conspiracy/ride, peace messengers, Joram/Ahaziah deaths, Jezebel death/remains and fulfillment interpretation.
- RECONSTRUCT: zero contradictions; keep evasive speech, comparison-address and attributed histories distinct from verified external fact.
- VERIFY: zero SKIPs/YOINKs; no divine form, Naboth-son backfill, cross-book chronology repair, dog-eating observation or hidden motive invented.

## Required compound-eye facets

1. Elisha selects young prophet/oil/Ramoth route.
2. Find Jehu/separate him into inner room.
3. Pour oil/carry LORD anointing/open/flee instruction.
4. Young prophet travels to Ramoth.
5. Captains seated/message selects Jehu.
6. Oil poured/Jehu king over LORD people.
7. Strike Ahab house/avenge servant blood speech.
8. Whole-house removal forecast.
9. Jeroboam/Baasha house comparison.
10. Jezebel dogs/no-burial forecast/prophet flees.
11. Madman question/Jehu partial answer.
12. Lie challenge/Jehu reports anointing.
13. Cloaks/stairs/trumpet/Jehu-is-king declaration.
14. Conspiracy and Ramoth defense context.
15. Joram wounds/healing/no-one-leaves instruction.
16. Jehu rides/Joram and Ahaziah at Jezreel.
17. Watchman sees company/first peace messenger sent.
18. First messenger joins and does not return.
19. Second messenger repeats and joins.
20. Watchman identifies furious Jehu driving.
21. Two kings ready chariots/meet on Naboth land.
22. Third peace question/Jezebel-practices answer.
23. Joram turns/flees/calls treason.
24. Jehu arrow/Joram dies in chariot, restrained.
25. Bidkar ordered to cast body on Naboth plot/recollection begins.
26. Jehu-carried LORD blood/repayment quotation and body placement.
27. Ahaziah flight/strike/Megiddo death, restrained.
28. Ahaziah carried/buried in Jerusalem.
29. Ahaziah reign synchronism.
30. Jezebel paints/adorns/looks from window.
31. Zimri/murderer-of-master address.
32. Jehu asks who is with him/two-or-three eunuchs look out.
33. Throw-down/blood/horses/trampling, restrained.
34. Jehu eats/drinks/then orders royal-daughter burial.
35. Burial party finds skull/feet/palms only, restrained.
36. Report and Jehu's Elijah-carried LORD-word interpretation.
37. Field/dung/unidentifiable-body quotation, text carrier only.

All thirty-seven facets appear simultaneously.

## Production boundary

One high-resolution 37-facet compound-eye image. `NOT-` identities and Joe faces for every living human and animal, including horses and any dogs if shown only as forecast/interpretive carriers. Oil vial, cloaks, trumpet, chariots, bows, arrows, tower, window, field and remains are nonliving/faceless. Zero SKIPs and zero Captain/YOINKs. Deaths, trampling and remains restrained/non-graphic. No God body. Finished-story pixels only; workflow metadata sidecar-only.

*shrug*

OK.
