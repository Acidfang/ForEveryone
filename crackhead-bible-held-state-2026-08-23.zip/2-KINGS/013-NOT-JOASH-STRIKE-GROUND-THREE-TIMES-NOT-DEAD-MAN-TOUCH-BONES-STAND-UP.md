# CRACKHEAD 2 KINGS 13

## Title field

**NOT-ELISHA: STRIKE THE GROUND. / NOT-JOASH: ONE. TWO. THREE. STOP. / NOT-ELISHA: SHOULD HAVE BEEN FIVE OR SIX. / NOT-DEAD-MAN: [TOUCHES BONES. STANDS UP.]**

Source parent: ENGWEBP 2 Kings chapter 13, verses 1-25, USFM. Prepared evidence: `.chapter-work/CHB-2KI-013/job.json` and `source.usfm`. Parent: 2 Kings 12. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: zero contradiction occurrences, zero SKIPs, zero Captain/YOINKs. One high-resolution 25-facet compound-eye image.

## Causal foundation

```text
JEHOAHAZ REIGNS 17 YEARS / JEROBOAM ROUTE / EVIL CLASSIFICATION
-> LORD-ATTRIBUTED DELIVERY TO HAZAEL + BENHADAD
-> JEHOAHAZ BEGS LORD / LORD LISTENS + SEES OPPRESSION
-> LORD GIVES UNNAMED SAVIOR / ISRAEL LEAVES SYRIAN HAND
-> ISRAEL RETAINS JEROBOAM SINS + ASHERAH
-> SYRIA REDUCES FORCE TO 50 HORSEMEN + 10 CHARIOTS + 10,000 FOOT
-> JEHOAHAZ DIES / JOASH SUCCEEDS
-> JOASH REIGNS 16 YEARS / SAME SIN ROUTE / EVIL CLASSIFICATION
-> JOASH LATER DIES / JEROBOAM SUCCEEDS
-> ELISHA SICK WITH DEATH ILLNESS / JOASH WEEPS
-> BOW + ARROW / EAST WINDOW / SHOT
-> ELISHA CALLS IT LORD VICTORY ARROW / APHEK CONSUMPTION FORECAST
-> ELISHA ORDERS GROUND STRIKES
-> JOASH STRIKES THREE / STOPS
-> ELISHA ANGRY / STATES FIVE-SIX WOULD CONSUME / NOW THREE VICTORIES
-> ELISHA DIES / BURIED
-> MOAB RAIDERS APPEAR DURING ANOTHER BURIAL
-> BURIAL PARTY THROWS MAN INTO ELISHA TOMB
-> MAN TOUCHES ELISHA BONES / REVIVES / STANDS
-> HAZAEL OPPRESSION RETAINED
-> LORD COVENANT COMPASSION / NOT DESTROYED OR CAST AWAY YET
-> HAZAEL DIES / BENHADAD SUCCEEDS
-> JOASH STRIKES THREE TIMES / RECOVERS THREE CITIES
```

## Verses 1-9 — Jehoahaz, oppression, unnamed savior and reduced army

Jehoahaz begins a seventeen-year Israel reign in Joash of Judah's twenty-third year. Narrator classifies his Jeroboam route as evil in LORD's sight and says he does not depart from it.

Narrator says LORD's anger burns and LORD continually delivers Israel into Hazael and Benhadad's hands. Jehoahaz begs LORD; LORD listens because he sees Syrian oppression. LORD gives Israel a savior, Israel exits Syrian control, and people live in tents as before.

The savior's identity, act, timing and mechanism are not supplied here. No later person is backfilled into that role. Relief does not create complete reform: Israel keeps Jeroboam-house sins and Samaria's Asherah remains.

The Syrian king leaves Jehoahaz only fifty horsemen, ten chariots and ten thousand footmen after destroying the rest like threshing dust. The metaphor is retained without depicting people as literal dust. Jehoahaz's other acts point to chronicles; he dies, is buried in Samaria and his son Joash succeeds.

## Verses 10-13 — Joash of Israel's reign frame

Jehoash/Joash son of Jehoahaz begins a sixteen-year Israel reign in Joash of Judah's thirty-seventh year. The two same-named kings remain distinct people and ledgers. Israel's Joash receives the same evil/Jeroboam-path evaluation.

His broader acts and fight against Amaziah point to Israel's chronicles. The chapter gives his death, Samaria burial and Jeroboam succession before returning narratively to an earlier Elisha encounter. This placement is not forced into a single forward-only timeline; verses 14-25 supply the encounter and later recovery relation.

## Verses 14-19 — One shot, three ground strikes and an explicit scope transition

Elisha becomes sick with the illness from which he dies. Israel's Joash visits, weeps and calls him father, Israel's chariots and horsemen. The expression remains Joash's speech; Elisha is not rendered as a literal vehicle or army.

Elisha orders bow and arrows. Joash takes them, places his hand on the bow, and Elisha places his hands on the king's hands. At the opened east window Joash shoots. Elisha calls it LORD's victory arrow over Syria and says Joash will strike Syria at Aphek until consumed.

Elisha then tells him to take the arrows and strike the ground. Joash strikes three times and stops. Elisha becomes angry and says five or six strikes would have resulted in consuming Syria; now Joash will strike only three times.

This is an explicit conditional transition, not a contradiction. The second enacted selector changes the retained future scope before the later battles occur. The source supplies no prior numerical instruction, so Joash's reason for stopping and Elisha's expectation that he should continue remain unresolved.

## Verses 20-21 — Elisha's burial and the revived man

Elisha dies and is buried. Moabite bands invade at the year's coming. During another man's burial, the burial party sees raiders and throws the man into Elisha's tomb. When the man touches Elisha's bones, he revives and stands on his feet.

The sequence is observed exactly: dead/burial-bound man, thrown into tomb, bone contact, revival, standing. The source does not identify the man, burial party, death cause, time since death, biological mechanism, divine speech or later life. Contact is retained as temporal/physical relation without inventing a complete causal mechanism. Depiction remains restrained.

## Verses 22-25 — Covenant restraint and three recovered cities

Hazael oppresses Israel throughout Jehoahaz's days. Narrator says LORD is gracious, compassionate and favorable because of covenant with Abraham, Isaac and Jacob, and does not destroy or cast Israel from his presence yet. This covenant attribution is narrator State; no God body appears.

Hazael dies and Benhadad succeeds. Joash retakes from Benhadad the cities Hazael had taken from Jehoahaz. Joash strikes him three times and recovers Israel's cities. This observed threefold outcome closes the limited scope Elisha stated after the ground strikes. Exact city names, battle sequence and whether every loss is recovered remain unresolved.

## God-line boundary

- Narrator attributes anger, delivery, listening, seeing oppression and provision of an unnamed savior to LORD.
- Elisha calls the east-window shot LORD's victory arrow and supplies the Aphek/Syria forecast.
- Elisha explicitly revises outcome scope after three ground strikes.
- Narrator attributes continued non-destruction to LORD's grace, compassion and patriarch covenant.
- No God body, savior identity, listening mechanism, arrow power, corpse-revival mechanism or invisible battle act is invented.

## Character and world-ledger changes

- NOT-JEHOAHAZ JOE closes his seventeen-year reign, oppression appeal, military reduction, death and succession.
- NOT-JOASH-OF-ISRAEL JOE remains distinct from NOT-JOASH-OF-JUDAH JOE; he moves through reign frame, Elisha visit, arrow acts, three Syrian victories and city recovery.
- NOT-ELISHA JOE closes his living path through death illness, final instruction, death and burial; his bones remain a nonliving retained carrier.
- NOT-REVIVED-MAN JOE moves from dead burial State through tomb contact to standing alive; identity and later State remain unresolved.
- NOT-HAZAEL JOE closes through oppression and death; NOT-BENHADAD JOE succeeds and loses three encounters/cities.

## Bullshit pass

Issue `2KI-013 / PERFORMANCE TARGET COMMUNICATED AFTER PERFORMANCE`.

- Dying consultant: **TAKE A BOW. OPEN EAST WINDOW. SHOOT.**
- King shoots.
- Consultant: **VICTORY ARROW. YOU CONSUME SYRIA.**
- Consultant: **NOW STRIKE THE GROUND.**
- King: **ONE. TWO. THREE.** Stops.
- Consultant: **WHY DIDN'T YOU DO FIVE OR SIX? NOW YOU ONLY WIN THREE TIMES.**
- No number was stated before the test.
- Later: exactly three victories and recovered cities.
- Meanwhile, unrelated burial team sees raiders and performs emergency tomb insertion.
- Corpse touches consultant bones.
- Corpse stands up.

Captain cannot find a contradiction because the forecast was explicitly re-scoped before execution, so he does absolutely nothing.

## FIR verification

- FILTER: all 25 markers retained; 2 Kings 14 excluded.
- ISOLATE: Jehoahaz oppression/relief, both Israel reign frames, Elisha arrow selectors/death, tomb revival, covenant restraint and three city recoveries.
- RECONSTRUCT: later three victories test the explicit post-selector scope; narrative chronology and same-name kings remain distinct.
- VERIFY: zero contradictions/SKIPs/YOINKs; no savior identity, stop motive, resurrection mechanism, divine form or complete city inventory invented.

## Required compound-eye facets

1. Jehoahaz synchronism/17-year reign.
2. Evil/Jeroboam route retained.
3. LORD anger/delivery to Hazael and Benhadad attribution.
4. Jehoahaz begs/LORD listens and sees oppression.
5. Unnamed savior/exit Syrian hand/tent life restored.
6. Jeroboam sins/Asherah remain.
7. Force reduced to 50 horsemen/10 chariots/10,000 foot.
8. Jehoahaz chronicles/death/burial/Joash succession.
9. Israel Joash synchronism/16-year reign.
10. Israel Joash evil/Jeroboam route.
11. Chronicles/Amaziah fight pointer/death/burial/Jeroboam succession.
12. Elisha death illness/Joash visit/weeping/chariots speech.
13. Bow/arrows/king hand/Elisha hands.
14. East window opens/arrow shot.
15. LORD victory-arrow/Aphek consumption forecast.
16. Ground-strike command/three strikes/stop.
17. Elisha anger/five-or-six counterfactual/three-victory scope.
18. Elisha death/burial/Moab bands invade.
19. Other burial/raiders seen/man thrown into tomb.
20. Bone contact/revival/standing, restrained.
21. Hazael oppression all Jehoahaz days.
22. LORD covenant grace/compassion/non-destruction/not-cast-away-yet.
23. Hazael death/Benhadad succession.
24. Joash retakes Hazael-captured cities from Benhadad.
25. Exactly three strikes/victories/city recovery.

All twenty-five facets appear simultaneously.

## Production boundary

One high-resolution 25-facet compound-eye image. `NOT-` identities and Joe faces for all living humans and animals. Bow, arrows, window, ground, chariots, tents, chronicles, tomb, bones, cities and maps are nonliving/faceless. Zero SKIPs and zero Captain/YOINKs. Death, burial, invasion and revival restrained/non-graphic; the revived man is visibly living only after the contact Moment. No God body. Finished-story pixels only; workflow metadata sidecar-only.

*shrug*

OK.
