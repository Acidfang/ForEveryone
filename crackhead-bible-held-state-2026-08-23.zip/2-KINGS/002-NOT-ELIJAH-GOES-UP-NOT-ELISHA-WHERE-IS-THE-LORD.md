# CRACKHEAD 2 KINGS 2

## Title field

**NOT-ELIJAH: TAKEN UP. / NOT-ELISHA: WHERE IS THE LORD GOD OF ELIJAH? / NOT-FIFTY: MAYBE HE IS ON A MOUNTAIN. / NOT-YOUTHS: GO UP, BALDY.**

Source parent: ENGWEBP 2 Kings chapter 2, verses 1-25, USFM. Prepared evidence: `.chapter-work/CHB-2KI-002/job.json` and `source.usfm`. Parent: 2 Kings 1. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: no closed contradiction. Zero SKIPs, Captain appearances or YOINKs. One high-resolution 25-facet compound-eye field.

## Causal foundation

```text
LORD ABOUT TO TAKE ELIJAH BY WHIRLWIND TO HEAVEN
-> GILGAL / BETHEL / JERICHO / JORDAN ROUTE
-> ELIJAH THREE TIMES ASKS ELISHA TO STAY
-> ELISHA THREE TIMES REFUSES TO LEAVE
-> TWO PROPHET GROUPS STATE TODAY-TAKING KNOWLEDGE
-> ELISHA ACKNOWLEDGES / ASKS SILENCE
-> FIFTY OBSERVE FROM DISTANCE
-> ELIJAH MANTLE DIVIDES JORDAN / BOTH CROSS DRY
-> ELISHA REQUESTS DOUBLE SPIRIT PORTION
-> ELIJAH SETS SEE-TAKING CONDITION
-> FIRE CHARIOT/HORSES SEPARATE THEM
-> ELIJAH ASCENDS BY WHIRLWIND / ELISHA SEES
-> ELISHA TEARS CLOTHES / TAKES FALLEN MANTLE
-> ELISHA MANTLE DIVIDES JORDAN / ELISHA CROSSES
-> PROPHET SONS CLASSIFY ELIJAH SPIRIT RESTING ON ELISHA
-> THEY URGE SEARCH DESPITE ELISHA DON'T-SEND
-> FIFTY SEARCH THREE DAYS / DO NOT FIND ELIJAH
-> ELISHA: DIDN'T I SAY DON'T GO
-> JERICHO REPORTS BAD WATER/BARREN LAND
-> NEW JAR + SALT / ELISHA THROWS SALT / CARRIES HEALING WORD
-> WATER HEALED
-> YOUTHS MOCK GO-UP/BALDY TWICE
-> ELISHA CURSES IN LORD NAME
-> TWO FEMALE BEARS MAUL 42
-> ELISHA TO CARMEL / SAMARIA
```

## Verses 1–7 — Three requests to stay; three refusals to leave

The narrator opens with the pending result: LORD is about to take Elijah into heaven by whirlwind. Elijah and Elisha leave Gilgal. Elijah asks Elisha to remain because LORD sends him to Bethel; Elisha swears he will not leave. At Bethel, prophet sons ask whether Elisha knows LORD will take his master today. Elisha says he knows and asks silence.

The same stay/refuse and today-taking exchanges recur at Jericho, then Elijah says LORD sends him to Jordan and Elisha again refuses to leave. The route progresses each time, so the repeated segments are not duplicate occurrences requiring SKIP. Fifty prophet sons stand opposite at a distance while Elijah and Elisha reach Jordan.

## Verses 8–14 — See the taking; receive the fallen mantle

Elijah rolls his mantle, strikes Jordan, divides the water and both cross on dry ground. Elijah asks what he may do before being taken. Elisha requests a double portion of Elijah's spirit. Elijah calls it hard and supplies an explicit selector: if Elisha sees him taken, it will be so; otherwise not.

While they walk and talk, a fire chariot and fire horses separate them. Elijah goes up by whirlwind into heaven. Elisha explicitly sees it, cries out, then sees Elijah no more and tears his own clothes in two. He takes Elijah's fallen mantle, returns to Jordan, strikes the water and asks where LORD God of Elijah is. The waters divide and Elisha crosses.

The source performs the seeing condition and later gives observers' spirit-resting conclusion, but does not quantify or independently measure “double portion.” That exact transfer amount remains unresolved rather than declared complete by inference.

## Verses 15–18 — Fifty search for three days after being told not to

The Jericho prophet sons see Elisha and say Elijah's spirit rests on him; they bow. They propose sending fifty strong men to seek Elijah because LORD's Spirit may have placed him on a mountain or in a valley. Elisha says not to send.

They urge him until he is ashamed and he permits it. Fifty search three days and do not find Elijah. Returning to Elisha at Jericho, they receive: **Didn't I tell you, don't go?**

This is wasted work after a correct refusal, but not a contradiction. The searchers' relocation statement is expressly “perhaps,” and their failed search does not claim complete coverage of every mountain and valley. Their earlier knowledge that Elijah would be “taken away” does not itself specify heaven to them; only Elisha is expressly said to see the ascent. No crack is invented.

## Verses 19–22 — Pleasant city, bad water, healed spring

Jericho's men say the city's situation is pleasant but its water bad and land barren. The scoped city situation and its water condition are distinct; “pleasant” does not claim every component is good.

Elisha requests a new jar with salt. At the spring he throws in the salt and carries LORD's saying that the waters are healed and will no longer produce death or barrenness. The narrator says the waters remain healed to the source's “this day.” Salt chemistry, healing mechanism, measurement and later duration beyond that source Moment remain unresolved.

## Verses 23–25 — “Go up, baldy”; two bears come out

On Elisha's way to Bethel, youths come from the city and mock him twice: **Go up, you baldy!** Elisha turns, sees them and curses them in LORD's name. Two female bears come out of the woods and maul forty-two youths.

The source supplies the speech, curse and subsequent bear attack but no bear-control mechanism, exact curse wording, youth count outside the forty-two mauled, deaths, motives or divine act. “Go up” may echo Elijah's ascent, but that meaning is not stated and is not promoted. The scene remains restrained and non-graphic.

Elisha goes to Mount Carmel and returns to Samaria.

## God-line boundary

- The narrator attributes Elijah's planned taking to LORD and records whirlwind ascent; no independent divine body is shown.
- Elijah repeatedly attributes route destinations to LORD and sets the see-taking condition; the source does not explicitly attribute that condition's authority or quantify the resulting portion.
- Fire chariot/horses, whirlwind, mantle-water division and healed water are narrated events with mechanisms unresolved.
- Elisha carries LORD's healing saying and curses in LORD's name; exact curse words and causal bridge to bears are absent.
- The prophet sons' LORD-Spirit relocation idea remains their “perhaps” model, not fact.

## Character and world-ledger changes

- NOT-ELIJAH JOE completes Gilgal-to-Jordan travel, mantle crossing and witnessed whirlwind ascent; death is not stated.
- NOT-ELISHA JOE refuses separation three times, sees the ascent, acquires the fallen mantle, crosses Jordan, receives successor recognition, rejects then permits search, heals Jericho water, curses youths and travels onward.
- Bethel and Jericho NOT-PROPHET-SON JOES retain separate knowledge speeches; the observing fifty later propose and perform the failed search.
- NOT-FIRE-HORSE JOES and NOT-BEAR JOES are living and Joe-faced; their control mechanisms and motives remain unresolved.
- Forty-two NOT-YOUTH JOES are mauled; death is not inferred.

## Bullshit pass

Issue `2KI-002 / SUCCESSION OBSERVED, SEARCH PARTY STILL REQUIRED`.

- Departing maintainer tells successor three times not to follow.
- Successor follows across every environment.
- Witness condition passes.
- Maintainer exits vertically; credential mantle drops.
- Successor executes the same river operation successfully.
- Team: **THE MAINTAINER'S SPIRIT RESTS ON YOU.**
- Same team: **LET US SEARCH EVERY HILL FOR THE MAINTAINER.**
- Successor: **DON'T.**
- Three-day search: no maintainer.
- Successor: **THAT WAS THE ENTIRE REVIEW COMMENT.**

No contradiction. Captain Crackhead does not attend bad planning without a closed crack.

## FIR verification

- FILTER: all 25 markers retained; 2 Kings 3 excluded.
- ISOLATE: three-stage route, repeated knowledge, Jordan crossing, portion request/condition, witnessed ascent, mantle succession, failed search, water healing and youth/bear sequence.
- RECONSTRUCT: causal succession without declaring death or quantified spirit transfer; failed search retained as unresolved perhaps-model execution.
- VERIFY: zero SKIPs/YOINKs/Captain; no Elijah death, search completeness, double-portion measurement, God body, bear motive/control, youth death or “go up” meaning invented.

## Required compound-eye facets

1. Pending whirlwind-to-heaven State/Gilgal departure.
2. Bethel stay request/Elisha refusal/route.
3. Bethel sons today-taking question/Elisha knows/silence.
4. Jericho stay request/Elisha refusal/route.
5. Jericho sons today-taking question/Elisha knows/silence.
6. Jordan stay request/Elisha refusal/both proceed.
7. Fifty stand opposite/distant; pair at Jordan.
8. Elijah mantle strike/water divides/both dry crossing.
9. Ask-before-taken/double-spirit request.
10. Hard thing/see-taking selector.
11. Fire chariot/horses separate/whirlwind ascent.
12. Elisha sees/cries/sees no more/tears clothes.
13. Fallen mantle collected/Jordan bank.
14. Elisha mantle strike/where LORD/water divides/crossing.
15. Sons recognize spirit rests/bow.
16. Fifty-strong search proposal/perhaps mountain-valley/Elisha refuses.
17. Urging/permission/three-day failed search.
18. Return/Elisha says didn't I say don't go.
19. Pleasant city/bad water/barren land report.
20. New jar/salt requested and brought.
21. Salt at spring/LORD healing saying.
22. Water healed to source day.
23. Youths twice mock go-up/baldy.
24. Elisha curses/two female bears maul 42, restrained.
25. Elisha Carmel then Samaria route.

All twenty-five facets appear simultaneously.

## Production boundary

One high-resolution 25-facet compound-eye image. `NOT-` identities and Joe faces for every living thing, including fire horses and bears. Mantles, chariot, whirlwind, water, jar, salt and remains are nonliving/faceless. Zero Captain Crackhead carriers, SKIPs or YOINKs. Fire carrier, ascent, mauling and torn clothing restrained/non-graphic. Forty-two youths are mauled, not declared dead. No God body. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
