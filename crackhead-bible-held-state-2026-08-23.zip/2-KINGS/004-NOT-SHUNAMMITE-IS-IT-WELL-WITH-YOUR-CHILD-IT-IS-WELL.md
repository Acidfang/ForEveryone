# CRACKHEAD 2 KINGS 4

## Title field

**NOT-GEHAZI: IS IT WELL WITH YOUR CHILD? / NOT-SHUNAMMITE: IT IS WELL. / THE CHILD: DEAD ON THE BED.**

Source parent: ENGWEBP 2 Kings chapter 4, verses 1-44, USFM. Prepared evidence: `.chapter-work/CHB-2KI-004/job.json` and `source.usfm`. Parent: 2 Kings 3. Exact source identities remain in evidence; visible names use `NOT-`; every living thing is Joe-faced.

CrackFlix: new mental `S253-E001-2KI4`. Zero SKIPs. Exactly one causally-null post-closure Captain YOINK. One high-resolution 44-facet compound-eye field.

## Causal foundation

```text
DEAD HUSBAND / CREDITOR SEEKS TWO CHILDREN
-> ONE POT OF OIL / BORROW MANY EMPTY CONTAINERS / SHUT DOOR / POUR
-> CONTAINERS FILL UNTIL NONE REMAIN / OIL STOPS
-> SELL / PAY DEBT / FAMILY LIVES ON REST
-> SHUNAMMITE FEEDS ELISHA / BUILDS ROOF ROOM
-> NO SON + OLD HUSBAND / NEXT-SEASON SON PROMISE
-> SHE BEARS SON
-> CHILD GROWS / HEAD PAIN / DIES ON MOTHER'S KNEES
-> MOTHER LAYS CHILD ON ELISHA'S BED / TRAVELS TO CARMEL
-> GEHAZI ASKS WHETHER SHE, HUSBAND AND CHILD ARE WELL
-> SHE ANSWERS IT IS WELL WHILE CHILD REMAINS DEAD
-> S253 CLOSES / ONE YOINK
-> SHE ADDRESSES ELISHA / GEHAZI STAFF PRODUCES NO VOICE OR HEARING
-> ELISHA PRAYS / BODY CONTACT / WARMTH / SECOND CONTACT
-> SEVEN SNEEZES / EYES OPEN / MOTHER TAKES LIVING SON
-> FAMINE / UNKNOWN WILD GOURDS / DEATH-IN-POT REPORT
-> MEAL ADDED / NOTHING HARMFUL
-> TWENTY BARLEY LOAVES + GRAIN / ONE HUNDRED PEOPLE EAT / LEFTOVERS
```

## Verses 1–7 — Oil, containers, debt and remainder

A prophet-son's widow reports her husband dead, his fear of LORD, and a creditor coming to take her two children as slaves. Elisha asks what she has. Her house contains nothing except a pot of oil. He orders many borrowed empty containers, a shut door, pouring and setting full containers aside.

She and her sons execute the sequence. Every presented container fills. When her son says no container remains, the oil stops. Elisha tells her to sell it, pay the debt, and live with her sons on the rest. The source observes the bounded result but does not supply the oil-production mechanism, sale execution, prices or later household duration.

## Verses 8–17 — A room, a promise and a son

A prominent Shunammite repeatedly feeds Elisha, identifies him as a holy man of God, and arranges a roof room with bed, table, chair and lamp stand. Elisha asks Gehazi to call her and offers intercession with king or army captain. She says she lives among her own people.

Gehazi identifies her childlessness and old husband. Elisha says she will embrace a son at the same season next year. She asks him not to deceive her. She conceives and bears a son at the stated season. The fulfilled birth does not become deception merely because a later event changes the child's State.

## Verses 18–27 — The child dies; the child is called well

When grown, the child goes to his father and the reapers, cries twice that his head hurts, and is carried to his mother. He sits on her knees until noon and dies. She lays him on Elisha's bed, shuts the door and asks her husband for a servant and donkey.

Her husband asks why she is going today when it is neither new moon nor Sabbath. She answers, **It's all right.** Because his question addresses the timing of her trip rather than the child's State, that sentence is retained but not forced into a contradiction.

She rides urgently to Mount Carmel. Elisha sees her and sends Gehazi with three explicit questions: whether it is well with her, her husband and her child. She answers, **It is well.** The child is still dead on Elisha's bed. No recovery, narrower referent or semantic bridge has yet occurred. This closes mental `S253-E001-2KI4`: an explicitly child-scoped wellbeing answer exceeds retained observed State. Captain appears only after closure, performs one boilless poke/lick/**YOINK!**/walk-away sequence, and changes nothing.

She reaches Elisha and holds his feet. Gehazi moves to push her away; Elisha stops him, says her soul is troubled, and says LORD hid the matter and did not tell him.

## Verses 28–37 — Failed staff route, prayer and living son

The mother asks whether she requested a son and recalls asking not to be deceived. Elisha sends Gehazi urgently with his staff, no greetings, and an instruction to place it on the child's face. She refuses to leave Elisha, so he follows.

Gehazi applies the staff; there is no voice and no hearing. He reports the child has not awakened. No earlier sentence guarantees that the staff alone will work, so its observed failure is not a contradiction.

Elisha finds the child dead, shuts the door and prays to LORD. He aligns mouth, eyes and hands with the child and stretches over him; the body grows warm. After walking in the house he repeats the contact. The child sneezes seven times and opens his eyes. Elisha calls the mother; she bows, takes her living son and leaves. Prayer, contact, warmth, sneezing and recovery are retained in order; their mechanism is unresolved.

## Verses 38–41 — Unknown gourds and transformed stew

During famine at Gilgal, Elisha orders a large pot of stew for the prophet sons. One person gathers unrecognized wild gourds and cuts them into the pot. While eating, the men cry that death is in the pot and cannot eat it.

Elisha adds meal and orders it served. The resulting pot contains nothing harmful. The added intervention separates the two observed States; “death in the pot” and later harmless stew are not flattened into a contradiction. Plant identity, toxicity and treatment mechanism remain unresolved.

## Verses 42–44 — Twenty loaves, one hundred eat, food remains

A man from Baal Shalishah brings twenty barley loaves and fresh grain. Elisha orders it given to the people. His servant asks how this can be placed before one hundred men. Elisha repeats the instruction and carries LORD's saying that they will eat and have some left. They eat and leave some, matching the carried word. A question is not converted into a failed claim; the distribution mechanism and quantities consumed remain unresolved.

## God-line boundary

- The widow says her dead husband feared LORD; this is her retained report.
- The Shunammite identifies Elisha as a holy man of God.
- Elisha says LORD hid the mother's trouble and did not tell him.
- Elisha prays to LORD before the child warms, sneezes and opens his eyes; no divine body or hidden mechanism is rendered.
- Elisha carries LORD's eat-and-leftovers saying; narrator outcome matches it.
- Oil multiplication, child recovery and stew remediation remain observed sequences with mechanism unresolved.

## Character and world-ledger changes

- NOT-WIDOW JOE and TWO NOT-CHILD JOES move from creditor threat through filled-container provision and debt-payment instruction.
- NOT-SHUNAMMITE JOE moves from hospitality through promised birth, child's death, exact child-well answer, appeal and retrieval of the living child.
- NOT-CHILD JOE moves from birth through head pain, death, warmth, seven sneezes and opened eyes.
- NOT-ELISHA JOE moves through oil routing, room hospitality, son promise, hidden-trouble admission, failed staff delegation, prayer/body-contact sequence, stew intervention and food distribution.
- NOT-GEHAZI JOE carries calls, wellbeing questions, staff attempt and report; he does not cause the contradiction or recovery.

## Bullshit pass

Issue `2KI-004 / STATUS DASHBOARD SAYS CHILD: GREEN`.

- A dependent household has one pot of oil and many empty containers.
- Every available container fills; supply stops exactly when container capacity ends.
- A hosted consultant predicts a child; the child arrives on schedule.
- Years later the child dies and is placed in the consultant's room.
- Operations asks: **ARE YOU GREEN? IS YOUR HUSBAND GREEN? IS YOUR CHILD GREEN?**
- Owner, with the dead child still in the room: **GREEN.**
- Direct escalation begins immediately afterward.

Captain licks the child-status dashboard. **YOINK!** Nothing changes.

## FIR verification

- FILTER: all 44 markers retained; 2 Kings 5 excluded.
- ISOLATE: oil/debt chain, hospitality/son promise, death/travel/inquiry, staff attempt, recovery, harmful stew intervention and bread distribution.
- RECONSTRUCT: new S253 only at the explicit child-scoped v26 question/answer; v23 travel-timing response does not establish the same referent.
- VERIFY: zero SKIPs, one YOINK, no oil, recovery, stew, food, LORD-communication or maternal-motive mechanism invented.

## Required compound-eye facets

1. Widow reports dead husband/creditor/two children.
2. Elisha asks resources; one pot oil.
3. Borrow many empty containers.
4. Shut door/pour/set full aside.
5. Mother and sons execute pouring.
6. No container remains/oil stops.
7. Sell/pay debt/live on rest instruction.
8. Shunammite repeatedly feeds Elisha.
9. Holy-man identification.
10. Roof room/bed/table/chair/lamp.
11. Elisha stays in room.
12. Gehazi calls woman.
13. King/captain intercession offer; own-people answer.
14. Gehazi identifies no son/old husband.
15. Next-season embrace-a-son promise.
16. Do-not-deceive response.
17. Son born at stated season.
18. Grown child goes to father/reapers.
19. My-head twice/carry-to-mother.
20. Knees until noon/death.
21. Child laid on Elisha bed/door shut.
22. Servant/donkey request.
23. Trip-timing question/all-right response; no crack.
24. Urgent donkey ride.
25. Arrival toward Carmel/Elisha sees her.
26. Explicit self/husband/child wellbeing questions; it-is-well answer; dead child still on bed; S253/YOINK.
27. Feet held/Gehazi intervention/Elisha hidden-trouble statement.
28. Did-I-ask/don't-deceive speech.
29. Staff/no-greeting/child-face instruction.
30. Mother refuses separation/Elisha follows.
31. Staff applied/no voice or hearing/not awakened report.
32. Elisha finds child dead on bed.
33. Door shut/prayer to LORD.
34. Mouth/eyes/hands contact/body warms.
35. Walk/repeat/seven sneezes/eyes open.
36. Gehazi calls mother/take-son instruction.
37. Mother bows/takes son/leaves.
38. Gilgal famine/large stew order.
39. Unrecognized wild gourds cut into pot.
40. Eating/death-in-pot/cannot eat.
41. Meal added/served/nothing harmful.
42. Twenty barley loaves/fresh grain/give-to-people.
43. Hundred-men question/LORD eat-and-leftovers saying.
44. People eat/leftovers remain.

All forty-four facets appear simultaneously.

## Production boundary

One high-resolution 44-facet compound-eye image. `NOT-` identities and Joe faces for every living human and animal. Oil, containers, furniture, staff, food, plants, pots and remains are nonliving/faceless. Zero SKIPs. Exactly one separate boilless Captain poke/lick/YOINK/walk-away carrier after v26 closure. Child death and body-contact recovery restrained/non-graphic. No God body. Finished-story pixels only: no workflow, review, publication, job, hash, path, validation, instruction or next-source metadata.

*shrug*

OK.
