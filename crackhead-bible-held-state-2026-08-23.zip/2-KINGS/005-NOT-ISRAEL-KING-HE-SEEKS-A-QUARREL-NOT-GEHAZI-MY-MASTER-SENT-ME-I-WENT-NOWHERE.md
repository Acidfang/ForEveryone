# CRACKHEAD 2 KINGS 5

## Title field

**NOT-ISRAEL-KING: HE SEEKS A QUARREL. / NOT-GEHAZI: MY MASTER SENT ME. / ALSO NOT-GEHAZI: I WENT NOWHERE.**

Source parent: ENGWEBP 2 Kings chapter 5, verses 1-27, USFM. Prepared evidence: `.chapter-work/CHB-2KI-005/job.json` and `source.usfm`. Parent: 2 Kings 4. Exact source identities remain in evidence; visible identities use `NOT-`; every living thing is Joe-faced.

CrackFlix: new mental `S254-E001-2KI5`; new mental series `S255` with `S255-E001-2KI5` and recurring `S255-E002-2KI5`. Exactly one inert SKIP from E002 to E001. Exactly three separate causally-null post-closure Captain YOINKs. One 27-facet compound-eye image.

## Causal foundation

```text
NAAMAN: HONORED SYRIAN CAPTAIN + LEPROSY
-> CAPTURED ISRAELITE GIRL POINTS TO SAMARIA PROPHET
-> SYRIAN KING SENDS LETTER / WEALTH / NAAMAN
-> LETTER ASKS ISRAEL KING TO HEAL
-> ISRAEL KING CLAIMS SENDER SEEKS QUARREL WITHOUT MOTIVE EVIDENCE
-> S254 CLOSES / YOINK
-> ELISHA ROUTES NAAMAN TO HIMSELF
-> MESSENGER: WASH JORDAN SEVEN TIMES
-> NAAMAN EXPECTS PERSONAL CEREMONY / LEAVES ANGRY
-> SERVANTS ARGUE FOR SIMPLE ACT
-> SEVEN DIPS / FLESH RESTORED / CLEAN
-> NAAMAN RETURNS / CONFESSES / OFFERS GIFT
-> ELISHA REFUSES / NAAMAN REQUESTS EARTH AND FUTURE PARDON / GO IN PEACE
-> GEHAZI DECIDES TO TAKE SOMETHING
-> GEHAZI: MY MASTER SENT ME / TWO PROPHET SONS ARRIVED
-> ACTUAL STATE: NO SEND / NO ARRIVALS / GEHAZI SELF-INITIATED PURSUIT
-> S255-E001 CLOSES / YOINK
-> NAAMAN GIVES TWO TALENTS + TWO GARMENTS / GEHAZI HIDES THEM
-> ELISHA: WHERE DID YOU COME FROM?
-> GEHAZI: I WENT NOWHERE
-> ACTUAL STATE: HE FOLLOWED NAAMAN / TOOK AND HID GOODS
-> SKIP -> S255-E001 / S255-E002 CLOSES / YOINK
-> ELISHA NAMES OBSERVED MEETING / PRONOUNCES LEPROSY
-> GEHAZI LEAVES LEPROUS WHITE AS SNOW
```

## Verses 1–8 — Captive girl's route and an invented quarrel

Naaman is the Syrian king's honored army captain, a mighty man through whom narrator attribution says LORD gave Syria victory, and he has leprosy. A little Israelite girl captured by Syrian bands serves Naaman's wife and says the Samaria prophet would heal him. Her report reaches the king.

The Syrian king sends Naaman, a letter, ten talents of silver, six thousand gold pieces and ten clothing changes. The letter tells Israel's king that Naaman is sent so the king may heal him. Israel's king tears his clothes, distinguishes himself from God and asks how he could kill, make alive or heal. He then asserts: **he seeks a quarrel against me.** The letter contains a healing demand but no quarrel statement, motive carrier or observed hostile act. This unsupported motive asserted as State closes mental `S254-E001-2KI5`. Captain performs one boilless **YOINK!** and changes no letter, fear or diplomacy.

Elisha hears of the torn clothes, asks why, and directs that Naaman come to him so he will know a prophet is in Israel. This supplies a different actionable route; it does not prove the Syrian king's unstated motive.

## Verses 9–16 — Expected ceremony, simple instruction, observed restoration

Naaman arrives with horses and chariots. Elisha does not come out; a messenger says to wash seven times in Jordan so flesh returns and he becomes clean. Naaman leaves angry because he had thought Elisha would personally emerge, invoke LORD, wave a hand and heal. He compares Damascus rivers favorably and asks why he could not wash there. These are identified expectations and questions, not falsely reported completed acts.

His servants distinguish a great requested act from the simple wash instruction. Naaman dips seven times in Jordan according to the saying; his flesh is restored like a little child's and he is clean. The exact sequence closes the girl's and Elisha's predictions while leaving the physical mechanism unresolved.

Naaman and his company return. He says he now knows no God in all earth except in Israel and offers a gift. Elisha swears by living LORD, before whom he stands, to receive nothing and refuses despite urging.

## Verses 17–19 — Earth, future bowing and peace

Naaman requests two mule-loads of earth, says he will offer only to LORD, and prospectively asks pardon for bowing in Rimmon's house when his master leans on his hand. Elisha says, **Go in peace.** The future bowing is not narrated as performed here; the request is not converted into an occurrence or contradiction.

## Verses 20–24 — Gehazi manufactures a delivery

Gehazi says Elisha spared Naaman by refusing the goods, swears by LORD and decides to run after him and take something. Naaman sees him, dismounts and asks whether all is well.

Gehazi says all is well, then claims: **My master sent me** because two prophet sons just arrived, requesting one talent and two garments. Retained State contains Gehazi's self-authored decision and pursuit; it contains no Elisha send and no arriving young men. This closes new mental `S255-E001-2KI5`, the false-occurrence series. Captain performs one causally null YOINK.

Naaman urges two talents, binds them with two garments and has two servants carry them. Gehazi takes the goods at the hill, stores them in the house, dismisses the men and returns.

## Verses 25–27 — I went nowhere

Elisha asks where Gehazi came from. Gehazi answers: **Your servant went nowhere.** The narrator has just retained his pursuit, meeting, receipt, transport and concealment. This is the same false-occurrence relation as E001, so an inert **SKIP -> S255-E001-2KI5** points to the retained explanation without deleting this second lie or any act. `S255-E002-2KI5` closes and receives its own separate YOINK.

Elisha asks whether his heart went with Gehazi when Naaman turned from the chariot and lists money, garments, groves, vineyards, sheep, cattle and servants. He says Naaman's leprosy will cling to Gehazi and his offspring forever. Gehazi leaves visibly leprous, white as snow. The perception mechanism, disease-transfer mechanism, descendant scope and future duration remain unresolved; only Gehazi's present exit State is observed.

## God-line boundary

- Narrator attributes Syrian victory through Naaman to LORD.
- The Israelite girl attributes healing capability to the Samaria prophet.
- Israel's king distinguishes himself from God, then supplies the quarrel motive himself.
- Naaman's imagined ceremony includes calling on LORD; it remains his prior expectation.
- Elisha swears by living LORD and refuses payment.
- Naaman confesses and makes future worship/pardon statements; Elisha says go in peace.
- Gehazi invokes living LORD for his own planned taking; that invocation does not supply authorization.
- No God body, hidden perception channel, healing mechanism or leprosy-transfer mechanism is rendered.

## Character and world-ledger changes

- NOT-NAAMAN JOE moves from honored captain with leprosy through messenger instruction, anger, servant correction, seven dips, clean flesh, confession, refused gift, earth request and departure in peace.
- NOT-CAPTIVE-GIRL JOE supplies the first retained healing route despite her captured-service State.
- NOT-ISRAEL-KING JOE turns the letter into an unsupported quarrel motive; Elisha redirects the case.
- NOT-GEHAZI JOE self-initiates pursuit, invents an Elisha send and visitor occurrence, obtains and hides goods, denies travel, is confronted and leaves leprous.
- NOT-ELISHA JOE refuses payment and distinguishes his act from Gehazi's execution.

## Bullshit pass

Issue `2KI-005 / THE EXPENSE CLAIM FROM NOWHERE`.

- Foreign executive arrives with a referral letter and an enormous budget.
- Local executive: **THIS IS CLEARLY A HOSTILE TAKEOVER.**
- Technician emails one instruction: **WASH SEVEN TIMES.**
- Foreign executive: **I EXPECTED A HAND-WAVING CEREMONY.**
- Procedure works.
- Technician refuses every bonus.
- Assistant chases the client: **TECHNICIAN SENT ME. TWO EMERGENCY CONTRACTORS ARRIVED.**
- Assistant takes payment, hides it, returns.
- Technician: **WHERE WERE YOU?**
- Assistant: **NOWHERE.**

Captain presses SKIP, arrives at the same lie wearing different trousers, and YOINKs it anyway.

## FIR verification

- FILTER: all 27 markers retained; 2 Kings 6 excluded.
- ISOLATE: captive referral, royal letter/model, prophet route, wash instruction, restoration, gift refusal, earth/pardon request, Gehazi pursuit, two false occurrence claims and leprous exit.
- RECONSTRUCT: S254 unsupported quarrel motive; S255 E001 false send/visitors and recurring E002 false no-travel claim.
- VERIFY: one exact SKIP, three YOINKs, no future Rimmon act, quarrel motive, healing, perception, disease-transfer or descendant outcome invented.

## Required compound-eye facets

1. Naaman honored captain/LORD-attributed victory/leprosy.
2. Syrian bands/captive Israelite girl/Naaman-wife service.
3. Girl points to Samaria prophet healing.
4. Girl's report carried to lord.
5. Syrian king letter/ten silver talents/6000 gold/ten garments.
6. Letter asks Israel king to heal Naaman.
7. Torn clothes/not-God/quarrel assertion/S254 YOINK.
8. Elisha hears and redirects Naaman.
9. Horses/chariots at Elisha door.
10. Messenger: Jordan seven washes/clean promise.
11. Naaman anger/expected personal LORD ceremony.
12. Damascus-river comparison/rage departure.
13. Servants' great-thing versus simple-wash argument.
14. Seven dips/restored childlike flesh/clean.
15. Return/confession/gift offer.
16. Elisha living-LORD refusal.
17. Two-mule earth request/exclusive future offering.
18. Prospective Rimmon bow/pardon request.
19. Go-in-peace/departure.
20. Gehazi self-authored pursuit/taking decision.
21. Pursuit/Naaman dismounts/is-all-well.
22. False master-sent/two-men-arrived claim/S255-E001 YOINK.
23. Two talents/two garments/two carriers.
24. Hill transfer/hide/dismiss servants.
25. Where-from/went-nowhere/SKIP->E001/S255-E002 YOINK.
26. Elisha heart-went/meeting and asset-list confrontation.
27. Leprosy pronouncement/Gehazi white-as-snow exit.

All twenty-seven facets appear simultaneously.

## Production boundary

One high-resolution 27-facet compound-eye image. `NOT-` identities and Joe faces for every living human and animal, including horses and mules. Letters, money, garments, rivers, earth, chariots and disease marks are nonliving/faceless. Exactly one inert SKIP and three separate boilless Captain poke/lick/YOINK/walk-away carriers. Leprosy restrained/non-graphic. No God body. Finished-story pixels only; workflow metadata remains sidecar-only.

*shrug*

OK.
