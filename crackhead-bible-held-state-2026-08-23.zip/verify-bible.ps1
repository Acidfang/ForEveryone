[CmdletBinding()]
param([string]$BibleRoot = $PSScriptRoot)

$ErrorActionPreference = 'Stop'
$inventoryPath = Join-Path $BibleRoot 'source-inventory.json'
$ledgerPath = Join-Path $BibleRoot 'book-ledger.jsonl'
if (-not (Test-Path -LiteralPath $inventoryPath)) { throw 'Missing source-inventory.json. Run build-source-index.ps1.' }

$inventory = Get-Content -Raw -LiteralPath $inventoryPath | ConvertFrom-Json
$events = @(Get-Content -LiteralPath $ledgerPath | Where-Object { $_.Trim() } | ForEach-Object { $_ | ConvertFrom-Json })
$manuscripts = @($events | Where-Object kind -eq 'chapter-manuscript')
$seen = @{}
$coveredVerseMarkers = 0

foreach ($manuscript in $manuscripts) {
    if (-not $manuscript.bookId -or -not $manuscript.chapter -or -not $manuscript.coverage -or -not $manuscript.manuscript) {
        throw "Incomplete chapter manuscript: $($manuscript.momentId)"
    }
    $key = "$($manuscript.bookId):$($manuscript.chapter)"
    if ($seen.ContainsKey($key)) { throw "Multiple active manuscripts without revision relation: $key" }
    $seen[$key] = $true
    $book = $inventory.books | Where-Object bookId -eq ($manuscript.bookId -replace '^CHB-', '') | Select-Object -First 1
    if (-not $book) { throw "Unknown source book for manuscript: $key" }
    $chapter = $book.chapters | Where-Object chapter -eq ([int]$manuscript.chapter) | Select-Object -First 1
    if (-not $chapter) { throw "Unknown source chapter: $key" }
    $filePath = Join-Path $BibleRoot $manuscript.manuscript
    if (-not (Test-Path -LiteralPath $filePath)) { throw "Missing manuscript file: $filePath" }
    if ($manuscript.causalClosure -eq $true) { $coveredVerseMarkers += $chapter.verseCount }
}

$state = [ordered]@{
    protocol = 'CRACKHEAD-BIBLE-VERIFY/1'
    sourceBooks = $inventory.bookCount
    sourceChapters = $inventory.chapterCount
    sourceVerseMarkers = $inventory.verseMarkerCount
    heldClosedChapters = @($manuscripts | Where-Object causalClosure -eq $true).Count
    heldCoveredVerseMarkers = $coveredVerseMarkers
    remainingChapters = $inventory.chapterCount - @($manuscripts | Where-Object causalClosure -eq $true).Count
    publicationObserved = $false
    complete = (@($manuscripts | Where-Object causalClosure -eq $true).Count -eq $inventory.chapterCount)
}
$state | ConvertTo-Json -Compress
if ($state.complete) { 'PASS complete source coverage; all manuscripts held.' }
else { "INCOMPLETE chapters=$($state.heldClosedChapters)/$($state.sourceChapters) verse-markers=$($state.heldCoveredVerseMarkers)/$($state.sourceVerseMarkers)" }

