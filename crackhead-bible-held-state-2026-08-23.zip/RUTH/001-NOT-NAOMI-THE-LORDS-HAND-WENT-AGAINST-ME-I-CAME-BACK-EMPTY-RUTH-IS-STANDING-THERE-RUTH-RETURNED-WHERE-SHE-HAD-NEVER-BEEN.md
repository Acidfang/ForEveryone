# CRACKHEAD RUTH 1

## Title page

**NOT-NAOMI: “THE LORD'S HAND WENT AGAINST ME. I CAME BACK EMPTY.” NOT-RUTH IS STANDING THERE. NOT-RUTH “RETURNED” WHERE SHE HAD NEVER BEEN.**

Source parent: Ruth chapter 1, verses 1–22, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-RUT-001/job.json` and `source.usfm`. Parent: Judges 21.

Display-origin layer: exact source identities remain in evidence. Comic display uses **NOT-ELIMELECH JOE**, **NOT-NAOMI JOE**, **NOT-MAHLON JOE**, **NOT-CHILION JOE**, **NOT-ORPAH JOE**, **NOT-RUTH JOE**, and **NOT-BETHLEHEM JOES**. Every living person is Joe-faced. NOT-THE-LORD and NOT-THE-ALMIGHTY remain unrendered.

CrackFlix routing: causal-credit `S022-E007-RUT1` uses `SKIP -> S022-E006-JDG21`; new visible-empty `S166-E001-RUT1` and new first-trip-return `S167-E001-RUT1` have no SKIP. Exactly three causally-null post-closure YOINKs.

## Causal foundation

```text
JUDGES PERIOD / FAMINE
-> ELIMELECH + NAOMI + TWO SONS MOVE BETHLEHEM-JUDAH TO MOAB
-> ELIMELECH DIES
-> SONS MARRY ORPAH + RUTH / ABOUT TEN YEARS
-> BOTH SONS DIE
-> NAOMI LEFT WITHOUT HUSBAND/SONS
-> HEARS LORD VISITED PEOPLE/GAVE BREAD
-> NAOMI + ORPAH + RUTH START RETURN TO JUDAH
-> NAOMI TELLS BOTH TO RETURN TO MOTHERS / PRAYS KINDNESS+REST
-> BOTH SAY THEY WILL GO WITH HER
-> NAOMI ARGUES NO PRESENT/FUTURE HUSBANDS
-> ATTRIBUTES HER GRIEF TO LORD HAND AGAINST HER
-> ORPAH RETURNS / RUTH STAYS
-> NAOMI TELLS RUTH FOLLOW ORPAH TO PEOPLE/GOD
-> RUTH COMMITS GO/STAY/PEOPLE/GOD/DIE/BURY
-> NAOMI STOPS URGING
-> BOTH ARRIVE BETHLEHEM
-> CITY ASKS IS THIS NAOMI
-> NAOMI REQUESTS MARA / ATTRIBUTES BITTERNESS+RETURN+AFFLICTION TO DIVINE ACTORS
-> SAYS SHE RETURNED EMPTY WHILE RUTH IS WITH HER
-> NARRATOR SAYS RUTH RETURNED FROM MOAB THOUGH NO PRIOR JUDAH STATE IS SUPPLIED
-> BARLEY HARVEST BEGINS
```

## Ruth 1:1–5 — FAMINE / MOAB / THREE DEATHS

During the judges' period, famine exists in the land. NOT-ELIMELECH moves from NOT-BETHLEHEM-JUDAH to NOT-MOAB with NOT-NAOMI and sons NOT-MAHLON and NOT-CHILION. They live there.

Elimelech dies. The sons marry Moabite women NOT-ORPAH and NOT-RUTH and live there about ten years. Both sons die. Naomi is left without husband and two sons.

No cause of any death, marriage pairing, children, property State, disease, judgment or divine action is supplied.

## Ruth 1:6–10 — BREAD HEARD / RETURN BEGINS

Naomi hears in Moab that NOT-THE-LORD visited his people by giving bread. This is narrator-retained divine attribution; no physical delivery mechanism or amount is supplied. Naomi rises with both daughters-in-law to return from Moab. All three leave and travel toward Judah.

Naomi tells both women to return to their mothers' houses. She asks the LORD to deal kindly with them as they dealt with the dead and with her, and to grant each rest in a husband's house. These are requests, not observed divine promises or completed outcomes.

After kisses and weeping, both say they will return with Naomi to her people.

## Ruth 1:11–15 — GO BACK / LORD'S HAND

Naomi tells them to go back. She asks whether she has sons in her womb for husbands and describes the impossible waiting chain even if she obtained a husband that night and bore sons. She says her grief is serious for their sakes because:

**“THE LORD'S HAND HAS GONE OUT AGAINST ME.”**

The retained source narrates human travel, marriages and three deaths but supplies no LORD hand act producing those deaths or bereavement. This repeats causal-credit substitution:

**SKIP -> S022-E006-JDG21: RESULT CREDITED TO DIVINE ACTOR / PRODUCING ACT NOT RETAINED.**

Captain zones out. After Naomi completes the attribution, Captain pokes the causal-credit boil, licks his finger, says **“YOINK!”**, and walks away.

Orpah kisses Naomi and goes back. Ruth stays. Naomi points to Orpah's return to her people and god and tells Ruth to follow. No Orpah rejection, apostasy motive or future State is invented.

## Ruth 1:16–18 — RUTH'S SELECTED ROUTE

Ruth asks Naomi not to urge separation and states the observable commitments:

- where Naomi goes, Ruth will go;
- where Naomi stays, Ruth will stay;
- Naomi's people will be Ruth's people;
- Naomi's God will be Ruth's God;
- where Naomi dies, Ruth will die and be buried;
- only death will part them.

The future death/burial and lifetime duration are speech, not completed facts. Naomi observes determination and stops urging. No private motive is assigned to Ruth.

## Ruth 1:19–21 — I CAME BACK EMPTY / RUTH IS THERE

Naomi and Ruth both arrive at Bethlehem. The city is excited and asks whether this is Naomi. Naomi says not to call her Pleasant but Bitter because the Almighty dealt bitterly with her. She continues:

**“I WENT OUT FULL, AND THE LORD HAS BROUGHT ME HOME AGAIN EMPTY.”**

Ruth has just traveled and arrived with her and remains physically present in the narrated State. No definition narrows “empty” to husband/sons, property, food or another selected class. New CrackFlix series:

**S166: I CAME BACK EMPTY. THIS PERSON CAME BACK WITH ME.**

After the empty claim and Ruth's present State coexist, Captain pokes the empty boil, licks his finger, says **“YOINK!”**, and walks away.

Naomi also says the LORD testified against her and the Almighty afflicted her. Those statements join the same `S022-E007-RUT1` causal-credit occurrence: no distinct testimony speech, affliction act or carrier is narrated. They are not multiplied into extra cracks.

## Ruth 1:22 — RUTH RETURNED TO A PLACE WITH NO PRIOR VISIT

The narrator says Naomi returned and Ruth the Moabitess returned with her out of Moab. Naomi has a retained Bethlehem origin. Ruth has only a retained Moab origin and no prior Judah/Bethlehem visit in the selected source State.

Applying “returned” to Ruth therefore claims a repeated route without a first occurrence. New CrackFlix series:

**S167: SHE RETURNED TO A PLACE SHE HAD NEVER BEEN.**

When Ruth's “returned” arrival is stated, Captain pokes the return boil, licks his finger, says **“YOINK!”**, and walks away. The women arrive at the beginning of barley harvest. No harvest participation occurs yet.

## Character and world-ledger changes

- NOT-NAOMI gains Bethlehem-to-Moab migration, widowhood/bereavement, Judah return, repeated daughter-in-law release attempts, divine-affliction attribution and Pleasant-to-Bitter requested name State.
- NOT-RUTH gains Moabite widow State, refusal to leave Naomi, people/God/death/burial commitments, Bethlehem arrival and first-trip “return” narration.
- NOT-ORPAH gains Moabite widow State, initial Judah travel, Naomi kiss and return to her people/god.
- NOT-ELIMELECH, NOT-MAHLON and NOT-CHILION gain narrated death States with causes unresolved.
- `S022-E007-RUT1`, `S166-E001-RUT1`, and `S167-E001-RUT1` retain the completed contradictions.

## Bullshit pass

Issue `RUT-001 / EMPTY ARRIVAL MANIFEST`. NOT-NAOMI files **PASSENGERS RETURNED: ZERO** while NOT-RUTH stands inside the barcode, and the route engine marks NOT-RUTH **RETURN CUSTOMER** on her first retained visit. The divine claims are stored under **HAND OF LORD — NO TRACKING NUMBER**. Foundation unchanged.

## FIR verification

- FILTER: Ruth 1 only; all 22 markers retained in order; Ruth 2 excluded.
- ISOLATE: famine migration, marriages/deaths, bread report, return route, release dialogue, Orpah return, Ruth commitment, Bethlehem arrival, name request, divine attributions, empty claim and first-trip return wording.
- RECONSTRUCT: repeated `S022` causal-credit; new `S166` visible-empty and `S167` first-trip-return roots.
- VERIFY: exactly three cracks, one SKIP and three YOINKs; no death cause, divine mechanism, answered prayer, marriage pairing details, child State, property State, private motive, future oath fulfillment or harvest act invented; publication held.

## Required comic states

1. Judges-period famine and family migration from Bethlehem to Moab.
2. Elimelech death; sons' Moabite marriages/ten-year residence; both sons die.
3. Bread report and three-woman Judah return begins.
4. Naomi's return-to-mothers request, kindness/rest prayers, both women's refusal.
5. Hypothetical-son argument and LORD-hand attribution; S022 SKIP and first YOINK.
6. Orpah returns; Ruth stays; Naomi says follow Orpah.
7. Ruth's go/stay/people/God/die/bury commitment; Naomi stops urging.
8. Two women arrive; city asks “Is this Naomi?”
9. Mara request, divine-affliction speech, “home empty” while Ruth stands there; S166 and second YOINK.
10. Narrator calls Ruth's first retained Judah arrival a return; S167 and third YOINK; barley-harvest timing.
11. Held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; exact source identities remain in evidence.
- Every living human is Joe-faced. NOT-THE-LORD and NOT-THE-ALMIGHTY remain unrendered.
- Keep deaths restrained and non-graphic. Do not visually manufacture divine hands, testimony, affliction or bread-delivery mechanism.
- One SKIP points exactly to `S022-E006-JDG21`. New `S166` and `S167` have no SKIP. Exactly three boilless, causally-null Captain occurrences after each contradiction completes.
- Do not invent death causes, divine approval/response, prayer fulfillment, marriage pair allocation, children, wealth/property, Orpah motive/future, Ruth motive, future oath fulfillment, definition of empty or Ruth 2 harvest acts.
- Publication held. `CHB-RUT-002` excluded.

*shrug*

OK.
