# CRACKHEAD RUTH 4

## Title page

**NOT-RUTH BORE A SON. THE WOMEN SAID A SON WAS BORN TO NOT-NAOMI.**

Source parent: Ruth chapter 4, verses 1–22, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-RUT-004/job.json` and `source.usfm`. Parent: Ruth 3.

Display-origin layer: exact source identities remain in evidence. Comic display uses **NOT-BOAZ JOE**, **NOT-NEARER-KINSMAN JOE**, **NOT-NAOMI JOE**, **NOT-RUTH JOE**, **NOT-ELIMELECH JOE**, **NOT-MAHLON JOE**, **NOT-CHILION JOE**, the ten **NOT-ELDER JOES**, the gate **NOT-PEOPLE JOES**, the neighbor **NOT-WOMEN JOES**, and baby **NOT-OBED JOE**. Every living person is Joe-faced. The named genealogy is displayed with `NOT-` identities. NOT-THE-LORD remains unrendered.

CrackFlix routing: new birth-recipient mismatch `S171-E001-RUT4` has no SKIP. Exactly one causally-null post-closure YOINK.

## Causal foundation

```text
BOAZ GOES TO GATE / SITS
-> NEARER KINSMAN PASSES / BOAZ CALLS HIM / HE SITS
-> BOAZ SEATS TEN ELDERS
-> BOAZ PRESENTS NAOMI LAND REDEMPTION
-> NEARER KINSMAN SAYS I WILL REDEEM
-> BOAZ ADDS SAME-DAY RUTH PURCHASE / DEAD-NAME DUTY
-> NEARER KINSMAN SAYS I CANNOT / ENDANGER OWN INHERITANCE
-> TRANSFERS REDEMPTION RIGHT / REMOVES SANDAL
-> BOAZ DECLARES PROPERTY PURCHASE + RUTH AS WIFE PURCHASE
-> ELDERS/PEOPLE WITNESS + SPEAK BLESSINGS
-> BOAZ TAKES RUTH / SHE BECOMES WIFE
-> BOAZ GOES IN TO HER
-> NARRATOR: LORD ENABLES CONCEPTION
-> RUTH BEARS SON
-> WOMEN SPEAK TO NAOMI / ATTRIBUTE KINSMAN + FUTURE RESTORATION
-> WOMEN SAY RUTH LOVES NAOMI / BETTER THAN SEVEN SONS
-> NAOMI TAKES CHILD / BOSOM / NURSE
-> NEIGHBOR WOMEN SAY A SON IS BORN TO NAOMI
-> WOMEN NAME HIM OBED
-> OBED IDENTIFIED AS FATHER OF JESSE / GRANDFATHER OF DAVID
-> PEREZ-TO-DAVID GENEALOGY
```

## Ruth 4:1–4 — THE FIRST ANSWER

Boaz goes to the gate and sits. The nearer kinsman he previously addressed comes by. Boaz calls him **“FRIEND”**, asks him to sit, and seats ten city elders.

Boaz says Naomi, returned from Moab, is selling Elimelech's parcel. He tells the nearer kinsman to buy before the seated people and elders. If he redeems it, redeem it; if not, tell Boaz. Boaz identifies the nearer man as first and himself as next.

The nearer kinsman answers:

**“I WILL REDEEM IT.”**

The source gives no personal name for him. `NOT-NEARER-KINSMAN JOE` remains an address, not an invented identity.

## Ruth 4:5–8 — THE ADDED CONDITION CHANGES THE ANSWER

After the acceptance, Boaz says that on the day the field is bought from Naomi, it must also be bought from Ruth, the dead man's wife, to raise the dead man's name on his inheritance.

The nearer kinsman then says he cannot redeem it for himself lest he endanger his own inheritance. He transfers his right to Boaz.

This is retained as a changed-answer sequence, not declared contradiction. The second answer follows a newly supplied Ruth/dead-name condition absent from Boaz's first offer. The nature of the inheritance danger, whether the man knew the condition earlier, and the complete legal relation remain unresolved.

The narrator describes the former Israel custom for formalizing redemption/exchange: one man removes a sandal and gives it to his neighbor. The nearer kinsman tells Boaz to buy it and removes his sandal. Do not import any other sandal procedure.

## Ruth 4:9–12 — WITNESSES

Boaz tells the elders and people they are witnesses that day. He says he bought from Naomi everything belonging to Elimelech, Chilion and Mahlon. He also says he purchased Ruth the Moabitess, Mahlon's wife, as his wife, to raise the dead man's name on his inheritance so it is not cut off among his brothers or at his place's gate.

The people and elders say they are witnesses. They ask LORD to make the woman entering Boaz's house like Rachel and Leah, ask Boaz to act worthily and be famous, and ask that his house be like Perez's house through offspring LORD will give by Ruth.

These are witness declarations and blessings. No divine response or outcome has yet occurred in their speech Moment. The transaction's institution is source-stated; consent dialogue, price, deed, land transfer mechanics and Ruth's presence at the gate are not supplied.

## Ruth 4:13 — RUTH BEARS A SON

Boaz takes Ruth and she becomes his wife. He goes in to her. The narrator says LORD enables her to conceive, and Ruth bears a son.

The divine enablement is retained as narrator attribution. No visible form, speech, biological mechanism or independent verification is supplied. The source does not narrate a wedding ceremony, Ruth's reply, pregnancy duration or birth procedure.

## Ruth 4:14–17 — A SON IS BORN TO NAOMI

The women tell Naomi LORD is blessed for not leaving her that day without a near kinsman. They ask that his name be famous in Israel and predict he will restore Naomi's life and sustain her in old age. They say Ruth loves Naomi, is better to her than seven sons, and has given birth to him.

Naomi takes the child, lays him in her bosom and becomes his nurse.

The neighbor women then give him a name, saying:

**“A SON IS BORN TO NAOMI.”**

The retained birth actor is Ruth. Naomi subsequently takes and nurses the child; no Naomi pregnancy or birth is supplied. New CrackFlix series:

**S171: SHE BORE HIM. THEY SAY HE WAS BORN TO SOMEONE ELSE.**

After the statement completes, Captain pokes the birth-recipient boil, licks his finger, says **“YOINK!”**, and walks away. The women name the child Obed. Naming authority, whether Naomi agrees, and whether “born to” is intended as biological, household or social language remain unresolved; the words and acts are retained without repairing them.

Obed is identified as Jesse's father and David's grandfather. No future acts are imported.

## Ruth 4:18–22 — THE RETAINED LINE

The chapter closes with a genealogy:

**NOT-PEREZ JOE → NOT-HEZRON JOE → NOT-RAM JOE → NOT-AMMINADAB JOE → NOT-NAHSHON JOE → NOT-SALMON JOE → NOT-BOAZ JOE → NOT-OBED JOE → NOT-JESSE JOE → NOT-DAVID JOE.**

The genealogy supplies parent relations only. Birth locations, mothers, dates, lifespans, overlapping lifetimes and acts are not backfilled here. Ruth closes 4/4. First Samuel 1 remains excluded.

## Character and world-ledger changes

- NOT-BOAZ gains gate assembly, land/Ruth condition presentation, redemption acquisition, sandal confirmation, witnessed property/wife declarations, Ruth marriage and fatherhood.
- NOT-NEARER-KINSMAN JOE gains gate appearance, first redemption acceptance, changed refusal after added condition, inheritance-danger claim, right transfer and sandal removal; personal identity remains unresolved.
- NOT-RUTH gains source-stated wife State, conception attribution and son birth.
- NOT-NAOMI gains completed same-day settlement forecast, land-sale attribution, child reception and nurse State; birth remains Ruth's act.
- NOT-OBED JOE gains birth, neighbor-given name and retained descendant relations.
- The elders/people/women gain witness, blessing, prediction, evaluation and naming speech exactly as carried.
- `S171-E001-RUT4` retains the completed birth-recipient contradiction.

## Bullshit pass

Issue `RUT-004 / SANDAL SIGNATURE AUTHORITY`. The redemption terminal displays **I WILL REDEEM**, Boaz expands **TERMS AND CONDITIONS**, and the nearer kinsman unplugs his shoe. The maternity ledger then records **BIRTH EXECUTOR: NOT-RUTH / DELIVERY RECIPIENT: NOT-NAOMI**. Foundation unchanged.

## FIR verification

- FILTER: Ruth 4 only; all 22 markers retained in order; First Samuel 1 excluded.
- ISOLATE: gate procedure, changed redemption answer after added condition, sandal transfer, witnessed acquisition, marriage/conception/birth, Naomi child-care State, birth-recipient mismatch and genealogy.
- RECONSTRUCT: one new `S171` occurrence; the redeemer answer change remains non-crack because the addressed input changes.
- VERIFY: exactly one crack, zero SKIPs and one YOINK; no nearer-man identity, inheritance mechanism, consent, price, deed, ceremony, divine form/speech/mechanism, pregnancy timing, naming authority or later biography invented; publication held.

## Required comic states

1. Boaz gate arrival, nearer kinsman called/seated, ten elders seated.
2. Naomi land offer, redemption priority and nearer man's “I will redeem.”
3. Added Ruth/dead-name condition and changed refusal/inheritance claim; explicitly no crack.
4. Former custom narration kept minimal; sandal removal/right transfer.
5. Boaz's property and Ruth-wife acquisition declaration to witnesses.
6. Elders/people witness response and Rachel/Leah/Perez blessing speech.
7. Boaz takes Ruth; wife/conception/birth chain with NOT-THE-LORD unrendered.
8. Women address Naomi with kinsman/restorer/seven-sons evaluation.
9. Naomi takes/holds/nurses baby NOT-OBED JOE.
10. Women say “a son is born to Naomi”; S171 and one YOINK.
11. Women name Obed; retained father/grandfather statement.
12. Perez-to-David genealogy and Ruth 4/4 held lineage page.

## Production boundary

- Every rendered biblical identity and place label carries `NOT-`; exact source identities remain in evidence.
- Every living human, including baby NOT-OBED and genealogy figures if rendered alive, is Joe-faced. NOT-THE-LORD remains unrendered.
- Do not name the nearer kinsman beyond the source's friend/nearer-kinsman address.
- Preserve first offer, first acceptance, added condition and refusal in order. Do not mark that answer change as contradiction.
- Keep purchase/marriage language source-bound. Do not invent consent, coercion, price, deed, wedding ritual or legal explanation.
- One crack only, after the women say the son was born to Naomi. No SKIP. Exactly one boilless, causally-null Captain occurrence: poke, lick, **“YOINK!”**, walk away, no look back.
- Keep conception as narrator-attributed LORD act without divine form, speech or mechanism.
- Do not reinterpret “born to Naomi”; preserve Ruth's birth act and the women's later exact statement.
- Genealogy supplies relations only. Do not backfill lives or future acts.
- Publication held. `CHB-1SA-001` excluded.

*shrug*

OK.

