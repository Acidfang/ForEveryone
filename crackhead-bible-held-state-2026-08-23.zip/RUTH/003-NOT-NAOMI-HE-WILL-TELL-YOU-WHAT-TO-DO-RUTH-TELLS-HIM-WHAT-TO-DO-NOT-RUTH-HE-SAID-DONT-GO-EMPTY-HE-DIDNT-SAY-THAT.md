# CRACKHEAD RUTH 3

## Title page

**NOT-NAOMI: “HE WILL TELL YOU WHAT TO DO.” NOT-RUTH TELLS HIM WHAT TO DO. NOT-RUTH: “HE SAID, ‘DON'T GO EMPTY.’” HE DIDN'T SAY THAT.**

Source parent: Ruth chapter 3, verses 1–18, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-RUT-003/job.json` and `source.usfm`. Parent: Ruth 2.

Display-origin layer: exact source identities remain in evidence. Comic display uses **NOT-NAOMI JOE**, **NOT-RUTH JOE**, **NOT-BOAZ JOE**, and the unresolved **NOT-NEARER-KINSMAN JOE** only as an unrendered address until he appears. Every living person is Joe-faced. NOT-THE-LORD remains unrendered.

CrackFlix routing: new instruction-reversal `S169-E001-RUT3` and new unspoken-quote `S170-E001-RUT3` have no SKIP. Exactly two causally-null post-closure YOINKs.

## Causal foundation

```text
NAOMI SEEKS REST/WELLBEING FOR RUTH
-> IDENTIFIES BOAZ KINSMAN + NIGHT WINNOWING
-> INSTRUCTS WASH/ANOINT/DRESS/GO UNSEEN UNTIL EAT+DRINK FINISH
-> INSTRUCTS NOTE SLEEPING PLACE / UNCOVER FEET / LIE DOWN
-> SAYS BOAZ WILL TELL RUTH WHAT TO DO
-> RUTH SAYS ALL YOU SAY I WILL DO
-> NARRATOR: RUTH DID EVERYTHING NAOMI TOLD
-> BOAZ EATS/DRINKS/MERRY / LIES AT GRAIN HEAP
-> RUTH SOFTLY UNCOVERS FEET / LIES DOWN
-> MIDNIGHT BOAZ STARTLED / ASKS IDENTITY
-> RUTH IDENTIFIES SELF / TELLS BOAZ SPREAD GARMENT / KINSMAN BASIS
-> BOAZ BLESSES/COMMENDS / PROMISES ALL SHE SAYS
-> BOAZ IDENTIFIES NEARER KINSMAN
-> CONDITIONAL DUTY ORDER / BOAZ OATH IF OTHER REFUSES
-> RUTH LIES UNTIL PRE-RECOGNITION MORNING
-> BOAZ SAYS WOMAN'S VISIT SHOULD NOT BE KNOWN
-> BOAZ DIRECT SPEECH: BRING MANTLE / HOLD IT
-> BOAZ MEASURES SIX BARLEY / LOADS RUTH / GOES CITY
-> RUTH RETURNS / REPORTS ALL BOAZ DID
-> RUTH QUOTES BOAZ: DON'T GO EMPTY TO MOTHER-IN-LAW
-> RETAINED BOAZ DIRECT SPEECH DID NOT CONTAIN THAT LINE
-> NAOMI PREDICTS BOAZ WILL SETTLE TODAY
```

## Ruth 3:1–6 — HE WILL TELL YOU WHAT TO DO

Naomi says she seeks rest for Ruth so it may be well with her. She identifies Boaz as their kinsman and says he will winnow barley that night.

Naomi instructs Ruth to wash, anoint, dress and go to the threshing floor without making herself known until Boaz finishes eating and drinking. Ruth must note where he lies, uncover his feet and lie down. Naomi closes the instruction:

**“THEN HE WILL TELL YOU WHAT TO DO.”**

Ruth says she will do all Naomi says. She goes down, and the narrator says she does everything her mother-in-law told her.

The plan's purpose is Naomi's stated rest/wellbeing. No sexual act, marriage agreement, sedative effect, romance, legal custom or guaranteed outcome is supplied.

## Ruth 3:7–9 — RUTH TELLS BOAZ WHAT TO DO

Boaz eats and drinks, his heart is merry, and he lies at the grain heap. Ruth comes softly, uncovers his feet and lies down. “Merry” does not establish incapacity or intoxication level.

At midnight Boaz is startled, turns and finds a woman at his feet. He asks who she is. Ruth identifies herself and directs him:

**“SPREAD THE CORNER OF YOUR GARMENT OVER YOUR SERVANT; FOR YOU ARE A NEAR KINSMAN.”**

Naomi said Boaz would tell Ruth what to do. The first retained post-discovery instruction instead comes from Ruth to Boaz. New CrackFlix series:

**S169: HE WILL TELL YOU WHAT TO DO. YOU TELL HIM WHAT TO DO.**

After Ruth gives the instruction, Captain pokes the instruction-reversal boil, licks his finger, says **“YOINK!”**, and walks away. Boaz answers normally.

## Ruth 3:10–13 — KINSMAN ORDER

Boaz says Ruth is blessed by the LORD and calls her latter kindness greater because she did not follow young men, poor or rich. This is Boaz's evaluation; Ruth's private motive and actual alternative suitors are not supplied.

He says the whole city knows she is worthy and promises to do all she says. He confirms he is a near kinsman but says another is nearer.

Ruth must stay the night. In the morning, if the nearer kinsman performs the duty, he may do it; if not, Boaz swears by the living LORD that he will. The duty's full procedure, property relation, other man's identity/knowledge and outcome remain future.

No divine speech or witnessed blessing effect occurs.

## Ruth 3:14–15 — KNOWN WORTH / UNKNOWN VISIT

Ruth lies at Boaz's feet until morning and rises before people can discern one another. Boaz says the woman's threshing-floor visit must not be known.

This secrecy follows his statement that the whole city knows Ruth is worthy. The two States are retained as friction, not declared contradiction: the source does not say worthy people must publicize every visit or supply Boaz's reason.

Boaz directly says:

**“BRING THE MANTLE THAT IS ON YOU, AND HOLD IT.”**

Ruth holds it. He measures six unspecified measures of barley, places it on her, and goes into the city. The unit, weight and exact carrier capacity remain unresolved.

## Ruth 3:16–18 — HE SAID A LINE THE SOURCE DIDN'T RECORD

Ruth returns to Naomi and tells all the man did for her. She reports the six measures and adds:

**“HE SAID, ‘DON'T GO EMPTY TO YOUR MOTHER-IN-LAW.’”**

The retained Boaz speech at the barley transfer contains only the mantle/hold instruction. No “don't go empty” line appears before or during the transfer. New CrackFlix series:

**S170: HE SAID THIS. THE RETAINED SPEECH DOESN'T.**

The barley act remains real; only the claimed quotation lacks a retained carrier. After the report completes, Captain pokes the unspoken-quote boil, licks his finger, says **“YOINK!”**, and walks away.

Naomi tells Ruth to wait until she knows what happens and predicts Boaz will not rest until settling it that day. This remains a future prediction; Ruth 4 is excluded and cannot close it here.

## Character and world-ledger changes

- NOT-NAOMI gains Ruth-rest objective, covert threshing-floor plan, Boaz-will-instruct forecast and same-day settlement prediction.
- NOT-RUTH gains full plan execution, feet-position State, garment/kinsman instruction to Boaz, overnight stay, early departure, six-measure barley transport and unretained Boaz quote report.
- NOT-BOAZ gains night winnowing/eating/drinking/merry/lying State, midnight discovery, Ruth-worth evaluation, conditional kinsman promise, secrecy instruction, six-measure barley transfer and city departure.
- NOT-NEARER-KINSMAN gains existence/priority only; identity, knowledge, decision and execution remain unresolved.
- `S169-E001-RUT3` and `S170-E001-RUT3` retain the completed contradictions.

## Bullshit pass

Issue `RUT-003 / MIDNIGHT WORKFLOW HANDOFF`. NOT-NAOMI submits **HE WILL PROVIDE INSTRUCTIONS**, NOT-RUTH immediately opens **INSTRUCT BOAZ**, and the morning transcript generator attaches **DON'T GO EMPTY** to a speech bubble that never existed. Six measures remain in **UNIT NOT FOUND**. Foundation unchanged.

## FIR verification

- FILTER: Ruth 3 only; all 18 markers retained in order; Ruth 4 excluded.
- ISOLATE: Naomi plan, Ruth execution, midnight instruction reversal, kinsman ordering, secrecy, barley transfer, later quotation and future settlement forecast.
- RECONSTRUCT: new `S169` instruction reversal and new `S170` unretained quotation.
- VERIFY: exactly two cracks, zero SKIPs and two YOINKs; no sexual act, intoxication/incapacity, romance, legal custom, duty result, secrecy motive, barley unit, divine effect or Ruth 4 closure invented; publication held.

## Required comic states

1. Naomi rest objective, Boaz/tonight identification, washing/dressing/hidden-arrival instructions.
2. Sleeping-place/feet/lie-down plan and “he will tell you what to do”; Ruth agrees and narrator says full execution.
3. Boaz meal/merry/lying; Ruth softly uncovers feet/lies down; non-sexual, restrained.
4. Midnight startle/identity question; Ruth tells Boaz spread garment/kinsman; S169 and first YOINK.
5. Boaz blessing/kindness/worthy speech and promise.
6. Nearer kinsman disclosure and conditional morning duty oath.
7. Pre-dawn departure and “don't let visit be known”; retain friction without crack.
8. Direct mantle/hold speech and six-measure barley transfer.
9. Ruth home report and inserted “don't go empty” quotation; S170 and second YOINK.
10. Naomi wait/today forecast retained as unexecuted speech.
11. Held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; exact source identities remain in evidence.
- Every living human is Joe-faced. NOT-THE-LORD remains unrendered. Do not render the nearer kinsman as a visible person before his source appearance.
- Present the threshing-floor sequence as source acts only: wash/dress, wait, uncover feet, lie at feet, speak, remain until morning. Do not add sexual contact, nudity, romance or intoxication incapacity.
- No SKIP. Exactly two boilless, causally-null Captain occurrences after `S169` and `S170` complete.
- Preserve direct speech versus later report. Do not insert “don't go empty” into Boaz's earlier speech to repair continuity.
- Do not invent legal custom, marriage consent, duty procedure/outcome, secrecy motive, barley unit, divine blessing effect or Ruth 4 settlement.
- Publication held. `CHB-RUT-004` excluded.

*shrug*

OK.
