# CRACKHEAD RUTH 2

## Title page

**NOT-RUTH CAME “BACK” TO PEOPLE SHE DIDN'T KNOW. NOT-BOAZ DID THE WORK; THE LORD GOT THE KINDNESS CREDIT. “STAY WITH MY MAIDENS” BECOMES “HE SAID YOUNG MEN.”**

Source parent: Ruth chapter 2, verses 1–23, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-RUT-002/job.json` and `source.usfm`. Parent: Ruth 1.

Display-origin layer: exact source identities remain in evidence. Comic display uses **NOT-NAOMI JOE**, **NOT-RUTH JOE**, **NOT-BOAZ JOE**, **NOT-OVERSEER JOE**, **NOT-REAPER JOES**, **NOT-MAIDEN JOES**, and **NOT-YOUNG-MAN JOES**. Every living person and grain interpreted as faced is Joe-faced. NOT-THE-LORD remains unrendered.

CrackFlix routing: first-trip-return `S167-E002-RUT2` uses `SKIP -> S167-E001-RUT1`; causal-credit `S022-E008-RUT2` uses `SKIP -> S022-E007-RUT1`; new speech-carrier drift `S168-E001-RUT2` has no SKIP. Exactly three causally-null post-closure YOINKs.

## Causal foundation

```text
NAOMI HAS WEALTHY ELIMELECH-RELATIVE BOAZ
-> RUTH ASKS TO GLEAN WHERE SHE FINDS FAVOR
-> NAOMI SAYS GO
-> RUTH HAPPENS INTO BOAZ FIELD / GLEANS
-> BOAZ ARRIVES / LORD GREETING EXCHANGE
-> BOAZ ASKS WHOSE YOUNG WOMAN
-> OVERSEER: MOABITE WHO CAME BACK WITH NAOMI
-> OVERSEER REPORTS REQUEST + MORNING WORK/LITTLE REST
-> BOAZ TELLS RUTH STAY CLOSE TO MY MAIDENS
-> BOAZ SAYS YOUNG MEN ORDERED NOT TO TOUCH / WATER AVAILABLE
-> RUTH ASKS WHY FAVOR AS FOREIGNER
-> BOAZ: TOLD HER ACTS / LEFT BIRTH LAND / CAME TO PEOPLE NOT KNOWN BEFORE
-> BOAZ PRAYS LORD REPAY/REWARD
-> BOAZ FEEDS RUTH / ORDERS PROTECTION + EXTRA GRAIN
-> RUTH GLEANS ABOUT ONE EPHAH / BRINGS GRAIN+LEFTOVER FOOD HOME
-> NAOMI ASKS / BLESSES PERSON WHO NOTICED HER
-> RUTH IDENTIFIES BOAZ
-> NAOMI CREDITS LORD'S UNABANDONED KINDNESS / IDENTIFIES KINSMAN
-> RUTH REPORTS BOAZ SAID STAY CLOSE TO YOUNG MEN
-> ACTUAL RETAINED BOAZ SPEECH SAID STAY CLOSE TO MAIDENS
-> NAOMI SAYS GO WITH MAIDENS
-> RUTH DOES SO THROUGH BARLEY+WHEAT HARVESTS / LIVES WITH NAOMI
```

## Ruth 2:1–3 — GLEANING ROUTE

Naomi has a wealthy, mighty relative of Elimelech named NOT-BOAZ. NOT-RUTH asks permission to glean grain after a person in whose sight she finds favor. Naomi tells her to go.

Ruth goes, gleans behind reapers and happens into Boaz's field portion. “Happened” is retained as narrator wording; no probability, divine steering, property map or prior knowledge is invented.

## Ruth 2:4–7 — CAME BACK / FIRST ARRIVAL

Boaz arrives from Bethlehem and exchanges LORD blessing speech with the reapers. These are greetings, not observed divine appearances or completed blessing effects.

Boaz asks the overseer whose young woman Ruth is. The overseer identifies her as:

**“THE MOABITE LADY WHO CAME BACK WITH NAOMI OUT OF MOAB.”**

This repeats the Ruth 1 return classification. Later in the same chapter Boaz states she left her birth land and came to a people she did not know before, confirming no retained prior-people State:

**SKIP -> S167-E001-RUT1: RETURNED TO A PLACE SHE HAD NEVER BEEN.**

Captain zones out. When Boaz's before/unknown statement completes the retained mismatch, Captain pokes the first-return boil, licks his finger, says **“YOINK!”**, and walks away.

The overseer reports Ruth's request to glean among sheaves and says she worked from morning with a little house rest. His observation duration and exact rest length remain source speech.

## Ruth 2:8–13 — STAY, PROTECTION, WATER, REWARD PRAYER

Boaz tells Ruth:

**“STAY HERE CLOSE TO MY MAIDENS.”**

He tells her to follow their field, says he commanded the young men not to touch her, and grants water from vessels they drew. Ruth bows and asks why a foreigner receives notice.

Boaz says he was told all she did for Naomi after her husband's death: leaving father, mother and birth land and coming to a people she did not know before. He asks the LORD to repay her work and give full reward under divine wings.

That is a prayer/request. No completed LORD repayment or wing form is narrated here.

## Ruth 2:14–18 — BOAZ'S OBSERVABLE PROVISION CHAIN

Boaz invites Ruth to eat bread and vinegar. She sits beside reapers, receives parched grain, eats, is satisfied and keeps leftovers.

When she resumes gleaning, Boaz orders young men to:

- let her glean among sheaves;
- not reproach her;
- pull grain from bundles and leave it;
- let her glean;
- not rebuke her.

Ruth gleans until evening, beats out about an ephah of barley, carries it into the city, shows Naomi the grain and gives her leftover food.

These are retained Boaz, worker and Ruth acts. No supernatural grain multiplication or wage contract is inferred.

## Ruth 2:19–20 — BOAZ DID IT / LORD KINDNESS CREDIT

Naomi asks where Ruth gleaned and worked and blesses the person who noticed her. Ruth names Boaz.

Naomi says Boaz may be blessed by the LORD, **“WHO HAS NOT ABANDONED HIS KINDNESS TO THE LIVING AND TO THE DEAD,”** then identifies Boaz as a close relative/kinsman.

The immediate producing chain—field access, protection order, water, meal, permission and deliberately released grain—is performed by Boaz and his workers. Naomi attributes the observed kindness result to the LORD without a separate narrated LORD provision act. This repeats causal-credit substitution:

**SKIP -> S022-E007-RUT1: HUMAN PRODUCING ACTS / DIVINE RESULT CREDIT.**

Captain zones out. After Naomi completes the attribution, Captain pokes the kindness-credit boil, licks his finger, says **“YOINK!”**, and walks away.

The dead recipient and exact kinsman duty are not explained in this chapter.

## Ruth 2:21–23 — MAIDENS BECOME YOUNG MEN

Ruth reports:

**“HE SAID TO ME, ‘STAY CLOSE TO MY YOUNG MEN UNTIL THEY FINISH ALL MY HARVEST.’”**

The retained direct speech from Boaz said **“stay here close to my maidens.”** His young men were separately ordered not to touch her and later told to release grain. No second stay-close-to-young-men speech is supplied.

New CrackFlix series:

**S168: I SAID STAY WITH MY MAIDENS. SHE REPORTS I SAID YOUNG MEN.**

Naomi replies that it is good for Ruth to go with Boaz's maidens so she is not harmed in another field. Ruth then actually stays close to the maidens through barley and wheat harvests and lives with Naomi.

Once the report and retained direct speech disagree, Captain pokes the speech-carrier boil, licks his finger, says **“YOINK!”**, and walks away. The harvest continues unchanged.

## Character and world-ledger changes

- NOT-RUTH gains gleaning request, Boaz-field arrival, all-day work, foreigner/favor dialogue, meal, about-one-ephah harvest, leftover transfer, Naomi report and two-harvest continued gleaning.
- NOT-BOAZ gains wealthy Elimelech-relative State, field ownership, worker greeting, Ruth inquiry, protection/water/meal/grain orders, reward prayer and kinsman identification by Naomi.
- NOT-NAOMI gains observed grain/food receipt, Boaz identification, LORD-kindness attribution and kinsman statement.
- NOT-OVERSEER gains Ruth identity/request/work report.
- `S167-E002-RUT2`, `S022-E008-RUT2`, and `S168-E001-RUT2` retain the completed contradictions.

## Bullshit pass

Issue `RUT-002 / HARVEST ACCESS CONTROL`. NOT-BOAZ runs **FOREIGNER FAVOR MODE**, the workers enable **ACCIDENTAL BUNDLE LEAKAGE**, and NOT-RUTH's message transcript auto-corrects **MAIDENS** to **YOUNG MEN** before NOT-NAOMI corrects it back. Divine kindness receives the executive credit badge. Foundation unchanged.

## FIR verification

- FILTER: Ruth 2 only; all 23 markers retained in order; Ruth 3 excluded.
- ISOLATE: field route, overseer report, Boaz protection/provision, reward prayer, work/output, Naomi attribution, kinsman identification and speech-report drift.
- RECONSTRUCT: repeated `S167` first-trip-return, repeated `S022` causal-credit and new `S168` maidens/young-men report mismatch.
- VERIFY: exactly three cracks, two SKIPs and three YOINKs; no divine steering, blessing effect, supernatural provision, reward completion, wing form, wage, consent issue, kinsman duty, second Boaz speech or Ruth 3 plan invented; publication held.

## Required comic states

1. Boaz relation/wealth; Ruth asks to glean; Naomi says go; Ruth happens into Boaz field.
2. Boaz/reaper greeting and inquiry; overseer identifies Ruth as having “come back.”
3. Overseer work report; Boaz tells Ruth stay with maidens, protection and water.
4. Ruth asks why favor; Boaz says she came to people not known before; S167 SKIP and first YOINK; reward prayer.
5. Meal and retained leftovers.
6. Boaz commands sheaf access/no reproach/pulled grain; Ruth gleans and beats one ephah.
7. Ruth returns home with barley and leftovers; Naomi asks/name supplied.
8. Naomi attributes kindness to LORD and identifies kinsman; S022 SKIP and second YOINK.
9. Ruth reports “young men” against direct “maidens”; S168 and third YOINK.
10. Naomi says maidens; Ruth stays with maidens through both harvests and lives with Naomi.
11. Held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; exact source identities remain in evidence.
- Every living human and any faced grain is Joe-faced. NOT-THE-LORD remains unrendered; divine wings are not rendered as anatomy.
- Two SKIPs point exactly to `S167-E001-RUT1` and `S022-E007-RUT1`. New `S168` has no SKIP. Exactly three boilless, causally-null Captain occurrences after each contradiction completes.
- Preserve direct-speech/report distinction. Do not silently alter Boaz's “maidens” or Ruth's “young men.”
- Do not invent divine steering, blessing effects, reward completion, supernatural grain, wages, harassment acts, romantic motive, kinsman obligation, dead-person recipient or Ruth 3 content.
- Publication held. `CHB-RUT-003` excluded.

*shrug*

OK.
