# CRACKHEAD JUDGES 14

## Title page

**NOT-SAMSON: LION. BEES. HONEY. RIDDLE. “TELL US.” “YOU CALLED US TO IMPOVERISH US.” “YOU HATE ME.”**

Source parent: Judges chapter 14, verses 1–20, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-014/job.json` and `source.usfm`. Parent: Judges 13.

Display-origin layer: exact source identities remain in evidence. Comic display uses **NOT-SAMSON JOE**, **NOT-MANOAH JOE**, **NOT-MANOAH'S WIFE JOE**, **NOT-TIMNAH WOMAN JOE**, **NOT-PHILISTINE COMPANION JOES**, **NOT-LION JOE**, **NOT-BEE JOES**, and `NOT-` place labels. NOT-THE-LORD and Spirit remain unrendered attributions.

CrackFlix routing: `S012-E004-JDG14` uses `SKIP -> S012-E003-JDG11` because companions accept the wager then assign its impoverishment risk to the wife/couple; new mental `S154-E001-JDG14`, no SKIP, because the wife asserts Samson's private hate/non-love without an observed mental carrier. Exactly two causally-null post-closure YOINKs.

## Causal foundation

```text
NOT-SAMSON SEES TIMNAH WOMAN -> ORDERS PARENTS GET HER
-> PARENTS OBJECT -> NOT-SAMSON REPEATS
-> NARRATOR: PARENTS DON'T KNOW “IT WAS OF LORD”; “HE” SOUGHT OCCASION
-> JOURNEY -> LION ROARS -> SPIRIT ATTRIBUTION -> LION TORN
-> ACT WITHHELD FROM PARENTS
-> RETURN -> BEES/HONEY IN LION BODY
-> NOT-SAMSON EATS/GIVES PARENTS -> ORIGIN WITHHELD
-> FEAST + 30 COMPANIONS
-> MUTUAL 30+30 CLOTHING RIDDLE WAGER ACCEPTED
-> THREE DAYS NO ANSWER
-> DAY SEVEN COMPANIONS THREATEN WIFE/BURN HOUSE
-> “DID YOU CALL US TO IMPOVERISH US?”
-> WIFE: “YOU HATE ME / DON'T LOVE ME”
-> SEVEN-DAY PRESSURE -> NOT-SAMSON TELLS -> WIFE TELLS PEOPLE
-> CITY MEN ANSWER BEFORE SUNSET
-> NOT-SAMSON IDENTIFIES WIFE AS ANSWER PATH
-> SPIRIT ATTRIBUTION -> 30 ASHKELON MEN STRUCK/PLUNDERED
-> CHANGES GIVEN TO ANSWERERS -> ANGER/DEPARTURE
-> WIFE GIVEN TO COMPANION/FRIEND
```

## Judges 14:1–4 — GET HER FOR ME

NOT-SAMSON goes to NOT-TIMNAH, sees a Philistine woman, returns and tells his parents to get her as his wife. They ask whether no woman exists among his brothers' daughters or their people and question taking a wife from uncircumcised Philistines. NOT-SAMSON repeats the demand because she pleases him.

The narrator says his parents did not know it was “of NOT-THE-LORD,” for “he” sought an occasion against the Philistines, who ruled NOT-ISRAEL. The exact pronoun and attribution remain source-bounded; no private motive is assigned to NOT-SAMSON or NOT-THE-LORD beyond what the ambiguous carrier establishes.

## Judges 14:5–9 — LION HONEY SUPPLY CHAIN

NOT-SAMSON travels with his parents toward NOT-TIMNAH. At the vineyards a young NOT-LION JOE roars at him. The narrator says NOT-THE-LORD's Spirit comes mightily on him, and he tears the lion with bare hands as one tears a young goat. He does not tell his parents.

After talking with the woman and later returning to take her, he turns aside to the carcass. A swarm of tiny Joe-faced NOT-BEES and honey occupy the lion's body. He takes and eats honey while walking, gives some to his parents, and they eat. He does not tell them its carcass origin. The production mechanism, elapsed decomposition State and parental food-rule consequences are not invented.

## Judges 14:10–14 — THIRTY COMPANIONS ACCEPT THE RIDDLE

His father goes to the woman. NOT-SAMSON makes the customary young-men's feast. On seeing him, the Philistines bring thirty companions.

NOT-SAMSON proposes a seven-day riddle wager: if they tell/find the answer, he gives thirty linen garments and thirty clothing changes; if they cannot, they give him the same. They answer:

**“TELL US YOUR RIDDLE, THAT WE MAY HEAR IT.”**

He gives the lion-honey riddle: food from the eater, sweetness from the strong. They cannot declare it for three days.

## Judges 14:15 — WE ACCEPTED / YOU IMPOVERISHED US

On the seventh day, the companions tell NOT-SAMSON's wife to entice the answer from her or they will burn her and her father's house. They ask:

**“HAVE YOU CALLED US TO IMPOVERISH US?”**

Their retained act is acceptance of the mutual wager. No act by the wife calling them, accepting for them or forcing their wager entry is supplied. The own-act/result-blame relation repeats `S012`:

**SKIP -> S012-E003-JDG11: I DID IT. YOUR FAULT.**

SKIP points to the contradiction and changes nothing. Captain zones out, then pokes the completed wager-blame boil, licks his finger, says **“YOINK!”**, and walks away. The threat remains active.

## Judges 14:16–18 — MENTAL LOVE DETECTOR

The wife weeps and tells NOT-SAMSON:

**“YOU JUST HATE ME AND DON'T LOVE ME. YOU TOLD MY PEOPLE A RIDDLE AND HAVEN'T TOLD ME.”**

His observable act is withholding the answer; neither he nor another carrier states his hate or non-love. Her asserted private State exceeds the evidence boundary and creates mental crack at her model. Captain's eyes bulge at **MENTAL CRACK**, then he pokes the boil, licks his finger, says **“YOINK!”**, and walks away.

NOT-SAMSON says he has not told even his parents and asks why he should tell her. She weeps during the seven-day feast and presses him severely. On day seven he tells her; she tells her people. Before sunset the city men answer honey/lion. NOT-SAMSON says they found it by “plowing with my heifer,” explicitly identifying the wife as their answer path. The wager requires an answer within seven days and does not state an independent-solve or no-assistance rule, so no cheating contradiction is invented.

## Judges 14:19–20 — THIRTY GARMENTS FROM THIRTY OTHER MEN

The narrator says NOT-THE-LORD's Spirit comes mightily on NOT-SAMSON. He goes to NOT-ASHKELON, strikes thirty men, takes their plunder, and gives clothing changes to the riddle answerers. His anger burns and he returns to his father's house. The source does not enumerate a separate linen-garment delivery; absence from this sentence is not promoted to nonpayment.

NOT-SAMSON's wife is given to his companion who had been his friend. No consent, divorce procedure, transfer authority or future response is invented.

## Character and world-ledger changes

- NOT-SAMSON gains marriage selection, lion act, honey secrecy, feast/riddle wager, wife disclosure, Ashkelon strike/payment and angry departure.
- NOT-TIMNAH WOMAN gains marriage/feast, threat, mental claim, answer extraction/disclosure and transfer to companion.
- Thirty companions gain wager acceptance, failed first three days, coercive threat, leaked answer and clothing receipt.
- `S012-E004-JDG14` repeats own act followed by blame. `S154-E001-JDG14` is mental crack located in the wife's unsupported model of NOT-SAMSON's mind.

## Bullshit pass

Issue `JDG-014 / CORPSE HONEY COMPLIANCE UNKNOWN`. NOT-LION runs **EATER-TO-FOOD CONVERSION**, the companions install **VOLUNTARY WAGER IMPOVERISHMENT PROTECTION**, and NOT-SAMSON sources **30 THIRD-PARTY GARMENT DONORS**. Foundation unchanged.

## FIR verification

- FILTER: Judges 14 only; all 20 markers retained in order.
- ISOLATE: wife selection, hidden occasion attribution, lion/honey acts, wager, threat, disclosure, answer, payment and wife transfer.
- RECONSTRUCT: companion blame joins existing S012 with SKIP; hate/non-love is new mental S154; wager leak does not violate an unstated independent-solve rule.
- VERIFY: exactly two cracks, one SKIP and two YOINKs; no hidden motive, honey mechanism, food consequence, payment omission or transfer procedure invented; publication held.

## Required comic states

1. NOT-SAMSON sees woman, parent objection and repeated get-her demand; hidden narrator attribution retained separately.
2. NOT-LION encounter, Spirit attribution and bare-hand tearing; parents uninformed.
3. Return to Joe-faced bees/honey in Joe-faced lion carcass; eating/sharing/origin withholding.
4. Feast, thirty companions and accepted mutual clothing wager.
5. Riddle and three-day no-answer State.
6. Day-seven threat plus “called us to impoverish”; `SKIP -> S012-E003-JDG11`; first YOINK.
7. Wife's hate/non-love assertion; mental crack and second YOINK.
8. Seven-day pressure, answer disclosure and city answer; NOT-SAMSON identifies disclosure path.
9. Ashkelon strike/plunder/clothing payment, anger/departure and wife-to-companion transfer.
10. Held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; exact names remain in citations and machine ledgers.
- Every living human, lion and bee is Joe-faced; lion carcass retains Joe face. NOT-THE-LORD and Spirit remain unrendered.
- Exactly one SKIP pointing to `S012-E003-JDG11`. Exactly two boilless, causally-null Captain occurrences after their respective contradictions complete: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent the ambiguous “he” referent, motives, honey-generation mechanism, parental food consequences, independent-solve wager rule, missing payment, consent or wife-transfer procedure.
- Publication held. `CHB-JDG-015` excluded.

*shrug*

OK.
