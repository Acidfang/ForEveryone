# CRACKHEAD JUDGES 21

## Title page

**NOT-ISRAEL: “WHY DID THE LORD MAKE A BREACH?” WE DESTROYED IT. DESTROY ANOTHER TOWN TO FIX IT. “DON'T GIVE WIVES.” TAKE THEM.**

Source parent: Judges chapter 21, verses 1–25, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-021/job.json` and `source.usfm`. Parent: Judges 20.

Display-origin layer: exact source identities remain in evidence. Comic display uses **NOT-ISRAEL JOES**, **NOT-BENJAMIN JOES**, **NOT-JABESH-GILEAD JOES**, **NOT-SHILOH-DAUGHTER JOES**, and **NOT-ELDER JOES**. Every living person is Joe-faced. NOT-THE-LORD remains unrendered.

CrackFlix routing: causal-credit `S022-E006-JDG21` uses `SKIP -> S022-E005-JDG16`; collective-liability `S127-E006-JDG21` uses `SKIP -> S127-E005-JDG20`; new replacement-destruction `S164-E001-JDG21` and new give/take loophole `S165-E001-JDG21` have no SKIP. Exactly four causally-null post-closure YOINKs.

## Causal foundation

```text
ISRAEL SWEARS NOT TO GIVE DAUGHTERS TO BENJAMIN
-> ISRAEL WEEPS: WHY HAS LORD LEFT ONE TRIBE LACKING?
-> PRIOR RETAINED ISRAEL ACTS DESTROYED BENJAMIN CITIES/PEOPLE
-> ISRAEL REMEMBERS ABSENT-ASSEMBLY DEATH OATH
-> JABESH-GILEAD IDENTIFIED ABSENT
-> 12,000 ORDERED TO STRIKE ALL INHABITANTS
-> ORDER DESTROYS MALES + WOMEN WHO HAVE KNOWN MEN
-> 400 VIRGINS RETAINED / BROUGHT TO SHILOH
-> PEACE PROCLAIMED TO 600 BENJAMIN SURVIVORS
-> 400 WOMEN GIVEN / NOT ENOUGH
-> PEOPLE GRIEVE / ATTRIBUTE BREACH TO LORD
-> ELDERS REQUIRE BENJAMIN INHERITANCE
-> OATH STILL FORBIDS GIVING ISRAEL DAUGHTERS
-> BENJAMIN TOLD TO AMBUSH SHILOH DANCERS
-> EACH MAN CATCHES/CARRIES OFF A WIFE
-> ELDERS PLAN: FATHERS DID NOT GIVE, SO NOT GUILTY
-> BENJAMIN REBUILDS / ISRAEL DEPARTS
-> NO KING / EVERYONE RIGHT IN OWN EYES
```

## Judges 21:1–4 — WHO MADE THE BREACH?

Israel had sworn at NOT-MIZPAH that none would give a daughter to Benjamin as wife. The people then sit before God, weep severely and ask NOT-THE-LORD why this happened so one tribe is lacking.

Judges 20 retains Israel's own city-wide destruction, livestock killing and burning after Benjamin's defeat. The source supplies no intervening LORD act that destroys the tribe. This repeats causal-credit substitution:

**SKIP -> S022-E005-JDG16: HUMAN PRODUCING ACTS / DIVINE RESULT CREDIT.**

Captain zones out while the people build an altar and offer offerings. After the attribution completes, Captain pokes the causal-credit boil, licks his finger, says **“YOINK!”**, and walks away.

The offerings do not establish a divine response, approval or repair instruction.

## Judges 21:5–12 — ABSENT PERSON MUST DIE / DESTROY THEIR COMMUNITY

Israel recalls a great oath: whoever did not come to the assembly at Mizpah must be put to death. A count finds no inhabitants of NOT-JABESH-GILEAD present.

The congregation sends 12,000 valiant men with an order to strike the inhabitants, including women and little ones, then specifies destruction of every male and every woman who has lain with a man. The initiating oath addresses the person who did not attend. The executed command allocates death across a community, including children, without an individual attendance test. This repeats collective liability:

**SKIP -> S127-E005-JDG20: ADDRESSED PERSON / WHOLE POPULATION PAYS.**

After the expanded order and execution complete, Captain pokes the collective boil, licks his finger, says **“YOINK!”**, and walks away.

Four hundred young virgins are found and carried to NOT-SHILOH. The source supplies no participation, consent, parent survival, individual selection procedure or journey speech for them.

## Judges 21:13–18 — DESTROY ANOTHER COMMUNITY TO REPAIR THE FIRST

The congregation proclaims peace to the 600 Benjamin survivors at NOT-RIMMON. Benjamin returns. Israel gives them the 400 women saved from Jabesh-Gilead, but there are not enough.

The people grieve because the LORD “had made a breach,” while their own retained acts remain the producing chain. The elders ask how to provide wives because Benjamin's women are destroyed, and insist that the escaped men retain an inheritance.

The selected repair for one tribe damaged by Israel is to destroy another Israelite community and transfer selected survivors. New CrackFlix series:

**S164: WE GRIEVE THE COMMUNITY WE DESTROYED. DESTROY ANOTHER COMMUNITY TO REPAIR IT.**

After the Jabesh destruction, survivor transfer and shortage complete this relation, Captain pokes the replacement-destruction boil, licks his finger, says **“YOINK!”**, and walks away. The remaining shortage continues unchanged.

The women are “given,” but no consent or marriage act by them is supplied. Do not convert survival into consent.

## Judges 21:19–23 — DON'T GIVE THEM / LET THEM TAKE THEM

The elders retain the oath: Israel may not give its daughters to Benjamin; anyone who gives is cursed. They identify the annual LORD feast at NOT-SHILOH and command Benjamin to hide in vineyards. When Shiloh's daughters dance, each Benjaminite is to catch a wife and take her away.

The elders pre-plan the answer to complaining fathers and brothers:

**“NEITHER DID YOU GIVE THEM TO THEM; OTHERWISE YOU WOULD NOW BE GUILTY.”**

The rule forbids and punishes giving. The actual authorized process obtains the same wives through taking, while the planners use the absence of a “give” act to avoid guilt. New CrackFlix series:

**S165: DON'T GIVE THEM WIVES. TELL THEM TO TAKE WIVES SO NOBODY GAVE.**

Benjamin does so, taking and carrying off women according to its number. No consent, prior agreement, complaint outcome or exact remaining count is supplied. Once the instructed taking and planned no-give defense execute, Captain pokes the loophole boil, licks his finger, says **“YOINK!”**, and walks away.

## Judges 21:23–25 — REBUILD / OWN EYES

Benjamin returns to its inheritance, builds cities and lives in them. Israel departs by tribe and family to each inheritance.

The book closes:

**NO KING IN ISRAEL. EVERYONE DID WHAT WAS RIGHT IN HIS OWN EYES.**

This is narrator classification, not a supplied motive for every prior act and not a claim that every person performed the same conduct.

## Character and world-ledger changes

- NOT-ISRAEL gains no-daughter oath, breach lament, absentee oath enforcement, Jabesh destruction order, survivor transfer, Shiloh abduction plan and departure.
- NOT-BENJAMIN gains peace, return, 400 transferred women, remaining shortage, vineyard ambush/abduction, city rebuilding and residence.
- NOT-JABESH-GILEAD gains nonattendance count, community destruction and 400 surviving young women transported to Shiloh.
- NOT-SHILOH-DAUGHTERS gain feast dancing, ambush, capture and carriage to Benjamin; consent remains unresolved.
- `S022-E006-JDG21`, `S127-E006-JDG21`, `S164-E001-JDG21`, and `S165-E001-JDG21` retain the four completed contradictions.

## Bullshit pass

Issue `JDG-021 / OATH COMPLIANCE DEPARTMENT`. The **TRIBE REPAIR TEAM** fixes one destroyed branch by deleting another branch, then passes the **NO-GIVE CERTIFICATION** because the wives were captured through the side entrance. The final compliance stamp reads **EVERYONE DID WHAT PASSED THEIR OWN EYEBALL AUDIT**. Foundation unchanged.

## FIR verification

- FILTER: Judges 21 only; all 25 markers retained in order; Ruth 1 excluded.
- ISOLATE: oath, lament/attribution, absentee-oath enforcement, Jabesh destruction, 400-woman transfer, remaining shortage, Shiloh abduction instruction/execution and book closure.
- RECONSTRUCT: repeated `S022` causal-credit and `S127` collective-liability; new `S164` replacement destruction and `S165` give/take loophole.
- VERIFY: exactly four cracks, two SKIPs and four YOINKs; no divine response, individual attendance, women consent, marriage ceremony, survivor-parent relation, complaint outcome, exact remaining count or universal motive invented; publication held.

## Required comic states

1. No-daughter oath; severe weeping and “why has this happened?”
2. Retained Israel destruction parent versus LORD attribution; S022 SKIP and first YOINK; altar/offerings continue.
3. Absent-assembly death oath and Jabesh absence count.
4. Non-graphic whole-community command/execution versus addressed absentee; S127 SKIP and second YOINK.
5. Four hundred survivors transported; peace to 600 Benjamin survivors; transfer and shortage.
6. Grief/breach speech and destroy-another-community repair; S164 and third YOINK.
7. No-give oath restated; feast location and vineyard instruction.
8. Dance, catch/carry-off instruction, planned “you didn't give” defense.
9. Abduction executes; S165 and fourth YOINK.
10. Benjamin rebuilds, Israel disperses, no-king/own-eyes book close.
11. Held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; exact source identities remain in evidence.
- Every living human is Joe-faced. NOT-THE-LORD stays unrendered; altar/offerings are objects.
- Keep killings and abductions non-graphic. Preserve actors, orders, missing consent, transfers and causal order without explicit violence.
- Two SKIPs point exactly to `S022-E005-JDG16` and `S127-E005-JDG20`. New `S164` and `S165` have no SKIP. Exactly four boilless, causally-null Captain occurrences after each contradiction completes.
- Do not invent divine response/approval, personal motive, individual attendance, Jabesh guilt, women's consent, marriage rites, fathers/brothers survival, complaint execution, remaining wife count or Ruth content.
- Publication held. `CHB-RUT-001` excluded.

*shrug*

OK.
