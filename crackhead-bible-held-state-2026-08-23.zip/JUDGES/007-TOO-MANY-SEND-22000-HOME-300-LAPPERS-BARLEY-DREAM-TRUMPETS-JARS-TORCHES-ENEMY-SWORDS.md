# CRACKHEAD JUDGES 7

## Title page

**TOO MANY. SEND 22,000 HOME. KEEP 300 LAPPERS. BARLEY DREAM. TRUMPETS, JARS, TORCHES, ENEMY SWORDS.**

Source parent: Judges chapter 7, verses 1–25, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-007/job.json` and `source.usfm`. Parent: Judges 6.

CrackFlix routing: `S070-E015-JDG7`, with `SKIP -> S070-E014-JDG4`. The three pre-battle delivery statements are one causal occurrence, not three episodes.

## Causal foundation

```text
ARMY AT HAROD / MIDIAN BY MOREH
-> TOO MANY LEST “MY OWN HAND SAVED ME”
-> 22,000 RETURN / 10,000 REMAIN
-> WATER TEST -> 300 HAND-TO-MOUTH LAPPERS / REST KNEEL
-> 300 RETAINED / OTHERS SENT HOME
-> LORD: CAMP ALREADY DELIVERED
-> OPTIONAL IF-AFRAID PURAH ROUTE
-> DREAM + INTERPRETATION HEARD
-> GIDEON: CAMP ALREADY DELIVERED
-> 3 COMPANIES / TRUMPETS / JARS / TORCHES
-> BLOW / BREAK / SHOUT -> 300 STAND / CAMP RUNS
-> ENEMY SWORDS AGAINST FELLOWS -> PURSUIT / OREB + ZEEB KILLED
```

## Judges 7:1–8 — TOO MANY PEOPLE

Gideon/Jerubbaal and his people camp beside Harod; Midian camps north by Moreh. The LORD says the people are too many to give Midian into their hand, lest Israel brag that its own hand saved it. The fearful and trembling may return: 22,000 return and 10,000 remain.

The LORD says there are still too many and directs a water test. The source separates hand-to-mouth lappers from those kneeling to drink. The first group numbers 300. The LORD selects the 300 and sends the rest home. Food and trumpets are taken; the 300 remain.

No alertness, fitness, personality, dog identity or selection psychology is supplied. The dog is a comparison, not an observed dog occurrence.

## Judges 7:9–15 — THE CAMP HAS ALREADY BEEN DELIVERED

The LORD tells Gideon to go down because the camp **has been delivered**. A conditional route follows: if Gideon is afraid, he may take Purah, hear the camp's speech, and afterward his hands will be strengthened. Gideon goes with Purah. That act does not prove the condition, so fear is not inferred.

A man tells his fellow a dream: a barley cake tumbles into Midian's camp and flattens a tent. This remains visibly framed as reported dream imagery, not a physical attack. His fellow interprets it as Gideon's sword and says God **has delivered** Midian. Gideon hears, worships, returns, and says the LORD **has delivered** the army. Dream, interpretation and strengthening mechanisms remain unresolved.

## Judges 7:16–22 — THE EXECUTION AFTER THE COMPLETION

Gideon divides the 300 into three companies and gives each a trumpet, empty pitcher and torch inside it. At the middle watch they reach the camp edge, blow trumpets and break pitchers. Torches are held left, trumpets right, and they shout: **“THE SWORD OF THE LORD AND OF GIDEON!”**

The 300 stand. The army runs and flees. The narrator attributes every enemy sword being set against a fellow and the army to the LORD.

```text
CLAIMED: CAMP HAS BEEN DELIVERED
STILL REQUIRED: LISTEN / RETURN / DIVIDE / EQUIP / APPROACH / BLOW / BREAK / SHOUT / FLIGHT
LATER OBSERVED: PROCESS EXECUTES AND ARMY FLEES
```

CrackFlix displays **SKIP -> S070-E014-JDG4**. SKIP points to the retained contradiction and omits the repeated explanation; it causes nothing. After flight completes, permanently boilless Captain pokes the addressed boil, licks his finger, says **“YOINK!”**, and walks away without looking back. Everyone else continues.

No unmentioned Israelite sword, acoustic mechanism, torch mechanism or divine body is invented.

## Judges 7:23–25 — PURSUIT, WATERS, OREB AND ZEEB

Naphtali, Asher and Manasseh pursue. Gideon summons Ephraim to take the waters through Beth Barah and the Jordan; they do. Ephraim captures Oreb and Zeeb, kills them at Oreb's rock and Zeeb's winepress, pursues Midian, and brings their heads to Gideon beyond Jordan. Violence and the transported heads remain source States and are rendered non-graphically.

## Character and world-ledger changes

- Gideon/Jerubbaal gains army-reduction, Purah-scouting, heard-dream, deployment and battle/pursuit Moments.
- Purah, the 300, returned groups, dream speaker/interpreter, coalition, pursuing tribes, Ephraim, Oreb and Zeeb gain observed relational edges.
- `SCRIPTURE-GOD-JDG7` retains direct LORD speech and narrator attribution without divine form.
- `S070-E015-JDG7` is the only crack. Captain remains boilless, causally useless and unaware of the mechanism.

## Bullshit pass

Issue `JDG-007 / ARMY DOWNSIZER PRO`. Harod runs **22,000-CLICK RETURN**, the water station ships **HAND-TO-MOUTH SELECTOR 300**, the enemy dream airs on **BARLEY CAKE HOME DEMOLITION**, and the army receives the **LEFT TORCH / RIGHT TRUMPET / ZERO FREE HANDS BUNDLE**. Foundation unchanged.

## FIR verification

- FILTER: Judges chapter 7 only; all 25 markers retained in order.
- ISOLATE: army reduction, water selection, conditional Purah route, attributed dream/interpretation, three-company act, flight and pursuit.
- RECONSTRUCT: three pre-battle delivery statements are one occurrence; later execution closes it without erasing the earlier mismatch.
- VERIFY: one repeated crack, exact `SKIP -> S070-E014-JDG4`, one post-closure YOINK, no inferred fear/test psychology, no divine form, publication held.

## Required comic states

1. Harod/Moreh camps and too-many explanation.
2. 22,000 return; 10,000 remain.
3. Water test; 300 selected; others sent home.
4. Already-delivered speech and conditional Purah route.
5. Attributed barley-cake dream and interpretation.
6. Gideon repeats delivered State and equips three companies.
7. Blow/break/torch/shout execution.
8. Enemy swords/flight; `SKIP -> S070-E014-JDG4`; one post-closure `YOINK!`.
9. Pursuit, waters and non-graphic Oreb/Zeeb closure.
10. Held lineage page.

## Production boundary

- Every depicted living human, camel or actual organism is Joe-faced. The comparison dog need not be instantiated.
- Never render God/LORD as face, form, body, silhouette or anatomy.
- Dream imagery stays visibly inside the attributed dream.
- Captain is permanently boilless. Exactly one causally-null post-closure occurrence: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent Gideon's fear, water-test psychology, mechanisms, unmentioned weapons, motives or graphic violence.
- Publication held. `CHB-JDG-008` excluded.

*shrug*

OK.
