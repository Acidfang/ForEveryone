# CRACKHEAD JUDGES 3

## Title page

**TEST NATIONS. OTHNIEL. EHUD'S SECRET MESSAGE. LOCKED-DOOR TOILET THEORY. SHAMGAR'S OX GOAD.**

Source parent: Judges chapter 3, verses 1–31, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JDG-003/job.json` and `source.usfm`.

Parent manuscript: `JUDGES/002-MESSENGER-SAYS-YOU-DIDNT-LISTEN-WEEP-SACRIFICE-JOSHUA-DIES-AGAIN-BUT-NOT-AGAIN-JUDGE-CYCLE-INSTALLED.md`.

CrackFlix routing:

- new `S137-E001-JDG3`, no SKIP: promised secret message/message from God / concealed sword thrust with no spoken message supplied;
- new mental `S138-E001-JDG3`, no SKIP: locked door means relieving himself / unlocked room contains dead king.

## Causal foundation

```text
NATIONS LEFT -> TEST + TEACH WAR
-> ISRAEL LIVES AMONG / INTERMARRIES / SERVES GODS

EVIL -> SOLD TO CUSHAN 8 YEARS
-> CRY -> OTHNIEL RAISED -> SPIRIT / JUDGE / WAR / PREVAIL
-> REST 40 -> OTHNIEL DIES

EVIL AGAIN -> EGLON STRENGTHENED
-> MOAB + AMMON + AMALEK -> PALM CITY -> SERVICE 18 YEARS
-> CRY -> EHUD RAISED
-> TRIBUTE + HIDDEN TWO-EDGED SWORD
-> SECRET MESSAGE -> ROOM CLEARED
-> MESSAGE FROM GOD -> KING STANDS
-> SWORD THRUST / DOORS LOCKED / ESCAPE
-> SERVANTS ASSUME TOILET / WAIT / UNLOCK / FIND DEAD
-> TRUMPET / FORDS / ABOUT 10,000 / MOAB SUBDUED
-> REST 80

SHAMGAR -> 600 PHILISTINES WITH OX GOAD -> SAVES ISRAEL
```

## Judges 3:1–7 — THE TEST SET AND THE FAILED TEST STATE

The narrator names the nations left to test Israel and teach war to generations
that had not known Canaan's wars: five Philistine lords, Canaanites, Sidonians
and Lebanon Hivites from Baal Hermon to Hamath's entrance. The same nations
test whether Israel listens to Moses-delivered commandments.

Israel lives among six named people classes, intermarriages in both directions,
serves their gods, forgets the LORD and serves Baals and Asheroth. The test,
war-teaching and observed response remain distinct relations; no private reason
for any marriage or service is invented.

## Judges 3:8–11 — OTHNIEL INSTANTIATES THE CYCLE

The narrator attributes Israel's sale to Cushan Rishathaim of Mesopotamia to
the LORD. Israel serves him eight years, cries to the LORD, and the LORD raises
Othniel as savior. The LORD's Spirit comes on Othniel; he judges Israel, goes
to war, receives Cushan into his hand and prevails.

The land rests forty years. Othniel dies. This is the first named execution of
the Judges 2 cycle, not a new version of the generalized model.

## Judges 3:12–18 — EGLON, EIGHTEEN YEARS AND THE CONCEALED SWORD

Israel again does evil. The narrator attributes Eglon's strengthening to the
LORD. Eglon gathers Ammon and Amalek, strikes Israel, possesses the City of
Palms and receives Israelite service for eighteen years.

Israel cries; the LORD raises Ehud, a left-handed Benjamite. Israel sends
tribute through him. Ehud makes a cubit-long two-edged sword and wears it under
his clothing on his right thigh. He delivers tribute to very-fat Eglon, then
sends the tribute carriers away.

## Judges 3:19–23 — THE SECRET MESSAGE

Ehud turns back from the Gilgal stone idols and tells Eglon, “I have a secret
message for you.” Eglon commands silence and clears everyone else. Alone in the
cool upper room, Ehud says, “I have a message from God to you.” Eglon rises.

No verbal message content follows. Ehud draws the concealed sword with his left
hand and thrusts it into Eglon. Handle follows blade, fat closes over it, Ehud
does not withdraw it, and it exits behind. Ehud leaves by the porch and shuts
and locks the upper-room doors.

Promised message and delivered act do not cleanly agree. This is new
`S137-E001-JDG3: SECRET MESSAGE FROM GOD / CONCEALED SWORD IN BODY`.

No SKIP occurs. After the mismatch is completed by the thrust without supplied
speech, Captain Crackhead pokes the Joe-faced boil, sees a crack crystal, licks
his finger, says **“YOINK!”**, and walks away. Ehud's escape proceeds exactly
the same.

## Judges 3:24–26 — LOCKED DOOR, ASSERTED TOILET, OBSERVED DEATH

Eglon's servants arrive and observe locked doors. From that state they say,
“Surely he is relieving himself.” The text supplies no sound, reply, sight or
other evidence for the claim. They wait until ashamed. Eglon does not open.

They take the key, open the doors and observe their lord fallen dead on the
floor. Their asserted living-toilet model exceeds the retained evidence and is
closed by the contrary observation. This is mental crack
`S138-E001-JDG3: LOCKED DOOR / DEFINITELY TOILET / ACTUALLY DEAD`.

No SKIP occurs. Once the servants see the body, Captain performs another
causally useless poke and finger lick, says **“YOINK!”**, and leaves. The delay
still gives Ehud time to pass the idols and escape to Seirah.

## Judges 3:27–30 — FORDS, TEN THOUSAND AND EIGHTY YEARS

Ehud blows a trumpet in Ephraim hill country and leads Israel down. He says the
LORD has delivered the Moabite enemies. Israel follows, takes Jordan's fords
and allows no crossing. They strike about ten thousand strong Moabite men; no
man escapes. Moab is subdued that day and the land rests eighty years.

The delivery claim is followed by a completed stated campaign and result, so
no delivery-before-process crack is added here.

## Judges 3:31 — SHAMGAR'S ONE-VERSE EXECUTION

After Ehud comes Shamgar son of Anath. He strikes six hundred Philistine men
with an ox goad and also saves Israel. The ox, if represented by association
with its goad, is Joe-faced because every living animal is Joe. No battle
duration, force size, ox presence or weapon mechanism is invented.

## Character and world-ledger changes

- the left-nation test and war-teaching functions join Judges 2;
- intermarriage and other-god service are completed, not prospective;
- Othniel's eight-year oppression, rescue, forty-year rest and death instantiate one cycle;
- Ehud's eighteen-year oppression, tribute route, concealment, killing, escape and campaign instantiate another;
- the servants' toilet assertion is mental crack at the servants' evidence boundary;
- `S137-E001-JDG3` and `S138-E001-JDG3` are new and have no SKIP;
- exactly two causally null post-closure YOINKs occur;
- Shamgar's six-hundred/ox-goad rescue is a distinct compact occurrence;
- Captain remains permanently boilless and changes nothing;
- every living human, animal or plant Joe and every face-like non-divine nation-test card, sword, fat fold, locked door, key, toilet theory, trumpet, ford or ox goad is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JUDGES — THREE SAVIORS / ONE VERY PRIVATE MESSAGE`;
- test selector: `LEARN WAR + SEE IF LISTENS / RESULT: MARRIED TEST DATA`;
- sword label: `RIGHT-THIGH LEFT-HAND SECRET MESSAGE ATTACHMENT`;
- upper-room privacy: `EVERYONE OUT / KING STANDING / MESSAGE EXECUTED`;
- servant dashboard: `LOCKED = TOILET / WAIT UNTIL ASHAMED`;
- key result: `MODEL UPDATE: KING DEAD`;
- Shamgar warning: `OX GOAD RATED TO 600 PHILISTINES`;
- CrackFlix: `S137 PREMIERE`; `S138 MENTAL PREMIERE`;
- barcode: `CHB-JDG3-31-2CRACKS-2YOINKS-HELD`.

## FIR verification

- all 31 verse markers are represented in order;
- nation test, war teaching, residence, marriage and god service remain distinct;
- Othniel, Ehud and Shamgar are three separate identity/occurrence paths;
- every oppression/rest duration remains attached to its own cycle;
- Ehud's sword manufacture, concealment, tribute, return, privacy request, words and acts stay ordered;
- no unspoken secret-message content or divine instruction is invented;
- servants' assertion remains their mental model until the dead-body observation;
- delivery at verse 28 is not called contradiction because its campaign/result completes;
- exactly two new contradiction series and two post-closure YOINKs occur;
- no unsupported motive, bodily detail beyond source, divine form or Captain effect is added;
- publication remains held and unpublished.

Continuation required: Judges 4 instantiates Deborah, Barak, Sisera and Jael,
including Barak's conditional participation, Sisera's flight, milk, blanket,
tent peg and death without importing Judges 5's song retelling.
