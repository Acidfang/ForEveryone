# CRACKHEAD JUDGES 5

## Title page

**DEBORAH AND BARAK SING. STARS FIGHT. RIVER SWEEPS. SISERA FALLS DEAD AGAIN BUT NOT AGAIN. MOTHER WAITS FOR PLUNDER.**

Source parent: Judges chapter 5, verses 1–31, ENGWEBP USFM. Prepared evidence:
`.chapter-work/CHB-JDG-005/job.json` and `source.usfm`. Parent: Judges 4.

CrackFlix routing:

- new `S140-E001-JDG5`, no SKIP: retained sleeping peg death / song says Sisera bowed and fell at Jael's feet;
- mental `S138-E002-JDG5`, `SKIP -> S138-E001-JDG3`: delayed chariot means plunder division / Sisera is dead.

## Causal foundation

```text
JUDGES 4 BATTLE + TENT DEATH COMPLETE
-> DEBORAH + BARAK SING THAT DAY
-> PRAISE WILLING LEADERS/PEOPLE
-> DIVINE MARCH + WEATHER IMAGERY
-> OLD UNSAFE ROADS / DEBORAH AROSE
-> TRIBE PARTICIPATION + NONPARTICIPATION INVENTORY
-> KINGS / STARS / KISHON / HORSES BATTLE IMAGERY
-> MEROZ CURSE SPEECH
-> JAEL BLESSED / MILK + BUTTER / PEG + HAMMER
-> SONG DEATH POSTURE DIFFERS FROM RETAINED NARRATIVE
-> SISERA MOTHER WAITS / PLUNDER MODEL
-> DEAD SISERA CANNOT RETURN
-> ENEMY/LOVER WISH -> LAND REST 40 YEARS
```

## Judges 5:1–5 — THE SONG BEGINS

Deborah and Barak sing on that day. They bless the LORD because leaders led and
people offered themselves willingly, address kings and princes, and announce
their song and praise.

They sing to the LORD of a march from Seir/Edom: earth trembles, sky/clouds drop
water, mountains and Sinai quake at the LORD's presence. These are performed
lyrics about an attributed event, not a newly observed divine body or a second
current march. No divine form is rendered.

## Judges 5:6–13 — EMPTY HIGHWAYS TO THE GATES

The song places unoccupied highways and byway travel in Shamgar's and Jael's
days. Rulers cease until Deborah arises as a mother in Israel. New gods are
chosen, war reaches the gates, and the singers ask whether shield or spear was
seen among forty thousand.

Deborah's heart is toward willing governors. Riders of white donkeys, carpet
sitters and walkers are told to speak. At water-drawing places people will
rehearse the LORD's righteous acts; the LORD's people go to the gates. Deborah
is called awake and Barak is told to lead captives. A remnant descends and the
song says the LORD came down against the mighty.

The rhetorical weapon question supplies no counted answer. “Will rehearse” is
future song grammar, not an observed rehearsal.

## Judges 5:14–18 — WHO CAME AND WHO SAT STILL

The song names participants from Ephraim, Benjamin, Machir, Zebulun and
Issachar. Issachar is with Deborah and rushes into the valley at Barak's feet.
Reuben has resolves/searchings of heart but sits among sheepfolds listening to
flocks. Gilead remains beyond Jordan; Dan remains in ships; Asher stays by the
sea and creeks. Zebulun and Naphtali jeopardize their lives on the field.

This is a sung participation inventory. Interior “heart” statements remain the
singers' attributed language; no private motive is invented.

## Judges 5:19–23 — KINGS, STARS, KISHON AND MEROZ

Kings of Canaan fight at Taanach by Megiddo's waters and take no silver
plunder. The song says stars fight Sisera from their courses, Kishon sweeps
them away, and horse hooves stamp. These claims may join the retained campaign
as attributed song details but do not replace Judges 4's narrator chain or
expose their mechanism.

The song attributes a command to the LORD's angel: bitterly curse Meroz because
its inhabitants did not come to help the LORD against the mighty. Messenger
speech stays messenger-carried; no divine form, curse execution or later Meroz
outcome is supplied.

## Judges 5:24–27 — ONE DEATH, TWO POSTURES

The song blesses Jael above women in tents. It says Sisera requested water,
Jael gave milk and brought butter in a lordly dish. It then sings that her hand
took the peg and hammer, struck and pierced Sisera's head and temples.

Judges 4 retained Sisera in deep sleep under cover when the peg passes through
his temples into the ground. The song now says repeatedly that at Jael's feet
he bowed, fell, lay and fell dead. No waking, movement, position change or
alternate staging bridge is supplied.

```text
RETAINED NARRATIVE: DEEP SLEEP / COVERED / PEG THROUGH TEMPLES INTO GROUND
SUNG ACCOUNT: AT HER FEET HE BOWED / FELL / LAY / FELL DEAD
```

After both accounts coexist, permanently boilless Captain pokes the account
boil, licks his finger, says **“YOINK!”**, and walks away without looking back.
The song and retained death remain unchanged.

## Judges 5:28–30 — MOTHER'S PLUNDER MODEL

Sisera's mother looks through the lattice and asks why his chariot and wheels
are delayed. Her wise ladies answer, and she repeats the answer to herself:
surely they are finding and dividing plunder—women for men and dyed embroidered
garments for Sisera.

The retained State already has Sisera dead in Jael's tent and the song earlier
says the Canaanite kings took no silver plunder. The mother/ladies' explanation
is a mental model, not an observed return or plunder division.

**SKIP -> S138-E001-JDG3 — DELAYED BECAUSE BUSY. ACTUALLY DEAD.**

Captain's eyes glaze. Nothing skips. The women continue their answer. Once the
dead-versus-return model is complete, Captain pokes the mental-model boil,
licks his finger, says **“YOINK!”**, and walks away without looking back. He
does not inform them or change anything.

The lyric's “lady, two ladies to every man” remains source speech and is not
endorsed, instantiated or converted into an unobserved assault/plunder event.

## Judges 5:31 — WISH AND FORTY YEARS

The song closes by asking that the LORD's enemies perish and those who love him
be like the strong rising sun. These are wishes, not newly completed universal
outcomes. The narrator then states the land had rest forty years. No rest
measurement mechanism or named endpoint event is supplied.

## Character and world-ledger changes

- Deborah and Barak receive a shared performed-song Moment without merging
  their identities or duplicating Judges 4's campaign.
- Participating and nonparticipating tribes remain singer-attributed classes.
- Sisera's mother and wise ladies receive a mental-model Moment, not knowledge
  of Sisera's observed death.
- `SCRIPTURE-GOD-JDG5` separates song-address, attributed messenger speech and
  closing narrator rest.
- `S140-E001-JDG5` and `S138-E002-JDG5` are the only cracks; Captain remains
  permanently boilless and causally useless.

## Bullshit pass

Issue `JDG-005 / LIVE FROM KISHON`. White donkeys carry **PREMIUM SEATING**,
Reuben runs **HEART SEARCH v2**, Dan's ships display **AWAY STATUS**, the stars
are **SKY ARTILLERY**, and Sisera's mother watches **CHARIOT TRACKING: DELAYED**.
None of this replaces the sung/source boundary.

## FIR verification

- FILTER: Judges chapter 5 only; all 31 verse markers retained in order.
- ISOLATE: performed song, attributed imagery, prior-event pointers and closing
  narrator rest remain different occurrence classes.
- RECONSTRUCT: no second battle/death, no divine form, no invented motives,
  plunder or lyric fulfillment.
- VERIFY: exactly two cracks, one valid SKIP to `S138-E001-JDG3`, two
  post-closure YOINKs, and publication held.

## Required comic states

1. Deborah and Barak begin the song and praise willing participation.
2. Seir/Sinai/weather lyrics shown explicitly as attributed song imagery.
3. Unsafe-road/new-gods/gates/forty-thousand rhetorical sequence.
4. Participation/nonparticipation tribal ledger.
5. Kings/stars/Kishon/horses battle lyrics; Meroz messenger-curse carrier.
6. Jael blessed; water/milk/butter and peg lyrics.
7. Retained sleeping death versus sung feet/bowing death; first `YOINK!`.
8. Mother waits; ladies and mother construct plunder model.
9. Exact `SKIP -> S138-E001-JDG3`; dead Sisera remains absent; second `YOINK!`.
10. Closing enemy/lover wish and narrator's forty-year rest; held lineage page.

## Production boundary

- Every depicted living human, animal or plant is Joe-faced. Face-like
  non-divine objects may also receive Joe's face.
- Never render God/LORD as face, form, body, silhouette or anatomy. Song imagery
  and messenger-carried speech remain visibly attributed.
- Do not replay Judges 4 as a second event; lyric panels are lyric carriers.
- Exactly one `SKIP -> S138-E001-JDG3`; SKIP changes nothing.
- Exactly two permanently boilless, causally-null Captain occurrences after
  closure: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent cosmic mechanism, inner motives, weapon count, curse execution,
  plunder occurrence, Sisera return, or violence beyond source speech.
- Publication held. `CHB-JDG-006` excluded.

*shrug*

OK.
