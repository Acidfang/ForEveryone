# CRACKHEAD JUDGES 18

## Title page

**NOT-DAN: INHERITANCE ALLOTTED. “OUR INHERITANCE HAD NOT FALLEN.” ASK GOD. NO ASK SHOWN. “GOD HAS GIVEN IT.” NOW INVADE. “WE TOOK EVERYTHING. WHAT AILS YOU?”**

Source parent: Judges chapter 18, verses 1–31, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-018/job.json` and `source.usfm`. Parent: Judges 17, with Joshua 19's retained Dan-allotment parent.

Display-origin layer: exact source identities remain in evidence. Comic display uses **NOT-DANITE JOES**, **FIVE NOT-SCOUT JOES**, **NOT-LEVITE JOE**, **NOT-MICAH JOE**, **NOT-LAISH JOES**, **SIX HUNDRED NOT-WARRIOR JOES**, **NOT-JONATHAN JOE**, and the relevant household/family JOES. Every living person and livestock animal is Joe-faced. The engraved image, molten image, ephod and teraphim may carry Joe faces as face-bearing objects without establishing life. NOT-THE-LORD and God remain unrendered.

CrackFlix routing: new allocation-denial `S159-E001-JDG18`; new unperformed-consultation `S160-E001-JDG18`; repeated pre-completion delivery `S070-E016-JDG18` uses `SKIP -> S070-E015-JDG7`; and new take/ask/threat `S161-E001-JDG18`. Exactly four causally-null post-closure YOINKs and one SKIP.

## Causal foundation

```text
NO KING
-> DAN SEEKS INHERITANCE / NARRATOR: INHERITANCE HAD NOT FALLEN
-> RETAINED JOSHUA 19 DAN LOT/BOUNDARY/CITIES/LESHAM-DAN CHAIN
-> FIVE SCOUTS SENT -> LODGE AT NOT-MICAH HOUSE
-> RECOGNIZE LEVITE VOICE / ASK HIS ARRIVAL+ROLE
-> LEVITE REPORTS HIRE/PRIEST STATE
-> SCOUTS REQUEST GOD COUNSEL
-> PRIEST IMMEDIATELY STATES PEACE / WAY BEFORE LORD
-> SCOUTS OBSERVE NOT-LAISH: SAFE/QUIET/SECURE/FAR/NO DEALINGS
-> REPORT VERY GOOD/LARGE/UNSUSPECTING/NO LACK
-> “GOD HAS GIVEN IT”
-> 600 ARMED MEN TRAVEL/CAMP/RETURN TO NOT-MICAH HOUSE
-> FIVE SCOUTS DISCLOSE SHRINE OBJECTS
-> FIVE TAKE OBJECTS WHILE 600 STAND AT GATE
-> PRIEST OBJECTS
-> DANITES OFFER BIGGER FATHER/PRIEST JOB
-> PRIEST GLAD / TAKES OBJECTS / JOINS
-> LITTLE ONES/LIVESTOCK/GOODS FRONT-LOADED
-> NOT-MICAH HOUSEHOLD PURSUES
-> DANITES ASK WHAT AILS HIM
-> NOT-MICAH: YOU TOOK MY GODS+PRIEST / WHAT MORE DO I HAVE
-> DANITES THREATEN HIS/HOUSEHOLD LIVES IF VOICE HEARD
-> NOT-MICAH RETURNS BECAUSE THEY ARE STRONGER
-> DANITES STRIKE QUIET UNSUSPECTING NOT-LAISH / BURN CITY
-> NO DELIVERER -> REBUILD/LIVE/RENAME NOT-DAN
-> IMAGE INSTALLED / NOT-JONATHAN LINE PRIESTS
-> IMAGE REMAINS DURING GOD-HOUSE AT NOT-SHILOH
```

## Judges 18:1 — ALLOTTED / HAD NOT FALLEN

There is no king in NOT-ISRAEL. The Danite tribe seeks an inheritance to live in because, to that day, the narrator says:

**“THEIR INHERITANCE HAD NOT FALLEN TO THEM AMONG THE TRIBES OF ISRAEL.”**

Joshua 19 already retains the seventh lot coming out for Dan, an enumerated border/city allocation, and an explicit NOT-LESHEM capture-and-rename chain. No loss, rescission, second Dan, unperformed-lot classification or chronology bridge is supplied between the completed allotment and the later “had not fallen” State. New CrackFlix series:

**S159: THE INHERITANCE WAS ALLOTTED / THE INHERITANCE HAD NOT FALLEN.**

After the later narrator State completes the mismatch, Captain pokes the allotment-status boil, licks his finger, says **“YOINK!”**, and walks away. The Danites continue searching.

This does not prove that allocation equalled effective occupation. The crack is the categorical fall/allotment status without a supplied distinction; continuing possession difficulty remains separately retained.

## Judges 18:2–4 — FIVE-SCOUT VOICE RECOGNITION

Dan sends five men of valor from NOT-ZORAH and NOT-ESHTAOL to spy and search the land. They lodge at NOT-MICAH's house, recognize the young Levite's voice, approach and ask who brought him, what he does and what he has.

The Levite says NOT-MICAH dealt with him, hired him and made him priest. This retains Judges 17's wage/priest State. The source does not say how the scouts previously knew the voice, so no prior meeting, kinship or identification technology is invented.

## Judges 18:5–6 — ASK GOD / ANSWER WITHOUT AN ASK

The scouts request:

**“PLEASE ASK COUNSEL OF GOD, THAT WE MAY KNOW WHETHER OUR WAY SHALL BE PROSPEROUS.”**

The next observable act is the priest's reply:

**“GO IN PEACE. YOUR WAY IN WHICH YOU GO IS BEFORE THE LORD.”**

No counsel-asking act, divination procedure, God/LORD response, sign or message carrier occurs between request and attributed answer. This is not proof that no hidden process happened; it is proof that the source does not supply one while the priest outputs a LORD-position answer. New CrackFlix series:

**S160: ASK GOD / SKIP THE ASK / RETURN GOD'S ANSWER.**

After the attributed answer is spoken, Captain pokes the missing-consultation boil, licks his finger, says **“YOINK!”**, and leaves. The scouts proceed. “Go in peace” remains ordinary speech and is not redefined as a promise that their later acts will be peaceful.

## Judges 18:7–10 — SECURITY AUDIT SELECTS THE UNSUSPECTING

The five reach NOT-LAISH. They observe people living safely in the Sidonian way, quiet and secure, with no local authority who might shame them, far from Sidonians and with no dealings with anyone else.

Back at NOT-ZORAH/NOT-ESHTAOL, the scouts report the land very good and urge immediate possession. They describe an unsuspecting people, a large land and no lack of anything on earth. They say:

**“GOD HAS GIVEN IT INTO YOUR HAND.”**

At this claimed completed gift State, no Danite force has departed, entered NOT-LAISH, fought, captured, burned, rebuilt, occupied or renamed it. This is the same retained `S070` root:

**SKIP -> S070-E015-JDG7: DELIVERED BEFORE THE EXECUTION PROCESS.**

Captain zones out. The crack remains open through preparation and travel; it closes only when the source later performs the attack/occupation acts that were still necessary after the completed-gift statement. Captain then pokes the delivery-before-acquisition boil, licks his finger, says **“YOINK!”**, and walks away. The city remains captured.

The source explicitly makes quietness, security, distance and lack of dealings observable scouting facts. It does not supply a NOT-LAISH attack, threat, negotiation or Danite self-defense claim. No private Danite motive beyond their spoken possession recommendation is invented.

## Judges 18:11–13 — SIX-HUNDRED-PERSON POSSESSION CLIENT

Six hundred Danite men armed with weapons leave NOT-ZORAH and NOT-ESHTAOL. They camp at NOT-KIRIATH-JEARIM; the site is called NOT-MAHANEH-DAN “to this day.” They continue into Ephraim's hill country and reach NOT-MICAH's house.

Little ones, livestock and goods appear later in the moving group. The source does not state their exact departure point, counts, family mapping or whether they were present at every camp.

## Judges 18:14–21 — HELLO PRIEST / WE ARE TAKING THE OFFICE

The five scouts tell their brothers the houses contain an ephod, teraphim, carved image and molten image and instruct them to consider what to do. They greet the Levite while six hundred armed men stand at the gate.

The five enter and take the engraved/carved image, ephod, teraphim and molten image. The priest asks:

**“WHAT ARE YOU DOING?”**

They order silence, hand on mouth and migration with them. They offer the same father/priest label at a larger scope: priest to a tribe and family rather than one man's house. The priest's heart is glad. He takes the ephod, teraphim and engraved image and joins the people. The molten image is included in the earlier taking but is not named in the priest's later carried subset; its exact carrier remains unresolved.

The group turns away with little ones, livestock and goods positioned in front. The visible armed force at the gate, taking acts and recruitment are retained without inventing consent from NOT-MICAH, a sale, compensation, title transfer or threat spoken before the priest's acceptance.

## Judges 18:22–26 — WE TOOK EVERYTHING / WHAT AILS YOU?

Men from houses near NOT-MICAH gather and overtake Dan. Danites turn and ask NOT-MICAH:

**“WHAT AILS YOU, THAT YOU COME WITH SUCH A COMPANY?”**

NOT-MICAH answers:

**“YOU HAVE TAKEN AWAY MY GODS WHICH I MADE, AND THE PRIEST, AND HAVE GONE AWAY! WHAT MORE DO I HAVE? HOW CAN YOU ASK ME, ‘WHAT AILS YOU?’”**

The Danites then tell him not to let his voice be heard lest angry fellows attack and cause him and his household to lose their lives. NOT-MICAH sees they are too strong, turns and returns home.

The same actors retain their completed object/priest removal, ask the dispossessed owner why he is upset, then threaten death when he states the producing act. New CrackFlix series:

**S161: WE TOOK YOUR STUFF / WHY ARE YOU UPSET? / STOP ANSWERING OR DIE.**

After the threat forces NOT-MICAH's retreat while the taken State remains, Captain pokes the customer-feedback boil, licks his finger, says **“YOINK!”**, and walks away. Nothing is returned.

NOT-MICAH says “gods which I made.” Judges 17 retains that he made ephod/teraphim while his mother and silversmith produced the carved/molten images. The plural phrase does not identify each object, so no false universal maker claim is manufactured.

## Judges 18:27–29 — PEACEFUL TARGET ACQUISITION

Dan takes what NOT-MICAH made and the priest he had, reaches the quiet unsuspecting NOT-LAISH people, strikes them with the sword and burns the city. No deliverer comes because the city is far from NOT-SIDON and has no dealings with others. Dan rebuilds, lives there and renames the city NOT-DAN after ancestral Dan; the prior name was NOT-LAISH.

These acts complete the execution path that remained after “God has given it.” The narrator supplies no God/LORD battle act, no casualty count, no survivor State and no negotiation. The city rebuild does not restore its prior people or identity.

## Judges 18:30–31 — IMAGE AND PRIEST LEDGER

Dan installs the engraved image. The source introduces NOT-JONATHAN, son of NOT-GERSHOM, son of NOT-MOSES, and his sons as Danite priests until the land's captivity. It then says NOT-MICAH's engraved image remains all the time God's house is at NOT-SHILOH.

The source does not explicitly say “the previously unnamed Levite was Jonathan” inside an identity-transition act. Narrative placement makes that relation a candidate, not a forced merge. NOT-JONATHAN and the unnamed NOT-LEVITE retain separate addresses until an exact identity carrier joins them.

The engraved image remains installed under the `S157` prohibited-dedication history, but this chapter adds no new LORD-dedication claim and therefore does not manufacture a second `S157` episode. Continued object State is retained without duplicate crack.

## Character and world-ledger changes

- NOT-DAN gains an inheritance-search claim, five-scout reconnaissance, six-hundred-warrior movement, Micah-object/priest taking, NOT-LAISH destruction/rebuild/rename and long-term image/priest installation.
- NOT-LEVITE gains scout consultation answer, object-taking objection, tribe-priest offer, glad acceptance and migration; possible identity with NOT-JONATHAN remains unresolved.
- NOT-MICAH loses shrine objects and priest under threat and returns home alive; household later State remains unresolved.
- NOT-LAISH changes from quiet/secure/unsuspecting city to struck/burned/rebuilt/renamed NOT-DAN; individual survivor count remains unresolved.
- `S159-E001-JDG18`, `S160-E001-JDG18`, `S070-E016-JDG18`, and `S161-E001-JDG18` retain the four completed frictions.

## Bullshit pass

Issue `JDG-018 / HOSTILE RELIGIOUS INFRASTRUCTURE MIGRATION`. Five NOT-SCOUT JOES locate **UNSUSPECTING LAND WITH ZERO SUPPORT CONTRACT**, six hundred armed migration technicians acquire **PRIEST PLUS IDOL STACK**, and customer service asks the previous owner **WHAT AILS YOU** before deploying **VOICE-BASED HOUSEHOLD TERMINATION TERMS**. Foundation unchanged.

## FIR verification

- FILTER: Judges 18 only, with Judges 17 household parents and Joshua 19 Dan-allotment parent; all 31 markers retained in order.
- ISOLATE: inheritance mismatch, scout/consultation chain, Laish report, pre-completion gift claim, armed migration, shrine/priest taking, confrontation/threat, conquest/rename and priest/image close.
- RECONSTRUCT: three new roots and one repeated `S070`; continued `S157` object State is not duplicated.
- VERIFY: exactly four cracks, one SKIP and four YOINKs; no voice-history, counsel act, God response, peace promise, Laish motive/threat, lawful title transfer, maker universal, Jonathan identity merge or casualty count invented; publication held.

## Required comic states

1. Joshua 19 allotment parent beside Judges 18 “had not fallen”; first YOINK.
2. Five scouts sent, lodge, recognize voice and obtain Levite job report.
3. Ask-God request, immediate LORD-position answer with no consultation carrier; second YOINK.
4. Quiet/secure/far/no-dealings NOT-LAISH observation and very-good/unsuspecting report.
5. “God has given it” with S070 SKIP; six hundred arm and travel.
6. Shrine-object disclosure, six hundred at gate, five take objects, priest objects.
7. Bigger father/priest offer, glad heart, priest takes objects and joins.
8. NOT-MICAH pursuit; Dan asks what ails; taking answer; death threat; retreat; fourth YOINK.
9. NOT-LAISH sword/fire, no deliverer, rebuild/live/rename; S070 third YOINK after execution closes.
10. Engraved-image installation, NOT-JONATHAN lineage and NOT-SHILOH duration.
11. Held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; source identities remain exact in evidence and machine ledgers.
- Every living human and livestock animal is Joe-faced. Face-bearing shrine objects may carry Joe's face without adding life or agency. NOT-THE-LORD/God remain unrendered.
- One SKIP points exactly to `S070-E015-JDG7`. Exactly four boilless, causally-null Captain occurrences after the addressed contradictions complete: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent voice-recognition history, consultation act, divine reply, peace guarantee, Laish aggression, ownership law, compensation, molten-image carrier, universal Micah manufacture, Jonathan/unnamed-Levite identity equality, casualties or survivor count.
- Publication held. `CHB-JDG-019` excluded.

*shrug*

OK.
