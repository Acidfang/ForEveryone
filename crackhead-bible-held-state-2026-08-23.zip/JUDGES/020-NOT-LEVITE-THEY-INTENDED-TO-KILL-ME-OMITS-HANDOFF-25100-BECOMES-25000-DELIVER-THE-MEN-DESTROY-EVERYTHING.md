# CRACKHEAD JUDGES 20

## Title page

**NOT-LEVITE: “THEY INTENDED TO KILL ME.” OMITS HIS HANDOFF. 25,100 BECOMES 25,000. “DELIVER THE MEN.” DESTROYS CITIES, PEOPLE AND LIVESTOCK.**

Source parent: Judges chapter 20, verses 1–48, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-020/job.json` and `source.usfm`. Parent: Judges 19.

Display-origin layer: exact source identities remain in evidence. Comic display uses **NOT-LEVITE JOE**, **NOT-CONCUBINE JOE**, **NOT-ISRAEL JOES**, **NOT-BENJAMIN JOES**, **NOT-GIBEAH JOES**, **NOT-PHINEHAS JOE**, and Joe-faced livestock. NOT-THE-LORD remains unrendered.

CrackFlix routing: mental `S154-E004-JDG20` uses `SKIP -> S154-E003-JDG16`; new count mismatch `S163-E001-JDG20` has no SKIP; collective-liability `S127-E005-JDG20` uses `SKIP -> S127-E004-JDG16`. Exactly three causally-null post-closure YOINKs.

## Causal foundation

```text
ALL ISRAEL ASSEMBLES / FOUR HUNDRED THOUSAND
-> BENJAMIN HEARS OF ASSEMBLY
-> ISRAEL ASKS HOW WICKEDNESS HAPPENED
-> LEVITE REPORTS LODGING / SURROUNDING / INTENDED KILLING / ABUSE / DEATH
-> REPORT OMITS HIS RETAINED JUDGES 19 HANDOFF
-> HE REPORTS CUTTING / SENDING / ASKS COUNSEL
-> ISRAEL SELECTS ACTION AGAINST GIBEAH
-> REQUESTS BENJAMIN DELIVER SPECIFIC GIBEAH MEN
-> BENJAMIN REFUSES / MUSTERS 26,000 + 700
-> ISRAEL MUSTERS 400,000 BESIDES BENJAMIN
-> FIRST DIVINE ANSWER: JUDAH FIRST
-> FIRST BATTLE: ISRAEL LOSES 22,000
-> SECOND DIVINE ANSWER: GO UP
-> SECOND BATTLE: ISRAEL LOSES 18,000
-> FAST / OFFERINGS / THIRD QUESTION
-> THIRD DIVINE ANSWER: TOMORROW DELIVER BENJAMIN
-> AMBUSH / FEIGNED FLIGHT / CITY SMOKE / TURN
-> 25,100 REPORTED DESTROYED
-> DETAIL REPORTS 18,000 + 5,000 + 2,000 = 25,000
-> 600 ESCAPE FOUR MONTHS
-> ISRAEL STRIKES ENTIRE CITY / LIVESTOCK / ALL FOUND / BURNS CITIES
```

## Judges 20:1–3 — ALL ISRAEL / BENJAMIN HEARS

The congregation assembles as one from NOT-DAN to NOT-BEERSHEBA and NOT-GILEAD. Chiefs of all tribes present with four hundred thousand armed footmen. The source separately says Benjamin hears Israel has gone to NOT-MIZPAH. This creates a membership frontier, not a closed contradiction: the text does not enumerate who attended, when Benjamin heard, or whether any Benjamin representative was present.

Israel asks how the wickedness happened.

## Judges 20:4–7 — THE REPORT IS NOT THE RETAINED EVENT

The Levite identifies the woman as his murdered concubine and reports their arrival at Gibeah. He says the Gibeah men surrounded the house and:

**“THEY INTENDED TO KILL ME.”**

Judges 19 retains the crowd's spoken demand for the male guest for sex, but no spoken killing threat, killing attempt or mind carrier. The Levite's asserted private intent therefore exceeds the retained evidence. Mental CrackFlix occurrence:

**SKIP -> S154-E003-JDG16: CLAIMED PRIVATE INTENT WITHOUT AN OBSERVED MIND CARRIER.**

Captain's eyes glaze. The report continues unchanged. When the unsupported intent assertion completes, Captain pokes the mental boil, licks his finger, says **“YOINK!”**, and walks away.

The Levite says the men abused his concubine and she is dead. The narrator also calls her murdered, so her dead State is now source-retained; exact death timing and mechanism remain unresolved. He says he cut and sent her throughout Israel because “they” committed lewdness and folly, then asks for counsel.

His Judges 19 act of grabbing and handing her to the crowd is absent from this report. That omission is retained as a report/history Difference, not declared a separate contradiction: he does not explicitly claim the report is complete or say he performed no handoff.

## Judges 20:8–17 — DELIVER THE SPECIFIC MEN / TRIBAL WAR

The people remain as one, plan provisions and action against Gibeah, and gather against the city. Israel sends through Benjamin demanding delivery of the specifically addressed wicked Gibeah men for death and removal of evil.

Benjamin refuses to listen, gathers from its cities and goes to battle. The count is 26,000 from the cities plus 700 Gibeah men. Seven hundred selected left-handed slingers are described within the soldiers; the source does not state whether they are additional to or included within the prior 700. Israel besides Benjamin counts 400,000.

## Judges 20:18–25 — TWO ANSWERS / TWO LOSSES

Israel asks God who should go first. NOT-THE-LORD answers:

**“JUDAH FIRST.”**

Benjamin destroys 22,000 Israelites. Israel weeps and asks whether to approach battle again against Benjamin, called brother. NOT-THE-LORD answers:

**“GO UP AGAINST HIM.”**

Benjamin destroys another 18,000 Israelites. Neither first answer promises victory, so the losses are not converted into a failed promise or punishment claim.

## Judges 20:26–34 — THIRD QUESTION / TOMORROW

Israel weeps, fasts and offers burnt and peace offerings. The ark is there and NOT-PHINEHAS stands before it. Israel asks whether to fight again or cease. NOT-THE-LORD says:

**“GO UP; FOR TOMORROW I WILL DELIVER HIM INTO YOUR HAND.”**

Israel sets ambushes. On the third day Benjamin is drawn from the city by a planned flight. About thirty Israelites are struck. The ambushers break out and ten thousand selected Israelites enter the severe battle. No divine visible form or mechanism is supplied.

## Judges 20:35–47 — 25,100 / 25,000

The source attributes Benjamin's defeat to the LORD and says Israel destroys **25,100** Benjaminite sword-bearers that day.

The detailed count then reports:

- 18,000 fall;
- 5,000 are struck on the highways;
- 2,000 are struck near NOT-GIDOM;
- therefore all who fell that day are **25,000**.

The same selected day and population are given totals differing by 100. New CrackFlix series:

**S163: 25,100 PEOPLE / 25,000 PEOPLE.**

No rounding rule or missing subgroup is supplied. Once both totals have been stated, Captain pokes the arithmetic boil, licks his finger, says **“YOINK!”**, and walks away. Six hundred flee to the rock of NOT-RIMMON for four months. Their relation to the initial 26,700 and either casualty total remains unresolved rather than forced into an invented reconciliation.

## Judges 20:48 — DELIVER THOSE MEN / DESTROY EVERYTHING FOUND

The initiating demand addressed specific wicked Gibeah men. After Benjamin refuses and the armies fight, Israel turns on Benjamin and strikes the entire city, livestock and all found, then burns every city found.

The final scope includes persons and animals for whom the source supplies no individual participation in the original offense or refusal. This repeats collective liability:

**SKIP -> S127-E004-JDG16: ADDRESSED WRONG / WHOLE POPULATION PAYS.**

Captain zones out while the action continues. After the city/livestock/all-found expansion completes, he pokes the collective boil, licks his finger, says **“YOINK!”**, and walks away. Nothing changes.

## Character and world-ledger changes

- NOT-LEVITE gains national testimony, unsupported killing-intent assertion, retained omission of his own handoff, cutting/sending admission and counsel request.
- NOT-CONCUBINE gains narrator-retained murdered/dead State; exact death timing and mechanism remain unresolved.
- NOT-ISRAEL gains 400,000 muster, three inquiries, two defeats, third-day ambush/victory, city-wide destruction and burning.
- NOT-BENJAMIN gains refusal, 26,000+700 muster, two victories, third defeat, conflicting casualty totals and 600 survivors.
- `S154-E004-JDG20` retains unsupported private intent.
- `S163-E001-JDG20` retains 25,100 versus 25,000.
- `S127-E005-JDG20` retains named-offender demand versus whole-city/livestock punishment.

## Bullshit pass

Issue `JDG-020 / NATIONAL INCIDENT REPORT PATCH NOTES`. NOT-LEVITE submits **THEY INTENDED TO KILL ME v2.0** with the HANDOFF FIELD hidden, the NOT-ARMY runs **JUDAH FIRST**, **GO UP AGAIN**, and finally **TOMORROW DELIVERY**, and NOT-CASUALTY ACCOUNTING offers both 25,100 and 25,000 under **SAME DAY COMPATIBILITY MODE**. Foundation unchanged.

## FIR verification

- FILTER: Judges 20 only; all 48 markers retained in order; Judges 21 excluded.
- ISOLATE: assembly, Levite report, addressed demand, refusal/musters, three inquiries, two losses, ambush/victory, conflicting totals, survivors and expanded destruction.
- RECONSTRUCT: repeated mental `S154`, new arithmetic `S163`, repeated collective-liability `S127`; report omission retained without manufacturing a completeness claim.
- VERIFY: exactly three cracks, two SKIPs and three YOINKs; no assembly membership, hidden intent, divine promise before verse 28, death timing, casualty reconciliation, individual guilt or divine mechanism invented; publication held.

## Required comic states

1. National assembly, 400,000 count, Benjamin hears; membership frontier visible.
2. Levite report begins; unsupported “intended to kill me,” S154 SKIP and first YOINK.
3. Non-graphic report/dead State/cutting-sending/counsel; retained Judges 19 handoff shown absent from report without narration of motive.
4. Israel plan and specific-men delivery demand; Benjamin refusal and two army counts.
5. First question/“Judah first”/first 22,000 loss.
6. Second question/“go up”/second 18,000 loss.
7. Fast, offerings, ark/Phinehas, third question and tomorrow-delivery answer.
8. Ambush, feigned flight, about thirty, smoke signal and turn.
9. 25,100 statement followed by 18,000+5,000+2,000=25,000; S163 and second YOINK.
10. Six hundred survivors; whole city/livestock/all-found/cities scope, S127 SKIP and third YOINK.
11. Held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; exact source identities remain in evidence.
- Every living human and animal is Joe-faced. NOT-THE-LORD stays unrendered; ark is an object and does not establish a divine face.
- Keep sexual violence, death and warfare non-graphic while retaining actors, speech, counts and causal order.
- Two SKIPs point exactly to `S154-E003-JDG16` and `S127-E004-JDG16`. New `S163` has no SKIP. Exactly three boilless, causally-null Captain occurrences after each addressed contradiction closes: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent Benjamin assembly membership, Levite motive, complete-report claim, killing intent, death timing/mechanism, slinger inclusion, divine authorization beyond exact answers, victory promise before verse 28, casualty reconciliation, individual guilt, divine form/mechanism or Judges 21 consequences.
- Publication held. `CHB-JDG-021` excluded.

*shrug*

OK.
