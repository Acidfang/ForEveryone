# CRACKHEAD JUDGES 10

## Title page

**NOT-TOLA, SON OF PU-AH, SON OF DODO. 23 YEARS. NOT-JAIR: 30 SONS, 30 DONKEYS, 30 CITIES. I WILL SAVE NO MORE. WHATEVER YOU WANT. ONLY SAVE US.**

Source parent: Judges chapter 10, verses 1–18, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-010/job.json` and `source.usfm`. Parent: Judges 9.

Display-origin layer: source names remain exact in evidence. Story displays use **NOT-TOLA JOE**, **NOT-PUAH JOE**, **NOT-DODO JOE**, **NOT-SHAMIR**, **NOT-JAIR JOE**, **NOT-HAVVOTH-JAIR**, **NOT-KAMON**, **NOT-ISRAEL**, **NOT-GILEAD**, **NOT-MIZPAH**, and **NOT-THE-LORD**.

CrackFlix routing: new `S148-E001-JDG10`, no SKIP: Israel says NOT-THE-LORD may do whatever seems good, then immediately requires delivery today.

## Causal foundation

```text
AFTER NOT-ABIMELECH
-> NOT-TOLA ARISES/SAVES -> JUDGES 23 YEARS -> DIES/BURIED NOT-SHAMIR
-> NOT-JAIR ARISES -> JUDGES 22 YEARS
-> 30 SONS / 30 DONKEY COLTS / 30 CITIES
-> DIES/BURIED NOT-KAMON

NOT-ISRAEL SERVES MULTIPLE FOREIGN GOD GROUPS / ABANDONS NOT-THE-LORD
-> NOT-THE-LORD SELLS TO PHILISTINES + AMMON
-> OPPRESSION 18 YEARS EAST OF JORDAN
-> AMMON CROSSES AGAINST JUDAH/BENJAMIN/EPHRAIM
-> GREAT DISTRESS -> CONFESSION/CRY
-> NOT-THE-LORD LISTS PRIOR SAVINGS
-> “I WILL SAVE YOU NO MORE; CRY TO CHOSEN GODS”
-> “DO WHATEVER SEEMS GOOD; ONLY DELIVER US TODAY”
-> FOREIGN GODS REMOVED / NOT-THE-LORD SERVED
-> SOUL-GRIEVED ATTRIBUTION
-> AMMON CAMP NOT-GILEAD / ISRAEL CAMP NOT-MIZPAH
-> WHOEVER BEGINS FIGHT BECOMES HEAD
```

## Judges 10:1–5 — 23, THEN 22, THEN 30/30/30

After NOT-ABIMELECH, NOT-TOLA son of NOT-PUAH son of NOT-DODO, an Issachar man, arises to save NOT-ISRAEL. He lives in NOT-SHAMIR in Ephraim's hill country, judges 23 years, dies and is buried there.

NOT-JAIR of Gilead follows and judges 22 years. His 30 sons ride 30 donkey colts and have 30 cities called NOT-HAVVOTH-JAIR “to this day” in NOT-GILEAD. NOT-JAIR dies and is buried in NOT-KAMON. Each depicted donkey and living human is Joe-faced. The matched thirties are retained inventory, not inferred status or contradiction.

## Judges 10:6–9 — THE FULL OTHER-GODS SUBSCRIPTION

NOT-ISRAEL again does evil in NOT-THE-LORD's sight and serves the Baals, Ashtaroth and gods attributed to Syria, Sidon, Moab, Ammon and the Philistines. They abandon NOT-THE-LORD and do not serve him.

The narrator says NOT-THE-LORD's anger burns and he sells them into Philistine and Ammonite hands. They are troubled/oppressed that year and for 18 years east of Jordan in Amorite Gilead. Ammon crosses Jordan to fight Judah, Benjamin and Ephraim, leaving NOT-ISRAEL greatly distressed. No deity is rendered with a form, and “sold” receives no invented price or transaction carrier.

## Judges 10:10–14 — I WILL SAVE YOU NO MORE

NOT-ISRAEL cries to NOT-THE-LORD and confesses sin: abandoning their God and serving Baals. NOT-THE-LORD replies with a list of attributed prior savings from Egyptians, Amorites, Ammonites, Philistines, Sidonians, Amalekites and Maonites. He says they nevertheless abandoned him and served other gods, therefore:

**“I WILL SAVE YOU NO MORE.”**

He tells them to cry to their chosen gods and let those gods save them during distress. This statement is retained as an open future relation. This chapter contains no completed later delivery, so it does not yet produce a crack and Captain does not attend it.

## Judges 10:15–16 — WHATEVER. ONLY THIS.

NOT-ISRAEL replies:

**“WE HAVE SINNED! DO TO US WHATEVER SEEMS GOOD TO YOU; ONLY DELIVER US, PLEASE, TODAY.”**

The mismatch completes inside the speech:

```text
PERMISSION: DO WHATEVER SEEMS GOOD
IMMEDIATE REQUIREMENT: THE RESULT MUST INCLUDE DELIVERING US TODAY
OBSERVED STATE: “WHATEVER” EXCLUDES OUTCOMES THAT DO NOT DELIVER
```

After both clauses are spoken, Captain pokes the whatever-but-only boil, licks his finger, says **“YOINK!”**, and walks away without looking back. The plea, oppression and coming war remain unchanged.

NOT-ISRAEL removes foreign gods and serves NOT-THE-LORD. The narrator says his soul was grieved for Israel's misery. No internal divine anatomy, mental mechanism or promised future response is rendered.

## Judges 10:17–18 — TWO CAMPS AND A JOB OFFER

Ammon gathers and camps in NOT-GILEAD. NOT-ISRAEL assembles and camps at NOT-MIZPAH. Gilead's people and princes ask who will begin to fight Ammon and state that person will become head over all Gilead's inhabitants. No fighter, battle or installed head occurs in this chapter.

## Character and world-ledger changes

- NOT-TOLA and NOT-JAIR receive complete judge/death/burial Moments; NOT-JAIR's sons, donkeys and cities retain the exact 30/30/30 relation.
- NOT-ISRAEL gains foreign-service, oppression, confession, constrained permission, god-removal and assembly Moments.
- `SCRIPTURE-GOD-JDG10` retains anger/sale, historical-saving speech, no-more-saving speech and soul-grieved attribution without divine form.
- `S148-E001-JDG10` is the only crack. “I will save no more” remains unresolved until an actual later State joins it.

## Bullshit pass

Issue `JDG-010 / DODO LINEAGE VERIFIED`. NOT-JAIR operates **30 SONS / 30 ASSES / 30 CITIES ASSET MATCH**, NOT-ISRAEL installs **EVERY FOREIGN GOD PACK**, and NOT-MIZPAH posts **START FIGHT / BECOME HEAD — APPLICANT PENDING**. Foundation unchanged.

## FIR verification

- FILTER: Judges chapter 10 only; all 18 markers retained in order.
- ISOLATE: two judge summaries, apostasy/oppression, confession/divine reply, removal/service and opposing camps.
- RECONSTRUCT: “whatever/only” closes internally; “save no more” has no completed contrary outcome in this chapter and stays open.
- VERIFY: exactly one new crack, no SKIP, one post-closure YOINK, full `NOT-` display layer, no divine form or invented future, publication held.

## Required comic states

1. NOT-TOLA lineage, save/judge 23 years, death/burial.
2. NOT-JAIR judges 22 years; 30 Joe sons on 30 Joe donkeys with 30 cities; death/burial.
3. NOT-ISRAEL's multi-god service and abandonment.
4. Attributed sale, 18-year oppression and cross-Jordan fighting/distress.
5. Confession and NOT-THE-LORD's prior-saving inventory.
6. “I will save no more / cry to chosen gods,” visibly retained as open.
7. “Whatever seems good / only deliver us today”; one `YOINK!`.
8. Foreign gods removed, NOT-THE-LORD served, soul-grieved attribution.
9. Ammon at NOT-GILEAD, NOT-ISRAEL at NOT-MIZPAH, head-for-first-fighter offer.
10. Held lineage page.

## Production boundary

- Every rendered biblical identity carries `NOT-`; exact source names stay in citations and machine addresses.
- Every living human, donkey, plant or other organism is Joe-faced.
- Never render NOT-THE-LORD, foreign gods or soul as face, body, silhouette or anatomy.
- No SKIP. Exactly one boilless, causally-null Captain occurrence after the constrained-permission speech: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent foreign-god forms, sale price, motives, divine anatomy, future saving, fighter, battle or installed leader.
- Publication held. `CHB-JDG-011` excluded.

*shrug*

OK.
