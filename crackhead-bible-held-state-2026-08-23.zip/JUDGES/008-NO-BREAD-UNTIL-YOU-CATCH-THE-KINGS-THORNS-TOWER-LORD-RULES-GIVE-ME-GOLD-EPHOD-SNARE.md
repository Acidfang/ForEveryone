# CRACKHEAD JUDGES 8

## Title page

**NO BREAD UNTIL YOU CATCH THE KINGS. THORNS. TOWER. THE LORD RULES. GIVE ME THE GOLD. EPHOD SNARE.**

Source parent: Judges chapter 8, verses 1–35, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-008/job.json` and `source.usfm`. Parent: Judges 7.

CrackFlix routing:

- new `S143-E001-JDG8`, no SKIP: faint pursuers need bread to capture two kings / towns require the kings already captured before giving bread;
- new `S144-E001-JDG8`, no SKIP: Gideon says the LORD shall rule / makes an ephod that Israel worships and that becomes a snare.

## Causal foundation

```text
EPHRAIM REBUKES GIDEON -> GIDEON COMPARES THEIR GLEANING TO HIS VINTAGE
-> OREB/ZEEB CREDIT -> ANGER ABATES

300 CROSS JORDAN FAINT YET PURSUING
-> ASK SUCCOTH FOR BREAD
-> SUCCOTH: ARE THE KINGS ALREADY IN YOUR HAND?
-> NO BREAD -> THORN THREAT
-> PENUEL SAME ANSWER -> TOWER THREAT
-> GIDEON STRIKES SECURE CAMP -> CAPTURES ZEBAH/ZALMUNNA
-> RETURNS -> SUCCOTH ELDERS/THORNS -> PENUEL TOWER/MEN
-> TABOR BROTHERS DISCLOSED -> JETHER DOES NOT DRAW SWORD
-> GIDEON KILLS KINGS / TAKES CAMEL CRESCENTS

ISRAEL: YOU SAVED US, RULE DYNASTICALLY
-> GIDEON: I/SON WILL NOT RULE; LORD SHALL RULE
-> REQUESTS PLUNDER EARRINGS -> 1700 SHEKELS + ROYAL/CAMEL ITEMS
-> MAKES EPHOD / PUTS IN OPHRAH
-> ISRAEL WORSHIPS IT / SNARE TO GIDEON + HOUSE
-> MIDIAN SUBDUED / 40 YEARS REST
-> GIDEON HOUSE / 70 SONS / ABIMELECH / DEATH + BURIAL
-> ISRAEL RETURNS TO BAALS / FORGETS LORD / NO KINDNESS TO HOUSE
```

## Judges 8:1–3 — THE GRAPE COMPARISON

Ephraim sharply rebukes Gideon for not calling them when he went to fight Midian. Gideon asks what he has done compared with them, calls Ephraim's grape gleaning better than Abiezer's vintage, and credits their capture of Oreb and Zeeb. Their anger abates. Judges 7 records a later summons to Ephraim during pursuit; the complaint about the earlier fight is not rewritten as false, and rhetoric is not converted into motive.

## Judges 8:4–9 — BREAD AFTER THE KINGS, APPARENTLY

Gideon and the 300 cross Jordan **faint, yet pursuing**. Gideon asks Succoth for bread because the people are faint and he is pursuing Zebah and Zalmunna. Succoth's princes ask whether the kings' hands are already in Gideon's hand such that they should give bread. Gideon promises that after the LORD delivers the kings, he will tear their flesh with wilderness thorns and briers.

At Penuel Gideon speaks the same way; its men answer as Succoth answered. Gideon promises to break their tower when he returns in peace.

The completed dependency is observable:

```text
NEEDED NOW: BREAD FOR FAINT PURSUERS
PURPOSE: CONTINUE PURSUIT AND CAPTURE KINGS
TOWN CONDITION FOR BREAD: KINGS ALREADY CAPTURED
RESULT: SUPPORT REQUIRED FOR X IS WITHHELD UNTIL X
```

Only after both refusal States and the later capture coexist, Captain pokes the support-after-success boil, licks his finger, says **“YOINK!”**, and walks away without looking back. He supplies no bread and changes nothing.

## Judges 8:10–17 — CAPTURE, RETURN AND EXECUTED THREATS

Zebah and Zalmunna are at Karkor with about 15,000 remaining; the source says 120,000 sword-drawing men had fallen. Gideon approaches by the tent-dwellers' route, strikes the secure army, pursues and captures both kings, and confuses the army.

Returning from battle, Gideon catches a young Succoth man who writes/describes the 77 princes and elders. Gideon presents the captured kings, repeats Succoth's taunt, takes the elders and teaches Succoth's men with thorns and briers. He breaks Penuel's tower and kills the city's men. The teaching mechanism and individual outcomes at Succoth remain exactly as stated, without euphemistic or graphic expansion.

## Judges 8:18–21 — TABOR, JETHER AND THE TWO KINGS

Gideon asks the kings about men they killed at Tabor. They say the men resembled Gideon and children of a king. Gideon identifies them as his maternal brothers and says he would not kill the kings if they had kept those brothers alive.

Gideon orders his firstborn Jether to kill them. Jether does not draw his sword; the narrator explicitly says he was afraid because he was still a youth. Zebah and Zalmunna tell Gideon to do it, and Gideon kills them and takes crescents from their camels' necks. This supplied fear is retained; no private State is added.

## Judges 8:22–27 — THE LORD SHALL RULE. GIVE ME YOUR GOLD.

Israel's men ask Gideon, his son and grandson to rule because Gideon saved them from Midian. Gideon refuses rule for himself and his son and says: **“THE LORD SHALL RULE OVER YOU.”**

Gideon then requests each person's plunder earring. They willingly spread a garment and throw them in. The requested gold weighs 1,700 shekels, apart from crescents, pendants, royal purple clothing and camel-neck chains. Gideon makes an ephod, puts it in Ophrah, all Israel plays the prostitute with it there, and it becomes a snare to Gideon and his house.

```text
GIDEON'S SPOKEN RULE: THE LORD SHALL RULE
GIDEON'S NEXT COMPLETED ACT: COLLECT GOLD -> MAKE EPHOD -> INSTALL AT OPHRAH
OBSERVED CHANGED STATE: ISRAEL WORSHIPS IT / EPHOD BECOMES SNARE
```

Only after the worship/snare State completes, Captain pokes the rule-object boil, licks his finger, says **“YOINK!”**, and walks away without looking back. He neither rules nor removes the ephod.

## Judges 8:28–35 — REST, HOUSE, DEATH, RETURN

Midian is subdued and does not lift its head again. The land rests 40 years during Gideon's days. Jerubbaal lives in his house. Gideon has 70 sons from many wives; his Shechem concubine bears a son whom he names Abimelech. No lexical meaning, kingship or Judges 9 act is imported.

Gideon dies at a good old age and is buried in Joash's tomb at Ophrah. After his death Israel returns to the Baals, makes Baal Berith its god, does not remember the LORD's deliveries, and shows no kindness to Jerubbaal's house corresponding to his goodness to Israel.

## Character and world-ledger changes

- Gideon gains Ephraim de-escalation, continued pursuit, town refusals/threats, king capture/death, rule refusal, gold/ephod, household, death and burial Moments.
- Succoth's 77 leaders, Penuel, Zebah/Zalmunna, Jether, Gideon's brothers, wives, 70 sons, concubine and Abimelech receive only source-stated edges.
- `SCRIPTURE-GOD-JDG8` retains divine delivery/rule references as speech attribution; no divine form appears.
- `S143-E001-JDG8` and `S144-E001-JDG8` are the only cracks; Captain is boilless and causally useless.

## Bullshit pass

Issue `JDG-008 / CATCH-FIRST CATERING`. Succoth operates **PROOF-OF-CAPTURE BREAD**, Penuel offers **SAME ANSWER / DIFFERENT BUILDING**, the royal loot enters **VOLUNTARY EARRING DROP 1700**, and Ophrah installs **LORD-RULES EPHOD SNARE EDITION**. Foundation unchanged.

## FIR verification

- FILTER: Judges chapter 8 only; all 35 markers retained in order.
- ISOLATE: Ephraim exchange, faint pursuit/refusals, capture/return, kings/Jether, rule/ephod and household/death aftermath.
- RECONSTRUCT: repeated town answers form one pursuit occurrence; Gideon's later object and narrator-stated worship/snare complete the second mismatch.
- VERIFY: exactly two new cracks, no SKIP, two post-closure YOINKs, explicit Jether fear only, no Abimelech future, divine form or invented motive, publication held.

## Required comic states

1. Ephraim rebuke, Gideon's grape comparison and anger abatement.
2. Faint 300 cross Jordan and request bread.
3. Succoth requires captured kings first; Gideon states thorn consequence.
4. Penuel repeats refusal; Gideon states tower consequence.
5. Remaining-army count, surprise strike and capture; first `YOINK!` after capture closes the dependency mismatch.
6. Succoth identification/thorns and Penuel tower/men outcomes.
7. Tabor brothers, Jether's explicit fear/non-act, Gideon kills kings.
8. Israel offers dynasty; Gideon says the LORD shall rule.
9. Earrings/1,700 shekels/additional items, ephod construction and Ophrah placement.
10. Israel worships ephod; snare State; second `YOINK!`.
11. Midian subdued, 40-year rest, Gideon household/death/burial and Israel's return.
12. Held lineage page.

## Production boundary

- Every depicted living human, camel, thorn/brier plant or other organism is Joe-faced.
- Never render God/LORD as face, form, body, silhouette or anatomy.
- No SKIP. Exactly two boilless, causally-null post-closure Captain occurrences: **“YOINK!”**, poke, lick, walk away, no look back.
- Render violence non-graphically. Do not invent Succoth injury detail, motives, unrecorded bread, Abimelech's future, ephod symbolism/mechanism or private State beyond Jether's explicit fear.
- Publication held. `CHB-JDG-009` excluded.

*shrug*

OK.
