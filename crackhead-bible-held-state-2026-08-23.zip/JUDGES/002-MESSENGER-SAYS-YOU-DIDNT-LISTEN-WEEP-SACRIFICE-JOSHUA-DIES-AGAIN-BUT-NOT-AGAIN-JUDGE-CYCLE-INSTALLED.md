# CRACKHEAD JUDGES 2

## Title page

**MESSENGER SAYS YOU DIDN'T LISTEN. WEEP. SACRIFICE. JOSHUA DIES AGAIN, BUT NOT AGAIN. JUDGE CYCLE INSTALLED.**

Source parent: Judges chapter 2, verses 1–23, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JDG-002/job.json` and `source.usfm`.

Parent manuscript: `JUDGES/001-LAND-DELIVERED-FIGHT-FOR-IT-JERUSALEM-BURNED-JEBUSITES-STILL-THERE-EVERYONE-DIDNT-DRIVE-EVERYONE-OUT.md`.

CrackFlix routing:

- `S070-E013-JDG2`, `SKIP -> S070-E012-JDG1`: all delivered / narrator says remaining nations were not delivered into Joshua's hand;
- new `S136-E001-JDG2`, no SKIP: Joshua's same burial site changes from Timnathserah to Timnath Heres without a rename bridge.

## Causal foundation

```text
LORD MESSENGER: GILGAL -> BOCHIM
-> FIRST-PERSON LORD COVENANT / COMMAND / CHARGE
-> YOU DID NOT LISTEN
-> I WILL NOT DRIVE THEM OUT
-> PEOPLE WEEP
-> PLACE NAMED BOCHIM
-> SACRIFICE TO LORD

RETROSPECTIVE JOSHUA RELEASE / SERVICE / DEATH / BURIAL
-> OLD GENERATION ENDS
-> NEW GENERATION DOES NOT KNOW LORD OR WORK
-> BAAL / ASHTAROTH SERVICE
-> RAIDERS / ENEMIES / DISTRESS
-> JUDGES RAISED + SAVE
-> PEOPLE DO NOT LISTEN
-> JUDGE LIVES: SAVED
-> JUDGE DIES: PEOPLE TURN BACK WORSE
-> NATIONS LEFT AS TEST
```

## Judges 2:1–5 — THE MESSENGER AT BOCHIM

The LORD's messenger travels from Gilgal to Bochim. The messenger speaks in
first person as the LORD's carrier: Egypt-to-land action, an unbroken covenant,
the no-covenant-with-inhabitants rule and altar-demolition command. The speech
then charges Israel with not listening and asks why.

The carrier states the resulting change: the peoples will not be driven out;
they will be in Israel's sides and their gods will be a snare. The messenger's
Joe face, if shown, identifies the living messenger—not a rendered divine form.
No explanation of first-person transmission is invented.

Israel hears, raises its voice and weeps. The place is called Bochim/Weepers,
and Israel sacrifices there to the LORD. Weeping, naming and sacrifice are
completed acts. No internal repentance motive or future compliance is inferred.

## Judges 2:6–10 — THE JOSHUA CLOSE IS RETOLD, NOT REPEATED

The narrative steps backward to Joshua sending the people to possess their
inheritances, their service through Joshua and the elders, and Joshua's death
at 110. This joins Joshua 24's retained occurrence; it does not create a second
Joshua, death or burial.

The burial retains Ephraim hill country, north of Mount Gaash, but calls the
site **Timnath Heres** rather than Joshua 24's **Timnathserah**. The matching
person, age, region and Gaash relation identify the same burial occurrence; no
rename, alternate-name or spelling bridge is supplied. This is new
`S136-E001-JDG2: SAME GRAVE / DIFFERENT PLACE NAME`.

No SKIP occurs. After the name mismatch closes, Captain Crackhead pokes the
Joe-faced boil, sees a crack crystal, licks his finger, says **“YOINK!”**, and
walks away. The grave stays exactly where both source addresses put it.

After that generation is gathered to its fathers, another generation arises
that does not know the LORD or the work done for Israel. The generational State
changes; no missing teaching act or private mental cause is invented.

## Judges 2:11–15 — OTHER-GOD SERVICE AND DISTRESS

Israel does what the narrator calls evil, serves Baals, abandons the LORD,
follows surrounding gods, bows, and serves Baal and Ashtaroth. The narrator
attributes burning anger, delivery to plundering raiders, sale to surrounding
enemies, inability to stand, hostile outcomes wherever Israel goes, and severe
distress to the LORD.

These are completed generalized states for the new generation. Individual
raiders, battles, sale mechanism, dates and quantities remain unsupplied.

## Judges 2:16–19 — THE JUDGE CYCLE

The LORD raises judges who save Israel from plunderers. Israel does not listen
to the judges, follows other gods and turns quickly from the earlier way.

When a judge is raised, the LORD is with that judge and saves Israel throughout
the judge's life, with groaning under oppression supplied as the relation.
When the judge dies, Israel turns back and acts more corruptly, continuing
other-god service and stubborn ways.

This is the narrator's recurring cycle model. It retains judge-life and
judge-death gates without inventing unnamed judges, counts or duplicate cycles.
Specific executions begin only when later chapters instantiate them.

## Judges 2:20–23 — NATIONS LEFT, TEST INSTALLED, NON-DELIVERY STATED

The LORD directly states that because Israel transgressed the covenant and did
not listen, no more of the nations Joshua left at death will be driven out.
They will be used to test whether Israel keeps the LORD's way.

The narrator closes: those nations were left without rapid expulsion and were
**not delivered into Joshua's hand**. Retained Joshua 21 says all enemies were
delivered into Israel's hand, and Joshua 24 says all peoples were driven out.
The present verse supplies an explicit non-delivery State for Joshua's remaining
nations.

This is `S070-E013-JDG2`, the established delivered/not-delivered process type.
CrackFlix displays `SKIP -> S070-E012-JDG1`. It points to the same bullshit and
does nothing. After closure, Captain pokes, licks his finger, says
**“YOINK!”**, and walks away. The nations, test and causal explanation remain.

The covenant-transgression -> no-drive-out -> test relation is a new later
explanation for why nations remain. It joins the retained state but does not
erase the earlier contradiction Moments that existed without that bridge.

## Character and world-ledger changes

- the Gilgal-to-Bochim messenger and first-person carrier speech remain distinct from God form;
- covenant, inhabitant, altar, non-listening and non-expulsion lines stay in one messenger speech;
- weeping, Bochim naming and sacrifice are completed;
- Joshua release/service/death/burial are deduplicated against Joshua 24;
- Timnathserah/Timnath Heres becomes new `S136-E001-JDG2` without SKIP;
- new-generation non-knowledge and other-god service are completed narrative states;
- the judge/oppressor cycle is retained as a model, not multiplied into unnamed occurrences;
- explicit non-delivery becomes `S070-E013-JDG2` with exact SKIP pointer;
- the later non-expulsion/test explanation joins but does not erase prior cracks;
- exactly two causally null post-closure YOINKs occur;
- Captain remains permanently boilless and changes nothing;
- every living human, animal, plant, angel or messenger Joe and every face-like non-divine altar, snare, grave sign, generation counter, judge timer, raider receipt or test terminal is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JUDGES — BOCHIM CUSTOMER COMPLAINT DESK`;
- messenger badge: `FIRST PERSON DELIVERY / SENDER NOT RENDERED`;
- grave sign: `TIMNATHSERAH / TIMNATH HERES / SAME GAASH EXIT`;
- generation terminal: `PREVIOUS KNOWLEDGE NOT FOUND`;
- judge cycle: `OPPRESS -> GROAN -> SAVE -> JUDGE DIES -> WORSE -> REPEAT`;
- nation tester: `LEFT INSTALLED FOR QUALITY ASSURANCE`;
- CrackFlix: `S070-E013 -> SKIP E012`; `S136 PREMIERE`;
- barcode: `CHB-JDG2-23-2CRACKS-2YOINKS-HELD`.

## FIR verification

- all 23 verse markers are represented in order;
- messenger identity, first-person carrier speech and divine attribution remain distinct;
- no divine body or transmission mechanism is invented;
- Bochim response acts are completed without inferred inner change;
- Joshua chronology is recognized as retrospective and not duplicated;
- the grave-name mismatch preserves both source names and exact shared location evidence;
- new generation, other-god service, raider/enemy distress and judge cycle remain in source order;
- the generalized cycle does not create unnamed episode instances;
- the later non-expulsion/test relation joins earlier State without retroactive erasure;
- one repeated and one new contradiction type produce exactly two YOINKs;
- Captain changes no outcome;
- publication remains held and unpublished.

Continuation required: Judges 3 names the nations left for testing, records
intermarriage and other-god service, then instantiates Othniel, Ehud and Shamgar
without importing Judges 4.
