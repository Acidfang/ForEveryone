# CRACKHEAD JUDGES 9

## Title page

**SEVENTY RULERS OR ME. BROTHER MONEY. ONE STONE. TALKING TREES. MOUNTAIN SHADOWS. DON'T SAY A WOMAN KILLED ME.**

Source parent: Judges chapter 9, verses 1–57, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-009/job.json` and `source.usfm`. Parent: Judges 8.

Display-origin layer: source names remain exact in this evidence manuscript;
comic nameplates/dialogue use **NOT-ABIMELECH JOE**, **NOT-JOTHAM JOE**,
**NOT-SHECHEM**, **NOT-GAAL JOE**, **NOT-ZEBUL JOE**, **NOT-THEBEZ**, and
**NOT-THE-LORD**. These are Crackheadverse identities, not source originals.

CrackFlix routing:

- new mental `S145-E001-JDG9`, no SKIP: Abimelech offers seventy rulers versus himself before the seventy sons are observed ruling;
- new `S146-E001-JDG9`, no SKIP: actual descending companies are called mountain shadows;
- new `S147-E001-JDG9`, no SKIP: Abimelech says a woman broke his skull while ordering death so nobody says a woman killed him.

## Causal foundation

```text
ABIMELECH TO MATERNAL FAMILY
-> “70 JERUBBAAL SONS RULE OR ONE?” + BONE/FLESH
-> SHECHEM: OUR BROTHER -> 70 BAAL-BERITH SILVER
-> HIRES RECKLESS MEN -> KILLS BROTHERS ON ONE STONE
-> JOTHAM HIDES / ABIMELECH MADE KING

JOTHAM FROM GERIZIM
-> TREE PARABLE: OLIVE/FIG/VINE REFUSE; BRAMBLE ACCEPTS + FIRE WARNING
-> APPLIES TRUE/RIGHTEOUS TEST TO SHECHEM/ABIMELECH
-> MUTUAL-FIRE CURSE -> JOTHAM FLEES

ABIMELECH 3 YEARS
-> GOD-SENT EVIL SPIRIT ATTRIBUTION -> SHECHEM TREACHERY/AMBUSH
-> GAAL TRUST/FEAST/CURSE/CHALLENGE
-> ZEBUL SECRET MESSAGE -> 4-COMPANY NIGHT AMBUSH
-> GAAL: PEOPLE DESCENDING / ZEBUL: MOUNTAIN SHADOWS
-> PEOPLE CONFIRMED -> FIGHT -> GAAL FLEES/EXPELLED
-> ABIMELECH DESTROYS/SALTS SHECHEM
-> BOUGHS + FIRE -> ABOUT 1000 TOWER PEOPLE DIE
-> THEBEZ TOWER -> WOMAN DROPS MILLSTONE -> SKULL BROKEN
-> “KILL ME SO THEY DON'T SAY A WOMAN KILLED ME”
-> ARMOR BEARER KILLS -> ARMY DEPARTS
-> NARRATOR: GOD REPAID BOTH WICKEDNESSES / JOTHAM CURSE CAME
```

## Judges 9:1–6 — THE SEVENTY-RULER PACKAGE

Abimelech asks his maternal family to ask Shechem whether it is better for all seventy sons of Jerubbaal to rule or for one to rule, and reminds them he is their bone and flesh. The retained prior State records Gideon's sons but no seventy-person rule. His family repeats the words; Shechem's hearts incline toward him because they call him their brother.

Shechem gives him seventy silver pieces from Baal Berith's house. He hires vain and reckless fellows, kills Jerubbaal's sons on one stone, while youngest Jotham survives by hiding. Shechem and Millo make Abimelech king.

```text
OFFERED ALTERNATIVE: SEVENTY SONS RULE
RETAINED STATE: SEVENTY SONS EXIST; THEIR RULE IS NOT OBSERVED
CLAIM EXCEEDS EVIDENCE -> MENTAL CRACK AT ABIMELECH'S ASSERTED CHOICE
```

After Abimelech's one-man rule is installed, Captain pokes the mental-choice boil, licks his finger, says **“YOINK!”**, and walks away. He changes no killing or kingship.

## Judges 9:7–21 — JOTHAM'S TALKING-TREE BROADCAST

Jotham stands on Mount Gerizim and calls Shechem to listen. His parable says trees seek a king. Olive, fig and vine refuse to leave oil, sweetness/fruit and wine to wave over trees. The bramble accepts if they truly take refuge in its shade; otherwise it threatens fire consuming Lebanon's cedars.

Every living tree/vine in the visibly framed parable has Joe's face. The parable is Jotham's speech, not a literal tree election. Its God/oil/wine statements remain within that speech.

Jotham applies a true-and-righteous conditional to Shechem's treatment of Jerubbaal's house, explicitly recalls Gideon's risk/delivery and the seventy killings, and says mutual fire should follow if the treatment was not righteous. Jotham flees to Beer because of Abimelech. His fear is source-stated.

## Judges 9:22–29 — THREE YEARS, TREACHERY AND GAAL'S CHALLENGE

Abimelech is prince over Israel three years. The narrator says God sends an evil spirit between him and Shechem; Shechem deals treacherously so the violence/blood of Jerubbaal's sons will return upon Abimelech and the men who strengthened him. No spirit body, psychology or mechanism is rendered.

Shechem sets mountain ambushes and robs travelers. Gaal and his brothers arrive; Shechem trusts him. During vineyard harvest, celebration, eating and drinking in their god's house, they curse Abimelech. Gaal challenges Abimelech, wishes the people under his hand, and tells him to increase his army and come out. These are spoken boasts followed by an actual fight, not contradiction merely because Gaal later loses.

## Judges 9:30–41 — THE MOUNTAINS HAVE PEOPLE-SHAPED SHADOWS

City ruler Zebul hears Gaal and becomes angry. He craftily tells Abimelech that Gaal is inciting the city and instructs a four-company night ambush and morning attack. Abimelech executes it.

At the gate Gaal observes people descending from mountain tops. Zebul says he sees mountain shadows **as if they were men**. Gaal observes people again by two routes. Zebul then asks where Gaal's mouth is, identifies them as the despised people, and tells him to fight. Gaal fights, flees under pursuit, many are wounded, and Zebul drives Gaal and his brothers from Shechem.

```text
GAAL: PEOPLE ARE DESCENDING
ZEBUL: THOSE ARE MOUNTAIN SHADOWS
OBSERVED STATE: ABIMELECH'S COMPANIES ARE DESCENDING
ZEBUL NEXT: THESE ARE THE PEOPLE; GO FIGHT THEM
```

After the companies are openly identified, Captain pokes the shadow boil, licks his finger, says **“YOINK!”**, and walks away. The fight continues unchanged.

## Judges 9:42–49 — SHECHEM AND THE BRANCH FIRE

The next day people enter the field. Abimelech divides three companies, ambushes, strikes the field groups, takes Shechem after all-day fighting, kills its people, demolishes it and sows salt.

The tower people enter Elberith's stronghold. Abimelech cuts a tree bough at Zalmon and tells followers to copy him. They place boughs at the stronghold and burn it over the people; about one thousand men and women die. This is a completed fire occurrence following Jotham's attributed warning. It is not turned into literal fire emerging from a human body, and violence is non-graphic.

## Judges 9:50–55 — DON'T SAY A WOMAN KILLED ME

Abimelech takes Thebez. Its men and women flee into a tower and go to the roof. Abimelech approaches the door to burn it. A woman drops an upper millstone on his head and breaks his skull.

Abimelech urgently orders his armor bearer to kill him **“THAT MEN NOT SAY OF ME, ‘A WOMAN KILLED HIM.’”** The bearer thrusts him through and he dies. Israel's men see he is dead and depart.

```text
ABIMELECH'S PURPOSE: PREVENT THE REPORT “A WOMAN KILLED HIM”
ABIMELECH'S OWN WORDS: ANNOUNCE THE WOMAN'S MILLSTONE AND ORDER A SUBSTITUTE FINAL BLOW
RETAINED STORY: WOMAN BREAKS SKULL -> ORDER -> BEARER KILLS -> DEATH
```

After death completes, Captain pokes the reputation boil, licks his finger, says **“YOINK!”**, and walks away without looking back. He changes neither cause nor report.

## Judges 9:56–57 — NARRATED REPAYMENT

The narrator says God repaid Abimelech's wickedness in killing his brothers and repaid Shechem's wickedness, and that Jotham's curse came upon them. This is narrator-attributed closure. God receives no rendered form, and the mechanism linking each event is unresolved.

## Character and world-ledger changes

- Abimelech gains kinship pitch, funding, fratricide, kingship/principality, Shechem war, tower fires and death Moments.
- Jotham gains hidden-survivor, parable/curse and Beer-flight Moments; every tree act remains inside his speech.
- Shechem/Millo, Gaal, Zebul, tower populations, Thebez woman and armor bearer gain exact observed edges.
- `SCRIPTURE-GOD-JDG9` retains evil-spirit and repayment attributions without form or mechanism.
- `S145-E001-JDG9`, `S146-E001-JDG9` and `S147-E001-JDG9` are the only cracks; Captain remains boilless and causally useless.

## Bullshit pass

Issue `JDG-009 / FAMILY PLAN 70`. Baal Berith funds **BROTHER STARTUP SILVER**, Gerizim airs **TREES CHOOSE BRAMBLE CEO**, Zebul installs **PEOPLE-SHAPED MOUNTAIN SHADOW FILTER**, and Thebez closes with **REPUTATION MANAGEMENT: SAY THE WHOLE THING OUT LOUD**. Foundation unchanged.

## FIR verification

- FILTER: Judges chapter 9 only; all 57 markers retained in order.
- ISOLATE: Abimelech accession, Jotham speech, three-year reversal, Gaal/Zebul conflict, Shechem destruction, Thebez death and narrator repayment.
- RECONSTRUCT: parable and curse remain attributed speech; evil spirit and repayment remain narrator attribution; future/private mechanisms are absent.
- VERIFY: exactly three new cracks, no SKIP, three post-closure YOINKs, no divine/spirit form, no invented motive or graphic violence, publication held.

## Required comic states

1. Abimelech's seventy-versus-one pitch and brother appeal.
2. Seventy silver, hired followers, one-stone killings, Jotham hidden and coronation; mental `YOINK!`.
3. Gerizim parable: olive/fig/vine refuse, bramble accepts/fire warning, visibly framed as speech.
4. Jotham applies conditional/history/curse and flees.
5. Three-year rule; attributed evil spirit; Shechem treachery/robbery.
6. Gaal harvest feast, curse and challenge; Zebul's secret plan.
7. Four-company approach; “shadows” denial; actual people confirmed; second `YOINK!`; fight/expulsion.
8. Field attack, Shechem destruction/salt.
9. Copied boughs and non-graphic stronghold fire/about-1000 deaths.
10. Thebez tower; woman drops millstone; broken skull.
11. Abimelech states reputation purpose, bearer kills, army departs; third `YOINK!`.
12. Narrator repayment/curse closure and held lineage page.

## Production boundary

- Every rendered biblical identity carries the `NOT-` origin marker. Source
  citations and machine addresses remain unchanged.
- Every depicted living human, tree, vine or other organism is Joe-faced. Parable organisms remain visibly inside Jotham's speech.
- Never render God or the evil spirit as face, form, body, silhouette or anatomy.
- No SKIP. Exactly three boilless, causally-null post-closure Captain occurrences: **“YOINK!”**, poke, lick, walk away, no look back.
- Render mass death and injury non-graphically. Do not invent motives, divine/spirit/curse mechanisms, unrecorded rule by Gideon's sons or future events.
- Publication held. `CHB-JDG-010` excluded.

*shrug*

OK.
