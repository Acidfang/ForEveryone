# CRACKHEAD JUDGES 16

## Title page

**NOT-DELILAH: “TELL ME HOW TO AFFLICT YOU. STOP LYING. TELL ME THE TRUTH.” NOT-SAMSON TELLS HER. SHE AFFLICTS HIM. NOT-DAGON DID IT. THREE THOUSAND WATCHERS PAY FOR TWO EYES.**

Source parent: Judges chapter 16, verses 1–31, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-016/job.json` and `source.usfm`. Parent: Judges 15.

Display-origin layer: exact source identities remain in evidence. Comic display uses **NOT-SAMSON JOE**, **NOT-DELILAH JOE**, **NOT-GAZITE JOES**, **NOT-PHILISTINE LORD JOES**, **NOT-PHILISTINE JOES**, **NOT-HAIR-CUTTER JOE**, **NOT-BOY JOE**, and **NOT-SAMSON'S FAMILY JOES**. NOT-DAGON is only a source-addressed god/idol identity; any face-bearing representation may carry Joe's face without establishing life or causal power. NOT-THE-LORD remains unrendered.

CrackFlix routing: mental `S154-E003-JDG16` uses `SKIP -> S154-E001-JDG14`; new truth-demand `S155-E001-JDG16` has no SKIP; causal-credit `S022-E005-JDG16` uses `SKIP -> S022-E004-GEN50`; collective-liability `S127-E004-JDG16` uses `SKIP -> S127-E003-JDG15`. Exactly four causally-null post-closure YOINKs.

## Causal foundation

```text
NOT-SAMSON ENTERS NOT-GAZA / VISITS PROSTITUTE
-> GAZITES WAIT AT GATE FOR MORNING KILL
-> MIDNIGHT GATE-DOOR/POST/BAR REMOVAL -> MOUNTAIN DELIVERY
-> NOT-SAMSON LOVES NOT-DELILAH
-> PHILISTINE LORDS OFFER 1100 SILVER EACH FOR STRENGTH METHOD
-> NOT-DELILAH ASKS HOW TO BIND/AFFLICT HIM
-> CORD CLAIM -> BIND/AMBUSH/CALL -> CORDS BREAK
-> ROPE CLAIM -> BIND/AMBUSH/CALL -> ROPES BREAK
-> LOOM CLAIM -> FASTEN/CALL -> PIN/FABRIC REMOVED
-> “HOW CAN YOU SAY I LOVE YOU?” / DAILY PRESSURE
-> TRUE NAZIRITE/RAZOR/SHAVING DISCLOSURE
-> LORDS RETURN WITH MONEY -> SLEEP -> SEVEN LOCKS SHAVED
-> AFFLICTION / STRENGTH DEPARTS / LORD DEPARTURE ATTRIBUTION
-> SEIZURE / EYES REMOVED / BRONZE FETTERS / PRISON MILL
-> HAIR REGROWS
-> NOT-DAGON SACRIFICE/PRAISE / NOT-SAMSON ENTERTAINS
-> BOY POSITIONS HIM AT TWO SUPPORT PILLARS
-> NOT-SAMSON PRAYS FOR ONE STRENGTH/REVENGE FOR TWO EYES
-> PUSH -> HOUSE COLLAPSE -> MORE DEAD THAN DURING LIFE
-> FAMILY RECOVERS/BURIES BODY -> TWENTY-YEAR JUDGESHIP CLOSE
```

## Judges 16:1–3 — MIDNIGHT MUNICIPAL-GATE REMOVAL

NOT-SAMSON goes to NOT-GAZA, sees a prostitute and goes in to her. Gazites are told he is there. They surround him, wait quietly at the city gate through the night and say they will kill him at morning light.

At midnight NOT-SAMSON rises, takes the gate doors, two posts and bar, puts them on his shoulders and carries them to the mountain before NOT-HEBRON. The source supplies no report of the waiting Gazites' response, the gate's dimensions, travel distance, lifting mechanism or prostitute's later State.

## Judges 16:4–14 — THREE LIVE PENETRATION TESTS

Afterward NOT-SAMSON loves NOT-DELILAH in the valley of NOT-SOREK. Philistine lords ask her to entice him and discover his strength and how they can bind and afflict him. Each promises eleven hundred pieces of silver.

NOT-DELILAH asks NOT-SAMSON where his strength lies and how he might be bound **to afflict him**. He supplies three claims:

1. seven undried green cords;
2. new ropes on which no work has been done;
3. seven hair locks woven into loom fabric.

Each proposed restraint is actually installed. An ambush waits during the first two narrated trials. Each time NOT-DELILAH calls, **“THE PHILISTINES ARE ON YOU, NOT-SAMSON!”** He breaks the cords, breaks the ropes, then wakes and pulls away the loom pin and fabric. No ambusher attack, payment, injury or discovery of his actual strength occurs during these trials.

## Judges 16:15–18 — LOVE-AS-PRIVATE-STATE READER / TRUTH PROCUREMENT

NOT-DELILAH says:

**“HOW CAN YOU SAY, ‘I LOVE YOU,’ WHEN YOUR HEART IS NOT WITH ME?”**

She observes three false restraint disclosures and asserts his private heart State from them. The source separately states that NOT-SAMSON loved her; it supplies no retraction before her claim. This repeats the exact mental root:

**SKIP -> S154-E001-JDG14: YOU DIDN'T TELL ME, SO I KNOW YOUR PRIVATE FEELINGS.**

Captain zones out, then pokes the mental-model boil, licks his finger, says **“YOINK!”**, and walks away. NOT-DELILAH continues pressing him daily.

Her words press and urge him until the source says his soul is troubled to death. NOT-SAMSON tells all his heart: no razor has come on his head; he has been a Nazirite to God from his mother's womb; shaving will make his strength leave and make him weak like another man.

The interaction began with NOT-DELILAH explicitly requesting the binding information **so he could be afflicted**. She then performed each false method, objected to the lies, invoked love and continued until he disclosed the true method. The truth is then routed directly into the requested affliction. New CrackFlix series:

**S155: REQUIRE THE TRUTH NEEDED TO HARM HIM / HARM HIM WITH THE TRUTH.**

The crack does not complete at the disclosure. It completes only when the true information is executed against him in the next State.

## Judges 16:18–22 — THE TRUE ANSWER PASSES ACCEPTANCE TESTING

NOT-DELILAH says he has told all his heart and summons the Philistine lords once more. They arrive carrying the money. She makes him sleep on her knees, calls a man, and the seven locks are shaved. She begins to afflict him. His strength leaves.

Now the requested truth has produced the requested affliction. Captain pokes the truth-procurement boil, licks his finger, says **“YOINK!”**, and leaves. The shaving, affliction and capture remain unchanged.

When NOT-DELILAH calls the Philistine warning, NOT-SAMSON wakes and says he will go out and shake free as before. He does not know the LORD has departed from him. Philistines seize him, put out his eyes, take him to NOT-GAZA, bind him in bronze fetters and make him grind in prison. His hair begins growing again after the shaving. The source does not define whether hair is cause, condition, sign, retained vow carrier or timing mechanism; no model is invented.

## Judges 16:23–25 — NOT-DAGON RECEIVES THE PRODUCTION CREDIT

Philistine lords gather for a great sacrifice to NOT-DAGON and rejoice. They say:

**“OUR GOD HAS DELIVERED NOT-SAMSON OUR ENEMY INTO OUR HAND.”**

The people see NOT-SAMSON and praise their god with the same delivery claim. The retained production chain instead names NOT-DELILAH's information procurement, the lords' payment and return, a man's shaving act, the LORD's departure, and Philistine seizure. No NOT-DAGON act appears in that chain. This repeats `S022`:

**SKIP -> S022-E004-GEN50: RETAINED ACTORS PRODUCED IT / GOD GETS THE CLAIM.**

Captain zones out. After the people complete the praise, he pokes the causal-credit boil, licks his finger, says **“YOINK!”**, and walks away. The sacrifice and celebration continue.

With their hearts merry, they call NOT-SAMSON from prison to entertain them. He performs and is placed between the pillars. No performance content or intoxication mechanism is supplied.

## Judges 16:26–30 — TWO EYES / WHOLE BUILDING INVOICE

NOT-SAMSON asks the boy holding his hand to let him feel the pillars supporting the house so he may lean on them. The house is full of men and women, all Philistine lords are present, and about three thousand men and women are on the roof watching the performance.

NOT-SAMSON calls to NOT-THE-LORD for remembrance and strength once, stating the purpose:

**“THAT I MAY BE AT ONCE AVENGED OF THE PHILISTINES FOR MY TWO EYES.”**

He grips the two middle support pillars, says, **“LET ME DIE WITH THE PHILISTINES,”** and bows with all his might. The house falls on the lords and all the people in it. The source states the dead at his death exceed those killed during his life.

The retained grievance is the removal of his two eyes by Philistines. The collapse assigns death to the full house and roof crowd without identifying each attendee as an eye-removal actor or supplying a collective-liability bridge. This repeats `S127`:

**SKIP -> S127-E003-JDG15: AN ADDRESSED ACT / ADDITIONAL PEOPLE PAY.**

After the collapse completes the mismatch, Captain pokes the whole-building invoice boil, licks his finger, says **“YOINK!”**, and walks away without looking back. The building remains collapsed.

## Judges 16:31 — BODY RECOVERY / TWENTY-YEAR CLOSE

NOT-SAMSON's brothers and his father's house recover his body, carry it up and bury it between NOT-ZORAH and NOT-ESHTAOL in NOT-MANOAH's burial site. The source closes by stating he judged NOT-ISRAEL twenty years. Burial access, casualty count, structural geometry and whether every roof observer died remain unresolved.

The LORD's earlier departure is not stated to be permanent. NOT-SAMSON's later prayer followed by renewed strength therefore does not itself contradict the departure State. The narration supplies the sequence but not the strength-return mechanism or a spoken divine response.

## Character and world-ledger changes

- NOT-SAMSON gains Gaza gate removal, NOT-DELILAH relationship, three false restraint trials, true Nazirite disclosure, shaving/strength loss, eye removal, imprisonment, hair regrowth, final prayer, house collapse, death and burial.
- NOT-DELILAH gains the lords' offer, three restraint trials, repeated pressure, successful disclosure, summons, shaving/affliction chain and unresolved post-payment State.
- `S154-E003-JDG16` retains the repeated unsupported private-heart inference.
- `S155-E001-JDG16` retains truth demanded for affliction and used for affliction.
- `S022-E005-JDG16` retains NOT-DAGON causal credit without a NOT-DAGON producing act.
- `S127-E004-JDG16` retains the two-eye grievance distributed over the whole house.

## Bullshit pass

Issue `JDG-016 / PASSWORD ACCEPTED`. NOT-DELILAH runs **THREE FAILED RESTRAINT BUILDS**, then deploys **LOVE-BASED CREDENTIAL RECOVERY**. NOT-DAGON receives **ZERO-ACT PRODUCTION CREDIT**. NOT-SAMSON closes the account with **TWO-PILLAR MASS REFUND**. Foundation unchanged.

## FIR verification

- FILTER: Judges 16 only, with living NOT-SAMSON State from Judges 15; all 31 markers retained in order.
- ISOLATE: Gaza escape, four disclosure States, true-method execution, capture, Dagon attribution, performance, final prayer/collapse and burial.
- RECONSTRUCT: one repeated mental occurrence, one new truth-demand/punishment occurrence, one repeated false-causal-credit occurrence and one repeated collective-liability occurrence.
- VERIFY: exactly four cracks, three SKIPs and four YOINKs; no betrayal motive, love falsification, hidden ambush acts, strength physics, Dagon act, divine form/response, attendee guilt or exact casualty count invented; publication held.

## Required comic states

1. Gaza visit, quiet gate ambush plan, midnight gate removal and mountain delivery.
2. Philistine-lord offer and NOT-DELILAH's explicit bind/afflict question.
3. Green-cord install, ambush warning and break.
4. New-rope install, ambush warning and break.
5. Hair/loom install, warning and pin/fabric removal.
6. “How can you say love?” mental SKIP and first YOINK; daily pressure and true disclosure.
7. Lords return with money, sleep, shaving, affliction/strength departure; new-series second YOINK.
8. Failed shake-free, LORD-departure narration, eye removal, fetters, prison grinding and hair regrowth.
9. NOT-DAGON sacrifice/praise; causal-credit SKIP and third YOINK.
10. Entertainment, boy/pillar request and full-house/three-thousand-roof State.
11. Prayer for two-eye revenge, pillar push and collapse; collective SKIP and fourth YOINK.
12. Body recovery, burial and twenty-year close.
13. Held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; source identities remain exact in evidence and machine ledgers.
- Every living human is Joe-faced. NOT-DAGON is not established living; a face-bearing idol may carry Joe's face without adding life or agency. NOT-THE-LORD remains unrendered.
- Three SKIPs point exactly to `S154-E001-JDG14`, `S022-E004-GEN50`, and `S127-E003-JDG15`. Exactly four boilless, causally-null Captain occurrences after their respective contradictions complete: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent prostitute/ambusher aftermath, love falsity, betrayal motive, payment distribution, hair/strength physics, Dagon action, divine form/spoken answer, roof geometry, individual attendee guilt or exact death count.
- Publication held. `CHB-JDG-017` excluded.

*shrug*

OK.
