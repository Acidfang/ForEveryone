# CRACKHEAD JUDGES 4

## Title page

**DEBORAH'S PALM. BARAK'S PLUS-ONE. 900 IRON CHARIOTS. DON'T BE AFRAID. TENT PEG.**

Source parent: Judges 4:1–24, ENGWEBP USFM. Prepared evidence:
`.chapter-work/CHB-JDG-004/job.json` and `source.usfm`. Parent: Judges 3.

CrackFlix routing:

- `S070-E014-JDG4`, `SKIP -> S070-E013-JDG2`: Sisera already delivered / descent, battle and pursuit still follow.
- new `S139-E001-JDG4`, no SKIP: Jael says “don't be afraid” / kills Sisera with a tent peg.

## Causal foundation

```text
EHUD DEAD -> EVIL -> SOLD TO JABIN
-> SISERA + 900 IRON CHARIOTS -> 20 YEARS -> CRY
-> DEBORAH JUDGES UNDER PALM
-> CARRIES COMMAND TO BARAK: TABOR + 10,000
-> BARAK REQUIRES DEBORAH -> SHE GOES / WOMAN-HAND OUTCOME
-> SISERA MOBILIZES -> DELIVERED CLAIM
-> DESCENT / CONFUSION / BATTLE / PURSUIT -> SISERA FLEES
-> PEACE WITH HEBER HOUSE -> JAEL: DON'T BE AFRAID
-> RUG / MILK / COVER / SLEEP -> PEG + HAMMER -> DEATH
-> BARAK OBSERVES BODY
-> JABIN SUBDUED -> ISRAEL PREVAILS -> JABIN DESTROYED
```

## Judges 4:1–5 — NEXT CYCLE

After Ehud dies, Israel again does evil. The narrator attributes their sale to
Jabin at Hazor. Sisera commands Jabin's army from Harosheth. Israel cries after
twenty years of mighty oppression under nine hundred iron chariots.

Deborah, prophetess and wife of Lappidoth, judges Israel beneath Deborah's palm
between Ramah and Bethel. Israel comes to her for judgment. No chariot, sale,
prophetic or divine-appearance mechanism is supplied.

## Judges 4:6–10 — BARAK'S PLUS-ONE

Deborah calls Barak from Kedesh. She carries an attributed LORD command: go to
Tabor with ten thousand from Naphtali and Zebulun; Sisera, chariots and multitude
will be drawn to Kishon and delivered into Barak's hand.

Barak says he goes if Deborah goes and does not go if she does not. Deborah
agrees, then says the journey will not be for his honor because Sisera will be
sold into a woman's hand. She travels with him. Barak gathers the two tribes;
ten thousand follow.

The hand statements are separated by Barak's condition and Deborah's expressed
changed consequence. No contradiction or honor mechanism is invented.

## Judges 4:11–16 — ALREADY DELIVERED; NOW FIGHT

Heber has separated from the Kenites and pitched near Kedesh. An unidentified
reporter tells Sisera that Barak went up Tabor. Sisera gathers all nine hundred
chariots and his people at Kishon.

Deborah says this is the day the LORD **has delivered** Sisera and gone before
Barak. Barak has not yet descended into the narrated battle.

**SKIP -> S070-E013-JDG2 — I HAVE DONE IT. IT HAS NOT HAPPENED YET.**

Captain's eyes glaze. Nothing skips. Barak descends. The narrator attributes
confusion of Sisera, chariots and army to the LORD before Barak's sword. Sisera
abandons his chariot and flees on foot. Barak pursues; the army falls and the
source says not a man remains.

Only after closure, permanently boilless Captain pokes the boil, licks his
finger, says **“YOINK!”**, and walks away without looking back. Nothing changes.

Whether “army” includes the separately fleeing captain is unresolved, not a
manufactured crack.

## Judges 4:17–22 — DON'T BE AFRAID / TENT PEG

Sisera flees to Jael's tent because the source states peace between Jabin and
Heber's house. Jael meets him:

**“Turn in, my lord. Turn in to me. DON'T BE AFRAID.”**

She covers him. He asks for water; she gives milk and covers him again. He asks
her to stand at the door and say “No” if someone asks whether a man is there.
No such question or denial is narrated.

Sisera sleeps. Jael takes a tent peg and hammer, approaches softly, drives the
peg through his temples into the ground, and he dies.

```text
DON'T BE AFRAID -> ENTER / DRINK / SLEEP
-> JAEL DRIVES PEG -> SISERA DEAD
```

Only after death, Captain pokes Jael's boil, licks his finger, says
**“YOINK!”**, and walks away without looking back. He changes nothing.

Barak arrives pursuing Sisera. Jael offers to show the man he seeks. Barak
observes Sisera dead with the peg through his temples. The woman-hand speech is
fulfilled without inventing Jael's motive.

## Judges 4:23–24 — JABIN'S END

The narrator says God subdued Jabin that day. Israel's hand grows stronger
until Jabin is destroyed. No separate Jabin-death scene or progressive-hand
mechanism is supplied.

## Required comic states

1. Ehud dead; evil, sale, 900 chariots, twenty years, cry.
2. Deborah judges beneath her palm.
3. Deborah carries the Tabor/Kishon command.
4. Barak requires Deborah; she agrees and speaks the woman-hand outcome.
5. Heber separates; Sisera receives report and mobilizes.
6. Exact `SKIP -> S070-E013-JDG2`; claimed delivery precedes battle.
7. Descent, confusion, defeat, Sisera flight; first post-closure `YOINK!`.
8. Peace context; Jael says “DON'T BE AFRAID,” covers and gives milk.
9. Door-denial request remains only speech; sleep and peg killing complete.
10. Second post-closure `YOINK!`; Barak observes body.
11. Jabin subdued and destroyed; held lineage page.

## Production boundary

- Every depicted living human or plant is Joe-faced. Face-like non-divine
  objects may also receive Joe's face.
- Never render God/LORD as a face, form, body, silhouette or anatomy.
- Deborah remains the carrier of her attributed LORD quotations.
- Exactly one `SKIP -> S070-E013-JDG2`; SKIP changes nothing.
- Exactly two permanently boilless, causally-null Captain occurrences, each
  only after closure: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent reporter identity, motive, divine/honor mechanism, door denial,
  Jabin death scene or army scope.
- Violence may be diagrammatic but the stated act and death remain legible.
- Publication held. `CHB-JDG-005` excluded.

## Character and world-ledger changes

- Deborah, Barak, Sisera and Jael receive distinct observed histories; shared
  Joe facial genetics never merges their identities.
- Heber's separation, the stated house-peace relation, Deborah's palm, the
  nine-hundred-chariot force, Kishon campaign and tent occurrence remain
  addressable world edges.
- Deborah's attributed LORD quotation is retained in `SCRIPTURE-GOD-JDG4`;
  God receives no rendered identity.
- `S070-E014-JDG4` and `S139-E001-JDG4` are the only contradiction occurrences.
- Captain remains permanently boilless and causally useless.

## Bullshit pass

Issue `JDG-004 / PALM COURT WARRANTY VOID IF PEGGED`. Deborah operates the
**PALM COURT**, Barak checks the **PLUS-ONE REQUIRED** box, Sisera deploys the
**IRON FLEET 900**, the milk container says **WATER UPGRADE**, and the tent peg
carries warning `DO NOT INSTALL THROUGH CAPTAIN`. None of this replaces the
source chain.

## FIR verification

- FILTER: Judges chapter 4 only; all 24 verse markers retained in order.
- ISOLATE: two completed mismatches only—premature delivery and safe invitation
  followed by killing.
- RECONSTRUCT: Barak's condition precedes the changed woman-hand statement;
  army scope, reporter, motives and mechanisms remain unresolved.
- VERIFY: exactly one valid SKIP pointer, two post-closure YOINKs, no divine
  form, no invented door-denial act, and publication remains held.

*shrug*

OK.
