# CRACKHEAD JUDGES 15

## Title page

**NOT-SAMSON: “YOU HATED HER.” 300 FOXES. ONE FATHER MOVED ONE WIFE. BURN ALL PHILISTINE CROPS. ONE FATHER DID IT. BURN BOTH.**

Source parent: Judges chapter 15, verses 1–20, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-015/job.json` and `source.usfm`. Parent: Judges 14.

Display-origin layer: exact source identities remain in evidence. Comic display uses **NOT-SAMSON JOE**, **NOT-TIMNITE FATHER JOE**, **NOT-SAMSON'S WIFE JOE**, **NOT-COMPANION JOE**, **NOT-PHILISTINE JOES**, **NOT-JUDAH JOES**, **300 NOT-FOX JOES**, and the **NOT-DONKEY JAWBONE** retaining its Joe face. NOT-THE-LORD and Spirit remain unrendered.

CrackFlix routing: mental `S154-E002-JDG15` uses `SKIP -> S154-E001-JDG14`; collective-liability `S127-E002-JDG15` uses `SKIP -> S127-E001-JOS7`; distinct collective-liability `S127-E003-JDG15` uses `SKIP -> S127-E002-JDG15`. Exactly three causally-null post-closure YOINKs.

## Causal foundation

```text
NOT-SAMSON RETURNS WITH GOAT -> FATHER BLOCKS WIFE ROOM
-> FATHER: “I CERTAINLY THOUGHT YOU UTTERLY HATED HER”
-> FATHER ADMITS GIVING WIFE TO COMPANION / OFFERS SISTER
-> NOT-SAMSON CLAIMS BLAMELESSNESS FOR HARMING PHILISTINES
-> CATCHES 300 FOXES -> TAIL PAIRS + TORCHES -> RELEASES
-> PHILISTINE GRAIN/SHOCKS/OLIVES BURN
-> REPORT IDENTIFIES FATHER'S WIFE TRANSFER AS CAUSE
-> PHILISTINES BURN WIFE + FATHER
-> NOT-SAMSON REVENGE/GREAT SLAUGHTER -> ETAM CAVE
-> PHILISTINES CAMP JUDAH TO BIND NOT-SAMSON
-> 3000 JUDAH MEN BIND/DELIVER HIM UNDER NO-ATTACK/NO-KILL TERMS
-> SPIRIT ATTRIBUTION -> ROPES FALL
-> FRESH DONKEY JAWBONE -> 1000 MEN STRUCK
-> JAWBONE THROWN / PLACE NAMED
-> THIRST/PRAYER -> GOD SPLITS HOLLOW -> WATER -> REVIVAL
-> NOT-SAMSON JUDGES 20 YEARS
```

## Judges 15:1–3 — THE HATE MODEL TRANSFER FORM

At wheat harvest, NOT-SAMSON visits his wife with a young goat and announces entry to her room. Her father refuses. He says:

**“I MOST CERTAINLY THOUGHT YOU UTTERLY HATED HER; THEREFORE I GAVE HER TO YOUR COMPANION.”**

He offers the younger, allegedly more beautiful sister instead. NOT-SAMSON's prior observable State is angry departure to his father's house; no speech, message or other mental carrier states that he hates his wife. The father asserts private hate as fact and uses it as the transfer premise. CrackFlix has heard this mental bullshit before:

**SKIP -> S154-E001-JDG14: YOU DIDN'T TELL ME, SO I KNOW YOUR PRIVATE FEELINGS.**

Captain zones out, then pokes the mental-model boil, licks his finger, says **“YOINK!”**, and leaves. The wife remains transferred.

NOT-SAMSON says this time he will be blameless regarding the Philistines when he harms them. This is his self-classification, not an externally verified liability rule.

## Judges 15:4–5 — 300-FOX AGRICULTURAL INTERFACE

NOT-SAMSON catches 300 Joe-faced foxes, pairs tails, places one torch between each pair, lights them and releases the foxes into Philistine standing grain. Shocks, standing grain and olive groves burn. The source does not supply capture time, animal-control mechanism, injury State, exact field owners or fire geometry; none is invented.

The producing grievance retained by the chapter is one Timnite father's transfer of one wife. The performed harm is allocated across Philistine agricultural property without a source-supplied owner participation or collective-liability bridge. This repeats `S127`:

**SKIP -> S127-E001-JOS7: ONE PERSON DID IT. THE GROUP PAYS.**

After the crop destruction completes the mismatch, Captain pokes the collective invoice boil, licks his finger, says **“YOINK!”**, and walks away. The fields continue burning.

## Judges 15:6–8 — IDENTIFY ONE ACTOR, BURN TWO PEOPLE

Philistines ask who acted. The answer identifies NOT-SAMSON and explicitly gives the cause: the Timnite father took NOT-SAMSON's wife and gave her to the companion. The Philistines then burn both the wife and her father.

The report addresses the father's transfer act. No act by the daughter performing or authorizing that transfer is supplied. A second collective-liability occurrence completes:

**SKIP -> S127-E002-JDG15: IDENTIFIED ACTOR / ADDITIONAL PERSON PAYS.**

Captain zones out, pokes the new boil after both deaths are narrated, licks his finger, says **“YOINK!”**, and leaves. Nothing changes.

NOT-SAMSON announces revenge followed by cessation, strikes them hip and thigh with a great slaughter, then lives in NOT-ETAM's rock cave. Later Philistine retaliation is a new intervening act, so “after that I will cease” is not falsely treated as an unconditional forever statement.

## Judges 15:9–13 — THREE THOUSAND DELIVERY STAFF

Philistines camp in NOT-JUDAH and spread through NOT-LEHI. They tell Judah they came to bind NOT-SAMSON and do to him as he did to them. Three thousand Judah men descend to the cave, cite Philistine rule and ask what he has done. He says, **“AS THEY DID TO ME, SO I HAVE DONE TO THEM.”** The collective “they” claim remains his speech; it does not erase the named father/wife/companion acts.

Judah says it will bind and deliver him. NOT-SAMSON requires an oath that Judah will not attack him. They promise secure binding and delivery but no killing, bind him with two new ropes, and bring him from the rock. The binding is expressly permitted under his requested boundary; no betrayal contradiction is invented.

## Judges 15:14–17 — FRESH NOT-DONKEY JAWBONE

At NOT-LEHI the Philistines shout. The narrator attributes mighty Spirit arrival. The ropes become like burned flax and fall from NOT-SAMSON's hands. He finds a fresh donkey jawbone, takes it and strikes one thousand men. The jawbone retains a Joe-faced donkey-origin identity without becoming a living donkey.

NOT-SAMSON performs the jawbone/heaps wordplay, throws it away, and the place is called NOT-RAMATH-LEHI, with the source footnote retaining “hill” and “jawbone.” No battle duration, casualty detail or jawbone material mechanism is invented.

## Judges 15:18–20 — GREAT DELIVERY, ZERO DRINKS PACKAGE

Very thirsty, NOT-SAMSON calls on NOT-THE-LORD. He attributes the great deliverance to NOT-THE-LORD through the servant's hand and asks whether he will now die of thirst and fall into uncircumcised hands.

The narrator says God splits the hollow place in NOT-LEHI. Water comes out; NOT-SAMSON drinks, his spirit returns and he revives. The site is called NOT-EN-HAKKORE “to this day.” His question is not a categorical death prediction, so no crack is manufactured.

NOT-SAMSON judges NOT-ISRAEL twenty years during Philistine days. The chapter does not state that Philistine rule ended, so “begin to save” remains compatible with the retained partial process.

## Character and world-ledger changes

- NOT-SAMSON gains rejected wife visit, fox-fire crop destruction, retaliatory slaughter, Etam residence, Judah delivery, rope release, jawbone victory, thirst/water revival and twenty-year judgeship.
- Wife and father close as burned/dead; companion's later State remains unresolved.
- `S154-E002-JDG15` retains the father's unsupported hate model.
- `S127-E002-JDG15` and `S127-E003-JDG15` retain two distinct one-act/broader-liability occurrences.

## Bullshit pass

Issue `JDG-015 / 300-FOX WIRING DIAGRAM MISSING`. NOT-SAMSON deploys **150 DUAL-TAIL TORCH PORTS**, NOT-PHILISTINES run **IDENTIFIED-ACTOR PLUS-ONE EXECUTION**, and NOT-LEHI supplies **POST-THOUSAND-MAN ROCK WATER**. Foundation unchanged.

## FIR verification

- FILTER: Judges 15 only, with wife-transfer parent from Judges 14; all 20 markers retained in order.
- ISOLATE: return/refusal, hate model, crop attack, two retaliations, Judah binding, jawbone battle, thirst/water and judgeship.
- RECONSTRUCT: one repeated mental occurrence and two distinct repeated collective-liability occurrences; later retaliation prevents a false cessation contradiction.
- VERIFY: exactly three cracks, three SKIPs and three YOINKs; no fox mechanics, liability law, betrayal, unconditional cease, death prediction or divine mechanism invented; publication held.

## Required comic states

1. Goat visit, room refusal, father's hate claim/wife-transfer admission/sister offer; mental SKIP and first YOINK.
2. 300 Joe-faced fox capture/pair/torch/release and crop destruction; collective SKIP and second YOINK.
3. Actor/cause report, wife+father burning; next collective SKIP and third YOINK.
4. NOT-SAMSON revenge/slaughter and Etam cave.
5. Philistine Judah camp and three-thousand-man cave dialogue.
6. No-attack/no-kill terms, two new ropes and delivery.
7. Spirit attribution, rope release, Joe-faced donkey jawbone and thousand-man result/place naming.
8. Thirst/prayer, split hollow/water/drinking/revival/place naming.
9. Twenty-year judgeship.
10. Held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; source identities remain exact in evidence/machine ledgers.
- Every living human and fox is Joe-faced; the donkey jawbone retains Joe-face origin. NOT-THE-LORD and Spirit remain unrendered.
- Three SKIPs, pointing exactly to `S154-E001-JDG14`, `S127-E001-JOS7`, and `S127-E002-JDG15`. Exactly three boilless, causally-null Captain occurrences after the respective contradictions complete: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent hatred, fox capture/control mechanics, crop-owner participation, daughter's transfer act, liability law, unconditional cease, Judah betrayal, jawbone physics, water mechanism or end of Philistine rule.
- Publication held. `CHB-JDG-016` excluded.

*shrug*

OK.
