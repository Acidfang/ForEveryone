# CRACKHEAD JUDGES 12

## Title page

**NOT-EPHRAIM: “YOU DIDN'T CALL US.” NOT-JEPHTHAH: “I CALLED YOU.” SAY NOT-SHIBBOLETH. “NOT-SIBBOLETH.”**

Source parent: Judges chapter 12, verses 1–15, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-012/job.json` and `source.usfm`. Parent: Judges 11.

Display-origin layer: exact source identities remain in evidence. Comic display uses **NOT-EPHRAIM JOE**, **NOT-JEPHTHAH JOE**, **NOT-GILEAD JOE**, **NOT-ISRAEL**, **NOT-IBZAN JOE**, **NOT-ELON JOE**, **NOT-ABDON JOE**, **NOT-HILLEL JOE**, and `NOT-` place labels.

CrackFlix routing: new `S150-E001-JDG12`, no SKIP, for incompatible call/no-call accounts; new `S151-E001-JDG12`, no SKIP, for denied Ephraimite identity against the source-addressed fugitive and acted-on pronunciation marker. Exactly two causally-null post-closure YOINKs.

## Causal foundation

```text
NOT-EPHRAIM GATHERS/CROSSES NORTH
-> “WHY DIDN'T YOU CALL US? WE WILL BURN YOUR HOUSE AROUND YOU”
-> NOT-JEPHTHAH: “I CALLED; YOU DIDN'T SAVE ME”
-> GILEAD/EPHRAIM FIGHT -> GILEAD WINS
-> GILEAD TAKES JORDAN FORDS
-> FUGITIVE REQUESTS CROSSING
-> DENIES EPHRAIM IDENTITY
-> NOT-SHIBBOLETH PRONUNCIATION TEST -> NOT-SIBBOLETH
-> SEIZURE/KILLING -> 42,000 EPHRAIM FALL
-> NOT-JEPHTHAH JUDGES SIX YEARS -> DIES/BURIED
-> NOT-IBZAN 30 SONS / 30 DAUGHTERS OUT / 30 DAUGHTERS IN / SEVEN YEARS
-> NOT-ELON TEN YEARS
-> NOT-ABDON 40 SONS + 30 GRANDSONS / 70 DONKEY COLTS / EIGHT YEARS
-> EACH DIES/BURIED
```

## Judges 12:1–3 — THE CALL LOG HAS TWO OWNERS

NOT-EPHRAIM's men gather, pass northward and tell NOT-JEPHTHAH:

**“WHY DID YOU FIGHT AMMON AND NOT CALL US TO GO WITH YOU? WE WILL BURN YOUR HOUSE AROUND YOU WITH FIRE!”**

NOT-JEPHTHAH answers:

**“I AND MY PEOPLE WERE IN GREAT STRIFE. WHEN I CALLED YOU, YOU DIDN'T SAVE ME.”**

He says he saw they would not save him, risked his life, crossed against Ammon, and NOT-THE-LORD delivered Ammon. He asks why they now came to fight him.

The two accounts address the same proposed call with incompatible States. No messenger, timing, recipient, failed delivery or independent witness is supplied to decide the call State. After both accounts exist, Captain pokes the call-log boil, licks his finger, says **“YOINK!”**, and walks away without looking back. The armed confrontation continues unchanged.

## Judges 12:4–6 — NOT-SHIBBOLETH BORDER CONTROL

NOT-JEPHTHAH gathers Gilead's men and fights NOT-EPHRAIM. Gilead strikes Ephraim after the reported insult that Gileadites are Ephraimite fugitives amid Ephraim and Manasseh.

Gilead takes the Jordan fords. When an Ephraimite fugitive asks to cross, Gilead asks whether he is Ephraimite. He says:

**“NO.”**

They require **“SHIBBOLETH.”** He says **“SIBBOLETH,”** because the source says he cannot pronounce it correctly. They seize and kill him at the ford. The chapter reports 42,000 of Ephraim fell at that time.

The source-addressed fugitive denies the same identity for which the checkpoint tests him, then supplies the pronunciation State used to classify him. After the denial/test mismatch completes, Captain pokes the border boil, licks his finger, says **“YOINK!”**, and leaves. He changes no crossing, seizure, death or count.

No claim is added that pronunciation is universally accurate, that every death followed the identical dialogue, or that the test reveals motive or ancestry by mechanism.

## Judges 12:7 — SIX YEARS

NOT-JEPHTHAH judges NOT-ISRAEL six years, dies and is buried in the cities of NOT-GILEAD. The plural burial-place wording remains exact; no single city or tomb is invented.

## Judges 12:8–10 — 30 OUT, 30 IN

NOT-IBZAN of NOT-BETHLEHEM judges NOT-ISRAEL. He has 30 sons, sends 30 daughters outside his clan, and brings 30 daughters from outside for his sons. He judges seven years, dies and is buried at NOT-BETHLEHEM. The relationship inventory is retained without invented names, pairings, ceremonies or motives.

## Judges 12:11–12 — TEN YEARS

NOT-ELON the Zebulunite judges NOT-ISRAEL ten years, dies and is buried at NOT-AIJALON in NOT-ZEBULUN. No additional acts are supplied.

## Judges 12:13–15 — 40 + 30 = 70 DONKEYS

NOT-ABDON son of NOT-HILLEL the Pirathonite judges NOT-ISRAEL. He has 40 sons and 30 sons' sons who ride 70 donkey colts. He judges eight years, dies and is buried at NOT-PIRATHON in Ephraim's Amalekite hill country. Every depicted living person and donkey is Joe-faced. The arithmetic is inventory, not contradiction or inferred status.

## Character and world-ledger changes

- NOT-JEPHTHAH gains Ephraim conflict, six-year judgeship, death and plural-Gilead-cities burial closure.
- NOT-EPHRAIM gains incompatible call accusation, battle defeat, ford filtering and 42,000-fall State.
- NOT-IBZAN, NOT-ELON and NOT-ABDON receive bounded judge/family/death/burial histories.
- `S150-E001-JDG12` retains incompatible call claims without choosing a hidden truth.
- `S151-E001-JDG12` retains identity denial, pronunciation response and the source's acted-on classification without generalizing the test.

## Bullshit pass

Issue `JDG-012 / CALL LOG UNAVAILABLE`. The NOT-JORDAN ford installs **NOT-SHIBBOLETH VOICE AUTH**, NOT-IBZAN runs **30 OUT / 30 IN CLAN EXCHANGE**, and NOT-ABDON deploys **70-DONKEY FAMILY TRANSPORT**. Foundation unchanged.

## FIR verification

- FILTER: Judges 12 only; all 15 verse markers retained in order.
- ISOLATE: Ephraim confrontation, incompatible call claims, battle/ford test/count, and four judge closures.
- RECONSTRUCT: two new contradiction types; no repeated-series match proven, therefore no SKIP.
- VERIFY: exactly two cracks and two post-closure YOINKs; numeric/family inventories remain non-cracks; no hidden call truth, pronunciation mechanism or generalized checkpoint accuracy invented; publication held.

## Required comic states

1. NOT-EPHRAIM gathers/crosses, accuses non-call and threatens house fire.
2. NOT-JEPHTHAH says he called and was not saved; first YOINK after both claims.
3. Gilead/Ephraim fight, Gilead victory and ford control.
4. Fugitive identity denial, NOT-SHIBBOLETH request and NOT-SIBBOLETH response; second YOINK.
5. Source count and NOT-JEPHTHAH six-year/death/burial closure.
6. NOT-IBZAN's 30 sons, 30 daughters out, 30 daughters in, seven years and burial.
7. NOT-ELON's ten years and burial.
8. NOT-ABDON's 40 sons, 30 grandsons, 70 Joe-faced donkey colts, eight years and burial.
9. Held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; exact names remain in source citations and machine identities.
- Every living human, donkey, plant or organism is Joe-faced. Do not render NOT-THE-LORD as a body, face or silhouette.
- No SKIP. Exactly two boilless, causally-null Captain occurrences after the respective contradictions complete: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent which call claim is true, a missing messenger, motives, universal pronunciation accuracy, forty-two-thousand identical tests, marriage pairings or unreported judge acts.
- Publication held. `CHB-JDG-013` excluded.

*shrug*

OK.
