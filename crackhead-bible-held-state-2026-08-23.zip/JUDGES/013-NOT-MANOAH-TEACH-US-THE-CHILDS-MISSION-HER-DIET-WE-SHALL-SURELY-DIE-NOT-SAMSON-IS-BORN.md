# CRACKHEAD JUDGES 13

## Title page

**NOT-MANOAH: “TEACH US THE CHILD'S WAY AND MISSION.” NOT-ANGEL: “HER DIET.” “WE SHALL SURELY DIE.” NOT-SAMSON IS BORN.**

Source parent: Judges chapter 13, verses 1–25, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-013/job.json` and `source.usfm`. Parent: Judges 12.

Display-origin layer: exact source names remain in evidence. Comic display uses **NOT-MANOAH JOE**, **NOT-MANOAH'S WIFE JOE**, **NOT-THE-LORD'S-ANGEL JOE**, **NOT-SAMSON JOE**, **NOT-ISRAEL**, **NOT-PHILISTINES**, and `NOT-` place labels. NOT-THE-LORD remains an unrendered attributed Root; the explicitly appeared messenger remains a separate visible Joe-faced identity.

CrackFlix routing: new `S152-E001-JDG13`, no SKIP, for a child-way/mission question answered only with maternal restrictions; new `S153-E001-JDG13`, no SKIP, for “we shall surely die” followed by the promised child's birth. Exactly two causally-null post-closure YOINKs.

## Causal foundation

```text
NOT-ISRAEL EVIL -> DELIVERED TO PHILISTINES 40 YEARS
-> CHILDLESS WOMAN -> VISIBLE MESSENGER PROMISES SON
-> MATERNAL FOOD/DRINK RESTRICTIONS + CHILD RAZOR/NAZIRITE RULE
-> CHILD WILL BEGIN SAVE
-> WOMAN REPORTS TO NOT-MANOAH
-> NOT-MANOAH REQUESTS MESSENGER RETURN/CHILD INSTRUCTION
-> GOD-LISTENED ATTRIBUTION -> MESSENGER RETURNS TO WOMAN
-> NOT-MANOAH ASKS CHILD WAY/MISSION
-> MESSENGER REPEATS MATERNAL RESTRICTIONS
-> GOAT OFFER REDIRECTED TO NOT-THE-LORD
-> NAME QUESTION / INCOMPREHENSIBLE ANSWER
-> OFFERING + FLAME ASCENT -> COUPLE FALLS
-> NOT-MANOAH: “WE SHALL SURELY DIE”
-> WIFE CITES RECEIVED OFFERING/SHOWING/TELLING
-> WOMAN BEARS/NAMES NOT-SAMSON -> CHILD GROWS/BLESSED
-> SPIRIT-MOVEMENT ATTRIBUTION BEGINS
```

## Judges 13:1–5 — THE CHILD STARTS BEFORE THE CHILD

NOT-ISRAEL again does evil in NOT-THE-LORD's sight. The narrator says NOT-THE-LORD delivers them into Philistine hands for forty years.

NOT-MANOAH is a Danite from NOT-ZORAH. His unnamed wife is barren and childless. NOT-THE-LORD'S-ANGEL appears to her and says she will conceive and bear a son. He tells her to drink no wine or strong drink and eat no unclean thing. No razor is to touch the son's head; he will be a Nazirite to God from the womb and will begin to save NOT-ISRAEL from the Philistines.

The visible messenger is rendered as an awesome Joe-faced man because the source later gives the woman's observed face-description and Manoah's man-address. This does not render or merge NOT-THE-LORD.

## Judges 13:6–11 — SEND THE SAME MAN AGAIN

The woman tells NOT-MANOAH a man of God came to her, with a face like God's angel, very awesome. She says she did not ask his origin and he did not tell his name. She reports the conception, dietary restrictions and Nazirite duration “from the womb to the day of his death.” Her report remains her speech; the added death endpoint is not silently inserted into the messenger's first recorded speech.

NOT-MANOAH entreats NOT-THE-LORD to send the man again to teach them what to do to the child. The narrator says God listens. The messenger returns to the woman while she sits in a field and NOT-MANOAH is absent. She runs, tells him, and leads him back. NOT-MANOAH asks whether he is the prior man. He says, **“I AM.”**

## Judges 13:12–14 — CHILD MISSION CUSTOMER SERVICE

NOT-MANOAH asks:

**“WHEN YOUR WORDS HAPPEN, WHAT SHALL THE CHILD'S WAY OF LIFE AND MISSION BE?”**

NOT-THE-LORD'S-ANGEL answers that the woman must beware of everything already stated: nothing from the vine, no wine or strong drink, no unclean thing, and observance of all commands to her.

The requested object is the child's future way and mission. The supplied answer addresses only the woman's present restrictions and gives no child-way or mission relation. After the response completes, Captain pokes the non-answer boil, licks his finger, says **“YOINK!”**, and walks away without looking back. The restrictions remain active.

## Judges 13:15–21 — GOAT, NAME, FLAME

NOT-MANOAH asks the messenger to stay while they prepare a young goat for him. The messenger says detention will not make him eat their bread; if a burnt offering is prepared it must be offered to NOT-THE-LORD. The narrator says NOT-MANOAH did not yet know he was NOT-THE-LORD'S angel.

NOT-MANOAH asks the messenger's name so they may honor him when his words occur. The messenger asks why and says the name is incomprehensible, with the source footnote retaining “or, wonderful.” No hidden name is invented.

NOT-MANOAH offers the goat and meal offering on a rock to NOT-THE-LORD. The messenger does an amazing thing while the couple watches: as altar flame rises, he ascends in the flame. They fall face-down. The messenger appears no more, and NOT-MANOAH then knows the messenger's role. The visible messenger, flame, ascent and witnesses are retained; no combustion mechanism, destination or identity merger is supplied.

## Judges 13:22–25 — WE SHALL SURELY DIE / BABY ARRIVES

NOT-MANOAH tells his wife:

**“WE SHALL SURELY DIE, BECAUSE WE HAVE SEEN GOD.”**

She replies that if NOT-THE-LORD intended to kill them, he would not have received their offerings, shown these things or told them these things at that time. Her reasoning remains her stated model; no private divine intention is promoted to narrator fact.

The woman then bears a son and names him NOT-SAMSON. Her continued life and completed birth contradict the prediction that both shall surely die from the encounter. After the birth makes the mismatch observable, Captain pokes the surely-die boil, licks his finger, says **“YOINK!”**, and walks away. Mother and child continue unchanged.

NOT-SAMSON grows and NOT-THE-LORD blesses him. The narrator says NOT-THE-LORD's Spirit begins to move him in NOT-MAHANEH-DAN between NOT-ZORAH and NOT-ESHTAOL. No Spirit body, movement mechanism or later Samson act is imported.

## Character and world-ledger changes

- NOT-MANOAH and his wife gain messenger encounters, offering witness, incompatible death prediction and child-birth closure.
- NOT-THE-LORD'S-ANGEL JOE gains two appearances, bounded instructions, food refusal/offering redirect, withheld name and flame ascent; he remains distinct from NOT-THE-LORD.
- NOT-SAMSON receives conception promise, birth/name, growth, blessing and first Spirit-movement attribution; Philistine saving remains future.
- `S152-E001-JDG13` retains question/answer object mismatch. `S153-E001-JDG13` closes only when birth proves at least one member of “we shall surely die” survived.

## Bullshit pass

Issue `JDG-013 / CHILD SUPPORT TICKET`. NOT-MANOAH opens **MISSION REQUEST**, receives **MATERNAL DIET FAQ**, then submits a goat to **ROCK-BASED FLAME ASCENSION**. NOT-SAMSON enters production under **NO RAZOR / BEGIN SAVE — DELIVERY LATER**. Foundation unchanged.

## FIR verification

- FILTER: Judges 13 only; all 25 markers retained in order.
- ISOLATE: oppression, two messenger appearances, promise/restrictions, question/response, offering/flame ascent, death prediction, birth and Spirit beginning.
- RECONSTRUCT: visible messenger is source-renderable and Joe-faced but not merged with LORD; two new contradiction types, no proven repeat and no SKIP.
- VERIFY: exactly two cracks/two YOINKs; wife's report additions stay attributed; no divine body, hidden name, intention, ascent mechanism or future saving invented; publication held.

## Required comic states

1. Forty-year Philistine delivery and childless NOT-MANOAH household.
2. First NOT-ANGEL JOE appearance: promise, maternal restrictions, child razor/Nazirite/begin-save rule.
3. Wife's bounded report and NOT-MANOAH's return request.
4. Messenger returns to wife; she fetches NOT-MANOAH; identity confirmation.
5. Child way/mission question versus maternal-rule response; first YOINK.
6. Goat request, eating refusal and offering redirect.
7. Name request/incomprehensible answer, rock offering and flame ascent.
8. “We shall surely die” and wife's stated counter-relation.
9. NOT-SAMSON birth/name; second YOINK; growth/blessing/Spirit beginning.
10. Held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; exact source identities remain in citations and machine ledgers.
- Every visible living human and the explicitly appeared messenger is Joe-faced. NOT-THE-LORD and Spirit remain unrendered; do not merge messenger with LORD.
- No SKIP. Exactly two boilless, causally-null Captain occurrences after their contradictions complete: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent wife/Manoah names beyond source, messenger origin/name, God form, divine intention, flame mechanism/destination, future Samson acts, or whether every reported instruction was spoken off-record.
- Publication held. `CHB-JDG-014` excluded.

*shrug*

OK.
