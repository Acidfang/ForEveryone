# CRACKHEAD JUDGES 11

## Title page

**NOT-JEPHTHAH: DRIVEN OUT. BROUGHT BACK AS HEAD. “I WILL SAVE YOU NO MORE.” DELIVERED. “WHATEVER COMES OUT.” “YOU TROUBLED ME.”**

Source parent: Judges chapter 11, verses 1–40, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-011/job.json` and `source.usfm`. Parent: Judges 10.

Display-origin layer: evidence retains Jephthah, Gilead, Tob, Israel, Ammon, Mizpah and LORD exactly. Story display uses **NOT-JEPHTHAH JOE**, **NOT-GILEAD**, **NOT-TOB**, **NOT-ISRAEL**, **NOT-AMMON**, **NOT-MIZPAH** and **NOT-THE-LORD**. The unnamed daughter is **NOT-JEPHTHAH'S DAUGHTER JOE**.

CrackFlix routing: new `S149-E001-JDG11`, no SKIP, for “I will save you no more” followed by attributed delivery; `S012-E003-JDG11` uses `SKIP -> S012-E002-GEN27` for producing an outcome and blaming another actor for it. Exactly two causally-null post-closure YOINKs.

## Causal foundation

```text
NOT-JEPHTHAH DRIVEN OUT -> LIVES NOT-TOB -> OUTLAWS GO WITH HIM
AMMON WAR -> GILEAD ELDERS FETCH HIM -> CHIEF/HEAD CONDITION
-> PEOPLE MAKE HIM HEAD/CHIEF
-> LAND CLAIM EXCHANGE -> AMMON KING DOES NOT LISTEN
-> LORD SPIRIT ATTRIBUTION -> NOT-JEPHTHAH PASSES THROUGH
-> UNRESTRICTED HOUSE-DOOR VOW
-> NOT-THE-LORD DELIVERS AMMON -> 20-CITY DEFEAT
-> ONLY DAUGHTER COMES OUT
-> NOT-JEPHTHAH: “YOU BROUGHT ME LOW / TROUBLE ME”
-> TWO MONTHS -> RETURN -> FATHER DOES ACCORDING TO VOW
-> YEARLY FOUR-DAY CUSTOM
```

## Judges 11:1–11 — OUTCAST HEADHUNT

NOT-JEPHTHAH is identified as a mighty Gileadite man, son of a prostitute and fathered by Gilead. Gilead's wife's sons grow up, drive him out and deny him inheritance because he is another woman's son. He flees to NOT-TOB; outlaws join him and go out with him.

When Ammon makes war, Gilead's elders fetch him and ask him to become chief for the fight. NOT-JEPHTHAH tells the elders they hated him and drove him from his father's house, then asks why they came during distress. They answer that they have turned to him now so he can fight and become head. Under his delivery condition they agree, travel with him, and the people make him head and chief. The rejection and later recruitment are retained changed States; no unspoken rule or motive is invented, so no crack is declared here.

## Judges 11:12–28 — THREE-HUNDRED-YEAR LAND TICKET

NOT-JEPHTHAH and Ammon's king exchange messenger-carried claims. The king says NOT-ISRAEL took Ammonite land during the Egypt departure and requests peaceful restoration. NOT-JEPHTHAH answers with a historical route: refused passage by Edom and Moab, route around their borders, Sihon's refusal and attack, attributed delivery of Sihon, and Israelite possession of Amorite land. He invokes each side possessing what its god gives, compares Balak's non-fight, cites 300 years of residence, denies wrongdoing and calls on NOT-THE-LORD as judge. Ammon's king does not listen. Claims remain speaker-attributed; no independent map verdict or divine form is invented.

## Judges 11:29–33 — SAVE-NO-MORE DELIVERY

The narrator says NOT-THE-LORD's Spirit comes on NOT-JEPHTHAH. He crosses Gilead and Manasseh toward Ammon, then vows that if Ammon is delivered into his hand, whatever comes from his house doors to meet him on peaceful return will belong to NOT-THE-LORD and be offered as a burnt offering.

NOT-JEPHTHAH fights. The narrator explicitly says NOT-THE-LORD delivers Ammon into his hand. He strikes from Aroer toward Minnith across twenty cities and to Abelcheramim, and Ammon is subdued.

This completes the relation carried from Judges 10:

```text
NOT-THE-LORD: “I WILL SAVE YOU NO MORE.”
NEXT CHAPTER: NOT-THE-LORD DELIVERS THE OPPRESSOR INTO ISRAEL'S HEAD'S HAND
NO RETRACTION OR SCOPE BRIDGE SUPPLIED
```

Captain pokes the completed no-more-delivery boil, licks his finger, says **“YOINK!”**, and walks away without looking back. The victory remains unchanged.

## Judges 11:34–40 — WHATEVER WALKED OUT

NOT-JEPHTHAH returns to NOT-MIZPAH. His only child, his daughter, comes out from his house to meet him with tambourines and dances. He tears his clothes and says:

**“ALAS, MY DAUGHTER! YOU HAVE BROUGHT ME VERY LOW. YOU ARE ONE OF THOSE WHO TROUBLE ME. I OPENED MY MOUTH TO NOT-THE-LORD, AND I CAN'T GO BACK.”**

His own vow selected **whatever comes out**. Her observable act satisfies that selection. His next speech assigns the trouble to her while retaining his own producing vow. CrackFlix has heard that bullshit before:

**SKIP -> S012-E002-GEN27: I DID IT. YOUR FAULT.**

SKIP explains nothing and changes nothing. Captain zones out, then after the blame relation completes pokes the boil, licks his finger, says **“YOINK!”**, and walks away.

The daughter tells him to do according to his vow, asks for two months with companions to mourn her virginity in the mountains, leaves, returns, and the father does with her according to his vow. The source does not state the physical procedure; no killing, fire, survival, death or mechanism is invented. It states she was a virgin and that Israel's daughters yearly celebrate her four days.

## Character and world-ledger changes

- NOT-JEPHTHAH moves from expelled son to NOT-TOB leader, Gilead head/chief, messenger claimant, victorious fighter and vow performer.
- The Judges 10 save-no-more frontier closes as `S149-E001-JDG11` when attributed delivery occurs.
- The vow/blame occurrence joins existing series S012 as `S012-E003-JDG11`; `SKIP` points to the prior episode and causes nothing.
- The daughter's return and the father's according-to-vow act are retained without supplying the missing physical procedure.

## Bullshit pass

Issue `JDG-011 / NOT-YOUR-ORIGIN`. NOT-GILEAD installs **OUTCAST EXECUTIVE RECALL**, NOT-JEPHTHAH submits **300-YEAR LAND RECEIPT**, and the house door runs **WHATEVER OUTPUT SELECTOR — NO TYPE CHECKING**. Foundation unchanged.

## FIR verification

- FILTER: Judges 11 only, joined only to the explicit Judges 10 open save-no-more parent; all 40 markers retained in order.
- ISOLATE: expulsion/recruitment, land-message exchange, attributed Spirit/delivery, vow, daughter return and exact according-to-vow close.
- RECONSTRUCT: save-no-more/delivery is new S149; vow/result blame is existing S012 and therefore SKIP-addressed.
- VERIFY: exactly two cracks, one SKIP pointer, two post-closure YOINKs, no invented divine form, motive, land verdict or vow procedure; publication held.

## Required comic states

1. NOT-JEPHTHAH's source-defined birth relation, expulsion, NOT-TOB life and followers.
2. War-driven elder retrieval, dialogue and installed head/chief State.
3. Both messenger claims and the retained historical route/300-year argument.
4. Spirit attribution, crossing and exact unrestricted house-door vow.
5. Attributed delivery and twenty-city defeat; `S149-E001-JDG11` YOINK.
6. Daughter exits with tambourine/dance; only-child State.
7. “You trouble me” after his retained vow; `SKIP -> S012-E002-GEN27`; second YOINK.
8. Two-month request/departure/return, source-only according-to-vow act and yearly four-day custom.
9. Held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; source names remain exact in evidence and ledger identities.
- Every living human, animal, plant or organism is Joe-faced. Do not render NOT-THE-LORD or Spirit as a body, face, silhouette or anatomy.
- Exactly one SKIP, pointing to `S012-E002-GEN27`. Exactly two boilless, causally-null Captain occurrences after their respective contradictions complete: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent prostitute motive, elder/brother identity bridge, land ownership verdict, divine mechanism, vow intent, daughter's consent beyond exact speech, or the physical act hidden by “did according to his vow.”
- Publication held. `CHB-JDG-012` excluded.

*shrug*

OK.
