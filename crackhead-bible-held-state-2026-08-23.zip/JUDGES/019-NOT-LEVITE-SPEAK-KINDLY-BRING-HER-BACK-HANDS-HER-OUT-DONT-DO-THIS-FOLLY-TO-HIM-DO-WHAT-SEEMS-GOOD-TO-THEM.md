# CRACKHEAD JUDGES 19

## Title page

**NOT-LEVITE: “I'LL SPEAK KINDLY AND BRING HER BACK.” HANDS HER OUT. NOT-HOST: “DON'T DO THIS FOLLY TO HIM. DO WHAT SEEMS GOOD TO THESE TWO WOMEN.”**

Source parent: Judges chapter 19, verses 1–30, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-019/job.json` and `source.usfm`. Parent: Judges 18.

Display-origin layer: exact source identities remain in evidence. Comic display uses **NOT-LEVITE JOE**, **NOT-CONCUBINE JOE**, **NOT-FATHER-IN-LAW JOE**, **NOT-SERVANT JOE**, **NOT-OLD-HOST JOE**, **NOT-HOST-DAUGHTER JOE**, **NOT-GIBEAH JOES**, and all receiving **NOT-ISRAEL JOES**. Both donkeys are Joe-faced. Every living person is Joe-faced. NOT-THE-LORD remains unrendered.

CrackFlix routing: repeated protected-target substitution `S014-E002-JDG19` uses `SKIP -> S014-E001-GEN19`; new kind-return/hand-out `S162-E001-JDG19` has no SKIP. Exactly two causally-null post-closure YOINKs.

## Causal foundation

```text
NO KING
-> NOT-LEVITE TAKES NOT-CONCUBINE FROM NOT-BETHLEHEM-JUDAH
-> SOURCE CLASSIFIES HER ACT / SHE LEAVES TO FATHER HOUSE 4 MONTHS
-> NOT-LEVITE TRAVELS TO SPEAK KINDLY / BRING HER BACK
-> SHE BRINGS HIM IN / FATHER REJOICES
-> THREE DAYS EAT/DRINK/STAY
-> DAY 4 DEPARTURE -> BREAD -> STAY NIGHT
-> DAY 5 DEPARTURE -> FOOD UNTIL DECLINE -> REFUSES ANOTHER NIGHT
-> TRAVELS PAST NOT-JEBUS BECAUSE FOREIGNER/NON-ISRAEL
-> SUNSET AT NOT-GIBEAH / NO ONE TAKES THEM IN
-> NOT-OLD-HOST QUESTIONS / OFFERS HOUSE + ALL NEEDS
-> FODDER / FOOT WASH / EAT/DRINK
-> CITY MEN SURROUND/BEAT DOOR / DEMAND MALE GUEST
-> HOST CALLS ACT WICKED/FOLLY AGAINST MALE GUEST
-> HOST OFFERS DAUGHTER + CONCUBINE FOR SAME CROWD'S CHOICE
-> CROWD REFUSES HOST
-> NOT-LEVITE GRABS CONCUBINE / HANDS HER OUT
-> CROWD SEXUALLY ABUSES HER THROUGH NIGHT / RELEASES AT DAWN
-> SHE FALLS AT HOST DOOR / HANDS ON THRESHOLD
-> NOT-LEVITE OPENS TO LEAVE / ORDERS HER UP / NO ANSWER
-> CARRIES HER HOME
-> KNIFE / TWELVE-PART DIVISION / SENDS THROUGH ISRAEL
-> RECIPIENTS: NEVER DONE/SEEN SINCE EGYPT EXIT / CONSIDER+COUNSEL+SPEAK
```

## Judges 19:1–4 — SPEAK KINDLY / BRING HER BACK

With no king in NOT-ISRAEL, a Levite living in Ephraim's farther hill country takes a concubine from NOT-BETHLEHEM-JUDAH. The source says she “played the prostitute against him,” then went to her father's house and stayed four months. No partner, payment, location, timing, consent history or motive is supplied; the source classification is retained without expansion.

Her husband travels with a servant and two Joe-faced donkeys. His stated purpose is:

**TO SPEAK KINDLY TO HER, TO BRING HER AGAIN.**

She brings him into her father's house. Her father rejoices, keeps him three days, and they eat, drink and stay. Her acceptance of return, private conversation and terms remain unstated.

## Judges 19:5–10 — DEPARTURE RETRY LOOP

On day four the Levite rises early to leave. His father-in-law asks him to strengthen his heart with bread and says afterward he may go. They eat and drink; the father asks him to stay the night. The Levite rises to depart, is urged and stays.

On day five he again rises early. The father asks him to eat and remain until the day declines. When the Levite rises again, the father points out evening and asks for one more night followed by an early departure. This time the Levite refuses and leaves with concubine, servant and two saddled donkeys.

The repeated hospitality/delay sequence changes only when the Levite refuses. No coercion, intoxication, lost-day motive or consent claim is invented.

## Judges 19:11–15 — FOREIGN CITY REJECTED / NOT-ISRAEL CITY SELECTED

Near NOT-JEBUS/NOT-JERUSALEM late in the day, the servant proposes staying in the Jebusite city. The Levite refuses because it is a foreigner city not of Israel's children and chooses NOT-GIBEAH or NOT-RAMAH. They pass on; sunset reaches them at Benjaminite NOT-GIBEAH.

They sit in the street because nobody takes them into a house. The Levite never explicitly promises that an Israelite city will be safer or hospitable, so the later outcome is not converted into an invented failed-safety claim. The identity-based routing choice and its observed result remain visible without mind-reading.

## Judges 19:16–21 — ONE OUT-OF-TOWN HOST

An old man returns from field work. He is from Ephraim's hill country and lives in NOT-GIBEAH; the local men are Benjamites. He sees the traveler and asks origin/destination.

The Levite reports the Bethlehem-to-Ephraim route, says he is going to the LORD's house, and says no one has taken him in. He lists straw/feed for donkeys and bread/wine for the people, saying nothing is lacking. The old man says peace, offers to supply every need, forbids street sleeping, brings him home, feeds the donkeys, and the group washes feet, eats and drinks.

Going to the LORD's house is human travel speech. No LORD act, command or protection claim occurs.

## Judges 19:22–24 — DON'T DO THAT TO HIM / DO IT TO THEM

While the household makes merry, certain source-labelled wicked city men surround the house, beat the door and demand that the male guest be brought out for sex.

The old host goes out and says:

**“DON'T ACT SO WICKEDLY. SINCE THIS MAN CAME INTO MY HOUSE, DON'T DO THIS FOLLY.”**

He immediately offers his virgin daughter and the guest's concubine, saying he will bring them out so the crowd may humble them and do what seems good to them, while repeating that the threatened act must not be done to the man.

This is the exact retained `S014` target-substitution root:

**SKIP -> S014-E001-GEN19: DON'T DO THAT TO THEM. DO IT TO THESE.**

Captain zones out. After the host completes the offer, Captain pokes the protected-target boil, licks his finger, says **“YOINK!”**, and walks away. The crowd continues at the door. No consent from either woman is supplied or inferred.

## Judges 19:25–28 — KIND RETURN MISSION / HAND HER OUT

The crowd refuses to listen to the host. The Levite then grabs his concubine and brings her out to them. The source narrates sexual abuse through the night and release at dawn. This reconstruction remains non-graphic while preserving the acts, actors and absence of consent.

The woman reaches the host's door at dawn and falls with her hands on the threshold. In the morning the Levite opens the doors to go his way, sees her, and says:

**“GET UP, AND LET'S GET GOING!”**

No one answers. He places her on a donkey and returns home.

The Levite's chapter-entry purpose was to speak kindly and bring her back. After completing the return, he personally grabs and hands her to the threatening crowd, then prepares to leave in the morning. No intervening act by her authorizes that handoff. New CrackFlix series:

**S162: SPEAK KINDLY AND BRING HER BACK / PERSONALLY HAND HER OUT.**

After his handoff and the resulting non-response State complete the mismatch, Captain pokes the kind-return boil, licks his finger, says **“YOINK!”**, and walks away. The journey home continues.

The source does not explicitly pronounce the woman dead before the later knife act. Her exact death time and State at the threshold, transport and arrival remain unresolved. No medical examination, pulse check, response interpretation or cause-of-death allocation is invented.

## Judges 19:29–30 — TWELVE-PART NATIONAL MESSAGE

At home the Levite uses a knife, divides the concubine into twelve pieces and sends them throughout Israel's borders. The source supplies no messenger count, recipient mapping, transport method, packaging, written explanation or spoken national allegation in this chapter.

All who see say no such deed has been done or seen from Israel's Egypt exit to that day, and direct one another to consider, take counsel and speak. “Such a deed” has multiple immediately retained acts—the night abuse, the Levite's handoff, and the later division/sending—and the speakers do not isolate which combination they mean. Their classification remains speech; it is not silently narrowed to only the crowd's act.

Judges 20 contains a later Levite report. It is excluded here and cannot retroactively supply the missing message or erase his Judges 19 producing acts.

## Character and world-ledger changes

- NOT-LEVITE gains concubine-return mission, repeated father-in-law hospitality, Jebus rejection/Gibeah selection, host lodging, concubine handoff, morning non-response, return transport, twelve-part division and national dispatch.
- NOT-CONCUBINE gains four-month father-house stay, return journey, non-consensual handoff/abuse, threshold fall, non-response, transport, division and dispatch; exact death time remains unresolved.
- NOT-OLD-HOST gains hospitality, male-guest protection speech and daughter/concubine substitution offer.
- `S014-E002-JDG19` retains the repeated protected-man/offered-women target substitution.
- `S162-E001-JDG19` retains the kind-return purpose versus personal handoff.

## Bullshit pass

Issue `JDG-019 / HOSPITALITY ROUTER FAILURE`. Four rounds of **ONE MORE MEAL** push departure into the evening, the **ISRAELITE-ONLY LODGING FILTER** selects a street with zero hosts until one outsider arrives, and NOT-LEVITE converts **SPEAK KINDLY / BRING BACK** into **HANDOFF / TWELVE-REGION MESSAGE FORMAT**. Foundation unchanged.

## FIR verification

- FILTER: Judges 19 only; all 30 markers retained in order; Judges 20 report excluded.
- ISOLATE: relationship departure/return, hospitality delay, route selection, Gibeah lodging, door threat/substitution, Levite handoff, threshold/non-response, division/dispatch and recipient speech.
- RECONSTRUCT: one exact repeated `S014` occurrence and one new `S162` root.
- VERIFY: exactly two cracks, one SKIP and two YOINKs; no sexual detail beyond source-required act class, consent, motive, safety promise, death time, medical State, dispatch logistics or later-report meaning invented; publication held.

## Required comic states

1. Concubine at father house four months; Levite's speak-kindly/bring-back purpose and arrival.
2. Three-day stay and day-four bread/night delay.
3. Day-five meal/delay request, refusal and late departure.
4. NOT-JEBUS rejected by identity; sunset and empty NOT-GIBEAH street.
5. Old host questions, provisions stated, hospitality/meal completed.
6. Crowd surrounds/door demand; host calls act wicked against man then offers daughter/concubine; S014 SKIP and first YOINK.
7. Crowd refusal; Levite grabs/hands out concubine; non-graphic all-night abuse/release.
8. Threshold fall, morning departure attempt, “get up,” no response; second YOINK.
9. Donkey transport home, non-graphic twelve-part division and national dispatch.
10. Recipients say never done/seen and request consideration/counsel/speech.
11. Held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; source identities remain exact in evidence and machine ledgers.
- Every living human and both donkeys are Joe-faced. NOT-THE-LORD remains unrendered.
- Keep sexual violence and body division non-graphic. Preserve actors, sequence, coercion and missing consent without explicit anatomy or sensational detail.
- One SKIP points exactly to `S014-E001-GEN19`. Exactly two boilless, causally-null Captain occurrences after the addressed contradictions complete: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent sex-work details, reconciliation consent, father-in-law coercion, alcohol effect, Israelite-safety promise, women's consent, death timing/cause, medical check, body-dispatch logistics, recipient mapping or Judges 20 report content.
- Publication held. `CHB-JDG-020` excluded.

*shrug*

OK.
