# CRACKHEAD JUDGES 6

## Title page

**MIDIAN EATS EVERYTHING. GIDEON HIDES WHEAT IN A WINEPRESS. FIRE ROCK. BAAL, DEFEND YOURSELF. FLEECE: JUST ONCE AGAIN.**

Source parent: Judges chapter 6, verses 1–40, ENGWEBP USFM. Prepared evidence:
`.chapter-work/CHB-JDG-006/job.json` and `source.usfm`. Parent: Judges 5.

CrackFlix routing:

- new `S141-E001-JDG6`, no SKIP: Baal treated as god / humans demand Gideon's death to defend Baal;
- new `S142-E001-JDG6`, no SKIP: fire sign and first fleece sign already completed / reverse fleece requested as “just this once.”

## Causal foundation

```text
EVIL -> MIDIAN 7 YEARS
-> DENS/CAVES/STRONGHOLDS
-> SOW -> MIDIAN/AMALEK/EAST DESTROY INCREASE
-> NO SUSTENANCE/LIVESTOCK -> LOW -> CRY
-> PROPHET CARRIES EXODUS/LAND/NONLISTENING SPEECH

MESSENGER SITS UNDER OAK
-> GIDEON HIDES WHEAT IN WINEPRESS
-> MIGHTY VALOR GREETING / GIDEON QUESTIONS
-> LORD SENDS / GIDEON LEAST-POOREST CLAIM
-> WITH-YOU PROMISE -> SIGN REQUEST
-> GOAT/CAKES/BROTH -> ROCK -> STAFF TOUCH
-> FIRE CONSUMES / MESSENGER DEPARTS
-> GIDEON FEARS DEATH -> LORD SAYS PEACE/NO DEATH
-> ALTAR: LORD IS PEACE

SAME NIGHT -> DESTROY BAAL ALTAR/ASHERAH
-> BUILD LORD ALTAR/OFFER FATHER'S BULL
-> GIDEON + 10 SERVANTS DO IT AT NIGHT
-> CITY INVESTIGATES -> DEMANDS GIDEON DIE
-> JOASH: IF BAAL IS GOD LET BAAL CONTEND
-> JERUB-BAAL NAME

MIDIAN/AMALEK/EAST ASSEMBLE
-> SPIRIT ON GIDEON -> TRUMPET/MESSENGERS -> TRIBES GATHER
-> FLEECE TEST 1 WET/ALL GROUND DRY -> BOWL WATER
-> “JUST THIS ONCE” FLEECE TEST 2 DRY/ALL GROUND DEW
-> BOTH TESTS COMPLETE
```

## Judges 6:1–10 — SEVEN YEARS OF HARVEST DELETION

Israel does evil; the narrator attributes seven-year delivery to Midian. Israel
makes mountain dens, caves and strongholds. Whenever Israel sows, Midian,
Amalek and eastern peoples encamp, destroy increase to Gaza, and leave no
sustenance, sheep, ox or donkey. Their people, livestock, tents and unnumbered
camels arrive like locusts. Israel is brought low and cries.

The LORD sends an unnamed prophet. The prophet carries first-person LORD speech:
Egypt/bondage exit, delivery from Egyptians and all oppressors, people driven
out, land given, Amorite gods not to be feared, and Israel did not listen. This
is a carrier speech occurrence, not a replay of the Exodus or land transfer.

## Judges 6:11–18 — MIGHTY VALOR IN THE WINEPRESS

The LORD's messenger comes and sits under Joash's oak at Ophrah. Gideon beats
wheat in a winepress to hide it from Midian. The messenger appears and calls
him a mighty man of valor with the LORD.

Gideon asks why the oppression happened if the LORD is with “us,” where the
reported wonders are, and says the LORD has cast Israel off and delivered it to
Midian. The source then says the LORD looks at Gideon and commands him to go in
his might, save Israel, and says he has been sent. Gideon calls his family the
poorest in Manasseh and himself least in his father's house. The LORD promises
presence and says Gideon will strike Midian as one man.

Singular “with you,” Gideon's plural “with us,” messenger/LORD carrier changes,
valor, might, poverty and family rank are retained without invented identity,
wealth, psychology or mechanism.

Gideon requests a sign that the speaker is speaking with him and asks the
speaker to wait while he brings a present. The speaker agrees to wait.

## Judges 6:19–24 — FIRE FROM THE ROCK

Gideon prepares a young goat, unleavened cakes from one ephah of meal, meat in a
basket and broth in a pot. The messenger of God directs meat/cakes onto a rock
and broth poured out. Gideon complies. The LORD's messenger touches the food
with the staff; fire rises from the rock, consumes meat and cakes, and the
messenger leaves Gideon's sight.

Gideon then says he has seen the LORD's messenger face to face and fears the
result. The LORD says peace, do not fear, and Gideon will not die. Gideon builds
an altar called **THE LORD IS PEACE**, retained at Ophrah “to this day.”

The messenger may be shown as a living Joe-faced messenger. God/LORD is never
given that face or any visible form. Fire origin mechanics remain unresolved.

## Judges 6:25–32 — BAAL'S HUMAN SUPPORT DESK

That night the LORD commands Gideon to take his father's second bull, seven
years old; destroy his father's Baal altar and adjacent Asherah; build an
orderly LORD altar on the stronghold; offer the bull using cut Asherah wood.

Gideon takes ten servants and performs the acts. The narrator states he fears
his household and city men and therefore does it at night rather than day. This
supplied attribution is retained; no further motive is invented.

In the morning city men observe the broken Baal altar, cut Asherah and offered
bull. They inquire, identify Gideon, and demand Joash bring his son out to die
because Gideon broke Baal's altar and cut Asherah.

Joash exposes the completed relation:

```text
CITY MEN: BAAL IS TREATED AS GOD
CITY MEN: HUMANS MUST KILL GIDEON TO DEFEND BAAL
JOASH: WILL YOU CONTEND FOR / SAVE HIM?
JOASH: IF HE IS A GOD, LET HIM CONTEND FOR HIMSELF
```

Only after both States coexist, permanently boilless Captain pokes the city
support boil, licks his finger, says **“YOINK!”**, and walks away without
looking back. He does not defend Gideon, Baal or anyone.

Gideon is named Jerub-Baal—let Baal contend—because he broke the altar. No Baal
appearance, speech, contention, city execution or Gideon death occurs.

## Judges 6:33–35 — TRUMPET AND GATHERING

Midian, Amalek and eastern peoples assemble, cross and camp in Jezreel. The
narrator says the LORD's Spirit comes on Gideon. Gideon blows a trumpet;
Abiezer gathers. His messengers gather Manasseh, Asher, Zebulun and Naphtali.
No divine body or internal Spirit mechanism is rendered.

## Judges 6:36–40 — JUST THIS ONCE, AFTER THE OTHER ONCES

Gideon addresses God: if Israel will be saved by his hand as spoken, he will
place wool fleece on the floor; dew on fleece only with all ground dry will let
him know. It occurs. Gideon rises, presses the fleece and wrings a bowl full of
water.

This follows the earlier fire-from-rock sign requested to know who spoke.
Gideon now asks not to provoke anger and says he will speak **“but this once”**
and make a trial **“just this once”**: fleece dry only, all ground dewy. God does
so that night.

```text
SIGN 1: FIRE FROM ROCK / MESSENGER DEPARTS
SIGN 2: FLEECE WET / ALL GROUND DRY
GIDEON: JUST THIS ONCE
SIGN 3: FLEECE DRY / ALL GROUND DEWY
```

Only after the reverse test completes, Captain pokes the just-once boil, licks
his finger, says **“YOINK!”**, and walks away without looking back. The fleece,
dew and coming battle remain unchanged.

## Character and world-ledger changes

- Gideon gains wheat-hiding, messenger encounter, food-sign, altar, Jerub-Baal,
  mobilization and fleece-test Moments without inferring private State beyond
  the narrator's explicit fear attribution.
- Prophet, LORD messenger, God/LORD speech and human messenger roles stay
  addressably distinct; none is silently merged.
- Joash, city men, ten servants, gathered tribes and Midian coalition receive
  observed relational edges.
- `SCRIPTURE-GOD-JDG6` preserves carrier and direct-speech boundaries.
- `S141-E001-JDG6` and `S142-E001-JDG6` are the only cracks; Captain remains
  permanently boilless and causally useless.

## Bullshit pass

Issue `JDG-006 / WINEPRESS WHEAT PRIVACY MODE`. Midian runs **HARVEST DELETE**,
the messenger opens **VALOR DETECTED**, the rock uses **BROTH-COOLED FIRE PORT**,
Baal's altar displays **CONTACT HUMAN SUPPORT**, and fleece testing ships as
**DEW A/B v3: JUST THIS ONCE**. Foundation unchanged.

## FIR verification

- FILTER: Judges chapter 6 only; all 40 markers retained in order.
- ISOLATE: oppression/cry, prophet carrier, Gideon encounter, first sign,
  altar replacement, city response, mobilization and two fleece trials.
- RECONSTRUCT: unanswered questions, future victory and divine mechanisms are
  not completed States; messenger/God identities are not invented.
- VERIFY: exactly two new cracks, no SKIP, two post-closure YOINKs, no divine
  form, publication held.

## Required comic states

1. Seven-year Midian harvest/livestock deletion and Israel's hiding/cry.
2. Prophet carries Exodus/land/non-listening speech.
3. Messenger under oak; Gideon hides wheat; valor greeting and questions.
4. Send/save/presence exchange; first sign request.
5. Food preparation, rock instructions, staff touch, fire, departure.
6. Gideon fear; LORD peace/no-death speech; Peace altar.
7. Night Baal/Asherah destruction and replacement offering.
8. City investigation/death demand; Joash exposes Baal support contradiction;
   first `YOINK!`; Jerub-Baal name.
9. Enemy assembly, Spirit attribution, trumpet and tribal gathering.
10. First fleece condition and completed bowl of water.
11. “Just this once” reverse fleece and completed result; second `YOINK!`.
12. Held lineage page.

## Production boundary

- Every depicted living human, animal or plant is Joe-faced. Face-like
  non-divine objects may also receive Joe's face.
- The unnamed prophet and LORD messenger may be Joe-faced living carriers.
  Never render God/LORD/Spirit as face, form, body, silhouette or anatomy.
- No SKIP. Exactly two permanently boilless, causally-null Captain occurrences
  after closure: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent messenger/God identity, divine/fire/dew mechanisms, private
  motives, Baal action, unperformed executions or future Midian victory.
- Publication held. `CHB-JDG-007` excluded.

*shrug*

OK.
