# CRACKHEAD JUDGES 17

## Title page

**NOT-MICAH: “I TOOK YOUR SILVER.” NOT-MOTHER: “MAY THE LORD BLESS YOU. I DEDICATE IT TO THE LORD. MAKE IDOLS.” NOT-LEVITE: “I'LL BE YOUR FATHER.” BECOMES HIS SON.**

Source parent: Judges chapter 17, verses 1–13, ENGWEBP USFM. Prepared evidence: `.chapter-work/CHB-JDG-017/job.json` and `source.usfm`. Parent: Judges 16.

Display-origin layer: exact source identities remain in evidence. Comic display uses **NOT-MICAH JOE**, **NOT-MICAH'S MOTHER JOE**, **NOT-SILVERSMITH JOE**, **NOT-MICAH'S SON JOE**, and **NOT-LEVITE JOE**. Every living person is Joe-faced. The carved image, molten image and teraphim may carry Joe faces as face-bearing objects without establishing life. NOT-THE-LORD remains unrendered.

CrackFlix routing: new curse/blessing `S156-E001-JDG17`, new dedicated/prohibited-work `S157-E001-JDG17`, and new reversed-family-role `S158-E001-JDG17`; none has a prior episode, so there is no SKIP. Exactly three causally-null post-closure YOINKs.

## Causal foundation

```text
MOTHER'S 1100 SILVER TAKEN -> MOTHER UTTERS CURSE
-> NOT-MICAH CONFESSES TAKING / SILVER PRESENT
-> MOTHER ASKS LORD TO BLESS CONFESSED TAKER
-> 1100 RESTORED
-> MOTHER DEDICATES SILVER TO LORD FOR CARVED + MOLTEN IMAGE
-> SILVER RETURNED TO NOT-MICAH
-> 200 TO SILVERSMITH -> TWO IMAGE OBJECTS -> NOT-MICAH HOUSE
-> HOUSE OF GODS / EPHOD / TERAPHIM
-> NOT-MICAH CONSECRATES SON AS PRIEST
-> NO KING / EVERYONE RIGHT IN OWN EYES
-> JUDAH-FAMILY LEVITE LEAVES NOT-BETHLEHEM-JUDAH FOR PLACE
-> ARRIVES NOT-MICAH HOUSE
-> NOT-MICAH OFFERS FATHER+PRIEST ROLE / 10 SILVER YEAR+CLOTHES+FOOD
-> LEVITE ACCEPTS / DWELLS
-> LEVITE BECOMES AS ONE OF NOT-MICAH'S SONS
-> NOT-MICAH CONSECRATES LEVITE AS PRIEST
-> NOT-MICAH PREDICTS LORD GOOD BECAUSE LEVITE PRIEST
```

## Judges 17:1–2 — CURSE THE TAKER / BLESS THE TAKER

In Ephraim's hill country, NOT-MICAH tells his mother that the eleven hundred silver pieces taken from her—the taking about which she uttered a curse in his hearing—are with him:

**“I TOOK IT.”**

His mother replies:

**“MAY THE LORD BLESS MY SON!”**

The retained curse addresses the taker. NOT-MICAH identifies himself as that taker. His mother then routes a LORD blessing to the same confessed person without retracting, replacing or narrowing the curse. New CrackFlix series:

**S156: CURSE WHOEVER TOOK IT / YOU TOOK IT / MAY THE LORD BLESS YOU.**

After the blessing completes the opposed speech States, Captain pokes the curse-and-blessing boil, licks his finger, says **“YOINK!”**, and walks away. The silver remains with NOT-MICAH until restored.

The source does not state when the taking happened, why NOT-MICAH returns it, what the curse said, whether the mother knew the taker's identity earlier, or any spiritual effect from either utterance.

## Judges 17:3–4 — DEDICATED TO NOT-THE-LORD / IMAGE FACTORY

NOT-MICAH restores all eleven hundred pieces to his mother. She says:

**“I MOST CERTAINLY DEDICATE THE SILVER TO THE LORD FROM MY HAND FOR MY SON, TO MAKE A CARVED IMAGE AND A MOLTEN IMAGE.”**

She says she will restore it to him. When he restores the money, she takes two hundred pieces and gives them to a silversmith. The silversmith makes a carved image and molten image, which are installed in NOT-MICAH's house.

The retained Exodus 20 rule prohibits making an idol or image and bowing to or serving it. Here the mother expressly identifies the LORD as the dedication recipient while specifying image manufacture as the dedication's purpose; the objects are actually made and placed in a house of gods. Unlike `S086`, no authority command creates an exception. This is a distinct root:

**S157: DEDICATE IT TO THE AUTHORITY BY PERFORMING THE AUTHORITY'S PROHIBITED ACT.**

After the images are manufactured, Captain pokes the dedicated-prohibition boil, licks his finger, says **“YOINK!”**, and leaves. The images remain in the house.

The mother dedicates “the silver” after receiving eleven hundred; only two hundred are routed to the silversmith. The source does not route the remaining nine hundred. That absence remains unresolved and is not converted into theft, retention, spending or crack.

## Judges 17:5–6 — HOME RELIGION STARTER PACK

NOT-MICAH has a house of gods, makes an ephod and teraphim, and consecrates one of his sons as priest. The source footnote says teraphim were household idols that may have been associated with inheritance rights. “May have been” remains footnote possibility, not this household's proven purpose.

In those days there is no king in NOT-ISRAEL. Everyone does what is right in his own eyes. This is narrator classification; it does not establish that every person performs the same act or that absence of a king causes each event.

## Judges 17:7–9 — NOT-JUDAH FAMILY / NOT-LEVITE

A young man from NOT-BETHLEHEM-JUDAH, of Judah's family, is also source-identified as a Levite living there. He leaves the city looking for a place to live and reaches NOT-MICAH's house while traveling through Ephraim's hill country.

NOT-MICAH asks where he came from. The young man says he is a Levite of NOT-BETHLEHEM-JUDAH looking for a place to live. The Judah-family and Levite labels are both retained. No exclusivity rule, genealogy bridge or identity correction is supplied, so they are not falsely forced into a contradiction.

## Judges 17:10–12 — PLEASE BE MY FATHER / HE BECAME MY SON

NOT-MICAH offers:

**“DWELL WITH ME, AND BE TO ME A FATHER AND A PRIEST.”**

The wage is ten silver pieces per year, a suit of clothing and food. The Levite goes in and is content to dwell with NOT-MICAH. The source then states:

**“THE YOUNG MAN WAS TO HIM AS ONE OF HIS SONS.”**

No biological claim is inferred from either relational term. But the same pair changes from the hired young man being **father to NOT-MICAH** to being **as a son to NOT-MICAH**, with no supplied title definition or transition explaining the reversed direction. New CrackFlix series:

**S158: HIRED AS MY FATHER / BECAME AS MY SON.**

After the son-like State is narrated, Captain pokes the reversible-family-role boil, licks his finger, says **“YOINK!”**, and walks away. NOT-MICAH consecrates the Levite; he becomes priest and remains in NOT-MICAH's house. NOT-MICAH's earlier son-priest is not said to die, leave or lose every other role; later priest allocation remains exact to the Levite without inventing the son's reaction.

## Judges 17:13 — LEVITE INSTALLED / GOOD PREDICTED

NOT-MICAH says:

**“NOW I KNOW THAT THE LORD WILL DO GOOD TO ME, SINCE I HAVE A LEVITE AS MY PRIEST.”**

This is NOT-MICAH's forecast and causal model. Judges 17 supplies no later good/bad outcome against which to close it. It remains speech, not divine promise, narrator fact or completed contradiction. No God line or act occurs in the chapter beyond human LORD-addressed curse, blessing, dedication and prediction.

## Character and world-ledger changes

- NOT-MICAH gains silver-taking confession, restoration, house of gods, ephod/teraphim, son-priest installation, Levite contract, Levite consecration and good-outcome forecast.
- NOT-MICAH's mother gains curse history, blessing, eleven-hundred dedication claim and two-hundred silversmith transfer.
- NOT-LEVITE gains Bethlehem departure, place search, father/priest contract, son-like household State and priest installation.
- `S156-E001-JDG17` retains curse and blessing addressed to the confessed taker.
- `S157-E001-JDG17` retains LORD-dedication through prohibited image manufacture.
- `S158-E001-JDG17` retains father-to-employer / son-to-employer reversed relational labels.

## Bullshit pass

Issue `JDG-017 / HOME PRIEST SUBSCRIPTION`. NOT-MICAH deploys **ELEVEN-HUNDRED-SILVER CURSE REVERSAL**, purchases a **TWO-HUNDRED-SILVER NOT-THE-LORD IDOL PACKAGE**, and upgrades from **SON PRIEST** to **FATHER-SON LEVITE AS A SERVICE**. Nine hundred pieces remain outside the routing diagram. Foundation unchanged.

## FIR verification

- FILTER: Judges 17 only, with retained Exodus 20 rule used only for the performed-image relation; all 13 markers retained in order.
- ISOLATE: confession/blessing, silver restoration/dedication/manufacture, home shrine/son priest, Levite migration, contract/consecration and forecast.
- RECONSTRUCT: three new contradiction roots; no unsupported reuse and no missing-silver crack.
- VERIFY: exactly three cracks, zero SKIPs and three YOINKs; no curse content/effect, missing-900 disposition, teraphim purpose, identity exclusivity, biological father/son claim, displaced-son reaction or divine promise invented; publication held.

## Required comic states

1. Mother reports missing eleven hundred and curse history; NOT-MICAH confesses; mother blesses; first YOINK.
2. Full restoration and mother's LORD-dedication/image-purpose speech.
3. Two hundred to silversmith, carved/molten images completed and installed; second YOINK; missing nine hundred simply unshown/unresolved.
4. House of gods, ephod/teraphim and son consecrated priest.
5. No-king/everyone-own-eyes narrator transition.
6. NOT-LEVITE leaves NOT-BETHLEHEM-JUDAH, arrives and states identity/search.
7. Father/priest wage offer and acceptance.
8. Son-like State, third YOINK, Levite consecration/priest installation.
9. NOT-MICAH's LORD-good forecast held as speech.
10. Held lineage page.

## Production boundary

- Every rendered biblical identity/place label carries `NOT-`; source identities remain exact in evidence and machine ledgers.
- Every living human is Joe-faced. Face-bearing image/teraphim objects may carry Joe's face without adding life or agency. NOT-THE-LORD remains unrendered.
- No SKIP occurs because all three series are new. Exactly three boilless, causally-null Captain occurrences after the relevant contradictions complete: **“YOINK!”**, poke, lick, walk away, no look back.
- Do not invent curse wording/effect, theft motive, remaining-nine-hundred route, teraphim purpose, Judah/Levite exclusivity, biological father/son relation, prior-son displacement, LORD response or future good outcome.
- Publication held. `CHB-JDG-018` excluded.

*shrug*

OK.
