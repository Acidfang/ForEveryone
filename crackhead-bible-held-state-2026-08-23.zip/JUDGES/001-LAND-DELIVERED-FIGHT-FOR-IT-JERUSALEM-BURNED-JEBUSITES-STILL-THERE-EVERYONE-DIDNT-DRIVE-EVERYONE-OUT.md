# CRACKHEAD JUDGES 1

## Title page

**LAND DELIVERED. FIGHT FOR IT. JERUSALEM TAKEN AND BURNED. JEBUSITES STILL THERE. THE REST DIDN'T DRIVE THE REST OUT.**

Source parent: Judges chapter 1, verses 1–36, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JDG-001/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/024-CHOOSE-WHOM-YOU-WILL-SERVE-YOU-CANT-SERVE-HIM-COVENANT-MADE-THREE-BURIALS.md`.

CrackFlix routing:

- `S070-E012-JDG1`, `SKIP -> S070-E011-JOS21`: land delivered before the required campaign and incomplete expulsion;
- `S130-E004-JDG1`, `SKIP -> S130-E003-JOS24`: all peoples driven out / extensive retained peoples remain;
- new `S135-E001-JDG1`, no SKIP: Jerusalem taken, struck and burned / Jebusites still inhabit Jerusalem.

## Causal foundation

```text
AFTER JOSHUA'S DEATH
-> ISRAEL ASKS WHO FIGHTS FIRST
-> LORD: JUDAH; LAND DELIVERED
-> JUDAH ASKS SIMEON TO JOIN
-> BEZEK / ADONI-BEZEK / JERUSALEM / HILLS / SOUTH / LOWLAND
-> OVERLAPPING HEBRON / DEBIR / ACHSAH MATERIAL
-> KENITES RELOCATE
-> ZEPHATH-HORMAH + GAZA / ASHKELON / EKRON
-> HILL PEOPLE DRIVEN OUT
-> VALLEY PEOPLE NOT DRIVEN OUT: IRON CHARIOTS

BENJAMIN: JEBUSITES REMAIN IN JERUSALEM
JOSEPH: BETHEL TAKEN THROUGH ENTRANCE INFORMANT; INFORMANT BUILDS NEW LUZ
MANASSEH / EPHRAIM / ZEBULUN / ASHER / NAPHTALI: PEOPLE REMAIN
DAN: CONFINED TO HILLS
SOME REMAINING PEOPLE -> FORCED LABOR
```

## Judges 1:1–4 — AFTER JOSHUA, DELIVERED LAND STILL NEEDS A CAMPAIGN

After Joshua's completed death, Israel asks the LORD who should first fight the
Canaanites. The LORD directly answers: Judah goes first; the land has been
delivered into Judah's hand.

Judah then asks Simeon to join the fight in Judah's lot in exchange for future
help in Simeon's lot. Simeon joins. Judah goes up; the LORD delivers Canaanites
and Perizzites, and the joined force strikes ten thousand at Bezek.

The delivered-land statement precedes the requested ally, campaign and later
failure to remove valley inhabitants. This is `S070-E012-JDG1`, the same
delivery-before-required-process type as `S070-E011-JOS21`.

CrackFlix displays `SKIP -> S070-E011-JOS21`. It omits the repeated explanation
while the world continues. After the chapter supplies the incomplete expulsion
state, Captain Crackhead pokes the Joe-faced boil, sees a crack crystal, licks
his finger, says **“YOINK!”**, and walks away. He changes nothing.

## Judges 1:5–8 — ADONI-BEZEK AND JERUSALEM

The force finds, fights and defeats Adoni-Bezek. He flees; they pursue, catch
him and cut off his thumbs and big toes. He states that seventy similarly
mutilated kings scavenged under his table and attributes his present treatment
to God returning what he did. His seventy-king history and divine causal claim
remain his speech. He is brought to Jerusalem and dies there.

Judah fights Jerusalem, takes it, strikes it with the sword and sets the city
on fire. Those are completed acts.

## Judges 1:9–18 — SOUTHERN CAMPAIGN AND RETAINED OVERLAPS

Judah fights hill-country, South and lowland Canaanites. The Hebron action
names Sheshai, Ahiman and Talmai. The following Debir/Kiriath Sepher challenge,
Othniel's capture, Achsah marriage, field request and upper/lower spring grant
overlap the retained Joshua 15 occurrence. They join that historical parent;
they are not silently duplicated as a second daughter, marriage or spring
grant.

The Kenites leave the City of Palms with Judah, move to the wilderness south
of Arad and live with the people. Judah and Simeon strike Zephath, utterly
destroy it and call it Hormah. Judah takes Gaza, Ashkelon and Ekron with their
borders.

## Judges 1:19–21 — HILLS OUT, VALLEY NOT; JERUSALEM STILL INHABITED

The LORD is with Judah. Judah drives out hill-country inhabitants but cannot
drive out valley inhabitants because they have iron chariots. The source gives
the equipment relation; it does not explain how divine presence, delivered
land and iron-chariot resistance interact.

Hebron is given to Caleb and the three Anak sons are driven out, retaining the
Joshua 15 overlap.

Then Benjamin does not drive the Jebusites from Jerusalem; they dwell with
Benjamin in Jerusalem to the narrator's day. Earlier in this same chapter,
Judah took Jerusalem, struck it by sword and burned it. No survivor, return,
partial-city, rebuilding or time bridge is supplied. This is new
`S135-E001-JDG1: TOOK AND BURNED JERUSALEM / JEBUSITES STILL LIVE THERE`.

There is no SKIP. After the contradiction closes, Captain repeats his
causally useless poke, finger lick and departure: **“YOINK!”**

## Judges 1:22–26 — BETHEL, AN ENTRANCE AND ANOTHER LUZ

Joseph's house goes against Bethel with attributed LORD presence. Watchers spy
the city, formerly called Luz, and ask a man leaving it to show the entrance in
exchange for kind treatment. He shows it. They strike the city but release him
and his family.

The man goes to Hittite land, builds another city and names it Luz. The old
Bethel/Luz and new Hittite-land Luz remain distinct place histories.

## Judges 1:27–36 — THE PEOPLE WHO REMAIN

Manasseh does not drive inhabitants from Beth Shean, Taanach, Dor, Ibleam,
Megiddo and their towns. The Canaanites persist in dwelling there. When Israel
becomes strong, it places them under forced labor but does not utterly expel
them.

Ephraim does not drive Gezer's Canaanites; they live among Ephraim. Zebulun
does not drive Kitron and Nahalol inhabitants; they remain and become forced
labor. Asher does not drive seven named populations and instead lives among
the Canaanite inhabitants. Naphtali does not drive Beth Shemesh or Beth Anath
inhabitants, lives among them and subjects them to forced labor.

Amorites force Dan into the hill country and refuse valley access. Amorites
remain at Mount Heres, Aijalon and Shaalbim until Joseph's house prevails and
subjects them to forced labor. Their border is stated from Akrabbim's ascent,
the rock and upward.

Joshua 24 immediately retained the people's claim that the LORD drove out all
peoples. Judges 1 now records multiple named peoples still resident, controlling
access or placed under labor. This is `S130-E004-JDG1`.

CrackFlix displays `SKIP -> S130-E003-JOS24`. The explanation is skipped, not
the events. After the occurrence closes, Captain pokes, licks his finger,
says **“YOINK!”**, and leaves. All residence, labor and territorial states
remain identical.

“Could not drive out,” “did not drive out,” “would dwell,” “lived among,”
“forced into hills,” “would not allow,” and “became forced labor” remain
separate observable relations. Labor control is not rewritten as expulsion,
and non-expulsion is not assigned an unspoken motive.

## Character and world-ledger changes

- Joshua's death is retained as the book-boundary parent;
- the first Judges inquiry and direct LORD reply are retained as God-only lines;
- Judah/Simeon alliance and every named campaign act remain ordered;
- Adoni-Bezek's history and divine interpretation remain his speech;
- Joshua 15 Hebron/Debir/Achsah material is joined as overlap, not duplicated;
- `S070-E012-JDG1` and `S130-E004-JDG1` use exact same-type SKIP pointers;
- new `S135-E001-JDG1` has no SKIP;
- exactly three causally null post-closure YOINKs occur;
- every tribe's non-expulsion/residence/labor outcome retains its own verb and place;
- Captain remains permanently boilless and changes nothing;
- every living human, animal or plant Joe and every face-like non-divine chariot, city, severed-thumb counter, sword, fire, spring, border, labor ticket or map is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JUDGES — BOOK ONE / LAND DELIVERED, INSTALL MANUALLY`;
- ally dialog: `OWNERSHIP DETECTED / SECOND TRIBE REQUIRED`;
- iron-chariot warning: `LORD PRESENT / DRIVER NOT INSTALLED`;
- Jerusalem status: `TAKEN + BURNED + CURRENTLY OCCUPIED`;
- expulsion dashboard: `COULD NOT / DID NOT / WOULD NOT / LIVES HERE / PAYROLL ACTIVE`;
- Luz duplicator: `OLD LUZ -> BETHEL; NEW LUZ -> SOMEWHERE ELSE`;
- CrackFlix: `S070-E012 -> SKIP E011`; `S130-E004 -> SKIP E003`; `S135 PREMIERE`;
- barcode: `CHB-JDG1-36-3CRACKS-3YOINKS-HELD`.

## FIR verification

- all 36 verse markers are represented in order;
- Joshua death precedes the Judges inquiry and is not repeated;
- direct LORD speech is limited to the source reply;
- delivered land is not converted into completed possession;
- all campaigns, deaths, captures, releases, relocations and renames remain distinct;
- Joshua 15 overlap is joined without manufacturing duplicate lives/events;
- Jerusalem take/burn and later Jebusite residence retain both States without an invented bridge;
- every tribe/place non-expulsion outcome remains source-specific;
- forced labor is not equated with expulsion or motive;
- two repeated contradiction types have exact SKIP pointers; the new type has none;
- exactly three post-closure YOINKs occur with no causal effect;
- no divine form, missing survivor, return, motive or military mechanism is invented;
- publication remains held and unpublished.

Continuation required: Judges 2 brings the LORD's messenger from Gilgal,
states the covenant/non-expulsion charge, retells Joshua's death, records a new
generation and begins the judge/oppressor cycle without importing Judges 3.
