# CRACKHEAD NUMBERS 18

## Title page

**NO LAND INHERITANCE. TAKE THE TITHE AS INHERITANCE.**

**THEN TITHE THE TITHE.**

Source parent: Numbers chapter 18, verses 1–32, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-018/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/017-EVERYONE-WHO-APPROACHES-DIES-MOSES-JUST-CAME-BACK.md`.

CrackFlix routing: none. The chapter supplies distinct liability, access,
inheritance and transfer objects; no observable contradiction closes.

## Causal foundation

```text
AARON HOUSE
-> BEARS SANCTUARY INIQUITY
AARON + SONS
-> BEAR PRIESTHOOD INIQUITY

LEVITES JOIN AARON
-> TENT SERVICE / COMMAND SUPPORT
-> DO NOT APPROACH SANCTUARY VESSELS OR ALTAR

AARON + SONS
-> ALTAR + INSIDE-VEIL PRIESTHOOD
-> STRANGER APPROACH = DEATH RULE

ISRAEL HOLY GIFTS/FIRSTFRUITS/FIRSTBORN
-> PRIEST HOUSE PORTIONS
-> HUMAN + UNCLEAN FIRSTBORN REDEEMED
-> CLEAN HERD/FLOCK FIRSTBORN SACRIFICED / MEAT TO PRIESTS

PRIESTS/LEVITES: NO LAND PORTION
-> LORD / TITHES BECOME STATED INHERITANCE OBJECTS

ISRAEL TITHE
-> LEVITE SERVICE REWARD
-> LEVITE TAKES BEST TENTH OF RECEIVED TITHE
-> LORD WAVE OFFERING GIVEN TO AARON
-> REMAINDER MAY BE EATEN ANYWHERE BY LEVITE HOUSEHOLDS
```

## Numbers 18:1–7 — LIABILITY AND ACCESS MAP

The LORD speaks directly to Aaron. Aaron, his sons and his fathers' house bear
sanctuary iniquity; Aaron and his sons bear priesthood iniquity. The Levite
tribe is brought near to join and minister to Aaron while Aaron and sons remain
before the Tent of Testimony.

The service boundary is explicit:

- Levites keep Aaron's commands and whole-Tent duty;
- Levites do not approach sanctuary vessels or altar, preventing death for
  both Levites and priests;
- Levites keep Tent service and strangers do not approach them;
- Aaron and sons keep sanctuary/altar duty;
- Aaron and sons alone serve the altar and inside the veil;
- an unauthorized stranger who approaches the priesthood boundary is put to
  death.

The LORD calls the Levites a gift to Aaron while also saying they are dedicated
to the LORD for Tent service. Those are compatible recipient and purpose
relations, not a transfer contradiction. No violation or death occurs here.

## Numbers 18:8–14 — PRIEST HOUSE FOOD STREAMS

The LORD assigns Aaron stewardship and household portions from Israel's holy
gifts:

- meal, sin and trespass offerings remaining from fire are most holy and eaten
  by every eligible male;
- wave gifts go to Aaron's sons and daughters, with every clean household
  member eligible;
- best oil, wine and grain firstfruits go to Aaron;
- first-ripe land produce goes to clean household members;
- everything devoted in Israel goes to Aaron.

The source distinguishes most-holy male-only consumption from clean-household
wave/firstfruit consumption. It does not merge the eligibility rules. These are
standing allocations; no new offering receipt or meal is narrated.

## Numbers 18:15–19 — FIRSTBORN ROUTER AND SALT COVENANT

Everything opening the womb that is offered to the LORD belongs to Aaron's
line, but the route branches:

- human firstborn must be redeemed;
- unclean-animal firstborn must be redeemed;
- redemption begins from one month old at five sanctuary shekels, twenty gerahs
  per shekel;
- firstborn cow, sheep and goat are not redeemed because they are holy;
- their blood goes on the altar and fat burns as a pleasant-aroma offering;
- their meat belongs to the priest like wave breast and right thigh.

All wave offerings are a perpetual portion for Aaron's sons and daughters,
called a covenant of salt. The source supplies no salt mechanism or current
firstborn transaction.

## Numbers 18:20–24 — NO LAND / DIFFERENT INHERITANCE OBJECT

Aaron receives no inheritance or land portion among Israel. The LORD identifies
himself as Aaron's portion and inheritance.

The Levites also receive no land inheritance among Israel. Instead, all Israel's
tithe is assigned to them as inheritance and reward for Tent service. Ordinary
Israelites must not approach the Tent and incur sin/death; Levites perform the
service and bear its iniquity.

```text
LAND INHERITANCE = NONE
PRIEST PORTION = LORD + ASSIGNED HOLY GIFTS
LEVITE INHERITANCE = ISRAEL TITHE FOR TENT SERVICE
```

Because the nouns and transfer objects are explicitly separated, “no land
inheritance” does not conflict with “tithe as inheritance.”

## Numbers 18:25–32 — TITHE THE TITHE

The LORD tells Moses to instruct the Levites. When they receive Israel's tithe,
they must lift a tenth of that received tithe as a wave offering to the LORD.
The accounting treats that offering like threshing-floor grain and winepress
fullness.

The best/holy portion of every received gift is transferred to Aaron the priest:

```text
ISRAEL PRODUCE
-> ISRAEL TITHE TO LEVITES
-> BEST TENTH OF LEVITE RECEIPT TO LORD
-> LORD WAVE OFFERING GIVEN TO AARON
-> LEVITE REMAINDER = SERVICE REWARD
```

After lifting the best portion, Levites and households may eat the remainder
anywhere. They bear no sin from it when the best portion has been lifted. They
must not profane Israel's holy things, preventing death. No actual tithe receipt,
calculation, transfer, eating or violation is completed in this chapter.

## Character and world-ledger changes

- Aaron's house, Aaron/sons and Levites gain distinct liability scopes;
- Levite support and priest-only altar/veil boundaries remain exact;
- Levites are both an Aaron-directed gift and LORD-dedicated service group;
- most-holy male and clean-household food permissions remain separate;
- human/unclean firstborn redemption and clean herd/flock sacrifice branches
  remain separate;
- priests and Levites receive no land inheritance;
- priest holy portions and Levite tithes are distinct replacement allocations;
- tithe-of-tithe routes the best tenth from Levites through LORD to Aaron;
- all rules remain prospective with no new transfer occurrence;
- every living human, animal, plant and face-like Tent, altar, tithe or salt
  carrier is Joe-faced if shown;
- Captain is absent because no contradiction closes;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — SANCTUARY LIABILITY & PAYROLL ENGINE`;
- access matrix: `LEVITE SUPPORT / PRIEST ALTAR / STRANGER DEAD`;
- HR label: `LEVITES — GIFTED TO AARON, DEDICATED TO LORD, STILL WORKING`;
- priest pantry: `MOST HOLY MALES / CLEAN HOUSEHOLD GENERAL ADMISSION`;
- firstborn router: `REDEEM HUMAN + UNCLEAN / DO NOT REDEEM COW-SHEEP-GOAT`;
- land account: `0 HECTARES`;
- service account: `ALL ISRAEL TITHE`;
- recursive payment button: `TITHE THE TITHE`;
- credit note: `COUNTS AS GRAIN AND WINE EVEN THOUGH YOU RECEIVED IT`;
- barcode: `CHB-NUM18-32-LIABILITY-NOLAND-TITHEOFTITHE-NOCRACK-HELD`.

## FIR verification

- all 32 verse markers are represented in order;
- sanctuary, priesthood and Levite liability scopes remain distinct;
- Levite Tent service is not expanded into altar/vessel access;
- stranger death rule remains prospective and role-bounded;
- most-holy and clean-household consumption permissions are not merged;
- firstborn redemption amount/age and clean-animal exceptions remain exact;
- covenant-of-salt wording remains source attribution without mechanism;
- no-land inheritance remains distinct from LORD/holy-gift/tithe portions;
- Israel tithe, Levite reward, best tenth and Aaron receipt retain transfer order;
- no receipt, eating, violation, death or future compliance is invented;
- no unsupported contradiction, CrackFlix, Captain, SKIP or YOINK appears;
- publication remains held and unpublished.

Continuation required: Numbers 19 records the red-heifer ash/water purification
system, corpse-contact impurity, sprinkling schedule and purifier contamination.
