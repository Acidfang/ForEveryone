# CRACKHEAD NUMBERS 35

## Title page

**FORTY-EIGHT CITIES.**

**SIX REFUGES.**

**ONE WITNESS IS NOT ENOUGH.**

Source parent: Numbers chapter 35, verses 1–34, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-035/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/034-DRAW-FOUR-BORDERS-TEN-PRINCES-DIVIDE-NOTHING-YET.md`.

CrackFlix routing: none. No completed observable contradiction is derived.

## Causal foundation

```text
ISRAEL INHERITANCE
-> GIVE LEVITES 48 CITIES + PASTURE
-> 6 REFUGE CITIES + 42 OTHER CITIES
-> MANY-INHERITANCE GIVES MANY / FEW GIVES FEW

PERSON DIES FROM ANOTHER'S ACT
-> CLASSIFY INSTRUMENT + HOSTILITY + WAITING + VISIBILITY + INTENT
-> MULTIPLE-WITNESS JUDGMENT
-> MURDER: DEATH / NO RANSOM
-> UNWITTING KILLING: REFUGE UNTIL HIGH PRIEST DIES / NO EARLY RANSOM
-> LEAVES REFUGE EARLY: AVENGER MAY KILL WITHOUT BLOOD GUILT

RULES DEFINED
!= ANY HOMICIDE CASE EXECUTED
```

## Numbers 35:1–5 — CITIES AND TWO PASTURE DIMENSIONS

In the Moab plains, the LORD tells Moses that Israel must give Levites cities
from tribal inheritance, plus surrounding pasture for livestock, possessions
and animals.

The source retains two measurement statements:

- pasture extends from the city wall outward **1,000 cubits** around it;
- outside the city, each east/south/west/north side is measured **2,000 cubits**,
  with the city in the middle.

The first is an outward wall-depth field; the second is a side-measurement field.
The exact city size, reference points and geometry relating them are not supplied.
They are preserved separately rather than forcing one number to replace the other
or manufacturing a contradiction.

No Levite city or pasture boundary is physically allocated here.

## Numbers 35:6–8 — SIX PLUS FORTY-TWO EQUALS FORTY-EIGHT

The Levite-city total is exact:

```text
6 REFUGE CITIES
+ 42 OTHER CITIES
= 48 LEVITE CITIES WITH PASTURE
```

Tribes with many cities/inheritance contribute many; tribes with few contribute
few. The proportional relation is stated without a per-tribe city table or
named-city selection.

## Numbers 35:9–15 — REFUGE BEFORE JUDGMENT

After Israel crosses into Canaan, six refuge cities are to be appointed: three
beyond Jordan and three in Canaan. Israelite, stranger and resident foreigner
who kills a person unwittingly may flee there.

The refuge prevents the blood avenger from killing the manslayer before the
manslayer stands before the congregation for judgment. The city is a pre-judgment
protection boundary, not an automatic innocence declaration.

Crossing, city appointment, killing, flight and judgment are all prospective.

## Numbers 35:16–21 — MURDER BRANCHES

The source classifies a death as murder when the fatal strike uses:

- an iron instrument;
- a hand-held stone capable of killing;
- a hand-held wooden weapon capable of killing;
- a shove from hatred;
- a hurled object while lying in wait;
- a hostile hand strike.

The murderer is to be put to death, and the blood avenger performs that death
when meeting the murderer. These are conditional case rules. No weapon, victim,
murderer, avenger meeting or execution occurs in the chapter.

## Numbers 35:22–25 — UNWITTING-DEATH BRANCH

Sudden shoving without hostility, throwing without lying in wait, or casting a
potentially fatal stone without seeing the person—where the striker was not an
enemy and did not seek harm—routes the case to congregational judgment.

The congregation judges between striker and avenger, delivers the manslayer
from the avenger, and restores the manslayer to the refuge city. The manslayer
must live there until the death of the high priest anointed with holy oil.

No exact evidentiary test for hostility, sight or intent is supplied beyond the
stated selectors. No current high priest dies here.

## Numbers 35:26–29 — BORDER EXIT CHANGES PROTECTION

If the manslayer leaves the refuge-city border before the high priest dies and
the blood avenger finds and kills that person outside, the avenger has no blood
guilt. The source assigns the result to the manslayer's duty to remain inside.

After the high priest's death, the manslayer may return to the land of possession.
The high-priest-death release mechanism is stated but not explained or executed.
These statutes apply through generations in all dwellings.

## Numbers 35:30 — MULTIPLE-WITNESS DEATH GATE

A murderer may be slain on witness testimony, but one witness alone may not
testify against a person so that the person dies. The source does not specify
the minimum beyond excluding one; it does not authorize invented witness counts,
testimony quality or verdicts.

## Numbers 35:31–32 — TWO RANSOM PROHIBITIONS

No ransom may replace the death of a murderer guilty of death. No ransom may
release a refuge-city manslayer to return before the priest dies. The two
prohibitions address different case States and do not merge murder punishment
with refuge confinement.

## Numbers 35:33–34 — BLOOD, LAND AND DIVINE DWELLING

The command prohibits polluting the inhabited land. Blood pollutes it, and the
source says no atonement for shed blood exists except the blood of the shedder.
Israel must not defile the land because the LORD dwells among them.

The land-pollution and blood-atonement relations remain divine source claims.
No blood is shed and no land State changes in this chapter.

## Character and world-ledger changes

- 48 future Levite cities divide exactly into six refuge plus 42 other cities;
- many/few contribution scaling is retained without invented tribal totals;
- 1,000-outward and 2,000-side pasture fields remain distinct and geometry unresolved;
- six refuges split three east/three Canaan west;
- refuge protects until congregational judgment rather than deciding the case;
- weapon/hostility/waiting/visibility/intent selectors remain distinct;
- murder and unwitting-death outcome branches are not merged;
- refuge duration and early-exit avenger boundary remain exact;
- one witness cannot independently trigger death;
- murderer ransom and early-refuge-release ransom are separately prohibited;
- no actual killing, trial, flight, execution, priest death or land pollution is invented;
- no unsupported contradiction, Captain, crack, YOINK or SKIP occurs;
- every living human, animal and face-like city, wall, pasture ruler, weapon,
  witness stand, refuge border, ransom coin, blood drop or land parcel is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — LEVITE CITY + HOMICIDE ROUTER`;
- city arithmetic: `6 REFUGE + 42 STANDARD = 48`;
- pasture warning: `1000 DEPTH / 2000 SIDE / GEOMETRY DRIVER MISSING`;
- refuge topology: `3 EAST + 3 WEST`;
- case selector: `IRON / STONE / WOOD / HATRED / WAITING / HOSTILITY`;
- accidental selector: `SUDDEN / NO HOSTILITY / NO WAIT / DIDN'T SEE`;
- witness gate: `1 != ENOUGH TO KILL`;
- refuge timer: `UNTIL HIGH PRIEST DEATH`;
- ransom ports: `MURDER NO / EARLY RETURN NO`;
- barcode: `CHB-NUM35-34-48-CITIES-6-REFUGES-WITNESSES-HELD`.

## FIR verification

- all 34 verse markers are represented in order;
- 6 + 42 = 48 closes exactly;
- proportional tribal contribution remains unquantified where source is unquantified;
- 1,000 and 2,000 measurements retain different addressed dimensions;
- no unsupported geometric reconciliation or contradiction is invented;
- refuge availability and three-east/three-west topology remain future;
- murder and unwitting branches retain all stated selectors;
- congregation judgment precedes restored refuge confinement;
- refuge exit and high-priest-death timing remain exact;
- one-witness prohibition is not inflated into an unstated exact minimum;
- two ransom prohibitions remain case-specific;
- land/blood/atonement claims remain source-attributed and unexecuted;
- no Captain or CrackFlix event is added without a completed contradiction;
- publication remains held and unpublished.

Continuation required: Numbers 36 returns to Zelophehad's daughters and
restricts inheritance-bearing marriage to preserve tribal land allocation.
