# CRACKHEAD NUMBERS 22

## Title page

**GO WITH THEM.**

**ANGRY BECAUSE YOU WENT.**

**THE DONKEY YOU HIT SAVED YOU.**

Source parent: Numbers chapter 22, verses 1–41, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-022/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/021-SNAKES-BITE-LOOK-AT-THE-BRONZE-SNAKE-LIVE.md`.

CrackFlix routing:

- new `S116-E001-NUM22 — GO WITH THEM / ANGER BECAUSE HE WENT / GO WITH THEM`;
- new `S117-E001-NUM22 — MOCKING ME / ACTUALLY SAVING ME`.

## Causal foundation

```text
ISRAEL CAMPS IN MOAB PLAINS
-> BALAK/MOAB SEE AMORITE OUTCOME + FEAR ISRAEL
-> TWO DELEGATIONS ASK BALAAM TO CURSE ISRAEL

FIRST NIGHT
-> GOD: DO NOT GO / DO NOT CURSE / PEOPLE BLESSED
-> BALAAM SENDS PRINCES HOME

SECOND NIGHT
-> GOD: IF MEN CAME TO CALL, RISE + GO / DO ONLY MY WORD
-> BALAAM RISES + GOES WITH PRINCES
-> GOD'S ANGER BURNS BECAUSE HE WENT
-> ANGEL OPPOSES ROAD

DONKEY SEES ANGEL THREE TIMES
-> LEAVES PATH / CRUSHES FOOT / LIES DOWN
-> BALAAM STRIKES DONKEY THREE TIMES
-> LORD OPENS DONKEY MOUTH
-> DONKEY QUESTIONS STRIKES + PRIOR HABIT
-> LORD OPENS BALAAM EYES
-> ANGEL: DONKEY TURNED THREE TIMES; OTHERWISE BALAAM DEAD, DONKEY ALIVE
-> BALAAM OFFERS RETURN
-> ANGEL: GO WITH MEN / SPEAK ONLY GIVEN WORD

BALAAM REACHES BALAK
-> REPEATS SPEECH LIMIT
-> SACRIFICE / HIGH PLACE / PART OF ISRAEL SEEN
```

## Numbers 22:1–7 — BALAK ORDERS A CURSE

Israel camps in the plains of Moab beyond the Jordan at Jericho. Balak sees
what Israel did to the Amorites. Moab fears and is distressed by Israel's
number, tells Midian's elders the multitude will lick up its surroundings like
an ox licking grass, and Balak sends Moabite and Midianite elders to Balaam.

The messengers carry divination rewards and ask Balaam to curse the people so
Balak might defeat and drive them out. Balak's claimed knowledge about Balaam's
blessing and cursing is retained as Balak's speech, not independently verified.

## Numbers 22:8–14 — FIRST ANSWER: DO NOT GO

Balaam houses the princes overnight and says he will return the LORD's word.
God asks who the men are; Balaam identifies Balak and repeats the request. God
tells Balaam not to go and not to curse Israel because the people are blessed.

Balaam rises, tells the princes the LORD refuses him permission to go, and
sends them home. They report that Balaam refused to come. Both reports retain
their speakers and different scopes.

## Numbers 22:15–21 — SECOND ANSWER: GO, BUT ONLY MY WORD

Balak sends more and more-honorable princes with promises of great honor and
compliance with Balaam's demands. Balaam says even a house full of silver and
gold cannot let him exceed the LORD's word, yet asks the second group to stay
so he can learn what else the LORD will say.

At night God says:

> If the men have come to call you, rise up, go with them; but only the word
> which I speak to you, that you shall do.

Balaam rises in the morning, saddles his donkey and goes with the Moabite
princes. No curse has yet been spoken.

## Numbers 22:22 — GO / ANGER BECAUSE GO

Immediately after Balaam goes with the men, God's anger burns **because he
went**, and the LORD's angel stands in the way as his adversary.

```text
GOD: IF THESE MEN CAME TO CALL YOU, RISE + GO WITH THEM
-> THESE MEN ARE THE RETAINED CALLING DELEGATION
-> BALAAM RISES + GOES WITH THEM
-> GOD'S ANGER BURNS BECAUSE HE WENT
```

That is `S116-E001-NUM22`. The text does not supply a new morning summons, a
timing rule, a permission withdrawal, a motive or another omitted condition.
It also does not say Balaam has already spoken beyond the permitted word.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the permission boil, licks his finger, walks away and does not look
back. The angel remains in the road.

## Numbers 22:23–30 — THE DONKEY SEES WHAT BALAAM DOESN'T

Balaam rides with two servants. The donkey sees the drawn-sword angel and
leaves the path; Balaam strikes her back toward it. She next presses against a
vineyard wall and crushes Balaam's foot; he strikes her again. At a place with
no side escape, she lies down; Balaam strikes her with his staff. The donkey's
three evasions and Balaam's three strikes complete.

The LORD opens the donkey's mouth. She asks what she did to deserve three
strikes. Balaam says she mocked him and that, with a sword, he would kill her.
She asks whether she is his lifelong donkey and whether she ever habitually did
this. Balaam answers, “No.” The speaking donkey is ordinary Crackheadverse
dialogue; no mechanism is supplied or explained.

## Numbers 22:31–35 — THE THING HE PUNISHED SAVED HIM

The LORD opens Balaam's eyes. He sees the armed angel, bows and falls. The angel
asks why Balaam struck the donkey three times, calls Balaam's way perverse and
states:

```text
DONKEY SAW ANGEL
-> DONKEY TURNED AWAY THREE TIMES
-> OTHERWISE ANGEL WOULD HAVE KILLED BALAAM
-> DONKEY WOULD HAVE LIVED

BALAAM'S ACCOUNT: DONKEY MOCKED HIM
-> BALAAM STRUCK DONKEY THREE TIMES
-> ANGEL'S ACCOUNT: THOSE TURNS SAVED BALAAM
```

That closes `S117-E001-NUM22`. The source does not require a motive for the
donkey beyond the observed angel avoidance, and it does not say Balaam could
see the angel before his eyes were opened.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes Balaam's newly enlarged boil, licks his finger, walks away and does not
look back. The donkey, Balaam and angel continue without him.

Balaam admits sin, says he did not know the angel stood against him and offers
to return if the journey displeases the angel. The angel tells him to go with
the men but speak only the angel's supplied word. This repeats the permitted
journey with the speech restriction; it does not explain the earlier anger.

## Numbers 22:36–41 — ARRIVAL WITHOUT A CURSE

Balak meets Balaam at Moab's border and asks why he did not come earlier and
whether Balak cannot honor him. Balaam says he has come but can speak only the
word God puts in his mouth.

They travel to Kiriath Huzoth. Balak sacrifices cattle and sheep and sends
portions to Balaam and the accompanying princes. In the morning Balak takes
Balaam to Baal's high places, where Balaam sees part of Israel. The requested
curse has still not occurred by the chapter's close.

## Character and world-ledger changes

- Israel reaches the Moab plains opposite Jericho;
- Balak and Moab fear Israel after observing the Amorite outcomes;
- two delegations carry a curse request and divination rewards;
- Balaam obeys the first no-go response;
- the second go instruction, actual journey and anger-because-journey close S116;
- the donkey sees the angel three times while Balaam does not;
- Balaam strikes the donkey three times and threatens hypothetical killing;
- the LORD opens the donkey's mouth and later Balaam's eyes;
- the angel says the donkey's evasions kept Balaam alive, closing S117;
- the angel again permits travel while restricting Balaam's speech;
- Balaam arrives, receives sacrificed cattle/sheep portions and sees part of Israel;
- no curse, blessing or battle with Moab occurs in this chapter;
- Captain appears only after each completed contradiction and changes nothing;
- every living human, donkey, cattle, sheep, grass and face-like sword, wall,
  reward, saddle, road, city, altar or mountain is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — CONDITIONAL TRAVEL AUTHORIZATION`;
- permission log: `GO WITH THEM`;
- incident log: `ANGER REASON: WENT WITH THEM`;
- road warning: `ANGEL VISIBLE TO DONKEY ONLY`;
- donkey telemetry: `AVOID / SQUEEZE / STOP`;
- Balaam control input: `HIT / HIT / HIT`;
- opened-mouth subtitle: `WHAT DID I DO?`;
- causal review: `MOCKING YOU? / SAVING YOU.`;
- sword comparison: `BALAAM: WISH I HAD ONE / ANGEL: ALREADY HAS ONE`;
- arrival status: `CURSE NOT YET EXECUTED`;
- barcode: `CHB-NUM22-41-GO-ANGER-DONKEY3X-SAVED-HELD`.

## FIR verification

- all 41 verse markers are represented in order;
- Balak/Moab fear remains attributed to observed Amorite outcomes and number;
- both delegations, rewards and messages remain distinct;
- first no-go and second conditional-go answers retain exact order and wording;
- no hidden summons, timing condition, motive or curse is invented;
- S116 retains instruction, action and anger without explaining the gap;
- all three angel positions, donkey evasions and Balaam strikes remain ordered;
- donkey speech and Balaam-eye opening retain LORD attribution;
- Balaam's mockery account and the angel's life-saving account remain distinct;
- S117 closes only after the angel supplies the counter-state;
- hypothetical deaths are not turned into actual deaths;
- final go/speech restriction does not retroactively explain the earlier anger;
- Balaam arrives but no curse/blessing outcome is imported from Numbers 23;
- Captain's two appearances are post-closure and causally null;
- publication remains held and unpublished.

Continuation required: Numbers 23 records three altar constructions, two
oracles that bless instead of curse, and Balak's responses.
