# CRACKHEAD NUMBERS 34

## Title page

**DRAW FOUR BORDERS.**

**TEN PRINCES.**

**DIVIDE NOTHING YET.**

Source parent: Numbers chapter 34, verses 1–29, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-034/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/033-MOSES-WROTE-EVERY-STOP-AARON-DIED-AGE-123.md`.

CrackFlix routing: none. No completed observable contradiction is derived.

## Causal foundation

```text
WHEN ISRAEL ENTERS CANAAN
-> SOUTH BORDER DEFINED
-> WEST BORDER DEFINED
-> NORTH BORDER DEFINED
-> EAST BORDER DEFINED

EAST 2.5 TRIBES ALREADY ASSIGNED
-> WEST LAND FALLS BY LOT TO 9.5 TRIBES

ELEAZAR + JOSHUA
+ ONE PRINCE FOR EACH WEST-RECIPIENT TRIBE
-> FUTURE LAND DIVISION AUTHORITY

MAP + APPOINTMENT COMPLETE
!= LAND SURVEYED / LOTS CAST / PARCELS TRANSFERRED
```

## Numbers 34:1–5 — SOUTH BORDER

The LORD tells Moses to command Israel regarding the land that will fall to
them when they enter Canaan. The south quarter begins at the wilderness of Zin
beside Edom and the east end of the Salt Sea. It turns south of the ascent of
Akrabbim, passes to Zin and south of Kadesh Barnea, then goes through Hazar
Addar and Azmon, turns to the brook of Egypt and ends at the sea.

This defines a future inheritance boundary. No survey crew walks it and no
border marker is installed in this chapter.

## Numbers 34:6 — WEST BORDER

The Great Sea and its boundary form the west border. The concise water boundary
is not expanded with invented coastal points.

## Numbers 34:7–9 — NORTH BORDER

From the Great Sea the northern line is marked toward Mount Hor, then the
entrance of Hamath, Zedad, Ziphron and Hazar Enan.

This Mount Hor is retained at the north-border address. The source supplies no
identity bridge proving it is Aaron's Mount Hor at Edom's edge, so same spelling
does not merge the two geographic records.

## Numbers 34:10–12 — EAST BORDER

The east line runs from Hazar Enan to Shepham, down to Riblah east of Ain, down
to the east side of the Sea of Chinnereth, then down the Jordan and ends at the
Salt Sea. That closes the described land around its four sides.

The line is a commanded map relation. Entry, measurement, possession and
boundary enforcement remain future.

## Numbers 34:13–15 — NINE AND A HALF WEST; TWO AND A HALF EAST

Moses tells Israel that the mapped land will be inherited by lot by nine tribes
and half-Manasseh. Reuben, Gad and the other half-Manasseh have received their
inheritance east of the Jordan at Jericho toward sunrise.

The east receipt restates Numbers 32's grant State. It does not establish that
the west armed-crossing/subdual obligations have been fulfilled.

## Numbers 34:16–18 — DIVISION AUTHORITY

The LORD appoints Eleazar and Joshua to divide the future inheritance, plus one
prince from each addressed recipient tribe. The immediately retained scope is
the nine tribes plus west half-Manasseh, so ten princes are required and ten are
named.

Appointment is completed. Division, lot results and parcel delivery are not.

## Numbers 34:19–28 — THE TEN PRINCES

| West recipient | Appointed prince |
|---|---|
| Judah | Caleb son of Jephunneh |
| Simeon | Shemuel son of Ammihud |
| Benjamin | Elidad son of Chislon |
| Dan | Bukki son of Jogli |
| west Manasseh | Hanniel son of Ephod |
| Ephraim | Kemuel son of Shiphtan |
| Zebulun | Elizaphan son of Parnach |
| Issachar | Paltiel son of Azzan |
| Asher | Ahihud son of Shelomi |
| Naphtali | Pedahel son of Ammihud |

Manasseh and Ephraim remain separate Joseph branches. Hanniel represents the
west Manasseh recipient half; the already assigned east half is not assigned a
second west parcel through this appointment.

## Numbers 34:29 — APPOINTED TO DIVIDE IN CANAAN

The LORD-commanded allocation team is complete: Eleazar, Joshua and the ten
princes. Their selected job is to divide inheritance in Canaan. No evidence in
the chapter shows them entering Canaan, casting a lot, deciding a boundary
dispute or transferring land.

## Character and world-ledger changes

- all south, west, north and east border chains are retained in order;
- northern Mount Hor remains separate from Aaron's death mountain absent a bridge;
- east 2.5-tribe grant and west 9.5-tribe lot scopes remain distinct;
- Numbers 32's future armed-crossing obligations remain open;
- Eleazar and Joshua are appointed as division authorities;
- all ten west-recipient princes and father lineages are retained;
- west Manasseh and east Manasseh halves are not collapsed;
- no survey, border installation, entry, lot cast, parcel decision or transfer is invented;
- no unsupported contradiction, Captain, crack, YOINK or SKIP occurs;
- every living human, animal and face-like sea, river, mountain, border line,
  compass, lot machine, map pin or nameplate is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — CANAAN GEOMETRY DEPARTMENT`;
- south polyline: `SALT SEA -> AKRABBIM -> ZIN -> KADESH -> HAZAR -> AZMON -> BROOK -> SEA`;
- west mode: `BIG WATER. DONE.`;
- north warning: `MOUNT HOR NAME COLLISION / DO NOT AUTO-MERGE`;
- east polyline: `HAZAR ENAN -> SHEPHAM -> RIBLAH -> CHINNERETH -> JORDAN -> SALT SEA`;
- allocation scope: `9.5 WEST / 2.5 ALREADY EAST`;
- authority bundle: `ELEAZAR + JOSHUA + 10 PRINCES`;
- fake warning: `APPOINTMENT IS NOT A LAND PARCEL`;
- barcode: `CHB-NUM34-29-FOUR-BORDERS-TEN-PRINCES-HELD`.

## FIR verification

- all 29 verse markers are represented in order;
- every border point remains attached to the correct cardinal chain;
- Great Sea, Salt Sea, Chinnereth and Jordan roles are not merged;
- northern Mount Hor is not equated with Aaron's Mount Hor without evidence;
- mapped border is not called a performed survey or possession;
- east 2.5 and west 9.5 recipient scopes remain distinct;
- one-prince-per-tribe statement is evaluated inside the ten-recipient west scope;
- all ten princes and father names are exact;
- Manasseh's east/west halves remain separately addressed;
- Eleazar/Joshua/prince appointments are complete;
- future division, lots and land transfers remain unperformed;
- no Captain or CrackFlix event is added without a completed contradiction;
- publication remains held and unpublished.

Continuation required: Numbers 35 assigns forty-eight Levite cities, six refuge
cities and the witness/blood-avenger rules for homicide cases.
