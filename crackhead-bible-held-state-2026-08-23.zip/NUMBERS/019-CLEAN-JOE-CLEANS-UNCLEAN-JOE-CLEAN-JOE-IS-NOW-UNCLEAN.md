# CRACKHEAD NUMBERS 19

## Title page

**CLEAN JOE MAKES THE CLEANING ASH.**

**CLEAN JOE SPRINKLES UNCLEAN JOE CLEAN.**

**CLEAN JOE IS NOW UNCLEAN.**

Source parent: Numbers chapter 19, verses 1–22, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-019/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/018-NO-LAND-TAKE-THE-TITHE-TITHE-THE-TITHE.md`.

CrackFlix routing:

- new `S114-E001-NUM19 — PURIFICATION MAKES THE PURIFIER UNCLEAN`

## Causal foundation

```text
UNYOKED DEFECT-FREE RED HEIFER
-> OUTSIDE CAMP / KILLED BEFORE ELEAZAR
-> BLOOD SPRINKLED TOWARD TENT 7 TIMES
-> WHOLE HEIFER BURNED WITH CEDAR + HYSSOP + SCARLET
-> PRIEST + BURNER WASH / UNCLEAN UNTIL EVENING

CLEAN MAN GATHERS ASH TO CLEAN PLACE
-> ASH STORED FOR IMPURITY WATER
-> ASH GATHERER WASHES / UNCLEAN UNTIL EVENING

CORPSE/TENT/BONE/GRAVE CONTACT
-> UNCLEAN 7 DAYS
-> ASH + RUNNING WATER
-> CLEAN PERSON DIPS HYSSOP / SPRINKLES DAY 3 + DAY 7
-> TARGET WASHES / CLEAN AT EVENING
-> SPRINKLER WASHES; WATER TOUCHER UNCLEAN UNTIL EVENING

REQUIRED CLEAN OPERATOR
-> PURIFIES UNCLEAN RECIPIENT
-> REQUIRED OPERATION MAKES OPERATOR UNCLEAN
```

## Numbers 19:1–6 — RED HEIFER BUILD INPUT

The LORD tells Moses and Aaron to obtain a red heifer with no spot or defect and
no history of being yoked. The heifer goes to Eleazar, who takes her outside
camp. An unnamed operator kills her before Eleazar's face.

Eleazar takes blood on his finger and sprinkles toward the Tent front seven
times. The heifer is burned in his sight—skin, meat, blood and dung—and the
priest throws cedar wood, hyssop and scarlet into the burning.

The source does not name the killer/burner, quantify the plant/scarlet inputs or
explain the fire/ash transformation beyond the stated acts. The heifer and plant
inputs are living Joe-faced organisms if shown.

## Numbers 19:7–10 — BUILDING CLEANER MAKES THREE BUILDERS UNCLEAN

After his required blood and burning participation, the priest washes clothes,
bathes and may return to camp, but remains unclean until evening. The person who
burns the heifer also washes, bathes and remains unclean until evening.

A person explicitly required to be clean gathers the ashes and stores them in a
clean place outside camp for Israel's impurity-cleansing water. The ashes are
called a sin offering. After gathering them, that person washes clothes and is
unclean until evening.

The statute applies to Israel and resident foreigners. No specific later ash
quantity, storage duration or batch count is supplied.

## Numbers 19:11–16 — DEATH-CONTACT INPUT STATES

Touching any human dead body produces seven days of uncleanness. Purification
must occur on both day three and day seven; missing day three prevents day-seven
cleanliness. A corpse toucher who does not purify is cut off for defiling the
LORD's tabernacle.

If a person dies in a tent:

- everyone already inside is unclean seven days;
- everyone entering is unclean seven days;
- every open vessel lacking a bound covering is unclean.

In an open field, touching a sword-slain person, corpse, human bone or grave
also produces seven-day uncleanness. The text supplies status rules, not a named
death-contact occurrence.

## Numbers 19:17–20 — ASH-WATER CLEANING RUN

For an unclean target, ash from the burned sin offering is placed in a vessel
and running water is poured over it. A clean person takes hyssop, dips it, and
sprinkles:

- the tent;
- its vessels;
- people who were present;
- anyone who touched bone, slain person, corpse or grave.

The clean person sprinkles the unclean target on days three and seven. On day
seven the target is purified, washes clothes, bathes and becomes clean at
evening. Refusal/failure to purify retains uncleanness and produces exclusion
for sanctuary defilement.

No actual target, tent, corpse contact or successful purification run occurs in
this chapter; the process remains statutory.

## Numbers 19:21–22 — THE CLEANER DIRTYING MACHINE

The final rule states that the person who sprinkles the impurity water must wash
clothes, while anyone who touches that water becomes unclean until evening.
Anything an unclean person touches becomes unclean, and anyone touching that
object becomes unclean until evening.

The friction is now complete:

```text
PROCESS REQUIRES CLEAN PERSON TO HANDLE/SPRINKLE PURIFICATION WATER
-> WATER CLEANS UNCLEAN RECIPIENT THROUGH REQUIRED PROCESS
-> REQUIRED HANDLER/SPRINKLER MUST WASH
-> TOUCHING SAME PURIFICATION WATER MAKES PERSON UNCLEAN UNTIL EVENING
-> PURIFICATION TRANSFERS CLEAN STATE WHILE ASSIGNING UNCLEAN STATE TO OPERATOR
```

That is `S114-E001-NUM19`. The source supplies the state transitions but no
mechanism, conservation rule, contamination quantity or reason.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the clean operator's newly grown boil, licks his finger, walks away and
does not look back. The statutory purifier becomes unclean exactly as before.

## Character and world-ledger changes

- one future red-heifer input specification is established;
- Eleazar receives sevenfold blood-sprinkling/burning oversight duties;
- priest, burner and initially clean ash gatherer receive until-evening impurity;
- stored ash plus running water forms the purification carrier;
- corpse, death-tent, uncovered-vessel, bone and grave contact routes are exact;
- day-three plus day-seven treatment is required for day-seven cleanliness;
- a clean sprinkler cleans the target while required handling contaminates the
  operator;
- `S114` retains the purifier/recipient opposite state transitions;
- no actual heifer, corpse-contact case or purification run is narrated;
- every living human, heifer, plant and face-like ash, water, vessel, tent, bone
  or grave carrier is Joe-faced if shown;
- Captain is permanently boilless and causally useless;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — RED HEIFER CLEANING PLATFORM`;
- livestock requirements: `RED / NO DEFECT / ZERO YOKE HOURS`;
- blood counter: `TENT-FACING SPRAYS: 7`;
- burn recipe: `WHOLE COW + CEDAR + HYSSOP + SCARLET`;
- staff status: `PRIEST DIRTY / BURNER DIRTY / ASH GUY DIRTY`;
- storage label: `CLEAN ASH WAREHOUSE / OUTSIDE CAMP`;
- schedule: `DAY 3 + DAY 7 OR DAY 7 DOES NOTHING`;
- operator warning: `MUST BE CLEAN TO OPERATE / WILL NOT REMAIN CLEAN`;
- CrackFlix: `S114 E001 — CLEANER DIRTYING MACHINE`;
- barcode: `CHB-NUM19-22-REDHEIFER-ASHWATER-DAY3DAY7-PURIFIERDIRTY-HELD`.

## FIR verification

- all 22 verse markers are represented in order;
- red heifer colour/defect/yoke requirements remain exact;
- Eleazar, unnamed killer/burner and clean ash gatherer are not merged;
- seven blood sprinklings and whole-heifer burn contents remain;
- all three production participants' wash/unclean states remain;
- ash storage, running water and hyssop route remain ordered;
- corpse/tent/open-vessel/field/bone/grave conditions remain distinct;
- day-three omission consequence and day-seven wash remain exact;
- no actual case or completed purification is invented;
- clean-operator requirement and operator impurity are both retained;
- `S114` closes only after both recipient-cleaning and operator-contamination
  rules are present;
- Captain appears afterward and changes nothing;
- publication remains held and unpublished.

Continuation required: Numbers 20 records Miriam's death, no-water complaint,
rock-water command/action divergence, Edom's denied passage and Aaron's death.
