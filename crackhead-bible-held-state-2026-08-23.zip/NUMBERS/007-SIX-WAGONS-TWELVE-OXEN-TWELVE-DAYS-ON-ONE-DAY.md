# CRACKHEAD NUMBERS 7

## Title page

**SIX WAGONS. TWELVE OXEN. TWELVE IDENTICAL PRINCE LOADS.**

**TWELVE NUMBERED DAYS. ON THE DAY THE ALTAR WAS ANOINTED.**

Source parent: Numbers chapter 7, verses 1–89, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-007/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/006-NO-GRAPES-NO-HAIRCUT-SOMEONE-DIES-BESIDE-YOU-START-OVER.md`.

CrackFlix routing:

- returning `S101-E002-NUM07 — DEUEL CAME BACK` with `SKIP -> S101-E001-NUM02`;
- new `S104-E001-NUM07 — TWELVE DAYS ON THE ANOINTING DAY`.

## Causal foundation

```text
TABERNACLE SET UP + ANOINTED + SANCTIFIED
-> 12 PRINCES PRESENT 6 WAGONS + 12 OXEN
-> LORD SAYS ACCEPT / ASSIGN BY SERVICE
-> GERSHON 2 WAGONS + 4 OXEN
-> MERARI 4 WAGONS + 8 OXEN
-> KOHATH 0 WAGONS / SHOULDER CARRY

LORD: ONE PRINCE EACH DAY
-> DAYS 1 THROUGH 12
-> 12 SEPARATE IDENTICAL INVENTORIES
-> EXACT TOTALS

NUMBERS 2: ELIASAPH SON OF REUEL
-> NUMBERS 7: SAME GAD PRINCE / SON OF DEUEL
-> NO FATHER/IDENTITY TRANSITION

12 NUMBERED OFFERING DAYS
-> SOURCE: DEDICATION OFFERING ON THE DAY ALTAR WAS ANOINTED
-> NO DAY-SCOPE BRIDGE

MOSES ENTERS TENT
-> HEARS VOICE ABOVE MERCY SEAT BETWEEN CHERUBIM
-> VOICE SPEAKS TO HIM
```

## Numbers 7:1–9 — VEHICLES ACCORDING TO THE LOAD

On the day Moses finishes setting up the Tabernacle, he anoints and sanctifies
it, its furniture, the altar and its vessels. The twelve tribal princes who had
overseen the census present six covered wagons and twelve oxen: one wagon per
two princes and one ox per prince.

The LORD tells Moses to accept them and distribute them according to Levite
service. Moses does so:

| Service branch | Wagons | Oxen | Observable carrier relation |
|---|---:|---:|---|
| Gershon | 2 | 4 | fabric service |
| Merari | 4 | 8 | structural service under Ithamar |
| Kohath | 0 | 0 | sanctuary load carried on shoulders |

The vehicles, animals and allocations are completed acts, not future rules.

## Numbers 7:10–11 — ONE PRINCE ON EACH DAY

The princes present altar-dedication offerings. The LORD explicitly tells
Moses that each prince must offer on his own day. The following twelve daily
occurrences are all narrated as completed.

## Numbers 7:12–83 — TWELVE DISTINCT DAYS, ONE REPEATED INVENTORY

The repeated inventory is deduplicated as an act definition, not as an
occurrence. Every row below retains a distinct day, prince, tribe and verse
address while pointing to the same complete load:

```text
ONE SILVER PLATTER / 130 SANCTUARY SHEKELS
+ ONE SILVER BOWL / 70 / BOTH FULL OF OIL-MIXED FINE FLOUR
+ ONE GOLD LADLE / 10 / FULL OF INCENSE
+ BURNT: 1 YOUNG BULL + 1 RAM + 1 ONE-YEAR MALE LAMB
+ SIN: 1 MALE GOAT
+ PEACE: 2 CATTLE + 5 RAMS + 5 MALE GOATS + 5 ONE-YEAR MALE LAMBS
```

| Day | Verses | Prince and retained identity | Tribe |
|---:|---|---|---|
| 1 | 12–17 | Nahshon son of Amminadab | Judah |
| 2 | 18–23 | Nethanel son of Zuar | Issachar |
| 3 | 24–29 | Eliab son of Helon | Zebulun |
| 4 | 30–35 | Elizur son of Shedeur | Reuben |
| 5 | 36–41 | Shelumiel son of Zurishaddai | Simeon |
| 6 | 42–47 | Eliasaph son of **Deuel** | Gad |
| 7 | 48–53 | Elishama son of Ammihud | Ephraim |
| 8 | 54–59 | Gamaliel son of Pedahzur | Manasseh |
| 9 | 60–65 | Abidan son of Gideoni | Benjamin |
| 10 | 66–71 | Ahiezer son of Ammishaddai | Dan |
| 11 | 72–77 | Pagiel son of Ochran | Asher |
| 12 | 78–83 | Ahira son of Enan | Naphtali |

### Day 6 — the father name changes back

Numbers 1 called Gad prince Eliasaph the son of Deuel. Numbers 2 retained the
same prince and tribe but called him son of Reuel. Numbers 7 now calls him son
of Deuel again. No new Eliasaph, second Gad prince, rename, equivalence or
parent transition is supplied.

`SKIP -> S101-E001-NUM02 — SAME PRINCE. DIFFERENT FATHER NAME.`

Captain's eyes glaze. The sixth offering and all later offerings continue.
After the Deuel occurrence closes:

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the boil, licks his finger, walks away and does not look back. Eliasaph
remains the prince named in the offering ledger.

## Numbers 7:84–88 — THE TOTALS AND THE ONE-DAY SUMMARY

The twelve completed inventories total exactly:

| Class | Total |
|---|---:|
| silver platters | 12 × 130 = 1,560 shekels |
| silver bowls | 12 × 70 = 840 shekels |
| all silver | 2,400 shekels |
| gold ladles | 12 × 10 = 120 shekels |
| burnt-offering bulls / rams / year-old male lambs | 12 / 12 / 12 |
| sin-offering male goats | 12 |
| peace-offering cattle / rams / male goats / year-old male lambs | 24 / 60 / 60 / 60 |

The source then calls this complete twelve-prince inventory the dedication
offering **“on the day when [the altar] was anointed”**, after previously
requiring and numbering one offering per day across days one through twelve.
No alternate meaning of day, concurrent calendar, delayed-label rule or bridge
is supplied. That completed state mismatch is `S104-E001-NUM07`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the boil, licks his finger, walks away and does not look back. All
twelve days, all twelve offerings and the single-day wording remain unchanged.

## Numbers 7:89 — THE VOICE BETWEEN THE CHERUBIM

Moses enters the Tent of Meeting to speak with the LORD. He hears the voice
speaking from above the mercy seat on the ark of the Testimony, between the two
cherubim, and the voice speaks to him. The entry and hearing are completed.
The source does not supply the words spoken in this occurrence.

## Character and world-ledger changes

- Tabernacle, furniture, altar and vessels are set up, anointed and sanctified;
- twelve princes jointly present six wagons and twelve oxen;
- vehicle distribution completes at Gershon 2/4, Merari 4/8, Kohath 0/0;
- twelve princes complete twelve separate daily offerings;
- identical inventory is deduplicated without merging occurrence lineage;
- `S101-E002` retains Eliasaph's father name returning to Deuel;
- `S104-E001` retains twelve numbered days against one anointing-day summary;
- all vessel weights and animal totals verify exactly;
- Moses enters the Tent and hears the voice from the mercy-seat location;
- all living people, oxen, cattle, sheep and goats are Joe-faced if shown;
- Captain is permanently boilless and causally useless;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — ALTAR DEDICATION DAILY DUPLICATE INVOICE`;
- fleet decal: `6 WAGONS / 12 OXEN / 0 FOR SHOULDER DEPARTMENT`;
- dedup card: `INVENTORY ACT ID: PRINCE-LOAD-130-70-10-1-1-1-1-2-5-5-5`;
- schedule: `ONE PRINCE PER DAY / DAYS 1–12`;
- Gad ticket: `ELIASAPH / FATHER FIELD: DEUEL AGAIN`;
- CrackFlix pointer: `SKIP -> S101-E001`;
- day label: `TWELVE-DAY ONE-DAY DEDICATION EVENT`;
- silver checksum: `1560 + 840 = 2400`;
- gold checksum: `12 × 10 = 120`;
- barcode: `CHB-NUM07-89-6W-12O-12D-1D-2400-120-HELD`.

## FIR verification

- all 89 verse markers are represented in order;
- setup/anointing, prince vehicle gift and Levite distribution are completed;
- wagons/oxen allocations preserve the three distinct service branches;
- each of twelve daily offering occurrences retains prince, tribe and verses;
- only the identical inventory definition is deduplicated;
- every inventory item, weight and animal count is retained;
- all source totals independently reproduce from the twelve occurrences;
- `S101-E002` uses the retained Deuel/Reuel/Deuel identity path only;
- SKIP points exactly to `S101-E001` and changes nothing;
- `S104` closes only after twelve days and the one-day summary both exist;
- Moses' completed hearing receives no invented speech content;
- Captain appears only after addressed contradictions close;
- every living thing uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Numbers 8 installs the lamp orientation, Levite
cleansing/substitution/service procedure, and completed cleansing/service acts.
