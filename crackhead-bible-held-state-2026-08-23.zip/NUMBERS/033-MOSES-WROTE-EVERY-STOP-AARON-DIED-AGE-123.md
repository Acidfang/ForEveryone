# CRACKHEAD NUMBERS 33

## Title page

**MOSES WROTE EVERY STOP.**

**AARON DIED.**

**AGE 123.**

Source parent: Numbers chapter 33, verses 1–56, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-033/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/032-CROSS-FIRST-GET-THE-LAND-LAND-GIVEN-BEFORE-CROSSING.md`.

CrackFlix routing: none. No completed observable contradiction is derived.

## Causal foundation

```text
PAST JOURNEY OCCURRENCES
-> MOSES WRITES STARTING POINTS BY LORD COMMAND
-> ORDERED EGYPT-TO-MOAB ROUTE RETAINED

ROUTE REACHES MOUNT HOR
-> AARON ASCENDS BY COMMAND
-> DIES THERE
-> YEAR 40 / MONTH 5 / DAY 1 / AGE 123

CURRENT CAMP: MOAB PLAINS BY JORDAN
-> LORD GIVES FUTURE CANAAN COMMANDS
-> CROSS / DISPOSSESS / DESTROY IMAGES / POSSESS / LOT LAND
-> FAILURE WARNING REMAINS CONDITIONAL
```

## Numbers 33:1–4 — THE JOURNEY LEDGER HAS AN AUTHOR AND COMMAND

The chapter identifies these as Israel's journeys out of Egypt by armies under
Moses and Aaron. Moses writes the starting points by the LORD's command.

The route begins at Rameses on first-month day fifteen, the day after Passover.
Israel goes out openly while Egyptians bury firstborn struck by the LORD, and
the source attributes judgments against Egypt's gods to the LORD.

These are retrospective records of retained occurrences. Writing them does not
cause the exodus, deaths or judgments to happen again.

## Numbers 33:5–15 — RAMESES TO SINAI

The ordered route is:

```text
RAMESES
-> SUCCOTH
-> ETHAM
-> TURN BACK TO PIHAHIROTH BEFORE BAAL ZEPHON / CAMP BEFORE MIGDOL
-> THROUGH THE SEA / THREE DAYS IN ETHAM WILDERNESS
-> MARAH
-> ELIM: 12 SPRINGS + 70 PALMS
-> RED SEA
-> WILDERNESS OF SIN
-> DOPHKAH
-> ALUSH
-> REPHIDIM: NO DRINKING WATER
-> WILDERNESS OF SINAI
```

The turn-back, sea crossing, three-day journey, Elim inventory and Rephidim
water absence remain attached to their stated stages.

## Numbers 33:16–36 — SINAI TO KADESH

```text
SINAI
-> KIBROTH HATTAAVAH
-> HAZEROTH
-> RITHMAH
-> RIMMON PEREZ
-> LIBNAH
-> RISSAH
-> KEHELATHAH
-> MOUNT SHEPHER
-> HARADAH
-> MAKHELOTH
-> TAHATH
-> TERAH
-> MITHKAH
-> HASHMONAH
-> MOSEROTH
-> BENE JAAKAN
-> HOR HAGGIDGAD
-> JOTBATHAH
-> ABRONAH
-> EZION GEBER
-> KADESH IN ZIN
```

The route supplies travel and encampment relations, not dates, distances,
events or populations for every intermediate stop. Missing details remain
missing rather than being copied from similarly named places.

## Numbers 33:37–40 — MOUNT HOR AND AARON'S CLOSED DEATH STATE

Israel travels from Kadesh to Mount Hor at Edom's edge. Aaron goes up Mount Hor
by the LORD's command and dies there:

- fortieth year after the exodus;
- fifth month;
- first day;
- age **123**.

Aaron's death location, date and age are now closed. The chapter does not state
burial, grave, body transfer or body disposition.

The Canaanite king of Arad hears of Israel's coming. No new response or battle
is narrated in this route entry.

## Numbers 33:41–49 — MOUNT HOR TO THE MOAB PLAINS

```text
MOUNT HOR
-> ZALMONAH
-> PUNON
-> OBOTH
-> IYE ABARIM AT MOAB BORDER
-> DIBON GAD
-> ALMON DIBLATHAIM
-> ABARIM MOUNTAINS BEFORE NEBO
-> MOAB PLAINS BY JORDAN AT JERICHO
```

The present camp extends by the Jordan from Beth Jeshimoth to Abel Shittim.
Verse 49 describes the range of the same Moab-plains camp; it does not add an
unrecorded travel transition between two new stages.

## Numbers 33:50–54 — WHEN YOU CROSS, DO THESE THINGS

At the current Moab camp, the LORD tells Moses to command Israel that when they
cross into Canaan they must:

- drive out all inhabitants before them;
- destroy stone idols and molten images;
- demolish high places;
- take possession and dwell in the land;
- divide inheritance by lot and family, larger to larger groups and smaller to
  smaller groups, according to father tribes.

The LORD says he has given the land for Israel to possess. The grant and future
possession act are distinct: crossing, dispossession, destruction, lot casting
and dwelling do not occur in this chapter.

## Numbers 33:55–56 — CONDITIONAL FAILURE WARNING

If Israel does not drive out the inhabitants, those allowed to remain will be
pricks in their eyes, thorns in their sides and harassers in the land. The LORD
says he will then do to Israel as he thought to do to those inhabitants.

This is a future conditional consequence. No retained inhabitants, eye pricks,
side thorns, harassment or reversed judgment occurs here.

## Character and world-ledger changes

- Moses is explicitly the commanded journey-record writer;
- every stated departure/encampment relation remains ordered;
- route-specific sea, water, springs/palms and border details are retained;
- the route is not treated as replaying historical occurrences;
- Aaron's death closes at Mount Hor, year 40/month 5/day 1, age 123;
- Aaron burial/body disposition remains unresolved;
- Arad's hearing is retained without invented reaction;
- the current Moab-plains camp range is fixed;
- all Canaan entry/dispossession/image destruction/lot/dwelling acts remain future;
- the failure consequence remains conditional and unexecuted;
- no unsupported contradiction, Captain, crack, YOINK or SKIP occurs;
- every living human, animal, plant and face-like route marker, sea, spring,
  palm, mountain, grave-shaped absence, idol, lot, border or map is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — JOURNEY LEDGER EXPORT`;
- author field: `MOSES / COMMAND-SIGNED`;
- route mode: `DEPART -> ENCAMP -> REPEAT`;
- Elim service area: `12 WATER PORTS / 70 PALM JOES`;
- Rephidim warning: `NO DRINKING WATER`;
- Aaron record: `YEAR 40 / M5 / D1 / AGE 123 / BODY FILE ABSENT`;
- current GPS: `BETH JESHIMOTH .. ABEL SHITTIM`;
- Canaan job queue: `CROSS / DISPOSSESS / DELETE IMAGES / LOT / DWELL`;
- fake warning: `READING ROUTE DOES NOT RE-EXECUTE EXODUS`;
- barcode: `CHB-NUM33-56-ROUTE-AARON123-CANAAN-FUTURE-HELD`.

## FIR verification

- all 56 verse markers are represented in order;
- Moses' writing act and LORD command are retained;
- exodus date, Egyptian burial and divine-judgment attributions remain exact;
- every named route stage appears in source order;
- verse 49 is retained as current-camp range rather than invented movement;
- no missing intermediate dates/distances/events are fabricated;
- Aaron death date, year, age and Mount Hor location are closed;
- Aaron burial/body disposition remains unresolved;
- Arad hears without an invented response;
- all Canaan commands remain prospective;
- divine land grant is not confused with completed possession;
- failure warning remains conditional and unexecuted;
- no Captain or CrackFlix event is added without a completed contradiction;
- publication remains held and unpublished.

Continuation required: Numbers 34 defines Canaan's south, west, north and east
borders and names the leaders assigned to divide it.
