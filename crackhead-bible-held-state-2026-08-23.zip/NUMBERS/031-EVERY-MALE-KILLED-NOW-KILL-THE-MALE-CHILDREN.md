# CRACKHEAD NUMBERS 31

## Title page

**EVERY MALE KILLED.**

**NOW KILL THE MALE CHILDREN.**

Source parent: Numbers chapter 31, verses 1–54, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-031/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/030-SAY-NOTHING-IT-STANDS-DISALLOW-TODAY-OR-BEAR-IT.md`.

CrackFlix routing: **S067-E003-NUM31**, `ALL OF IT DIED. PUT THE REST OF IT INSIDE.`

SKIP points to **S067-E002-EXO12 / ALL LIVESTOCK DIED; FIRSTBORN LIVESTOCK DIED**.
It skips explaining the retained contradiction. It causes nothing.

## Causal foundation

```text
LORD ORDERS MIDIAN VENGEANCE
-> 12,000 ARMED / PHINEHAS / SANCTUARY VESSELS / TRUMPETS
-> BATTLE + FIVE KINGS + BALAAM KILLED
-> WOMEN / CHILDREN / ANIMALS / GOODS CAPTURED
-> CITIES / CAMPS BURNED

REPORT: EVERY MALE KILLED
-> MALE CHILDREN STILL ALIVE
-> MOSES ORDERS MALE CHILDREN + NON-VIRGIN WOMEN KILLED
-> GIRLS NOT KNOWN MAN KEPT ALIVE

CAPTIVES + SPOIL
-> PURIFICATION
-> COUNT
-> HALF WAR / HALF CONGREGATION
-> 1/500 WAR TRIBUTE TO ELEAZAR
-> 1/50 CONGREGATION LEVY TO LEVITES

OFFICERS COUNT SOLDIERS
-> ZERO MISSING
-> GOLD OFFERED AS ATONEMENT/MEMORIAL
```

## Numbers 31:1–6 — 12,000 SENT; MOSES' DEATH STILL FUTURE

The LORD orders Moses to avenge Israel on Midian and says Moses will afterward
be gathered to his people. Moses orders one thousand armed men from every tribe.
Exactly twelve thousand are delivered and sent with Phinehas son of Eleazar,
the sanctuary vessels and alarm trumpets.

The campaign begins. Moses is not gathered or buried in this chapter.

## Numbers 31:7–12 — BATTLE, DEATHS, CAPTIVES AND BURNING

Israel fights Midian and the source says they kill **every male**. Five Midianite
kings—Evi, Rekem, Zur, Hur and Reba—are killed, and Balaam son of Beor is killed
with the sword.

Israel captures Midianite women and little ones, livestock, flocks and goods;
burns inhabited cities and encampments; and brings all captives, human/animal
prey and plunder to Moses, Eleazar and the congregation at the Moab-plains camp.

The five kings and Balaam are individually closed as dead. No body count for
the phrase “every male” is supplied.

## Numbers 31:13–18 — EVERY MALE, THEN MALE CHILDREN

Moses, Eleazar and the princes meet the returning force outside camp. Moses is
angry with its officers and asks why all the women were kept alive. He attributes
Israel's Peor trespass and plague to these women through Balaam's counsel.

He then orders:

- kill every male among the little ones;
- kill every woman who has known a man by lying with him;
- keep alive all girls who have not known a man that way.

The first battle report already said **every male** was killed. The source now
retains living male children without supplying an adult-only qualifier,
replacement population or scope bridge.

**SKIP → S067-E002-EXO12.**

The world continues. Moses finishes the selection order. The order is not
separately narrated as executed, so deaths under this later order are not
silently completed. After the contradiction is visible, Captain Crackhead
pokes the addressed boil, says **“YOINK!”**, licks his finger and walks away.
Everyone else sees poking and licking; the campaign outcome does not change.

## Numbers 31:19–24 — SEVEN-DAY PERSON AND OBJECT PURIFICATION

Anyone who killed a person or touched a slain body must camp outside seven days
and purify on days three and seven, along with the captives. Garments, skins,
goat-hair work and wooden things require purification.

Eleazar gives the material router:

- gold, silver, bronze, iron, tin and lead—or anything fire-resistant—goes
  through fire and is also purified with impurity water;
- anything not fire-resistant goes through water;
- clothes are washed on day seven, after which the people are clean and may
  enter camp.

The instructions are prospective. The chapter does not individually narrate
each person/object completing the third-day, seventh-day, fire and water acts.

## Numbers 31:25–31 — DIVIDE FIRST, THEN APPLY DIFFERENT RATES

The LORD orders Moses, Eleazar and household heads to count human and animal
plunder and split it equally:

- half to the warriors;
- half to the congregation.

From the warriors' half, one of every 500 persons/cattle/donkeys/flock animals
goes to Eleazar as the LORD's wave offering. From the congregation's half, one
of every 50 goes to the Levites serving the tabernacle. Moses and Eleazar do as
commanded.

## Numbers 31:32–47 — THE PLUNDER ARITHMETIC CLOSES

Counted plunder above the warriors' individual booty is:

| Class | Total | Each half | 1/500 warrior tribute | Derived 1/50 congregation levy |
|---|---:|---:|---:|---:|
| Sheep | 675,000 | 337,500 | 675 | 6,750 |
| Cattle | 72,000 | 36,000 | 72 | 720 |
| Donkeys | 61,000 | 30,500 | 61 | 610 |
| Girls/women not known man | 32,000 | 16,000 | 32 | 320 |

The source explicitly states every total, half and warrior tribute. The final
column is derived exactly from the commanded 1-in-50 rate and stated
congregation half; the source says Moses took that rate and gave it to the
Levites but does not print those four resulting numbers.

Moses gives the 1/500 wave-offering tribute to Eleazar and the 1/50 levy to the
Levites. These transfers are completed. The 32,000 selector is retained exactly;
it does not itself narrate the fate of every other captive.

## Numbers 31:48–54 — ZERO SOLDIERS MISSING; 16,750 SHEKELS

The officers report that their count of the men under command lacks not one
man. They bring gold ornaments found by each man—armlets, bracelets, signet
rings, earrings and necklaces—as an offering to make atonement for their souls.

Moses and Eleazar receive **16,750 shekels** of worked gold from the officers.
Warriors' separately taken personal booty remains outside the counted plunder.
The officers' gold is brought into the Tent as a memorial before the LORD.

The zero-missing claim is scoped to the officers' returned men under command.
No enemy casualty total, battle mechanics or atonement mechanism is inferred.

## Character and world-ledger changes

- the commanded Midian campaign and twelve-thousand deployment are completed;
- five named kings and Balaam are dead;
- women, children, animals and goods are captured; cities/camps are burned;
- `every male killed` is followed by living male children without a bridge;
- S067 gains episode E003 and SKIP points to E002 without changing anything;
- Moses' later captive-killing order is retained but not marked executed;
- purification and material-routing commands remain prospective;
- spoil division, Eleazar tribute and Levite levy are completed;
- exact total/half/tribute arithmetic and derived 1/50 amounts are retained;
- officers report zero soldiers missing and transfer 16,750 shekels of gold;
- one causally null Captain YOINK occurs after the contradiction closes;
- every living human, animal and face-like sword, trumpet, city, fire, captive
  list, fraction, metal, water, gold ornament or tally is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — MIDIAN INVENTORY LIQUIDATION`;
- deployment: `12 x 1,000 = 12,000`;
- CrackFlix: `S067-E003 / EVERY MALE KILLED; NOW KILL MALE CHILDREN`;
- SKIP: `S067-E002 / UNIVERSAL SET ALREADY CAME BACK`;
- purification router: `FIRE-SAFE -> FIRE + WATER / NOT FIRE-SAFE -> WATER`;
- split controller: `50% WAR / 50% EVERYONE ELSE`;
- tax ports: `WAR 1:500 -> ELEAZAR / CONGREGATION 1:50 -> LEVITES`;
- return report: `12,000 OUT / NONE MISSING`;
- gold receipt: `16,750 SHEKELS / MEMORIAL MODE`;
- barcode: `CHB-NUM31-54-EVERY-MALE-MALE-CHILDREN-S067E003-HELD`.

## FIR verification

- all 54 verse markers are represented in order;
- command, deployment, battle, capture, burning and return remain distinct acts;
- all five kings and Balaam retain named death closure;
- every-male report and later living-male-child address form a valid S067 recurrence;
- SKIP points to the retained prior contradiction and causes nothing;
- post-return killing order is not falsely marked executed;
- purification selectors/material routes remain exact and prospective;
- plunder totals, halves and 1/500 tributes verify arithmetically;
- derived 1/50 amounts are labelled derived rather than source-printed;
- Eleazar and Levite transfers are completed;
- zero missing is scoped to the officers' men under command;
- 16,750-shekel gold memorial transfer is retained separately from personal booty;
- Captain appears only after contradiction completion and changes no outcome;
- publication remains held and unpublished.

Continuation required: Numbers 32 handles Reuben/Gad's east-Jordan livestock
request, Moses' refusal comparison, and the negotiated armed-crossing condition.
