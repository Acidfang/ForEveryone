# CRACKHEAD NUMBERS 26

## Title page

**601,730 WAR JOES.**

**23,000 LEVITE JOES COUNTED SEPARATELY.**

**NONE OF THE OLD WAR COUNT LEFT EXCEPT TWO.**

Source parent: Numbers chapter 26, verses 1–65, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-026/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/025-SPEAR-TWO-PEOPLE-RECEIVE-THE-COVENANT-OF-PEACE.md`.

CrackFlix routing: none. No completed observable contradiction is derived.

## Causal foundation

```text
AFTER PEOR PLAGUE
-> LORD ORDERS NEW CENSUS
-> SELECTOR: ISRAEL / FATHERS' HOUSES / MALE / AGE 20+ / WAR-CAPABLE
-> MOSES + ELEAZAR COUNT TWELVE TRIBAL LINES
-> TOTAL 601,730

COUNTED NAMES/NUMBERS
-> FUTURE LAND INHERITANCE
-> MORE PEOPLE: MORE LAND / FEWER: LESS
-> LOCATION DIVIDED BY LOT AMONG FATHER-TRIBE NAMES

LEVITE SELECTOR
-> MALE / ONE MONTH+
-> COUNTED SEPARATELY: 23,000
-> NO LAND INHERITANCE AMONG ISRAEL

COMPARE WITH SINAI WAR CENSUS
-> NO MAN FROM THAT SELECTED COUNT REMAINS
-> EXCEPT CALEB + JOSHUA
```

## Numbers 26:1–4 — THE SECOND WAR COUNT

After the plague, the LORD tells Moses and Eleazar son of Aaron to count all
Israel by fathers' houses: age twenty and upward and able to go to war. Moses
and Eleazar issue that selector in the Moab plains by the Jordan at Jericho.

This is a new census occurrence. It does not silently reuse Numbers 1's people,
representatives or 603,550 total.

## Numbers 26:5–11 — REUBEN: 43,730; KORAH'S SONS LIVE

Reuben's count contains Hanochite, Palluite, Hezronite and Carmite families:
**43,730**. Pallu's Eliab line includes Nemuel, Dathan and Abiram. The source
rejoins Dathan/Abiram to the Korah rebellion, earth swallowing and 250-man fire
death/sign event.

It then explicitly states that Korah's sons did not die. Their survival does
not contradict the later old-census survivor statement because Levites were
excluded from the Numbers 1 military census, and no age/eligibility entry for
these sons in that count is supplied.

## Numbers 26:12–27 — SIMEON THROUGH ZEBULUN

- Simeon: Nemuelite, Jaminite, Jachinite, Zerahite and Shaulite families —
  **22,200**.
- Gad: Zephonite, Haggite, Shunite, Oznite, Erite, Arodite and Arelite families
  — **40,500**.
- Judah: Shelanite, Perezite and Zerahite families; Perez branches Hezronite and
  Hamulite — **76,500**. Er and Onan remain previously dead in Canaan.
- Issachar: Tolaite, Punite, Jashubite and Shimronite families — **64,300**.
- Zebulun: Seredite, Elonite and Jahleelite families — **60,500**.

Each number is a completed subtotal under the same twenty-plus war-capable
selector. No individual life/death transition is inferred from a changed tribal
subtotal alone.

## Numbers 26:28–37 — JOSEPH: MANASSEH 52,700; EPHRAIM 32,500

Joseph divides into Manasseh and Ephraim.

Manasseh contains Machirite/Gileadite and Gilead's Iezerite, Helekite,
Asrielite, Shechemite, Shemidaite and Hepherite lines. Hepher's Zelophehad has
no sons and five named daughters: **Mahlah, Noah, Hoglah, Milcah and Tirzah**.
Manasseh totals **52,700**. The daughters are named lineage members; the source
does not count them inside the male war total.

Ephraim contains Shuthelahite, Becherite and Tahanite lines, with Eranites under
Shuthelah: **32,500**.

## Numbers 26:38–50 — BENJAMIN THROUGH NAPHTALI

- Benjamin: Belaite, Ashbelite, Ahiramite, Shuphamite and Huphamite lines;
  Ardite and Naamite beneath Bela — **45,600**.
- Dan: Shuhamite family — **64,400**.
- Asher: Imnite, Ishvite and Berite lines; Heberite and Malchielite beneath
  Beriah; Serah daughter of Asher named — **53,400**.
- Naphtali: Jahzeelite, Gunite, Jezerite and Shillemite lines — **45,400**.

Serah's named presence does not change the male war selector or supply her age,
location, census inclusion or death state.

## Numbers 26:51 — 601,730

The twelve subtotals close exactly:

```text
43,730 + 22,200 + 40,500 + 76,500
+ 64,300 + 60,500 + 52,700 + 32,500
+ 45,600 + 64,400 + 53,400 + 45,400
= 601,730
```

The first military census was 603,550. The observed difference is **−1,820**,
but the source supplies a replaced generation rather than a one-person ledger,
so no births/deaths/migrations are reverse-invented from that net difference.

## Numbers 26:52–56 — SIZE BY COUNT, LOCATION BY LOT

The LORD orders future land division among these names. More numerous groups
receive more inheritance and fewer receive less. The land is nevertheless
divided by lot according to father-tribe names, with inheritance divided by lot
between more and fewer.

The rules can coexist as distinct dimensions—amount by count, tribal allocation
by lot—but the exact parcel/lot/area integration is not performed here. No land
is allocated, entered, surveyed or possessed in this chapter.

## Numbers 26:57–62 — LEVITES: 23,000, SEPARATE SELECTOR

Levite lines are Gershonite, Kohathite and Merarite, plus Libnite, Hebronite,
Mahlite, Mushite and Korahite families. Kohath fathers Amram. Amram's wife is
Jochebed daughter of Levi, born to Levi in Egypt; she bears Aaron, Moses and
Miriam. Aaron's children are Nadab, Abihu, Eleazar and Ithamar. Nadab and Abihu
remain dead after strange fire.

Levite males aged **one month and upward** total **23,000**. They are explicitly
not counted among Israel's military count because they receive no inheritance
among Israel. The different selector, total and inheritance rule remain
separate.

## Numbers 26:63–65 — NONE OF THE OLD SELECTED MEN, EXCEPT TWO

Moses and Eleazar complete the Moab count. Among this new military census there
is no man from the earlier Moses-and-Aaron Sinai military census, because the
LORD had said that selected population would die in the wilderness. The stated
exceptions are Caleb son of Jephunneh and Joshua son of Nun.

This does not claim that only two humans from the older generation remain
alive. Moses, Eleazar, Levites, women and other people outside the original
military selector are not members of the compared set. The statement closes
the retained Numbers 14 outcome for the old counted war population only.

## Character and world-ledger changes

- Moses and Eleazar complete the second twenty-plus war census;
- all named clans and twelve subtotals are retained;
- 601,730 arithmetic verifies exactly;
- Korah's sons are explicitly alive after the rebellion event;
- Zelophehad's five daughters and Asher's daughter Serah are named;
- future inheritance uses group size and lot without present allocation;
- Levites are counted separately at one month-plus: 23,000;
- Jochebed/Amram/Aaron/Moses/Miriam and Aaron-child histories are restated;
- no old Sinai military-count man remains in the new war count except Caleb/Joshua;
- no unsupported contradiction, Captain, crack, YOINK or SKIP occurs;
- every living human, clan animal image, plant and face-like tally, lot, land,
  earth mouth, altar, census tablet or border is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — SECOND WAR-JOE INVENTORY`;
- selector card: `20+ / WAR-CAPABLE / FATHER HOUSE`;
- total: `601,730`;
- old total comparison: `603,550 -> 601,730 / NET -1,820 / CAUSE LIST NOT INCLUDED`;
- Levite side count: `1 MONTH+ / 23,000 / NO LAND`;
- inheritance router: `SIZE BY COUNT / LOCATION BY LOT`;
- survivor query: `OLD WAR COUNT ONLY`;
- exceptions: `CALEB + JOSHUA`;
- barcode: `CHB-NUM26-65-CENSUS601730-LEVITES23000-OLDCOUNT2-HELD`.

## FIR verification

- all 65 verse markers are represented in order;
- every clan grouping and tribal subtotal is retained;
- the twelve subtotals independently sum to 601,730;
- net change from 603,550 is calculated without backfilling individual causes;
- Dathan/Abiram/Korah event and Korah-son survival remain separately scoped;
- Zelophehad daughters and Serah are named without male-count inclusion;
- future land rules are not marked allocated or performed;
- size and lot relations remain distinct rather than called contradictory;
- Levite 23,000 uses the one-month-plus selector and remains outside land count;
- old-count survivor claim remains scoped to the Numbers 1 military census;
- Caleb/Joshua exceptions do not erase living selector-excluded people;
- no Captain or CrackFlix event is added without a completed contradiction;
- publication remains held and unpublished.

Continuation required: Numbers 27 resolves Zelophehad's daughters' inheritance,
defines the no-son succession chain and appoints Joshua before Eleazar/Israel.
