# CRACKHEAD NUMBERS 6

## Title page

**NO GRAPES. NO HAIRCUT. NO DEAD BODIES.**

**SOMEONE DIES SUDDENLY BESIDE YOU? YOU SINNED. START OVER.**

**THE LORD BLESS YOU AND KEEP YOU.**

Source parent: Numbers chapter 6, verses 1–27, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-006/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/005-PUT-THEM-OUT-PAY-BACK-PLUS-A-FIFTH-DRINK-THE-WRITTEN-CURSE.md`.

CrackFlix routing:

- new `S103-E001-NUM06 — SOMEONE ELSE DIES BESIDE YOU. YOU SINNED. START OVER.`

## Causal foundation

```text
MAN OR WOMAN MAKES NAZIRITE VOW
-> NO GRAPE PRODUCT
-> NO RAZOR / HAIR GROWS
-> NO DEAD BODY, INCLUDING CLOSE FAMILY

SOMEONE ELSE DIES VERY SUDDENLY BESIDE THE NAZIRITE
-> SEPARATION DEFILED
-> SOURCE CALLS IT SIN BY REASON OF THE DEAD
-> SHAVE DAY 7 + BIRDS DAY 8 + LAMB
-> ALL FORMER DAYS VOID
-> START SEPARATION AGAIN

VOW DAYS FULFILLED
-> ANIMALS + BREAD + MEAL/DRINK OFFERINGS
-> SHAVE + HAIR INTO FIRE
-> PRIEST PORTIONS WAVED
-> WINE ALLOWED AGAIN

AARON + SONS SPEAK BLESSING
-> LORD NAME ON ISRAEL
-> LORD SAYS I WILL BLESS THEM
```

## Numbers 6:1–4 — NOTHING FROM THE GRAPEVINE

The LORD tells Moses that either a man or a woman may make the special vow of
a Nazirite and separate to the LORD. During the separation the vowed person
must avoid wine, strong drink, wine vinegar, fermented-drink vinegar, grape
juice, fresh grapes, dried grapes and everything produced by the grapevine from
seed to skin. No person makes the vow here.

## Numbers 6:5–8 — LET THE HAIR GROW; AVOID EVERY DEAD BODY

No razor may touch the vowed person's head until the selected days are
fulfilled. The hair grows long and the person is holy to the LORD. The person
may not approach a dead body or become unclean even for a dead father, mother,
brother or sister. These are future vow conditions, not observed abstention,
hair growth, family death or contact.

## Numbers 6:9–12 — A STRANGER DIES; YOUR DAYS BECOME VOID

The rule then supplies an event outside the vowed person's described action:

```text
ANOTHER MAN DIES VERY SUDDENLY BESIDE HIM
-> HIS SEPARATION IS DEFILED
-> SOURCE: HE SINNED BY REASON OF THE DEAD
-> HIS FORMER DAYS ARE VOID
```

The person must shave on the seventh cleansing day. On the eighth day he must
bring two turtledoves or two young pigeons to the priest: one for a sin offering
and one for a burnt offering. The priest makes atonement, the person dedicates
his head again, brings a one-year-old male lamb as a trespass offering, and
restarts the separation because the former days no longer count.

The source describes no choice, approach, touch or other act by the Nazirite
between the stranger's sudden death and the assigned sin/restart cost. That
closed rule mismatch is `S103-E001-NUM06`. No actual death or restart occurs.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the boil, licks his finger, walks away and does not look back. The
vow rule and every required offering remain unchanged.

## Numbers 6:13–17 — THE COMPLETION INVENTORY

When the separation days are fulfilled, the Nazirite is brought to the Tent
door with:

- one defect-free one-year-old male lamb for a burnt offering;
- one defect-free one-year-old ewe lamb for a sin offering;
- one defect-free ram for peace offerings;
- a basket of unleavened bread, oil-mixed cakes and oil-anointed wafers;
- the corresponding meal and drink offerings.

The priest presents and offers them in the stated classes. This is a completion
procedure; nobody completes a vow or presents the inventory here.

## Numbers 6:18–21 — SHAVE IT AND PUT THE HAIR IN THE FIRE

The Nazirite shaves the separation hair at the Tent door and puts it in the
fire under the peace offering. After the shave, the priest places the boiled
ram shoulder, one unleavened cake and one wafer in the Nazirite's hands, then
waves them before the LORD. Those portions, with the waved breast and offered
thigh, are holy for the priest. After that, the Nazirite may drink wine.

The required offering is additional to whatever the person can afford and has
vowed. The person must do according to the vow and this law. No haircut,
burning, waving, priest transfer or resumed drinking occurs.

## Numbers 6:22–27 — PUT MY NAME ON THEM

The LORD tells Moses to give Aaron and his sons the exact Israelite blessing:

> **“The LORD bless you, and keep you.**
>
> **The LORD make his face to shine on you, and be gracious to you.**
>
> **The LORD lift up his face toward you, and give you peace.”**

Aaron and his sons are thereby to put the LORD's name on Israel, and the LORD
says, **“I will bless them.”** The chapter supplies the blessing text and its
future use; it does not narrate Aaron speaking it to an assembled Israel.

## Character and world-ledger changes

- either a man or woman may enter the vow;
- grape, razor and corpse boundaries apply throughout selected vow days;
- sudden nearby death triggers cleansing, offerings and a complete day reset;
- `S103` retains sudden third-party death against attributed sin and restart cost;
- vow-completion animals, bread, hair, fire and priest portions remain distinct;
- wine becomes permitted only after the completion sequence;
- Aaron and sons receive the exact blessing formula;
- no vow, death, defilement, offering, shaving, drinking or spoken blessing occurs;
- all living humans, birds, sheep, grapevines and grapes are Joe-faced if shown;
- Captain is permanently boilless and causally useless;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — VOLUNTARY HAIR AND GRAPE COMPLIANCE`;
- grape warning: `SEEDS TO SKINS: ABSOLUTELY FUCKING NONE`;
- razor lock: `DO NOT UNLOCK UNTIL VOW COMPLETE`;
- corpse proximity alarm: `SOMEONE ELSE DIED / YOUR SUBSCRIPTION RESET`;
- invoice: `DAY 7 SHAVE / DAY 8 BIRDS / PLUS ONE LAMB`;
- history screen: `FORMER DAYS: VOID`;
- hair disposal chute: `PUT HOLY HAIR UNDER RAM FIRE`;
- wine gate: `AFTER THAT: ENABLED`;
- CrackFlix: `S103 E001 — WRONG PLACE WHEN SOMEONE DIED`;
- blessing banner: `BLESS / KEEP / SHINE / GRACE / PEACE`;
- barcode: `CHB-NUM06-27-NO-GRAPES-START-OVER-BLESS-HELD`.

## FIR verification

- all 27 verse markers are represented in order;
- man/woman vow admission is retained;
- every grape-product, razor and corpse boundary remains distinct;
- close-family corpse exclusion is not omitted;
- sudden death is attributed to another man and no Nazirite act is invented;
- cleansing days, two birds, lamb and voided former days remain exact;
- `S103` rests only on the source's death/sin/void/cost relation;
- completion animals, breads, offerings, hair and priest portions remain complete;
- prescribed blessing is not reported as an observed performance;
- Captain appears only after `S103` closes and changes nothing;
- every living thing uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Numbers 7 records the princes' completed Tabernacle
dedication offerings, repeated daily inventories and the altar totals.
