# CRACKHEAD NUMBERS 2

## Title page

**EAST FIRST. SOUTH SECOND. TENT IN THE MIDDLE. WEST THIRD. NORTH LAST.**

**ELIASAPH SON OF DEUEL. ELIASAPH SON OF REUEL.**

Source parent: Numbers chapter 2, verses 1–34, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-002/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/001-COUNT-EVERY-WAR-JOE-EXCEPT-THE-TABERNACLE-JOES.md`.

Joined parents: Numbers 1 census, named tribal heads and Levite alternate-duty route.

CrackFlix routing:

- new `S101-E001-NUM02 — MY DAD IS DEUEL. MY DAD IS REUEL.`

The same Gad prince retains the name Eliasaph and the same office while his
father relation changes from Deuel in Numbers 1:14 to Reuel in Numbers 2:14.
No rename, alternate identity, translation rule or transition act is supplied.

## Causal foundation

```text
ISRAEL CAMPS BY STANDARD + FATHER'S-HOUSE BANNER
-> AROUND TENT AT A DISTANCE

EAST / JUDAH STANDARD
-> JUDAH 74,600 + ISSACHAR 54,400 + ZEBULUN 57,400
-> 186,400 -> MARCH FIRST

SOUTH / REUBEN STANDARD
-> REUBEN 46,500 + SIMEON 59,300 + GAD 45,650
-> 151,450 -> MARCH SECOND

TENT + LEVITES
-> MARCH IN MIDDLE / SAME RELATIVE PLACES

WEST / EPHRAIM STANDARD
-> EPHRAIM 40,500 + MANASSEH 32,200 + BENJAMIN 35,400
-> 108,100 -> MARCH THIRD

NORTH / DAN STANDARD
-> DAN 62,700 + ASHER 41,500 + NAPHTALI 53,400
-> 157,600 -> MARCH LAST

4 CAMP TOTALS -> 603,550
LEVITES -> NOT INCLUDED
ISRAEL -> ENCAMPED + SET OUT AS COMMANDED

NUMBERS 1: ELIASAPH SON OF DEUEL
NUMBERS 2: ELIASAPH SON OF REUEL
-> FATHER RELATION HAS TWO UNBRIDGED NAMES
-> CRACK
```

## Numbers 2:1–2 — CAMP AROUND THE TENT, BUT NOT ON TOP OF IT

The LORD tells Moses and Aaron that every Israelite is to camp by their own
standard and fathers'-house banner, around the Tent of Meeting but at a
distance. The source supplies relative organization, not a measured distance.

## Numbers 2:3–9 — EAST: JUDAH GOES FIRST

The east/sunrise side belongs to the Judah standard:

- Judah under Nahshon son of Amminadab: 74,600;
- Issachar under Nethanel son of Zuar: 54,400;
- Zebulun under Eliab son of Helon: 57,400.

Their camp total is 186,400, which equals the three retained tribal totals.
This division sets out first.

## Numbers 2:10–16 — SOUTH: REUBEN GOES SECOND

The south side belongs to the Reuben standard:

- Reuben under Elizur son of Shedeur: 46,500;
- Simeon under Shelumiel son of Zurishaddai: 59,300;
- Gad under Eliasaph son of Reuel: 45,650.

Their camp total is 151,450, matching its components. This division sets out
second.

Numbers 1:14 named the same Gad representative and office as **Eliasaph son of
Deuel**. Numbers 2:14 now says **Eliasaph son of Reuel**. Nothing between the
two occurrences changes Eliasaph, his office or his father relation, and the
source supplies no bridge between the two father names.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the boil, licks his finger, walks away eating the crack crystal he
believes he took, and does not look back. Eliasaph's father ledger remains
unchanged in both retained source Moments.

## Numbers 2:17 — THE PORTABLE BUILDING GOES IN THE MIDDLE

After the first two division camps, the Tent of Meeting and Levite camp set out
in the middle. The marching arrangement preserves the camp arrangement: every
person stays in their place by standards. This joins the Numbers 1 Levite
carrying assignment to a precise middle position.

## Numbers 2:18–24 — WEST: EPHRAIM GOES THIRD

The west side belongs to the Ephraim standard:

- Ephraim under Elishama son of Ammihud: 40,500;
- Manasseh under Gamaliel son of Pedahzur: 32,200;
- Benjamin under Abidan son of Gideoni: 35,400.

Their camp total is 108,100, matching its components. This division sets out
third, after the Tent/Levite middle unit has been placed in the sequence.

## Numbers 2:25–31 — NORTH: DAN GOES LAST

The north side belongs to the Dan standard:

- Dan under Ahiezer son of Ammishaddai: 62,700;
- Asher under Pagiel son of Ochran: 41,500;
- Naphtali under Ahira son of Enan: 53,400.

Their camp total is 157,600, matching its components. This division sets out
last by its standards.

## Numbers 2:32–33 — SAME 603,550; LEVITES STILL NOT IN IT

The four camp totals sum to 603,550, exactly matching Numbers 1. The Levites are
again explicitly outside that military count according to the LORD's command.
Their absence from the number does not erase their central camp and service
position.

## Numbers 2:34 — THEY CAMPED AND SET OUT THAT WAY

The narrator says Israel did according to all the LORD commanded Moses: they
encamped by standards and set out by families and fathers' houses. This closes
the camp-and-march compliance relation. The source does not date a particular
departure or name a destination here, so no specific cloud movement or journey
is invented.

## Character and world-ledger changes

- the counted tribal divisions gain east/south/west/north camp positions;
- each side retains three tribes, its standard leader and verified subtotal;
- the four subtotals independently reproduce 603,550;
- marching order is Judah first, Reuben second, Tent/Levites middle, Ephraim third, Dan last;
- Israel's encamping and setting-out compliance is narrated complete without a dated route;
- Numbers 1 Deuel and Numbers 2 Reuel remain distinct father-name claims for Eliasaph;
- S101 records the unbridged father-ledger change without choosing or merging a name;
- Captain appears only after S101 closes, remains boilless and changes nothing;
- all living people are Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — CAMPING TETRIS`;
- compass UI: `JUDAH EAST / REUBEN SOUTH / EPHRAIM WEST / DAN NORTH`;
- marching playlist: `1 / 2 / PORTABLE BUILDING / 3 / LAST`;
- center label: `LEVITE MOBILE HOME SUPPORT`;
- subtotal checker: `186400 + 151450 + 108100 + 157600 = 603550`;
- standards menu: `ONE FLAG PER THREE-TRIBE MEGACAMP`;
- genealogy alert: `GAD_PRINCE.FATHER != LAST_CHAPTER`;
- CrackFlix: `S101 — SAME PRINCE, DIFFERENT DAD LEDGER`;
- Captain sticker: `YOINK! NO FAMILY-TREE TECH SUPPORT`;
- barcode: `CHB-NUM02-34-FOUR-SIDES-MIDDLE-TENT-DEUEL-REUEL-HELD`.

## FIR verification

- all 34 verse markers are represented in order;
- all directions, tribes, leaders, fathers, counts and marching positions are retained;
- every three-tribe subtotal is arithmetically verified;
- four camp totals verify to 603,550 and preserve Levite exclusion;
- Tent/Levite middle position is not misnumbered as a tribal division;
- verse 34 compliance is retained without an invented date, destination or cloud act;
- S101 uses only the observable Deuel/Reuel father-name mismatch for the same Eliasaph role;
- no spelling explanation, identity merge, motive or preferred name is invented;
- Captain appears after the contradiction, says only YOINK, and has no effect;
- every living thing uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Numbers 3 inventories Aaron's sons and the Levite family-service lines, including the retained Nadab and Abihu death State.
