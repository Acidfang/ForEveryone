# CRACKHEAD NUMBERS 25

## Title page

**SPEAR TWO PEOPLE.**

**RECEIVE THE COVENANT OF PEACE.**

Source parent: Numbers chapter 25, verses 1–18, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-025/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/024-THIRD-CURSE-ATTEMPT-THIRD-BLESSING-I-WITHHELD-IT-GOD-DID.md`.

CrackFlix routing:

- new `S121-E001-NUM25 — SPEAR TWO PEOPLE / COVENANT OF PEACE`.

## Causal foundation

```text
ISRAEL AT SHITTIM
-> SEX WITH MOABITE WOMEN
-> INVITATION TO GOD-SACRIFICES
-> PEOPLE EAT + BOW
-> ISRAEL JOINS BAAL PEOR
-> LORD ANGER + PLAGUE

LORD ORDERS CHIEFS HANGED
MOSES ORDERS JUDGES TO KILL JOINED MEN
-> EXECUTION TOTALS NOT NARRATED

ZIMRI BRINGS COZBI BEFORE WEEPING CONGREGATION
-> PHINEHAS TAKES SPEAR / FOLLOWS INTO PAVILION
-> THRUSTS THROUGH BOTH
-> PLAGUE STOPS
-> 24,000 PLAGUE DEATHS
-> LORD CREDITS PHINEHAS WITH TURNING WRATH / ATONEMENT
-> COVENANT OF PEACE + EVERLASTING PRIESTHOOD

LORD ORDERS FUTURE MIDIAN HARASSMENT/STRIKING
```

## Numbers 25:1–3 — JOINED TO BAAL PEOR

Israel stays at Shittim. Some people begin sexual relations with Moabite women.
The women call the people to sacrifices for their gods; the people eat and bow
to those gods. Israel joins itself to Baal Peor, and the LORD's anger burns.

The chapter supplies group actions but no complete participant roster, count,
marital status, invitation wording or individual sequence.

## Numbers 25:4–5 — TWO JUDICIAL ORDERS, EXECUTION UNSTATED

The LORD tells Moses to take **all the chiefs of the people** and hang them
before the LORD in the sun so fierce anger may turn away. Moses tells Israel's
judges that each must kill his men who joined Baal Peor.

The source does not narrate either mass order being carried out, state whether
the chiefs are identical to the joined men, give a hanging or judge-killing
count, or say these orders stop the plague. The two target descriptions remain
separate and prospective.

## Numbers 25:6–9 — ONE SPEAR, TWO NAMED DEATHS, PLAGUE STOP

While Israel weeps at the Tent door, an Israelite man brings a Midianite woman
before Moses and the congregation. Phinehas, son of Eleazar and grandson of
Aaron, sees it, rises, takes a spear, follows them into the pavilion and thrusts
through both the man and the woman.

The plague then stops. The source states 24,000 people died by the plague. It
does not state whether the two spear deaths are inside or outside that number,
so no combined total is derived.

## Numbers 25:10–13 — VIOLENT ACT, PEACE-NAMED COVENANT

The LORD identifies Phinehas by lineage and says his jealousy turned divine
wrath away so Israel was not consumed. The LORD then gives him:

- “my covenant of peace”;
- an everlasting priesthood covenant for him and his offspring;
- the attribution that he was jealous for God and made atonement for Israel.

The observable relation is exact:

```text
PHINEHAS THRUSTS A SPEAR THROUGH TWO PEOPLE
-> BOTH DIE
-> PLAGUE STOPS
-> LORD CREDITS ACT WITH WRATH-TURNING / ATONEMENT
-> REWARD NAME: COVENANT OF PEACE
```

That closes `S121-E001-NUM25`. The contradiction is the peace-labelled reward
attached to the completed double killing; no claim about private intent or a
general definition of peace is required.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes Phinehas' new status boil, licks his finger, walks away and does not
look back. The covenant, plague stop and deaths remain unchanged.

## Numbers 25:14–15 — ZIMRI AND COZBI NAMED AFTER DEATH

The slain Israelite is named Zimri son of Salu, a Simeonite fathers'-house
prince. The slain Midianite woman is Cozbi daughter of Zur, head of a Midianite
fathers' house. Their names and parent/status relations arrive after the killing
but identify the already completed deaths; they are not new people or deaths.

## Numbers 25:16–18 — FUTURE MIDIAN COMMAND

The LORD orders Moses to harass and strike the Midianites because the source
attributes Peor and Cozbi deception/harassment to Midianite wiles. Cozbi is
called their sister and is stated to have been slain on the plague day.

This is a future command. Numbers 25 does not narrate Israel carrying out a
campaign, selecting targets, striking another Midianite or completing the
hostility. Those acts belong to later source if and when observed.

## Character and world-ledger changes

- Israel remains at Shittim and joins Baal Peor through stated sex/eating/bowing acts;
- LORD anger and a plague occur;
- chief-hanging and joined-man killing remain ordered but unobserved;
- Zimri brings Cozbi before Moses/congregation during public weeping;
- Phinehas takes one spear and kills both in the pavilion;
- the plague stops after 24,000 plague deaths;
- the source credits Phinehas with wrath-turning and atonement;
- Phinehas receives covenant of peace and everlasting priesthood;
- S121 retains the double killing/peace-labelled reward relation;
- Zimri/Salu and Cozbi/Zur identities join the completed event;
- future Midian harassment/striking is commanded but not executed;
- Captain's one post-closure appearance is causally null;
- every living human, god-image carrier, plant and face-like spear, pavilion,
  sun, plague, covenant, altar or Tent is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — PEOR INCIDENT RESPONSE`;
- judiciary queue: `CHIEFS: HANG / JOINED MEN: KILL / COMPLETION LOG MISSING`;
- spear ticket: `ONE INPUT / TWO TARGETS`;
- plague counter: `24,000 / SPEAR-DEATH INCLUSION UNKNOWN`;
- outcome card: `PLAGUE STOPPED`;
- reward ribbon: `COVENANT OF PEACE`;
- priesthood badge: `EVERLASTING / OFFSPRING ENABLED`;
- Midian task: `HARASS + STRIKE / NOT RUN IN THIS CHAPTER`;
- barcode: `CHB-NUM25-18-PEOR-SPEAR2-PLAGUE24000-PEACE-HELD`.

## FIR verification

- all 18 verse markers are represented in order;
- Moabite sex, sacrificial invitation, eating, bowing and Baal joining remain distinct;
- LORD anger and plague are retained without an invented transmission mechanism;
- chiefs and Baal-joined men are not silently merged;
- hanging/judge-killing commands are not marked executed;
- Zimri/Cozbi arrival, Phinehas sight, spear acquisition and double killing remain ordered;
- plague stop follows the spear act; source attribution is preserved;
- 24,000 plague deaths are not automatically combined with the two spear deaths;
- S121 closes only when peace covenant is explicitly given because of the act;
- Zimri/Cozbi names revise the prior unnamed identities without duplication;
- Midian harassment/striking remains prospective;
- Captain appears after the completed contradiction and changes nothing;
- publication remains held and unpublished.

Continuation required: Numbers 26 records the second census, clan totals,
inheritance-by-lot rules and the surviving wilderness-generation exceptions.
