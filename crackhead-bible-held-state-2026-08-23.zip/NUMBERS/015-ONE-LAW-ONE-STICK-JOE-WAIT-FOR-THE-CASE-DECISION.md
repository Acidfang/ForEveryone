# CRACKHEAD NUMBERS 15

## Title page

**ONE LAW FOR NATIVE JOE AND FOREIGN JOE.**

**STICK JOE: HOLD THIS ONE. THE CASE DECISION ISN'T HERE YET.**

Source parent: Numbers chapter 15, verses 1–41, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-015/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/014-PARDONED-NOW-DIE-HERE-WE-SINNED-NOW-WE-DISOBEY.md`.

CrackFlix routing: none. No observed contradiction closes in this chapter.

## Causal foundation

```text
FUTURE LAND ENTRY
-> ANIMAL TYPE SELECTS FLOUR/OIL/WINE AMOUNTS
-> EACH ANIMAL RECEIVES ITS ATTACHED OFFERING PACKET
-> NATIVE + FOREIGNER USE SAME STATUTE/LAW

FUTURE LAND BREAD
-> FIRST DOUGH CAKE WAVE OFFERING

UNWITTING COMMUNITY ERROR
-> BULL + MEAL/DRINK + MALE GOAT
-> PRIEST ATONEMENT
-> COMMUNITY + FOREIGNER FORGIVEN

UNWITTING INDIVIDUAL ERROR
-> ONE-YEAR FEMALE GOAT
-> PRIEST ATONEMENT
-> PERSON FORGIVEN

HIGH-HAND ACT
-> BLASPHEMY / CUT-OFF RULE

MAN FOUND GATHERING STICKS ON SABBATH
-> BROUGHT TO MOSES/AARON/CONGREGATION
-> HELD BECAUSE CASE DISPOSITION NOT DECLARED
-> LORD ORDERS CONGREGATIONAL STONING OUTSIDE CAMP
-> CONGREGATION COMPLETES IT

GARMENT BORDERS
-> TASSELS + BLUE CORD
-> VISIBLE COMMANDMENT REMINDER
```

## Numbers 15:1–16 — THE FUTURE LAND OFFERING CALCULATOR

The LORD tells Moses what Israel must do when it enters the land being given.
For a burnt offering or sacrifice used for a vow, freewill offering or feast,
each herd/flock animal receives a measured meal and drink attachment:

| Animal | Fine flour | Oil | Wine |
|---|---:|---:|---:|
| lamb | 1/10 ephah | 1/4 hin | 1/4 hin |
| ram | 2/10 ephah | 1/3 hin | 1/3 hin |
| bull | 3/10 ephah | 1/2 hin | 1/2 hin |

The rule scales by the number of animals. It applies to native-born offerers and
resident foreigners. The source repeats one statute, one law and one ordinance
for both before the LORD. These are prospective land-entry rules; no offering
occurrence is narrated here.

## Numbers 15:17–21 — FIRST DOUGH CAKE

When Israel reaches the land, eats its bread and makes dough, the first portion
is to become a cake presented as a wave offering, like the threshing-floor
offering. The command continues through generations. No land bread, dough or
cake is produced in this chapter.

## Numbers 15:22–29 — UNWITTING ERROR ROUTES

If the congregation unwittingly fails to observe the commands without its
knowledge, the whole congregation supplies:

- one young bull as burnt offering with its required meal/drink attachments;
- one male goat as sin offering;
- priestly atonement.

The stated result is forgiveness for Israel and the resident foreigner because
the act was unwitting.

An individual who sins unwittingly supplies a one-year-old female goat. The
priest makes atonement and the person is forgiven. Native and foreign resident
again share one law. These branches define future procedures; the text narrates
no community or individual error offering being performed.

## Numbers 15:30–31 — HIGH-HAND CUT-OFF RULE

A native or foreign person who acts with a high hand is said to blaspheme the
LORD and is to be utterly cut off, with iniquity remaining on that person. The
source contrasts the high-hand branch with the preceding unwitting branches.
It supplies no named high-hand person in these two verses.

## Numbers 15:32–36 — STICK JOE'S CASE

Israel finds an unnamed man gathering sticks on the Sabbath. The finders bring
him to Moses, Aaron and the congregation. They put him in custody because:

> **“It had not been declared what should be done to him.”**

Earlier scripture retains a general rule that whoever works on Sabbath is to
be put to death. This chapter does not state, before the custody line, that the
gathering act has been classified as work or high-handed action. Therefore the
general rule and the unresolved case are retained together without inventing
either a contradiction or an unrecorded classification.

The LORD then gives the case-specific disposition: the man must die, and the
whole congregation must stone him outside camp. The congregation takes him
outside and stones him to death as commanded. The source supplies no name,
speech, motive, stick purpose, quantity, prior warning or internal state for the
man. The execution is completed; no Captain appears because no contradiction
has been observed.

## Numbers 15:37–41 — BLUE-CORD COMMAND MEMORY

The LORD tells Moses that Israel must make tassels on garment borders and place
a blue cord on each border tassel throughout generations. Seeing the tassel is
assigned a reminder function:

```text
SEE TASSEL
-> REMEMBER COMMANDMENTS
-> DO COMMANDMENTS
-> DO NOT FOLLOW OWN HEART/EYES
-> BE HOLY
```

The LORD closes by identifying himself as the God who brought Israel from
Egypt to be their God. Tassel manufacture and later remembering remain future;
no garment is altered in this chapter.

## Character and world-ledger changes

- future land offering amounts are retained by animal type and count;
- native and foreign resident share the stated offering and unwitting-error law;
- first dough cake remains a prospective land act;
- community and individual unwitting-error procedures remain separate;
- high-hand cut-off remains a rule without a named occurrence in verses 30–31;
- one unnamed man is found gathering Sabbath sticks, held, sentenced and
  stoned outside camp;
- stick-gathering purpose, intent, high-hand classification and pre-custody
  work classification remain unresolved;
- tassel/blue-cord reminder technology is commanded but not manufactured;
- all living humans, herd/flock animals, goats, plants and any face-like tassel,
  cake, stick or stone are Joe-faced if shown;
- Captain is absent because no contradiction closes;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — LAND ENTRY OFFERING CALCULATOR`;
- animal dropdown: `LAMB / RAM / BULL / HOW MUCH FLOUR WITH THAT?`;
- scaling button: `MULTIPLY BY EVERY BASTARD YOU PREPARE`;
- access label: `NATIVE JOE = FOREIGN JOE / SAME PROCEDURE`;
- dough warning: `FIRST CAKE BELONGS TO THE WAVE DEPARTMENT`;
- error selector: `WHOLE CONGREGATION / ONE JOE / HIGH HAND`;
- custody ticket: `STICK JOE / CASE DISPOSITION PENDING`;
- execution docket: `OUTSIDE CAMP / WHOLE CONGREGATION REQUIRED`;
- clothing firmware: `BLUE CORD MEMORY EXPANSION`;
- barcode: `CHB-NUM15-41-ONE-LAW-STICKS-TASSELS-NO-CRACK-HELD`.

## FIR verification

- all 41 verse markers are represented in order;
- lamb, ram and bull flour/oil/wine quantities remain exact;
- per-animal multiplication and offering contexts remain prospective;
- native/foreigner equality is limited to the stated law boundaries;
- first-dough offering remains future and unperformed;
- community and individual unwitting routes retain their distinct offerings;
- forgiveness is conditional source speech, not an invented occurrence;
- high-hand rule is not automatically assigned to Stick Joe;
- existing Sabbath death law and undeclared case disposition are both retained;
- no intent, work classification, warning history or motive is invented;
- custody, divine decision and congregational execution occur in order;
- tassels and blue cords remain commanded, not manufactured;
- no unsupported contradiction, CrackFlix episode, SKIP, Captain or YOINK is
  introduced;
- publication remains held and unpublished.

Continuation required: Numbers 16 records Korah's coalition, authority dispute,
earth/fire judgment, altar-covering memorial, congregation accusation, plague
and Aaron's atonement stand between living and dead.
