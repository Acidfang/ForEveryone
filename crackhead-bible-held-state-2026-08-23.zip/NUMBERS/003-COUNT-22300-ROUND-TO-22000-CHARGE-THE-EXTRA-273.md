# CRACKHEAD NUMBERS 3

## Title page

**COUNT 22,300. ROUND IT TO 22,000.**

**22,273 IS 273 MORE. THAT'LL BE 1,365 SHEKELS.**

Source parent: Numbers chapter 3, verses 1–51, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-003/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/002-EAST-FIRST-SOUTH-SECOND-TENT-MIDDLE-WEST-THIRD-NORTH-LAST.md`.

Joined parents: Exodus firstborn death/consecration; Exodus and Leviticus
Tabernacle/priesthood lineages; Leviticus 10 Nadab and Abihu death State;
Numbers 1–2 Levite service/camp assignment.

CrackFlix routing:

- new `S102-E001-NUM03 — ROUND THE HEADCOUNT, CHARGE THE DIFFERENCE EXACTLY`.

The three Levite family totals sum to 22,300. The chapter states 22,000 and its
footnote explicitly identifies that as a rounded sum. It then treats 22,000 as
an exact substitution count, says 22,273 firstborn exceed the Levites by 273,
and collects exactly 273 times five shekels. The rounding explanation remains;
it does not make the exact redemption difference equal under both retained
counts.

## Causal foundation

```text
AARON'S SONS -> NADAB / ABIHU / ELEAZAR / ITHAMAR
NADAB + ABIHU -> STRANGE FIRE -> DIED / NO CHILDREN
ELEAZAR + ITHAMAR -> MINISTERED BEFORE AARON

LEVITES -> GIVEN TO AARON/SONS FOR TABERNACLE SERVICE
LEVITES -> SUBSTITUTE FOR ISRAEL FIRSTBORN
LEVITE LIVESTOCK -> SUBSTITUTE FOR ISRAEL FIRSTBORN LIVESTOCK

COUNT LEVITE MALES AGE 1 MONTH+
GERSHON 7,500 + KOHATH 8,600 + MERARI 6,200 = 22,300
STATED TOTAL -> 22,000 (FOOTNOTE: ROUNDED)

COUNT ISRAEL FIRSTBORN MALES AGE 1 MONTH+ -> 22,273
USE STATED 22,000 AS EXACT SUBSTITUTE COUNT
-> EXCESS 273
-> 5 SHEKELS EACH
-> 1,365 SHEKELS TAKEN AND GIVEN TO AARON/SONS

USE COMPONENT SUM 22,300
-> 22,273 DOES NOT EXCEED LEVITES

ROUNDED TOTAL / EXACT BILL
-> CRACK
```

## Numbers 3:1–4 — FOUR SONS; TWO DEAD; TWO MINISTERING

The Aaron-and-Moses generation history names Aaron's sons: firstborn Nadab,
then Abihu, Eleazar and Ithamar. All four are identified as anointed,
consecrated priests. Nadab and Abihu died before the LORD after offering
source-labelled strange fire in the Sinai wilderness, and they had no
children. Eleazar and Ithamar ministered as priests in the presence of Aaron.

This retains Leviticus 10's death occurrence and adds the no-children State. It
does not supply a burial act, so that frontier remains open.

## Numbers 3:5–10 — GIVE LEVI TO AARON FOR THE BUILDING JOB

The LORD commands Moses to bring Levi near and place the tribe before Aaron.
The Levites keep Aaron's and the congregation's requirements, serve at the
Tent, and guard its furnishings and Israel's obligations. They are wholly
given to Aaron and his sons on Israel's behalf. Aaron and his sons retain the
priesthood; a stranger who comes near is subject to the stated death rule. No
stranger approach or death occurs.

## Numbers 3:11–16 — LEVITES INSTEAD OF FIRSTBORN

The LORD claims the Levites instead of every Israelite firstborn who opens the
womb. He connects the substitution to the day he struck Egypt's firstborn and
made Israel's human and animal firstborn holy to himself. Moses then performs
the commanded census of every Levite male aged one month and upward.

## Numbers 3:17–26 — GERSHON: 7,500, WEST, FABRIC DEPARTMENT

Levi's sons are Gershon, Kohath and Merari. Gershon branches through Libni and
Shimei. The counted Gershonite males aged one month and upward total 7,500.
They camp west under Eliasaph son of Lael.

Their duty covers the Tabernacle/tent, covering, Tent entrance screen, court
hangings, court entrance screen and cords with their service.

## Numbers 3:27–32 — KOHATH: 8,600, SOUTH, HOLY FURNITURE DEPARTMENT

Kohath branches through Amram, Izhar, Hebron and Uzziel. The counted males aged
one month and upward total 8,600 and keep sanctuary requirements. They camp
south under Elizaphan son of Uzziel.

Their duty covers the ark, table, lampstand, altars, sanctuary vessels, screen
and related service. Eleazar son of Aaron is prince over the Levite princes and
oversees the sanctuary-duty keepers.

## Numbers 3:33–37 — MERARI: 6,200, NORTH, HARDWARE DEPARTMENT

Merari branches through Mahli and Mushi. The counted males aged one month and
upward total 6,200. They camp north under Zuriel son of Abihail.

Their duty covers boards, bars, pillars, sockets, instruments, court pillars,
sockets, pins and cords with their service.

## Numbers 3:38–39 — EAST GUARD; 22,000 TOTAL

Moses, Aaron and Aaron's sons camp east at the Tent front, keeping sanctuary
requirements for Israel. An outsider who comes near is subject to death; no
outsider does.

The chapter states the commanded Levite census total as 22,000. Its supplied
footnote observes that 7,500 + 8,600 + 6,200 is 22,300 and characterizes 22,000
as rounding to two significant digits. Both the three components and the stated
rounded total are retained.

## Numbers 3:40–43 — FIRSTBORN COUNT: 22,273

The LORD orders Moses to count every Israelite firstborn male aged one month
and upward by name, taking the Levites and Levite livestock as substitutes for
Israel's firstborn people and livestock. Moses performs the human count:
22,273.

## Numbers 3:44–51 — THE ROUNDED NUMBER BECOMES AN EXACT BILL

The LORD again directs the substitution and calls the firstborn who exceed the
Levites **273**. Each requires five sanctuary shekels, twenty gerahs per
shekel. Moses performs the collection:

```text
273 x 5 = 1,365 shekels
```

He gives the money to Aaron and his sons as commanded.

That calculation is internally exact only when the rounded 22,000 total is
used as though it were the actual Levite count:

```text
22,273 - 22,000 = 273
```

But the retained family counts give:

```text
7,500 + 8,600 + 6,200 = 22,300
22,273 - 22,300 = -27
```

The explicit rounding note explains why two Levite totals appear. It does not
bridge using the rounded figure to assert an exact 273-person excess and exact
money liability.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the boil, licks his finger, walks away and does not look back. The
1,365 shekels remain transferred to Aaron and his sons.

## Character and world-ledger changes

- Nadab and Abihu remain dead, childless, and still lack a narrated burial;
- Eleazar and Ithamar retain active priestly service;
- Levi's service is reconstructed as firstborn substitution;
- Gershon/Kohath/Merari gain exact family, count, side, leader and cargo duties;
- Moses completes the Levite and firstborn censuses;
- the source retains both 22,300 component sum and rounded 22,000 stated total;
- 273-person surplus, five-shekel rate and 1,365-shekel transfer are completed;
- S102 records rounded-count/exact-bill incompatibility without discarding the footnote;
- Captain appears only after money transfer completes and changes nothing;
- all living people and livestock are Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — HUMAN SUBSTITUTION ACCOUNTING`;
- priest roster: `4 INSTALLED / 2 DEAD / 2 ON SHIFT`;
- Levite age filter: `ONE MONTH+ — START THEM EARLY`;
- Gershon label: `FABRIC AND CORDS`;
- Kohath label: `DO NOT DROP THE HOLY FURNITURE`;
- Merari label: `FLAT-PACK TABERNACLE HARDWARE`;
- subtotal screen: `7500 + 8600 + 6200 = 22300`;
- official total: `22000 (ROUNDING ENABLED)`;
- billing screen: `ROUNDING DISABLED FOR MONEY`;
- CrackFlix: `S102 — APPROXIMATE PEOPLE, EXACT INVOICE`;
- barcode: `CHB-NUM03-51-22300-22000-273X5-1365-HELD`.

## FIR verification

- all 51 verse markers are represented in order;
- Aaron's four sons, priest States and Nadab/Abihu deaths/no-children relation are retained;
- all Levite substitution, service and outsider-death rules remain source-attributed;
- every Levite branch, family, camp side, leader, count and cargo class is retained;
- 7,500 + 8,600 + 6,200 independently verifies to 22,300;
- stated 22,000 and its rounding footnote remain visible;
- 22,273 firstborn, 273 declared excess, five-shekel rate and 1,365 transfer are retained and verified;
- S102 isolates the use of an approximate count as an exact liability base;
- no unknown missing 300 people, scribal cause, motive or preferred total is invented;
- Captain appears after completed collection, says only YOINK, and changes nothing;
- every living thing uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Numbers 4 counts working-age Levites and specifies how each cargo class is covered, carried and protected from lethal contact.
