# CRACKHEAD NUMBERS 32

## Title page

**CROSS FIRST.**

**GET THE LAND.**

**LAND GIVEN BEFORE CROSSING.**

Source parent: Numbers chapter 32, verses 1–42, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-032/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/031-EVERY-MALE-KILLED-NOW-KILL-THE-MALE-CHILDREN.md`.

CrackFlix routing: **S070-E003-NUM32**, `I HAVE DONE IT. IT HAS NOT HAPPENED YET.`

SKIP points to **S070-E002-EXO15 / GUIDED TO THE HOLY HABITATION / WILL BRING THEM IN**.
It skips explaining the retained contradiction and changes nothing.

## Causal foundation

```text
REUBEN + GAD HAVE MUCH LIVESTOCK
-> EAST LAND FITS LIVESTOCK
-> REQUEST: GIVE EAST LAND / DO NOT TAKE US ACROSS JORDAN

MOSES: BROTHERS FIGHT WHILE YOU SIT?
-> KADESH FAILURE COMPARISON
-> WARNING: TURNING AWAY MAY LEAVE ISRAEL IN WILDERNESS

REUBEN + GAD REVISE EXECUTION PLAN
-> BUILD EAST CITIES/FOLDS
-> EVERY ARMED MAN CROSSES
-> REMAIN UNTIL ALL ISRAEL INHERITS

MOSES' CONDITION
-> CROSS ARMED + WEST LAND SUBDUED
-> THEN RETURN + EAST LAND BECOMES POSSESSION

BEFORE CROSSING OR WEST SUBDUAL IS NARRATED
-> MOSES GIVES EAST LAND
-> EAST CITIES BUILT / RENAMED / OTHER EAST AREAS TAKEN
```

## Numbers 32:1–5 — LIVESTOCK FINDS LIVESTOCK LAND

Reuben and Gad possess a very great multitude of livestock. They observe that
Jazer and Gilead are livestock country and identify Ataroth, Dibon, Jazer,
Nimrah, Heshbon, Elealeh, Sebam, Nebo and Beon. They ask Moses, Eleazar and the
princes to give them that land and not bring them across the Jordan.

The request is observable. No unwillingness to fight is yet spoken by them.

## Numbers 32:6–15 — MOSES HEARS “SIT HERE WHILE THEY FIGHT”

Moses asks whether their brothers should go to war while they sit, and why they
would discourage Israel from crossing. He reconstructs the earlier Kadesh
spies' discouragement, the LORD's anger, the exclusion of twenty-plus men except
Caleb and Joshua, and forty wilderness years until that selected generation was
consumed.

He calls Reuben and Gad an increase of sinful men and warns that turning away
may again leave Israel in the wilderness and destroy the people. These are
Moses' comparison, classification and future warning. Reuben/Gad have not yet
refused armed service, and the warned renewed wilderness outcome does not occur.

## Numbers 32:16–19 — THEY SUPPLY THE MISSING WAR ACT

Reuben and Gad propose to build sheepfolds and fortified cities for livestock,
children and families, then cross armed before Israel. They promise not to
return home until every Israelite has received inheritance. Their own inheritance
will remain east of the Jordan, so they will not inherit west of it.

This changes the proposed process without erasing the original east-land request.

## Numbers 32:20–24 — CROSS, SUBDUE, THEN POSSESS

Moses accepts conditionally:

```text
EVERY ARMED MAN CROSSES BEFORE THE LORD
+ ENEMIES DRIVEN OUT
+ LAND SUBDUED
-> RETURN CLEAR OF OBLIGATION
-> EAST LAND SHALL BE YOUR POSSESSION
```

Failure means sin against the LORD, with the warning that their sin will find
them. Moses authorizes cities and folds now and tells them to perform what came
from their mouths.

## Numbers 32:25–32 — THE CONDITION IS PUBLICLY ROUTED

Reuben and Gad accept: families and livestock remain in Gilead while every
armed man crosses to battle. Moses routes the condition to Eleazar, Joshua and
tribal household heads:

- if every armed man crosses and the land is subdued, give them Gilead;
- if not, they receive possessions among Israel in Canaan.

They repeat that they will cross armed and retain their inheritance east of
Jordan. These are commitments; the crossing, western campaign, universal
inheritance and return have not occurred.

## Numbers 32:33 — THE CONDITIONAL LAND IS GIVEN NOW

Before any Jordan crossing or west-land subdual is narrated, Moses gives Gad,
Reuben and half-Manasseh the kingdoms of Sihon and Og with their cities, borders
and surrounding land.

The prior relation said **then**—after armed crossing and subdual—the east land
would become their possession, and told successor authorities to give it under
that condition. The source supplies no conditional-title, escrow, later-time
jump or fulfillment bridge for Moses' completed giving act.

**SKIP → S070-E002-EXO15.**

The land remains given and the world continues. Captain Crackhead later pokes
the addressed boil, says **“YOINK!”**, licks his finger and walks away. The
grant, promise and later building are unchanged.

## Numbers 32:34–38 — GAD AND REUBEN BUILD AND RENAME

Gad builds Dibon, Ataroth, Aroer, Atroth-shophan, Jazer, Jogbehah, Beth Nimrah
and Beth Haran as fortified cities and sheepfolds.

Reuben builds Heshbon, Elealeh, Kiriathaim, Nebo, Baal Meon and Sibmah. Names
are changed and the rebuilt cities receive other names. The source does not
provide every old-to-new name mapping, so none is invented.

## Numbers 32:39–42 — MANASSEH LINES TAKE AND NAME EASTERN PLACES

Machir son of Manasseh goes to Gilead, takes it, dispossesses its Amorites,
receives Gilead from Moses and lives there. Jair son of Manasseh takes villages
and calls them Havvoth Jair. Nobah takes Kenath and its villages and names it
Nobah after himself.

These east-side acts are completed. Half-Manasseh was not a speaker in the
opening Gad/Reuben request; its later grant and conquest remain a separately
introduced lineage rather than being backfilled into the negotiation.

## Character and world-ledger changes

- Reuben/Gad's livestock-driven east-land request is retained exactly;
- Moses' initial sit-while-brothers-fight model remains his spoken response;
- Kadesh history and renewed-wilderness warning remain attributed and scoped;
- Reuben/Gad add armed crossing and all-Israel inheritance conditions;
- Moses routes the agreement to Eleazar, Joshua and tribal heads;
- crossing, west-land subdual, universal inheritance and return remain future;
- Moses nevertheless completes the east-land grant, producing S070-E003;
- SKIP points to S070-E002 and changes no causal outcome;
- Gad/Reuben city building and partial renaming are completed;
- Machir/Jair/Nobah take, receive, inhabit and rename eastern places;
- one causally null Captain YOINK occurs after contradiction completion;
- every living human, livestock animal and face-like Jordan, city, fold, border,
  agreement, condition gate, inheritance map or nameplate is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — EAST-JORDAN LIVESTOCK DLC`;
- initial request: `LAND YES / CROSSING NO`;
- Moses parser: `NO CROSSING = NO WAR`;
- revised packet: `FAMILIES PARK / ARMED JOES CROSS / RETURN LAST`;
- condition gate: `CROSS + SUBDUE -> GIVE EAST LAND`;
- CrackFlix: `S070-E003 / LAND GIVEN BEFORE CONDITION`;
- SKIP: `S070-E002 / COMPLETED BEFORE NECESSARY ACTS`;
- city operation: `BUILD / FORTIFY / RENAME SOMEHOW`;
- Manasseh expansion: `TAKE / DISPOSSESS / RENAME AFTER SELF`;
- barcode: `CHB-NUM32-42-CROSS-FIRST-LAND-GIVEN-S070E003-HELD`.

## FIR verification

- all 42 verse markers are represented in order;
- opening request does not invent a refusal to fight;
- Moses' interpretation, Kadesh comparison and warning remain attributed;
- Reuben/Gad's revised armed-crossing plan is preserved as a later state;
- condition requires armed crossing and west-land subdual before possession;
- successor-authority routing and failure fallback remain exact;
- no promised crossing/subdual/inheritance/return is marked fulfilled;
- Moses' completed precondition grant forms a valid S070 recurrence;
- SKIP points backward and causes nothing;
- half-Manasseh is not backfilled into the opening speakers;
- all named city building, taking, inhabiting and renaming acts remain distinct;
- unknown rename mappings are not invented;
- Captain appears only after contradiction completion and changes no outcome;
- publication remains held and unpublished.

Continuation required: Numbers 33 inventories the journey stages from Egypt to
Moab, closes Aaron's death age/date, and commands future Canaan dispossession.
