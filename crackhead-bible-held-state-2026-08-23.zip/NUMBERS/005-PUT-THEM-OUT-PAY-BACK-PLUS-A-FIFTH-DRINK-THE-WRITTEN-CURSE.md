# CRACKHEAD NUMBERS 5

## Title page

**PUT THEM OUT. PAY IT BACK PLUS A FIFTH.**

**JEALOUS? WRITE THE CURSE. WIPE IT INTO WATER. MAKE HER DRINK IT.**

Source parent: Numbers chapter 5, verses 1–31, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-005/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/004-COVER-IT-FIRST-CARRY-IT-DONT-TOUCH-DONT-EVEN-LOOK.md`.

CrackFlix routing: none. The camp removal is performed. Confession,
restitution and the jealousy procedure are rules; the chapter narrates no
specific offence, accusation, drinking test or bodily result.

## Causal foundation

```text
SOURCE-LABELLED UNCLEAN CATEGORY
-> OUTSIDE CAMP
-> ISRAEL DID IT

HUMAN TRESPASS + GUILT
-> CONFESS ACTUAL SIN
-> RESTORE FULL VALUE + ONE FIFTH
-> HARMED PERSON
-> IF NO KINSMAN: PRIEST + ATONEMENT RAM

HUSBAND'S JEALOUSY
+ WIFE DEFILED OR WIFE NOT DEFILED
-> SAME PRIEST-ADMINISTERED TEST
-> INNOCENT: FREE + MAY CONCEIVE
-> GUILTY: STATED BODILY CURSE + CURSE AMONG PEOPLE
```

## Numbers 5:1–4 — PUT THEM OUTSIDE THE CAMP

The LORD tells Moses to command Israel to put outside camp every person the
source labels a leper, every person with a discharge, and every person made
unclean by a corpse. The command includes male and female. Its stated purpose
is preventing defilement of the camp where the LORD dwells.

Israel does it. The people in the named categories are sent outside camp as
the LORD told Moses. The source supplies no names, count or individual
conditions beyond those categories.

## Numbers 5:5–10 — CONFESS, REPAY, ADD ONE FIFTH

The LORD gives Moses a restitution rule. When a man or woman commits a human
sin that trespasses against the LORD and becomes guilty, that person must
confess the actual sin, restore the full amount and add one fifth. Payment goes
to the person harmed.

If the harmed man has no kinsman to receive it, the restitution belongs to the
LORD for the priest, in addition to the atonement ram. Every heave offering and
holy thing presented to a priest belongs to that priest. A person's holy things
remain that person's until they are given. No particular sin, confession,
victim, payment or ram occurs in this chapter.

## Numbers 5:11–15 — TWO ENTRY BRANCHES, ONE PROCEDURE

The LORD supplies two paths into the jealousy law:

- a wife has sexual relations with another man, the act is hidden, there is no
  witness and she was not caught; or
- the wife is not defiled, but a spirit of jealousy comes on her husband.

In either branch the husband brings his wife to the priest with one tenth of an
ephah of barley meal. He adds no oil or frankincense because it is the jealousy
offering, a memorial offering that brings iniquity to remembrance. No husband,
wife or offering is actually brought in this chapter.

## Numbers 5:16–18 — WATER, DUST, HAIR AND OFFERING

The priest is to set the woman before the LORD, put holy water in an earthen
vessel, and add dust from the Tabernacle floor. He loosens the woman's hair,
places the memorial offering in her hands, and holds the bitter water that
carries the curse.

## Numbers 5:19–22 — THE OATH AND “AMEN, AMEN”

The priest places the woman under oath. If no other man has lain with her and
she has not gone aside, she is free from the bitter water. If she has gone
aside and been defiled, the oath invokes the source's stated curse: her thigh
falls away and her body swells as the water enters her. The woman is required
to answer:

**“Amen, Amen.”**

These are prescribed words and conditional effects, not a narrated confession
or completed bodily event.

## Numbers 5:23–26 — WRITE IT, WIPE IT IN, BURN THE HANDFUL

The priest writes the curses in a book, wipes the writing into the bitter
water, and makes the woman drink. He takes the jealousy offering from her
hands, waves it before the LORD, presents it at the altar, burns a memorial
handful, and afterward gives her the water. This is the ordered procedure; no
priest performs it here.

## Numbers 5:27–28 — GUILTY AND INNOCENT OUTCOMES

If the woman has been defiled, the water becomes bitter in her, her body
swells, her thigh falls away, and she becomes a curse among her people. If she
has not been defiled and is clean, she is free and may conceive offspring.

The source states both branches. It does not select one through an observed
test in this chapter. No medical mechanism, diagnostic reliability, pregnancy,
consent, motive or additional meaning is supplied.

## Numbers 5:29–31 — SCOPE AND RESPONSIBILITY

The chapter calls this the law of jealousy. It applies when a wife goes aside
and is defiled and when a husband becomes jealous while she is not defiled.
The husband presents her before the LORD and the priest applies the law. The
closing rule says the man is free from iniquity and the woman bears her own
iniquity. The innocent branch has already declared the clean woman free; the
text does not narrate an innocent woman receiving a guilty outcome.

## Character and world-ledger changes

- Israel completes the commanded outside-camp removal;
- the removed people remain unnamed and uncounted;
- confession, full restitution and one-fifth addition become prospective law;
- the no-kinsman payment route terminates at priest plus atonement ram;
- jealousy may enter through actual defilement or jealousy without defilement;
- both entry branches use the same prescribed priest procedure;
- guilty and innocent outcomes remain distinct conditional branches;
- no offence, confession, restitution, jealousy accusation, priest test,
  drinking, curse effect or conception occurs;
- all living people are Joe-faced if shown;
- no contradiction, SKIP, crack, Captain or YOINK occurs;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — CAMP CLEANUP / DEBT RECOVERY / JEALOUSY LAB`;
- gate stamp: `MALE OR FEMALE / SOURCE CATEGORY -> OUTSIDE`;
- invoice: `RESTITUTION 100% + 20%`;
- routing label: `NO KIN? PRIEST + RAM`;
- barley sack: `NO OIL / NO FRANKINCENSE`;
- vessel: `HOLY WATER + TABERNACLE FLOOR DUST`;
- document shredder: `DISSOLVED TERMS AND CONDITIONS`;
- response button: `AMEN / AMEN`;
- branch display: `DEFILED? TRUE OR FALSE -> SAME TEST`;
- barcode: `CHB-NUM05-31-OUTSIDE-PLUS-FIFTH-BITTER-WATER-HELD`.

## FIR verification

- all 31 verse markers are represented in order;
- completed camp removal is separated from prospective rules;
- source categories are preserved without diagnoses, names or counts;
- confession, restitution, fifth, kinless route and priest ownership remain
  distinct;
- the actual-defilement and no-defilement jealousy entries are both retained;
- the ordered water/dust/oath/writing/offering procedure is preserved;
- “Amen, Amen” remains prescribed speech, not an observed admission;
- innocent and guilty outcomes are not merged;
- no medicine, motive, reliability, consent or biological mechanism is invented;
- no contradiction is closed from a procedure that never occurs;
- no Captain, SKIP, crack or YOINK is added;
- publication remains held and unpublished.

Continuation required: Numbers 6 gives separation-vow rules, the completed
princely offerings and the priestly blessing.
