# CRACKHEAD NUMBERS 36

## Title page

**MARRY WHO YOU THINK BEST.**

**INSIDE THE TRIBE.**

Source parent: Numbers chapter 36, verses 1–13, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-036/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/035-FORTY-EIGHT-CITIES-SIX-REFUGES-ONE-WITNESS-NOT-ENOUGH.md`.

CrackFlix routing: none. No completed observable contradiction is derived.

## Causal foundation

```text
ZELOPHEHAD'S DAUGHTERS OWN FATHER'S INHERITANCE
+ MARRIAGE CAN JOIN THEM TO ANOTHER TRIBE
-> HEADS OF GILEAD/MACHIR/MANASSEH PRESENT TRANSFER CONSEQUENCE
-> MARRIAGE WOULD MOVE LAND OUT OF MANASSEH
-> JUBILEE WOULD RETAIN IT IN THE NEW TRIBE

MOSES CARRIES LORD'S RULING
-> CLAIMANTS SPEAK RIGHT
-> DAUGHTERS MAY CHOOSE HUSBANDS
-> SELECTOR: FATHER'S TRIBAL FAMILY ONLY
-> INHERITANCE MUST NOT MOVE TRIBE TO TRIBE

FIVE DAUGHTERS MARRY PATERNAL COUSINS
-> INHERITANCE REMAINS IN MANASSEH
```

## Numbers 36:1–4 — THE SECOND ZELOPHEHAD CASE

Heads of the Gilead-Machir-Manasseh family of Joseph come before Moses and the
Israelite princes. They retain two prior commands:

- Israel's land is divided by lot;
- Zelophehad's inheritance goes to his daughters.

They identify a prospective interaction: if the daughters marry men from other
tribes, their inherited land joins the husbands' tribe and is removed from
Manasseh's lot. At Jubilee, the land would remain added to that new tribe rather
than returning across the tribal boundary.

This is their stated future consequence. No daughter has yet married and no
inheritance has moved.

## Numbers 36:5–9 — THEY SPEAK RIGHT; CHOICE GETS A TRIBAL SELECTOR

Moses commands according to the LORD's word and says Joseph's tribe speaks
right. Zelophehad's daughters may marry whom they think best, with one explicit
selector: the husband must be within the family of their father's tribe.

The rule generalizes to every daughter possessing tribal inheritance. Each must
marry within the family of her father's tribe so each tribe keeps its inherited
land and no inheritance moves from tribe to tribe.

“Whom they think best” and “within the father's tribal family” are one scoped
permission. The qualifier is stated in the same ruling; it is not a later denial
of an unqualified promise and does not produce crack.

## Numbers 36:10–12 — FIVE MARRIAGES COMPLETE THE CASE

Mahlah, Tirzah, Hoglah, Milcah and Noah do as commanded. They marry sons of
their father's brothers—paternal cousins—inside the families of Manasseh son of
Joseph. Their inheritance remains in the tribe of their father's family.

The five marriage occurrences and tribal-retention outcome are completed. The
source does not name the five husbands, pair a particular husband with a
particular daughter, describe ceremonies, or identify individual parcels.

## Numbers 36:13 — NUMBERS CLOSES IN THE MOAB PLAINS

The chapter and book close by identifying these as commandments and ordinances
the LORD commanded through Moses to Israel in the Moab plains by the Jordan at
Jericho.

The Book of Numbers is now reconstructed through all 36 chapters. Israel remains
at the Moab boundary; Jordan crossing, western conquest, lots and general land
possession remain future.

## Character and world-ledger changes

- Gilead/Machir/Manasseh household heads present the inheritance-transfer case;
- their future transfer/Jubilee consequence remains attributed to their claim;
- Moses carries the LORD-word ruling and says they speak right;
- inherited-land daughters receive tribe-bounded spouse choice;
- the rule generalizes without inventing other daughters or marriages;
- all five Zelophehad daughters complete marriages to paternal cousins;
- their inheritance remains in Manasseh;
- husband names, daughter-husband pairings, ceremonies and parcels remain unresolved;
- Numbers closes at the Moab plains without inventing Jordan crossing;
- no unsupported contradiction, Captain, crack, YOINK or SKIP occurs;
- every living human and face-like inheritance parcel, lot, family tree,
  marriage selector, Jubilee clock, tribal border or book-end marker is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — INHERITANCE FIREWALL PATCH`;
- input: `5 DAUGHTERS + LAND + POSSIBLE OUT-TRIBE MARRIAGE`;
- transfer warning: `MARRIAGE -> LAND CHANGES TRIBAL LEDGER`;
- Jubilee warning: `RETURN DOES NOT CROSS NEW OWNER-TRIBE`;
- choice control: `WHO YOU THINK BEST [FILTER: FATHER TRIBE]`;
- result: `5/5 PATERNAL-COUSIN MATCHES / MANASSEH LAND RETAINED`;
- missing fields: `HUSBAND NAMES / PAIRINGS / PARCELS`;
- book status: `NUMBERS 36/36 HELD`;
- barcode: `CHB-NUM36-13-CHOOSE-WITHIN-TRIBE-NUMBERS-CLOSED-HELD`.

## FIR verification

- all 13 verse markers are represented in order;
- complainant lineage and prior lot/daughter commands remain exact;
- cross-tribe transfer and Jubilee effect remain prospective claim components;
- claimants are explicitly validated by the LORD-word ruling;
- choice permission retains its same-sentence tribal-family selector;
- no false contradiction is created from scoped permission;
- generalized inherited-daughter rule is retained without invented instances;
- all five daughter names and completed marriages remain exact;
- husbands remain unnamed and unpaired where source is silent;
- inheritance retention in Manasseh is completed;
- Numbers closes without inventing Canaan entry or general land division;
- no Captain or CrackFlix event is added without a completed contradiction;
- publication remains held and unpublished.

Continuation required: Deuteronomy 1 begins Moses' retrospective address,
leadership appointment history and Kadesh refusal reconstruction.
