# CRACKHEAD NUMBERS 1

## Title page

**COUNT EVERY WAR JOE BY NAME, FAMILY, HOUSE AND TRIBE.**

**DON'T COUNT THE TABERNACLE JOES IN THAT COUNT. THEY HAVE TO CARRY THE BUILDING.**

Source parent: Numbers chapter 1, verses 1–54, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-001/job.json` and `source.usfm`.

Parent manuscript: `LEVITICUS/027-FIFTY-THIRTY-ADD-A-FIFTH-DONT-SWAP-OR-BOTH-ARE-HOLY.md`.

Joined parents: Exodus Tent construction and erection; Israel's tribal and
family lineages; Leviticus priest/sanctuary service rules.

CrackFlix routing: none. The military census includes an exact eligibility
selector, and Levi is expressly excluded from that count because a different
service assignment is given. The chapter narrates the census and obedience as
completed.

## Causal foundation

```text
YEAR 2 / MONTH 2 / DAY 1 / SINAI WILDERNESS / TENT OF MEETING
LORD -> MOSES

COUNT ISRAEL
-> FAMILY + FATHER'S HOUSE + NAME
-> MALE + AGE 20 OR MORE + ABLE TO GO TO WAR
-> DIVISIONS
-> MOSES + AARON + ONE NAMED HEAD PER TRIBAL LINE

ASSEMBLE CONGREGATION + DECLARE ANCESTRY
-> COUNT EACH ELIGIBLE PERSON
-> 12 TRIBAL-LINE TOTALS
-> 603,550

LEVI
-> NOT IN MILITARY CENSUS
-> APPOINTED OVER TABERNACLE + FURNISHINGS
-> CARRY / CARE / CAMP AROUND
-> WHEN MOVING: TAKE DOWN / SET UP
-> STRANGER COMES NEAR: DEATH RULE

OTHER ISRAEL
-> CAMP BY CAMP + STANDARD + DIVISION
LEVITES AROUND TABERNACLE
-> WRATH-PREVENTION CLAIM + RESPONSIBILITY

ISRAEL DID ACCORDING TO ALL THE LORD COMMANDED MOSES
```

## Numbers 1:1 — THE COUNT GETS A DATE AND ADDRESS

The LORD speaks to Moses in the Tent of Meeting in the Sinai wilderness on the
first day of the second month of the second year after Israel left Egypt. This
is a new dated speech occurrence at the existing Tent; it does not establish
that the cloud has moved or resolve the outside-Tent identity question.

## Numbers 1:2–4 — WHO THIS COUNT COUNTS

The commanded census is organized by families, fathers' houses and individual
names. Its counted class is every male twenty years old and upward who is able
to go out to war in Israel. Moses and Aaron must count them by divisions, with
one head of a fathers' house from every tribe.

“All the congregation” is immediately bounded by the stated age, sex and
war-eligibility selectors. People outside the selector are not silently
declared absent from Israel.

## Numbers 1:5–16 — TWELVE NAMED COUNTING JOES

The LORD names the men who stand with Moses and Aaron:

- Reuben: Elizur son of Shedeur;
- Simeon: Shelumiel son of Zurishaddai;
- Judah: Nahshon son of Amminadab;
- Issachar: Nethanel son of Zuar;
- Zebulun: Eliab son of Helon;
- Ephraim: Elishama son of Ammihud;
- Manasseh: Gamaliel son of Pedahzur;
- Benjamin: Abidan son of Gideoni;
- Dan: Ahiezer son of Ammishaddai;
- Asher: Pagiel son of Ochran;
- Gad: Eliasaph son of Deuel;
- Naphtali: Ahira son of Enan.

They are identified as congregation-called tribal princes and heads of
Israel's thousands. Joseph's two descendant lines supply Ephraim and Manasseh;
there is no separate Joseph total.

## Numbers 1:17–19 — THEY ASSEMBLED AND COUNTED THEM

Moses and Aaron take the named men. On the same dated day they assemble the
whole congregation. The people declare ancestry by families and fathers'
houses, and the eligible males are identified one by one. Moses counts them in
the Sinai wilderness as commanded. These are performed acts, not future rules.

## Numbers 1:20–43 — THE TWELVE TOTALS

The same lineage, family, house, name, age and war-capacity boundary is repeated
for each counted tribal line:

| Tribal line | Counted |
|---|---:|
| Reuben | 46,500 |
| Simeon | 59,300 |
| Gad | 45,650 |
| Judah | 74,600 |
| Issachar | 54,400 |
| Zebulun | 57,400 |
| Ephraim | 40,500 |
| Manasseh | 32,200 |
| Benjamin | 35,400 |
| Dan | 62,700 |
| Asher | 41,500 |
| Naphtali | 53,400 |

Every total is retained as a source count. The chapter supplies no weapons,
combat action, deployment or claim that all counted people later fight.

## Numbers 1:44–46 — 603,550

Moses, Aaron and the twelve fathers'-house representatives complete the count.
The twelve stated totals sum to 603,550 eligible Israelite males aged twenty or
older and able to go to war. The arithmetic agrees with the narrated total.

## Numbers 1:47–50 — LEVI IS NOT MISSING; LEVI HAS ANOTHER JOB

The Levites are not counted among the military tribal totals. The LORD
explicitly commands Moses not to include Levi in that census and instead to
appoint the Levites over the Tabernacle of the Testimony, its furnishings and
everything belonging to it. They are to carry it, care for it and camp around
it.

The exclusion and alternate assignment are one stated routing relation. It is
not a rule claiming everyone is counted while secretly discarding a tribe.

## Numbers 1:51 — MOVING THE BUILDING; STRANGER-DEATH RULE

When the Tabernacle moves, the Levites are to take it down; when it is set up,
they are to erect it. A stranger who comes near is to be put to death. No move,
dismantling, erection, stranger approach or death occurs in the chapter. The
source does not identify a prospective stranger or execution actor here, so
neither is invented.

## Numbers 1:52–53 — CAMPS OUTSIDE, LEVITES AROUND THE TESTIMONY

Israel is commanded to pitch by camps, standards and divisions. The Levites
camp around the Tabernacle of the Testimony, hold responsibility for it, and
are assigned there so that wrath will not fall on the congregation. The
wrath-prevention relation remains a direct divine claim; its mechanism is not
invented.

## Numbers 1:54 — THEY DID IT

The narrator says Israel did according to all the LORD commanded Moses. That
closes the chapter's obedience relation, including the census exclusion and
service/camp assignments. It does not manufacture a Tabernacle journey,
stranger trespass or death, because those remain conditional event branches.

## Character and world-ledger changes

- the narrative advances to year two, month two, day one after Egypt;
- Moses, Aaron and twelve named tribal heads conduct the census;
- ancestry declarations and individual counting occur;
- twelve military-eligibility totals and the verified 603,550 sum are retained;
- women, people under twenty, people unable to go to war and Levites remain outside this census selector, not outside Israel;
- Levi receives a separate Tabernacle carrying/care/camp assignment;
- Israel's camp/standard/division arrangement is narrated obeyed;
- future Tabernacle movement and stranger-death branches remain unperformed;
- all living counted and uncounted people are Joe-faced if shown;
- no contradiction, SKIP, crack, Captain appearance or YOINK occurs;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — YES, THIS ONE HAS NUMBERS`;
- date stamp: `Y2-M2-D1 / SINAI / TENT OFFICE`;
- census form: `NAME / DAD HOUSE / FAMILY / TRIBE / 20+ / WAR?`;
- human spreadsheet: `ONE JOE PER ROW`;
- tribal administrators: `TWELVE HEAD JOES WITH CLIPBOARDS`;
- Joseph splitter: `EPHRAIM + MANASSEH / NO DUPLICATE JOSEPH ROW`;
- checksum: `46,500 + ... + 53,400 = 603,550`;
- exclusion router: `LEVI: NOT THIS LIST / CARRY THE BUILDING`;
- portable-building warning: `AUTHORIZED TABERNACLE JOES ONLY`;
- wrath firewall: `LEVITES CAMP HERE`;
- barcode: `CHB-NUM01-54-COUNTED-603550-LEVITES-SEPARATE-HELD`.

## FIR verification

- all 54 verse markers are represented in order;
- exact date, place and post-Egypt relation are retained;
- census eligibility and lineage selectors remain complete;
- all twelve named representatives and fathers are retained;
- all twelve source totals are retained and arithmetically verify to 603,550;
- performed assembly, ancestry declaration and census are distinguished from future military action;
- Levi's exclusion is joined to the explicit alternate Tabernacle assignment;
- verse 54 closes command compliance without inventing conditional move/death events;
- stranger death and wrath-prevention claims remain source-attributed;
- every living thing uses Joe face if shown;
- no contradiction, SKIP, crack, Captain or YOINK is added;
- publication remains held and unpublished.

Continuation required: Numbers 2 assigns every tribal division its camp and marching position around the Tent of Meeting.
