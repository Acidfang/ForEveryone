# CRACKHEAD NUMBERS 12

## Title page

**WE BOTH SPOKE. GOD WAS ANGRY WITH THEM. WE BOTH SINNED.**

**SHE TURNED WHITE AND GOT SEVEN DAYS OUTSIDE.**

Source parent: Numbers chapter 12, verses 1–16, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-012/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/011-WANT-MEAT-HERES-A-MONTH-MEAT-IN-TEETH-PLAGUE.md`.

CrackFlix routing:

- new `S109-E001-NUM12 — WE BOTH DID IT. ONLY SHE GOT PUNISHED.`

## Causal foundation

```text
MIRIAM + AARON SPEAK AGAINST MOSES
-> CUSHITE WIFE GROUND
-> LORD-SPEAKS-ONLY-THROUGH-MOSES QUESTION
-> LORD HEARS

LORD CALLS MOSES + AARON + MIRIAM
-> DISTINGUISHES PROPHET DREAM/VISION FROM MOSES PLAIN SPEECH/FORM
-> ANGER BURNS AGAINST THEM
-> CLOUD DEPARTS

MIRIAM -> WHITE / SOURCE-LABELLED LEPROUS
AARON -> OBSERVES / ADMITS WE SINNED
MOSES -> BEGS HEALING
LORD -> SEVEN DAYS OUTSIDE
MIRIAM EXCLUDED -> WHOLE CAMP WAITS
MIRIAM BROUGHT BACK -> ISRAEL TRAVELS TO PARAN
```

## Numbers 12:1–3 — MIRIAM AND AARON BOTH SPEAK

Miriam and Aaron speak against Moses because he married an unnamed Cushite
woman. The source confirms that he married her but does not name her, identify
her with Zipporah, call her a replacement wife or supply a marriage date.

They jointly ask:

> **“Has the LORD indeed spoken only with Moses? Hasn't he spoken also with us?”**

The LORD hears it. The narrator then states that Moses is more humble than every
man on earth. That is narrator attribution, not Moses speaking about himself in
this scene.

## Numbers 12:4–9 — THREE CALLED; TWO CALLED FORWARD

The LORD suddenly orders Moses, Aaron and Miriam to come to the Tent. All three
come out. The LORD descends in the cloud pillar, stands at the Tent door and
calls Aaron and Miriam forward.

The LORD distinguishes communication states:

- prophets: LORD known in vision and speaking in dream;
- Moses: faithful in the LORD's house, mouth-to-mouth, plain rather than riddled,
  and seeing the LORD's form.

“Form” is retained as the source word. It is not silently converted into face,
body, dream or the prior protected glory-viewing occurrence. The LORD asks why
they were not afraid to speak against Moses. The LORD's anger burns against
**them**, and the LORD departs.

## Numbers 12:10–13 — MIRIAM CHANGES; AARON SAYS “WE”

When the cloud leaves the Tent, Miriam is source-labelled leprous and white as
snow. Aaron looks and observes that state. No matching bodily change is recorded
for Aaron.

Aaron tells Moses:

> **“Please don't count this sin against us, in which we have done foolishly,
> and in which we have sinned.”**

He asks that Miriam not remain like a partly consumed stillborn body. Moses
cries to the LORD, **“Heal her, God, I beg you!”** The source does not state that
Aaron receives a hidden punishment or that Miriam alone performed the speech.

## Numbers 12:14–15 — JOINT ACT, SINGLE EXCLUSION

The LORD compares the consequence to seven days of shame if a father had spit
in her face and orders Miriam shut outside camp for seven days, then brought in.
No father or actual spitting act occurs.

The complete mismatch is:

```text
MIRIAM + AARON -> BOTH SPEAK
LORD -> ANGRY AGAINST THEM
AARON -> WE ACTED FOOLISHLY / WE SINNED
MIRIAM -> BODILY AFFLICTION + SEVEN-DAY EXCLUSION
AARON -> NO PUNISHMENT STATE SUPPLIED
```

That is `S109-E001-NUM12`. No reason for the unequal allocation is invented.

Miriam is actually shut outside seven days. Israel does not travel until she is
brought back. The source confirms reentry after seven days but does not directly
state the moment or mechanism of bodily healing.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the boil, licks his finger, walks away and does not look back. Miriam,
Aaron, Moses and the waiting camp continue unchanged by him.

## Numbers 12:16 — HAZEROTH TO PARAN

After Miriam's reentry, Israel leaves Hazeroth and camps in the wilderness of
Paran. The delayed departure and new encampment are completed.

## Character and world-ledger changes

- unnamed Cushite wife enters Moses' retained marriage history without an
  invented Zipporah merge;
- Miriam and Aaron jointly speak against Moses and jointly question prophetic
  exclusivity;
- the LORD distinguishes prophet dream/vision from Moses plain communication;
- LORD anger is directed against both speakers;
- Miriam alone receives the observed bodily change and seven-day exclusion;
- Aaron explicitly admits joint foolishness and joint sin;
- Moses requests healing; healing mechanism/moment remains unstated;
- `S109` retains the joint-action/single-punishment allocation;
- Israel waits seven days, then moves from Hazeroth to Paran;
- all living humans are Joe-faced; cloud and face-like bodily conditions may
  receive Joe faces when rendered;
- Captain is permanently boilless and causally useless;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — JOINT INCIDENT / SINGLE-PERSON DISCIPLINE`;
- wife field: `CUSHITE WOMAN / NAME NOT PROVIDED / DO NOT AUTO-MERGE`;
- communication tiers: `DREAM / VISION / MOUTH-TO-MOUTH / PLAIN MODE`;
- incident form: `ACTORS: MIRIAM + AARON`;
- confession form: `WE DID FOOLISHLY / WE SINNED`;
- consequence form: `MIRIAM ONLY / 7 DAYS OUTSIDE`;
- camp status: `DEPARTURE BLOCKED UNTIL REENTRY`;
- CrackFlix: `S109 E001 — GROUP OFFENCE, INDIVIDUAL INVOICE`;
- barcode: `CHB-NUM12-16-BOTH-SPOKE-SHE-OUTSIDE-HELD`.

## FIR verification

- all 16 verse markers are represented in order;
- Cushite wife remains unnamed and unmerged;
- joint speech and exact question remain attributed to Miriam/Aaron;
- Moses humility remains narrator statement;
- dream/vision/plain/form distinctions remain source-exact;
- form is not merged with face or prior glory-viewing claims;
- LORD anger against both and Aaron's joint confession are retained;
- Miriam's observed condition/exclusion and Aaron's absent punishment remain
  observable states without invented cause;
- father-spitting comparison is not turned into an event;
- reentry is observed but healing mechanism/moment remains unresolved;
- Captain appears only after `S109` closes and changes nothing;
- every living thing uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Numbers 13 sends twelve spies, retains the land/fruit
evidence, majority danger report, Caleb's contrary assessment and giant/grasshopper
claims.
