# CRACKHEAD NUMBERS 14

## Title page

**PARDONED. NOW DIE IN THE WILDERNESS.**

**WE HAVE SINNED. NOW LET'S DISOBEY THE CURRENT COMMAND.**

Source parent: Numbers chapter 14, verses 1–45, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-014/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/013-WE-FELT-LIKE-GRASSHOPPERS-SO-THEY-SAW-GRASSHOPPERS.md`.

CrackFlix routing:

- `S097-E002-NUM14 — PARDONED / WILDERNESS DEATH ACCOUNT`
- `S068-E002-NUM14 — WE SINNED / CURRENT COMMAND DISOBEYED`

Both repeat retained contradiction types. Each SKIP points to the earlier exact
episode and omits explanation only. The world continues.

## Causal foundation

```text
CONGREGATION WEEPS / COMPLAINS
-> WISHES IT HAD DIED IN EGYPT OR WILDERNESS
-> PREDICTS WIVES/CHILDREN CAPTURED
-> PROPOSES NEW LEADER + RETURN TO EGYPT

JOSHUA/CALEB: LAND GOOD / DO NOT REBEL / DO NOT FEAR
-> CONGREGATION THREATENS STONING
-> LORD GLORY APPEARS

LORD PROPOSES PESTILENCE + DISINHERITANCE + MOSES-NATION
-> MOSES ARGUES NATIONS WILL SAY LORD COULD NOT COMPLETE PROMISE
-> MOSES QUOTES FORGIVING / NOT CLEARING ATTRIBUTE
-> ASKS PARDON
-> LORD: I HAVE PARDONED
-> ADULT COMPLAINERS EXCLUDED + DIE IN WILDERNESS
-> CHILDREN ENTER / 40 YEARS WANDERING
-> TEN EVIL-REPORT SPIES DIE; JOSHUA/CALEB LIVE

PEOPLE: WE HAVE SINNED; WE WILL GO UP
-> MOSES: CURRENT COMMAND SAYS DO NOT GO / LORD NOT WITH YOU
-> PEOPLE GO ANYWAY; ARK + MOSES STAY
-> AMALEKITES/CANAANITES DEFEAT THEM TO HORMAH
```

## Numbers 14:1–4 — THE RETURN-TO-EGYPT PROPOSAL

The congregation cries through the night, complains against Moses and Aaron,
and says it wishes it had died in Egypt or the wilderness. It asks why the LORD
brings it toward sword death and predicts its wives and little ones will be
captured or killed. The people propose selecting a leader and returning to
Egypt. These are spoken wishes, predictions and a proposal; no return occurs.

## Numbers 14:5–10 — LAND DEFENCE, THEN A STONING THREAT

Moses and Aaron fall on their faces. Joshua and Caleb tear their clothes and
tell the congregation the land is exceedingly good. They condition entry on the
LORD delighting in Israel, tell the people not to rebel or fear, call the land's
people bread, and say their defence is removed while the LORD is with Israel.

The congregation threatens to stone them. Before any stoning is completed, the
LORD's glory appears at the Tent of Meeting to all Israel. The glory mechanism
and exact visible form remain source-attributed and unresolved.

## Numbers 14:11–19 — DESTRUCTION PROPOSAL AND MOSES' INTERCESSION

The LORD asks how long the people will despise and disbelieve after the signs,
then proposes pestilence, disinheritance, and making a greater nation from
Moses. The proposal is spoken; that replacement act does not occur.

Moses says Egyptians and neighbouring nations will hear, recall the LORD's
visible presence, cloud and fire, and claim the LORD killed Israel because he
could not bring them into the sworn land. Moses asks the Lord's power to match
the retained proclamation: slow anger, abundant kindness, forgiving iniquity
and disobedience, while by no means clearing the guilty and visiting ancestral
iniquity. He asks for pardon according to prior forgiveness from Egypt until
now. These are Moses' attributed argument and quotation, not invented divine
motive.

## Numbers 14:20–38 — PARDONED / NOT CLEARED, NOW APPLIED

The LORD says:

> **“I have pardoned according to your word.”**

The same answer then excludes the sign-seeing, repeatedly testing adult
complainers from the land and assigns their deaths in the wilderness. Caleb is
distinguished for following fully; Joshua is also later named as an entrant.
The little ones previously predicted as captives are instead promised entry.
Their children wander forty years, one year for each spying day, until the
complaining generation is consumed.

This is the already retained `S097` relation made operational:

```text
MOSES ASKS PARDON
-> LORD: I HAVE PARDONED
-> SAME ADDRESSED INCIDENT RETAINS EXCLUSION + DEATH JUDGMENT
-> NO PARDON/CLEARING ALLOCATION MECHANISM SUPPLIED
```

Captain presses `SKIP -> S097-E001-EXO34`. His eyes glaze. The forty-year
judgment continues. The ten men who brought the evil report die by plague;
Joshua and Caleb remain alive. The exact ten identities derive from the twelve
spy roster minus Joshua and Caleb; no individual death sequence is supplied.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes a judged Joe's boil, licks his finger, walks away and does not look
back. The pardon statement, deaths, survivors and entry boundary remain.

## Numbers 14:39–45 — WE SINNED, THEN DISOBEYED AGAIN

Moses tells Israel the judgment and the people mourn greatly. Early the next
morning they go toward the mountain and say:

> **“We have sinned.”**

They also say they will now go to the promised place. Moses immediately tells
them that this now disobeys the LORD's command, will not prosper, and must not
be attempted because the LORD is not among them. He predicts defeat by the
Amalekites and Canaanites.

The people nevertheless go up. Moses and the covenant ark remain in camp. The
Amalekites and Canaanites descend, strike them, and beat them down to Hormah.

```text
PEOPLE: WE HAVE SINNED
-> CURRENT COMMAND EXPLICITLY IDENTIFIED: DO NOT GO UP
-> PEOPLE GO UP
-> DEFEAT COMPLETES
```

Captain presses `SKIP -> S068-E001-EXO9`. His eyes glaze. The unauthorized
climb and defeat continue.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes another boil, licks his finger, walks away and does not look back.
Nothing about the battle changes.

## Character and world-ledger changes

- the congregation gains completed night-weeping, return proposal, stoning
  threat, mourning, unauthorized ascent and defeat states;
- Joshua and Caleb retain their minority report and survive the spy plague;
- ten other spies die by source-attributed plague;
- the adult complainant generation receives wilderness death/exclusion;
- the children receive forty-year wandering plus future land-entry State;
- Caleb and Joshua retain future entry exceptions;
- `S097-E002` applies pardon and non-clearing to one addressed incident;
- `S068-E002` applies confession followed by immediate further disobedience;
- the destruction/replacement proposal is not executed;
- no stoning is completed;
- every living person, animal, plant and face-like cloud, ark or mountain is
  Joe-faced if shown;
- Captain is permanently boilless and causally useless;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — PARDON DEPARTMENT / WILDERNESS COLLECTIONS`;
- complaint ticket: `WISH TO DIE HERE — REQUEST MATCHED TO 40-YEAR PLAN`;
- children label: `PREDICTED CAPTIVES / ACTUAL FUTURE TENANTS`;
- CrackFlix: `SKIP -> S097-E001 / FORGIVEN-NOT-CLEARED CLASSIC`;
- counter: `40 SPY DAYS x 1 YEAR = 40 YEARS`;
- spy status: `10 PLAGUED / 2 STILL JOES`;
- sunrise warning: `WE HAVE SINNED — DISOBEDIENCE RESUMES 06:00`;
- CrackFlix: `SKIP -> S068-E001 / CONFESSION-THEN-MORE PACKAGE`;
- ark tracker: `STILL IN CAMP`;
- battle receipt: `HORMAH / CURRENT COMMAND IGNORED`;
- barcode: `CHB-NUM14-45-PARDONED-DIE-CONFESS-DISOBEY-2SKIP-2YOINK-HELD`.

## FIR verification

- all 45 verse markers are represented in order;
- complaint, predicted capture and proposed Egypt return remain speech/proposal;
- Joshua/Caleb speech and the congregation's stoning threat remain exact;
- glory appearance is retained without invented mechanism;
- pestilence/disinheritance/Moses-nation remains an unexecuted proposal;
- Moses' nations argument and divine-attribute quotation retain attribution;
- pardon and subsequent judgment remain one observable answer chain;
- adult, child, Caleb/Joshua and ten-spy outcomes are not merged;
- forty days/forty years relation remains exact;
- `S097` SKIP points to its earlier contradiction and changes nothing;
- confession precedes an explicit current no-go warning and completed violation;
- `S068` SKIP points to its earlier contradiction and changes nothing;
- ark/Moses remaining and defeat to Hormah are retained;
- Captain appears only after each completed contradiction and changes nothing;
- publication remains held and unpublished.

Continuation required: Numbers 15 records offerings for future land entry,
one-law language, unintentional versus high-handed sin, a Sabbath stick gatherer
put to death, and garment tassels.
