# CRACKHEAD NUMBERS 17

## Title page

**EVERYONE WHO APPROACHES THE TABERNACLE DIES.**

**MOSES JUST WALKED IN, GOT THE RODS, AND CAME BACK.**

Source parent: Numbers chapter 17, verses 1–13, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-017/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/016-EVERYONE-IS-HOLY-SELECT-THE-HOLY-ONE-GOD-KILLED-THEM-YOU-KILLED-THEM.md`.

CrackFlix routing:

- new `S113-E001-NUM17 — EVERY APPROACHER DIES / LIVING APPROACHERS RETURN`

Crack type: mental. The categorical model occurs in Israel's spoken claim.

## Causal foundation

```text
12 FATHERS' HOUSES
-> 12 NAMED PRINCE RODS
-> AARON NAME ON LEVI ROD
-> ALL RODS LAID BEFORE COVENANT

LORD: CHOSEN MAN'S ROD WILL BUD
-> NEXT DAY AARON ROD SPROUTS + BUDS + BLOSSOMS + RIPE ALMONDS
-> MOSES BRINGS ALL RODS OUT
-> ISRAEL LOOKS / EACH MAN TAKES HIS ROD

AARON ROD RETURNED BEFORE COVENANT
-> REBELLION TOKEN / COMPLAINT-END / DEATH-PREVENTION FUNCTION

ISRAEL: EVERYONE WHO KEEPS APPROACHING TABERNACLE DIES
-> SAME CHAPTER: MOSES APPROACHES/ENTERS AND RETURNS ALIVE
-> RETAINED PREVIOUS CHAPTER: AARON APPROACHES/RETURNS ALIVE
-> CATEGORICAL CLAIM EXCEEDS OBSERVED SET
```

## Numbers 17:1–5 — TWELVE-ROD SELECTION PROTOCOL

The LORD tells Moses to collect twelve rods, one for each fathers' house, and
write each prince's name on his rod. Aaron's name goes on Levi's rod. All twelve
are to be laid in the Tent of Meeting before the covenant, where the LORD meets
Moses.

The test has one declared signal:

> **“The rod of the man whom I shall choose shall bud.”**

The LORD assigns the test a further purpose: ending Israel's murmuring against
Moses as murmuring received by the LORD. These are declared future functions;
the rods have not yet changed.

## Numbers 17:6–9 — AARON'S ROD RUNS EVERY PLANT STAGE OVERNIGHT

Moses speaks to Israel. The princes supply twelve rods and Aaron's rod is among
them. Moses places them before the LORD in the Tent of the Testimony.

The next day Moses enters and observes Aaron's Levi rod has:

- sprouted;
- produced buds;
- produced blossoms;
- produced ripe almonds.

The source compresses all four states into the overnight result without giving
a biological, temporal or material mechanism. The rod is a plant-derived living
carrier when it sprouts and therefore has Joe's face if shown. Its almonds are
also Joe-faced living things.

Moses brings every rod out from before the LORD to Israel. The people look, and
each man takes his rod. No result is stated for the other eleven beyond their
return.

## Numbers 17:10–11 — KEEP THE WINNING STICK

The LORD tells Moses to put Aaron's rod back before the covenant as a retained
token against the children of rebellion. Its stated functions are to end their
complaining against the LORD and prevent their deaths. Moses does exactly what
the LORD commands.

The rod's future duration, preservation mechanism, continuing almond State and
later observation history remain unresolved. This chapter only completes its
return and placement.

## Numbers 17:12–13 — EVERYONE DIES, INCLUDING THE LIVING RETURNERS

Israel tells Moses:

> **“We perish! We are undone! We are all undone!”**

Then it states:

> **“Everyone who keeps approaching the LORD's tabernacle dies!”**

The same chapter has just recorded Moses entering the Tent and returning alive
with all twelve rods. The retained immediately preceding chapter also records
Aaron approaching the Tent, performing atonement and returning alive to Moses.
Their roles differ from the dead unauthorized offerers, but Israel's categorical
sentence supplies no role, authorization or lineage qualifier.

```text
CLAIM: EVERY APPROACHER DIES
-> OBSERVED MOSES APPROACHES + RETURNS ALIVE
-> OBSERVED AARON APPROACHES + RETURNS ALIVE
-> NO QUALIFIER IN CLAIM
-> MENTAL CRACK IN ISRAEL'S SPOKEN MODEL
```

That is `S113-E001-NUM17`. It does not decide what Israel privately believes or
predict who will approach next.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes a frightened Joe's forehead boil, licks his finger, walks away and
does not look back. Israel's question—whether all will perish—remains unanswered
inside this chapter.

## Character and world-ledger changes

- twelve fathers' houses/princes supply twelve named rods;
- Aaron remains the name written on Levi's single rod;
- Aaron's rod completes sprout, bud, blossom and ripe-almond states overnight;
- eleven other rods are observed and returned without stated change detail;
- Aaron's rod is returned before the covenant as a retained memorial;
- the rod's declared complaint-ending/death-prevention function is prospective;
- `S113` locates a categorical approach/death claim in Israel's spoken model;
- Israel's all-perish question remains unresolved;
- every living human, plant, almond and face-like rod, Tent or covenant carrier
  is Joe-faced if shown;
- Captain is permanently boilless and causally useless;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — TRIBAL STICK BENCHMARK / OVERNIGHT BUILD`;
- input rack: `12 HOUSES / 12 RODS / WRITE YOUR ADMIN NAME HERE`;
- Levi label: `AARON.EXE`;
- result card: `SPROUT + BUD + BLOSSOM + RIPE ALMONDS / ONE NIGHT`;
- produce warning: `DO NOT EAT THE AUTHORITY TOKEN`;
- memorial slot: `PUT THE WINNING STICK BACK`;
- fear dashboard: `EVERY APPROACHER DIES / LIVING APPROACHERS NOT DISPLAYED`;
- CrackFlix: `S113 E001 — CATEGORICAL DEATH FILTER`;
- barcode: `CHB-NUM17-13-12RODS-1ALMOND-MENTAL-YOINK-HELD`.

## FIR verification

- all 13 verse markers are represented in order;
- twelve rods, fathers' houses and named-prince relation remain exact;
- Aaron/Levi's one-rod relation is not inflated to thirteen rods;
- rod placement, overnight observation and return occur in order;
- sprout, bud, blossom and ripe-almond states all remain;
- no mechanism or other-rod result is invented;
- Aaron's rod is returned and kept as commanded;
- declared memorial functions remain prospective rather than verified forever;
- Israel's fear statements remain direct speech;
- categorical everyone-approaches/dies claim is compared only with retained
  living approach/return occurrences;
- no private belief, unauthorized qualifier or future death is invented;
- Captain appears only after the claim closes and changes nothing;
- publication remains held and unpublished.

Continuation required: Numbers 18 assigns priest/Levite sanctuary liability,
service boundaries, offerings and tithes, including Levite tithe-of-tithe.
