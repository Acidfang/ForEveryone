# CRACKHEAD NUMBERS 23

## Title page

**HIRED TO CURSE.**

**BLESSED TWICE.**

**DON'T CURSE THEM. TRY CURSING THEM AGAIN.**

Source parent: Numbers chapter 23, verses 1–30, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-023/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/022-GO-WITH-THEM-ANGRY-BECAUSE-YOU-WENT-THE-DONKEY-SAVED-YOU.md`.

CrackFlix routing:

- new `S118-E001-NUM23 — BROUGHT TO CURSE / BLESSED ALTOGETHER`;
- recurrence `S118-E002-NUM23 — CHANGE VIEW / REQUEST CURSE / COMMAND TO BLESS`;
- `S118-E002` may display `SKIP -> S118-E001`; SKIP changes nothing;
- new `S119-E001-NUM23 — NEITHER CURSE NOR BLESS / TRY CURSING FROM THERE`.

## Causal foundation

```text
ATTEMPT ONE
-> 7 ALTARS + 7 BULLS + 7 RAMS
-> GOD MEETS BALAAM / PUTS WORD IN MOUTH
-> BALAK'S REQUEST: CURSE ISRAEL
-> ORACLE: GOD HAS NOT CURSED / ISRAEL BLESSED
-> BALAK: I TOOK YOU TO CURSE; YOU BLESSED ALTOGETHER

ATTEMPT TWO
-> NEW VIEW + SAME 7-ALTAR / 14-ANIMAL LOAD
-> LORD MEETS BALAAM / PUTS WORD IN MOUTH
-> ORACLE: COMMAND TO BLESS / CANNOT REVERSE
-> BALAK: NEITHER CURSE NOR BLESS

ATTEMPT THREE SETUP
-> BALAK: MAYBE GOD WILL LET YOU CURSE FROM ANOTHER PLACE
-> PEOR + 7 ALTARS + 7 BULLS + 7 RAMS
-> NO THIRD ORACLE YET
```

## Numbers 23:1–6 — FIRST FOURTEEN ANIMALS

Balaam orders seven altars, seven bulls and seven rams. Balak complies. Balak
and Balaam offer one bull and one ram on each altar. Balaam leaves Balak and
the Moabite princes standing by the offerings and goes to a bare height.

God meets Balaam. Balaam reports the seven altars and fourteen offerings. The
LORD puts a word in Balaam's mouth and orders him back to speak it. Balaam
returns; the offerings, Balak and the princes remain in place.

## Numbers 23:7–12 — CURSE ORDER IN, BLESSING OUT

Balaam's first oracle explicitly recalls Balak bringing him from Aram to curse
Jacob and defy Israel. Balaam asks how he can curse or defy those God/LORD has
not cursed or defied, describes Israel as numerous and separate, and asks for a
righteous death and matching end.

Balak states the observable mismatch himself:

> I took you to curse my enemies, and behold, you have blessed them altogether.

That closes `S118-E001-NUM23`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes Balak's boil, licks his finger, walks away and does not look back.
Balaam answers that he must speak what the LORD puts in his mouth.

## Numbers 23:13–17 — CHANGE THE VIEW, REBUILD THE SAME INPUT

Balak takes Balaam to Zophim at Pisgah, where Balaam sees only part of Israel,
and again asks him to curse from there. Seven more altars are built and another
seven bulls and seven rams are offered, one pair per altar.

The repeated request, altar count and offering count address the already-held
series. Captain presses his private CrackFlix:

> **SKIP -> S118-E001-NUM23**

His eyes glaze. Nothing skips. Balak stands by the offering, the LORD meets
Balaam, puts a word in his mouth and sends him back. Balak asks what the LORD
has spoken.

## Numbers 23:18–24 — SECOND BLESSING CANNOT BE REVERSED

The second oracle says God is not a man who lies or repents, says God's spoken
word will be performed, and states:

> I have received a command to bless. He has blessed, and I can't reverse it.

The oracle continues with LORD-with-Israel, Egypt delivery, no
enchantment/divination, wild-ox strength and lion/lioness victory imagery.
These are oracle claims and images; no new battle or blood-drinking occurrence
is instantiated here.

The same commissioned curse again produces a commanded blessing. That closes
`S118-E002-NUM23`; the changed viewpoint does not change the result.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the second-site boil, licks his finger, walks away and does not look
back. SKIP did nothing.

## Numbers 23:25–27 — DON'T CURSE. TRY CURSING AGAIN.

After the second blessing, Balak tells Balaam:

> Neither curse them at all, nor bless them at all.

Balaam repeats that he must do all the LORD speaks. Balak then immediately
offers another place because perhaps it will please God for Balaam to **curse
them from there**.

```text
BALAK: DO NOT CURSE THEM AT ALL
-> BALAK: GO TO ANOTHER PLACE AND MAYBE CURSE THEM FOR ME
```

That closes `S119-E001-NUM23`. No interpretation of Balak's private intention is
needed; both instructions are observable speech.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes Balak's instruction-reversal boil, licks his finger, walks away and
does not look back.

## Numbers 23:28–30 — THIRD LOAD, OUTCOME PENDING

Balak takes Balaam to the top of Peor overlooking the desert. Balaam orders
seven altars, seven bulls and seven rams. Balak builds and offers one bull and
one ram on every altar.

The third physical setup completes, bringing the chapter total to twenty-one
altars, twenty-one bulls and twenty-one rams. The third oracle does not occur
until Numbers 24 and is not imported here.

## Character and world-ledger changes

- two complete seven-altar/fourteen-animal attempts occur at distinct sites;
- LORD/God meets Balaam twice and puts a word in his mouth twice;
- Balak's first two curse requests receive two blessing oracles;
- S118 contains two distinct episodes with exact shared structure;
- SKIP in episode two points to episode one and changes nothing;
- Balak's no-curse/no-bless instruction is followed by another curse request;
- S119 closes on those two observable Balak instructions;
- a third seven-altar/fourteen-animal setup completes without its oracle;
- chapter totals are twenty-one altars, bulls and rams;
- Captain's three post-closure appearances are causally null;
- every living human, bull, ram, lion, lioness, ox and face-like altar, mouth,
  rock, hill, field, desert or offering is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — CURSE-AS-A-SERVICE`;
- invoice one: `7 ALTARS / 14 ANIMALS / RESULT: BLESSING`;
- relocation patch: `SHOW LESS ISRAEL`;
- CrackFlix card: `SKIP -> S118-E001 / WORLD CONTINUES`;
- invoice two: `7 ALTARS / 14 ANIMALS / RESULT: BLESSING AGAIN`;
- word lock: `HE BLESSED / REVERSAL DISABLED`;
- Balak control panel: `CURSE OFF / CURSE ON`;
- attempt three: `21ST ALTAR READY / OUTPUT NEXT CHAPTER`;
- barcode: `CHB-NUM23-30-CURSE-BLESS2-SKIP-NOCURSE-CURSE-HELD`.

## FIR verification

- all 30 verse markers are represented in order;
- every altar, bull and ram count remains attached to its occurrence;
- meeting/word/return/oracle chains remain ordered twice;
- Balak's commission and Balaam's blessing output close S118-E001;
- second site/view and second blessing remain a separate S118 episode;
- SKIP points exactly to S118-E001 and causes no state change;
- oracle claims and imagery are not silently converted into completed events;
- S119 retains Balak's exact no-curse instruction and later curse request;
- no Balak motive or inner state beyond stated fear is invented;
- third setup closes without importing Numbers 24's oracle;
- three Captain appearances follow completed contradictions and change nothing;
- publication remains held and unpublished.

Continuation required: Numbers 24 completes the third oracle, adds Balaam's
later visions and ends the Balak–Balaam encounter.
