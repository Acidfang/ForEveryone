# CRACKHEAD NUMBERS 21

## Title page

**SNAKES BITE.**

**LOOK AT THE BRONZE SNAKE. LIVE.**

Source parent: Numbers chapter 21, verses 1–35, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-021/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/020-SPEAK-TO-THE-ROCK-HIT-IT-TWICE-WATER-STILL-COMES-YOU-CANT-GO-IN.md`.

CrackFlix routing: none. No completed observable contradiction is derived.

## Causal foundation

```text
ARAD ATTACKS + TAKES CAPTIVES
-> ISRAEL VOWS CITY DESTRUCTION IF DELIVERED
-> LORD DELIVERS CANAANITES
-> ISRAEL DESTROYS PEOPLE + CITIES
-> PLACE NAMED HORMAH

EDOM DETOUR + DISCOURAGED PEOPLE
-> PEOPLE SPEAK AGAINST GOD/MOSES
-> LORD SENDS VENOMOUS SNAKES
-> BITES + MANY DEATHS
-> PEOPLE ADMIT SIN / REQUEST REMOVAL PRAYER
-> MOSES PRAYS
-> LORD ORDERS VENOMOUS IMAGE ON POLE
-> MOSES MAKES BRONZE SERPENT
-> BITTEN PERSON LOOKS
-> PERSON LIVES

TRAVEL + WELL + SONG
-> SIHON REFUSES PASSAGE + ATTACKS
-> ISRAEL DEFEATS SIHON / POSSESSES LAND
-> JAZER TAKEN
-> OG ATTACKS
-> LORD DECLARES DELIVERY / ORDERS SAME DISPOSITION AS SIHON
-> OG / SONS / PEOPLE STRUCK WITH NO SURVIVORS
-> ISRAEL POSSESSES LAND
```

## Numbers 21:1–3 — CAPTIVES, VOW, HORMAH

The Canaanite king of Arad hears that Israel is coming by Atharim, fights
Israel and takes some Israelites captive. Israel vows to the LORD that, if the
people are delivered into Israel's hand, Israel will utterly destroy their
cities.

The LORD listens and delivers the Canaanites. Israel destroys them and their
cities, then calls the place Hormah. The source footnote supplies the meaning
“destruction.” It supplies no captive count, rescue roster, battle geometry or
survivor disposition beyond the stated destruction.

## Numbers 21:4–7 — COMPLAINT, SNAKES, DEATHS, ADMISSION

Israel travels from Mount Hor toward the Red Sea to go around Edom. The people
become discouraged because of the journey and speak against God and Moses.
They ask why they were brought from Egypt to die, say there is no bread or
water, and say they loathe “this disgusting food.”

Those are retained source statements. “No bread” and “this food” are not merged
into one category that the source does not explicitly equate.

The LORD sends venomous snakes. They bite the people and many Israelites die.
The people tell Moses they sinned by speaking against the LORD and Moses, ask
him to pray for removal of the serpents, and Moses prays. The source does not
say every snake is removed after the prayer.

## Numbers 21:8–9 — LOOK AT THE BRONZE SERPENT

The LORD tells Moses to make a venomous snake and set it on a pole. Everyone
who is bitten and sees it shall live. Moses makes a bronze serpent and places
it on the pole. When a serpent-bitten person looks at the bronze serpent, that
person lives.

```text
VENOMOUS SNAKE BITE
-> LOOK AT BRONZE SERPENT ON POLE
-> BITTEN PERSON LIVES
```

This is an explicitly instructed and completed relation, not a contradiction.
The source supplies neither the physical healing mechanism nor the number of
people who looked, lived, declined to look or were never bitten.

## Numbers 21:10–20 — CAMPS, BOOK, WELL, SONG

Israel moves through Oboth, Iyeabarim, the Zered valley and the far side of the
Arnon at the Moab–Amorite border. The chapter quotes the *Book of the Wars of
the LORD* concerning Vaheb, Suphah and the Arnon valleys. The quoted book's
full contents, author, date and carrier are not supplied.

At Beer the LORD tells Moses to gather the people and promises water. Israel
sings to the well. The song attributes its digging to princes and nobles using
scepter and poles. The chapter does not separately narrate the digging act or
state the water-delivery quantity. Israel then travels through Mattanah,
Nahaliel and Bamoth to the Moab valley near Pisgah.

## Numbers 21:21–26 — SIHON REFUSES, ATTACKS, LOSES LAND

Israel asks Sihon, Amorite king, for passage on the king's highway while
promising no field, vineyard or well-water use. Sihon refuses, assembles all
his people, comes into the wilderness and fights Israel at Jahaz.

Israel strikes him with the sword and possesses his land from the Arnon to the
fortified Ammon border. Israel takes and inhabits Heshbon and the Amorite
cities. The source says Sihon previously took that territory from Moab's former
king. Israel's passage promise was conditional speech in a rejected request;
the source does not narrate Israel violating it before Sihon's attack.

## Numbers 21:27–32 — THE PROVERB AND JAZER

The chapter quotes proverb speakers celebrating Sihon's Heshbon and recounting
its prior destruction of Moabite territory and captives. The poem's “we” is
retained as quoted speech without silently assigning every line to the current
Israelite generation.

Israel lives in Amorite territory. Moses sends people to spy out Jazer; they
take its villages and drive out the Amorites there. The spy roster, siege
sequence and expelled population's destination are unresolved.

## Numbers 21:33–35 — OG COMES OUT; NONE SURVIVE

Israel turns toward Bashan. Og, his sons and all his people come out to battle
at Edrei. The LORD tells Moses not to fear, declares Og, his people and land
delivered into Moses' hand, and orders the same treatment given to Sihon.

Israel strikes Og, his sons and all his people until no survivor remains, then
possesses the land. The declaration precedes the completed battle outcome; the
chapter records no contradictory result. Individual fighter counts, weapon
distribution and land-allocation detail remain unresolved.

## Character and world-ledger changes

- Arad attacks, takes captives, is delivered and destroyed with its cities;
- Hormah receives its destruction name in this occurrence;
- venomous snakes bite Israel and many die;
- Israel admits its speech as sin and Moses prays;
- the bronze-serpent look/life relation completes without a supplied mechanism;
- the Edom bypass and camp route continue;
- the *Book of the Wars of the LORD* is source-quoted but not reconstructed;
- Beer instruction and well song are retained without invented water quantity;
- Sihon refuses passage, attacks, is defeated and loses land/cities;
- Jazer's villages are taken and resident Amorites driven out;
- Og attacks, is defeated with sons and people, and leaves no survivors;
- no valid contradiction closes, so Captain, crack, YOINK and SKIP do not occur;
- every living human, snake, livestock, plant and face-like pole, well, city,
  sword, book, border or mountain is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — VENOM DISPLAY DRIVER`;
- snake alert: `MANY BITES / COUNT NOT INCLUDED`;
- pole label: `LOOK HERE TO CONTINUE LIVING`;
- healing panel: `MECHANISM: NOT IN THIS CHAPTER`;
- travel HUD: `EDOM AVOIDANCE ROUTE STILL RUNNING`;
- archive citation: `BOOK OF THE WARS OF THE LORD / FILE NOT ATTACHED`;
- Beer chorus card: `SPRING UP, WELL!`;
- passage request: `HIGHWAY ONLY / REQUEST DENIED / ATTACK STARTED`;
- Sihon map layer: `PREVIOUSLY MOAB / NOW ISRAEL`;
- Og status: `NO SURVIVORS`;
- barcode: `CHB-NUM21-35-ARAD-SNAKES-BRONZE-WELL-SIHON-OG-HELD`.

## FIR verification

- all 35 verse markers are represented in order;
- Arad attack, captivity, conditional vow, delivery and destruction remain ordered;
- the complaint is retained without equating “bread” and “food” beyond source;
- snake sending, bites, deaths, admission and prayer remain completed acts;
- snake removal is not invented;
- bronze-serpent construction, looking and living remain an instructed relation;
- no healing mechanism or participant count is invented;
- every campsite and border relation remains in source order;
- external book and proverb quotations retain their quoted-source boundary;
- Beer water quantity and separate digging occurrence are not invented;
- Sihon's refusal and attack precede Israel's conquest;
- Og's attack, LORD declaration, defeat and possession remain ordered;
- no unsupported contradiction, Captain appearance, YOINK or SKIP is added;
- publication remains held and unpublished.

Continuation required: Numbers 22 records Balak's summons, Balaam's replies,
the road confrontation and the speaking donkey.
