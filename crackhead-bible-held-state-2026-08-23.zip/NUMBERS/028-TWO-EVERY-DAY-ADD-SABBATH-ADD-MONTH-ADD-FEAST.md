# CRACKHEAD NUMBERS 28

## Title page

**TWO EVERY DAY.**

**ADD SABBATH.**

**ADD MONTH.**

**ADD FEAST.**

Source parent: Numbers chapter 28, verses 1–31, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-028/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/027-NO-SON-DAUGHTERS-INHERIT-MOSES-WILL-DIE-JOSHUA-COMMISSIONED.md`.

CrackFlix routing: none. No completed observable contradiction is derived.

## Causal foundation

```text
LORD ORDERS OFFERINGS AT THEIR DUE TIMES
-> DAILY BASE: MORNING LAMB + EVENING LAMB
-> SABBATH: DAILY BASE + SABBATH ADDITION
-> MONTH START: DAILY BASE + MONTHLY ADDITION
-> PASSOVER FEAST DAYS: DAILY BASE + DAILY FEAST ADDITION
-> FIRSTFRUITS/WEEKS: DAILY BASE + FESTIVAL ADDITION

SCHEDULE STATED
!= OFFERINGS OBSERVED PERFORMED
```

## Numbers 28:1–2 — DUE-SEASON COMMAND

The LORD tells Moses to command Israel to present the LORD's offering, food for
offerings made by fire and a pleasant aroma, in its due season. This chapter
defines the required schedule. It does not narrate a dated performance of the
schedule.

## Numbers 28:3–8 — THE CONTINUAL DAILY BASE

Every day requires two one-year-old male lambs without defect: one in the
morning and the other in the evening.

Each lamb is paired with:

- one tenth of an ephah of fine flour as a meal offering;
- one fourth of a hin of beaten oil mixed with that flour;
- one fourth of a hin of strong drink poured in the holy place.

The source identifies this as the continual burnt offering ordained at Mount
Sinai. The evening offering repeats the morning meal-and-drink relation. The
schedule therefore retains two separate daily occurrences rather than one lamb
being described twice.

## Numbers 28:9–10 — SABBATH ADDS; IT DOES NOT REPLACE

Every Sabbath adds two one-year-old male lambs without defect, two tenths of an
ephah of fine flour mixed with oil, and the associated drink offering. This is
explicitly **in addition to** the continual burnt offering and its drink
offering.

No Sabbath offering is performed in the chapter merely because its recurring
rule is stated.

## Numbers 28:11–15 — BEGINNING OF EVERY MONTH

At the beginning of each month, the burnt-offering addition is:

- two young bulls;
- one ram;
- seven one-year-old male lambs without defect.

The meal ratios are three tenths of an ephah of fine flour mixed with oil for
each bull, two tenths for the ram and one tenth for each lamb. The drink ratios
are half a hin of wine per bull, one third per ram and one fourth per lamb.

One male goat is added as a sin offering. The entire monthly set is additional
to the continual burnt offering and its drink offering. The chapter supplies
the recurring recipe, not a specific observed new-moon execution.

## Numbers 28:16–25 — PASSOVER AND SEVEN FEAST DAYS

The LORD's Passover is on day fourteen of the first month. The feast begins on
day fifteen; unleavened bread is eaten for seven days. Day one and day seven
are holy convocations with no regular work.

For each of the seven feast days, the scheduled addition is:

- two young bulls without defect;
- one ram without defect;
- seven one-year-old male lambs without defect;
- meal offering of three tenths per bull, two tenths for the ram and one tenth
  for each lamb;
- one male goat as a sin offering to make atonement.

These are offered in addition to the morning continual offering, and the same
feast food-by-fire schedule repeats daily for seven days in addition to the
continual burnt offering and drink offering. The calendar command does not
prove that a particular Passover week has occurred here.

## Numbers 28:26–31 — FIRSTFRUITS / FEAST OF WEEKS

On the day of firstfruits, when Israel offers a new meal offering at the feast
of weeks, there is a holy convocation and no regular work.

The scheduled burnt-offering addition is two young bulls, one ram and seven
one-year-old male lambs. Its meal ratios are again three tenths per bull, two
tenths for the ram and one tenth per lamb. One male goat makes atonement. The
animals must be without defect, their drink offerings remain required, and the
whole set is additional to the continual burnt and meal offering.

The new meal offering named in the occasion and the meal offerings paired with
the animals remain separately addressed; the source does not collapse them
into one quantity.

## Character and world-ledger changes

- Moses receives and carries the due-season offering command;
- the continual morning/evening base remains inherited from Sinai;
- Sabbath, monthly, Passover-week and firstfruits additions remain distinct;
- every explicit animal count and flour/oil/wine ratio is retained;
- `in addition to` prevents any festival set from replacing the daily base;
- first and seventh Passover feast days and firstfruits day prohibit regular work;
- no dated offering performance, animal death, fire, aroma or atonement outcome
  is invented from the prospective schedule;
- no unsupported contradiction, Captain, crack, YOINK or SKIP occurs;
- every living human, bull, ram, lamb, goat, plant and face-like calendar,
  fraction, ephah, hin, cup, altar, fire or schedule card is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — RECURRING OFFERING STACK`;
- daily daemon: `AM LAMB + PM LAMB / NEVER OFF`;
- Sabbath patch: `+2 LAMBS / BASE STILL RUNNING`;
- new-month bundle: `2 BULL + 1 RAM + 7 LAMB + 1 GOAT`;
- flour router: `BULL .3 / RAM .2 / LAMB .1 EPHAH`;
- drink router: `BULL .5 / RAM .333 / LAMB .25 HIN`;
- Passover loop: `DAY 1..7 / SAME ADDITION / BASE STILL RUNNING`;
- firstfruits package: `NEW MEAL + FESTIVAL SET + BASE`;
- fake warning: `SCHEDULE FILE IS NOT EXECUTION EVIDENCE`;
- barcode: `CHB-NUM28-31-DAILY-PLUS-SABBATH-MONTH-FEAST-HELD`.

## FIR verification

- all 31 verse markers are represented in order;
- daily morning and evening lambs remain two distinct scheduled offerings;
- every daily flour, oil and drink fraction is retained;
- Sabbath addition remains on top of the daily base;
- monthly animal counts and per-animal meal/drink ratios are exact;
- monthly sin goat remains additional to the continual offering;
- Passover day fourteen and feast day fifteen are not merged;
- seven feast days, unleavened bread and day-one/day-seven work boundaries remain;
- the Passover offering set repeats daily for seven days without being marked performed;
- firstfruits new meal offering is not merged with animal meal accompaniments;
- all festival sets remain additions rather than replacements;
- no commanded schedule is misreported as an observed sacrifice or atonement;
- no Captain or CrackFlix event is added without a completed contradiction;
- publication remains held and unpublished.

Continuation required: Numbers 29 continues the seventh-month trumpet,
atonement and booths offering schedules with changing daily bull counts.
