# CRACKHEAD NUMBERS 10

## Title page

**TWO SILVER TRUMPETS. DIFFERENT NOISE, DIFFERENT JOES MOVE.**

**SANCTUARY IN THE MIDDLE. ARK THREE DAYS OUT FRONT.**

Source parent: Numbers chapter 10, verses 1–36, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-010/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/009-DEAD-BODY-NEXT-MONTH-CLOUD-UP-MOVE-CLOUD-DOWN-STAY.md`.

CrackFlix routing:

- returning `S101-E003-NUM10 — DEUEL IS STILL BACK` with
  `SKIP -> S101-E002-NUM07`;
- new `S106-E001-NUM10 — SANCTUARY IN THE MIDDLE. ARK THREE DAYS AHEAD.`

## Causal foundation

```text
TWO BEATEN-SILVER TRUMPETS
-> BOTH BLOW: WHOLE CONGREGATION
-> ONE BLOWS: PRINCES
-> ALARM 1: EAST CAMPS MOVE
-> ALARM 2: SOUTH CAMPS MOVE
-> PLAIN BLOW: ASSEMBLE / NOT ALARM
-> PRIESTS OPERATE

CLOUD LIFTS / SECOND YEAR / MONTH 2 / DAY 20
-> ISRAEL LEAVES SINAI FOR PARAN
-> JUDAH GROUP
-> GERSHON + MERARI WITH DISMANTLED TABERNACLE
-> REUBEN GROUP
-> KOHATH WITH SANCTUARY
-> EPHRAIM GROUP
-> DAN REAR GUARD

NUMBERS 4 + NUMBERS 10:21
-> ARK IS KOHATHITE SANCTUARY LOAD IN MIDDLE

NUMBERS 10:33
-> SAME COVENANT ARK GOES BEFORE THEM THREE DAYS
-> NO SECOND ARK / REMOVAL / REINSERTION ACT
```

## Numbers 10:1–10 — THE SILVER TRUMPET SIGNAL TABLE

The LORD tells Moses to make two beaten-silver trumpets for congregation calls
and camp journeys. The signal grammar is prospective:

| Signal | Required response |
|---|---|
| both trumpets blown | whole congregation gathers at Tent door |
| one trumpet blown | princes/heads of Israel's thousands gather |
| first alarm | east-side camps depart |
| second alarm | south-side camps depart |
| ordinary blow without alarm | assembly gathers without journey alarm |

Aaron's priestly sons alone operate the trumpets as a continuing statute. In
future land warfare an alarm is to accompany Israel's appeal to be remembered
and saved from an oppressor. Trumpets also sound over burnt and peace offerings
on glad days, appointed feasts and new months as a memorial before God.

The chapter does not narrate the manufacture or a trumpet blast. Its later
departure likewise does not state that no trumpet sounded; silence is not an
observed breach and produces no crack.

## Numbers 10:11–13 — THE CLOUD LIFTS; SINAI ENDS

On the twentieth day of the second month of the second year, the cloud lifts
from the covenant Tabernacle. Israel begins the first narrated journey from
Sinai under the established cloud-command relation and the cloud settles in
the wilderness of Paran. The departure and arrival are completed.

## Numbers 10:14–28 — THE COMPLETED MARCH ORDER

Israel moves in the following retained order:

1. Judah standard: Nahshon/Judah, Nethanel/Issachar, Eliab/Zebulun.
2. Gershon and Merari after dismantling the Tabernacle, so they can erect it
   before the sanctuary load arrives.
3. Reuben standard: Elizur/Reuben, Shelumiel/Simeon, Eliasaph/Gad.
4. Kohathites carrying the sanctuary.
5. Ephraim standard: Elishama/Ephraim, Gamaliel/Manasseh, Abidan/Benjamin.
6. Dan rear guard: Ahiezer/Dan, Pagiel/Asher, Ahira/Naphtali.

This is not a proposed parade diagram; the groups actually go forward.

### Eliasaph's father field repeats Deuel

The same Gad prince is again named Eliasaph son of Deuel, retaining the
Deuel/Reuel/Deuel conflict from Numbers 1, 2 and 7.

`SKIP -> S101-E002-NUM07 — DEUEL CAME BACK.`

Captain's eyes glaze. The Reuben group, Kohathites, Ephraim group and Dan rear
guard keep moving. After the repeated identity occurrence closes:

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the boil, licks his finger, walks away and does not look back.

## Numbers 10:29–32 — HOBAB SAYS NO; MOSES ASKS AGAIN

Moses addresses Hobab with the source identification, “son of Reuel the
Midianite, Moses' father-in-law.” The grammar does not independently resolve
whether the final relation points to Hobab or Reuel, so no extra family identity
is imposed.

Moses invites Hobab to the promised place and promises to share the good the
LORD does for Israel. Hobab refuses and says he will return to his land and
relatives. Moses asks again: Hobab knows wilderness camping, can be Israel's
eyes, and will share the good. The chapter supplies no answer to this second
appeal and does not show whether Hobab goes.

The human “eyes” request coexists with the cloud controller and ark resting-place
claim; the source does not state that these functions are mutually exclusive.

## Numbers 10:33–34 — THE MIDDLE ARK GOES THREE DAYS AHEAD

Israel travels three days from the Mount of the LORD. The covenant ark goes
before them for the three-day journey to seek a resting place, while the cloud
remains over them by day.

Earlier in this same completed march, the Kohathites carrying the sanctuary
were explicitly fourth in a six-part sequence. Numbers 4 assigned the ark to
that Kohathite sanctuary load. No second ark, separate ark carrier, removal from
Kohath's load, pass through the forward groups or later reinsertion is supplied.

```text
ARK -> KOHATH SANCTUARY LOAD -> MIDDLE OF MARCH
ARK -> BEFORE THEM -> THREE DAYS AHEAD
```

That same-object/same-journey positional mismatch is `S106-E001-NUM10`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the ark-shaped boil's Joe face, licks his finger, walks away and does
not look back. The ark remains both in the retained middle order and ahead.

## Numbers 10:35–36 — RISE AND RETURN

Whenever the ark moves, Moses says:

> **“Rise up, LORD, and let your enemies be scattered! Let those who hate you
> flee before you!”**

Whenever it rests, he says:

> **“Return, LORD, to the ten thousands of the thousands of Israel.”**

These are repeated source-attributed Moses speeches. The chapter does not
narrate a particular enemy scattering or identify a hater fleeing here.

## Character and world-ledger changes

- two-trumpet signal grammar is established but no blast is observed;
- cloud lifts on the exact second-year/second-month/day-twenty date;
- Israel completes Sinai-to-Paran departure and ordered march;
- Tabernacle teardown, Gershon/Merari forward transport and Kohath sanctuary
  transport are completed;
- `S101-E003` repeats the Eliasaph/Deuel state with exact SKIP pointer;
- Hobab refuses once, receives a second appeal, and has no retained final answer;
- `S106` retains the same ark in middle sanctuary load and three days ahead;
- Moses gains repeated ark-move and ark-rest speeches;
- all living humans and animals are Joe-faced; trumpets, cloud and ark may have
  Joe faces when rendered as face-like actors/objects;
- Captain remains permanently boilless and causally useless;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — SILVER AIR-HORN CAMP ROUTER`;
- trumpet UI: `BOTH = EVERYONE / ONE = MANAGEMENT`;
- alarm UI: `BEEP 1 EAST / BEEP 2 SOUTH / NORMAL BEEP MEETING`;
- departure timestamp: `Y2 M2 D20 — SINAI LEASE ENDED`;
- order card: `JUDAH / TENT TRUCKS / REUBEN / HOLY LOAD / EPHRAIM / DAN`;
- Gad label: `ELIASAPH — DEUEL STILL BACK`;
- SKIP pointer: `S101-E002`;
- Hobab application: `WILDERNESS EYES / RESPONSE PENDING`;
- ark tracker: `MIDDLE` and `3 DAYS AHEAD` simultaneously;
- CrackFlix: `S106 E001 — HOLY GPS DUPLICATE POSITION`;
- barcode: `CHB-NUM10-36-2TRUMPETS-DEUEL-MIDDLE-AHEAD-HELD`.

## FIR verification

- all 36 verse markers are represented in order;
- every trumpet signal, operator and occasion remains distinct;
- absent trumpet narration is not converted into an observed rule breach;
- date, cloud lift, Sinai departure and Paran settlement are completed;
- all six march-order grains and named leaders are retained;
- `S101-E003` uses the retained father-field path and points to `S101-E002`;
- Hobab's refusal and unanswered second appeal remain separate;
- no decision, motive or family-identity bridge is invented for Hobab;
- `S106` joins the ark's Numbers 4 carrier identity to both positions;
- Moses' ark speeches receive no invented outcomes;
- Captain appears only after addressed contradictions close;
- every living thing uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Numbers 11 records complaint fire, craving, seventy
elders, Eldad/Medad prophecy, quail accumulation and the plague/graves outcome.
