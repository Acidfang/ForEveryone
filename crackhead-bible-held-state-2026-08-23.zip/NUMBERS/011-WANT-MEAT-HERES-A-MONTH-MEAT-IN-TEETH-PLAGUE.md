# CRACKHEAD NUMBERS 11

## Title page

**WANT MEAT? HERE'S ENOUGH FOR A MONTH.**

**MEAT STILL BETWEEN YOUR TEETH? PLAGUE.**

Source parent: Numbers chapter 11, verses 1–35, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-011/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/010-TWO-TRUMPETS-DEUEL-AGAIN-SANCTUARY-MIDDLE-ARK-THREE-DAYS-AHEAD.md`.

CrackFlix routing:

- new `S107-E001-NUM11 — ASK FOR MEAT. RECEIVE MEAT. PLAGUE.`;
- new `S108-E001-NUM11 — EAT FOR A MONTH. BURIED BEFORE THE FIRST BITE.`

## Causal foundation

```text
PEOPLE COMPLAIN
-> LORD HEARS / FIRE BURNS CAMP OUTSKIRTS
-> PEOPLE CRY TO MOSES
-> MOSES PRAYS
-> FIRE ABATES

MIXED MULTITUDE LUSTS + ISRAEL WEEPS FOR MEAT
-> MOSES SAYS BURDEN TOO HEAVY / ASKS TO DIE
-> LORD ADDS 70 ELDERS AT TENT
-> SPIRIT ON THEM + ELDAD/MEDAD IN CAMP

LORD: I WILL GIVE YOU MEAT
-> NOT 1/2/5/10/20 DAYS
-> WHOLE MONTH
-> WIND BRINGS QUAIL
-> PEOPLE GATHER AT LEAST 10 HOMERS EACH
-> MEAT IN TEETH / NOT YET CHEWED
-> LORD PLAGUES PEOPLE
-> PEOPLE WHO LUSTED BURIED
```

## Numbers 11:1–3 — COMPLAINT, FIRE, PRAYER, STOP

The people complain within the LORD's hearing. The LORD's anger burns and fire
burns among them, consuming some of the camp outskirts. The people cry to Moses;
Moses prays; the fire abates. The place is named Taberah because the LORD's fire
burned there. No complainant words, consumed people or death count are supplied.

## Numbers 11:4–9 — “NOTHING EXCEPT THIS MANNA”

The mixed multitude lusts intensely and Israel weeps again for meat. They name
Egyptian fish, cucumbers, melons, leeks, onions and garlic and say they ate the
fish for nothing. They say their appetite is gone and there is nothing to look
at except manna.

The narrator retains manna's actual properties: coriander-seed form, bdellium
appearance, night-dew arrival, gathering, milling or mortar beating, boiling,
cake making and fresh-oil taste. Wanting meat and possessing manna are different
food states; the source does not say the people literally possess no food.

## Numbers 11:10–15 — MOSES SAYS THE LOAD IS TOO HEAVY

Moses hears every family weeping at tent doors. The LORD is greatly angry and
Moses is displeased. Moses asks why the LORD has treated him badly and loaded
the whole people onto him. He asks whether he conceived or bore them, where he
could obtain their meat, and says he cannot bear them alone. He asks the LORD to
kill him immediately rather than let him see his wretchedness.

These are retained Moses questions and requests, not narrator conclusions that
he conceived Israel or an observed death attempt.

## Numbers 11:16–17 — ADD SEVENTY LOAD-BEARERS

The LORD orders Moses to select seventy known elders/officers and stand them at
the Tent. The LORD says he will come down, speak, take from the Spirit on Moses,
put it on them, and make them share the people's burden so Moses does not bear
it alone. This directly addresses the stated workload relation.

## Numbers 11:18–23 — THE WHOLE-MONTH MEAT PROMISE

The LORD tells Israel to prepare for meat. Their weeping and claim that Egypt
was better are the stated reason the LORD will give it. The duration is explicit:

> **“You will not eat just one day, or two days, or five days, or ten days, or
> twenty days, but a whole month.”**

The promised endpoint is meat becoming loathsome and coming out at their
nostrils. Moses observes six hundred thousand footmen and asks whether all the
flocks, herds or sea fish could suffice. The LORD answers, **“Has the LORD's
hand grown short?”** and tells Moses he will observe whether the word happens.

Moses' feasibility questions do not deny a completed supply; the supply has
not happened yet at this state.

## Numbers 11:24–30 — SEVENTY AT THE TENT, TWO IN THE CAMP

Moses reports the LORD's words, gathers seventy elders and sets them around the
Tent. The LORD descends in cloud, speaks, and puts the Spirit on the seventy;
they prophesy and then do so no more.

Eldad and Medad are separately retained as registered men who did not go to the
Tent. The Spirit also rests on them and they prophesy in camp. A young man runs
and reports this. Joshua asks Moses to forbid them. Moses asks whether Joshua is
jealous for him and says he wishes every LORD-person were a prophet.

The source therefore shows seventy at the Tent plus two named camp recipients.
It does not state the total registration size or how those two relate to the
ordered seventy-person selection pool, so that membership arithmetic remains
unresolved rather than invented as crack.

## Numbers 11:31–32 — THE REQUESTED MEAT ARRIVES

A wind from the LORD brings quail from the sea and deposits them around the
camp for a day's journey on each side and about two cubits above the ground
surface. The source does not resolve whether that measure describes flight,
depth or another spatial presentation.

The people gather all day, all night and the next day. The least gatherer gets
ten homers. They spread the quail around camp. The demanded meat has observably
been supplied in enormous quantity.

## Numbers 11:33–34 — GRANTED, THEN PLAGUED; PROMISED, THEN BURIED

While the meat is still between their teeth, before it is chewed, the LORD's
anger burns and the LORD strikes the people with a very great plague. The place
is named Kibroth Hattaavah because the people who lusted are buried there.

The first closed mismatch is request/grant/punishment:

```text
PEOPLE DEMAND MEAT
-> LORD EXPLICITLY GIVES MEAT BECAUSE OF THAT DEMAND
-> PEOPLE RECEIVE AND BEGIN EATING PROVIDED MEAT
-> LORD PLAGUES THEM WHILE IT IS STILL UNCHEWED
```

That is `S107-E001-NUM11`.

The second closed mismatch is promised duration versus recipient survival:

```text
ADDRESSED LUSTING PEOPLE: YOU WILL EAT MEAT FOR A WHOLE MONTH
-> SAME PEOPLE RECEIVE FIRST MEAT
-> BEFORE FIRST MOUTHFUL IS CHEWED
-> PEOPLE WHO LUSTED ARE BURIED
```

The source supplies no narrower recipient set that excludes the buried lusting
people from the whole-month promise. That is `S108-E001-NUM11`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes one boil, licks his finger and walks away without looking back.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the next boil, licks his finger and walks away without looking back.
The quail, plague, graves and journey all remain unchanged.

## Numbers 11:35 — MOVE TO HAZEROTH

Israel travels from Kibroth Hattaavah to Hazeroth and stays there. The movement
and new encampment are completed.

## Character and world-ledger changes

- complaint/fire/prayer/abatement cycle completes at Taberah;
- manna's material and food-processing properties are retained;
- Moses states overload and requests death; the LORD instead adds elders;
- seventy Tent elders and Eldad/Medad camp prophecy are completed;
- Joshua requests prohibition; Moses refuses the jealousy framing and wishes
  broader prophecy;
- wind, quail accumulation and minimum ten-homer gathering complete;
- `S107` retains demanded/provided meat against immediate plague;
- `S108` retains month promise against pre-chew burial of lusting recipients;
- people who lusted are actually buried at Kibroth Hattaavah;
- Israel completes travel to Hazeroth;
- all living humans, quail, plants and manna pieces are Joe-faced if shown;
- Captain is permanently boilless and causally useless;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — MEAT CUSTOMER SATISFACTION MONTH`;
- manna box: `LOOKS LIKE BDellium / TASTES LIKE FRESH OIL / STILL COMPLAINING`;
- workload ticket: `MOSES CPU 100% -> ADD 70 ELDER THREADS`;
- camp Wi-Fi: `ELDAD + MEDAD CONNECTED REMOTELY`;
- quail map: `ONE DAY THAT WAY / ONE DAY THIS WAY / 2 CUBITS SOMEHOW`;
- minimum order: `10 HOMERS OR YOU DIDN'T EVEN TRY`;
- promise label: `30-DAY MEAT PLAN`;
- delivery label: `PLAGUE BEFORE CHEWING`;
- CrackFlix: `S107 GRANTED AND PUNISHED / S108 MONTH ZERO BURIAL`;
- barcode: `CHB-NUM11-35-70PLUS2-QUAIL-MONTH-PLAGUE-HELD`.

## FIR verification

- all 35 verse markers are represented in order;
- complaint fire and meat episode remain separate;
- manna statements preserve source speech versus narrator material facts;
- Moses' questions/request remain attributed without invented intent;
- elder load-sharing, Tent prophecy and camp prophecy remain distinct;
- seventy-plus-two observation does not invent registration membership;
- all quail dimensions, collection duration and minimum amount are retained;
- `S107` closes only after demand, deliberate supply, receipt and plague;
- `S108` closes only after month promise, first mouthful and burial relation;
- no claim that every Israelite died is added;
- both Captain appearances occur after their addressed contradictions close;
- every living thing uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Numbers 12 records Miriam/Aaron's speech against Moses,
the LORD's response, Miriam's seven-day exclusion and Hazeroth departure delay.
