# CRACKHEAD NUMBERS 13

## Title page

**WE SAW BIG JOES. WE FELT LIKE GRASSHOPPERS.**

**THEREFORE WE KNOW THEY SAW US AS GRASSHOPPERS.**

Source parent: Numbers chapter 13, verses 1–33, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-013/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/012-WE-BOTH-SAID-IT-SHE-GOT-SEVEN-DAYS-OUTSIDE.md`.

CrackFlix routing:

- new `S110-E001-NUM13 — WE FELT SMALL, SO THEY SAW US SMALL.`

Crack type: mental. The unsupported perception claim is located in the
reporting spies' account, not in the observed inhabitants.

## Causal foundation

```text
LORD: SEND ONE PRINCE PER TRIBE TO SPY CANAAN
-> MOSES SENDS 12 HEADS FROM PARAN
-> HOSHEA RENAMED JOSHUA
-> OBSERVE LAND / PEOPLE / CITIES / SOIL / WOOD
-> BRING FRUIT

40-DAY ROUTE
-> ZIN TO REHOB/HAMATH + SOUTH/HEBRON + ESHCOL
-> 2-MAN GRAPE CLUSTER + POMEGRANATES + FIGS
-> RETURN TO MOSES/AARON/ISRAEL

SHARED REPORT
-> MILK/HONEY + FRUIT
-> STRONG PEOPLE + LARGE FORTIFIED CITIES + NAMED GROUPS

CALEB: WE CAN OVERCOME
OTHER MEN: WE CANNOT / THEY ARE STRONGER
-> COMPETING ASSESSMENTS / NO OUTCOME YET

SPIES' OWN SIGHT: WE WERE LIKE GRASSHOPPERS
-> CLAIM: SO WE WERE IN THEIR SIGHT
-> NO INHABITANT PERCEPTION CARRIER OBSERVED
-> MENTAL CRACK IN REPORTING JOES
```

## Numbers 13:1–16 — TWELVE NAMED SPIES

The LORD tells Moses to send one prince from every fathers' tribe to spy out
Canaan, which the LORD says he gives to Israel. Moses sends twelve heads from
Paran:

| Tribe | Spy |
|---|---|
| Reuben | Shammua son of Zaccur |
| Simeon | Shaphat son of Hori |
| Judah | Caleb son of Jephunneh |
| Issachar | Igal son of Joseph |
| Ephraim | Hoshea son of Nun |
| Benjamin | Palti son of Raphu |
| Zebulun | Gaddiel son of Sodi |
| Joseph/Manasseh | Gaddi son of Susi |
| Dan | Ammiel son of Gemalli |
| Asher | Sethur son of Michael |
| Naphtali | Nahbi son of Vophsi |
| Gad | Geuel son of Machi |

Moses explicitly calls Hoshea son of Nun **Joshua**. This is an observed rename
act, so both names belong to one retained identity without contradiction.

## Numbers 13:17–20 — THE OBSERVATION BRIEF

Moses sends them through the South into the hill country with addressed
questions:

- what the land is;
- whether the people are strong/weak and few/many;
- whether the land is good/bad and fertile/poor;
- whether cities are camps or strongholds;
- whether wood exists;
- and a requirement to bring fruit.

It is first-ripe grape season. Moses tells them to be courageous. The questions
do not pre-select an answer.

## Numbers 13:21–25 — FORTY DAYS AND A TWO-JOE GRAPE CLUSTER

The spies travel from Zin to Rehob at Hamath's entrance, pass through the South
to Hebron, and observe Ahiman, Sheshai and Talmai, children of Anak. The source
adds that Hebron was built seven years before Zoan in Egypt.

At Eshcol they cut one grape cluster so large that two people carry it on a
staff. They also take pomegranates and figs. The valley receives its Eshcol name
from the cut cluster. They return after forty days. All travel, cutting,
carrying and return acts are completed.

## Numbers 13:26–29 — FRUIT SHOWN, CONDITIONS REPORTED

At Kadesh in Paran they report to Moses, Aaron and the whole congregation and
physically show the fruit. They say the land flows with milk and honey and point
to the fruit. They also report:

- strong inhabitants;
- very large fortified cities;
- Anak's children;
- Amalek in the South;
- Hittites, Jebusites and Amorites in the hill country;
- Canaanites by the sea and Jordan.

Fruit evidence does not by itself measure military capacity, and fortified
cities do not negate the fruit. Both observed state classes remain.

## Numbers 13:30–31 — CALEB AND THE OTHERS DISAGREE

Caleb quiets the people and says Israel should go immediately because they are
well able to overcome. The men who travelled with him say Israel cannot go up
because the inhabitants are stronger.

These are opposed future-capacity assessments. No attempted conquest or battle
outcome occurs in this chapter, so disagreement alone does not produce crack.

## Numbers 13:32–33 — MENTAL CRACK

The narrator calls the majority account an evil report. The reporting men say
the land eats its inhabitants and all observed people are of great stature.
They say they saw Nephilim, the Anak descendants from Nephilim.

Their final sentence contains two different evidence boundaries:

> **“We were in our own sight as grasshoppers, and so we were in their sight.”**

The first clause is their direct report of their own perception. The second
asserts the inhabitants' perception. The chapter records no inhabitant saying,
signalling or otherwise showing that perception to the spies.

```text
SPIES OBSERVE THEIR OWN FELT SMALLNESS
-> SPIES ASSERT ANAK/NEPHILIM PERCEPTION AS FACT
-> CLAIM EXCEEDS RETAINED OBSERVATION
-> MENTAL CRACK AT THE REPORTING SPIES
```

That is `S110-E001-NUM13`. It does not prove what the inhabitants thought.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes a reporting Joe's forehead boil, licks his finger, walks away and does
not look back. The report, fruit, disagreement and unobserved perception remain.

## Character and world-ledger changes

- twelve named tribal spies gain a completed forty-day Canaan route;
- Hoshea becomes Joshua through an explicit Moses rename;
- Ahiman, Sheshai and Talmai enter as observed Anak identities;
- Eshcol fruit sample and two-person grape transport are completed;
- land/fruit/city/people observations remain separate evidence classes;
- Caleb retains immediate-conquest confidence;
- other spies retain inability/stronger-people assessment;
- `S110` locates the unsupported other-perception claim in the speakers' model;
- no conquest attempt or capacity result occurs;
- all living humans, grapes, pomegranates, figs and any face-like cities are
  Joe-faced if shown;
- Captain is permanently boilless and causally useless;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — CANAAN FIELD AUDIT / FIRST-RIPE GRAPE BUILD`;
- rename ticket: `HOSHEA -> JOSHUA / TRANSITION VERIFIED`;
- route tracker: `ZIN -> REHOB -> HEBRON -> ESHCOL -> KADESH / 40 DAYS`;
- grape shipping label: `1 CLUSTER / 2 JOES / STAFF REQUIRED`;
- evidence tray: `GRAPES + POMEGRANATES + FIGS`;
- city warning: `FORTIFIED AND VERY LARGE`;
- assessment split: `CALEB: CAN / MAJORITY: CAN'T`;
- mind-reader badge: `THEY DEFINITELY SAW OUR INTERNAL GRASSHOPPERS`;
- CrackFlix: `S110 E001 — MENTAL CRACK FIELD REPORT`;
- barcode: `CHB-NUM13-33-12SPIES-40DAYS-2JOEGRAPE-MENTAL-HELD`.

## FIR verification

- all 33 verse markers are represented in order;
- all twelve spy/tribe/father identities remain exact;
- Hoshea/Joshua identity has an explicit transition;
- Moses' observation brief remains distinct from returned answers;
- route, named Anak people, city-age note, fruit and forty days are retained;
- milk/honey/fruit and danger observations are not falsely opposed;
- Caleb/majority statements remain assessments without invented battle proof;
- narrator's evil-report label remains narrator attribution;
- self-perception and claimed other-perception are separated;
- `S110` is addressed to the speakers' unsupported claim, not imagined Anak
  crack;
- Captain appears only after the mental contradiction closes and changes nothing;
- every living thing uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Numbers 14 records the congregation's return-to-Egypt
proposal, Joshua/Caleb response, stoning proposal, LORD destruction/replacement
proposal, Moses intercession, forty-year judgment, spy deaths and unauthorized
hill-country defeat.
