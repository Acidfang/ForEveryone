# CRACKHEAD NUMBERS 20

## Title page

**SPEAK TO THE ROCK.**

**HIT IT TWICE. WATER STILL COMES.**

**YOU CAN'T GO IN.**

Source parent: Numbers chapter 20, verses 1–29, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-020/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/019-CLEAN-JOE-CLEANS-UNCLEAN-JOE-CLEAN-JOE-IS-NOW-UNCLEAN.md`.

CrackFlix routing:

- new `S115-E001-NUM20 — SPEAK TO ROCK / STRIKE TWICE / OUTPUT DELIVERED`

## Causal foundation

```text
ISRAEL TO ZIN/KADESH
-> MIRIAM DIES + IS BURIED THERE

NO WATER
-> CONGREGATION QUARRELS / WISHES DEATH / ACCUSES MOSES/AARON
-> MOSES/AARON FALL AT TENT / GLORY APPEARS

LORD COMMAND
-> TAKE ROD
-> ASSEMBLE CONGREGATION
-> SPEAK TO ROCK BEFORE THEIR EYES
-> ROCK POURS WATER FOR PEOPLE + LIVESTOCK

MOSES ACTION
-> TAKES ROD / ASSEMBLES PEOPLE
-> SAYS SHALL WE BRING WATER
-> STRIKES ROCK TWICE
-> ABUNDANT WATER STILL COMES
-> PEOPLE + LIVESTOCK DRINK
-> MOSES/AARON EXCLUDED FROM LAND-ENTRY LEADERSHIP

PASSAGE REQUEST TO EDOM
-> TWO REFUSALS + ARMED FORCE
-> ISRAEL TURNS AWAY

MOUNT HOR
-> AARON GARMENTS TRANSFERRED TO ELEAZAR
-> AARON DIES
-> MOSES/ELEAZAR RETURN
-> ISRAEL WEEPS 30 DAYS
```

## Numbers 20:1 — MIRIAM DIES AT KADESH

The whole congregation enters Zin in the first month and stays at Kadesh.
Miriam dies and is buried there. Her death and burial are completed, but the
source gives no day, age, cause, grave construction, mourners or ceremony.

This closes Miriam's living history without supplying the previously unresolved
mechanism by which her Numbers 12 bodily condition ended before reentry.

## Numbers 20:2–6 — NO WATER, SAME DEATH WISH

There is no water. The congregation assembles against Moses and Aaron, quarrels,
wishes it had died when its brothers died before the LORD, asks why the LORD's
assembly and livestock were brought to die in the wilderness, and asks why it
left Egypt for a place without seed, figs, vines, pomegranates or drinking
water.

These are spoken wishes, accusations and questions. No dehydration death occurs
before Moses and Aaron leave the assembly, go to the Tent door and fall on their
faces. The LORD's glory appears; its visible mechanism remains unresolved.

## Numbers 20:7–9 — EXACT ROCK INSTRUCTION

The LORD tells Moses:

1. take the rod;
2. assemble the congregation with Aaron;
3. speak to the rock before their eyes;
4. the rock will pour out water;
5. give the congregation and livestock drink.

Moses takes the rod from before the LORD as commanded. The presence of the rod
does not replace the explicit speech operation.

## Numbers 20:10–13 — HIT TWICE, RECEIVE OUTPUT, LOSE ENTRY

Moses and Aaron assemble Israel before the rock. Moses calls them rebels and
asks whether “we” shall bring water from the rock. He then raises his hand and
strikes the rock twice with the rod.

The source narrates no speech addressed to the rock. It does narrate abundant
water coming out, followed by the congregation and livestock drinking.

```text
REQUIRED OPERATION: SPEAK TO ROCK
-> PERFORMED OPERATION: STRIKE ROCK TWICE
-> REQUIRED OUTPUT ARRIVES ANYWAY
-> CONSUMERS RECEIVE WATER
-> LORD STATES MOSES/AARON DID NOT BELIEVE/SANCTIFY
-> MOSES/AARON CANNOT BRING ASSEMBLY INTO LAND
```

That is `S115-E001-NUM20`. Successful output does not establish that the
commanded operation was performed. The LORD's allocation of the joint penalty
to Moses and Aaron is explicit; the chapter does not separately narrate Aaron
striking, speaking or stopping Moses.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes Moses' boil, licks his finger, walks away and does not look back. The
water remains delivered and the land-entry exclusion remains.

The place is named the waters of Meribah because Israel strove with the LORD.
The source says the LORD was sanctified in them after saying Moses/Aaron failed
to sanctify him in Israel's eyes. It does not supply the intermediate
sanctification mechanism or say their failed act became successful; both
attributed states remain.

## Numbers 20:14–21 — EDOM SAYS NO TWICE

Moses sends Edom's king a “brother Israel” message recounting Egypt residence,
mistreatment, crying to the LORD, angel delivery and current Kadesh border
position. Israel asks to cross only by the king's highway without fields,
vineyards, well water or side turns.

Edom refuses and threatens sword. Israel offers to pay for any water used and
again requests foot passage. Edom again refuses, comes out with many people and
a strong hand, and denies passage. Israel turns away. No border crossing,
drinking, payment or battle occurs.

## Numbers 20:22–29 — AARON'S GARMENTS COME BACK DOWN

Israel travels from Kadesh to Mount Hor at Edom's border. The LORD tells Moses
and Aaron that Aaron will be gathered to his people and will not enter the land
because “you” rebelled against the word at Meribah.

Moses must bring Aaron and Eleazar up the mountain, strip Aaron's priestly
garments and put them on Eleazar. They ascend in view of the congregation.
Moses transfers the garments; Aaron dies on the summit; Moses and Eleazar come
down. Israel observes Aaron's death State and the whole house weeps thirty days.

The garment transfer visibly preserves the priestly office while Aaron's living
role ends. No burial, body transport, grave, cause, age or summit witness beyond
Moses/Eleazar is supplied.

## Character and world-ledger changes

- Miriam dies and is buried at Kadesh;
- Israel's no-water quarrel and death wishes remain speech without pre-water
  death;
- `S115` retains commanded rock speech versus performed double strike;
- abundant water and livestock/human drinking complete despite operation drift;
- Moses and Aaron receive joint land-entry leadership exclusion;
- Meribah sanctification mechanism remains unresolved;
- Edom twice refuses passage and Israel turns away without battle;
- Aaron's garments transfer to Eleazar and Aaron dies on Mount Hor;
- Israel completes thirty days of mourning;
- Aaron burial/body disposition remains unresolved;
- every living human, animal, plant and face-like rock, water, rod, garment,
  border or mountain is Joe-faced if shown;
- Captain is permanently boilless and causally useless;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — ROCK I/O / OPERATION MISMATCH`;
- command card: `INPUT: SPEECH / OUTPUT: WATER`;
- runtime log: `INPUT OBSERVED: TWO ROD HITS`;
- status light: `OUTPUT DELIVERED ANYWAY`;
- access revocation: `LAND-ENTRY LEADERSHIP: DENIED`;
- Meribah label: `SANCTIFIED SOMEHOW / BRIDGE NOT INCLUDED`;
- Edom toll request: `HIGHWAY ONLY / WATER PAID / STILL NO`;
- succession ticket: `AARON GARMENTS -> ELEAZAR / ROOT RETAINED`;
- mourning timer: `30 DAYS`;
- barcode: `CHB-NUM20-29-MIRIAM-ROCK2X-EDOMNO-AARONDEAD-HELD`.

## FIR verification

- all 29 verse markers are represented in order;
- Miriam death/burial remain exact without invented cause or rites;
- no-water complaint speech is not adopted as motive or outcome;
- rod-taking and rock-speaking requirements remain separately visible;
- no unrecorded rock speech is invented;
- two rock strikes, abundant water and completed drinking remain ordered;
- successful output does not erase command/action mismatch;
- Moses/Aaron joint penalty remains source attribution without invented Aaron act;
- sanctification statements remain distinct and mechanism unresolved;
- Edom negotiations, armed refusal and Israel withdrawal remain exact;
- Aaron-to-Eleazar garment transfer precedes Aaron's death;
- Aaron burial/body handling is not invented;
- Captain appears after the completed mismatch and changes nothing;
- publication remains held and unpublished.

Continuation required: Numbers 21 records Arad's attack, Hormah destruction,
fiery serpents and bronze serpent, travel wells, and Sihon/Og victories.
