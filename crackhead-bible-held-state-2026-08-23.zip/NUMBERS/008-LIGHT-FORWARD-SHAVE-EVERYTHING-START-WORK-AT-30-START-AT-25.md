# CRACKHEAD NUMBERS 8

## Title page

**LIGHT THE SEVEN LAMPS FORWARD. SHAVE EVERY LEVITE EVERYWHERE. WAVE THEM.**

**START TENT WORK AT 30. START TENT WORK AT 25.**

Source parent: Numbers chapter 8, verses 1–26, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-008/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/007-SIX-WAGONS-TWELVE-OXEN-TWELVE-DAYS-ON-ONE-DAY.md`.

CrackFlix routing:

- new `S105-E001-NUM08 — START WORK AT 30. START WORK AT 25.`

## Causal foundation

```text
LORD COMMANDS LAMP ORIENTATION
-> AARON LIGHTS SEVEN LAMPS FORWARD
-> COMPLETED

LEVITES SELECTED FROM ISRAEL
-> WATER + WHOLE-BODY SHAVE + CLOTHES WASH
-> ISRAEL LAYS HANDS ON LEVITES
-> AARON WAVES LEVITES TO LORD
-> LEVITES LAY HANDS ON BULLS
-> SIN + BURNT OFFERINGS / ATONEMENT
-> LEVITES GIVEN IN PLACE OF FIRSTBORN
-> LEVITES ENTER TENT SERVICE
-> COMPLETED

NUMBERS 4: AGE 30–50 ENTER SERVICE TO DO TENT WORK
NUMBERS 8: AGE 25+ ENTER SERVICE IN TENT WORK
-> SAME PEOPLE / SAME INSTITUTION / SAME WORK-SERVICE WORDING
-> NO 25–29 TRANSITION OR TRAINING CLASS SUPPLIED

AGE 50
-> RETIRE FROM WORK / SERVE NO MORE
-> MAY ASSIST BROTHERS IN DUTY
-> PERFORM NO SERVICE
```

## Numbers 8:1–4 — AARON LIGHTS THE LAMPS FORWARD

The LORD tells Moses to instruct Aaron that the seven lamps must light the area
in front of the lampstand. Aaron does exactly that. The lampstand is beaten
gold from base through flowers and was made according to the pattern the LORD
showed Moses. The lighting is completed; no new lamp manufacture occurs here.

## Numbers 8:5–14 — CLEAN, SHAVE, WASH, WAVE

The LORD orders the Levites taken from Israel and cleansed. The procedure is:

- sprinkle cleansing water on them;
- shave their whole bodies with a razor;
- wash their clothes and cleanse themselves;
- bring one young bull with oil-mixed flour and another bull for sin offering;
- assemble all Israel at the Tent;
- Israel lays hands on the Levites;
- Aaron presents the Levites as a wave offering on Israel's behalf;
- Levites lay hands on the bulls;
- one bull becomes sin offering, the other burnt offering;
- the Levites are set before Aaron and sons and offered to the LORD.

This separates the Levites from Israel and the LORD declares them his. The
procedure treats living Levites as the addressed wave offering without stating
that they are killed or burned.

## Numbers 8:15–19 — TAKEN, THEN GIVEN

After cleansing and presentation, the Levites enter Tent service. The LORD
says they are wholly given to him instead of every Israelite firstborn, whom he
claimed and sanctified when striking Egypt's firstborn. He then gives the
Levites to Aaron and sons to perform Israel's Tent service and atonement so no
plague occurs when Israel approaches the sanctuary.

The taking and giving are successive ownership/service relations. The source
does not say Aaron replaces the LORD as owner, and no plague occurs here.

## Numbers 8:20–22 — THEY ACTUALLY DO ALL OF IT

Moses, Aaron and the whole congregation carry out the command. The Levites
purify themselves, wash their clothes, are offered by Aaron as a wave offering,
receive atonement, and then enter the Tent to perform service before Aaron and
his sons. These are completed acts, not merely prescribed procedures.

## Numbers 8:23–26 — THE WORK AGE MOVES FIVE YEARS

The LORD now assigns Levites aged twenty-five and upward to enter service in
the work of the Tent of Meeting. Numbers 4 had repeatedly selected males aged
thirty through fifty as those who enter Tent service to do the work.

```text
NUMBERS 4:3,23,30,35,39,43,47
-> ENTER SERVICE / DO WORK / AGE 30 THROUGH 50

NUMBERS 8:24
-> GO IN TO WAIT ON SERVICE / WORK OF TENT / AGE 25 AND UP
```

No apprenticeship, training-only role, changed census grain or other 25–29
bridge is stated. The same Levite/Tent/service/work boundary therefore begins
at two different ages. That is `S105-E001-NUM08`.

At fifty the source supplies a distinct retirement boundary: the Levite stops
doing work and serves no more, but may assist brothers performing duty while
personally performing no service. That explicit post-fifty assistance class
does not identify the missing age-25-through-29 relation.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes the boil, licks his finger, walks away and does not look back. Both
starting ages and the completed Levite service remain unchanged.

## Character and world-ledger changes

- Aaron completes forward-facing seven-lamp lighting;
- lampstand retains beaten-gold/pattern craftsmanship;
- Levites complete water, whole-body shave and clothes-wash cleansing;
- Israel lays hands on Levites and Levites lay hands on bulls;
- Aaron offers living Levites as a wave offering and makes atonement;
- Levites are retained as firstborn substitutes and gift to Aaron/sons;
- Levites actually enter Tent service;
- `S105` retains age 30 versus age 25 for entering Tent-service work;
- age-fifty retirement/assistance/no-service distinction remains exact;
- all living humans, bulls and any face-like lampstand are Joe-faced if shown;
- Captain is permanently boilless and causally useless;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — LEVITE ONBOARDING AND FULL-BODY RAZOR DAY`;
- lamp switch: `ALL 7 -> FORWARD`;
- cleansing docket: `SPRINKLE / SHAVE ALL / WASH CLOTHES`;
- human cargo label: `WAVE OFFERING — DO NOT BURN THE JOES`;
- substitution sticker: `FIRSTBORN SLOT -> LEVITE`;
- employment form A: `START AGE 30`;
- employment form B: `START AGE 25`;
- retirement badge: `50+ ASSIST DUTY / NO SERVICE`;
- CrackFlix: `S105 E001 — FIVE YEARS OF UNDEFINED EMPLOYMENT`;
- barcode: `CHB-NUM08-26-7LAMPS-SHAVE-WAVE-30-25-HELD`.

## FIR verification

- all 26 verse markers are represented in order;
- lamp command and Aaron's completed act remain distinct from craftsmanship;
- every cleansing, laying-on, offering and atonement step is retained;
- living Levite wave offering is not converted into animal sacrifice;
- firstborn substitution and subsequent gift-to-Aaron relation remain ordered;
- completed cleansing/service acts are not reduced to prospective rules;
- `S105` compares the exact age/service/work boundaries only;
- no training/apprenticeship explanation is invented for ages 25–29;
- age-fifty assistance/no-service distinction remains preserved;
- Captain appears only after `S105` closes and changes nothing;
- every living thing uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Numbers 9 performs the wilderness Passover, derives a
second-month route for corpse-unclean/travelling people, and begins the completed
cloud/fire movement-control history.
