# CRACKHEAD NUMBERS 9

## Title page

**DEAD BODY OR FAR AWAY? DO PASSOVER NEXT MONTH.**

**CLOUD UP: MOVE. CLOUD DOWN: STAY. COULD BE A NIGHT. COULD BE A YEAR.**

Source parent: Numbers chapter 9, verses 1–23, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-009/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/008-LIGHT-FORWARD-SHAVE-EVERYTHING-START-WORK-AT-30-START-AT-25.md`.

CrackFlix routing: none. The second-month Passover is an explicit exception for
corpse-unclean and far-travelling people. The cloud's staying and lifting are
the observable camp/travel controller, not conflicting simultaneous commands.

## Causal foundation

```text
FIRST MONTH / DAY 14 / EVENING
-> ISRAEL KEEPS PASSOVER IN SINAI
-> COMPLETED

CORPSE-UNCLEAN MEN CANNOT KEEP THAT DAY
-> ASK WHY THEY ARE KEPT BACK
-> MOSES WAITS FOR LORD'S COMMAND
-> DEAD-BODY UNCLEAN OR FAR JOURNEY
-> SECOND MONTH / DAY 14 / EVENING
-> SAME PASSOVER STATUTE

CLEAN + NOT TRAVELLING + FAILS TO KEEP
-> CUT OFF / BEARS SIN

FOREIGNER DESIRES TO KEEP
-> SAME STATUTE AND ORDINANCE

TABERNACLE RAISED
-> CLOUD BY DAY / FIRE APPEARANCE BY NIGHT
-> CLOUD REMAINS: ISRAEL REMAINS CAMPED
-> CLOUD LIFTS: ISRAEL TRAVELS
-> DURATION MAY BE NIGHT / DAYS / MONTH / YEAR
```

## Numbers 9:1–5 — PASSOVER IN THE WILDERNESS

In the first month of the second year after leaving Egypt, the LORD tells Moses
that Israel must keep Passover at its appointed time: the fourteenth day at
evening, according to every statute and ordinance. Moses tells Israel. Israel
keeps it at the appointed evening in the Sinai wilderness exactly as commanded.
This Passover occurrence is completed.

## Numbers 9:6–8 — “WHY ARE WE KEPT BACK?”

Certain unnamed men are unclean because of a man's dead body and therefore
cannot keep Passover that day. They come to Moses and Aaron and say:

> **“We are unclean because of the dead body of a man. Why are we kept back,
> that we may not offer the offering of the LORD in its appointed season among
> the children of Israel?”**

Moses does not invent a ruling. He tells them to wait while he hears what the
LORD commands concerning them. The corpse, its identity and the men's exact
contact acts are not supplied.

## Numbers 9:9–14 — THE SECOND-MONTH ROUTE

The LORD supplies an explicit exception path. A person who is corpse-unclean or
on a far journey still keeps Passover, but on the fourteenth evening of the
second month. The person eats it with unleavened bread and bitter herbs, leaves
none until morning, breaks no bone, and follows the whole Passover statute.

This differs from the clean person who is not travelling and simply fails to
keep Passover: that person is cut off, bears the stated sin and is charged with
not offering at the appointed time. The two states do not cleanly collapse:

```text
PREVENTED BY NAMED CONDITION -> DELAYED ROUTE
NOT PREVENTED + FAILS -> CUT OFF
```

A resident foreigner who desires to keep Passover must use the same statute and
ordinance as a native-born person. No second-month Passover, cutting off or
foreigner Passover occurrence is narrated here.

## Numbers 9:15–16 — CLOUD BY DAY, FIRE APPEARANCE BY NIGHT

On the day the Tabernacle is raised, the cloud covers the Tent of the Testimony.
At evening its appearance is like fire until morning. This cloud/day and
fire-appearance/night pattern continues. The Tabernacle-raising day and initial
covering are completed historical acts.

## Numbers 9:17–23 — THE MOVEMENT CONTROLLER

The chapter records a recurring observed control relation:

```text
CLOUD LIFTED FROM TENT
-> ISRAEL TRAVELLED

CLOUD SETTLED / REMAINED
-> ISRAEL ENCAMPED AND DID NOT TRAVEL
```

The source attributes both responses to the LORD's command through Moses. The
observable durations vary without changing the controller:

- many days: remain;
- a few days: remain, then travel when lifted;
- evening until morning: travel when lifted in morning;
- by day or by night: travel whenever lifted;
- two days, a month or a year: remain for the whole stay, then travel.

Israel repeatedly keeps this command. The chapter does not enumerate every
camp location or travel leg and supplies no separate spoken sentence for each
cloud movement. Cloud motion is not described as Israel's motive; it is the
retained observable condition paired with each collective act.

## Character and world-ledger changes

- Israel completes the first-month Sinai Passover;
- corpse-unclean men ask a retained direct question;
- Moses explicitly waits for a LORD ruling rather than supplying one;
- corpse uncleanness and far journey receive the second-month route;
- clean/non-travelling failure retains cut-off/sin consequence;
- resident foreigner and native share performance statute;
- cloud/day and fire-appearance/night begin at Tabernacle raising;
- repeated cloud-stay/camp and cloud-lift/travel histories are completed;
- durations from one night through one year are retained;
- no contradiction, SKIP, crack, Captain or YOINK occurs;
- all living humans are Joe-faced; cloud/fire may receive Joe face if rendered
  as face-like controllers;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — PASSOVER EXCEPTION ROUTER / CLOUD TRAFFIC CONTROL`;
- calendar A: `MONTH 1 / DAY 14 / EVENING`;
- exception ticket: `DEAD BODY OR FAR AWAY -> MONTH 2`;
- food label: `UNLEAVENED + BITTER / NO LEFTOVERS / DON'T BREAK BONES`;
- eligibility gate: `CLEAN + HOME + DIDN'T -> CUT OFF`;
- foreigner form: `SAME STATUTE`;
- cloud dashboard: `DOWN = PARK / UP = FUCKING MOVE`;
- duration spinner: `OVERNIGHT / FEW DAYS / MANY DAYS / MONTH / YEAR`;
- fire mode: `NIGHT-SHIFT CLOUD SKIN`;
- barcode: `CHB-NUM09-23-PASSOVER2-CLOUD-UP-MOVE-HELD`.

## FIR verification

- all 23 verse markers are represented in order;
- first-month Passover performance is completed;
- corpse-unclean men's question and Moses' wait remain direct speech acts;
- second-month route retains both qualifying conditions and exact date;
- delayed eligibility is not merged with clean/non-travelling failure;
- foreigner/native one-statute rule is retained without invented participation;
- cloud, fire appearance, stay, lift, camp and travel relations remain ordered;
- every stated duration class is represented;
- source command attribution is preserved without invented spoken commands;
- recurring cloud behavior is not misread as uninterrupted physical covering;
- no unsupported contradiction or Captain mechanism is added;
- every living thing uses Joe face if shown;
- publication remains held and unpublished.

Continuation required: Numbers 10 creates the two-silver-trumpet signal system,
begins the first cloud-directed departure from Sinai, fixes march order, and
records Moses' invitation and ark movement speeches.
