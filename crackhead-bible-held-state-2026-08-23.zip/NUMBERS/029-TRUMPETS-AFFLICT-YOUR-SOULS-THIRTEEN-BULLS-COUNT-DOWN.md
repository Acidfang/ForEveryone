# CRACKHEAD NUMBERS 29

## Title page

**BLOW TRUMPETS.**

**AFFLICT YOUR SOULS.**

**THIRTEEN BULLS.**

**COUNT DOWN.**

Source parent: Numbers chapter 29, verses 1–40, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-029/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/028-TWO-EVERY-DAY-ADD-SABBATH-ADD-MONTH-ADD-FEAST.md`.

CrackFlix routing: none. No completed observable contradiction is derived.

## Causal foundation

```text
SEVENTH MONTH DAY 1
-> TRUMPET CONVOCATION SET + NEW-MOON SET + CONTINUAL BASE

SEVENTH MONTH DAY 10
-> AFFLICTION/ATONEMENT SET + ATONEMENT SIN OFFERING + CONTINUAL BASE

SEVENTH MONTH DAY 15..21
-> SEVEN-DAY FEAST
-> BULLS: 13, 12, 11, 10, 9, 8, 7
-> EACH DAY: 2 RAMS + 14 LAMBS + 1 GOAT + CONTINUAL BASE

DAY 22 / EIGHTH ASSEMBLY DAY
-> 1 BULL + 1 RAM + 7 LAMBS + 1 GOAT + CONTINUAL BASE

MOSES TELLS ISRAEL
!= SCHEDULE OBSERVED PERFORMED
```

## Numbers 29:1–6 — DAY ONE: TRUMPETS ON TOP OF TWO BASES

The first day of the seventh month is a holy convocation, a day of trumpet
blowing, with no regular work. Its scheduled burnt-offering set is one bull,
one ram and seven one-year-old male lambs without defect, plus one male goat as
a sin offering.

The meal ratio remains three tenths of an ephah for the bull, two tenths for the
ram and one tenth for each lamb, with the required drink offerings. This set is
explicitly additional to both the new-moon offering and the continual offering.
None of the three layers overwrites another.

## Numbers 29:7–11 — DAY TEN: AFFLICT YOUR SOULS

The tenth day is a holy convocation. Israel must afflict their souls and do no
kind of work. The scheduled set is again one bull, one ram, seven lambs and one
sin-offering goat, with the same meal ratios and drink offerings.

This goat is additional to the separately addressed sin offering of atonement,
and the whole scheduled layer remains additional to the continual burnt, meal
and drink offerings. The chapter does not perform or explain the soul-affliction
or atonement mechanisms.

## Numbers 29:12–16 — FEAST DAY ONE: THIRTEEN

The fifteenth day begins a seven-day feast with a holy convocation and no
regular work. Day one's addition is thirteen bulls, two rams, fourteen
one-year-old male lambs without defect and one sin-offering goat. Meal portions
are three tenths per bull, two tenths per ram and one tenth per lamb, with drink
offerings according to the ordinance. The continual base still runs.

## Numbers 29:17–34 — DAYS TWO THROUGH SEVEN: REMOVE ONE BULL PER DAY

The scheduled feast sequence is exact:

| Feast day | Bulls | Rams | Lambs | Sin goats |
|---:|---:|---:|---:|---:|
| 1 | 13 | 2 | 14 | 1 |
| 2 | 12 | 2 | 14 | 1 |
| 3 | 11 | 2 | 14 | 1 |
| 4 | 10 | 2 | 14 | 1 |
| 5 | 9 | 2 | 14 | 1 |
| 6 | 8 | 2 | 14 | 1 |
| 7 | 7 | 2 | 14 | 1 |

Across the seven days that is **70 bulls, 14 rams, 98 lambs and 7 goats**,
before the continual daily base. The arithmetic is derived from the explicit
day rows; it does not claim a mass offering occurred.

Every day retains meal and drink offerings according to that day's animal
number and the ordinance. Every day also states or inherits addition to the
continual burnt offering rather than replacement of it.

## Numbers 29:35–38 — EIGHTH DAY: SOLEMN ASSEMBLY

The eighth day is a solemn assembly with no regular work. Its distinct scheduled
set is one bull, one ram, seven one-year-old male lambs without defect and one
sin-offering goat, with meal and drink offerings according to their number.
It too is additional to the continual offering.

The eighth day is not silently treated as an eighth row of the 13-to-7 bull
countdown. It has its own assembly and 1-1-7-1 schedule.

## Numbers 29:39–40 — SET FEASTS DO NOT ABSORB VOLUNTARY ACTS

The set-feast offerings are additional to vows and freewill offerings, including
burnt, meal, drink and peace offerings. The recurring calendar therefore does
not erase separately initiated offerings.

Moses tells Israel everything the LORD commanded him. This delivery is the
chapter's completed human act. The future scheduled offerings remain commands,
not observed executions.

## Character and world-ledger changes

- Moses completes delivery of the seventh-month schedule to Israel;
- day-one trumpet, day-ten soul-affliction and day-fifteen feast boundaries remain distinct;
- trumpet day stacks on new-moon and continual offerings;
- atonement-day set stacks on its separate atonement sin offering and continual base;
- feast bulls descend exactly 13 through 7 while rams/lambs/goats remain fixed;
- the seven-day derived total is retained without inventing performance;
- eighth-day 1-1-7-1 assembly remains separate from the countdown;
- vows and freewill offerings remain additional, not absorbed by set feasts;
- no unsupported contradiction, Captain, crack, YOINK or SKIP occurs;
- every living human, bull, ram, lamb, goat and face-like trumpet, calendar,
  fraction, soul meter, ephah, hin, altar or countdown display is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — SEVENTH-MONTH OFFERING STACK`;
- day-one warning: `NEW MOON + TRUMPETS + DAILY / ALL THREE`;
- day-ten control: `AFFLICT SOULS / NO WORK / ADD ATONEMENT / ADD DAILY`;
- feast display: `13 > 12 > 11 > 10 > 9 > 8 > 7`;
- fixed channels: `2 RAM / 14 LAMB / 1 GOAT EVERY FEAST DAY`;
- seven-day inventory: `70 BULL / 14 RAM / 98 LAMB / 7 GOAT`;
- eighth-day reset: `1 / 1 / 7 / 1`;
- optional-input port: `VOWS + FREEWILL NOT INCLUDED`;
- fake warning: `MOSES SENT SCHEDULE. ALTAR LOG NOT ATTACHED.`;
- barcode: `CHB-NUM29-40-SEVENTH-MONTH-BULL-COUNTDOWN-HELD`.

## FIR verification

- all 40 verse markers are represented in order;
- trumpet day convocation/work boundary and 1-1-7-1 set are retained;
- its new-moon and continual additions are both retained;
- day-ten soul-affliction/no-work and offering layers remain distinct;
- atonement sin offering is not merged with the additional goat;
- feast days one through seven retain bulls 13 through 7 exactly;
- each feast day retains two rams, fourteen lambs and one goat;
- derived seven-day totals equal 70, 14, 98 and 7 respectively;
- every feast day remains additional to the continual base;
- eighth-day solemn assembly and 1-1-7-1 set remain separate;
- vows/freewill offerings remain outside and additional to set feasts;
- Moses' command delivery is completed without inventing offering execution;
- no Captain or CrackFlix event is added without a completed contradiction;
- publication remains held and unpublished.

Continuation required: Numbers 30 defines vow authority, silence-based
confirmation and same-day disallowance across father and husband relations.
