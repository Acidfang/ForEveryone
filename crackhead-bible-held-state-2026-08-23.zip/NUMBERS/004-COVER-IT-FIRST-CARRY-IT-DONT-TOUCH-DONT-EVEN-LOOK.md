# CRACKHEAD NUMBERS 4

## Title page

**COVER IT FIRST. THEN CARRY IT. DON'T TOUCH IT.**

**DON'T EVEN LOOK AT IT FOR A MOMENT OR YOU DIE.**

Source parent: Numbers chapter 4, verses 1–49, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-004/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/003-COUNT-22300-ROUND-TO-22000-CHARGE-THE-EXTRA-273.md`.

Joined parents: Numbers 3 Levite family/cargo assignments; Exodus Tabernacle
objects and carrying poles; Leviticus priestly access boundaries.

CrackFlix routing: none. Priests cover and prepare the holy objects before
Kohathite carriers approach; carrying does not require direct touching or
uncovered observation. The protection sequence is explicit.

## Causal foundation

```text
WORKING LEVITE SELECTOR -> MALE / AGE 30 THROUGH 50 / TENT SERVICE

CAMP MOVES
-> AARON + SONS ENTER FIRST
-> COVER/PACK ARK + TABLE + LAMPSTAND + ALTARS + VESSELS
-> INSTALL POLES / FRAMES
-> KOHATHITES ENTER AFTER PACKING
-> CARRY COVERED LOADS
-> NO DIRECT TOUCH / NO MOMENTARY SANCTUARY VIEW -> DEATH PREVENTED

KOHATH -> MOST HOLY LOADS / ELEAZAR OVERSIGHT
GERSHON -> CURTAINS / COVERINGS / SCREENS / HANGINGS / CORDS / ITHAMAR
MERARI -> BOARDS / BARS / PILLARS / SOCKETS / PINS / CORDS / ITHAMAR

COUNTED WORKERS
-> KOHATH 2,750
-> GERSHON 2,630
-> MERARI 3,200
-> TOTAL 8,580
-> EACH ASSIGNED SERVICE + BURDEN
```

## Numbers 4:1–4 — WORKING-AGE KOHATHITES

The LORD tells Moses and Aaron to count Kohathite males by family and fathers'
house from age thirty through fifty who enter Tent service. Their selected work
concerns the most holy things. This is a new service-age census, not the
one-month-and-up substitution census from Numbers 3.

## Numbers 4:5–15 — PRIESTS PACK; KOHATHITES CARRY

When camp moves, Aaron and his sons enter first. They take down the screen veil
and pack the sanctuary objects in a specified sequence:

- ark: veil, sealskin, blue cloth and poles;
- showbread table: blue cloth, dishes, spoons, bowls, cups, continual bread,
  scarlet cloth, sealskin and poles;
- lampstand and tools/oil vessels: blue cloth, sealskin and frame;
- golden altar: blue cloth, sealskin and poles;
- ministry vessels: blue cloth, sealskin and frame;
- altar: ashes removed, purple cloth, fire pans, hooks, shovels, basins,
  sealskin and poles.

Only after the priests finish covering everything may the Kohathites approach
to carry it. They may not directly touch the sanctuary objects, under the
stated death consequence. The coverings, frames and poles supply the observable
carrier boundary. No camp movement, packing, touch or death occurs here.

## Numbers 4:16–20 — ELEAZAR SUPERVISES; DON'T LOOK

Eleazar is responsible for lamp oil, incense, continual meal offering,
anointing oil, the Tabernacle requirements, sanctuary and furnishings.

The LORD tells Moses and Aaron not to let the Kohathite family be cut off.
Aaron and his sons must assign every carrier an exact service and burden so the
Kohathites live when approaching the holy things. They may not enter to see the
sanctuary even for a moment, under a death consequence. This is a prevention
procedure, not a narrated casualty.

## Numbers 4:21–28 — GERSHON: FABRIC LOADS UNDER ITHAMAR

The same age-thirty-through-fifty service selector applies to Gershon. Their
burdens are the Tabernacle curtains, Tent and coverings, sealskin, entrance
screen, court hangings and gate screen, cords and service instruments. Aaron
and his sons assign the individual burdens. Ithamar son of Aaron supervises.

## Numbers 4:29–33 — MERARI: STRUCTURAL LOADS UNDER ITHAMAR

The same working-age selector applies to Merari. Their burdens are boards,
bars, pillars, sockets, court pillars and sockets, pins, cords, instruments and
all related service. The instruments are assigned by name. Ithamar also
supervises this branch.

## Numbers 4:34–45 — THREE COMPLETED WORKER COUNTS

Moses, Aaron and Israel's princes perform the family and fathers'-house census
of service-eligible males aged thirty through fifty:

| Levite branch | Counted workers |
|---|---:|
| Kohath | 2,750 |
| Gershon | 2,630 |
| Merari | 3,200 |

Each source subtotal is retained. “Entered service” classifies the people
counted for the work; the chapter does not narrate an actual transport cycle.

## Numbers 4:46–49 — 8,580 NAMED BURDENS

The three worker counts sum exactly:

```text
2,750 + 2,630 + 3,200 = 8,580
```

Moses counts them as commanded, each according to service and burden. The
census and assignment are completed. The future packing, carrying, touching,
looking and death branches remain unperformed.

## Character and world-ledger changes

- service eligibility is fixed at ages thirty through fifty;
- Aaron and sons alone perform pre-carry sanctuary covering/packing;
- Kohath carries covered holy objects without direct touch or uncovered viewing;
- Eleazar oversees sanctuary materials and Kohathite duty keepers;
- Gershon carries fabrics/screens/cords under Ithamar;
- Merari carries structural hardware under Ithamar;
- three completed counts verify to 8,580 workers;
- individual service and burden assignments are completed;
- no transport, forbidden touch/view or death occurs;
- all living workers are Joe-faced if shown;
- no contradiction, SKIP, crack, Captain appearance or YOINK occurs;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — MOVING COMPANY SAFETY MANUAL`;
- age gate: `30–50 / IF OUTSIDE RANGE DO NOT CLOCK IN`;
- priest packing label: `AUTHORIZED WRAPPERS ONLY`;
- ark package: `VEIL + SEALSKIN + BLUE + POLES`;
- Kohath warning: `CARRY PACKAGE / DO NOT TOUCH CONTENTS / DO NOT PEEK`;
- Gershon truck: `CURTAINS, SCREENS, CORDS AND OTHER FLAPPY SHIT`;
- Merari truck: `BOARDS, BARS, PILLARS, SOCKETS AND HEAVY SHIT`;
- supervisor tags: `ELEAZAR: HOLY LOADS / ITHAMAR: EVERYTHING ELSE`;
- checksum: `2750 + 2630 + 3200 = 8580`;
- barcode: `CHB-NUM04-49-WRAP-CARRY-NO-TOUCH-NO-LOOK-8580-HELD`.

## FIR verification

- all 49 verse markers are represented in order;
- age, sex, family and service selectors remain exact;
- every sanctuary object, covering class and carrier boundary is retained;
- priest preparation occurs before Kohathite approach;
- carry/no-touch/no-look rules are not falsely collapsed into contradiction;
- lethal outcomes remain prospective and unperformed;
- Gershon and Merari loads and Ithamar oversight remain distinct;
- all three worker subtotals verify to 8,580;
- census/assignment completion is distinguished from future transport service;
- every living thing uses Joe face if shown;
- no contradiction, SKIP, crack, Captain or YOINK is added;
- publication remains held and unpublished.

Continuation required: Numbers 5 removes source-labelled unclean people from camp, orders restitution plus a fifth, and gives the priest-administered jealousy test.
