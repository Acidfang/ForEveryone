# CRACKHEAD NUMBERS 16

## Title page

**EVERYONE IS HOLY.**

**NOW RUN THE MACHINE THAT SELECTS WHICH ONE IS HOLY.**

**THE EARTH SWALLOWED THEM. LORD-FIRE BURNED THEM.**

**“YOU KILLED THEM, MOSES.”**

Source parent: Numbers chapter 16, verses 1–50, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-NUM-016/job.json` and `source.usfm`.

Parent manuscript: `NUMBERS/015-ONE-LAW-ONE-STICK-JOE-WAIT-FOR-THE-CASE-DECISION.md`.

CrackFlix routing:

- new `S111-E001-NUM16 — EVERYONE IS HOLY / SELECT THE HOLY ONE`
- new `S112-E001-NUM16 — LORD KILLED THEM / YOU KILLED THEM`

## Causal foundation

```text
KORAH + DATHAN + ABIRAM + ON + 250 RENOWNED PRINCES
-> ACCUSE MOSES/AARON OF LIFTING THEMSELVES
-> CLAIM EVERY CONGREGATION MEMBER IS HOLY

MOSES: LORD WILL SHOW WHO IS HIS/HOLY/ALLOWED NEAR
-> KORAH COMPANY + AARON BRING INCENSE CENSERS
-> CLAIMANTS PERFORM EXCLUSIVE HOLY-SELECTION TEST

DATHAN/ABIRAM REFUSE SUMMONS
-> CALL EGYPT MILK/HONEY LAND
-> ACCUSE MOSES OF WILDERNESS DEATH + FAILED LAND DELIVERY + RULE

LORD PROPOSES WHOLE-CONGREGATION CONSUMPTION
-> MOSES/AARON: ONE MAN SIN / ALL ANGER?
-> TARGET CHANGES TO SPACE AROUND KORAH/DATHAN/ABIRAM TENTS
-> CONGREGATION WITHDRAWS

MOSES PREDICTS NEW EARTH-SWALLOW TEST
-> EARTH SPLITS/SWALLOWS HOUSEHOLDS/GOODS
-> LORD-FIRE DEVOURS 250 INCENSE MEN
-> CENSERS BECOME HOLY ALTAR COVERING + MEMORIAL

NEXT DAY CONGREGATION: YOU KILLED LORD'S PEOPLE
-> CLAIM CONFLICTS WITH RETAINED EARTH/LORD-FIRE EVENT CHAIN
-> LORD PROPOSES CONSUMPTION
-> MOSES ORDERS AARON'S AUTHORIZED ALTAR-FIRE INCENSE ATONEMENT
-> AARON STANDS BETWEEN DEAD/LIVING
-> PLAGUE STOPS AFTER 14,700 DEATHS
```

## Numbers 16:1–3 — EVERYONE IS HOLY

Korah son of Izhar, son of Kohath, son of Levi joins Dathan and Abiram sons of
Eliab and On son of Peleth, Reubenites. They rise before Moses with 250 renowned
congregational princes. The coalition says Moses and Aaron have taken too much
on themselves because:

> **“All the congregation are holy, everyone of them.”**

They ask why Moses and Aaron lift themselves above the LORD's assembly. This is
their accusation. No motive or hidden priesthood demand is inserted into it.

## Numbers 16:4–11 — SELECT WHICH HOLY JOE IS HOLY

Moses falls on his face and announces a next-morning test. The LORD will show:

- who belongs to him;
- who is holy;
- who may come near;
- whom the LORD chooses.

Korah and his company must put fire and incense in censers before the LORD.
Moses tells the Levites that their existing separation, tabernacle service and
congregational ministry are not small, asks whether they also seek priesthood,
and classifies their assembly as against the LORD. Those are Moses' statements
and question; they do not supply private motives.

The first crack closes when the people who have asserted universal holiness
accept and perform an exclusive test whose declared output is the selected holy
man allowed near:

```text
CLAIM: EVERY MEMBER IS HOLY
-> PERFORM: LORD WILL SELECT WHICH MAN IS HOLY / MAY APPROACH
-> UNIVERSAL STATE AND EXCLUSIVE OUTPUT REMAIN UNBRIDGED
```

That is `S111-E001-NUM16`.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes a coalition Joe's boil, licks his finger, walks away and does not look
back. The censer test continues unchanged.

## Numbers 16:12–19 — REFUSAL, ACCUSATIONS AND 252 CENSERS

Dathan and Abiram refuse Moses' summons. They call Egypt a land flowing with
milk and honey, accuse Moses of bringing them out to kill them in the
wilderness, say he makes himself prince, and point out that he has not delivered
fields or vineyards. They again refuse. Egypt's new label is their speech; it
does not rewrite the retained Egypt history.

Moses becomes angry, asks the LORD not to respect their offering, and says he
has taken no donkey and hurt none of them. Moses then orders Korah's company and
Aaron before the LORD. The 250 men plus Korah and Aaron each bring a censer;
every man places fire and incense in it. Korah assembles the congregation at the
Tent, where the LORD's glory appears. The exact glory form remains unresolved.

## Numbers 16:20–27 — WHOLE CONGREGATION PROPOSAL NARROWS

The LORD tells Moses and Aaron to separate so the congregation can be consumed
in a moment. They fall down and ask whether one man's sin should produce anger
against all the congregation.

The next instruction changes the executable boundary: the congregation must
withdraw from around the tents of Korah, Dathan and Abiram. Moses and Israel's
elders carry the warning; the people withdraw. Dathan and Abiram stand at their
tent doors with wives, sons and little ones.

The proposed whole-congregation consumption is therefore not executed at this
Moment. The question followed by a narrowed target does not close a
contradiction.

## Numbers 16:28–35 — THE GROUND PASSES MOSES' TEST

Moses specifies an observable test. Common death would mean the LORD did not
send him. A new event—ground opening, swallowing them and their belongings
alive into Sheol—will establish the stated alternative.

When Moses finishes speaking:

- the ground splits;
- the earth opens its mouth;
- households, Korah's men and goods are swallowed;
- they go down alive into Sheol;
- the earth closes;
- surrounding Israel flees at their cry;
- fire from the LORD devours the 250 incense offerers.

The source directly supplies this causal attribution. It does not provide a
physical mechanism, individual household roster or separate death count.

## Numbers 16:36–40 — SINFUL CENSERS BECOME HOLY HARDWARE

The LORD tells Moses that Eleazar must recover the censers and scatter their
fire away because the censers are holy. The censers belonged to men described
as sinning against their own lives, yet are holy because they were offered
before the LORD. Eleazar beats the bronze into altar-covering plates.

The covering becomes a memorial warning that a non-Aaron descendant must not
approach to burn incense and become like Korah's company. The text explicitly
distinguishes the sinful operators from the holy offered objects; it does not
claim the men became holy. No contradiction is added.

## Numbers 16:41–45 — LORD KILLED THEM / YOU KILLED THEM

The next day the congregation complains to Moses and Aaron:

> **“You have killed the LORD's people!”**

The retained previous-day chain says the earth opened immediately after Moses'
test statement and fire came out from the LORD. It never records Moses or Aaron
opening the earth, producing the fire or physically killing those recipients.

```text
OBSERVED NARRATIVE CAUSE: EARTH SWALLOWS + FIRE COMES FROM LORD
-> CONGREGATION ASSERTS MOSES/AARON KILLED THEM
-> CLAIM REASSIGNS COMPLETED CAUSATION WITHOUT A CARRIER
-> CRACK AT THE CONGREGATION'S SPOKEN MODEL
```

That is `S112-E001-NUM16`. It does not establish what the congregation privately
believes; it records only what they say.

> **CAPTAIN CRACKHEAD:** `YOINK!`

He pokes a complaining Joe's forehead boil, licks his finger, walks away and
does not look back. The cloud covers the Tent, glory appears, and the LORD again
proposes consuming the congregation while Moses and Aaron fall down.

## Numbers 16:46–50 — AARON RUNS INTO THE PLAGUE

Moses tells Aaron to take his censer, use fire from the altar, add incense,
carry it quickly into the congregation and make atonement because wrath and
plague have begun. Aaron obeys and runs into the assembly.

This incense act has explicit Aaron-priest, altar-fire, atonement and emergency
authority. It is not merged with the unauthorized 250-man offering.

Aaron stands between dead and living. The plague stops after 14,700 people die,
in addition to those who died in Korah's matter. Aaron returns to Moses at the
Tent door. No individual plague mechanism or victim roster is supplied.

## Character and world-ledger changes

- Korah, Dathan, Abiram, On and 250 princes enter the authority dispute;
- On is named only in the opening coalition and receives no later narrated act;
- `S111` retains universal-holiness speech versus performed exclusive selection;
- Dathan/Abiram's refusal and Egypt milk/honey claim remain attributed speech;
- whole-congregation destruction is proposed, then immediate target narrows;
- earth swallowing and LORD-fire deaths complete;
- censers become altar plates and a non-Aaron incense memorial;
- `S112` retains the congregation's unsupported reassignment of death causation;
- authorized Aaron atonement stops a plague after 14,700 additional deaths;
- every living human, animal, plant and face-like earth, fire, censer, cloud,
  altar or plague carrier is Joe-faced if shown;
- Captain is permanently boilless and causally useless;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD NUMBERS — HOLINESS LOAD BALANCER / 252-CENSER BENCHMARK`;
- coalition badge: `EVERYONE ROOT / 250 ADMIN ACCOUNTS`;
- test screen: `SELECTED HOLY JOE: CALCULATING...`;
- Dathan helpdesk: `WE WON'T COME UP / TICKET CLOSED BY CUSTOMER`;
- Egypt review: `MILK & HONEY — WOULD LEAVE AGAIN`;
- ground feature: `NEW THING™ / MOUTH ENABLED`;
- fire receipt: `250 INCENSE USERS REMOVED`;
- recycling label: `SINFUL OWNERS / HOLY BRONZE / BEAT FLAT`;
- CrackFlix: `S112 E001 — GOD DID IT / BLAME MOSES`;
- plague dashboard: `14,700 + KORAH MATTER / AARON BETWEEN STATES`;
- barcode: `CHB-NUM16-50-252CENSERS-EARTH-FIRE-14700-2CRACK-HELD`.

## FIR verification

- all 50 verse markers are represented in order;
- Korah/Dathan/Abiram/On genealogies and 250-prince count remain exact;
- universal-holiness claim and exclusive selection test are actor speech/action;
- Moses' priesthood question is not converted into private motive;
- Dathan/Abiram accusations remain speech, not adopted history;
- 250 censers plus Korah and Aaron participation remains distinguishable;
- whole-congregation consumption remains proposed and unexecuted at first;
- narrowed withdrawal boundary and family presence remain exact;
- Moses' announced earth test and its completed result retain order;
- earth swallowing and LORD-fire attribution are not reassigned by narration;
- holy censers are not used to call dead offerers holy;
- congregation's Moses/Aaron-killed claim closes only at its spoken model;
- Aaron's later incense has explicit priest/altar/atonement authority;
- 14,700 plague deaths remain additional to Korah-matter deaths;
- each Captain appearance follows a completed contradiction and changes nothing;
- publication remains held and unpublished.

Continuation required: Numbers 17 records twelve tribal rods, Aaron's budding
rod, its memorial placement and Israel's fear that approaching means death.
