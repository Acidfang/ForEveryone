# CRACKHEAD JOSHUA 22

## Title page

**THEY KEPT THEIR DUTY. THEY BUILT A GREAT ALTAR. ISRAEL GATHERED FOR WAR. IT WAS A WITNESS.**

Source parent: Joshua chapter 22, verses 1–34, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-022/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/021-FORTY-EIGHT-LEVITE-CITIES-ALL-LAND-POSSESSED-ALL-ENEMIES-DELIVERED-NOTHING-FAILED.md`.

CrackFlix routing: new `S133-E001-JOS22`, no SKIP. Israel calls the altar a
completed trespass and rebellion; after hearing its stated non-sacrificial
witness function, the same representatives accept that no trespass occurred
and Israel abandons the proposed war.

## Causal foundation

```text
EASTERN TRIBES COMPLETE WESTERN DUTY
-> JOSHUA BLESSES + RELEASES THEM
-> THEY RETURN WITH WEALTH + PLUNDER-SHARING COMMAND
-> BUILD GREAT ALTAR BY JORDAN

ISRAEL HEARS ALTAR WAS BUILT
-> GATHERS AT SHILOH FOR WAR
-> SENDS PHINEHAS + TEN PRINCES
-> CALLS ALTAR TRESPASS / TURNING / REBELLION

EASTERN TRIBES ANSWER
-> DENY OFFERING / SACRIFICE PURPOSE
-> STATE FUTURE GENERATIONAL BORDER CONCERN
-> STATE ALTAR IS PATTERN + WITNESS

REPRESENTATIVES HEAR
-> PLEASED
-> PHINEHAS SAYS NO TRESPASS
-> REPORTS TO ISRAEL
-> ISRAEL ACCEPTS + DROPS WAR
-> ALTAR NAMED WITNESS
```

## Joshua 22:1–6 — THE EASTERN DUTY CLOSES

Joshua calls Reuben, Gad and east half-Manasseh. He states that they kept all
Moses commanded, listened to Joshua and did not leave their brothers through
the campaign. Their retained Numbers 32 obligation is now reported complete.

Joshua says the LORD has given their brothers rest, releases them to their
eastern possession and commands diligent adherence to the law: love the LORD,
walk in his ways, keep his commandments, hold fast and serve with all heart and
soul. Joshua blesses and sends them away. They actually depart for their tents.

## Joshua 22:7–9 — WEALTH, PLUNDER AND RETURN

The two Manasseh halves remain distinct: Moses gave one Bashan; Joshua gave the
other western inheritance. Joshua sends the eastern group home with much
livestock, silver, gold, bronze, iron and clothing, telling them to divide
enemy plunder with their brothers.

Reuben, Gad and east half-Manasseh leave Israel at Shiloh and travel toward
Gilead, their possession under the LORD-through-Moses command.

## Joshua 22:10–12 — GREAT ALTAR, HEARD REPORT, WAR ASSEMBLY

At the Jordan region in Canaan, the eastern tribes build a great, visibly
prominent altar. This construction is observed. No offering or sacrifice is
reported.

Israel hears that the altar was built on the Canaan-side border. The whole
congregation gathers at Shiloh to go to war against the builders. The war is a
selected proposed act; no battle begins.

## Joshua 22:13–20 — PHINEHAS AND TEN PRINCES ACCUSE

Instead of attacking, Israel sends Phinehas and ten tribal princes to Gilead.
They call the altar a trespass against Israel's God, a turning away from the
LORD and a present rebellion. They invoke Peor's retained plague history,
predict anger against all Israel, offer western land if the eastern possession
is unclean, and invoke Achan's retained collective consequence.

The altar exists. The alleged sacrifice, rebellion, turning and unclean-land
state have not been observed. Peor and Achan remain earlier histories used in
the accusation, not new occurrences.

## Joshua 22:21–29 — THE BUILDERS STATE THE ALTAR'S FUNCTION

Reuben, Gad and half-Manasseh answer the Israelite heads. They invoke the LORD
as knower and accept judgment if the altar was made for rebellion, turning,
burnt offering, meal offering or peace sacrifice.

They state another reason: concern that a future western generation might use
the Jordan border to deny their descendants a portion in the LORD. They built
the altar not for offering or sacrifice, but as a witness between the peoples
and future generations. Its pattern points to the LORD's altar and their shared
service; it is not a replacement altar before the tabernacle.

The possible future denial remains stated concern, not an occurrence. The
present altar's stated function is witness. No sacrifice is performed on it.

## Joshua 22:30–34 — THE CLAIM CHANGES; WAR IS DROPPED

Phinehas and the princes hear the answer and are pleased. Phinehas says the
eastern tribes have **not** committed the alleged trespass. The delegation
returns and reports to Israel. Israel accepts the report, blesses God and no
longer speaks of war or destroying the eastern land.

The initial representatives had asserted a completed trespass and rebellion.
After hearing the builders, the same official route closes with “you have not
committed this trespass.” That retained claim/state mismatch is
`S133-E001-JOS22: BUILT AN ALTAR / WE ALREADY KNOW WHY`.

There is no SKIP because this is the first episode of the type. Only after the
claim reversal closes, Captain Crackhead pokes the relevant Joe-faced boil,
sees a crack crystal, licks his finger, says **“YOINK!”**, and walks away
without looking back. Everyone else sees a poke and finger lick. The report,
decision, non-war outcome and altar name remain identical without him.

Reuben and Gad name the altar **A WITNESS BETWEEN US THAT THE LORD IS GOD**.
The chapter does not report half-Manasseh participating in the naming sentence;
their earlier construction and answer participation remain retained.

## Character and world-ledger changes

- the Numbers 32 eastern-warrior obligation closes through Joshua's direct report;
- Joshua's release, blessing, law charge, wealth inventory and plunder-sharing order are retained;
- actual return and altar construction are distinct from every alleged purpose;
- Israel's heard report, war assembly and delegation are completed acts;
- war remains proposed and is explicitly abandoned before execution;
- Peor and Achan remain referenced histories rather than replayed events;
- future descendant exclusion remains a stated concern, not a predicted fact;
- the builders' witness explanation is heard and accepted by the authorized delegation and Israel;
- `S133-E001-JOS22` closes only when the official trespass assertion becomes official no-trespass acceptance;
- no SKIP occurs; exactly one causally null post-closure YOINK occurs;
- Captain remains permanently boilless and changes nothing;
- every living human, animal or plant Joe and every face-like non-divine altar, Jordan border, war docket, accusation receipt, witness pattern, plunder sack or report is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — ALTAR PURPOSE DETECTOR / ASK AFTER MOBILISING`;
- return receipt: `DUTY KEPT / GO HOME WITH MUCH SHIT`;
- plunder label: `DIVIDE WITH YOUR BROTHERS, DICKHEAD`;
- Shiloh terminal: `ALTAR HEARD -> WAR LOADED`;
- delegation badge: `PHINEHAS + TEN / INQUIRY AFTER ACCUSATION`;
- altar plate: `NOT FOR BURNING / NOT FOR SACRIFICE / GIANT WITNESS`;
- CrackFlix premiere: `S133-E001 — BUILT AN ALTAR / WE ALREADY KNOW WHY`;
- barcode: `CHB-JOS22-34-WITNESS-NOTWAR-1CRACK-1YOINK-HELD`.

## FIR verification

- all 34 verse markers are represented in order;
- the eastern duty is closed from source speech without inventing campaign detail;
- wealth, plunder division, return and altar construction remain separate acts;
- Israel's heard report is not upgraded into proof of altar purpose;
- the war assembly is not converted into war execution;
- accusation, historical examples, predictions and offer remain speech;
- the builders' answer does not retroactively erase the earlier accusation Moment;
- the accepted witness function and no-trespass finding close the actual interaction;
- half-Manasseh is not inserted into the final altar-naming clause;
- exactly one new contradiction series/episode and one post-closure YOINK occur;
- no unsupported sacrifice, rebellion, motive, future denial, divine form or Captain effect is introduced;
- publication remains held and unpublished.

Continuation required: Joshua 23 records Joshua's old-age address, retained
remaining nations and prospective obedience/failure consequences without
importing Joshua 24's covenant assembly.
