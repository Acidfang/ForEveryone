# CRACKHEAD JOSHUA 3

## Title page

**FOLLOW THE ARK. STAY BACK. FEET IN WATER. EVERYONE CROSSES DRY.**

Source parent: Joshua chapter 3, verses 1–17, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-003/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/002-SHE-HID-THEM-THEY-WENT-OUT-SCARLET-CORD-LAND-ALREADY-DELIVERED.md`.

CrackFlix routing: none. The chapter supplies a complete ordered process and outcome without an unresolved observable mismatch.

## Causal foundation

```text
SHITTIM -> JORDAN CAMP
-> THREE DAYS COMPLETE
-> OFFICERS: SEE ARK / FOLLOW / KEEP 2,000 CUBITS
-> JOSHUA: SANCTIFY / PRIESTS TAKE ARK
-> LORD: MAGNIFY JOSHUA / PRIESTS STAND IN JORDAN
-> JOSHUA RELAYS WATER-STOP AND TWELVE-MAN INSTRUCTION
-> PEOPLE DEPART TENTS
-> PRIEST FEET DIP AT FLOOD-STAGE EDGE
-> UPSTREAM WATER HEAPS / DOWNSTREAM CUT OFF
-> PRIESTS STAND ON DRY MIDDLE
-> ALL NATION CROSSES COMPLETELY ON DRY GROUND
```

## Joshua 3:1–6 — THREE DAYS, ARK DISTANCE, SANCTIFICATION

Joshua rises early; he and all Israel move from Shittim to the Jordan and camp
before crossing. After three days the officers pass through camp. They command
the people to follow when they see the Levitical priests bearing the covenant
ark, while keeping about two thousand cubits away because they have not passed
this way before.

Joshua commands self-sanctification for tomorrow's attributed wonders. He tells
the priests to take the ark and cross before the people; they take it and go
before them. The source does not specify the sanctification acts, so none are
invented.

## Joshua 3:7–13 — JOSHUA MAGNIFIED; CONTACT CONDITION DECLARED

The LORD tells Joshua that magnification before Israel begins today so the
people may know the LORD is with him as with Moses. Joshua must command the ark
priests to stand still in the Jordan. Joshua calls Israel to hear, says the
event will evidence the living God's presence and future displacement of seven
named peoples, identifies the ark going ahead, selects twelve men—one per
tribe—and states the contact condition: priest-foot soles resting in Jordan
water will cut off the descending water and make it stand in one heap.

The seven-people displacement remains future. The twelve men are selected here;
their stone task belongs to Joshua 4 and is not imported.

## Joshua 3:14–17 — THE CONTACT OCCURS; THE WHOLE NATION CROSSES

The people leave their tents with the ark priests ahead. At harvest-time flood
stage, the priests' feet dip at the water's edge. The upstream water stands and
rises in a heap far away at Adam beside Zarethan; water toward the Salt Sea is
cut off. The people cross near Jericho.

The ark-bearing priests stand firm on dry ground in the Jordan's middle while
all Israel crosses on dry ground until the entire nation has passed completely.
The crossing commanded in Joshua 1 is now an observed completed act. It does not
by itself complete possession, conquest, tribal inheritance, rest, or the east-
warrior return condition.

## Character and world-ledger changes

- the three-day timetable reaches its crossing act;
- ark-distance and priest-leading instructions are complete;
- priest-foot contact, water interruption and dry-ground crossing are complete;
- all Israel/the whole nation is stated to pass completely;
- priests remain standing in the Jordan at chapter close;
- twelve tribal men are selected but their later task is not supplied here;
- future displacement, possession, rest and return remain open;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every living human, animal or plant Joe and face-like non-divine ark, river, water heap, foot, distance marker, tent or map is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — FLOOD-STAGE CROSSING UNIT`;
- distance warning: `2,000 CUBITS / DON'T CROWD THE ARK`;
- trigger: `PRIEST FEET -> WATER STATE CHANGE`;
- upstream status: `HEAP @ ADAM / ZARETHAN`;
- downstream status: `CUT OFF -> SALT SEA`;
- progress: `ALL NATION: COMPLETELY OVER`;
- unresolved priest status: `STILL IN THE MIDDLE`;
- barcode: `CHB-JOS3-17-ARK-FEET-DRY-CROSSING-NOCRACK-HELD`.

## FIR verification

- all 17 verse markers are represented in order;
- command, condition, contact, water change and crossing remain sequential;
- no sanctification ritual or water mechanism is invented;
- the twelve selected men do not perform Joshua 4 acts early;
- completed crossing is not expanded into conquest or possession;
- priests' chapter-end location remains the Jordan middle;
- no unsupported contradiction machinery or divine form appears;
- publication remains held and unpublished.

Continuation required: Joshua 4 performs the twelve-stone memorial extraction,
completes the priests' exit and records the water's return.
