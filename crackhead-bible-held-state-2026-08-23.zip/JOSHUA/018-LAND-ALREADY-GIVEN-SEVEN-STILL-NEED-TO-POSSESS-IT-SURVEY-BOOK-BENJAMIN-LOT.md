# CRACKHEAD JOSHUA 18

## Title page

**LAND ALREADY GIVEN. SEVEN STILL NEED TO POSSESS IT. WRITE THE MAP. CAST THE LOT. BENJAMIN GOES BETWEEN.**

Source parent: Joshua chapter 18, verses 1–28, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-018/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/017-TEN-PARTS-FIVE-DAUGHTERS-COULDNT-DRIVE-THEM-OUT-STRONG-ENOUGH-FOR-FORCED-LABOR.md`.

CrackFlix routing: `S070-E010-JOS18`, with `SKIP -> S070-E009-JOS10`.

## Causal foundation

```text
ISRAEL ASSEMBLES AT SHILOH
-> TENT OF MEETING SET UP
-> LAND STATED SUBDUED
-> SEVEN TRIBES STILL HAVE NO DIVIDED INHERITANCE

LORD HAS GIVEN THE LAND
+ SEVEN TRIBES STILL NEGLECT TO GO POSSESS IT
-> COMPLETED DELIVERY ASSERTED BEFORE REQUIRED POSSESSION ACT
-> S070-E010-JOS18
-> SKIP -> S070-E009-JOS10
-> SKIP DOES NOTHING
-> ONE CAUSALLY NULL POST-CLOSURE YOINK

SEVEN TRIBES
-> THREE MEN EACH = TWENTY-ONE SURVEYORS
-> WALK / DESCRIBE / WRITE BY CITIES
-> SEVEN PORTIONS IN A BOOK
-> RETURN TO SHILOH
-> JOSHUA CASTS LOTS BEFORE LORD
-> LAND DIVIDED BY DIVISIONS

BENJAMIN LOT
-> BETWEEN JUDAH AND JOSEPH
-> NORTH / WEST / SOUTH / EAST BORDER CHAINS
-> TWELVE-CITY GROUP + VILLAGES
-> FOURTEEN-CITY GROUP + VILLAGES
```

## Joshua 18:1–3 — SHILOH, SUBDUED LAND, SEVEN UNPOSSESSED INHERITANCES

Israel's whole congregation assembles at Shiloh and sets up the Tent of
Meeting. The land is stated to be subdued before them. Seven tribes still have
not divided their inheritance.

Joshua asks how long they will neglect to go in and possess the land the LORD,
God of their fathers, **has given** them. The completed gift state is asserted
while the recipient possession act remains required and neglected.

This matches CrackFlix series S070: completed delivery stated before the
process required to make that state operational. Captain has heard it before.
The panel points **`SKIP -> S070-E009-JOS10`**. Captain presses SKIP, his eyes
glaze, and the world continues. Nothing skips. After the contradiction is fully
shown, Captain appears in his unexplained suit, pokes the boil, says only
**“YOINK!”**, licks his finger, and walks away without looking back. The survey
still has to happen.

“Subdued” is not silently rewritten as “allocated,” “occupied,” or “possessed.”
It remains a separate current state and does not create an additional crack.

## Joshua 18:4–10 — THREE PER TRIBE WRITE SEVEN PORTIONS IN A BOOK

Joshua orders each of the seven tribes to appoint three men: twenty-one
surveyors in the stated selection plan. They are to rise, walk through the
land, describe it according to inheritance, and return.

The land is to be divided into seven portions while Judah remains in its
southern borders and Joseph's house in its northern borders. The surveyors must
bring the seven-part description to Joshua, who will cast lots before the LORD.

Levi has no territorial portion because the LORD's priesthood is stated as
Levi's inheritance. Gad, Reuben and eastern half-Manasseh retain the
inheritances Moses gave east of the Jordan. Those classes and prior grants are
not reopened by the seven-part survey.

The men arise and go. Joshua repeats the walk, survey, return and lot sequence.
They pass through the land, write it by cities into seven portions in a book,
and return to Joshua's Shiloh camp. Joshua then casts lots before the LORD and
divides the land by Israel's divisions. The source completes the survey,
writing, return, lot and division acts; it does not name each surveyor or show
how the descriptions were measured.

## Joshua 18:11–20 — BENJAMIN'S BORDER BETWEEN JUDAH AND JOSEPH

Benjamin's family lot falls between Judah and Joseph.

The north border starts at the Jordan, rises north of Jericho through the hill
country and ends in Beth Aven's wilderness. It passes Luz/Bethel southward,
descends to Ataroth Addar by the mountain south of lower Beth Horon, turns on
the western quarter and ends at Kiriath Baal/Kiriath Jearim in Judah.

The south route begins at Kiriath Jearim's far end, reaches Nephtoah's spring,
descends by the mountain before Hinnom/Rephaim, passes Hinnom south of the
Jebusite to En Rogel, then runs through En Shemesh, Geliloth opposite Adummim,
Bohan's stone, the Arabah and Beth Hoglah to the Salt Sea's northern bay at the
Jordan's south end. The Jordan closes the east border.

These surrounding routes define Benjamin's family inheritance. Shared border
places retain their Judah/Joseph/Benjamin relations rather than being cloned or
merged.

## Joshua 18:21–28 — TWELVE CITIES, THEN FOURTEEN

Benjamin's first city group is Jericho, Beth Hoglah, Emek Keziz, Beth Arabah,
Zemaraim, Bethel, Avvim, Parah, Ophrah, Chephar Ammoni, Ophni and Geba: source
total **twelve cities with villages**.

The second group is Gibeon, Ramah, Beeroth, Mizpeh, Chephirah, Mozah, Rekem,
Irpeel, Taralah, Zelah, Eleph, Jebus/Jerusalem, Gibeath and Kiriath: source total
**fourteen cities with villages**.

The final statement closes Benjamin's family inheritance. City inclusion is an
allocation register; it does not manufacture capture, removal or building acts.

## Character and world-ledger changes

- Shiloh becomes the current congregation/Tent-of-Meeting assembly address;
- land-subdued, seven-unallocated and seven-unpossessed states remain typed separately;
- `S070-E010-JOS18` points SKIP to `S070-E009-JOS10`; SKIP changes nothing;
- exactly one causally null post-closure YOINK occurs;
- the 3×7 selection plan and twenty-one-surveyor derived count are retained;
- survey, seven-part book, return, lots and division are completed acts;
- unnamed surveyor identities and measurement method remain unresolved;
- Levi and east-Jordan recipient exceptions remain retained parents;
- Benjamin's four border chains and both exact city groups are retained;
- alternate place names and shared border addresses do not merge Roots;
- every living human, animal or plant Joe and every face-like non-divine tent, lot, book, pen, city, border, spring, stone, valley, mountain, sea or counter is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — ALREADY GIVEN / PLEASE GO GET IT`;
- CrackFlix card: `S070-E010 / SKIP -> S070-E009-JOS10`;
- survey staffing: `7 TRIBES × 3 JOES = 21 JOES`;
- field-book label: `WRITE LAND BY CITIES / SEVEN TABS`;
- Shiloh terminal: `CAST LOTS BEFORE LORD / DIVINE FORM NOT INCLUDED`;
- Benjamin map: `INSERT BETWEEN JUDAH AND JOSEPH`;
- city counters: `12 + 14`;
- barcode: `CHB-JOS18-28-S070E010-SKIP-E009-1YOINK-HELD`.

## FIR verification

- all 28 verse markers are represented in order;
- subdued, divided, given and possessed states remain distinct;
- S070 points to the exact prior episode and SKIP has no causal effect;
- exactly one post-closure Captain YOINK is causally null;
- the survey staffing relation derives twenty-one without inventing names;
- survey, written seven-part book, return, lot and division are completed in order;
- Levi/eastern allocations are not rerun;
- every Benjamin border point and both city lists/totals remain represented;
- allocation does not become conquest, construction or expulsion;
- no unsupported divine form, survey method or motive is supplied;
- publication remains held and unpublished.

Continuation required: Joshua 19 assigns Simeon within Judah, then Zebulun,
Issachar, Asher, Naphtali and Dan; records Dan's Leshem capture/rename; and
closes Joshua's Timnath Serah inheritance and the Eleazar/Joshua/heads
distribution at Shiloh.
