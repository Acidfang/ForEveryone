# CRACKHEAD JOSHUA 9

## Title page

**VERY FAR AWAY. THREE DAYS TO THEIR CITIES. OATH STAYS.**

Source parent: Joshua chapter 9, verses 1–27, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-009/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/008-AI-ALREADY-GIVEN-AMBUSH-FLEE-ON-PURPOSE-TURN-BACK-COPY-READ-EVERY-WORD.md`.

CrackFlix routing: new `S128-E001-JOS9`. No SKIP. One causally-null
post-closure `YOINK!` occurrence.

## Causal foundation

```text
REGIONAL KINGS GATHER TO FIGHT
-> GIBEON HEARS JERICHO + AI OUTCOMES
-> RUSE: OLD SACKS / TORN SKINS / PATCHED SANDALS / OLD CLOTHES / MOLDY BREAD
-> “WE CAME FROM A FAR COUNTRY”
-> ISRAEL: “WHAT IF YOU LIVE AMONG US?”
-> “VERY FAR” STORY + OBJECT DISPLAY
-> MEN SAMPLE PROVISIONS / DO NOT ASK LORD
-> PEACE COVENANT + LIFE OATH
-> THREE DAYS LATER: THEY ARE NEIGHBORS
-> ISRAEL ARRIVES AT FOUR CITIES ON THIRD DAY
-> S128-E001 CLOSES / YOINK
-> OATH PREVENTS ATTACK / CONGREGATION MURMURS
-> PRINCES RETAIN LIFE OATH
-> JOSHUA ADDRESSES DECEPTION
-> GIBEONITES STATE FEAR/COMMAND REPORT
-> JOSHUA PROTECTS THEM FROM KILLING
-> WOOD-CUTTER / WATER-DRAWER ASSIGNMENT
```

## Joshua 9:1–5 — ONE GROUP FIGHTS, GIBEON BUILDS A JOURNEY

Kings from the hill country, lowland and great-sea shore hear and gather with
one accord to fight Joshua and Israel. Gibeon's inhabitants hear what happened
to Jericho and Ai and take a different observable route: the narrator calls it
a ruse. They load old sacks, old torn and repaired wineskins, wear old patched
sandals and clothes, and carry dry moldy bread.

The objects are real objects in their displayed states. Their claimed history
and distance are not thereby verified.

## Joshua 9:6–15 — THE RIGHT QUESTION, THE PROVISIONS, NO COUNSEL, OATH

At Gilgal the Gibeonites say they came from a far country and request a
covenant. Israel asks the exact relevant question: what if they live among
Israel? Joshua asks who they are and where they come from.

They answer “a very far country,” cite reports of Egypt, Sihon and Og, attribute
the mission to their elders, and present the bread, skins, clothes and sandals
as results of a very long journey. The men sample the provisions and do not ask
counsel from the LORD's mouth. Joshua makes peace and a covenant to let them
live; the congregation's princes swear to them.

Sampling the provisions is an observed act. It does not establish the asserted
origin, packing time, route or distance.

## Joshua 9:16–18 — THREE DAYS TO “VERY FAR AWAY”

At the end of three days after the covenant, Israel hears the people are
neighbors living among them. Israel travels and reaches their cities on the
third day: Gibeon, Chephirah, Beeroth and Kiriath Jearim.

The completed travel and named local residence close `S128-E001-JOS9`:

> **VERY FAR AWAY. THREE DAYS TO THEIR CITIES.**

No alternate starting point, special meaning of “far,” time gap or city move is
supplied. Captain says **“YOINK!”**, pokes, licks and leaves. Israel still does
not strike them because the princes swore by the LORD. The congregation murmurs
against the princes.

## Joshua 9:19–21 — THE DISCOVERED LIE DOES NOT DELETE THE OATH

The princes state that they swore by the LORD and may not touch the Gibeonites.
They choose to let them live to avoid wrath because of the oath. The people
become wood cutters and water drawers for the congregation.

This is a changed consequence after discovery, not retrospective truth for the
distance claim. The oath Moment and the later discovery Moment both remain.

## Joshua 9:22–27 — DECEPTION ADDRESSED, LIFE RETAINED, SERVICE ASSIGNED

Joshua asks why they deceived Israel by saying they were very far away while
living among them. He assigns an enduring servant class: wood cutters and water
drawers for God's house. The Gibeonites answer that they were told of the LORD's
command through Moses to give Israel the land and destroy its inhabitants, were
afraid for their lives and performed the ruse. Their fear and purpose are
retained as their own later statement, not invented motive.

They place themselves in Joshua's hand. Joshua delivers them from Israel's hand
so they are not killed. That day he makes them wood cutters and water drawers
for the congregation and the LORD's altar at the place to be chosen, continuing
to the narrator's “this day.” The future chosen place is not identified here.

## Character and world-ledger changes

- regional kings' fight coalition is formed but no battle occurs here;
- the Gibeonite ruse, staged carriers and false distance claims complete;
- Israel samples provisions, does not ask counsel, and swears a life covenant;
- `S128-E001-JOS9` closes only when neighboring residence and third-day arrival are observed;
- one causally-null Captain `YOINK!`; no SKIP because this distance contradiction is new;
- oath retention, congregation murmuring and servant assignment complete;
- fear and purpose remain attributed to the Gibeonites' own answer;
- every living human, animal or plant Joe and face-like non-divine bread, sack, skin, sandal, garment, city, axe, wood, bucket, water or altar carrier is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — DISTANCE VERIFICATION BY SANDAL`;
- travel evidence kit: `OLD / TORN / PATCHED / MOLDY`;
- inquiry receipt: `PROVISIONS SAMPLED / LORD NOT ASKED`;
- CrackFlix: `S128-E001 — VERY FAR / THIRD DAY`;
- city list: `GIBEON / CHEPHIRAH / BEEROTH / KIRIATH JEARIM`;
- oath lock: `DISCOVERY DOES NOT UNSWEAR`;
- job allocation: `WOOD + WATER / ALTAR ADDRESS PENDING`;
- barcode: `CHB-JOS9-27-S128-GIBEON-OATH-1YOINK-NOSKIP-HELD`.

## FIR verification

- all 27 verse markers are represented in order;
- staged object state remains distinct from asserted object history;
- Israel's local-residence question precedes the unverified acceptance;
- sampling and failure to ask counsel are retained without invented decision motive;
- the contradiction closes only after neighbor report and third-day city arrival;
- S128 is new, so SKIP is absent;
- Captain occurs after closure and changes nothing;
- covenant, discovery, non-attack and service assignment remain separate Moments;
- Gibeonite fear is attributed speech rather than inferred motive;
- publication remains held and unpublished.

Continuation required: Joshua 10 observes the five-king coalition, Gibeon rescue,
hail, sun/moon speech, cave confinement, executions and southern campaign.
