# CRACKHEAD JOSHUA 10

## Title page

**FIVE ARMIES ALREADY DELIVERED. SUN WAITS. DON'T LET THEM IN. REMNANT GOT IN.**

Source parent: Joshua chapter 10, verses 1–43, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-010/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/009-VERY-FAR-AWAY-THREE-DAYS-TO-THEIR-CITIES-OATH-STAYS.md`.

CrackFlix routing: `S070-E008-JOS10` with `SKIP -> S070-E007-JOS8`;
`S070-E009-JOS10` with `SKIP -> S070-E008-JOS10`; new
`S129-E001-JOS10`. Three distinct causally-null post-closure `YOINK!`
occurrences.

## Causal foundation

```text
FIVE KINGS ATTACK GIBEON FOR PEACE WITH ISRAEL
-> GIBEON REQUESTS COVENANT HELP
-> JOSHUA + WHOLE ARMY LEAVE GILGAL
-> LORD: ALL FIVE ARMIES ALREADY DELIVERED
-> SKIP S070-E007 / YOINK
-> NIGHT MARCH / CONFUSION / SLAUGHTER / PURSUIT
-> MORE DIE BY HAILSTONES THAN ISRAEL'S SWORD
-> JOSHUA SPEAKS TO SUN + MOON
-> SUN/MOON STAY UNTIL VENGEANCE / UNIQUE-DAY CLAIM
-> FIVE KINGS FOUND IN CAVE / SEALED + GUARDED
-> PURSUIT ORDER: DO NOT LET ENEMIES ENTER CITIES
-> LORD HAS DELIVERED THEM
-> SKIP S070-E008 / YOINK
-> GREAT SLAUGHTER / REMNANT ENTERS FORTIFIED CITIES
-> S129-E001 / YOINK
-> FIVE KINGS REMOVED / NECK ACT / KILLED / HANGED / RETURNED TO CAVE
-> MAKKEDAH -> LIBNAH -> LACHISH (+ GEZER) -> EGLON -> HEBRON -> DEBIR
-> SOUTHERN CAMPAIGN SUMMARY
-> RETURN TO GILGAL
```

## Joshua 10:1–9 — GIBEON CALLS; THE ARMIES ARE “DELIVERED” BEFORE BATTLE

Jerusalem's king hears of Ai's destruction and Gibeon's peace with Israel. He
calls the kings of Hebron, Jarmuth, Lachish and Eglon to strike Gibeon. The five
kings and armies encamp and make war. Gibeon sends from the retained covenant
relationship: do not abandon your servants; come quickly, save and help.

Joshua leaves Gilgal with the whole army and mighty warriors. Before the all-
night march ends, confusion, battle, pursuit, hail or any king capture, the LORD
says all the enemies have been delivered into Joshua's hands and none will
stand.

> **SKIP -> S070-E007-JOS8 — AI ALREADY GIVEN BEFORE THE AMBUSH**

`S070-E008-JOS10` closes. Captain says **“YOINK!”**, pokes, licks and leaves.
Joshua still marches all night and arrives suddenly.

## Joshua 10:10–14 — SWORD, HAILSTONES, SUN AND MOON

The LORD confuses the armies; the source attributes great slaughter, chase and
striking through the named route. During flight, the LORD hurls great stones
from the sky. More die from hailstones than from Israel's sword.

Joshua speaks to the LORD and, before Israel, tells the sun to stand still over
Gibeon and the moon to stop over Aijalon. The source says the sun stands and the
moon stays until the nation avenges itself, cites the book of Jashar, and says
the sun does not hurry down for about a whole day. It calls the day unmatched
before or after because the LORD listened to a man's voice and fought for
Israel.

These are source-stated occurrences in this universe. No imported astronomy,
mechanism, orbit, clock conversion, divine anatomy or metaphor is supplied.

## Joshua 10:15–21 — CAVE HOLD, SECOND EARLY DELIVERY, REMNANT GETS IN

Verse 15 states Joshua and Israel return to Gilgal. The next narrated segment
states the five kings fled and hid at Makkedah, were found, and were sealed in
the cave under guard. The source does not fix whether their flight predates the
summary return or narrate a new Gilgal departure; chronology remains unresolved
without manufacturing a movement contradiction.

Joshua orders the main force not to stay at the cave: pursue, attack the rear,
and **do not allow them to enter their cities**, because the LORD **has
delivered** them. The delivered assertion occurs while the pursuit and stated
prevention act remain unfinished:

> **SKIP -> S070-E008-JOS10 — FIVE ARMIES ALREADY DELIVERED BEFORE BATTLE**

`S070-E009-JOS10` closes. Captain performs a second **“YOINK!”** and changes
nothing.

The next completed state says the great slaughter finishes while a remnant
enters fortified cities. The required prevention and observed result do not
agree:

> **DON'T LET THEM ENTER THEIR CITIES. THE REMNANT ENTERED FORTIFIED CITIES.**

New `S129-E001-JOS10` closes. Captain performs a third **“YOINK!”**. The people
return safely to Joshua's camp at Makkedah; nobody moves a tongue against them.

## Joshua 10:22–27 — FIVE KINGS OUT, DOWN, DEAD, UP, DOWN, BACK IN

Joshua opens the cave and has the five named kings brought out. Chiefs place
feet on their necks. Joshua gives courage speech and a future enemy comparison.
He then strikes and kills the kings, hangs them on five trees until evening,
has them removed at sundown, throws them back into the cave and seals it with
great stones. Capture, confinement, removal, neck act, death, hanging, removal
and cave return stay sequential.

## Joshua 10:28–39 — CITY-BY-CITY SOUTHERN CAMPAIGN

The campaign proceeds through separately retained city states:

- Makkedah is taken that day, including its king;
- Libnah is fought, delivered and taken;
- Lachish is encamped against and taken on the second day;
- Gezer's king Horam comes to help Lachish and is defeated with his people;
- Eglon is taken that day;
- Hebron, its king and cities are taken;
- Debir, its king and cities are taken.

Repeated “as he had done” clauses preserve comparison without merging cities,
kings, days or battles into one occurrence.

## Joshua 10:40–43 — CAMPAIGN SUMMARY AND RETURN

The source summarizes hill country, South, lowland, slopes and kings, attributes
the commanded destruction to the LORD, gives the Kadesh Barnea–Gaza and Goshen–
Gibeon extent, and says all these kings and land were taken at one time because
the LORD fought for Israel. Joshua and all Israel return to Gilgal.

“One time” remains the source's summary phrase. It does not erase the stated
city sequence or Lachish's second-day timestamp.

## Character and world-ledger changes

- Joshua executes Gibeon's covenant rescue request;
- `S070-E008` and `S070-E009` retain two early-delivery recurrences with exact backward SKIPs;
- `S129-E001` retains the no-entry requirement / remnant-entry result;
- three causally-null Captain `YOINK!` occurrences;
- hailstone and sun/moon occurrences remain source-stated with mechanism unresolved;
- five kings' confinement, execution, hanging and cave return complete;
- the southern city campaign remains a sequence, not a merged conquest blob;
- every living human, animal or plant Joe and face-like non-divine sun, moon, hailstone, sword, cave, tree, gate, city or stone carrier is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — COVENANT CUSTOMER SUPPORT`;
- CrackFlix A: `SKIP -> S070-E007-JOS8`;
- weather receipt: `HAIL > SWORD`;
- sky controls: `SUN: WAIT / MOON: ALSO WAIT`;
- cave ticket: `5 KINGS / HOLD, PROCESS LATER`;
- CrackFlix B: `SKIP -> S070-E008-JOS10`;
- CrackFlix C: `S129 — CITY ENTRY PREVENTION: FAILED`;
- campaign route: `MAK > LIB > LAC (+GEZ) > EGL > HEB > DEB`;
- barcode: `CHB-JOS10-43-S070X2-S129-3YOINK-HELD`.

## FIR verification

- all 43 verse markers are represented in order;
- two completed-delivery assertions close before their remaining required acts;
- both S070 SKIPs point to exact prior episodes and remain noncausal;
- the no-entry order and remnant-entry outcome create a separate series;
- three Captain occurrences follow three closures and change nothing;
- sun/moon/hail claims remain source occurrences without imported physics;
- verse-15 return chronology remains unresolved rather than invented;
- cave states and city campaign states remain sequential and distinct;
- publication remains held and unpublished.

Continuation required: Joshua 11 observes the northern coalition, waters of
Merom attack, Hazor burning, city outcomes, Anakim removal and rest claim.
