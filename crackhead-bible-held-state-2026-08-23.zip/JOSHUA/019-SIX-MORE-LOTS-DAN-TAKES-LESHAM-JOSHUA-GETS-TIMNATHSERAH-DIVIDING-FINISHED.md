# CRACKHEAD JOSHUA 19

## Title page

**SIX MORE LOTS. JUDAH HAD TOO MUCH. DAN TAKES LESHEM AND NAMES IT DAN. JOSHUA GETS HIS CITY LAST. DIVIDING FINISHED.**

Source parent: Joshua chapter 19, verses 1–51, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-019/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/018-LAND-ALREADY-GIVEN-SEVEN-STILL-NEED-TO-POSSESS-IT-SURVEY-BOOK-BENJAMIN-LOT.md`.

CrackFlix routing: none. Every changed allocation or territorial extension in
this chapter has an explicit source route.

## Causal foundation

```text
SECOND LOT: SIMEON
-> INSIDE JUDAH
-> 13-CITY GROUP + 4-CITY GROUP + SURROUNDING VILLAGES
-> BECAUSE JUDAH PORTION WAS TOO MUCH

THIRD LOT: ZEBULUN
-> BORDER ROUTE + SOURCE 12-CITY TOTAL
FOURTH LOT: ISSACHAR
-> BORDER/CITY ROUTE + SOURCE 16-CITY TOTAL
FIFTH LOT: ASHER
-> BORDER/CITY ROUTE + SOURCE 22-CITY TOTAL
SIXTH LOT: NAPHTALI
-> BORDER/CITY ROUTE + SOURCE 19-CITY TOTAL
SEVENTH LOT: DAN
-> ORIGINAL BORDER/CITY ROUTE
-> BORDER GOES BEYOND
-> FIGHT LESHEM
-> TAKE / STRIKE / POSSESS / LIVE
-> RENAME LESHEM AS DAN

ALL LAND DISTRIBUTION FINISHED
-> ISRAEL GIVES JOSHUA REQUESTED TIMNATHSERAH
-> JOSHUA BUILDS + LIVES THERE
-> ELEAZAR + JOSHUA + HOUSE HEADS
-> SHILOH / TENT DOOR / BEFORE LORD / LOT
-> DIVIDING FINISHED
```

## Joshua 19:1–9 — SECOND LOT: SIMEON INSIDE JUDAH

Simeon's family inheritance falls inside Judah's inheritance. The first group
is Beersheba/Sheba, Moladah, Hazar Shual, Balah, Ezem, Eltolad, Bethul, Hormah,
Ziklag, Beth Marcaboth, Hazar Susah, Beth Lebaoth and Sharuhen: source total
**thirteen cities with villages**.

The second group is Ain, Rimmon, Ether and Ashan: **four cities with villages**,
plus the surrounding villages through Baalath Beer/Ramah of the South.

The source supplies the nesting bridge: Judah's portion was too much for Judah,
so Simeon inherits in its middle. This is a stated redistribution relation, not
a contradiction or a silent overwrite of Judah's earlier Root.

## Joshua 19:10–16 — THIRD LOT: ZEBULUN

Zebulun's family border starts at Sarid, runs west through Maralah and
Dabbesheth to the brook before Jokneam, then turns east through Chisloth Tabor,
Daberath, Japhia, Gath Hepher, Ethkazin and Rimmon toward Neah. It turns north
to Hannathon and ends at Iphtah El's valley.

Kattath, Nahalal, Shimron, Idalah and Bethlehem close the visible city names;
the source states **twelve cities with villages**. Border points may participate
in that total, but the chapter does not type the exact membership. Both the
route and source total remain intact without invented count repair.

## Joshua 19:17–23 — FOURTH LOT: ISSACHAR

Issachar's family inheritance lists Jezreel, Chesulloth, Shunem, Hapharaim,
Shion, Anaharath, Rabbith, Kishion, Ebez, Remeth, Engannim, En Haddah and Beth
Pazzez. The border reaches Tabor, Shahazumah and Beth Shemesh and ends at the
Jordan: source total **sixteen cities with villages**.

The list is an inheritance register. It does not replay earlier battles or
invent new residence changes.

## Joshua 19:24–31 — FIFTH LOT: ASHER

Asher's family border includes Helkath, Hali, Beten, Achshaph, Allammelech,
Amad and Mishal, reaches Carmel and Shihorlibnath, turns east through Beth Dagon
to Zebulun and Iphtah El, then Beth Emek, Neiel and Cabul. It continues through
Ebron, Rehob, Hammon and Kanah to great Sidon, turns through Ramah, fortified
Tyre and Hosah, and ends at the sea by Achzib. Ummah, Aphek and Rehob close the
named register: source total **twenty-two cities with villages**.

Repeated Rehob tokens are retained at their source positions; no same-name
identity merge is forced without a supplied relation.

## Joshua 19:32–39 — SIXTH LOT: NAPHTALI

Naphtali's family border runs from Heleph and Zaanannim's oak through
Adami-nekeb, Jabneel and Lakkum to the Jordan, then west through Aznoth Tabor
and Hukkok. It reaches Zebulun southward, Asher westward and Judah at the Jordan
toward sunrise.

The fortified-city register is Ziddim, Zer, Hammath, Rakkath, Chinnereth,
Adamah, Ramah, Hazor, Kedesh, Edrei, En Hazor, Iron, Migdal El, Horem, Beth
Anath and Beth Shemesh: source total **nineteen cities with villages**. The
source total is preserved without manufacturing unnamed entries.

## Joshua 19:40–48 — SEVENTH LOT: DAN, THEN LESHEM BECOMES DAN

Dan's original family border names Zorah, Eshtaol, Irshemesh, Shaalabbin,
Aijalon, Ithlah, Elon, Timnah, Ekron, Eltekeh, Gibbethon, Baalath, Jehud, Bene
Berak, Gath Rimmon, Me Jarkon and Rakkon, opposite Joppa.

Dan's border then extends beyond that register through an explicit causal
chain. Dan goes up, fights Leshem, takes it, strikes it by sword, possesses it,
lives there, and renames Leshem **Dan** after the forefather Dan. Former and new
city names remain one transitioned place identity. The action is completed;
missing battle detail and prior Leshem inhabitants' individual outcomes remain
unresolved.

## Joshua 19:49–51 — JOSHUA RECEIVES LAST; DIVIDING FINISHES

After Israel finishes distributing land by borders, Israel gives Joshua son of
Nun an inheritance among them. Under the stated LORD command, they give him the
city he requested: Timnathserah in Ephraim's hill country. Joshua builds the
city and lives there.

Eleazar, Joshua and the fathers'-house heads are the retained distributors. The
inheritances are distributed by lot at Shiloh before the LORD, at the Tent of
Meeting door. The chapter then states that they finished dividing the land.
The text supplies no divine form or lot mechanism.

## Character and world-ledger changes

- Simeon's Judah-embedded inheritance retains its explicit too-large-portion bridge;
- Zebulun, Issachar, Asher, Naphtali and Dan retain distinct ordered lot/border/city registers;
- every source-stated city subtotal is preserved without inventing hidden membership;
- repeated and alternate place names remain joined only where the source supplies a relation;
- Dan's Leshem battle, capture, sword strike, possession, residence and rename are completed in order;
- Leshem→Dan is one place transition and does not create a second historical city;
- Timnathserah is given to Joshua, then built and inhabited by him;
- Eleazar/Joshua/house-head Shiloh distribution closes as finished;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every living human, animal or plant Joe and every face-like non-divine lot, city, village, border, sea, brook, oak, sword, Tent door, nameplate or counter is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — LOTS 2 THROUGH 7 / JOSHUA LAST`;
- Simeon insert: `JUDAH HAD TOO MUCH / SHARE THE MIDDLE`;
- source counters: `13+4 / 12 / 16 / 22 / 19 / DAN`;
- Dan expansion ticket: `FIGHT -> TAKE -> STRIKE -> POSSESS -> LIVE -> RENAME`;
- rename plate: `LESHem WAS / DAN IS`;
- Joshua receipt: `TIMNATHSERAH / ASKED / GIVEN / BUILT / LIVED`;
- Shiloh terminal: `DIVIDING FINISHED`;
- barcode: `CHB-JOS19-51-SIXLOTS-LESHAMTODAN-DIVIDINGDONE-HELD`.

## FIR verification

- all 51 verse markers are represented in order;
- lots two through seven retain their correct tribe and sequence;
- Simeon's embedded Judah allocation preserves its supplied causal bridge;
- every named route/city block and every source-stated subtotal remains represented;
- unresolved subtotal membership is not silently repaired;
- Dan's Leshem action chain is complete and ordered;
- the Leshem-to-Dan rename preserves one transitioned identity;
- Joshua's gift/build/residence chain remains after general distribution completion;
- Shiloh distributors, lot boundary and Tent-door address remain retained;
- allocation does not manufacture conquest outside the explicit Leshem event;
- no unsupported divine form, motive or missing battle detail is supplied;
- publication remains held and unpublished.

Continuation required: Joshua 20 installs the six refuge-city system under
LORD speech, including accidental-killer speech at the gate, temporary asylum,
congregational judgment, avenger protection and high-priest-death return.
