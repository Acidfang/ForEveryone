# CRACKHEAD JOSHUA 16

## Title page

**JOSEPH GETS A LOT. EPHRAIM GETS A BORDER. GEZER STAYS AND DOES FORCED LABOR.**

Source parent: Joshua chapter 16, verses 1–10, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-016/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/015-NONE-LEFT-IN-HEBRON-CALEB-DRIVES-THREE-OUT-JUDAH-BORDERS-CITIES-AND-SPRINGS.md`.

CrackFlix routing: none. Inheritance, non-expulsion, continued residence and
forced labor coexist in the observed chapter without a stated inability or
failed required result.

## Causal foundation

```text
JOSEPH LOT
-> JORDAN AT JERICHO / JERICHO WATERS
-> WILDERNESS / HILL COUNTRY / BETHEL-LUZ
-> ARCHITE BORDER / ATAROTH
-> JAPHLETITE BORDER / LOWER BETH HORON / GEZER
-> SEA

JOSEPH CHILDREN
-> MANASSEH + EPHRAIM TAKE INHERITANCE

EPHRAIM FAMILY BORDER
-> ATAROTH ADDAR / UPPER BETH HORON
-> MICHMETHATH / TAANATH SHILOH / JANOAH
-> ATAROTH / NAARAH / JERICHO / JORDAN
-> TAPPUAH / KANAH BROOK / SEA
-> SET-APART CITIES INSIDE MANASSEH + VILLAGES

GEZER CANAANITES
-> NOT DRIVEN OUT
-> CONTINUE TO DWELL IN EPHRAIM
-> BECOME FORCED-LABOR SERVANTS
```

## Joshua 16:1–4 — THE JOSEPH LOT

Joseph's lot begins at the Jordan by Jericho and its eastern waters, climbs
through the wilderness and hill country to Bethel, runs from Bethel to Luz,
passes the Archite border to Ataroth, descends west through the Japhletite
border and lower Beth Horon to Gezer, and ends at the sea.

Manasseh and Ephraim, the two children-of-Joseph tribal identities, take their
inheritance. The shared Joseph route and the later Ephraim detail remain nested
records rather than competing boundaries.

## Joshua 16:5–9 — EPHRAIM'S FAMILY BORDER AND EMBEDDED CITIES

Ephraim's eastern family border runs from Ataroth Addar to upper Beth Horon. It
goes west at Michmethath, turns east to Taanath Shiloh and passes east of
Janoah. It descends through Ataroth and Naarah, reaches Jericho and exits at the
Jordan.

From Tappuah the border runs west to Kanah's brook and ends at the sea. This is
Ephraim's family inheritance. Ephraim also receives cities set apart inside
Manasseh's inheritance, with their villages. Those embedded cities do not
erase Manasseh's surrounding Root or become evidence of an unstated transfer
of every intervening place.

## Joshua 16:10 — GEZER REMAINS, THEN WORKS

Ephraim does not drive out the Canaanites living in Gezer. The Canaanites
continue dwelling in Ephraim's territory to the source's “this day,” and they
become servants performing forced labor.

The chapter says **did not drive out**, not **could not drive out**. It also
does not state that inheritance requires every resident's removal. Continued
residence and forced labor therefore remain a completed power relation without
an invented contradiction, motive, consent state, labor terms or causal bridge.
Joshua 17 may add a stronger claim; it is not imported early.

## Character and world-ledger changes

- Joseph's shared lot route is retained from Jericho to the sea;
- Manasseh and Ephraim retain their two-tribe identity and both take inheritance;
- Ephraim's border retains every named route point in source order;
- Ephraim's cities inside Manasseh remain embedded allocations, not a Root merge;
- Gezer's Canaanites are not expelled, remain resident and become forced-labor servants;
- no motive, consent, labor condition, expulsion inability or required-removal rule is invented;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every living human, animal or plant Joe and every face-like non-divine lot, border, city, river, sea, hill, brook, village or labor ticket is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — JOSEPH LOT / EPHRAIM INSERT`;
- route printer: `JERICHO -> BETHEL -> GEZER -> SEA`;
- nested-city warning: `INSIDE MANASSEH / STILL EPHRAIM / DON'T MERGE THE MAP`;
- Gezer status card: `RESIDENT / NOT EXPELLED / FORCED LABOR`;
- evidence warning: `DIDN'T IS NOT COULDN'T`;
- barcode: `CHB-JOS16-10-EPHRAIM-GEZER-NOCRACK-HELD`.

## FIR verification

- all 10 verse markers are represented in order;
- Joseph's shared lot and Ephraim's detailed border remain distinct layers;
- every named border point and endpoint remains represented;
- Ephraim's embedded Manasseh-territory cities preserve both tribal Roots;
- non-expulsion, residence and forced labor remain completed source states;
- “did not” is not rewritten as “could not”;
- no unsupported contradiction, motive, consent, labor mechanism or conquest is introduced;
- no unsupported divine form appears;
- publication remains held and unpublished.

Continuation required: Joshua 17 expands Manasseh's family allocations,
resolves the Zelophehad daughters' inheritance claim, retains Canaanite
residence/forced labor, and gives Joseph's house a second-lot complaint,
forest-clearing answer and iron-chariot dispute.
