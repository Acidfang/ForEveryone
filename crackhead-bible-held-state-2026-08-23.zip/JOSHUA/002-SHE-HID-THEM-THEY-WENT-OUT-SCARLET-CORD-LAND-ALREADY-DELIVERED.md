# CRACKHEAD JOSHUA 2

## Title page

**SHE HID THEM. “THEY WENT OUT.” SCARLET CORD. THE LAND IS ALREADY DELIVERED.**

Source parent: Joshua chapter 2, verses 1–24, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-002/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/001-MOSES-DEAD-JOSHUA-GO-THREE-DAYS-WE-LISTENED-IN-ALL-THINGS.md`.

CrackFlix routing: new `S126-E001-JOS2`; recurring `S070-E004-JOS2` with `SKIP -> S070-E003-NUM32`. Two distinct causally-null post-closure Captain `YOINK!` occurrences.

## Causal foundation

```text
JOSHUA SECRETLY SENDS TWO SPIES
-> SPIES ENTER RAHAB'S HOUSE
-> KING SENDS: BRING THEM OUT
-> RAHAB HIDES THEM ON ROOF
-> RAHAB SAYS THEY WENT OUT / SENDS PURSUERS AWAY
-> S126-E001 + YOINK
-> RAHAB REPORTS FEAR/HISTORY + REQUESTS HOUSEHOLD LIFE
-> SPIES GIVE CONDITIONAL OATH
-> CORD ESCAPE + SCARLET WINDOW LINE + THREE-DAY HIDE
-> SPIES RETURN
-> “ALL LAND HAS BEEN DELIVERED INTO OUR HANDS” BEFORE CROSSING
-> SKIP -> S070-E003-NUM32 + YOINK
```

## Joshua 2:1–7 — HIDDEN HERE; “THEY WENT OUT”

Joshua secretly sends two unnamed men from Shittim to view the land and
Jericho. They enter the house of Rahab, identified by name and occupation, and
sleep there. The king receives a report, sends to Rahab and orders the men out.

Rahab takes and hides both men. She confirms they came, says she did not know
their origin, says they went out near gate-closing, says she does not know where
they went, and tells the king's men to pursue quickly. The source then locates
the spies under ordered flax on her roof. The pursuers leave toward the Jordan
fords and the gate closes.

The observable hide plus went-out claim closes `S126-E001-JOS2: I HID THEM
HERE / THEY WENT OUT THAT WAY`. No motive or moral verdict is supplied.
Captain appears after closure, says **“YOINK!”**, pokes, licks his finger and
walks away. The pursuit proceeds unchanged.

## Joshua 2:8–14 — HEARD HISTORY, HOUSEHOLD REQUEST, CONDITIONAL OATH

Rahab tells the spies that the LORD has given the land, fear has fallen, and
inhabitants melt. She attributes this to reports of the Red Sea and the defeats
of Sihon and Og, then states the LORD is God above and beneath. These are Rahab's
knowledge, report and belief claims; earlier events remain history pointers.

She requests reciprocal kindness, a true sign, and life for named family
classes and possessions. The spies answer with their lives for hers if she does
not disclose their business, conditional on the LORD giving the land. No later
rescue or destruction is imported.

## Joshua 2:15–21 — CORD DOWN, THREE CONDITIONS, SCARLET LINE UP

Rahab lowers the spies by a cord through her wall-house window and directs them
to hide in the mountain for three days. The spies state the oath conditions:
scarlet line in that window, household gathered inside, outside blood assigned
outside their responsibility, inside harm assigned to them, and disclosure
releasing the oath. Rahab accepts, sends them away and ties the scarlet line.

The ordinary escape cord and scarlet identifying line remain distinct source
objects. Household gathering and future rescue remain unobserved.

## Joshua 2:22–24 — THREE DAYS, SAFE RETURN, LAND ALREADY IN HAND

The spies stay in the mountain three days while pursuers fail to find them,
then descend, cross the river, return to Joshua and report what happened. They
say all the land **has been delivered into our hands**, while Joshua 1's Jordan
crossing, western possession and military-help acts remain unexecuted.

This is the retained `S070` structure: completed possession/delivery asserted
before the stated necessary execution. CrackFlix displays:

> **SKIP -> S070-E003-NUM32 — CROSS AND SUBDUE; THEN POSSESS / LAND GIVEN BEFORE CROSSING**

SKIP explains nothing and changes nothing. Captain then says **“YOINK!”**,
pokes, licks and leaves. The report remains delivered.

## Character and world-ledger changes

- two unnamed spies complete the Shittim–Jericho–mountain–return route;
- Rahab's hiding, statements, oath negotiation, cord escape and scarlet tie are complete;
- the king's pursuers leave, search and return without finding the spies;
- family rescue and Jericho outcome remain future;
- `S126-E001-JOS2` is new; `S070-E004-JOS2` points to the prior same structure;
- Captain is boilless and causally useless; each completed mismatch gets one distinct `YOINK!`;
- every living human, animal or plant Joe and face-like non-divine flax, roof, gate, cord, window, scarlet line, mountain or report scroll is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — SECRET SPY HOUSE ROUTER`;
- roof storage: `TWO JOES / ORDERED FLAX`;
- pursuit arrow: `THEY WENT THAT WAY`;
- CrackFlix: `S126-E001 — HIDDEN HERE / WENT OUT`;
- window protocol: `SCARLET LINE + HOUSEHOLD INSIDE`;
- final display: `SKIP -> S070-E003-NUM32`;
- barcode: `CHB-JOS2-24-RAHAB-CORD-S126-S070-2YOINK-HELD`.

## FIR verification

- all 24 verse markers are represented in order;
- observed hiding and Rahab's claims remain distinct;
- reports/beliefs are not converted into direct observation;
- oath conditions and later outcomes remain separate;
- ordinary cord and scarlet line are not silently merged;
- S126 and recurring S070 have exact addresses and separate closure points;
- SKIP points backward and does nothing;
- no motive, moral judgment, divine form or future rescue is invented;
- publication remains held and unpublished.

Continuation required: Joshua 3 begins the camp departure, ark-distance,
sanctification and actual Jordan crossing process.
