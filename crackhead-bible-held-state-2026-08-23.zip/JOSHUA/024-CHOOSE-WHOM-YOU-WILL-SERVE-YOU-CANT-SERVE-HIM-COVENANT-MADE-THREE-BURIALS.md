# CRACKHEAD JOSHUA 24

## Title page

**CHOOSE WHOM YOU WILL SERVE. YOU CAN'T SERVE HIM. COVENANT MADE. JOSHUA, JOSEPH AND ELEAZAR CLOSE.**

Source parent: Joshua chapter 24, verses 1–33, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-024/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/023-NATIONS-REMAIN-THEY-WILL-BE-DRIVEN-OUT-NOT-ONE-GOOD-THING-FAILED.md`.

CrackFlix routing:

- `S130-E003-JOS24`, `SKIP -> S130-E002-JOS21`: all peoples driven out / retained nations remain;
- new `S134-E001-JOS24`, no SKIP: choose whom to serve / you cannot serve the chosen LORD / covenant records that service choice.

## Causal foundation

```text
SHECHEM ASSEMBLY
-> JOSHUA RELAYS LORD-ATTRIBUTED HISTORY
-> TERAH TO ABRAHAM / ISAAC / JACOB / ESAU
-> EGYPT / EXODUS / SEA / WILDERNESS
-> AMORITES / BALAK-BALAAM / JORDAN / JERICHO / LAND

JOSHUA: PUT AWAY GODS + CHOOSE WHOM TO SERVE
PEOPLE: WE WILL SERVE LORD
JOSHUA: YOU CAN'T SERVE LORD
PEOPLE: NO, WE WILL
-> PEOPLE BECOME SELF-WITNESSES
-> PUT AWAY FOREIGN GODS COMMAND
-> PEOPLE REPEAT SERVICE + LISTENING
-> COVENANT / STATUTE / ORDINANCE
-> WORDS WRITTEN + GREAT WITNESS STONE
-> PEOPLE SENT HOME

JOSHUA DIES AT 110 + BURIED
JOSEPH BONES BURIED
ELEAZAR DIES + BURIED
```

## Joshua 24:1–13 — GOD-ATTRIBUTED HISTORY AT SHECHEM

Joshua gathers all tribes and their elders, heads, judges and officers at
Shechem. They present themselves before God. Joshua introduces the following
history as the LORD's speech.

The speech retains, in order: Terah's family serving other gods beyond the
River; Abraham taken through Canaan and given Isaac; Jacob and Esau; Esau's
Seir possession; Jacob's family entering Egypt; Moses and Aaron; Egypt's
plagues and the exodus; pursuit at the sea, darkness and covering water; many
wilderness days; Amorite fighting and eastern possession; Balak/Balaam;
Jordan crossing and Jericho; seven named people classes; the hornet and two
Amorite kings; and land, cities, vineyards and olive groves Israel did not
create.

This is one attributed retrospective speech. It joins retained histories and
does not replay them as new occurrences. The hornet is Joe-faced if shown,
because every living thing is Joe. Its precise mechanism remains unsupplied.

## Joshua 24:14–18 — CHOOSE, THEN “ALL PEOPLES”

Joshua commands sincere service, putting away ancestral gods, and service of
the LORD. If that seems evil, the people must choose that day between the
beyond-River gods, Amorite gods and the LORD. Joshua selects the LORD for
himself and his house.

The people reject forsaking the LORD. They cite the exodus, signs,
preservation and the LORD driving out **all the peoples**, including the
Amorites. Joshua 23 immediately retained nations still among Israel and future
drive-out. No return, scope partition or reclassification is supplied.

This is `S130-E003-JOS24`. CrackFlix displays
`SKIP -> S130-E002-JOS21`, pointing to the prior same-type completeness crack.
Nothing skips. Once this occurrence closes, Captain Crackhead pokes the
Joe-faced boil, sees a crack crystal, licks his finger, says **“YOINK!”**, and
walks away without looking back. Everyone else sees the poke and lick; the
assembly continues unchanged.

## Joshua 24:19–24 — CHOOSE HIM; YOU CAN'T; WE WILL

After inviting the choice and hearing “we will serve the LORD,” Joshua says,
“You can't serve the LORD,” because God is holy and jealous and will not
forgive disobedience and sins. He gives the conditional foreign-god consequence.

The people answer, “No, but we will serve the LORD.” Joshua makes them
witnesses against themselves that they selected the LORD. They accept that
witness status. Joshua again orders the foreign gods among them put away and
their hearts inclined to the LORD. They repeat: “We will serve the LORD our God,
and we will listen to his voice.”

The interaction requires a service choice, rejects the selected service as
impossible, then accepts and records the same choice. That is new
`S134-E001-JOS24: CHOOSE WHOM TO SERVE / YOU CAN'T SERVE HIM / COVENANT IT`.

No SKIP appears because the type is new. After the covenant-choice mismatch is
fully spoken, Captain performs one more irrelevant poke and finger lick,
says **“YOINK!”**, and leaves. He causes none of the dialogue or outcome.

## Joshua 24:25–28 — COVENANT, BOOK, STONE, RELEASE

Joshua makes a covenant, statute and ordinance at Shechem. He writes the words
in the book of God's law, sets a great stone under the oak by the sanctuary,
and tells the people the stone heard all the LORD's words and will witness
against denial.

The stone's hearing is retained exactly as Joshua's statement. Anything
interpreted as its face can receive Joe's face, but no biological status,
acoustic mechanism or independent testimony is invented. Joshua sends every
person to their inheritance.

## Joshua 24:29–33 — THREE CLOSURES

Joshua dies at 110. He is buried in his inheritance at Timnathserah, north of
Mount Gaash in Ephraim. His death and burial are separate completed acts.

Israel serves the LORD through Joshua's days and the days of elders who outlive
him and know the retained works.

Joseph's bones, carried from Egypt, are buried at Shechem in Jacob's hundred-
kesitah parcel from Hamor's sons. The parcel becomes Joseph's children's
inheritance. This closes the Joseph-bones carry from Genesis and Exodus.

Eleazar dies and is buried in the hill of his son Phinehas in Ephraim. Joshua,
Joseph and Eleazar identities, locations and lineages remain distinct. The
book of Joshua closes here; Judges 1 is not imported.

## Character and world-ledger changes

- Joshua's God-attributed history remains one speech with all prior histories as parents;
- all historical actors/events retain their original occurrence identities;
- the all-peoples-driven claim routes to `S130-E003-JOS24` with exact SKIP pointer;
- the choose/cannot/covenant service chain creates new `S134-E001-JOS24` without SKIP;
- exactly two causally null post-closure YOINKs occur;
- present foreign-gods wording remains Joshua's claim/command, not an inventoried object set;
- the covenant, written words, stone installation and release are completed;
- stone hearing remains attributed speech without invented mechanism;
- Joshua dies at 110 and is buried at Timnathserah;
- Joseph's bones are buried at Shechem and the long carry closes;
- Eleazar dies and is buried in Phinehas's hill;
- Captain remains permanently boilless and changes nothing;
- every living human, animal or plant Joe and every face-like non-divine hornet, river, sea, city, law book, covenant docket, witness stone, bone chest, grave marker or coin is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — FINAL CHAPTER / CHOOSE SERVICE COMPATIBILITY MODE`;
- history channel: `PREVIOUSLY, ON EVERY FUCKING BOOK`;
- chooser: `SELECT GOD -> ERROR: CANNOT SERVE -> CREATE COVENANT ANYWAY`;
- witness stone label: `AUDIO CAPTURE: SOURCE CLAIMED / MIC NOT FOUND`;
- burial queue: `JOSHUA / JOSEPH BONES / ELEAZAR — THREE DISTINCT JOBS`;
- CrackFlix: `S130-E003 -> SKIP S130-E002`; `S134 PREMIERE`;
- barcode: `CHB-JOS24-33-BOOKCLOSE-2CRACKS-2YOINKS-HELD`.

## FIR verification

- all 33 verse markers are represented in order;
- the LORD-introduced history remains attributed speech and does not duplicate prior events;
- all named historical transitions and supplied objects remain in source order;
- the retained remaining nations validate S130 recurrence without inventing a bridge;
- choose, cannot serve, repeated choice and covenant remain one complete observable chain;
- conditional forgiveness/foreign-god consequences remain unexecuted;
- the stone-hearing claim is preserved without invented mechanism;
- Joshua death/burial, Joseph-bones burial and Eleazar death/burial remain distinct;
- exactly two contradiction occurrences and two post-closure YOINKs occur;
- no unsupported motive, foreign-god inventory, divine form or Captain effect is added;
- Joshua closes 24/24 with publication held and unpublished.

Continuation required: Judges 1 begins after Joshua's death with Israel asking
the LORD who goes first, Judah/Simeon campaigns and multiple retained
could-not/did-not-drive-out outcomes. No Judges event is backfilled here.
