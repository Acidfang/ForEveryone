# CRACKHEAD JOSHUA 23

## Title page

**NATIONS REMAIN. THEY WILL BE DRIVEN OUT. NOT ONE GOOD THING FAILED.**

Source parent: Joshua chapter 23, verses 1–16, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-023/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/022-THEY-KEPT-THEIR-DUTY-BUILT-A-GREAT-ALTAR-ISRAEL-GATHERED-FOR-WAR-IT-WAS-A-WITNESS.md`.

CrackFlix routing: `S132-E002-JOS23`, with exact `SKIP -> S132-E001-JOS21`.
Joshua retains remaining nations and future drive-out/possession, then says every
good thing spoken has happened and not one failed.

## Causal foundation

```text
MANY DAYS + REST + JOSHUA OLD
-> JOSHUA CALLS ISRAEL'S LEADERS
-> RETELLS LORD-FOR-YOU WAR STATE
-> NATIONS REMAIN
-> REMAINING NATIONS ALLOTTED
-> LORD WILL DRIVE THEM OUT
-> ISRAEL WILL POSSESS THEIR LAND

KEEP MOSES LAW + HOLD TO LORD
IF JOIN REMAINING NATIONS
-> LORD WILL NO LONGER DRIVE THEM OUT
-> SNARE / TRAP / SCOURGE / THORNS / PERISH

JOSHUA SAYS HE IS GOING WAY OF ALL EARTH
-> NOT ONE GOOD THING FAILED
-> ALL HAPPENED
-> FUTURE DISOBEDIENCE / EVIL / DESTRUCTION BRANCH
```

## Joshua 23:1–5 — OLD JOSHUA AND THE NATIONS THAT REMAIN

After many days of attributed rest, old Joshua calls Israel's elders, heads,
judges and officers. He says they saw what the LORD did and that the LORD
fought for them.

Joshua explicitly identifies nations that remain. He says he allotted both
remaining and cut-off nations as tribal inheritance. The LORD **will** thrust
the remaining nations out, and Israel **shall** possess their land. These are
future acts, not completed expulsion or possession.

## Joshua 23:6–11 — KEEP, DO, DO NOT JOIN, HOLD FAST

Joshua commands courage to keep and do the written law of Moses without
turning right or left. Israel must not mix with the remaining nations, mention
their gods, swear by them, serve them or bow to them; Israel must hold fast to
the LORD as it has to that day.

Joshua says the LORD drove out great and strong nations and no one stood before
Israel. He says one Israelite will chase a thousand because the LORD fights for
them. The one-to-thousand statement remains speech; no such chase occurs here.

## Joshua 23:12–13 — CONDITIONAL REVERSAL

If Israel turns back, joins the remnant nations and intermarriages, Joshua says
the LORD will no longer drive those nations out. They will become snare, trap,
scourge and thorns until Israel perishes from the land.

The chapter does not show the conditional joining, marriage, stopped drive-out
or perishing. The branch remains prospective.

## Joshua 23:14–16 — NOTHING FAILED, WITH WORK STILL FUTURE

Joshua says he is going the way of all the earth. This announces approaching
death; it does not report his death.

He then says Israel knows that not one good thing spoken by the LORD failed,
all happened, and not one failed. The same address has already retained nations
remaining, a future divine drive-out and future Israelite possession. This is
the next occurrence of `S132: NOTHING FAILED / A SPOKEN GOOD THING REMAINS
FUTURE`.

CrackFlix displays `SKIP -> S132-E001-JOS21`. It points to the prior exact
contradiction and omits its repeated explanation; nothing in the world skips.
After `S132-E002-JOS23` closes, Captain Crackhead pokes the Joe-faced boil,
sees a crack crystal, licks his finger, says **“YOINK!”**, and walks away
without looking back. Everyone else sees the poke and lick. No state changes.

Joshua finishes with a conditional warning: as good things came, evil things
will come until destruction if Israel disobeys the covenant and serves other
gods. No disobedience, other-god service, anger, destruction or perishing is
executed in this chapter.

## Character and world-ledger changes

- Joshua is old and announces approaching death, but remains alive;
- remaining nations and future drive-out/possession are explicit retained State;
- prior war outcomes remain historical speech and are not replayed;
- Moses-law obedience and remaining-nation separation are commands;
- all intermarriage, stopped-expulsion, trap and destruction chains remain conditional;
- `S132-E002-JOS23` repeats `S132-E001-JOS21` and uses an exact SKIP pointer;
- exactly one causally null post-closure YOINK occurs;
- Captain remains permanently boilless and changes nothing;
- every living human, animal or plant Joe and every face-like non-divine law book, allotment, nation counter, trap, thorn, good-thing ledger or warning terminal is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — REMAINING NATION UNINSTALLER / FUTURE BUILD`;
- allotment stamp: `INHERITED BEFORE EJECTION`;
- promise terminal: `WILL DRIVE OUT / ALL ALREADY HAPPENED`;
- conditional warning: `MARRIAGE PLUGIN MAY DISABLE EXPULSION SERVICE`;
- CrackFlix: `S132-E002 -> SKIP S132-E001`;
- barcode: `CHB-JOS23-16-REMAINING-NOTHINGFAILED-1YOINK-HELD`.

## FIR verification

- all 16 verse markers are represented in order;
- Joshua's age, audience, retrospective claims and future claims remain distinct;
- remaining nations are not erased by prior victory speech;
- future drive-out and possession are not converted into completed acts;
- every obedience and failure branch remains prospective;
- Joshua's approaching-death statement is not converted into death;
- the repeated no-failure mismatch routes only to the established S132 series;
- SKIP points exactly to the immediately prior same-type episode and does nothing;
- exactly one post-closure YOINK occurs with no causal effect;
- no divine form, future conduct or consequence is invented;
- publication remains held and unpublished.

Continuation required: Joshua 24 assembles Israel at Shechem, retells the
ancestral-to-land history, records covenant dialogue and witness stone, then
closes Joshua's death, Joseph's burial and Eleazar's death without importing
Judges 1.
