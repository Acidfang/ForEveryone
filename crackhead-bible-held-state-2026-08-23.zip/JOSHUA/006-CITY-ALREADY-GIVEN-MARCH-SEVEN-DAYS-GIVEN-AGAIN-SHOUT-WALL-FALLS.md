# CRACKHEAD JOSHUA 6

## Title page

**CITY ALREADY GIVEN. MARCH SEVEN DAYS. GIVEN AGAIN. SHOUT. WALL FALLS.**

Source parent: Joshua chapter 6, verses 1–27, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-006/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/005-CIRCUMCISE-HEAL-PASSOVER-MANNA-STOPS-NO-I-COMMAND-THE-ARMY.md`.

CrackFlix routing: `S070-E005-JOS6` with `SKIP -> S070-E004-JOS2`; then `S070-E006-JOS6` with `SKIP -> S070-E005-JOS6`. Two distinct causally-null post-closure `YOINK!` occurrences.

## Causal foundation

```text
JERICHO SHUT
-> LORD: “I HAVE GIVEN JERICHO” BEFORE MARCH
-> SKIP S070-E004 + YOINK
-> SIX DAYS: ONE CIRCUIT/DAY, TRUMPETS, SILENCE
-> DAY SEVEN: SEVEN CIRCUITS
-> JOSHUA: “LORD HAS GIVEN CITY” BEFORE SHOUT/FALL/TAKING
-> SKIP S070-E005 + YOINK
-> SHOUT / WALL FALLS / PEOPLE ENTER / CITY TAKEN
-> DEVOTED DESTRUCTION WITH RAHAB EXCEPTION + TREASURY ROUTE
-> RAHAB HOUSEHOLD EXTRACTED / CITY BURNED
-> JOSHUA'S FUTURE REBUILDING CURSE
```

## Joshua 6:1–5 — GIVEN BEFORE THE REQUIRED PROCESS

Jericho is tightly shut: nobody goes out or comes in. The LORD tells Joshua,
“I have given Jericho into your hand,” including king and warriors, then supplies
the still-future process: six daily circuits, seven priests/seven trumpets, seven
circuits on day seven, long blast, heard signal, collective shout, wall fall and
straight entry.

The completed-gift assertion precedes every stated execution act. CrackFlix:

> **SKIP -> S070-E004-JOS2 — LAND ALREADY DELIVERED BEFORE CROSSING**

`S070-E005-JOS6` closes. Captain says **“YOINK!”**, pokes, licks and leaves.
The marching protocol remains unchanged.

## Joshua 6:6–14 — SIX DAYS, ONE CIRCUIT EACH, PEOPLE SILENT

Joshua relays the ark, seven-priest, seven-trumpet and armed-front order. The
formation advances: armed men, trumpet priests, ark, rear guard. Joshua orders
no shout, heard voice or spoken word until his shout command. Day one circles
once and returns to camp; day two repeats; the source summarizes the same once-
daily act for six days. Trumpets sound while the people remain under the stated
voice restriction.

## Joshua 6:15–20 — GIVEN AGAIN, THEN THE WALL ACTUALLY FALLS

On day seven they circle seven times. At the seventh trumpet circuit—before the
people shout, the wall falls, anyone enters, or the city is taken—Joshua says
the LORD **has given** the city.

> **SKIP -> S070-E005-JOS6 — CITY ALREADY GIVEN BEFORE THE MARCH**

`S070-E006-JOS6` closes. Captain performs a second distinct **“YOINK!”** and
changes nothing. Joshua states the devoted-city rules: Rahab and everyone in
her house are an explicit exception; devoted goods are prohibited; silver,
gold, bronze and iron vessels route to the LORD's treasury.

The people then shout, priests blow, the wall falls flat, people enter straight
ahead and take the city. The claimed state now receives its later execution;
the earlier contradiction Moments remain historically true at their own times.

## Joshua 6:21–25 — DESTRUCTION, EXPLICIT EXCEPTION, TREASURY, FIRE

The source says the city population and named animal classes are destroyed by
the sword. Joshua orders the original two spies to bring Rahab and all she has
out according to their oath. They extract Rahab, parents, siblings, possessions
and relatives and place them outside Israel's camp. The city and contents are
burned; listed metals go to the treasury. Joshua saves Rahab and household, and
the narrator says she lives among Israel to its “this day.”

Rahab is not a post-“all” contradiction: the exception is explicitly declared
before the destruction and then executed.

## Joshua 6:26–27 — FUTURE REBUILDING CURSE, CURRENT FAME

Joshua gives an oath-bound future curse: a rebuilder will lose firstborn at the
foundation and youngest at the gates. No rebuilder, sons, foundation or gates
occur here. The chapter closes with the LORD with Joshua and Joshua's fame
throughout the land.

## Character and world-ledger changes

- the complete seven-day Jericho protocol and wall fall are executed;
- `S070-E005-JOS6` and `S070-E006-JOS6` retain two pre-execution completed-state assertions;
- Rahab's Joshua 2 oath condition resolves into household extraction and survival;
- devoted destruction, metal treasury routing and city burning complete;
- Joshua's rebuilding curse remains future speech;
- two distinct causally-null Captain `YOINK!` occurrences; each SKIP points backward and does nothing;
- every living human, animal or plant Joe and face-like non-divine wall, ark, trumpet, sword, treasury vessel, flame or gate is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — SEVEN-DAY CITY-OPENING PROCEDURE`;
- CrackFlix A: `SKIP -> S070-E004-JOS2`;
- marching counter: `1 x 6 DAYS / 7 x DAY 7`;
- voice lock: `NO WORD UNTIL SHOUT`;
- CrackFlix B: `SKIP -> S070-E005-JOS6`;
- wall status: `FLAT AFTER SHOUT`;
- exception register: `RAHAB HOUSEHOLD`;
- treasury: `Ag/Au/Cu/Fe`;
- barcode: `CHB-JOS6-27-S070X2-WALLFALL-RAHAB-2YOINK-HELD`.

## FIR verification

- all 27 verse markers are represented in order;
- six-day and seventh-day circuit counts remain distinct;
- both S070 closures occur before their respective later execution acts;
- SKIP pointers are exact and noncausal;
- Rahab's prior oath lineage closes without treating the explicit exception as contradiction;
- destruction, rescue, treasury and fire routes remain separate;
- rebuilding curse remains future;
- publication remains held and unpublished.

Continuation required: Joshua 7 observes devoted-property taking, Ai defeat,
inquiry, lot selection, confession, recovery and execution.
