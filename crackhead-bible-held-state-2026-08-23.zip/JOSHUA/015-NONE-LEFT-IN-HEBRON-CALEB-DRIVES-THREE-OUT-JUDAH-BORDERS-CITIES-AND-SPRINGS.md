# CRACKHEAD JOSHUA 15

## Title page

**NONE LEFT IN HEBRON. CALEB DRIVES THREE OUT. JUDAH GETS BORDERS, CITIES, A WIFE TICKET AND TWO SPRING SETS.**

Source parent: Joshua chapter 15, verses 1–63, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-015/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/014-NINE-AND-A-HALF-BY-LOT-CALEB-WAITED-FORTY-FIVE-YEARS-GIVE-ME-HEBRON.md`.

CrackFlix routing: `S131-E001-JOS15`. New contradiction type, so no SKIP.

## Causal foundation

```text
JOSHUA 11:21-22
-> JOSHUA CUT OFF ANAKIM FROM HEBRON
-> DESTROYED THEM WITH THEIR CITIES
-> NONE LEFT IN ISRAEL'S LAND

JOSHUA 15:13-14
-> CALEB RECEIVES HEBRON
-> CALEB DRIVES THREE NAMED SONS OF ANAK OUT OF HEBRON
-> NO RETURN / NEW GENERATION / SURVIVOR / SCOPE BRIDGE
-> S131-E001-JOS15
-> ONE CAUSALLY NULL POST-CLOSURE YOINK

JUDAH LOT
-> SOUTH + EAST + NORTH + WEST BORDER CHAINS
-> CALEB PORTION
-> DEBIR/KIRIATH SEPHER CAPTURE OFFER
-> OTHNIEL TAKES IT
-> ACHSAH GIVEN AS WIFE
-> ACHSAH REQUESTS WATER
-> UPPER + LOWER SPRINGS GIVEN
-> REGIONAL CITY/VILLAGE INVENTORIES
-> JEBUSITES REMAIN IN JERUSALEM
```

## Joshua 15:1–12 — JUDAH'S FOUR BORDER CHAINS

Judah's family lot begins at Edom and the wilderness of Zin in the far south.
The south border runs from the Salt Sea's southern bay through Akrabbim, Zin,
south of Kadesh Barnea, Hezron, Addar, Karka and Azmon to Egypt's brook and the
sea.

The east border is the Salt Sea to the Jordan's end. The north border begins at
that bay, then runs through Beth Hoglah, north of Beth Arabah, Bohan's stone,
Debir from Achor, Gilgal opposite Adummim, En Shemesh and En Rogel. It continues
through Hinnom beside Jebus/Jerusalem, the mountain by Hinnom and Rephaim,
Nephtoah, Mount Ephron, Baalah/Kiriath Jearim, Mount Seir, Mount
Jearim/Chesalon, Beth Shemesh, Timnah, Ekron, Shikkeron, Mount Baalah and
Jabneel to the sea.

The west border is the Great Sea shore. These routes define one Judah family
boundary; alternative place names remain joined labels, not duplicate cities.

## Joshua 15:13–14 — HEBRON HAS ANAKIM AGAIN

Caleb receives Kiriath Arba/Hebron within Judah under the stated command of the
LORD to Joshua. Arba remains named as Anak's father.

Caleb then drives out three sons of Anak: Sheshai, Ahiman and Talmai. Joshua
11:21–22 had already stated that Joshua cut off the Anakim from Hebron,
destroyed them with their cities, and left none in Israel's land. This chapter
supplies no return, survivor, new-generation or territory bridge before Caleb's
new Hebron expulsion.

CrackFlix opens **S131 — NONE LEFT IN HEBRON. THREE DRIVEN OUT OF HEBRON.** It
is the first episode, so there is no SKIP. After the completed expulsion exposes
both states, Captain Crackhead appears in his unexplained suit, pokes the boil,
says only **“YOINK!”**, licks his finger, and walks away without looking back.
Caleb's result remains identical.

## Joshua 15:15–19 — TAKE DEBIR, GET ACHSAH; ASK FOR WATER, GET SPRINGS

Caleb goes against Debir, formerly Kiriath Sepher. He says that whoever strikes
and takes Kiriath Sepher will receive his daughter Achsah as wife. Othniel son
of Kenaz, identified as Caleb's brother, takes it; Caleb gives Achsah to him as
wife. The source supplies the offer, completed capture and completed giving. It
does not supply Achsah's consent, Othniel's motive or missing battle detail.

On arrival, Achsah has Othniel ask her father for a field. She gets off her
Joe-faced donkey; Caleb asks what she wants. Achsah asks for a blessing and
springs because she has been set in southern land. Caleb gives her the upper
and lower springs. Field, southern land and the two spring sets remain distinct
objects; the text does not say whether the field request separately closed.

## Joshua 15:20–32 — SOUTH CITIES: SOURCE TOTAL TWENTY-NINE

Judah's southern city inventory toward Edom lists Kabzeel, Eder, Jagur, Kinah,
Dimonah, Adadah, Kedesh, Hazor, Ithnan, Ziph, Telem, Bealoth, Hazor Hadattah,
Kerioth Hezron/Hazor, Amam, Shema, Moladah, Hazar Gaddah, Heshmon, Beth Pelet,
Hazar Shual, Beersheba, Biziothiah, Baalah, Iim, Ezem, Eltolad, Chesil, Hormah,
Ziklag, Madmannah, Sansannah, Lebaoth, Shilhim, Ain and Rimmon.

The source states **twenty-nine cities with their villages**. The visible name
tokens exceed that stated total under a naive token count. The manuscript
retains both the exact source list and its stated twenty-nine without inventing
which entries are joined, alternate, dependent or excluded.

## Joshua 15:33–47 — LOWLAND AND COASTAL GROUPS

The first lowland group is Eshtaol, Zorah, Ashnah, Zanoah, En Gannim, Tappuah,
Enam, Jarmuth, Adullam, Socoh, Azekah, Shaaraim, Adithaim and
Gederah/Gederothaim: source total fourteen with villages.

The next group is Zenan, Hadashah, Migdal Gad, Dilean, Mizpah, Joktheel,
Lachish, Bozkath, Eglon, Cabbon, Lahmam, Chitlish, Gederoth, Beth Dagon, Naamah
and Makkedah: source total sixteen with villages.

The next is Libnah, Ether, Ashan, Iphtah, Ashnah, Nezib, Keilah, Achzib and
Mareshah: source total nine with villages.

Ekron retains its towns and villages. The coastal extent continues from Ekron
to the sea beside Ashdod, then Ashdod and Gaza with their towns and villages,
to Egypt's brook and the Great Sea coastline. No capture or removal act is
inferred merely from inclusion in an inheritance inventory.

## Joshua 15:48–62 — HILL COUNTRY AND WILDERNESS GROUPS

The first hill-country group is Shamir, Jattir, Socoh, Dannah, Kiriath
Sannah/Debir, Anab, Eshtemoh, Anim, Goshen, Holon and Giloh: source total eleven
with villages.

The next is Arab, Dumah, Eshan, Janim, Beth Tappuah, Aphekah, Humtah, Kiriath
Arba/Hebron and Zior: source total nine with villages.

The next is Maon, Carmel, Ziph, Jutah, Jezreel, Jokdeam, Zanoah, Kain, Gibeah
and Timnah: source total ten with villages.

The next is Halhul, Beth Zur, Gedor, Maarath, Beth Anoth and Eltekon: source
total six with villages. Kiriath Baal/Kiriath Jearim and Rabbah form the stated
two-city group.

The wilderness group is Beth Arabah, Middin, Secacah, Nibshan, the City of Salt
and En Gedi: source total six with villages.

## Joshua 15:63 — JERUSALEM IS IN THE INHERITANCE; THE JEBUSITES REMAIN

Judah cannot drive the Jebusites out of Jerusalem. The source says the
Jebusites live with Judah there to its “this day.” This is a completed
non-expulsion/residence state. Allocation and residence can coexist, so no new
contradiction is inferred. It remains additional evidence that a mapped
inheritance does not by itself prove completed possession or removal.

## Character and world-ledger changes

- Judah's south/east/north/west family borders are retained in source order;
- alternate place names remain joined identities rather than duplicated places;
- `S131-E001-JOS15` closes Joshua 11's no-Anakim-left state against Caleb's completed Hebron expulsion;
- exactly one causally null Captain YOINK follows the completed contradiction; no SKIP occurs;
- Caleb's Hebron portion, Othniel's Debir capture, Achsah's wife-giving and the upper/lower spring grants are completed acts;
- Achsah's consent, Othniel's motive, battle detail and the separate field-result state remain unresolved;
- all regional city lists and their stated totals are preserved without forcing the southern list to equal a naive token count;
- city inclusion does not become an invented capture or expulsion event;
- Jerusalem's Jebusite non-expulsion/residence state is retained without inventing cause;
- every living human, animal or plant Joe and every face-like non-divine border, city, sea, spring, stone, mountain, lot, counter or nameplate is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — NONE LEFT / REMOVE THREE`;
- CrackFlix card: `S131-E001 / HEBRON REPOPULATED BY UNSUPPLIED BRIDGE`;
- Judah plotter: `SOUTH -> EAST -> NORTH -> WEST`;
- marriage ticket: `TAKE DEBIR / ACHSAH DISPENSER`;
- water upgrade: `UPPER SPRINGS + LOWER SPRINGS`;
- city counter: `SOURCE TOTALS RETAINED / DO NOT FIX SCRIPTURE WITH A CALCULATOR`;
- Jerusalem tag: `INHERITANCE ADDRESS / CURRENT JEBUSITE OCCUPANTS`;
- barcode: `CHB-JOS15-63-S131E001-NOSKIP-1YOINK-HELD`.

## FIR verification

- all 63 verse markers are represented in order;
- Judah's four border chains retain their named route and endpoints;
- the Joshua 11 Anakim parent and Joshua 15 completed Hebron expulsion are both retained;
- S131 has no invented bridge, no SKIP and exactly one causally null YOINK;
- completed Caleb/Othniel/Achsah acts remain distinct from absent consent, motive and battle detail;
- alternative city names are not automatically counted as separate places;
- every regional list and source-stated subtotal remains represented;
- the southern twenty-nine statement is preserved without falsifying the visible source tokens;
- city allocation does not manufacture conquest;
- Jebusite continued residence remains a completed state without unsupported contradiction machinery;
- no unsupported divine form or causal explanation is supplied;
- publication remains held and unpublished.

Continuation required: Joshua 16 assigns Joseph's lot through Ephraim's border
and city relations, then records Ephraim's failure to drive out the Canaanites
of Gezer and their forced-labor state.
