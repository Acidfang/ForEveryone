# CRACKHEAD JOSHUA 20

## Title page

**SIX REFUGE CITIES. STATE YOUR CASE AT THE GATE. WAIT FOR JUDGMENT OR THE HIGH PRIEST'S DEATH. NO CASE INCLUDED.**

Source parent: Joshua chapter 20, verses 1–9, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-020/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/019-SIX-MORE-LOTS-DAN-TAKES-LESHAM-JOSHUA-GETS-TIMNATHSERAH-DIVIDING-FINISHED.md`.

CrackFlix routing: none. The chapter installs and names a prospective refuge
procedure but does not instantiate a homicide, pursuit, trial, priest death or
return.

## Causal foundation

```text
LORD SPEAKS TO JOSHUA
-> SPEAK TO ISRAEL
-> ASSIGN CITIES PREVIOUSLY SPOKEN THROUGH MOSES

IF PERSON KILLS ACCIDENTALLY / UNINTENTIONALLY
-> FLEE TO ONE REFUGE CITY
-> STAND AT GATE
-> DECLARE CASE TO ELDERS
-> ELDERS ADMIT + GIVE RESIDENCE
-> IF BLOOD AVENGER PURSUES
-> DO NOT DELIVER KILLER
-> BECAUSE UNINTENTIONAL + NO PRIOR HATRED
-> DWELL UNTIL CONGREGATIONAL JUDGMENT
-> AND/UNTIL CURRENT HIGH PRIEST DIES
-> RETURN TO OWN CITY / HOUSE

WEST OF JORDAN
-> KEDESH / SHECHEM / KIRIATH ARBA-HEBRON
EAST OF JORDAN
-> BEZER / RAMOTH GILEAD / GOLAN BASHAN
-> SIX APPOINTED CITIES
-> ISRAELITE + RESIDENT ALIEN ACCESS
```

## Joshua 20:1–3 — LORD SPEAKS; THE REFUGE CLASS IS DEFINED

The LORD speaks directly to Joshua. Joshua must tell Israel to assign the
refuge cities previously spoken through Moses.

The admitted case class is a person who kills another accidentally or
unintentionally. Such a killer may flee to refuge from the blood avenger. The
chapter defines the class prospectively; it does not identify an actual dead
person, killer, avenger, time, weapon or event.

## Joshua 20:4–6 — GATE SPEECH, ADMISSION, PROTECTION, JUDGMENT, RETURN

The prospective killer flees to one designated city, stands at its gate and
declares the case to the city elders. The elders are to admit the person and
give a place to live among them.

If the blood avenger pursues, the city must not deliver the killer because the
strike was unintentional and no prior hatred existed. Both conditions remain
case selectors; the chapter does not show evidence collection or an elder
finding in an actual matter.

The admitted person remains until standing before the congregation for
judgment and until the death of the high priest serving in those days. Then the
person returns to the own city and house from which they fled. The text retains
both judgment and high-priest-death timing language; it does not resolve their
precise interaction through a completed case.

## Joshua 20:7–8 — THE SIX CITIES ARE ACTUALLY DESIGNATED

Three western cities are set apart:

1. Kedesh in Galilee, Naphtali hill country;
2. Shechem, Ephraim hill country;
3. Kiriath Arba/Hebron, Judah hill country.

Three eastern cities are assigned beyond the Jordan:

4. Bezer in the wilderness/plain from Reuben;
5. Ramoth in Gilead from Gad;
6. Golan in Bashan from Manasseh.

The six designations are completed acts. Alternative Kiriath Arba/Hebron names
remain one city identity. No refuge case is inferred merely because the system
now exists.

## Joshua 20:9 — ACCESS FOR ISRAEL AND RESIDENT ALIENS

The appointed cities are available to Israel and the alien residing among
them. Whoever kills unintentionally may flee there and avoid death by the
blood avenger until standing trial before the congregation.

This final statement restates access, purpose and the trial boundary. It does
not report that anyone used the route.

## Character and world-ledger changes

- direct LORD-to-Joshua refuge instruction is retained as a God-only speech line;
- the earlier Moses instruction remains a parent rather than being recreated;
- accidental/unintentional killing and no-prior-hatred remain typed selectors;
- gate declaration, elder admission, residence and anti-delivery duties remain prospective;
- judgment, high-priest-death timing and return remain prospective and interaction-unresolved;
- all six refuge-city designations are completed and retain tribe/geography;
- Israelite and resident-alien access classes are both retained;
- no killer, victim, avenger, elder decision, trial, priest death or return event is invented;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every living human, animal or plant Joe and every face-like non-divine city, gate, road, house, blood token, trial docket, priest timer or map is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — REFUGE ROUTER / ZERO CASES LOADED`;
- selector: `ACCIDENTAL + UNINTENTIONAL + NO PRIOR HATRED`;
- gate terminal: `DECLARE CASE TO ELDER JOES`;
- protection sticker: `DO NOT DELIVER TO BLOOD AVENGER`;
- timer: `JUDGMENT / HIGH PRIEST DEATH / RELATION PENDING ACTUAL CASE`;
- city board: `3 WEST + 3 EAST = 6`;
- access badge: `ISRAEL + RESIDENT ALIEN`;
- barcode: `CHB-JOS20-9-SIXREFUGE-NOCASE-NOCRACK-HELD`.

## FIR verification

- all 9 verse markers are represented in order;
- direct LORD speech and Moses-parent instruction remain distinct;
- every prospective selector and procedural step remains in source order;
- no conditional killer, avenger, trial or return is converted into an occurrence;
- judgment and priest-death timing remain unresolved without a completed case;
- all six cities retain west/east, tribe and geographic identity;
- Israelite and resident-alien eligibility both remain represented;
- no unsupported contradiction, motive, evidence finding or causal mechanism is introduced;
- no divine form appears;
- publication remains held and unpublished.

Continuation required: Joshua 21 completes the commanded Levitical city and
pasture allocation through four clan lots, forty-eight total cities, and the
chapter's land/rest/delivery/no-failure closure statements.
