# CRACKHEAD JOSHUA 8

## Title page

**AI ALREADY GIVEN. AMBUSH. FLEE ON PURPOSE. TURN BACK. COPY IT. READ EVERY WORD.**

Source parent: Joshua chapter 8, verses 1–35, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-008/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/007-ONE-MAN-TOOK-IT-ISRAEL-STOLE-IT-THIRTY-SIX-DIED.md`.

CrackFlix routing: `S070-E007-JOS8` with `SKIP -> S070-E006-JOS6`.
One causally-null post-closure `YOINK!` occurrence.

## Causal foundation

```text
LORD: TAKE ALL WARRIORS / AI KING PEOPLE CITY LAND ALREADY GIVEN
-> SKIP S070-E006 / YOINK
-> AMBUSH ORDER + GOODS/LIVESTOCK EXCEPTION
-> 30,000 SENT BY NIGHT
-> AMBUSH INSTALLED WEST / ABOUT 5,000 ALSO STATED WEST
-> NORTH FORCE APPROACHES
-> AI EMPTIES CITY TO PURSUE FEIGNED FLIGHT
-> JAVELIN SIGNAL
-> AMBUSH TAKES AND BURNS CITY
-> FEIGNED FLEEING FORCE TURNS
-> AI FORCE ENCLOSED / KING CAPTURED ALIVE
-> 12,000 AI PEOPLE FALL / GOODS AND LIVESTOCK TAKEN
-> AI BURNED / KING HANGED THEN REMOVED / STONE HEAP
-> EBAL ALTAR / OFFERINGS
-> LAW COPY ON STONES
-> ARK-CENTERED GERIZIM/EBAL ASSEMBLY
-> BLESSING + CURSE + EVERY COMMANDED WORD READ
```

## Joshua 8:1–2 — GIVEN BEFORE THE AMBUSH EXISTS

The LORD tells Joshua not to fear, to take all the warriors and go to Ai. Before
the ambush is set, the army approaches, Ai responds, the city is entered or the
king is captured, the LORD says the king, people, city and land of Ai have been
given into Joshua's hand. The later required process is then supplied: treat Ai
as Jericho, except retain its goods and livestock, and set an ambush behind it.

> **SKIP -> S070-E006-JOS6 — CITY GIVEN BEFORE SHOUT, FALL AND CAPTURE**

`S070-E007-JOS8` closes. Captain says **“YOINK!”**, pokes, licks and leaves.
The ambush still has to be executed.

## Joshua 8:3–13 — THIRTY THOUSAND, ABOUT FIVE THOUSAND, NORTH AND WEST

Joshua rises with all the warriors and selects thirty thousand mighty men,
sending them by night. He orders the ambush behind Ai, not far from the city,
while Joshua's visible force approaches and deliberately flees as at the first
attack. The pursuers are to be drawn away; the ambush is then to rise, possess
the city and burn it.

The sent force stays between Bethel and Ai on Ai's west. Joshua remains among
the people overnight, rises, musters them and camps north of Ai with a valley
between. The source then states that Joshua takes about five thousand and sets
them in ambush between Bethel and Ai on the west. It does not state whether the
five thousand are a subset of the thirty thousand, a second force, or another
description. Both addressed counts and placements remain; no arithmetic bridge
is invented.

## Joshua 8:14–23 — THE SECOND FLIGHT IS THE PLAN

Ai's king and people come out at the appointed time without knowing the ambush
is behind the city. Joshua and Israel make as if beaten and flee toward the
wilderness. Ai and Bethel's available pursuers leave the city open.

The LORD tells Joshua to stretch the javelin toward Ai and says the city will
be given into his hand. This is future wording during the still-running process,
not another completed-state contradiction. Joshua stretches the javelin; the
ambush runs, enters, takes and burns the city. The pursuers see smoke and lose
both escape directions. The feigned-flight force turns, the ambush exits behind
them, and Ai is enclosed. None remain or escape from the addressed force. The
king of Ai is captured alive and brought to Joshua.

The second flight does not contradict the first defeat: this chapter explicitly
states the plan, the performance and the later turn.

## Joshua 8:24–29 — TWELVE THOUSAND, GOODS RETAINED, CITY AND KING CLOSED

Israel finishes the field and wilderness killing, returns to Ai and strikes the
city. The source totals twelve thousand men and women, all the people of Ai.
Joshua keeps the javelin extended until the destruction is complete. Israel
takes the livestock and goods under the stated exception.

Joshua burns Ai into a lasting heap. The king—captured alive earlier—is hanged
on a tree until evening, removed at sundown, thrown at the gate entrance and
covered by a great stone heap. Capture, hanging, removal and heap are sequential
states, not competing outcomes.

## Joshua 8:30–35 — UNCUT ALTAR, COPY, TWO SIDES, EVERY WORD

Joshua builds an altar to the LORD on Mount Ebal using uncut stones untouched
by iron, following the written Moses command. Burnt and peace offerings are
performed. Joshua writes a copy of Moses' law on stones in Israel's presence.

All Israel, elders, officers and judges stand on both sides of the ark before
the Levitical priests, with foreigner and native included: half toward Gerizim,
half toward Ebal. Joshua reads all the law, blessing and curse. The narrator
closes the chapter by saying no word Moses commanded is omitted before the
assembly, including women, little ones and resident foreigners.

The copy, the positioning and the reading are separate completed acts. No claim
is added about the copy's exact length, inscription layout, reading duration or
the altar stones being identical to the written-on stones.

## Character and world-ledger changes

- `S070-E007-JOS8` recurs before the ambush/capture process and points to `S070-E006-JOS6`;
- one causally-null Captain `YOINK!`; SKIP explains nothing and changes nothing;
- the thirty-thousand and about-five-thousand ambush statements remain separately retained;
- Israel's flight is an explicitly planned performance, not a new defeat contradiction;
- Ai's capture, twelve-thousand death total, retained goods/livestock, burning and king outcome complete;
- Mount Ebal altar, offerings, law copy and full assembly reading complete;
- every living human, animal or plant Joe and face-like non-divine javelin, wall, gate, flame, stone, altar, book, ark or letter carrier is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — RUN AWAY CORRECTLY THIS TIME`;
- CrackFlix: `SKIP -> S070-E006-JOS6`;
- night manifest: `30,000`;
- west-side manifest: `ABOUT 5,000 / RELATION UNRESOLVED`;
- tactical status: `BEATEN-LOOKING: DELIBERATE`;
- javelin signal: `DO NOT RETRACT UNTIL COMPLETE`;
- city receipt: `12,000 / GOODS + LIVESTOCK RETAINED`;
- stone terminal: `ALTAR / COPY / HEAP — DO NOT MERGE`;
- barcode: `CHB-JOS8-35-S070E007-AI-EBAL-1YOINK-HELD`.

## FIR verification

- all 35 verse markers are represented in order;
- the completed-gift assertion precedes the described necessary capture acts;
- S070 recurrence points backward exactly and SKIP remains noncausal;
- one Captain occurrence follows closure and changes nothing;
- the later “will give” wording is not upgraded into a second contradiction;
- thirty-thousand and about-five-thousand forces are not silently merged or added;
- feigned flight remains distinct from Joshua 7's actual defeat;
- capture, destruction, retained goods, king outcome, altar, copy and reading retain their order;
- publication remains held and unpublished.

Continuation required: Joshua 9 observes the Gibeonite disguise, Israel's
unasked inquiry, oath, discovery and retained servant assignment.
