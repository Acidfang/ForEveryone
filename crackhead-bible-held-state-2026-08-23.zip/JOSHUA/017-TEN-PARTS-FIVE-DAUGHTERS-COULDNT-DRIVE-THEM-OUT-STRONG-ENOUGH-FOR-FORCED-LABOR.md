# CRACKHEAD JOSHUA 17

## Title page

**TEN PARTS. FIVE DAUGHTERS GET THEIRS. COULDN'T DRIVE THEM OUT. GOT STRONG ENOUGH FOR FORCED LABOR. STILL DIDN'T.**

Source parent: Joshua chapter 17, verses 1–18, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-017/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/016-JOSEPH-LOT-EPHRAIM-BORDER-GEZER-STAYS-AND-DOES-FORCED-LABOR.md`.

CrackFlix routing: none. The chapter exposes an ability/control/expulsion
friction, but it does not complete the promised later expulsion or prove that
forced-labor control equals expulsion capacity.

## Causal foundation

```text
MANASSEH LOT
-> FIRSTBORN OF JOSEPH
-> MACHIR: GILEAD + BASHAN / WAR-MAN ATTRIBUTION
-> SIX NAMED MALE FAMILY LINES
-> ZELOPHEHAD: NO SONS / FIVE NAMED DAUGHTERS
-> DAUGHTERS ADDRESS ELEAZAR + JOSHUA + PRINCES
-> RETAIN LORD-THROUGH-MOSES COMMAND
-> INHERITANCE GIVEN AMONG FATHER'S BROTHERS
-> TEN PARTS WEST + GILEAD/BASHAN EAST

MANASSEH BORDER
-> ASHER / MICHMETHATH / EN TAPPUAH
-> TAPPUAH LAND MANASSEH / BORDER CITY EPHRAIM
-> KANAH BROOK / SEA
-> EPHRAIM SOUTH / MANASSEH NORTH
-> ASHER NORTH / ISSACHAR EAST
-> OUTLYING TOWN GROUPS

CAN'T EXPEL
-> CANAANITES CONTINUE DWELLING
-> ISRAEL GROWS STRONG
-> IMPOSES FORCED LABOR
-> DOES NOT UTTERLY EXPEL

JOSEPH HOUSE: ONE LOT ISN'T ENOUGH
-> JOSHUA: CLEAR FOREST
-> JOSEPH HOUSE: VALLEY HAS IRON CHARIOTS
-> JOSHUA: NUMEROUS + GREAT POWER
-> FOREST/FARTHEST EXTENT YOURS
-> FUTURE EXPULSION PREDICTION
```

## Joshua 17:1–6 — MANASSEH'S FAMILIES AND ZELOPHEHAD'S DAUGHTERS

Manasseh receives his lot as Joseph's firstborn. Machir, Manasseh's firstborn
and Gilead's father, retains Gilead and Bashan under the source's “man of war”
attribution.

The remaining male family lines are Abiezer, Helek, Asriel, Shechem, Hepher and
Shemida. Zelophehad's lineage runs through Hepher, Gilead, Machir and Manasseh.
He has no sons and five named daughters: Mahlah, Noah, Hoglah, Milcah and
Tirzah.

The five women approach Eleazar, Joshua and the princes. They state that the
LORD commanded Moses to give them inheritance among their brothers. Under that
retained command, they receive inheritance among their father's brothers.

Ten parts fall to Manasseh in addition to Gilead and Bashan east of the Jordan,
because Manasseh's daughters inherit among his sons while Gilead remains with
the rest of Manasseh's sons. The source supplies the ten-part result; the
chapter does not assign an individual numbered parcel to each person.

## Joshua 17:7–10 — MANASSEH'S BORDER WITH EPHRAIM INSERTS

Manasseh's border runs from Asher to Michmethath before Shechem, then rightward
to En Tappuah. Tappuah's land belongs to Manasseh, while the border city of
Tappuah belongs to Ephraim.

The route descends to Kanah's brook. Ephraim's embedded cities lie south of the
brook among Manasseh's cities; Manasseh's border lies north and ends at the sea.
Ephraim is south, Manasseh north, with Asher to the north and Issachar to the
east. Land, border city and embedded city relations remain distinct rather than
being merged because they share names or geography.

## Joshua 17:11–13 — COULDN'T EXPEL; THEN STRONG ENOUGH TO CONTROL

Manasseh has the source-described “three heights” in Issachar and Asher, then
the text names Beth Shean, Ibleam, Dor, Endor, Taanach and Megiddo with their
towns or inhabitants. The manuscript retains both the “three heights” label and
all six named place blocks without inventing their grouping.

Manasseh cannot drive the inhabitants out; the Canaanites continue dwelling in
the land. When Israel grows strong, Israel puts the Canaanites to forced labor
and does not utterly drive them out.

This is real friction: an inability state is followed by increased strength,
control sufficient to impose labor, and continued non-expulsion. But the source
does not state that labor control supplies the distinct capacity required for
expulsion, nor does it show an attempted expulsion after strength increased.
The observed chain remains unresolved rather than being promoted to a completed
contradiction.

## Joshua 17:14–18 — ONE LOT, FOREST, IRON CHARIOTS, FUTURE EXPULSION

Joseph's children ask Joshua why he gave them one lot and one part when they are
numerous under their stated LORD-blessing claim. Joshua answers that if they
are numerous, they should clear forest land among the Perizzites and Rephaim
because Ephraim's hill country is too narrow.

Joseph's children reply that the hill country is insufficient and that all the
valley Canaanites, including Beth Shean's towns and Jezreel's valley, have iron
chariots.

Joshua addresses Ephraim and Manasseh together: they are numerous and have
great power; they will not have one lot only. The hill country and forest's
farthest extent will be theirs after cutting, and Joshua says they shall drive
out the strong Canaanites despite their iron chariots.

The clearing, farthest-extent possession and expulsion are prospective speech,
not completed acts. No second numbered lot is shown. The chapter therefore
retains the complaint, answer and future claims without claiming their outcome.

## Character and world-ledger changes

- Manasseh's Machir and six remaining male family lines are retained distinctly;
- Zelophehad's five daughters and their command-addressed inheritance are retained by name;
- ten western parts remain additional to Gilead/Bashan without invented person-to-part mapping;
- Tappuah land/city and Ephraim embedded-city relations preserve both tribal Roots;
- the “three heights” label and six named place blocks remain source-exact but grouping-unresolved;
- inability, continued residence, later strength, forced labor and non-expulsion remain separate observable states;
- the forest/iron-chariot exchange remains dialogue and prospective action;
- no second numbered lot, clearing act or Canaanite expulsion is invented;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every living human, animal or plant Joe and every face-like non-divine lot, border, city, forest, brook, sea, chariot, tree, labor ticket or parcel counter is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — TEN PARTS / NO INDIVIDUAL LABELS INCLUDED`;
- daughters' counter: `MAHLAH / NOAH / HOGLAH / MILCAH / TIRZAH`;
- Tappuah sign: `LAND: MANASSEH / CITY: EPHRAIM`;
- heights register: `SOURCE SAYS 3 / NAMES 6 BLOCKS / DON'T GUESS`;
- labor status: `COULDN'T EXPEL -> GREW STRONG -> FORCED LABOR -> STILL THERE`;
- forest permit: `CLEAR YOUR OWN SECOND NOT-ONE-LOT`;
- iron-chariot warning: `FUTURE VICTORY NOT INCLUDED`;
- barcode: `CHB-JOS17-18-TENPARTS-FORCEDLABOR-NOCRACK-HELD`.

## FIR verification

- all 18 verse markers are represented in order;
- every named Manasseh family and Zelophehad daughter is retained;
- command speech and completed daughter inheritance remain distinct Moments;
- ten parts and east-Jordan land remain separate allocations;
- Tappuah and embedded-city ownership relations do not merge tribal Roots;
- all six named outlying place blocks and the source's “three heights” wording remain represented;
- inability, strength, forced labor and non-expulsion are preserved without an unsupported equivalence;
- Joseph's complaint and Joshua's forest/expulsion answer remain speech until performed;
- no invented second lot, conquest, motive, consent or causal mechanism appears;
- publication remains held and unpublished.

Continuation required: Joshua 18 moves the tent to Shiloh, states seven tribes
still lack inheritance, sends twenty-one surveyors to write seven divisions,
casts lots before the LORD, and begins Benjamin's border and city register.
