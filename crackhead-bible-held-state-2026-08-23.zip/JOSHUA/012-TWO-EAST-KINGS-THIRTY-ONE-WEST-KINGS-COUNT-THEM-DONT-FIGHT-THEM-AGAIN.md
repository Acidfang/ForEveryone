# CRACKHEAD JOSHUA 12

## Title page

**TWO EAST KINGS. THIRTY-ONE WEST KINGS. COUNT THEM. DON'T FIGHT THEM AGAIN.**

Source parent: Joshua chapter 12, verses 1–24, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-012/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/011-TOMORROW-NORTHERN-ARMIES-HAZOR-ONLY-BURNED-LONG-WAR-WHOLE-LAND-RESTS.md`.

CrackFlix routing: none. This chapter inventories retained outcomes; it does not
repeat their execution or complete a new contradiction.

## Causal foundation

```text
EAST-JORDAN RESULT SET
-> SIHON + EXACT TERRITORY
-> OG + EXACT TERRITORY
-> MOSES/ISRAEL STRUCK THEM
-> MOSES GAVE POSSESSION TO REUBEN/GAD/HALF-MANASSEH

WEST-JORDAN RESULT SET
-> JOSHUA/ISRAEL STRUCK KINGS
-> JOSHUA GAVE LAND TO TRIBAL DIVISIONS
-> SIX TERRAIN CLASSES / SIX PEOPLE CLASSES
-> THIRTY-ONE KING-PLACE ENTRIES
-> SOURCE TOTAL: THIRTY-ONE
```

## Joshua 12:1–6 — EAST OF JORDAN: SIHON, OG, MOSES' POSSESSION ROUTE

The chapter first inventories the kings struck eastward from the Jordan, from
Arnon to Hermon and through the eastern Arabah.

Sihon of Heshbon retains his Aroer/Arnon, half-Gilead/Jabbok, Chinneroth/Salt
Sea, Beth Jeshimoth and Pisgah territory description. Og of Bashan retains his
Rephaim-remnant identity, Ashtaroth/Edrei residence and Hermon, Salecah, Bashan,
Geshurite/Maacathite and half-Gilead borders.

Moses and Israel are the retained striking actors. Moses gives the possession
to Reuben, Gad and half-Manasseh. These statements point to completed parent
campaigns; no king is fought again.

## Joshua 12:7–8 — WEST OF JORDAN: JOSHUA'S RESULT SET

The westward inventory runs from Baal Gad in Lebanon's valley to Mount Halak
toward Seir. Joshua and Israel are the striking actors; Joshua gives possession
to Israel's tribal divisions. The terrain classes remain hill country, lowland,
Arabah, slopes, wilderness and South. The people classes remain Hittite,
Amorite, Canaanite, Perizzite, Hivite and Jebusite.

East and west result sets share the book ledger but do not lose their distinct
executor, territory or recipient relations.

## Joshua 12:9–24 — THIRTY-ONE WEST-JORDAN KING ENTRIES

The source counts each king-place occurrence as one:

1. Jericho
2. Ai beside Bethel
3. Jerusalem
4. Hebron
5. Jarmuth
6. Lachish
7. Eglon
8. Gezer
9. Debir
10. Geder
11. Hormah
12. Arad
13. Libnah
14. Adullam
15. Makkedah
16. Bethel
17. Tappuah
18. Hepher
19. Aphek
20. Lassharon
21. Madon
22. Hazor
23. Shimron Meron
24. Achshaph
25. Taanach
26. Megiddo
27. Kedesh
28. Jokneam in Carmel
29. Dor in the height of Dor
30. Goiim in Gilgal
31. Tirzah

The final stated total is thirty-one. The list is an inventory occurrence: it
retains each prior or summarized outcome address without inventing missing
battle detail for entries not individually narrated earlier.

## Character and world-ledger changes

- Sihon and Og histories are retained under Moses' east-Jordan route;
- Reuben/Gad/half-Manasseh possession remains distinct from Joshua's western distribution;
- thirty-one west-Jordan king-place entries are retained and counted exactly;
- the list does not duplicate battle, death, city or possession acts;
- absent individual battle detail remains absent rather than reconstructed from the count;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every living human, animal or plant Joe and face-like non-divine king token, map, border, mountain, river, sea or counter is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — DEFEATED KING STOCKTAKE`;
- east register: `SIHON + OG / MOSES ROUTE`;
- west register: `JOSHUA ROUTE`;
- terrain selector: `HILL / LOW / ARABAH / SLOPE / WILD / SOUTH`;
- counter: `01 ... 31`;
- warning: `AN INVENTORY IS NOT ANOTHER BATTLE`;
- barcode: `CHB-JOS12-24-2E-31W-NOCRACK-HELD`.

## FIR verification

- all 24 verse markers are represented in order;
- east and west executor/territory/recipient sets remain distinct;
- all thirty-one west-Jordan king-place entries appear once in source order;
- the stated total matches the listed count;
- prior histories are referenced without duplicate execution;
- unknown individual battle details remain unresolved;
- no unsupported contradiction machinery is introduced;
- publication remains held and unpublished.

Continuation required: Joshua 13 places Joshua in old age, states much land
remains, gives remaining-territory and east-allocation details, and opens the
inheritance phase.
