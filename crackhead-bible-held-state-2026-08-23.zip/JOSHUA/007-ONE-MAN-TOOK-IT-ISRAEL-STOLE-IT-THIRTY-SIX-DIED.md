# CRACKHEAD JOSHUA 7

## Title page

**ONE MAN TOOK IT. ISRAEL STOLE IT. THIRTY-SIX DIED.**

Source parent: Joshua chapter 7, verses 1–26, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-007/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/006-CITY-ALREADY-GIVEN-MARCH-SEVEN-DAYS-GIVEN-AGAIN-SHOUT-WALL-FALLS.md`.

CrackFlix routing: new `S127-E001-JOS7`. No SKIP. One causally-null
post-closure `YOINK!` occurrence.

## Causal foundation

```text
ACHAN TAKES DEVOTED THINGS
-> LORD'S ANGER BURNS AGAINST ISRAEL
-> AI SCOUTS RECOMMEND ABOUT TWO OR THREE THOUSAND
-> ABOUT THREE THOUSAND GO / FLEE / ABOUT THIRTY-SIX DIE
-> JOSHUA AND ELDERS FALL BEFORE THE ARK
-> LORD: ISRAEL TOOK / STOLE / DECEIVED / PUT IT WITH THEIR STUFF
-> S127-E001 CLOSES / YOINK
-> PEOPLE SANCTIFIED
-> TRIBE -> FAMILY -> HOUSEHOLD -> MAN
-> ACHAN SELECTED / CONFESSES
-> ROBE + 200 SILVER + 50 GOLD RECOVERED
-> ACHAN + LISTED PEOPLE / ANIMALS / PROPERTY TAKEN TO ACHOR
-> HIM STONED / THEM BURNED AND STONED — REFERENTS NOT SUPPLIED
-> STONE HEAP / ANGER TURNS / VALLEY NAMED
```

## Joshua 7:1–5 — ONE NAMED TAKER, COLLECTIVE ANGER, THIRTY-SIX DEAD

The narrator says the children of Israel commit trespass in the devoted things,
then supplies the addressed act: Achan, son of Carmi, son of Zabdi, son of Zerah,
of Judah, takes some devoted things. The LORD's anger burns against the children
of Israel.

Joshua sends men to spy Ai. They return and advise sending about two or three
thousand because Ai's people are few. About three thousand go, flee before Ai,
and about thirty-six are struck. The survivors are chased from the gate to
Shebarim and struck at the descent. The people's hearts melt and become like
water.

The scouts' estimate and the defeat are retained as distinct observed states.
Being wrong is not independently treated as contradiction.

## Joshua 7:6–12 — “ISRAEL HAS SINNED. THEY HAVE TAKEN.”

Joshua and Israel's elders tear their clothes, fall face-down before the LORD's
ark until evening and put dust on their heads. Joshua asks why the people were
brought across the Jordan, describes Israel turning its back, predicts what the
land's inhabitants will do and asks what the LORD will do for the LORD's name.
The predicted surrounding and name-cutting do not occur here.

The LORD orders Joshua to get up. The reply assigns the completed taking,
stealing, deceiving and placement among “their own stuff” to Israel. The source
has already identified Achan as the person who took the devoted things, while
about thirty-six other men have died before the later selection process.

`S127-E001-JOS7` closes at that retained relation:

> **ONE MAN TOOK IT. ISRAEL STOLE IT. THIRTY-SIX DIED.**

No collective-liability, knowledge-transfer or casualty-allocation mechanism is
supplied. Captain says **“YOINK!”**, pokes, licks and leaves. The response and
selection process remain unchanged.

## Joshua 7:13–18 — SANCTIFY, THEN REDUCE THE ADDRESS

The LORD commands sanctification for tomorrow because a devoted thing remains
among Israel. Israel cannot stand before enemies until it is removed. The
morning selector is stated in order: tribes, families, households, then man by
man. The selected person and all he has are assigned the stated fire outcome.

Joshua executes the selection the next morning: Judah, the Zerahites, Zabdi,
then Achan son of Carmi, son of Zabdi, son of Zerah. No selection mechanism is
added beyond the source wording that the LORD selects.

## Joshua 7:19–23 — ACHAN'S OWN WORDS AND THE VERIFIED CACHE

Joshua asks Achan to give glory, confess, state what he did and not hide it.
Achan says he sinned and gives the sequence: he saw a beautiful Babylonian
robe, two hundred shekels of silver and a fifty-shekel wedge of gold; coveted
them; took them; and hid them in the ground in the middle of his tent, with the
silver underneath.

Messengers run to the tent and find the cache in the described location. They
take the objects, bring them to Joshua and all Israel and lay them before the
LORD. The confession receives an observable object-and-location verification.

## Joshua 7:24–26 — LISTED TRANSPORT, PRONOUN-BOUND EXECUTION, STONE HEAP

Joshua and all Israel take Achan, the silver, robe, gold, his sons and daughters,
cattle, donkeys, sheep, tent and all he has to the valley of Achor. Transport is
explicit. The source does not assign Achan's confession, taking, knowledge or
guilt to his family.

Joshua asks why Achan troubled them and says the LORD will trouble him that day.
All Israel stones **him**; the text then says they burned **them** and stoned
**them**. The referent and living/dead state of every member of “them” are not
resolved by the supplied grammar. The comic may show only what the text fixes:
the listed group and property transported, Achan addressed, “him” stoned, and
an unresolved plural burn/stone act. It may not silently choose family guilt,
individual execution order or animal/object inclusion.

A great stone heap is raised over him. The LORD turns from fierce anger, and
the place is called the valley of Achor to the narrator's “this day.”

## Character and world-ledger changes

- Achan's taking, confession and cache location are explicit and verified;
- Ai defeats about three thousand attackers and kills about thirty-six;
- `S127-E001-JOS7` retains the named-act / collective-attribution / casualty relation;
- one causally-null Captain `YOINK!`; no SKIP because this contradiction type is new;
- tribe-to-family-to-household-to-man selection completes;
- the listed people, animals and property reach Achor;
- singular “him” and plural “them” remain grammatically distinct and the plural referents remain unresolved;
- no guilt, knowledge, motive or act is invented for Achan's family;
- every living human, animal or plant Joe and face-like non-divine robe, silver, gold, tent, stone, ark, dust or fire carrier is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — COLLECTIVE ACCOUNTING DEPARTMENT`;
- scout ticket: `AI: FEW PEOPLE / SEND 2K–3K`;
- loss receipt: `ABOUT 36`;
- CrackFlix: `S127-E001 — ONE MAN TOOK IT / ISRAEL STOLE IT`;
- selection funnel: `TRIBE > FAMILY > HOUSEHOLD > MAN`;
- cache label: `ROBE / Ag 200 / Au 50 / SILVER UNDER`;
- pronoun warning: `HIM != AUTOMATICALLY THEM`;
- barcode: `CHB-JOS7-26-S127-ACHOR-1YOINK-NOSKIP-HELD`.

## FIR verification

- all 26 verse markers are represented in order;
- Achan alone retains the explicit taking/confession chain;
- Israel retains the source's collective attribution without an invented mechanism;
- the roughly thirty-six deaths precede selection and confession;
- scout advice is not upgraded into contradiction merely because the outcome differs;
- S127 is new, so SKIP is absent;
- Captain occurs only after the contradiction closes and changes nothing;
- the final singular/plural execution grammar remains unresolved rather than reconstructed by assumption;
- publication remains held and unpublished.

Continuation required: Joshua 8 observes the Ai ambush, city capture, altar,
law copy and blessing/curse reading.
