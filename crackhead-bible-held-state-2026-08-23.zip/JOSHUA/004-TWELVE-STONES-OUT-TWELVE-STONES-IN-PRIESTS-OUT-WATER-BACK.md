# CRACKHEAD JOSHUA 4

## Title page

**TWELVE STONES OUT. TWELVE STONES IN. PRIESTS OUT. WATER BACK.**

Source parent: Joshua chapter 4, verses 1–24, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-004/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/003-FOLLOW-THE-ARK-STAY-BACK-FEET-IN-WATER-EVERYONE-CROSSES-DRY.md`.

CrackFlix routing: none. The two twelve-stone placements have distinct origins and destinations.

## Causal foundation

```text
WHOLE NATION ACROSS / PRIESTS STILL MIDSTREAM
-> TWELVE TRIBAL MEN TAKE TWELVE STONES FROM PRIEST-FOOT PLACE
-> CARRY OUT + LAY AT CAMP / LATER GILGAL
-> JOSHUA SETS TWELVE OTHER STONES AT MIDSTREAM FOOT PLACE
-> PEOPLE/ARK/PRIESTS COMPLETE CROSSING
-> EASTERN ARMED MEN CROSS (~40,000)
-> LORD COMMANDS PRIESTS OUT
-> PRIEST SOLES REACH DRY GROUND
-> WATER RETURNS OVER BANKS
-> GILGAL CAMP + OUTER TWELVE-STONE MEMORIAL
```

## Joshua 4:1–9 — TWO TWELVE-STONE SETS

After the whole nation has crossed, the LORD commands one man per tribe to take
twelve stones from the Jordan middle where the priests' feet stood, carry them
over and lay them at the night's camp. Joshua calls the already prepared twelve,
relays the shoulder-carry command, and states the future child-question memorial
answer: the waters were cut off before the covenant ark.

Israel performs the command, carrying twelve stones out and laying them at camp.
Separately, Joshua sets twelve stones in the Jordan middle at the priest-foot
place. The source says the inner set remains there to its “this day.” The sets
are not merged: one is extracted and carried; one is installed midstream.

## Joshua 4:10–14 — ARK EXIT, ARMED EASTERN CROSSING, JOSHUA MAGNIFIED

The priests remain midstream until the commanded speech/work is finished while
the people hurry across. Once all people have crossed, the ark and priests cross
in their presence. Reuben, Gad and half-Manasseh cross armed as Moses said;
about forty thousand ready for war pass toward Jericho's plains. Their armed-
help act begins, but western rest and their return remain future.

The source says the LORD magnifies Joshua that day and Israel fears him as it
feared Moses during his life. This is the stated public effect; private feelings
or permanent future conduct are not invented.

## Joshua 4:15–20 — PRIEST FEET OUT; WATER BACK; GILGAL

The LORD tells Joshua to command the ark priests out. Joshua does. When the
priests leave the Jordan middle and their soles reach dry ground, the Jordan
returns to its place and again overflows its banks. This closes Joshua 3's held
priest and water states.

The people emerge on the tenth day of the first month and camp at Gilgal east of
Jericho. Joshua sets up at Gilgal the twelve stones carried out of the Jordan.

## Joshua 4:21–24 — THE MEMORIAL'S FUTURE ANSWER

Joshua gives the future child-question script: Israel crossed this Jordan on
dry land; the LORD dried it until crossing was complete, as attributed for the
Red Sea, so peoples may know the LORD's mighty hand and Israel may fear the LORD.
The Red Sea remains a history comparison, not a repeated event. Future questions,
knowledge and perpetual fear remain prospective.

## Character and world-ledger changes

- the carried-out twelve stones and midstream twelve stones remain distinct sets;
- the ark priests exit and Jordan water returns to flood-stage banks;
- Reuben/Gad/half-Manasseh armed participation begins with about forty thousand;
- western rest and eastern return remain future;
- Israel camps at Gilgal on first-month day ten;
- the outer memorial is installed at Gilgal;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every living human, animal or plant Joe and face-like non-divine ark, stone, river, foot, shoulder, camp or memorial is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — DUAL TWELVE-STONE MEMORY SYSTEM`;
- set A: `MIDSTREAM -> SHOULDERS -> GILGAL`;
- set B: `MIDSTREAM -> STAYS MIDSTREAM`;
- priest status: `OUT`;
- river status: `BANKS OVERFLOWING AGAIN`;
- eastern army counter: `ABOUT 40,000 / RETURN PENDING`;
- child prompt: `WHAT DO THESE STONES MEAN?`;
- barcode: `CHB-JOS4-24-24STONES-WATER-RETURN-NOCRACK-HELD`.

## FIR verification

- all 24 verse markers are represented in order;
- two twelve-stone sets retain separate acts and destinations;
- priest exit causally precedes water return;
- armed crossing does not complete rest or return;
- Red Sea remains a history pointer;
- future child questions/effects are not instantiated;
- no unsupported contradiction machinery or divine form appears;
- publication remains held and unpublished.

Continuation required: Joshua 5 observes west-Jordan king reactions,
circumcision/healing, Passover, manna cessation and the sword-bearing commander.
