# CRACKHEAD JOSHUA 5

## Title page

**CIRCUMCISE. HEAL. PASSOVER. MANNA STOPS. “FOR US OR THEM?” “NO.”**

Source parent: Joshua chapter 5, verses 1–15, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-005/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/004-TWELVE-STONES-OUT-TWELVE-STONES-IN-PRIESTS-OUT-WATER-BACK.md`.

CrackFlix routing: none. The commander rejects a two-option question and supplies a third identity; no contradiction is completed.

## Causal foundation

```text
WESTERN KINGS HEAR JORDAN CROSSING -> HEART/SPIRIT REACTION
-> LORD COMMANDS SECOND CIRCUMCISION
-> FLINT KNIVES / WILDERNESS-BORN GENERATION CIRCUMCISED
-> WHOLE NATION STAYS IN CAMP UNTIL HEALED
-> EGYPT REPROACH ROLLED AWAY / GILGAL NAME
-> PASSOVER DAY 14
-> LAND PRODUCE EATEN NEXT DAY
-> MANNA CEASES / CANAAN PRODUCE CONTINUES
-> DRAWN-SWORD MAN APPEARS
-> “FOR US OR ENEMIES?” -> “NO; LORD'S ARMY COMMANDER”
-> JOSHUA WORSHIPS / REMOVES SANDALS
```

## Joshua 5:1 — WEST-BANK KINGS HEAR

Amorite kings west of Jordan and Canaanite kings by the sea hear that the LORD
dried Jordan until Israel crossed. The source states their hearts melted and no
spirit remained because of Israel. This is an observed narrator-attributed
reaction; no meeting, plan or individual king identity is invented.

## Joshua 5:2–9 — SECOND CIRCUMCISION, THEN HEALING

The LORD commands Joshua to make flint knives and circumcise Israel again a
second time. Joshua makes the knives and performs the act at the named hill.
The narrator separates the Egypt-exit circumcised fighting generation—dead in
the wilderness after not listening—from the wilderness-born uncircumcised
children raised in their place. The whole nation remains in camp until healed.

The LORD then says Egypt's reproach has been rolled away; the place is called
Gilgal at the source's “this day.” The source does not define the reproach's
physical mechanism, so none is supplied.

## Joshua 5:10–12 — PASSOVER, PRODUCE, MANNA CESSATION

At Gilgal, Israel keeps Passover on first-month day fourteen at evening. The
next day they eat unleavened cakes and parched grain from the land's produce.
Manna ceases the following day after that produce is eaten; Israel has no more
manna and eats Canaan's fruit that year. The transition is sequential, not an
instant retroactive replacement.

## Joshua 5:13–15 — “FOR US OR OUR ENEMIES?” “NO.”

Near Jericho, Joshua sees a man standing before him with a drawn sword. Joshua
asks whether he is for Israel or its enemies. The man says:

> **NO; BUT I HAVE COME NOW AS COMMANDER OF THE LORD'S ARMY.**

The answer rejects the offered binary and states his role. It does not establish
an unstated allegiance category, personal name, species, origin, divinity or
later battle act. Joshua falls face-down, worships and asks for instruction.
The commander tells him to remove his sandals because the place is holy; Joshua
does so. A source-described living man receives Joe's face if shown. No separate
divine face or form is invented.

## Character and world-ledger changes

- west-bank king reaction to the completed crossing is recorded;
- wilderness-born Israel is circumcised and waits until healed;
- Gilgal's roll-word name relation is retained;
- Passover and land-produce eating complete;
- manna provision ends after produce consumption;
- the sword-bearing man identifies himself only as commander/prince of the LORD's army;
- Joshua's worship, question, sandal removal and holy-place instruction complete;
- no contradiction, CrackFlix, Captain, SKIP or YOINK occurs;
- every living human, animal or plant Joe and face-like non-divine knife, manna, grain, sword, sandal or camp carrier is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — WEST-BANK BODY/FUEL/COMMANDER TRANSITION`;
- procedure: `FLINT -> CIRCUMCISE -> WAIT UNTIL HEALED`;
- Gilgal label: `REPROACH: ROLLED`;
- food ledger: `PASSOVER -> PRODUCE -> MANNA OFF`;
- allegiance selector: `US / THEM / NO`;
- commander badge: `LORD'S ARMY — NAME UNSUPPLIED`;
- ground warning: `SANDALS OFF`;
- barcode: `CHB-JOS5-15-HEALED-MANNAOFF-COMMANDER-NOCRACK-HELD`.

## FIR verification

- all 15 verse markers are represented in order;
- exit generation and wilderness-born generation remain distinct;
- circumcision precedes healing wait and Gilgal statement;
- Passover/produce/manna cessation remain sequential;
- “No” is not misclassified as contradiction;
- commander identity is not expanded beyond source wording;
- no divine body, battle outcome or unsupported motive is invented;
- publication remains held and unpublished.

Continuation required: Joshua 6 supplies the Jericho marching protocol,
wall-fall, destruction, Rahab rescue and city curse.
