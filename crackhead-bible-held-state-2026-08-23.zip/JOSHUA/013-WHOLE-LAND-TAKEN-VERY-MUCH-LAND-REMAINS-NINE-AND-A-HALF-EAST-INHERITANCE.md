# CRACKHEAD JOSHUA 13

## Title page

**WHOLE LAND TAKEN. VERY MUCH LAND REMAINS. NINE AND A HALF GET THE WEST. THE EAST ALREADY HAS RECEIPTS.**

Source parent: Joshua chapter 13, verses 1–33, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-013/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/012-TWO-EAST-KINGS-THIRTY-ONE-WEST-KINGS-COUNT-THEM-DONT-FIGHT-THEM-AGAIN.md`.

CrackFlix routing: `S130-E001-JOS13`. New contradiction type, so no SKIP.

## Causal foundation

```text
JOSHUA 11:23: JOSHUA TOOK THE WHOLE LAND
+ JOSHUA 13:1: VERY MUCH LAND REMAINS TO BE POSSESSED
+ JOSHUA 13:2-6: THE REMAINING LAND IS LISTED
+ NO SCOPE PARTITION / LOSS / REOCCUPATION BRIDGE
-> S130-E001-JOS13
-> ONE CAUSALLY NULL POST-CLOSURE YOINK

REMAINING WESTERN LAND
-> LORD FUTURE DRIVE-OUT SPEECH
-> ALLOCATE NOW
-> NINE TRIBES + WESTERN HALF-MANASSEH

ALREADY DISTRIBUTED EASTERN LAND
-> REUBEN + GAD + EASTERN HALF-MANASSEH
-> EXACT BORDERS / CITIES / FAMILY RECIPIENTS
-> LEVI HAS NO LAND ALLOTMENT
-> OFFERINGS / LORD ARE LEVI'S STATED INHERITANCE
```

## Joshua 13:1–7 — WHOLE LAND TAKEN / VERY MUCH LAND REMAINS

Joshua is old and advanced in years. The LORD tells him that he is old and that
very much land remains to be possessed.

The remaining inventory is not vague: Philistine and Geshurite regions;
Shihor-to-Ekron territory; the five Philistine lordships and their named peoples;
the Avvim; southern Canaanite land; Mearah, Sidon, Aphek and the Amorite border;
Gebalite land; Lebanon from Baal Gad under Hermon to Hamath; and the hill-country
inhabitants from Lebanon to Misrephoth Maim, including the Sidonians.

Joshua 11:23 retained the completed statement that Joshua took the whole land.
Joshua 13:1–6 now retains a direct statement that very much land remains and
supplies its extent. The source gives no partition, later loss or reoccupation
bridge between those states.

CrackFlix opens **S130 — WHOLE LAND TAKEN. VERY MUCH LAND REMAINS.** This is its
first observed episode, so Captain does not press SKIP. Once both states are on
the page, Captain Crackhead appears in his unexplained suit, touches the boil,
says only **“YOINK!”**, licks his finger, and walks away without looking back.
The allocation continues identically.

The LORD's “I will drive them out” remains future speech. Joshua is commanded to
allocate the land to nine tribes and the western half of Manasseh. The promised
driving-out is not rendered as already performed.

## Joshua 13:8–14 — THE EAST ALREADY HAS ITS INHERITANCE

Reuben, Gad and the eastern half of Manasseh retain the inheritance Moses gave
east of the Jordan: Aroer and the Arnon valley, Medeba to Dibon, Sihon's cities,
Gilead, the Geshurite and Maacathite border, Hermon, Bashan to Salecah and Og's
kingdom at Ashtaroth and Edrei.

Moses' attacks and expulsions are historical parents, not battles performed
again here. Israel did not drive out the Geshurites or Maacathites; the source
says those groups live within Israel to its stated “this day.” This supports the
remaining-land state but does not create another contradiction episode.

Levi receives no land inheritance. Fire offerings to the LORD are stated as
Levi's inheritance. Land allotment and offering inheritance remain different
classes rather than being forced into a mismatch.

## Joshua 13:15–23 — REUBEN'S RECEIPT

Moses' Reuben allocation retains its family boundary and cities: Aroer and the
Arnon valley, Medeba, Heshbon, Dibon, Bamoth Baal, Beth Baal Meon, Jahaz,
Kedemoth, Mephaath, Kiriathaim, Sibmah, Zereth Shahar, Beth Peor, Pisgah's
slopes, Beth Jeshimoth and the plain cities of Sihon's former kingdom.

Sihon and the five named Midian chiefs—Evi, Rekem, Zur, Hur and Reba—remain
historical result addresses. Balaam's sword death is likewise retained as a
history pointer, not executed again. Reuben's Jordan-bank border, cities and
villages close the family inheritance inventory.

## Joshua 13:24–28 — GAD'S RECEIPT

Gad's family inheritance retains Jazer, the Gilead cities, half the Ammonite
land to Aroer near Rabbah, Heshbon to Ramath Mizpeh and Betonim, Mahanaim to
Debir's border, and the valley route through Beth Haram, Beth Nimrah, Succoth
and Zaphon to Chinnereth's sea. The source identifies this as the remainder of
Sihon's kingdom and closes Gad's city-and-village inventory.

## Joshua 13:29–33 — EASTERN HALF-MANASSEH AND LEVI

The eastern half of Manasseh receives its family inheritance from Moses:
Mahanaim, Bashan, Og's former kingdom, Jair's sixty cities, half Gilead,
Ashtaroth and Edrei for half the children of Machir.

These are the distributions Moses made in Moab east of the Jordan at Jericho.
Levi again receives no land inheritance; the LORD, God of Israel, is stated as
their inheritance. The repeated statement closes the east-allocation register
without manufacturing a parcel for Levi.

## Character and world-ledger changes

- Joshua's old-age state and the remaining-land inventory are retained;
- `S130-E001-JOS13` closes only whole-land-taken versus very-much-land-remains;
- Joshua 11's rest-from-war state remains a prior snapshot, not a second inferred crack;
- the LORD's future drive-out speech remains future and no divine form appears;
- nine tribes plus western half-Manasseh remain allocation recipients;
- Reuben, Gad and eastern half-Manasseh retain distinct Moses-distributed receipts;
- Geshurite and Maacathite continued residence is retained without invented cause;
- Levi's land and non-land inheritance classes remain distinct;
- historical campaigns and Balaam's death are referenced without duplicate execution;
- Captain is permanently boilless, says only “YOINK!”, and changes nothing;
- every living human, animal or plant Joe and every face-like non-divine map, border, city, mountain, river, receipt or counter is Joe-faced if shown;
- publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — WHOLE MEANS CHECK THE BACK`;
- CrackFlix card: `S130-E001 / WHOLE LAND TAKEN / LAND STILL INCLUDED`;
- remaining-land printer: `VERY MUCH`;
- west divider: `9 + 1/2 / ALLOCATE BEFORE FUTURE DRIVE-OUT`;
- east receipt stack: `REUBEN / GAD / 1/2 MANASSEH / ALREADY DID`;
- Levi ticket: `NO LAND / DIFFERENT INHERITANCE CLASS`;
- warning: `AN INVENTORY DOES NOT RE-FIGHT THE DEAD`;
- barcode: `CHB-JOS13-33-S130E001-NOSKIP-1YOINK-HELD`.

## FIR verification

- all 33 verse markers are represented in order;
- the Joshua 11 whole-land parent and Joshua 13 remaining-land state are both retained;
- the new contradiction has no invented scope bridge and no SKIP;
- exactly one post-closure Captain YOINK is causally null;
- future divine driving-out is not converted into an occurrence;
- eastern allocations preserve tribe, family, border and executor distinctions;
- historical killings and conquests are not replayed;
- Levi's land and stated inheritance classes are not collapsed;
- unknown mechanisms and missing causation remain unresolved;
- publication remains held and unpublished.

Continuation required: Joshua 14 begins the western inheritance allocation,
retains the nine-and-a-half division, and carries Caleb's forty-year report and
Hebron request into a completed grant.
