# CRACKHEAD JOSHUA 11

## Title page

**TOMORROW: NORTHERN ARMIES. HAZOR ONLY BURNED. LONG WAR. WHOLE LAND RESTS.**

Source parent: Joshua chapter 11, verses 1–23, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-011/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/010-FIVE-ARMIES-ALREADY-DELIVERED-SUN-WAITS-DONT-LET-THEM-IN-REMNANT-GOT-IN.md`.

CrackFlix routing: none. No completed contradiction, Captain, SKIP or YOINK.

## Causal foundation

```text
JABIN SENDS TO NORTHERN KINGS
-> MANY ARMIES / HORSES / CHARIOTS AS SEASHORE SAND
-> COALITION CAMPS AT MEROM
-> LORD: TOMORROW I WILL DELIVER THEM SLAIN
-> COMMAND: HAMSTRING HORSES / BURN CHARIOTS
-> JOSHUA ATTACKS SUDDENLY
-> DELIVERY / STRIKING / THREE-WAY PURSUIT / NONE REMAIN
-> HORSES HAMSTRUNG / CHARIOTS BURNED
-> HAZOR KING STRUCK / HAZOR POPULATION DESTROYED / HAZOR BURNED
-> OTHER KINGDOM CITIES CAPTURED / MOUND CITIES NOT BURNED
-> PLUNDER + LIVESTOCK RETAINED
-> COMMAND CHAIN DECLARED COMPLETE
-> LAND-EXTENT SUMMARY / LONG WAR
-> GIBEON ONLY PEACE EXCEPTION
-> LORD-HARDENING ATTRIBUTION
-> ANAKIM REMOVED FROM ISRAEL LAND / GAZA-GATH-ASHDOD SURVIVORS
-> WHOLE LAND INHERITANCE / REST FROM WAR
```

## Joshua 11:1–6 — NORTHERN COALITION AND A DATED FUTURE PROMISE

Hazor's king Jabin sends to named kings and northern, eastern, western, hill,
lowland, Hermon and Mizpah groups. Their armies gather at Merom, numerous as
seashore sand, with very many horses and chariots.

The LORD tells Joshua not to fear and says **tomorrow at this time** all will be
delivered slain before Israel. Joshua is commanded to hamstring their horses
and burn their chariots.

The statement is explicitly future and time-addressed. It is not an early-
completed-state contradiction.

## Joshua 11:7–9 — ATTACK, PURSUIT, HORSES AND CHARIOTS

Joshua and all warriors attack suddenly at Merom. The source then says the LORD
delivers the coalition into Israel's hand. Israel strikes and chases along three
named routes until no one remains. Joshua performs the horse and chariot acts
as commanded.

Promise, attack, delivered state, pursuit and equipment treatment retain their
order. No horse mechanism or chariot inventory is supplied beyond the acts.

## Joshua 11:10–14 — HAZOR IS THE BURNING EXCEPTION

Joshua turns back, takes Hazor and strikes its king. Hazor is identified as the
former head of the kingdoms. Its population is destroyed and Hazor is burned.
The other cities and kings are captured and destroyed under the Moses command
lineage.

The source explicitly says Israel burns none of the mound cities except Hazor.
That exception prevents an all-cities-burning inference. Plunder and livestock
from those cities are retained; the addressed men are struck.

## Joshua 11:15–20 — COMMAND CHAIN, LAND SUMMARY, LONG WAR, ONE PEACE CITY

The command chain is stated: LORD to Moses, Moses to Joshua, Joshua performs it,
leaving nothing undone of that addressed command set. The land extent and king
outcomes are summarized, followed by the explicit statement that Joshua made
war a long time with those kings.

No city makes peace except the Hivites of Gibeon. The source attributes the
other cities' battle approach to the LORD hardening their hearts so they would
be destroyed without favor under the Moses command. This is retained as the
narrator's causal attribution. No unobserved mental process, independent motive
or free-will theory is added.

“Nothing undone” is scoped to the source's addressed command chain. Later
chapters are not imported into this Moment.

## Joshua 11:21–23 — ANAKIM ADDRESS, SURVIVOR EXCEPTION, WHOLE LAND AND REST

Joshua removes Anakim from named Israelite hill-country locations and their
cities. The source says none remain in the land of the children of Israel, then
explicitly preserves some in Gaza, Gath and Ashdod. The named survivor exception
is not a contradiction with the scoped Israel-land statement.

Joshua takes the whole land according to what the LORD spoke to Moses, gives it
to Israel by tribal divisions, and the land rests from war. These are the
chapter's closing states. Any later source that places remaining land or war
against them must close its own later Difference; it cannot be anticipated here.

## Character and world-ledger changes

- northern coalition, Merom attack and pursuit complete;
- horses are hamstrung and chariots burned under explicit command;
- Hazor alone is burned among the addressed mound cities;
- plunder/livestock retention and long-war summary are explicit;
- Gibeon remains the sole peace-city exception;
- hardening remains source-attributed causation without invented mental content;
- Anakim are removed from the scoped Israel land with Gaza/Gath/Ashdod survivors explicit;
- whole-land inheritance and rest-from-war become retained closing states;
- no contradiction machinery occurs;
- every living human, animal or plant Joe and face-like non-divine horse, chariot, sand, water, sword, fire, city, mound or boundary marker is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — NORTHERN HORSE-AND-CHARIOT DISPOSAL`;
- coalition size: `LIKE SAND / EXACT COUNT NOT INCLUDED`;
- appointment: `TOMORROW / THIS TIME`;
- route splitter: `SIDON / MISREPHOTH MAIM / MIZPAH EAST`;
- burn register: `HAZOR: YES / OTHER MOUND CITIES: NO`;
- duration: `A LONG TIME`;
- peace exception: `GIBEON ONLY`;
- Anakim residue: `GAZA / GATH / ASHDOD`;
- barcode: `CHB-JOS11-23-NOCRACK-HAZOR-REST-HELD`.

## FIR verification

- all 23 verse markers are represented in order;
- tomorrow-language remains future until the battle outcome;
- equipment acts follow their explicit command;
- Hazor and other mound-city burning states remain distinct;
- long-war wording is not overwritten by the later summary;
- hardening is retained as attribution without invented psychology;
- Anakim scope and survivor exception remain compatible;
- whole-land/rest state is retained without importing future disagreement;
- no unsupported CrackFlix, Captain, SKIP or YOINK is added;
- publication remains held and unpublished.

Continuation required: Joshua 12 records the east- and west-Jordan defeated
kings, territories and the thirty-one-king count.
