# CRACKHEAD JOSHUA 14

## Title page

**NINE AND A HALF BY LOT. CALEB WAITED FORTY-FIVE YEARS. GIVE ME HEBRON.**

Source parent: Joshua chapter 14, verses 1–15, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-014/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/013-WHOLE-LAND-TAKEN-VERY-MUCH-LAND-REMAINS-NINE-AND-A-HALF-EAST-INHERITANCE.md`.

CrackFlix routing: none. Caleb's proposed future expulsion of the Anakim does
not establish a completed occurrence against the retained Joshua 11 state.

## Causal foundation

```text
CANAAN INHERITANCE
-> ELEAZAR + JOSHUA + TRIBAL HOUSE HEADS DISTRIBUTE
-> LOT, AS LORD COMMANDED THROUGH MOSES
-> NINE TRIBES + WESTERN HALF-MANASSEH

EAST ALREADY GIVEN
-> TWO TRIBES + EASTERN HALF-MANASSEH
LEVI
-> NO TRIBAL LAND PORTION
-> DWELLING CITIES + PASTURE FOR LIVESTOCK/PROPERTY
JOSEPH
-> MANASSEH + EPHRAIM

CALEB AT 40
-> SENT FROM KADESH BARNEA
-> RETURNS HIS REPORT
-> MOSES SWEARS LAND PROMISE
-> 45 YEARS PASS
-> CALEB IS 85
-> REQUESTS HILL COUNTRY / HEBRON
-> JOSHUA BLESSES + GIVES HEBRON
-> INHERITANCE STATE CLOSES
```

## Joshua 14:1–5 — THE WESTERN DISTRIBUTION STARTS

Eleazar the priest, Joshua son of Nun and the heads of Israel's tribal fathers'
houses distribute the Canaan inheritances. The method is lot, under the command
the LORD gave through Moses, for nine tribes and the western half-tribe.

Moses' eastern allocation to two tribes and the eastern half-tribe remains a
completed parent. Levi receives no tribal land portion among them. Joseph is
counted through two tribes, Manasseh and Ephraim. The Levites receive dwelling
cities and pasture lands for livestock and property. These city/pasture
provisions do not become a tribal land inheritance by label substitution.

Israel performs the commanded division. The chapter states the distribution
act; later parcel detail may refine the result without replaying this opening.

## Joshua 14:6–9 — CALEB ADDRESSES THE FORTY-YEAR MOMENT

Judah approaches Joshua at Gilgal. Caleb son of Jephunneh the Kenizzite points
to the LORD's Kadesh Barnea speech through Moses concerning Caleb and Joshua.

Caleb states that he was forty when Moses sent him to spy out the land. He says
he returned the report as it was in his heart, while the accompanying brothers
made the people's heart melt, and that he wholly followed the LORD.

Moses' oath is retained as speech at that earlier Moment: the land Caleb walked
would become an inheritance for Caleb and his children because he followed the
LORD wholeheartedly. The promise is not backfilled as a parcel transfer at age
forty; its result closes later in this chapter.

## Joshua 14:10–12 — FORTY-FIVE YEARS LATER, AGE EIGHTY-FIVE

Caleb says the LORD has kept him alive for forty-five years since that speech
while Israel walked in the wilderness. Forty at sending plus forty-five elapsed
years yields his stated age of eighty-five.

He says his strength for war, going out and coming in, remains what it was on
the sending day. This is Caleb's present observable speech claim; the chapter
does not supply a strength test or a contradictory result.

Caleb requests the hill country spoken of on that earlier day. He recalls that
the Anakim were there and that the cities were great and fortified. “It may be”
that the LORD will be with him and that he will drive them out remains a future
conditional claim. No Anakim expulsion occurs in this chapter, so it cannot yet
close a contradiction with Joshua 11's no-Anakim-left state. That comparison is
retained for the next actual occurrence.

## Joshua 14:13–15 — HEBRON GIVEN

Joshua blesses Caleb and gives Hebron to him as an inheritance. Hebron becomes
Caleb's inheritance to the source's “this day,” attributed to his wholehearted
following of the LORD.

The city's former name is retained as Kiriath Arba, after the source-described
greatest man among the Anakim. The chapter closes with the land at rest from
war. That rest statement is a current state; Caleb's future conditional does
not turn it into an observed battle.

## Character and world-ledger changes

- Eleazar, Joshua and the house heads become the addressed western distributors;
- lot distribution and the nine-and-a-half recipient count are retained;
- Moses' eastern distribution remains a parent and is not performed again;
- Manasseh/Ephraim retain Joseph's two-tribe relation;
- Levite cities/pasture remain distinct from tribal land inheritance;
- Caleb's age chain closes exactly as 40 + 45 = 85;
- Caleb's report, wholehearted-following claim and Moses' oath remain attributed speech/history;
- Joshua's blessing and Hebron grant are completed acts;
- Kiriath Arba is retained as Hebron's former-name relation, not a second current city;
- Caleb's proposed Anakim expulsion remains future and creates no CrackFlix episode yet;
- no Captain, SKIP or YOINK occurs;
- every living human, animal or plant Joe and every face-like non-divine lot, city, pasture, mountain, receipt, age counter or nameplate is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — FORTY-FIVE-YEAR CLAIM TICKET`;
- lot machine: `9 + 1/2 / WEST ONLY`;
- east stamp: `ALREADY DISTRIBUTED — DO NOT PRINT AGAIN`;
- Caleb age display: `40 + 45 = 85`;
- strength meter: `CALEB SAYS: SAME`;
- Hebron receipt: `BLESSED / GIVEN / THIS DAY`;
- future warning: `IT MAY BE IS NOT DID`;
- old-name plate: `HEBRON / FORMERLY KIRIATH ARBA`;
- barcode: `CHB-JOS14-15-HEBRON-NOCRACK-HELD`.

## FIR verification

- all 15 verse markers are represented in order;
- west/east allocation actors, recipients and Moments remain distinct;
- Levi's cities/pasture are not collapsed into tribal land inheritance;
- Caleb's 40/45/85 chronology is retained without alteration;
- historical speech is not converted into earlier parcel delivery;
- Hebron blessing/grant/inheritance is completed in the current chapter;
- the Anakim expulsion remains prospective and no contradiction machinery is introduced;
- the rest-from-war state does not manufacture an unstated battle;
- no unsupported divine form, motive, strength measurement or causal mechanism is supplied;
- publication remains held and unpublished.

Continuation required: Joshua 15 gives Judah's borders and cities, completes
Caleb's Hebron Anakim expulsions, takes Debir through Othniel, gives Achsah land
and springs, and retains Jerusalem's Jebusite non-expulsion state.
