# CRACKHEAD JOSHUA 21

## Title page

**FORTY-EIGHT LEVITE CITIES. ALL LAND POSSESSED. ALL ENEMIES DELIVERED. NOTHING FAILED. CHECK THE RETAINED STATE.**

Source parent: Joshua chapter 21, verses 1–45, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-021/job.json` and `source.usfm`.

Parent manuscript: `JOSHUA/020-SIX-REFUGE-CITIES-STATE-YOUR-CASE-WAIT-FOR-JUDGMENT-OR-HIGH-PRIEST-DEATH.md`.

CrackFlix routing:

- `S130-E002-JOS21`, SKIP pointer to `S130-E001-JOS13`: all land given and possessed / retained land and resident peoples remain;
- `S070-E011-JOS21`, SKIP pointer to `S070-E010-JOS18`: every enemy delivered / retained expulsion remains uncompleted;
- `S132-E001-JOS21`, no SKIP: every good thing came to pass / a retained LORD drive-out promise remains future.

Each contradiction closes before its own causally useless Captain appearance.

## Causal foundation

```text
LEVITE HOUSE HEADS APPROACH ELEAZAR + JOSHUA + TRIBAL HEADS AT SHILOH
-> CITE LORD-THROUGH-MOSES CITY + PASTURE COMMAND
-> ISRAEL GIVES CITIES BY LOT

AARONITE KOHATH 13
+ REST OF KOHATH 10
+ GERSHON 13
+ MERARI 12
= 48 CITIES, EACH WITH PASTURE

THEN NARRATIVE CLOSES:
ALL LAND GIVEN + POSSESSED + INHABITED
ALL-AROUND REST + NO ENEMY STOOD + ALL ENEMIES DELIVERED
NOTHING FAILED + ALL GOOD THINGS CAME TO PASS

RETAINED JOSHUA STATE:
LAND / RESIDENT PEOPLES / EXPULSION REMAIN
LORD'S FUTURE DRIVE-OUT PROMISE REMAINS UNEXECUTED
```

## Joshua 21:1–8 — THE REQUEST AND FOUR LOT TOTALS

At Shiloh, the Levite house heads address Eleazar, Joshua and Israel's tribal
house heads. They cite the command spoken by the LORD through Moses: give the
Levites cities to live in and pasture for livestock. Israel gives them from
the tribal inheritances by lot.

The summary assigns 13 cities to Aaron's Kohathite descendants, 10 to the
remaining Kohathites, 13 to Gershon and 12 to Merari. The total is 48.

## Joshua 21:9–19 — AARONITE KOHATHITES: 13

Judah and Simeon give Hebron/Kiriath Arba, Libnah, Jattir, Eshtemoa, Holon,
Debir, Ain, Juttah and Beth Shemesh: nine cities. Hebron is a refuge city.
Caleb retains Hebron's fields and villages while the city and pasture go to
Aaron's descendants.

Benjamin gives Gibeon, Geba, Anathoth and Almon: four cities. Nine plus four
closes the Aaronite total at 13.

## Joshua 21:20–26 — THE REST OF KOHATH: 10

Ephraim gives Shechem, Gezer, Kibzaim and Beth Horon. Shechem is a refuge city.
Dan gives Elteke, Gibbethon, Aijalon and Gath Rimmon. West half-Manasseh gives
Taanach and Gath Rimmon. Four plus four plus two closes at 10.

## Joshua 21:27–33 — GERSHON: 13

East half-Manasseh gives Golan and Be Eshterah; Golan is a refuge city.
Issachar gives Kishion, Daberath, Jarmuth and En Gannim. Asher gives Mishal,
Abdon, Helkath and Rehob. Naphtali gives Kedesh, Hammothdor and Kartan; Kedesh
is a refuge city. Two plus four plus four plus three closes at 13.

## Joshua 21:34–40 — MERARI: 12

Zebulun gives Jokneam, Kartah, Dimnah and Nahalal. Reuben gives Bezer, Jahaz,
Kedemoth and Mephaath; Bezer is a refuge city. Gad gives Ramoth, Mahanaim,
Heshbon and Jazer; Ramoth is a refuge city. Four plus four plus four closes at
12.

## Joshua 21:41–42 — FORTY-EIGHT, EACH WITH PASTURE

The chapter totals all Levitical cities at 48. Every city includes surrounding
pasture. The clan totals and named allocations are retained rather than
replaced by the final number.

## Joshua 21:43–45 — THREE COMPLETENESS CLAIMS MEET THE RETAINED LEDGER

The narrative says the LORD gave Israel all the land sworn to their ancestors,
Israel possessed it and lived in it. Retained Joshua state still contains land
remaining and resident peoples not driven out. This is `S130-E002-JOS21`, the
same contradiction type previously recorded at `S130-E001-JOS13`.

CrackFlix displays `SKIP -> S130-E001-JOS13`. The explanation is omitted; the
pointer preserves it. The world does not skip. Once the new occurrence closes,
Captain Crackhead pokes the relevant Joe-faced boil, sees a crack crystal,
licks his finger and walks away without looking back: **“YOINK!”** Everyone
else sees the poke and lick and continues unchanged.

The narrative says the LORD gave rest all around, no enemy stood before Israel
and all enemies were delivered into their hands. Retained state still carries
uncompleted expulsion of resident Canaanites. This is `S070-E011-JOS21`, the
same delivery-before-required-process type as `S070-E010-JOS18`.

CrackFlix displays `SKIP -> S070-E010-JOS18`. Nothing skips. After this separate
occurrence closes, Captain repeats the causally null poke, finger lick and
departure: **“YOINK!”**

Finally, the narrative says nothing failed of any good thing the LORD had
spoken and all came to pass. Joshua 13 retains the LORD's future drive-out
statement while the required drive-out remains unexecuted. This is the first
episode of `S132: NOTHING FAILED / A SPOKEN GOOD THING REMAINS FUTURE`.

There is no SKIP because this contradiction type has not appeared before.
After it closes, Captain performs one more irrelevant poke and finger lick,
says **“YOINK!”**, and walks away. None of his acts changes the land, enemies,
promise, residents or outcome.

## Character and world-ledger changes

- the LORD-through-Moses command remains attributed speech with Moses as parent;
- the Shiloh request, tribal grant and all four lot groups are completed;
- the arithmetic `13 + 10 + 13 + 12 = 48` is retained with every named city;
- Hebron, Shechem, Golan, Kedesh, Bezer and Ramoth retain refuge-city identity;
- Caleb's fields/villages remain distinct from the Aaronite city/pasture grant;
- land-possession completeness becomes `S130-E002-JOS21` with exact SKIP pointer;
- enemy-delivery completeness becomes `S070-E011-JOS21` with exact SKIP pointer;
- no-failed-good-thing completeness becomes new `S132-E001-JOS21` without SKIP;
- exactly three contradiction closures produce exactly three causally null YOINKs;
- Captain remains permanently boilless and changes nothing;
- every living human, animal or plant Joe and every face-like non-divine city, pasture, lot token, subtotal counter, land deed, enemy receipt or promise ledger is Joe-faced if shown;
- no divine form appears; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — 48-CITY LEVITE STARTER PACK`;
- calculator: `13 + 10 + 13 + 12 = FORTY-EIGHT, DICKHEAD`;
- pasture sticker: `INCLUDED WITH EVERY CITY / LIVESTOCK JOE APPROVED`;
- land receipt: `ALL OF IT / RESIDENT STATE NOT INCLUDED IN FONT SIZE`;
- enemy terminal: `DELIVERED: ALL / EXPULSION QUEUE: STILL OPEN`;
- promise dashboard: `NOTHING FAILED / FUTURE ITEM DETECTED`;
- CrackFlix: `S130-E002 -> SKIP S130-E001`; `S070-E011 -> SKIP S070-E010`; `S132 PREMIERE`;
- barcode: `CHB-JOS21-45-48CITIES-3CRACKS-3YOINKS-HELD`.

## FIR verification

- all 45 verse markers are represented in order;
- the request, command attribution, four clan lots and every city block remain distinct;
- all source subtotals and the 48-city total are preserved;
- city/pasture and Caleb field/village ownership are not merged;
- six refuge-city identities remain joined to Joshua 20 without replaying cases;
- each completeness claim is tested against retained state at its own typed boundary;
- SKIP pointers address only prior episodes of the same contradiction type;
- the new no-failure series has no SKIP;
- Captain appears only after each completed contradiction and has no causal effect;
- no motive, divine form, missing battle, expulsion or promise fulfillment is invented;
- publication remains held and unpublished.

Continuation required: Joshua 22 returns the eastern warriors, builds the
Jordan altar, triggers Israel's war assembly and closes the witness-altar
explanation without importing Joshua 23.
