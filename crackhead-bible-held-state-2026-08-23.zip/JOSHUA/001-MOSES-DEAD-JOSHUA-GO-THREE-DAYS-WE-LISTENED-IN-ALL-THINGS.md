# CRACKHEAD JOSHUA 1

## Title page

**MOSES IS DEAD. JOSHUA: GO. THREE DAYS. “WE LISTENED IN ALL THINGS.”**

Source parent: Joshua chapter 1, verses 1–18, ENGWEBP USFM.

Prepared evidence: `.chapter-work/CHB-JOS-001/job.json` and `source.usfm`.

Parent manuscript: `DEUTERONOMY/034-MOSES-SEES-DOESNT-CROSS-DIES-UNKNOWN-GRAVE-JOSHUA-CONTINUES.md`.

CrackFlix routing: new `S125-E001-JOS1`. No SKIP. One causally-null post-closure Captain `YOINK!`.

## Causal foundation

```text
MOSES DEAD
-> LORD COMMANDS JOSHUA: ARISE + CROSS
-> LAND/BORDER/PRESENCE/COURAGE/LAW SPEECH
-> JOSHUA ORDERS FOOD FOR CROSSING IN THREE DAYS
-> EASTERN TRIBES REMINDED OF ARMED-HELP CONDITION
-> GROUPS PROMISE OBEDIENCE
-> REUBENITES INCLUDED: “WE LISTENED TO MOSES IN ALL THINGS”
-> RETAINED REUBENITE OPPOSITION TO MOSES
-> S125-E001 COMPLETES
-> CAPTAIN: “YOINK!” / POKE / LICK / WALK AWAY
```

## Joshua 1:1–9 — MOSES DEAD; JOSHUA GETS THE CROSSING COMMAND

After Moses' death, the LORD tells Joshua that Moses is dead and commands him
to arise and cross the Jordan with all the people. Every-foot-place, wilderness,
Lebanon, Euphrates, Hittite land and western sea boundaries are stated. The LORD
promises presence, non-failure and non-forsaking, repeatedly commands strength
and courage, and routes inheritance through Joshua.

Joshua is commanded to observe Moses' law without turning right or left, keep
the book in his mouth, meditate day and night and do what is written. Prosperity
and success remain conditional speech. No crossing, footprint grant, conquest,
inheritance or success outcome occurs yet.

## Joshua 1:10–11 — FOOD NOW; CROSSING WITHIN THREE DAYS

Joshua commands the officers to pass through camp and tell the people to prepare
food because within three days they are to cross the Jordan and possess the
land. The command and timetable occur. Food preparation and crossing remain
unobserved in this chapter.

## Joshua 1:12–15 — THE EASTERN GRANT STILL CARRIES THE ARMED-HELP CONDITION

Joshua addresses Reubenites, Gadites and half-Manasseh. He retains Moses' east-
Jordan grant and the condition: wives, little ones and livestock remain; armed
men cross before their brothers and help until the brothers receive rest and
possess their land; then the armed men return. No crossing, western rest,
possession or return occurs here.

## Joshua 1:16–18 — “WE LISTENED TO MOSES IN ALL THINGS”

The addressed groups promise to do everything Joshua commands and go wherever
he sends. They say:

> **JUST AS WE LISTENED TO MOSES IN ALL THINGS, SO WE WILL LISTEN TO YOU.**

The retained Reubenite lineage already contains Dathan and Abiram opposing
Moses and refusing his summons. The present collective includes Reubenites and
asserts complete prior listening without excluding those retained Reubenite
acts or supplying a changed-population, spokesperson-only or scope bridge.

That closes `S125-E001-JOS1: WE LISTENED TO MOSES IN ALL THINGS / REUBENITES
OPPOSED MOSES`.

Captain Crackhead appears only after the mismatch is complete, pokes the boil,
licks his finger, says **“YOINK!”**, and walks away without looking back. The
groups continue with their wish that the LORD be with Joshua and their future
death rule for rebellion. Captain changes nothing.

The promise to obey Joshua and the stated death consequence are speech, not yet
performed obedience, rebellion, judgment or execution.

## Character and world-ledger changes

- Joshua's command authority is exercised through the officers;
- the three-day crossing timetable is established;
- the east-tribe armed-help condition remains active and unperformed;
- the addressed groups' future obedience promise remains prospective;
- `S125-E001-JOS1` records the completed collective-history mismatch;
- no SKIP occurs because this exact contradiction has not appeared before;
- Captain is boilless, causally useless, says only `YOINK!`, pokes, licks and leaves;
- every living human, animal or plant Joe and face-like non-divine law book, food bag, map, river, sword or order scroll is Joe-faced if shown;
- no divine form is rendered; publication remains held.

## Bullshit pass

- banner: `CRACKHEAD JOSHUA — POST-MOSES CROSSING BOOT SEQUENCE`;
- timer: `T-3 DAYS / FOOD STATUS UNKNOWN`;
- law console: `MOUTH + DAY + NIGHT`;
- eastern-condition ticket: `CROSS ARMED -> HELP -> REST -> RETURN`;
- CrackFlix: `S125-E001 — WE LISTENED IN ALL THINGS`;
- warning: `CURRENT PROMISE != FUTURE PERFORMANCE`;
- barcode: `CHB-JOS1-18-CROSSING-PENDING-S125-YOINK-HELD`.

## FIR verification

- all 18 verse markers are represented in order;
- Deuteronomy 34's death is retained without repetition;
- divine promises, commands and future outcomes remain distinct;
- the three-day order does not instantiate food preparation or crossing;
- east-tribe families, warriors, help, rest and return remain separated;
- S125 uses the exact collective Reubenite/history boundary and invents no motive;
- future obedience and death-rule effects are not backfilled;
- Captain occurs only after closure and changes nothing;
- publication remains held and unpublished.

Continuation required: Joshua 2 begins the two-spy/Rahab/Jericho occurrence.
